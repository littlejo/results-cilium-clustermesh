# Cilium debug information

#### Cilium environment keys

```
proxy-portrange-max:20000
ipv4-node:auto
node-port-acceleration:disabled
ipv6-node:auto
egress-masquerade-interfaces:ens+
node-port-range:
tofqdns-idle-connection-grace-period:0s
enable-service-topology:false
bpf-auth-map-max:524288
enable-ingress-controller:false
bpf-sock-rev-map-max:262144
ipv4-native-routing-cidr:
nat-map-stats-interval:30s
bpf-ct-global-any-max:262144
k8s-namespace:kube-system
endpoint-queue-size:25
enable-external-ips:false
cluster-name:cmesh39
kvstore-periodic-sync:5m0s
tofqdns-pre-cache:
tofqdns-dns-reject-response-code:refused
gops-port:9890
cluster-id:39
hubble-recorder-storage-path:/var/run/cilium/pcaps
hubble-export-allowlist:
ipv4-range:auto
debug:false
enable-l2-pod-announcements:false
cgroup-root:/run/cilium/cgroupv2
enable-vtep:false
bpf-ct-timeout-regular-tcp-syn:1m0s
bpf-lb-acceleration:disabled
hubble-flowlogs-config-path:
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
enable-mke:false
enable-cilium-api-server-access:
hubble-event-buffer-capacity:4095
enable-bpf-clock-probe:false
bypass-ip-availability-upon-restore:false
enable-k8s-endpoint-slice:true
bpf-lb-sock-hostns-only:false
node-port-mode:snat
trace-payloadlen:128
cmdref:
prepend-iptables-chains:true
tunnel-protocol:vxlan
monitor-aggregation-flags:all
bgp-config-path:/var/lib/cilium/bgp/config.yaml
conntrack-gc-interval:0s
enable-bpf-masquerade:false
enable-host-legacy-routing:false
hubble-prefer-ipv6:false
vtep-mask:
enable-masquerade-to-route-source:false
k8s-client-qps:10
wireguard-persistent-keepalive:0s
hubble-listen-address::4244
enable-wireguard-userspace-fallback:false
static-cnp-path:
hubble-redact-enabled:false
endpoint-bpf-prog-watchdog-interval:30s
encrypt-interface:
max-connected-clusters:255
bpf-map-event-buffers:
ipam-default-ip-pool:default
clustermesh-config:/var/lib/cilium/clustermesh/
hubble-drop-events-interval:2m0s
force-device-detection:false
set-cilium-node-taints:true
cilium-endpoint-gc-interval:5m0s
mtu:0
hubble-disable-tls:false
allow-icmp-frag-needed:true
bpf-neigh-global-max:524288
service-no-backend-response:reject
dnsproxy-enable-transparent-mode:true
identity-change-grace-period:5s
enable-l7-proxy:true
hubble-event-queue-size:0
enable-ipv6:false
read-cni-conf:
enable-cilium-health-api-server-access:
bpf-node-map-max:16384
enable-icmp-rules:true
hubble-monitor-events:
iptables-lock-timeout:5s
ipv4-service-loopback-address:169.254.42.1
enable-ipv4-big-tcp:false
encryption-strict-mode-allow-remote-node-identities:false
annotate-k8s-node:false
controller-group-metrics:
http-retry-timeout:0
enable-ipsec-xfrm-state-caching:true
enable-health-check-nodeport:true
enable-wireguard:false
direct-routing-skip-unreachable:false
arping-refresh-period:30s
auto-create-cilium-node-resource:true
vtep-cidr:
join-cluster:false
bpf-ct-timeout-service-tcp:2h13m20s
dnsproxy-concurrency-processing-grace-period:0s
mesh-auth-spire-admin-socket:
envoy-config-timeout:2m0s
bpf-fragments-map-max:8192
proxy-idle-timeout-seconds:60
use-cilium-internal-ip-for-ipsec:false
enable-local-redirect-policy:false
hubble-drop-events:false
k8s-service-cache-size:128
bgp-announce-lb-ip:false
gateway-api-secrets-namespace:
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
dnsproxy-concurrency-limit:0
enable-hubble-recorder-api:true
kvstore:
hubble-redact-http-urlquery:false
kube-proxy-replacement:false
envoy-secrets-namespace:
derive-masq-ip-addr-from-device:
enable-ipv6-masquerade:true
enable-route-mtu-for-cni-chaining:false
proxy-xff-num-trusted-hops-egress:0
proxy-xff-num-trusted-hops-ingress:0
l2-announcements-lease-duration:15s
log-opt:
multicast-enabled:false
config:
enable-l2-neigh-discovery:true
enable-k8s-terminating-endpoint:true
synchronize-k8s-nodes:true
http-normalize-path:true
local-router-ipv6:
bpf-policy-map-full-reconciliation-interval:15m0s
config-dir:/tmp/cilium/config-map
k8s-sync-timeout:3m0s
l2-announcements-retry-period:2s
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
install-iptables-rules:true
label-prefix-file:
enable-srv6:false
bpf-lb-rss-ipv4-src-cidr:
enable-custom-calls:false
l2-pod-announcements-interface:
bpf-lb-source-range-map-max:0
bpf-lb-service-map-max:0
bpf-lb-maglev-map-max:0
policy-trigger-interval:1s
proxy-max-connection-duration-seconds:0
kvstore-connectivity-timeout:2m0s
k8s-heartbeat-timeout:30s
monitor-aggregation-interval:5s
enable-health-checking:true
socket-path:/var/run/cilium/cilium.sock
enable-svc-source-range-check:true
srv6-encap-mode:reduced
bpf-events-drop-enabled:true
hubble-export-file-path:
hubble-export-file-compress:false
restore:true
proxy-gid:1337
auto-direct-node-routes:false
agent-liveness-update-interval:1s
hubble-export-fieldmask:
http-max-grpc-timeout:0
enable-well-known-identities:false
agent-labels:
disable-envoy-version-check:false
hubble-drop-events-reasons:auth_required,policy_denied
max-internal-timer-delay:0s
clustermesh-ip-identities-sync-timeout:1m0s
envoy-config-retry-interval:15s
prometheus-serve-addr:
enable-metrics:true
ipam-multi-pool-pre-allocation:
metrics:
bpf-ct-timeout-regular-any:1m0s
enable-node-port:false
enable-host-firewall:false
enable-bpf-tproxy:false
disable-external-ip-mitigation:false
enable-host-port:false
datapath-mode:veth
node-port-algorithm:random
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
procfs:/host/proc
allocator-list-timeout:3m0s
enable-ipv6-big-tcp:false
certificates-directory:/var/run/cilium/certs
enable-envoy-config:false
l2-announcements-renew-deadline:5s
identity-gc-interval:15m0s
bpf-ct-timeout-service-any:1m0s
egress-gateway-policy-map-max:16384
policy-accounting:true
http-idle-timeout:0
kvstore-max-consecutive-quorum-errors:2
hubble-redact-http-headers-allow:
bpf-lb-affinity-map-max:0
enable-ipv6-ndp:false
proxy-admin-port:0
local-max-addr-scope:252
vtep-endpoint:
enable-k8s-networkpolicy:true
custom-cni-conf:false
enable-health-check-loadbalancer-ip:false
cluster-pool-ipv4-mask-size:24
config-sources:config-map:kube-system/cilium-config
enable-nat46x64-gateway:false
exclude-node-label-patterns:
cni-chaining-target:
k8s-require-ipv4-pod-cidr:false
lib-dir:/var/lib/cilium
ipv6-cluster-alloc-cidr:f00d::/64
enable-ipv4:true
cni-log-file:/var/run/cilium/cilium-cni.log
enable-ipv4-masquerade:true
mesh-auth-gc-interval:5m0s
enable-runtime-device-detection:true
enable-ipsec:false
node-labels:
bpf-events-policy-verdict-enabled:true
enable-identity-mark:true
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
enable-bandwidth-manager:false
mesh-auth-spiffe-trust-domain:spiffe.cilium
enable-ipv4-fragment-tracking:true
cflags:
bpf-lb-algorithm:random
mesh-auth-enabled:true
nodeport-addresses:
bpf-lb-mode:snat
enable-node-selector-labels:false
node-port-bind-protection:true
version:false
enable-recorder:false
agent-health-port:9879
keep-config:false
use-full-tls-context:false
ipv6-service-range:auto
enable-bbr:false
bpf-lb-external-clusterip:false
bpf-lb-maglev-table-size:16381
enable-k8s-api-discovery:false
k8s-client-burst:20
log-driver:
mke-cgroup-mount:
exclude-local-address:
tofqdns-proxy-response-max-delay:100ms
hubble-skip-unknown-cgroup-ids:true
bpf-ct-timeout-regular-tcp:2h13m20s
cluster-health-port:4240
clustermesh-sync-timeout:1m0s
pprof-address:localhost
proxy-prometheus-port:0
enable-ipv4-egress-gateway:false
ipv6-pod-subnets:
tofqdns-enable-dns-compression:true
remove-cilium-node-taints:true
preallocate-bpf-maps:false
bpf-ct-global-tcp-max:524288
k8s-kubeconfig-path:
enable-tracing:false
hubble-recorder-sink-queue-size:1024
proxy-portrange-min:10000
log-system-load:false
hubble-export-file-max-size-mb:10
enable-unreachable-routes:false
enable-session-affinity:false
api-rate-limit:
enable-endpoint-health-checking:true
clustermesh-enable-endpoint-sync:false
enable-encryption-strict-mode:false
k8s-client-connection-keep-alive:30s
clustermesh-enable-mcs-api:false
iptables-random-fully:false
mesh-auth-signal-backoff-duration:1s
dnsproxy-lock-count:131
identity-allocation-mode:crd
enable-gateway-api:false
envoy-log:
enable-stale-cilium-endpoint-cleanup:true
dnsproxy-lock-timeout:500ms
k8s-client-connection-timeout:30s
enable-monitor:true
http-retry-count:3
fixed-identity-mapping:
enable-auto-protect-node-port-range:true
ipam:cluster-pool
enable-ipsec-encrypted-overlay:false
tofqdns-min-ttl:0
encryption-strict-mode-cidr:
k8s-require-ipv6-pod-cidr:false
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
allow-localhost:auto
identity-heartbeat-timeout:30m0s
routing-mode:tunnel
mesh-auth-mutual-listener-port:0
enable-ipip-termination:false
policy-audit-mode:false
max-controller-interval:0
bpf-policy-map-max:16384
pprof-port:6060
disable-iptables-feeder-rules:
enable-pmtu-discovery:false
crd-wait-timeout:5m0s
unmanaged-pod-watcher-interval:15
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
proxy-max-requests-per-connection:0
monitor-queue-size:0
enable-sctp:false
ipv6-mcast-device:
tunnel-port:0
hubble-export-file-max-backups:5
encrypt-node:false
ipsec-key-rotation-duration:5m0s
enable-bgp-control-plane:false
policy-cidr-match-mode:
enable-ip-masq-agent:false
enable-k8s:true
hubble-redact-kafka-apikey:false
ipv6-native-routing-cidr:
local-router-ipv4:
egress-gateway-reconciliation-trigger-interval:1s
pprof:false
operator-prometheus-serve-addr::9963
http-request-timeout:3600
state-dir:/var/run/cilium
bpf-lb-sock-terminate-pod-connections:false
hubble-export-denylist:
bpf-lb-sock:false
hubble-redact-http-userinfo:true
kvstore-opt:
envoy-keep-cap-netbindservice:false
ipsec-key-file:
ipv4-pod-subnets:
cni-external-routing:false
direct-routing-device:
external-envoy-proxy:true
cluster-pool-ipv4-cidr:10.38.0.0/16
tofqdns-max-deferred-connection-deletes:10000
bpf-lb-rss-ipv6-src-cidr:
hubble-metrics-server:
enable-cilium-endpoint-slice:false
k8s-service-proxy-name:
dns-policy-unload-on-shutdown:false
tofqdns-proxy-port:0
bpf-lb-dsr-l4-xlate:frontend
enable-ipsec-key-watcher:true
bpf-ct-timeout-regular-tcp-fin:10s
cni-exclusive:true
bpf-ct-timeout-service-tcp-grace:1m0s
ipv4-service-range:auto
identity-restore-grace-period:30s
egress-multi-home-ip-rule-compat:false
enable-active-connection-tracking:false
proxy-connect-timeout:2
kvstore-lease-ttl:15m0s
enable-tcx:true
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
fqdn-regex-compile-lru-size:1024
bpf-events-trace-enabled:true
tofqdns-endpoint-max-ip-per-hostname:50
nat-map-stats-entries:32
disable-endpoint-crd:false
trace-sock:true
dnsproxy-insecure-skip-transparent-mode-check:false
bpf-lb-dsr-dispatch:opt
bpf-map-dynamic-size-ratio:0.0025
policy-queue-size:100
bpf-root:/sys/fs/bpf
debug-verbose:
mesh-auth-mutual-connect-timeout:5s
bgp-announce-pod-cidr:false
dns-max-ips-per-restored-rule:1000
enable-policy:default
devices:
bpf-lb-service-backend-map-max:0
mesh-auth-queue-size:1024
hubble-socket-path:/var/run/cilium/hubble.sock
enable-xdp-prefilter:false
enable-l2-announcements:false
install-no-conntrack-iptables-rules:false
kube-proxy-replacement-healthz-bind-address:
vlan-bpf-bypass:
hubble-redact-http-headers-deny:
ipv6-range:auto
enable-local-node-route:true
ipam-cilium-node-update-rate:15s
ingress-secrets-namespace:
conntrack-gc-max-interval:0s
nodes-gc-interval:5m0s
bpf-nat-global-max:524288
container-ip-local-reserved-ports:auto
bpf-lb-rev-nat-map-max:0
route-metric:0
enable-endpoint-routes:false
set-cilium-is-up-condition:true
vtep-mac:
k8s-api-server:
hubble-metrics:
bpf-filter-priority:1
endpoint-gc-interval:5m0s
ip-masq-agent-config-path:/etc/config/ip-masq-agent
labels:
monitor-aggregation:medium
cni-chaining-mode:none
envoy-base-id:0
enable-xt-socket-fallback:true
mesh-auth-rotated-identities-queue-size:1024
dnsproxy-socket-linger-timeout:10
bpf-lb-map-max:65536
enable-high-scale-ipcache:false
operator-api-serve-addr:127.0.0.1:9234
enable-hubble:true
```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 14698030                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 14698030                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 14698030                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400cc00000 rw-p 00000000 00:00 0 
400cc00000-4010000000 ---p 00000000 00:00 0 
ffff5f185000-ffff5f38b000 rw-p 00000000 00:00 0 
ffff5f393000-ffff5f4b4000 rw-p 00000000 00:00 0 
ffff5f4b4000-ffff5f4f5000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff5f4f5000-ffff5f536000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff5f536000-ffff5f576000 rw-p 00000000 00:00 0 
ffff5f576000-ffff5f578000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff5f578000-ffff5f57a000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff5f57a000-ffff5fb11000 rw-p 00000000 00:00 0 
ffff5fb11000-ffff5fc11000 rw-p 00000000 00:00 0 
ffff5fc11000-ffff5fc22000 rw-p 00000000 00:00 0 
ffff5fc22000-ffff61c22000 rw-p 00000000 00:00 0 
ffff61c22000-ffff61ca2000 ---p 00000000 00:00 0 
ffff61ca2000-ffff61ca3000 rw-p 00000000 00:00 0 
ffff61ca3000-ffff81ca2000 ---p 00000000 00:00 0 
ffff81ca2000-ffff81ca3000 rw-p 00000000 00:00 0 
ffff81ca3000-ffffa1c32000 ---p 00000000 00:00 0 
ffffa1c32000-ffffa1c33000 rw-p 00000000 00:00 0 
ffffa1c33000-ffffa5c24000 ---p 00000000 00:00 0 
ffffa5c24000-ffffa5c25000 rw-p 00000000 00:00 0 
ffffa5c25000-ffffa6422000 ---p 00000000 00:00 0 
ffffa6422000-ffffa6423000 rw-p 00000000 00:00 0 
ffffa6423000-ffffa6522000 ---p 00000000 00:00 0 
ffffa6522000-ffffa6582000 rw-p 00000000 00:00 0 
ffffa6582000-ffffa6584000 r--p 00000000 00:00 0                          [vvar]
ffffa6584000-ffffa6585000 r-xp 00000000 00:00 0                          [vdso]
fffff4f62000-fffff4f83000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium encryption



#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.38.0.0/24, 
Allocated addresses:
  10.38.0.100 (kube-system/coredns-cc6ccd49c-r5trn)
  10.38.0.142 (kube-system/clustermesh-apiserver-6b8445b784-q9cbn)
  10.38.0.205 (router)
  10.38.0.236 (health)
  10.38.0.245 (kube-system/coredns-cc6ccd49c-p82x8)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: ce69ada5688ed3fa
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    51s ago        never        0       no error   
  ct-map-pressure                                                     22s ago        never        0       no error   
  daemon-validate-config                                              38s ago        never        0       no error   
  dns-garbage-collector-job                                           54s ago        never        0       no error   
  endpoint-1350-regeneration-recovery                                 never          never        0       no error   
  endpoint-1989-regeneration-recovery                                 never          never        0       no error   
  endpoint-2297-regeneration-recovery                                 never          never        0       no error   
  endpoint-71-regeneration-recovery                                   never          never        0       no error   
  endpoint-936-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         4m54s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                22s ago        never        0       no error   
  ipcache-inject-labels                                               52s ago        never        0       no error   
  k8s-heartbeat                                                       25s ago        never        0       no error   
  link-cache                                                          7s ago         never        0       no error   
  local-identity-checkpoint                                           14m16s ago     never        0       no error   
  node-neighbor-link-updater                                          2s ago         never        0       no error   
  remote-etcd-cmesh1                                                  6m50s ago      never        0       no error   
  remote-etcd-cmesh10                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh100                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh101                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh102                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh103                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh104                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh105                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh106                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh107                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh108                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh109                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh11                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh110                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh111                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh112                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh113                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh114                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh115                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh116                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh117                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh118                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh119                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh12                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh120                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh121                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh122                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh123                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh124                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh125                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh126                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh127                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh128                                                6m50s ago      never        0       no error   
  remote-etcd-cmesh13                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh14                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh15                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh16                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh17                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh18                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh19                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh2                                                  6m50s ago      never        0       no error   
  remote-etcd-cmesh20                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh21                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh22                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh23                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh24                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh25                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh26                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh27                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh28                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh29                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh3                                                  6m50s ago      never        0       no error   
  remote-etcd-cmesh30                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh31                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh32                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh33                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh34                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh35                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh36                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh37                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh38                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh4                                                  6m50s ago      never        0       no error   
  remote-etcd-cmesh40                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh41                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh42                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh43                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh44                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh45                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh46                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh47                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh48                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh49                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh5                                                  6m50s ago      never        0       no error   
  remote-etcd-cmesh50                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh51                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh52                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh53                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh54                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh55                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh56                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh57                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh58                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh59                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh6                                                  6m50s ago      never        0       no error   
  remote-etcd-cmesh60                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh61                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh62                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh63                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh64                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh65                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh66                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh67                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh68                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh69                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh7                                                  6m50s ago      never        0       no error   
  remote-etcd-cmesh70                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh71                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh72                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh73                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh74                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh75                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh76                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh77                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh78                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh79                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh8                                                  6m50s ago      never        0       no error   
  remote-etcd-cmesh80                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh81                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh82                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh83                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh84                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh85                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh86                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh87                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh88                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh89                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh9                                                  6m50s ago      never        0       no error   
  remote-etcd-cmesh90                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh91                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh92                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh93                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh94                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh95                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh96                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh97                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh98                                                 6m50s ago      never        0       no error   
  remote-etcd-cmesh99                                                 6m50s ago      never        0       no error   
  resolve-identity-1350                                               2m33s ago      never        0       no error   
  resolve-identity-1989                                               4m50s ago      never        0       no error   
  resolve-identity-2297                                               4m51s ago      never        0       no error   
  resolve-identity-71                                                 4m52s ago      never        0       no error   
  resolve-identity-936                                                4m50s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-6b8445b784-q9cbn   7m33s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-p82x8                  14m50s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-r5trn                  14m50s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      14m52s ago     never        0       no error   
  sync-policymap-1350                                                 7m33s ago      never        0       no error   
  sync-policymap-1989                                                 14m47s ago     never        0       no error   
  sync-policymap-2297                                                 14m47s ago     never        0       no error   
  sync-policymap-71                                                   14m51s ago     never        0       no error   
  sync-policymap-936                                                  14m47s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (1350)                                   3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1989)                                   10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (936)                                    9s ago         never        0       no error   
  sync-utime                                                          52s ago        never        0       no error   
  write-cni-file                                                      14m54s ago     never        0       no error   
Proxy Status:            OK, ip 10.38.0.205, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 2555904, max 2621439
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 65.88   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
71         Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                
                                                           reserved:host                                                                                             
936        Disabled           Disabled          2567020    k8s:eks.amazonaws.com/component=coredns                                             10.38.0.245   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh39                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
1350       Disabled           Disabled          2616627    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.38.0.142   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh39                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
1989       Disabled           Disabled          2567020    k8s:eks.amazonaws.com/component=coredns                                             10.38.0.100   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh39                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
2297       Disabled           Disabled          4          reserved:health                                                                     10.38.0.236   ready   
```

#### BPF Policy Get 71

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 71

```
Invalid argument: unknown type 71
```


#### Endpoint Get 71

```
[
  {
    "id": 71,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-71-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f5f0b0de-497c-40fa-bea9-5b2e7a9cfb71"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-71",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:52.829Z",
            "success-count": 3
          },
          "uuid": "177ca722-65ef-4385-9b13-ea4c6a26a656"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-71",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:13:53.915Z",
            "success-count": 1
          },
          "uuid": "fc4a3c8a-7929-4424-8db5-36dd22200af1"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:56Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "e6:79:c3:19:87:56",
        "interface-name": "cilium_host",
        "mac": "e6:79:c3:19:87:56"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 71

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 71

```
Timestamp              Status   State                   Message
2024-10-25T10:21:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:56Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:13:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:13:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:54Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:13:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:13:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:52Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:52Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:52Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 936

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    84146   967       0        
Allow    Egress      0          ANY          NONE         disabled    14038   146       0        

```


#### BPF CT List 936

```
Invalid argument: unknown type 936
```


#### Endpoint Get 936

```
[
  {
    "id": 936,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-936-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "55e30062-9bd0-4e07-bb12-068ac49199a7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-936",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:55.127Z",
            "success-count": 3
          },
          "uuid": "05b41a25-bd55-4133-9095-1c3e5ddb44cb"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-p82x8",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:13:55.126Z",
            "success-count": 1
          },
          "uuid": "da099189-ea6a-4255-a96a-eb59c2462324"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-936",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:13:57.404Z",
            "success-count": 1
          },
          "uuid": "ebb23c96-daca-4377-a94e-b53d71db05b2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (936)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:45.204Z",
            "success-count": 91
          },
          "uuid": "115b9213-9221-4f8e-a65a-4c443910a69e"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "8e8f30643264ecb4ca3985de6db6e1b953322c4d741fb4fe8b20160add0118a7:eth0",
        "container-id": "8e8f30643264ecb4ca3985de6db6e1b953322c4d741fb4fe8b20160add0118a7",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-p82x8",
        "pod-name": "kube-system/coredns-cc6ccd49c-p82x8"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2567020,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh39",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh39",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:56Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.38.0.245",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "6e:7d:dd:2b:e0:b2",
        "interface-index": 11,
        "interface-name": "lxcae41fdbd1d66",
        "mac": "8a:5a:79:ac:f2:f6"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2567020,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2567020,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 936

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 936

```
Timestamp              Status   State                   Message
2024-10-25T10:21:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:56Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:57Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:13:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:55Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:55Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2567020

```
ID        LABELS
2567020   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh39
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1350

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3085476   31069     0        
Allow    Ingress     1          ANY          NONE         disabled    3279891   33354     0        
Allow    Egress      0          ANY          NONE         disabled    4716295   44657     0        

```


#### BPF CT List 1350

```
Invalid argument: unknown type 1350
```


#### Endpoint Get 1350

```
[
  {
    "id": 1350,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1350-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "65f7bb61-cca3-4261-96e2-ed1a8175c1de"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1350",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:12.038Z",
            "success-count": 2
          },
          "uuid": "a8114250-fbcc-4722-8440-459820095729"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-6b8445b784-q9cbn",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:12.037Z",
            "success-count": 1
          },
          "uuid": "faa6615a-8dd3-4439-81ae-402fbb2bb78a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1350",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:12.072Z",
            "success-count": 1
          },
          "uuid": "e1c150f2-a5a2-4d7c-bda2-1a7c59f365a4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1350)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:42.093Z",
            "success-count": 47
          },
          "uuid": "d1ecdf20-69b3-416a-98a4-5c6a0e1ecc29"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "d7f6081297961f8f0f10d21001678dbce5f917d893c12892e54782468cfc1110:eth0",
        "container-id": "d7f6081297961f8f0f10d21001678dbce5f917d893c12892e54782468cfc1110",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-6b8445b784-q9cbn",
        "pod-name": "kube-system/clustermesh-apiserver-6b8445b784-q9cbn"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2616627,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh39",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6b8445b784"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh39",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:56Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.38.0.142",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "c2:4c:17:a7:c7:2a",
        "interface-index": 15,
        "interface-name": "lxc92691c1b7bf9",
        "mac": "52:be:c5:10:16:5d"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2616627,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2616627,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1350

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1350

```
Timestamp              Status   State                   Message
2024-10-25T10:21:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:56Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:12Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:12Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:12Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2616627

```
ID        LABELS
2616627   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh39
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1989

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83816   962       0        
Allow    Egress      0          ANY          NONE         disabled    14522   152       0        

```


#### BPF CT List 1989

```
Invalid argument: unknown type 1989
```


#### Endpoint Get 1989

```
[
  {
    "id": 1989,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1989-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "8337040b-0c48-45b6-a38d-90a807376e36"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1989",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:55.097Z",
            "success-count": 3
          },
          "uuid": "0cefde1f-b1e3-4b55-bd5c-0cdbf84e3a7e"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-r5trn",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:13:55.096Z",
            "success-count": 1
          },
          "uuid": "d546ec99-bc39-4244-8479-e92a439672bb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1989",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:13:57.360Z",
            "success-count": 1
          },
          "uuid": "c79d0e2e-0b31-4da1-8936-63b1693b541b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1989)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:45.185Z",
            "success-count": 91
          },
          "uuid": "08184d52-ca5c-44dd-85f3-5183398035ef"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "f35b61cc6b3b4c5de649497358e404a93f5226572f17ce5820b883c19853bd56:eth0",
        "container-id": "f35b61cc6b3b4c5de649497358e404a93f5226572f17ce5820b883c19853bd56",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-r5trn",
        "pod-name": "kube-system/coredns-cc6ccd49c-r5trn"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2567020,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh39",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh39",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:56Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.38.0.100",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "2e:8d:56:3b:5f:79",
        "interface-index": 9,
        "interface-name": "lxca2def997ec15",
        "mac": "3e:29:a6:8c:47:ba"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2567020,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2567020,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1989

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1989

```
Timestamp              Status   State                   Message
2024-10-25T10:21:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:56Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:57Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:56Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:55Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:13:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:55Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:55Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2567020

```
ID        LABELS
2567020   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh39
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 2297

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    393340   5020      0        
Allow    Ingress     1          ANY          NONE         disabled    11702    135       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 2297

```
Invalid argument: unknown type 2297
```


#### Endpoint Get 2297

```
[
  {
    "id": 2297,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2297-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "3ed7c1da-deea-4898-ab4c-ea615cd062c1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2297",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:53.917Z",
            "success-count": 3
          },
          "uuid": "deadf3b9-00a4-44cf-9926-dc2aed35d08a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2297",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:13:57.354Z",
            "success-count": 1
          },
          "uuid": "965ce5ac-fcf1-4436-a99b-fd6e4f233747"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:56Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.38.0.236",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "26:b5:86:25:06:27",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "3e:8d:64:5b:76:b5"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2297

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2297

```
Timestamp              Status   State                   Message
2024-10-25T10:21:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:56Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:13:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:57Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:13:57Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:13:55Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:13:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:13:53Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:53Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:52Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Service list

```
ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.163.142:443 (active)    
                                        2 => 172.31.195.185:443 (active)    
2    10.100.25.154:443   ClusterIP      1 => 172.31.172.183:4244 (active)   
3    10.100.0.10:9153    ClusterIP      1 => 10.38.0.100:9153 (active)      
                                        2 => 10.38.0.245:9153 (active)      
4    10.100.0.10:53      ClusterIP      1 => 10.38.0.100:53 (active)        
                                        2 => 10.38.0.245:53 (active)        
5    10.100.58.24:2379   ClusterIP      1 => 10.38.0.142:2379 (active)      
```

#### Policy get

```
:
 []
Revision: 1

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x400212a630)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001d98780,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001d98780,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4000ae4d10)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4000ae4dc0)(frontends:[10.100.25.154]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4000ae4f20)(frontends:[10.100.0.10]/ports=[metrics dns dns-tcp]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x400321d970)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x400321da20)(frontends:[10.100.58.24]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4001750008)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-xgx26": (*k8s.Endpoints)(0x40034e4410)(172.31.172.183:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4001750010)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-rqw6w": (*k8s.Endpoints)(0x4002d5d5f0)(10.38.0.100:53/TCP[eu-west-3a],10.38.0.100:53/UDP[eu-west-3a],10.38.0.100:9153/TCP[eu-west-3a],10.38.0.245:53/TCP[eu-west-3a],10.38.0.245:53/UDP[eu-west-3a],10.38.0.245:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40015a3af8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-r8jw9": (*k8s.Endpoints)(0x40034e5c70)(10.38.0.142:2379/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4001750000)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x400010dad0)(172.31.163.142:443/TCP,172.31.195.185:443/TCP)
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001cd8000)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40021d74a0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x40093b0618
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4001d7ac00,
  gcExited: (chan struct {}) 0x4001d7ac60,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x400214a780)({
     ObserverVec: (*prometheus.HistogramVec)(0x400119e9c8)({
      MetricVec: (*prometheus.MetricVec)(0x4001cd0240)({
       metricMap: (*prometheus.metricMap)(0x4001cd0270)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001cd6000)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x400214a800)({
     ObserverVec: (*prometheus.HistogramVec)(0x400119e9d0)({
      MetricVec: (*prometheus.MetricVec)(0x4001cd02d0)({
       metricMap: (*prometheus.metricMap)(0x4001cd0300)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001cd6060)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x400214a880)({
     GaugeVec: (*prometheus.GaugeVec)(0x400119e9d8)({
      MetricVec: (*prometheus.MetricVec)(0x4001cd0360)({
       metricMap: (*prometheus.metricMap)(0x4001cd0390)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001cd60c0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x400214a900)({
     GaugeVec: (*prometheus.GaugeVec)(0x400119e9e0)({
      MetricVec: (*prometheus.MetricVec)(0x4001cd03f0)({
       metricMap: (*prometheus.metricMap)(0x4001cd0420)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001cd6120)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x400214a980)({
     GaugeVec: (*prometheus.GaugeVec)(0x400119e9e8)({
      MetricVec: (*prometheus.MetricVec)(0x4001cd0480)({
       metricMap: (*prometheus.metricMap)(0x4001cd04b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001cd6180)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x400214aa00)({
     GaugeVec: (*prometheus.GaugeVec)(0x400119e9f0)({
      MetricVec: (*prometheus.MetricVec)(0x4001cd0510)({
       metricMap: (*prometheus.metricMap)(0x4001cd0540)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001cd61e0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x400214aa80)({
     GaugeVec: (*prometheus.GaugeVec)(0x400119e9f8)({
      MetricVec: (*prometheus.MetricVec)(0x4001cd05a0)({
       metricMap: (*prometheus.metricMap)(0x4001cd05d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001cd6240)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x400214ab00)({
     GaugeVec: (*prometheus.GaugeVec)(0x400119ea00)({
      MetricVec: (*prometheus.MetricVec)(0x4001cd0630)({
       metricMap: (*prometheus.metricMap)(0x4001cd0660)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001cd62a0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x400214ab80)({
     ObserverVec: (*prometheus.HistogramVec)(0x400119ea08)({
      MetricVec: (*prometheus.MetricVec)(0x4001cd06c0)({
       metricMap: (*prometheus.metricMap)(0x4001cd06f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001cd6300)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001cd8000)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001cd9180)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001da8648)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 394ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.38.0.205": (string) (len=6) "router",
  (string) (len=11) "10.38.0.236": (string) (len=6) "health",
  (string) (len=11) "10.38.0.100": (string) (len=35) "kube-system/coredns-cc6ccd49c-r5trn",
  (string) (len=11) "10.38.0.245": (string) (len=35) "kube-system/coredns-cc6ccd49c-p82x8",
  (string) (len=11) "10.38.0.142": (string) (len=50) "kube-system/clustermesh-apiserver-6b8445b784-q9cbn"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.172.183": (string) (len=7) "node-ip"
}

```


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```

