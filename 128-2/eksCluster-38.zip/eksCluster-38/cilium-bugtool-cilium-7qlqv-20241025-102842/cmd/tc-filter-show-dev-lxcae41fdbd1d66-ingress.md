filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcae41fdbd1d66 direct-action not_in_hw id 508 tag abe2271e449265aa jited 
