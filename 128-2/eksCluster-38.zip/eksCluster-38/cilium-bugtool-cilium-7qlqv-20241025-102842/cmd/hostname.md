ip-172-31-172-183.eu-west-3.compute.internal
