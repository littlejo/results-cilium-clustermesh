{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.654Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.172.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.654Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:57.354Z",
  "value": "id=2297  sec_id=4     flags=0x0000 ifindex=7   mac=3E:8D:64:5B:76:B5 nodemac=26:B5:86:25:06:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:57.359Z",
  "value": "id=1989  sec_id=2567020 flags=0x0000 ifindex=9   mac=3E:29:A6:8C:47:BA nodemac=2E:8D:56:3B:5F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:57.402Z",
  "value": "id=936   sec_id=2567020 flags=0x0000 ifindex=11  mac=8A:5A:79:AC:F2:F6 nodemac=6E:7D:DD:2B:E0:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:57.403Z",
  "value": "id=1989  sec_id=2567020 flags=0x0000 ifindex=9   mac=3E:29:A6:8C:47:BA nodemac=2E:8D:56:3B:5F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:57.421Z",
  "value": "id=2297  sec_id=4     flags=0x0000 ifindex=7   mac=3E:8D:64:5B:76:B5 nodemac=26:B5:86:25:06:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:23.651Z",
  "value": "id=1989  sec_id=2567020 flags=0x0000 ifindex=9   mac=3E:29:A6:8C:47:BA nodemac=2E:8D:56:3B:5F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:23.651Z",
  "value": "id=936   sec_id=2567020 flags=0x0000 ifindex=11  mac=8A:5A:79:AC:F2:F6 nodemac=6E:7D:DD:2B:E0:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:23.652Z",
  "value": "id=2297  sec_id=4     flags=0x0000 ifindex=7   mac=3E:8D:64:5B:76:B5 nodemac=26:B5:86:25:06:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:23.683Z",
  "value": "id=1367  sec_id=2616627 flags=0x0000 ifindex=13  mac=A6:6C:95:4D:7E:22 nodemac=AE:76:EF:57:B8:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:24.651Z",
  "value": "id=2297  sec_id=4     flags=0x0000 ifindex=7   mac=3E:8D:64:5B:76:B5 nodemac=26:B5:86:25:06:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:24.652Z",
  "value": "id=1367  sec_id=2616627 flags=0x0000 ifindex=13  mac=A6:6C:95:4D:7E:22 nodemac=AE:76:EF:57:B8:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:24.652Z",
  "value": "id=1989  sec_id=2567020 flags=0x0000 ifindex=9   mac=3E:29:A6:8C:47:BA nodemac=2E:8D:56:3B:5F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:24.652Z",
  "value": "id=936   sec_id=2567020 flags=0x0000 ifindex=11  mac=8A:5A:79:AC:F2:F6 nodemac=6E:7D:DD:2B:E0:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:12.071Z",
  "value": "id=1350  sec_id=2616627 flags=0x0000 ifindex=15  mac=52:BE:C5:10:16:5D nodemac=C2:4C:17:A7:C7:2A"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.38.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:17.344Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:54.391Z",
  "value": "id=1350  sec_id=2616627 flags=0x0000 ifindex=15  mac=52:BE:C5:10:16:5D nodemac=C2:4C:17:A7:C7:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:54.392Z",
  "value": "id=2297  sec_id=4     flags=0x0000 ifindex=7   mac=3E:8D:64:5B:76:B5 nodemac=26:B5:86:25:06:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:54.392Z",
  "value": "id=1989  sec_id=2567020 flags=0x0000 ifindex=9   mac=3E:29:A6:8C:47:BA nodemac=2E:8D:56:3B:5F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:54.392Z",
  "value": "id=936   sec_id=2567020 flags=0x0000 ifindex=11  mac=8A:5A:79:AC:F2:F6 nodemac=6E:7D:DD:2B:E0:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:55.380Z",
  "value": "id=1350  sec_id=2616627 flags=0x0000 ifindex=15  mac=52:BE:C5:10:16:5D nodemac=C2:4C:17:A7:C7:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:55.382Z",
  "value": "id=2297  sec_id=4     flags=0x0000 ifindex=7   mac=3E:8D:64:5B:76:B5 nodemac=26:B5:86:25:06:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:55.382Z",
  "value": "id=1989  sec_id=2567020 flags=0x0000 ifindex=9   mac=3E:29:A6:8C:47:BA nodemac=2E:8D:56:3B:5F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:55.382Z",
  "value": "id=936   sec_id=2567020 flags=0x0000 ifindex=11  mac=8A:5A:79:AC:F2:F6 nodemac=6E:7D:DD:2B:E0:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:56.381Z",
  "value": "id=1350  sec_id=2616627 flags=0x0000 ifindex=15  mac=52:BE:C5:10:16:5D nodemac=C2:4C:17:A7:C7:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:56.382Z",
  "value": "id=2297  sec_id=4     flags=0x0000 ifindex=7   mac=3E:8D:64:5B:76:B5 nodemac=26:B5:86:25:06:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:56.382Z",
  "value": "id=1989  sec_id=2567020 flags=0x0000 ifindex=9   mac=3E:29:A6:8C:47:BA nodemac=2E:8D:56:3B:5F:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.38.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:56.382Z",
  "value": "id=936   sec_id=2567020 flags=0x0000 ifindex=11  mac=8A:5A:79:AC:F2:F6 nodemac=6E:7D:DD:2B:E0:B2"
}

