32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:06+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:07+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:07+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:07+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:12+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
61: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
64: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
72: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
75: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
80: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
83: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
107: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
110: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
451: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 112
452: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 113
453: sched_cls  name tail_handle_ipv4  tag 04563b1ce780dcd2  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 69,68,75,70,91
	btf_id 114
454: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 70,91
	btf_id 115
455: sched_cls  name __send_drop_notify  tag 982fb52024ff12f0  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 117
456: sched_cls  name tail_handle_ipv4_from_host  tag 689251499d367be2  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,93
	btf_id 118
457: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,93
	btf_id 119
460: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 70,69,93
	btf_id 122
461: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 123
462: sched_cls  name __send_drop_notify  tag 982fb52024ff12f0  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 125
463: sched_cls  name tail_handle_ipv4_from_host  tag 689251499d367be2  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,96
	btf_id 126
464: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,96
	btf_id 127
468: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 131
470: sched_cls  name __send_drop_notify  tag 982fb52024ff12f0  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 134
471: sched_cls  name tail_handle_ipv4_from_host  tag 689251499d367be2  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,97
	btf_id 135
472: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,97
	btf_id 136
474: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 70,97,69
	btf_id 138
480: sched_cls  name handle_policy  tag 268eca5d0ede172c  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,103,76,77,102,35,74,99,33,78,69,34,31,32
	btf_id 144
481: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,103
	btf_id 148
482: sched_cls  name tail_handle_arp  tag e8542f1ddc0fbf75  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,103
	btf_id 149
485: sched_cls  name tail_handle_ipv4_cont  tag 383632727405f34c  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,102,35,99,76,77,33,70,68,71,103,34,31,32,75
	btf_id 150
487: sched_cls  name tail_ipv4_ct_ingress  tag a05e9d4f05ab159f  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,103,76,77,102,78
	btf_id 153
489: sched_cls  name tail_handle_ipv4  tag 41a5e49b1d0d226a  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,103
	btf_id 155
490: sched_cls  name cil_from_container  tag bec9edd7c73fd338  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 103,70
	btf_id 157
491: sched_cls  name __send_drop_notify  tag 83304f468899cf68  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 158
492: sched_cls  name tail_ipv4_ct_egress  tag 3eb46486e2b3942f  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,103,76,77,102,78
	btf_id 159
497: sched_cls  name __send_drop_notify  tag fd5cae7b7fe3e242  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 165
499: sched_cls  name tail_ipv4_to_endpoint  tag a254d92ae3cd8bb6  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,102,35,76,77,74,99,33,103,34,31,32
	btf_id 160
500: sched_cls  name __send_drop_notify  tag a8646c606b737273  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 169
502: sched_cls  name tail_handle_ipv4_cont  tag 4e92efa53bb3100f  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 69,108,35,92,76,77,33,70,68,71,107,34,31,32,75
	btf_id 171
503: sched_cls  name tail_handle_ipv4  tag 906c69efcf9f4371  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,105
	btf_id 167
504: sched_cls  name tail_ipv4_ct_ingress  tag 1ce5dd44b29175e4  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 70,107,76,77,108,78
	btf_id 172
505: sched_cls  name cil_from_container  tag f6c3453a76334e67  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 107,70
	btf_id 173
506: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,107
	btf_id 174
507: sched_cls  name tail_ipv4_ct_egress  tag 3eb46486e2b3942f  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,105,76,77,106,78
	btf_id 175
508: sched_cls  name cil_from_container  tag abe2271e449265aa  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 105,70
	btf_id 176
509: sched_cls  name tail_handle_ipv4_cont  tag b0204e7bbd8e7651  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,106,35,104,76,77,33,70,68,71,105,34,31,32,75
	btf_id 177
510: sched_cls  name tail_ipv4_ct_ingress  tag 1cce8cbcbf5279ce  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,105,76,77,106,78
	btf_id 179
511: sched_cls  name tail_ipv4_to_endpoint  tag b0548a8cbdfe1ae2  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 69,70,108,35,76,77,74,92,33,107,34,31,32
	btf_id 178
512: sched_cls  name handle_policy  tag a291e7f6b59feda6  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,105,76,77,106,35,74,104,33,78,69,34,31,32
	btf_id 180
513: sched_cls  name tail_handle_ipv4  tag 39b4cc7926859171  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,107
	btf_id 181
514: sched_cls  name tail_ipv4_to_endpoint  tag b5715a020a39c2f5  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,106,35,76,77,74,104,33,105,34,31,32
	btf_id 182
515: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,105
	btf_id 183
516: sched_cls  name tail_handle_arp  tag 9675d61acefa608e  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,105
	btf_id 184
517: sched_cls  name handle_policy  tag aaf4466b8379ba3c  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 70,107,76,77,108,35,74,92,33,78,69,34,31,32
	btf_id 185
518: sched_cls  name tail_handle_arp  tag 99efab24047b8e73  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,107
	btf_id 186
519: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 70,107,76,77,108,78
	btf_id 187
520: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
523: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
524: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
527: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
528: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
531: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
532: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
535: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
575: sched_cls  name __send_drop_notify  tag 7f854480e2d93bce  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 203
576: sched_cls  name tail_handle_ipv4_cont  tag b2baf0e0d2c67f8e  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,125,35,123,76,77,33,70,68,71,124,34,31,32,75
	btf_id 204
577: sched_cls  name handle_policy  tag b34ab3aa3b3ca144  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,124,76,77,125,35,74,123,33,78,69,34,31,32
	btf_id 205
578: sched_cls  name tail_ipv4_ct_egress  tag b9619229ce1be55e  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,124,76,77,125,78
	btf_id 206
579: sched_cls  name tail_ipv4_ct_ingress  tag 4a2555c68a0a2645  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,124,76,77,125,78
	btf_id 207
580: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,124
	btf_id 208
581: sched_cls  name cil_from_container  tag 2904868ae960a35d  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 124,70
	btf_id 209
582: sched_cls  name tail_handle_ipv4  tag f870568c371075ff  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,124
	btf_id 210
583: sched_cls  name tail_handle_arp  tag 3515273328e8e3b0  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,124
	btf_id 211
585: sched_cls  name tail_ipv4_to_endpoint  tag 241bf30f7561a45e  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,125,35,76,77,74,123,33,124,34,31,32
	btf_id 213
586: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
589: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
602: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
605: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
606: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
609: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
610: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
613: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
