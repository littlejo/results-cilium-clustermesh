top - 10:28:43 up 15 min,  0 users,  load average: 0.10, 0.08, 0.08
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 10.3 us, 20.7 sy,  0.0 ni, 69.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1182.6 free,    898.1 used,   1755.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2769.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    656 root      20   0 1240432  16600  11420 S   6.7   0.4   0:00.02 cilium-+
      1 root      20   0 1472496 276484  76480 S   0.0   7.0   0:22.11 cilium-+
    389 root      20   0 1228848   5908   3056 S   0.0   0.2   0:00.25 cilium-+
    637 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    647 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    655 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    657 root      20   0 1228744   3604   2912 S   0.0   0.1   0:00.00 gops
    711 root      20   0    6576   2432   2104 R   0.0   0.1   0:00.00 top
    729 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
