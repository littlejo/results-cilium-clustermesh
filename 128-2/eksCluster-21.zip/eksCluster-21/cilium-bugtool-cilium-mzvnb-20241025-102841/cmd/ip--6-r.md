fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxc4179ff6b6df5 proto kernel metric 256 pref medium
fe80::/64 dev lxcf207e4125f87 proto kernel metric 256 pref medium
fe80::/64 dev lxca569c112d983 proto kernel metric 256 pref medium
