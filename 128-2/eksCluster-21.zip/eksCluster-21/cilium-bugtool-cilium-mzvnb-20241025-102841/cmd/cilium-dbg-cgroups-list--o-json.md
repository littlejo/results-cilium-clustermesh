[
  {
    "containers": [
      {
        "cgroup-id": 6784,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod566467c2_3dad_46fe_8449_fcda771f73c4.slice/cri-containerd-0323ffb82244b0bb9abdc7f8ee12945cfa0566a7a52300317ea913a5b8a614fa.scope"
      }
    ],
    "ips": [
      "10.21.0.176"
    ],
    "name": "coredns-cc6ccd49c-82h5c",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6868,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod22f0be9d_c473_4b11_a12a_33952f301848.slice/cri-containerd-7c7eddecc5c7433096f27a718e837a30a7d0af9e5eace5af717b97bff0a4af59.scope"
      }
    ],
    "ips": [
      "10.21.0.49"
    ],
    "name": "coredns-cc6ccd49c-8gkmj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8296,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd03ee480_d692_44f8_ab75_c2b6e3edfaa3.slice/cri-containerd-b5e032190a30d5801f495f59d65e6f967a3c159b8d4611f575180070a3ad5f83.scope"
      },
      {
        "cgroup-id": 8212,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd03ee480_d692_44f8_ab75_c2b6e3edfaa3.slice/cri-containerd-3c11855cf01ccc25f44ee2d8effb27a761db7fae778cc541c97dc5d26b3b042f.scope"
      },
      {
        "cgroup-id": 8380,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd03ee480_d692_44f8_ab75_c2b6e3edfaa3.slice/cri-containerd-feff667c6a6eaf06e829cc823b18900116ead6dd95e3ce5deba390223f3919ca.scope"
      }
    ],
    "ips": [
      "10.21.0.122"
    ],
    "name": "clustermesh-apiserver-567c89b4d6-sdpf7",
    "namespace": "kube-system"
  }
]

