USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         657  0.0  0.0 1228744 3604 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         656  0.0  0.4 1240432 16348 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         700  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         701  0.0  0.0   3852  1268 ?        R    10:28   0:00  \_ bash -c hostname
root         655  0.0  0.1 1228744 4040 ?        Ssl  10:28   0:00 /bin/gops stats 1
root         647  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root         637  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops stack 1
root           1  2.4  7.0 1472496 276484 ?      Ssl  10:13   0:22 cilium-agent --config-dir=/tmp/cilium/config-map
root         389  0.0  0.1 1228848 5908 ?        Sl   10:13   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
