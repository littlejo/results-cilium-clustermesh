 10:28:42 up 15 min,  0 users,  load average: 0.10, 0.08, 0.08
