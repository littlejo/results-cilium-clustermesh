CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8aa5403a_ac12_4e94_ac09_46885ae342fd.slice/cri-containerd-1b05737175a647141e4f530174f77c9fa88d3d19044fe152c133eea23f2ab1e9.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8aa5403a_ac12_4e94_ac09_46885ae342fd.slice/cri-containerd-4f05c189596cda64741b95a6a2c65c0290cf62cae4d923204f871580f385c05a.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod566467c2_3dad_46fe_8449_fcda771f73c4.slice/cri-containerd-0323ffb82244b0bb9abdc7f8ee12945cfa0566a7a52300317ea913a5b8a614fa.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod566467c2_3dad_46fe_8449_fcda771f73c4.slice/cri-containerd-bf9fe694d3ca2558d463cc22efca1cd2da6adce0587c323316f5e6cc92867392.scope
    500      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4979d583_9491_4ba1_b10b_7b1280e1b0e5.slice/cri-containerd-7136c34d3ec35b478ab104cadcff5ab63b062dd577cab65514a3376ae2fdb414.scope
    71       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4979d583_9491_4ba1_b10b_7b1280e1b0e5.slice/cri-containerd-d48558eed45ea9fcfa44773ae5095000e877a5227ea4e77a44dcc30c9fe42625.scope
    61       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod22f0be9d_c473_4b11_a12a_33952f301848.slice/cri-containerd-7c7eddecc5c7433096f27a718e837a30a7d0af9e5eace5af717b97bff0a4af59.scope
    542      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod22f0be9d_c473_4b11_a12a_33952f301848.slice/cri-containerd-839888f759747559e4ec156463dcbdb927d6f093a8c9ff24eb9b67e3ca1ab38e.scope
    495      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poded91d023_6bea_4644_a825_01f0a0238eee.slice/cri-containerd-4fed72767c9ff2ba7455ed1d0b0876d14ea79821b631d8d7dfbbdce3b2db9a3b.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poded91d023_6bea_4644_a825_01f0a0238eee.slice/cri-containerd-e845c812385347755a61908fc874b4376f9552f2ec1e4d0c356b6f9f71ceba5d.scope
    64       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ef56b7e_c136_48d2_978d_0478150b332b.slice/cri-containerd-c12cce0f00640b57ccae5268ab7a14a520ff0813925e8e30259128d682ec7791.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ef56b7e_c136_48d2_978d_0478150b332b.slice/cri-containerd-b128af84f9708f18e702667d84afa4f27ae81b07a4d78f65f666247a5bbea2a7.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd03ee480_d692_44f8_ab75_c2b6e3edfaa3.slice/cri-containerd-8d32960648a289d41c8e30da080c899167ba82c1e84124ccd6e07cf99e8cd55e.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd03ee480_d692_44f8_ab75_c2b6e3edfaa3.slice/cri-containerd-3c11855cf01ccc25f44ee2d8effb27a761db7fae778cc541c97dc5d26b3b042f.scope
    612      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd03ee480_d692_44f8_ab75_c2b6e3edfaa3.slice/cri-containerd-b5e032190a30d5801f495f59d65e6f967a3c159b8d4611f575180070a3ad5f83.scope
    616      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd03ee480_d692_44f8_ab75_c2b6e3edfaa3.slice/cri-containerd-feff667c6a6eaf06e829cc823b18900116ead6dd95e3ce5deba390223f3919ca.scope
    620      cgroup_device   multi                                          
