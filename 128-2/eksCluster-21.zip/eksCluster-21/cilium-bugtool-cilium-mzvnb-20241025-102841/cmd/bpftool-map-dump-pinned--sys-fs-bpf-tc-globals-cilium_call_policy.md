key: 4b 00 00 00  value: 50 02 00 00
key: 79 02 00 00  value: f1 01 00 00
key: bb 04 00 00  value: e1 01 00 00
key: 16 07 00 00  value: fc 01 00 00
Found 4 elements
