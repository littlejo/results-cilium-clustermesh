ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.205.83:443 (active)     
                                          2 => 172.31.163.99:443 (active)     
2    10.100.96.189:443     ClusterIP      1 => 172.31.247.164:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.21.0.49:9153 (active)       
                                          2 => 10.21.0.176:9153 (active)      
4    10.100.0.10:53        ClusterIP      1 => 10.21.0.49:53 (active)         
                                          2 => 10.21.0.176:53 (active)        
5    10.100.226.114:2379   ClusterIP      1 => 10.21.0.122:2379 (active)      
