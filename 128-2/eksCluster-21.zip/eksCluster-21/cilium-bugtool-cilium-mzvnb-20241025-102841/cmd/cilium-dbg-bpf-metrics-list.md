REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     229848    101797256   1132   bpf_host.c
Interface                 INGRESS     9965      782306      677    bpf_overlay.c
Success                   EGRESS      10235     801248      53     encap.h
Success                   EGRESS      5201      400682      1694   bpf_host.c
Success                   EGRESS      7636      1207074     86     l3.h
Success                   EGRESS      98161     12883903    1308   bpf_lxc.c
Success                   INGRESS     109492    13504680    86     l3.h
Success                   INGRESS     122541    15137284    235    trace.h
Unsupported L3 protocol   EGRESS      36        2672        1492   bpf_lxc.c
