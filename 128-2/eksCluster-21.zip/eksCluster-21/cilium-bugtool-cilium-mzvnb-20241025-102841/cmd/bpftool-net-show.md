xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 534
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 522
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 514
cilium_host(4) clsact/egress cil_from_host-cilium_host id 520
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 450
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 447
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 473
lxc4179ff6b6df5(9) clsact/ingress cil_from_container-lxc4179ff6b6df5 id 488
lxcf207e4125f87(11) clsact/ingress cil_from_container-lxcf207e4125f87 id 507
lxca569c112d983(15) clsact/ingress cil_from_container-lxca569c112d983 id 586

flow_dissector:

netfilter:

