IP ADDRESS         LOCAL ENDPOINT INFO
10.21.0.211:0      (localhost)                                                                                        
10.21.0.122:0      id=75    sec_id=1467853 flags=0x0000 ifindex=15  mac=CE:2E:3B:F0:00:C3 nodemac=9A:DA:2B:06:EB:D5   
10.21.0.176:0      id=633   sec_id=1449296 flags=0x0000 ifindex=9   mac=8E:17:16:0B:47:DA nodemac=8E:09:40:98:09:08   
172.31.247.164:0   (localhost)                                                                                        
10.21.0.180:0      id=1211  sec_id=4     flags=0x0000 ifindex=7   mac=32:18:2F:E1:AE:B9 nodemac=96:25:C4:E3:28:A6     
10.21.0.49:0       id=1814  sec_id=1449296 flags=0x0000 ifindex=11  mac=2A:29:77:EA:81:16 nodemac=C2:6D:08:C2:A4:57   
