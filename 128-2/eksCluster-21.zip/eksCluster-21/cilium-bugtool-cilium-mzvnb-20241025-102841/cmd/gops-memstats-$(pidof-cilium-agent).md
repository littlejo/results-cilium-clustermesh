alloc: 109.95MB (115287640 bytes)
total-alloc: 1.40GB (1507490592 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 49013665
frees: 47968050
heap-alloc: 109.95MB (115287640 bytes)
heap-sys: 165.17MB (173195264 bytes)
heap-idle: 31.59MB (33120256 bytes)
heap-in-use: 133.59MB (140075008 bytes)
heap-released: 720.00KB (737280 bytes)
heap-objects: 1045615
stack-in-use: 34.78MB (36470784 bytes)
stack-sys: 34.78MB (36470784 bytes)
stack-mspan-inuse: 2.06MB (2164160 bytes)
stack-mspan-sys: 2.51MB (2627520 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 862.58KB (883281 bytes)
gc-sys: 5.17MB (5417144 bytes)
next-gc: when heap-alloc >= 146.40MB (153516568 bytes)
last-gc: 2024-10-25 10:28:46.36751467 +0000 UTC
gc-pause-total: 12.184398ms
gc-pause: 140668
gc-pause-end: 1729852126367514670
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00032310896308832525
enable-gc: true
debug-gc: false
