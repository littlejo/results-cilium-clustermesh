{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:30.973Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.247.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:30.973Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:35.302Z",
  "value": "id=633   sec_id=1449296 flags=0x0000 ifindex=9   mac=8E:17:16:0B:47:DA nodemac=8E:09:40:98:09:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:35.304Z",
  "value": "id=1814  sec_id=1449296 flags=0x0000 ifindex=11  mac=2A:29:77:EA:81:16 nodemac=C2:6D:08:C2:A4:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:35.391Z",
  "value": "id=1211  sec_id=4     flags=0x0000 ifindex=7   mac=32:18:2F:E1:AE:B9 nodemac=96:25:C4:E3:28:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:35.449Z",
  "value": "id=633   sec_id=1449296 flags=0x0000 ifindex=9   mac=8E:17:16:0B:47:DA nodemac=8E:09:40:98:09:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:35.524Z",
  "value": "id=1814  sec_id=1449296 flags=0x0000 ifindex=11  mac=2A:29:77:EA:81:16 nodemac=C2:6D:08:C2:A4:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:59.905Z",
  "value": "id=1814  sec_id=1449296 flags=0x0000 ifindex=11  mac=2A:29:77:EA:81:16 nodemac=C2:6D:08:C2:A4:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:59.906Z",
  "value": "id=1211  sec_id=4     flags=0x0000 ifindex=7   mac=32:18:2F:E1:AE:B9 nodemac=96:25:C4:E3:28:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:59.907Z",
  "value": "id=633   sec_id=1449296 flags=0x0000 ifindex=9   mac=8E:17:16:0B:47:DA nodemac=8E:09:40:98:09:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:59.935Z",
  "value": "id=904   sec_id=1467853 flags=0x0000 ifindex=13  mac=C6:5B:6F:83:BC:29 nodemac=46:7B:88:20:A1:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:00.905Z",
  "value": "id=1211  sec_id=4     flags=0x0000 ifindex=7   mac=32:18:2F:E1:AE:B9 nodemac=96:25:C4:E3:28:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:00.905Z",
  "value": "id=904   sec_id=1467853 flags=0x0000 ifindex=13  mac=C6:5B:6F:83:BC:29 nodemac=46:7B:88:20:A1:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:00.905Z",
  "value": "id=633   sec_id=1449296 flags=0x0000 ifindex=9   mac=8E:17:16:0B:47:DA nodemac=8E:09:40:98:09:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:00.906Z",
  "value": "id=1814  sec_id=1449296 flags=0x0000 ifindex=11  mac=2A:29:77:EA:81:16 nodemac=C2:6D:08:C2:A4:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:28.404Z",
  "value": "id=75    sec_id=1467853 flags=0x0000 ifindex=15  mac=CE:2E:3B:F0:00:C3 nodemac=9A:DA:2B:06:EB:D5"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.21.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:40.468Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:54.798Z",
  "value": "id=75    sec_id=1467853 flags=0x0000 ifindex=15  mac=CE:2E:3B:F0:00:C3 nodemac=9A:DA:2B:06:EB:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:54.799Z",
  "value": "id=633   sec_id=1449296 flags=0x0000 ifindex=9   mac=8E:17:16:0B:47:DA nodemac=8E:09:40:98:09:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:54.799Z",
  "value": "id=1814  sec_id=1449296 flags=0x0000 ifindex=11  mac=2A:29:77:EA:81:16 nodemac=C2:6D:08:C2:A4:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:54.799Z",
  "value": "id=1211  sec_id=4     flags=0x0000 ifindex=7   mac=32:18:2F:E1:AE:B9 nodemac=96:25:C4:E3:28:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:55.786Z",
  "value": "id=1814  sec_id=1449296 flags=0x0000 ifindex=11  mac=2A:29:77:EA:81:16 nodemac=C2:6D:08:C2:A4:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:55.786Z",
  "value": "id=633   sec_id=1449296 flags=0x0000 ifindex=9   mac=8E:17:16:0B:47:DA nodemac=8E:09:40:98:09:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:55.786Z",
  "value": "id=75    sec_id=1467853 flags=0x0000 ifindex=15  mac=CE:2E:3B:F0:00:C3 nodemac=9A:DA:2B:06:EB:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:55.787Z",
  "value": "id=1211  sec_id=4     flags=0x0000 ifindex=7   mac=32:18:2F:E1:AE:B9 nodemac=96:25:C4:E3:28:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:56.786Z",
  "value": "id=1814  sec_id=1449296 flags=0x0000 ifindex=11  mac=2A:29:77:EA:81:16 nodemac=C2:6D:08:C2:A4:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:56.787Z",
  "value": "id=1211  sec_id=4     flags=0x0000 ifindex=7   mac=32:18:2F:E1:AE:B9 nodemac=96:25:C4:E3:28:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:56.787Z",
  "value": "id=75    sec_id=1467853 flags=0x0000 ifindex=15  mac=CE:2E:3B:F0:00:C3 nodemac=9A:DA:2B:06:EB:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:56.787Z",
  "value": "id=633   sec_id=1449296 flags=0x0000 ifindex=9   mac=8E:17:16:0B:47:DA nodemac=8E:09:40:98:09:08"
}

