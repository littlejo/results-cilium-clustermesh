Endpoint ID: 75
Path: /sys/fs/bpf/tc/globals/cilium_policy_00075

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3838640   36585     0        
Allow    Ingress     1          ANY          NONE         disabled    3406025   34709     0        
Allow    Egress      0          ANY          NONE         disabled    5178490   47633     0        


Endpoint ID: 481
Path: /sys/fs/bpf/tc/globals/cilium_policy_00481

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 633
Path: /sys/fs/bpf/tc/globals/cilium_policy_00633

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    216364   1947      0        
Allow    Ingress     1          ANY          NONE         disabled    89479    1030      0        
Allow    Egress      0          ANY          NONE         disabled    60628    582       0        


Endpoint ID: 1211
Path: /sys/fs/bpf/tc/globals/cilium_policy_01211

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    427646   5439      0        
Allow    Ingress     1          ANY          NONE         disabled    13300    156       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1814
Path: /sys/fs/bpf/tc/globals/cilium_policy_01814

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    207350   1871      0        
Allow    Ingress     1          ANY          NONE         disabled    89230    1029      0        
Allow    Egress      0          ANY          NONE         disabled    62938    605       0        


