filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc4179ff6b6df5 direct-action not_in_hw id 488 tag 4c16c7577b85bf78 jited 
