{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:45.637Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.207.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:45.637Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:50.271Z",
  "value": "id=846   sec_id=4     flags=0x0000 ifindex=10  mac=52:FC:32:97:4A:BA nodemac=E2:86:D5:3A:DC:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:50.286Z",
  "value": "id=3392  sec_id=6323134 flags=0x0000 ifindex=12  mac=12:FE:4D:26:D7:A3 nodemac=9E:0D:3D:49:67:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:50.287Z",
  "value": "id=3392  sec_id=6323134 flags=0x0000 ifindex=12  mac=12:FE:4D:26:D7:A3 nodemac=9E:0D:3D:49:67:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:50.311Z",
  "value": "id=846   sec_id=4     flags=0x0000 ifindex=10  mac=52:FC:32:97:4A:BA nodemac=E2:86:D5:3A:DC:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:55.931Z",
  "value": "id=2431  sec_id=6323134 flags=0x0000 ifindex=14  mac=0A:EB:0E:47:1A:ED nodemac=3E:FB:2B:A3:5E:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:40.440Z",
  "value": "id=846   sec_id=4     flags=0x0000 ifindex=10  mac=52:FC:32:97:4A:BA nodemac=E2:86:D5:3A:DC:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:40.440Z",
  "value": "id=3392  sec_id=6323134 flags=0x0000 ifindex=12  mac=12:FE:4D:26:D7:A3 nodemac=9E:0D:3D:49:67:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:40.440Z",
  "value": "id=2431  sec_id=6323134 flags=0x0000 ifindex=14  mac=0A:EB:0E:47:1A:ED nodemac=3E:FB:2B:A3:5E:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:40.472Z",
  "value": "id=2609  sec_id=6292321 flags=0x0000 ifindex=16  mac=D2:41:1F:83:14:6D nodemac=5E:B1:79:DE:65:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:41.439Z",
  "value": "id=846   sec_id=4     flags=0x0000 ifindex=10  mac=52:FC:32:97:4A:BA nodemac=E2:86:D5:3A:DC:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:41.439Z",
  "value": "id=3392  sec_id=6323134 flags=0x0000 ifindex=12  mac=12:FE:4D:26:D7:A3 nodemac=9E:0D:3D:49:67:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:41.439Z",
  "value": "id=2609  sec_id=6292321 flags=0x0000 ifindex=16  mac=D2:41:1F:83:14:6D nodemac=5E:B1:79:DE:65:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:41.439Z",
  "value": "id=2431  sec_id=6323134 flags=0x0000 ifindex=14  mac=0A:EB:0E:47:1A:ED nodemac=3E:FB:2B:A3:5E:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:23.274Z",
  "value": "id=4075  sec_id=6292321 flags=0x0000 ifindex=18  mac=E2:E9:55:3E:67:E8 nodemac=82:79:3E:67:45:D9"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.95.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:29.176Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:40.103Z",
  "value": "id=4075  sec_id=6292321 flags=0x0000 ifindex=18  mac=E2:E9:55:3E:67:E8 nodemac=82:79:3E:67:45:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:40.103Z",
  "value": "id=846   sec_id=4     flags=0x0000 ifindex=10  mac=52:FC:32:97:4A:BA nodemac=E2:86:D5:3A:DC:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:40.104Z",
  "value": "id=3392  sec_id=6323134 flags=0x0000 ifindex=12  mac=12:FE:4D:26:D7:A3 nodemac=9E:0D:3D:49:67:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:40.104Z",
  "value": "id=2431  sec_id=6323134 flags=0x0000 ifindex=14  mac=0A:EB:0E:47:1A:ED nodemac=3E:FB:2B:A3:5E:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:41.084Z",
  "value": "id=2431  sec_id=6323134 flags=0x0000 ifindex=14  mac=0A:EB:0E:47:1A:ED nodemac=3E:FB:2B:A3:5E:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:41.084Z",
  "value": "id=846   sec_id=4     flags=0x0000 ifindex=10  mac=52:FC:32:97:4A:BA nodemac=E2:86:D5:3A:DC:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:41.084Z",
  "value": "id=4075  sec_id=6292321 flags=0x0000 ifindex=18  mac=E2:E9:55:3E:67:E8 nodemac=82:79:3E:67:45:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:41.085Z",
  "value": "id=3392  sec_id=6323134 flags=0x0000 ifindex=12  mac=12:FE:4D:26:D7:A3 nodemac=9E:0D:3D:49:67:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:42.084Z",
  "value": "id=2431  sec_id=6323134 flags=0x0000 ifindex=14  mac=0A:EB:0E:47:1A:ED nodemac=3E:FB:2B:A3:5E:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:42.084Z",
  "value": "id=3392  sec_id=6323134 flags=0x0000 ifindex=12  mac=12:FE:4D:26:D7:A3 nodemac=9E:0D:3D:49:67:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:42.085Z",
  "value": "id=846   sec_id=4     flags=0x0000 ifindex=10  mac=52:FC:32:97:4A:BA nodemac=E2:86:D5:3A:DC:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.95.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:42.085Z",
  "value": "id=4075  sec_id=6292321 flags=0x0000 ifindex=18  mac=E2:E9:55:3E:67:E8 nodemac=82:79:3E:67:45:D9"
}

