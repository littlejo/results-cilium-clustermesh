ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.169.160:443 (active)    
                                          2 => 172.31.212.223:443 (active)    
2    10.100.84.23:443      ClusterIP      1 => 172.31.207.111:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.95.0.233:53 (active)        
                                          2 => 10.95.0.147:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.95.0.233:9153 (active)      
                                          2 => 10.95.0.147:9153 (active)      
5    10.100.105.136:2379   ClusterIP      1 => 10.95.0.250:2379 (active)      
