Endpoint ID: 119
Path: /sys/fs/bpf/tc/globals/cilium_policy_00119

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 846
Path: /sys/fs/bpf/tc/globals/cilium_policy_00846

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    440969   5632      0        
Allow    Ingress     1          ANY          NONE         disabled    12210    143       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2431
Path: /sys/fs/bpf/tc/globals/cilium_policy_02431

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    81395   936       0        
Allow    Egress      0          ANY          NONE         disabled    14294   149       0        


Endpoint ID: 3392
Path: /sys/fs/bpf/tc/globals/cilium_policy_03392

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    82884   955       0        
Allow    Egress      0          ANY          NONE         disabled    15017   159       0        


Endpoint ID: 4075
Path: /sys/fs/bpf/tc/globals/cilium_policy_04075

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3887292   36385     0        
Allow    Ingress     1          ANY          NONE         disabled    3161305   31906     0        
Allow    Egress      0          ANY          NONE         disabled    4316433   40127     0        


