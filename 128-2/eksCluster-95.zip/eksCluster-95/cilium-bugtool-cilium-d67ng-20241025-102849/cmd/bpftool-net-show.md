xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 498
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 491
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 485
cilium_host(7) clsact/egress cil_from_host-cilium_host id 481
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 477
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 523
lxc608a005cb9f0(12) clsact/ingress cil_from_container-lxc608a005cb9f0 id 503
lxce931f930a064(14) clsact/ingress cil_from_container-lxce931f930a064 id 549
lxcbab9562bb0c0(18) clsact/ingress cil_from_container-lxcbab9562bb0c0 id 606

flow_dissector:

netfilter:

