35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:49+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:59+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
477: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:14:47+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 116
478: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:14:47+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 117
479: sched_cls  name tail_handle_ipv4  tag 14916f188d0a8a11  gpl
	loaded_at 2024-10-25T10:14:47+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,97
	btf_id 118
480: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:14:47+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,97
	btf_id 119
481: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,99
	btf_id 121
482: sched_cls  name __send_drop_notify  tag 3f5d89d958ded1ad  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 122
483: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,99
	btf_id 123
485: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 125
487: sched_cls  name tail_handle_ipv4_from_host  tag 1375325abf32b552  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,99
	btf_id 127
488: sched_cls  name __send_drop_notify  tag 3f5d89d958ded1ad  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 129
489: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,101
	btf_id 130
491: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 132
493: sched_cls  name tail_handle_ipv4_from_host  tag 1375325abf32b552  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,101
	btf_id 134
495: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,104
	btf_id 137
498: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,104,75
	btf_id 140
499: sched_cls  name tail_handle_ipv4_from_host  tag 1375325abf32b552  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,104
	btf_id 141
501: sched_cls  name __send_drop_notify  tag 3f5d89d958ded1ad  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 143
503: sched_cls  name cil_from_container  tag eabde23e8a9d9b3f  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 109,76
	btf_id 148
512: sched_cls  name handle_policy  tag 63564da60b6304cb  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,109,82,83,108,41,80,105,39,84,75,40,37,38
	btf_id 149
515: sched_cls  name tail_ipv4_ct_ingress  tag 9b026626d1d82707  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,108,84
	btf_id 160
517: sched_cls  name tail_handle_arp  tag 3c6f41b3a0f03471  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,109
	btf_id 161
518: sched_cls  name __send_drop_notify  tag b89354c90cae4825  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 162
519: sched_cls  name tail_ipv4_to_endpoint  tag d67b8c2a977bb5d6  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,108,41,82,83,80,105,39,109,40,37,38
	btf_id 163
521: sched_cls  name tail_handle_ipv4_cont  tag 8e3b4b629f878d3e  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,108,41,105,82,83,39,76,74,77,109,40,37,38,81
	btf_id 165
522: sched_cls  name tail_handle_ipv4_cont  tag 512b45cdb39cb9bf  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,110,41,98,82,83,39,76,74,77,111,40,37,38,81
	btf_id 167
523: sched_cls  name cil_from_container  tag c25ca443c80ec646  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 111,76
	btf_id 169
524: sched_cls  name tail_handle_ipv4  tag ce147259a1210834  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,109
	btf_id 168
525: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,109
	btf_id 171
526: sched_cls  name tail_ipv4_ct_ingress  tag 16262bd3d89fe3f7  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,111,82,83,110,84
	btf_id 170
527: sched_cls  name __send_drop_notify  tag 6bd0ac9e13050272  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 173
528: sched_cls  name tail_ipv4_ct_egress  tag a0ebef63cc3aaa51  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,108,84
	btf_id 172
529: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 174
530: sched_cls  name handle_policy  tag 717bf9998e96b485  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,111,82,83,110,41,80,98,39,84,75,40,37,38
	btf_id 175
531: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,111,82,83,110,84
	btf_id 176
532: sched_cls  name tail_handle_ipv4  tag ddf439257d3496b0  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 177
533: sched_cls  name tail_ipv4_to_endpoint  tag 4467a9f54dd4c3a6  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,110,41,82,83,80,98,39,111,40,37,38
	btf_id 178
534: sched_cls  name tail_handle_arp  tag 31a63d2e2078de35  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 179
535: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
538: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
539: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
542: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
543: sched_cls  name tail_ipv4_to_endpoint  tag 4305b2a6499d07f7  gpl
	loaded_at 2024-10-25T10:14:55+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 181
544: sched_cls  name tail_ipv4_ct_ingress  tag 9e8b609c2be71944  gpl
	loaded_at 2024-10-25T10:14:55+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 182
545: sched_cls  name tail_handle_arp  tag 1481c106a0cee6c4  gpl
	loaded_at 2024-10-25T10:14:55+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 183
546: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:55+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 184
547: sched_cls  name handle_policy  tag 5f5801ee5cd1f790  gpl
	loaded_at 2024-10-25T10:14:55+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 185
548: sched_cls  name __send_drop_notify  tag 7c54aed93a44ff63  gpl
	loaded_at 2024-10-25T10:14:55+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 186
549: sched_cls  name cil_from_container  tag efc0db13a8f579e7  gpl
	loaded_at 2024-10-25T10:14:55+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 187
550: sched_cls  name tail_handle_ipv4_cont  tag add89640b3464954  gpl
	loaded_at 2024-10-25T10:14:55+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 188
551: sched_cls  name tail_handle_ipv4  tag 90ea34213b938c92  gpl
	loaded_at 2024-10-25T10:14:55+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 189
553: sched_cls  name tail_ipv4_ct_egress  tag a0ebef63cc3aaa51  gpl
	loaded_at 2024-10-25T10:14:55+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 191
554: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
557: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
558: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
561: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
601: sched_cls  name tail_handle_arp  tag edb4cfcad420c8f7  gpl
	loaded_at 2024-10-25T10:22:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,131
	btf_id 205
603: sched_cls  name tail_ipv4_ct_egress  tag 1f1b65ab3607d7fb  gpl
	loaded_at 2024-10-25T10:22:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,131,82,83,130,84
	btf_id 207
604: sched_cls  name tail_handle_ipv4  tag e941ec8aa4353ae4  gpl
	loaded_at 2024-10-25T10:22:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,131
	btf_id 208
605: sched_cls  name tail_ipv4_ct_ingress  tag a2a160fa2af70cb0  gpl
	loaded_at 2024-10-25T10:22:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,131,82,83,130,84
	btf_id 209
606: sched_cls  name cil_from_container  tag e774ddd969fd1eae  gpl
	loaded_at 2024-10-25T10:22:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 131,76
	btf_id 210
607: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,131
	btf_id 211
608: sched_cls  name tail_handle_ipv4_cont  tag 4538e130c5a297fe  gpl
	loaded_at 2024-10-25T10:22:23+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,130,41,129,82,83,39,76,74,77,131,40,37,38,81
	btf_id 212
609: sched_cls  name tail_ipv4_to_endpoint  tag 8e69540c0d77baa3  gpl
	loaded_at 2024-10-25T10:22:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,130,41,82,83,80,129,39,131,40,37,38
	btf_id 213
610: sched_cls  name __send_drop_notify  tag 18d7c7b4f33cb5f8  gpl
	loaded_at 2024-10-25T10:22:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 214
611: sched_cls  name handle_policy  tag 51ca21a91c214665  gpl
	loaded_at 2024-10-25T10:22:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,131,82,83,130,41,80,129,39,84,75,40,37,38
	btf_id 215
612: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
615: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
628: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
631: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
632: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
635: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
636: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
639: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
