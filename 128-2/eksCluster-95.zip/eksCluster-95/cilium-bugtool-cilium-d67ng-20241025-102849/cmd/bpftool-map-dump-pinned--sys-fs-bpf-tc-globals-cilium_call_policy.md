key: 4e 03 00 00  value: 12 02 00 00
key: 7f 09 00 00  value: 23 02 00 00
key: 40 0d 00 00  value: 00 02 00 00
key: eb 0f 00 00  value: 63 02 00 00
Found 4 elements
