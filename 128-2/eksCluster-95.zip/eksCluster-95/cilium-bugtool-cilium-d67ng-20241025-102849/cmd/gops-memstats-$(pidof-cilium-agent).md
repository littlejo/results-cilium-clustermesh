alloc: 135.43MB (142009176 bytes)
total-alloc: 1.35GB (1445211080 bytes)
sys: 206.57MB (216606036 bytes)
lookups: 0
mallocs: 48103911
frees: 46601231
heap-alloc: 135.43MB (142009176 bytes)
heap-sys: 161.17MB (169000960 bytes)
heap-idle: 9.53MB (9994240 bytes)
heap-in-use: 151.64MB (159006720 bytes)
heap-released: 1.56MB (1638400 bytes)
heap-objects: 1502680
stack-in-use: 34.78MB (36470784 bytes)
stack-sys: 34.78MB (36470784 bytes)
stack-mspan-inuse: 2.48MB (2600800 bytes)
stack-mspan-sys: 2.61MB (2741760 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 764.33KB (782673 bytes)
gc-sys: 5.34MB (5603560 bytes)
next-gc: when heap-alloc >= 146.09MB (153182728 bytes)
last-gc: 2024-10-25 10:28:35.046980739 +0000 UTC
gc-pause-total: 6.361199ms
gc-pause: 78679
gc-pause-end: 1729852115046980739
num-gc: 71
num-forced-gc: 0
gc-cpu-fraction: 0.0002906035614409406
enable-gc: true
debug-gc: false
