REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10248     801756     677    bpf_overlay.c
Interface                 INGRESS     219302    85192876   1132   bpf_host.c
Success                   EGRESS      10447     816596     53     encap.h
Success                   EGRESS      5276      405520     1694   bpf_host.c
Success                   EGRESS      91280     12239808   1308   bpf_lxc.c
Success                   INGRESS     102836    12538886   86     l3.h
Success                   INGRESS     108457    12979028   235    trace.h
Unsupported L3 protocol   EGRESS      46        3524       1492   bpf_lxc.c
