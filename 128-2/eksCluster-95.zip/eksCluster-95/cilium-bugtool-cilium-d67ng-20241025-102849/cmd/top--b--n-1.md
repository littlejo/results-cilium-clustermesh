top - 10:28:50 up 15 min,  0 users,  load average: 0.10, 0.17, 0.13
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 13.3 us, 23.3 sy,  0.0 ni, 63.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    797.4 free,    896.4 used,   2142.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2770.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    636 root      20   0 1240176  15872  10896 S   6.2   0.4   0:00.03 cilium-+
      1 root      20   0 1538292 281276  77000 S   0.0   7.2   0:25.51 cilium-+
    416 root      20   0 1228848   5540   2872 S   0.0   0.1   0:00.28 cilium-+
    607 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    625 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    679 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    697 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
