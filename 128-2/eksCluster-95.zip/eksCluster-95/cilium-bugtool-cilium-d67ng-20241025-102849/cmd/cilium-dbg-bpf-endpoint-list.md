IP ADDRESS         LOCAL ENDPOINT INFO
10.95.0.25:0       id=846   sec_id=4     flags=0x0000 ifindex=10  mac=52:FC:32:97:4A:BA nodemac=E2:86:D5:3A:DC:04     
172.31.207.111:0   (localhost)                                                                                        
10.95.0.233:0      id=3392  sec_id=6323134 flags=0x0000 ifindex=12  mac=12:FE:4D:26:D7:A3 nodemac=9E:0D:3D:49:67:AE   
10.95.0.250:0      id=4075  sec_id=6292321 flags=0x0000 ifindex=18  mac=E2:E9:55:3E:67:E8 nodemac=82:79:3E:67:45:D9   
10.95.0.84:0       (localhost)                                                                                        
10.95.0.147:0      id=2431  sec_id=6323134 flags=0x0000 ifindex=14  mac=0A:EB:0E:47:1A:ED nodemac=3E:FB:2B:A3:5E:F6   
