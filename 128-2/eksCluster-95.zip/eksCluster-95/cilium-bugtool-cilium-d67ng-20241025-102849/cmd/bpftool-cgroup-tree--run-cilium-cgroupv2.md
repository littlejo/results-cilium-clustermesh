CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8aeefe42_55bc_4733_b434_34aa23f093e8.slice/cri-containerd-9a951116af1308856abe7be9a848d19436a870ab3d4d764dc6d759e3d1c1f9fe.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8aeefe42_55bc_4733_b434_34aa23f093e8.slice/cri-containerd-3af0752893a259b4fc50f6608dc3d3646d54ab276f175935776add002883c738.scope
    542      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd1c5b677_f6d8_442b_a561_2ac772ff2eb4.slice/cri-containerd-f59eff3b4a2b639a2660c0ef14c22fe20ead1b81726ea1ac595f43c855a5beff.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd1c5b677_f6d8_442b_a561_2ac772ff2eb4.slice/cri-containerd-35fbe4273538307f49751f66d8360a894849d354931602ee79933d1be72e19ac.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode4870ffe_72d3_431a_9ff7_270277ed9351.slice/cri-containerd-4fe18fc108d57f6f3b681bcb84587519140a18cad815e118a6ee253c4224a4b1.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode4870ffe_72d3_431a_9ff7_270277ed9351.slice/cri-containerd-31bcd01e949e52cef807dc39a1ee759838793fba12d66bec067c603b3d61b9a3.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf173a616_6cba_421d_8379_0025f56beca9.slice/cri-containerd-aca4647374f21d8f054256799b9bc4157bf39470c083fcf1f1c38eff69c3f66c.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf173a616_6cba_421d_8379_0025f56beca9.slice/cri-containerd-a439ed9f386b5cf4a8e8071339841738a895835c442c6750a21f1276b382c698.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1185253c_7424_47d7_a9e9_084f4b7e6085.slice/cri-containerd-9366298487c402484e1e780d560d8dc70822939096c0a4c02b976b84a98e77d2.scope
    615      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1185253c_7424_47d7_a9e9_084f4b7e6085.slice/cri-containerd-f0fe39a2762712c8f147be1addf999433e514b18be8809bc02d54757b859c94c.scope
    635      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1185253c_7424_47d7_a9e9_084f4b7e6085.slice/cri-containerd-2896dc386ae3de4ce67589f241c4b480f08063e699979523aa7e84d34fc125be.scope
    631      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1185253c_7424_47d7_a9e9_084f4b7e6085.slice/cri-containerd-99034dd4aacf87e4124dbaac0bc1a2955de4653b89beacc8707258e801028d12.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf16d8d29_5463_4f66_92bd_975836eb3d75.slice/cri-containerd-73131d495dfe0f366887f9a1b64d60b0c28d155e061e5ac10c0c8d387064b659.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf16d8d29_5463_4f66_92bd_975836eb3d75.slice/cri-containerd-763a8fe15a05ae82664d326e24356a2097eaa8df48b795238ff471fb4eaad85c.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeced8390_c607_42bd_b1ac_7448c4fcd615.slice/cri-containerd-0de2320eb8f855ec771ad338a0fa48c9be97e02098267451a9806d8fca00b768.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeced8390_c607_42bd_b1ac_7448c4fcd615.slice/cri-containerd-961e1155d977180143af7851b5d29d4b8a1809c42de1caedf281fb24734e3c83.scope
    109      cgroup_device   multi                                          
