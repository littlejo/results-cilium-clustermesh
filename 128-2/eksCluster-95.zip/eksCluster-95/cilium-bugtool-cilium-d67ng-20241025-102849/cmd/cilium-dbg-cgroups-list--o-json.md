[
  {
    "containers": [
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1185253c_7424_47d7_a9e9_084f4b7e6085.slice/cri-containerd-99034dd4aacf87e4124dbaac0bc1a2955de4653b89beacc8707258e801028d12.scope"
      },
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1185253c_7424_47d7_a9e9_084f4b7e6085.slice/cri-containerd-f0fe39a2762712c8f147be1addf999433e514b18be8809bc02d54757b859c94c.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1185253c_7424_47d7_a9e9_084f4b7e6085.slice/cri-containerd-2896dc386ae3de4ce67589f241c4b480f08063e699979523aa7e84d34fc125be.scope"
      }
    ],
    "ips": [
      "10.95.0.250"
    ],
    "name": "clustermesh-apiserver-5b6b8f4845-4rc4f",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7535,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8aeefe42_55bc_4733_b434_34aa23f093e8.slice/cri-containerd-3af0752893a259b4fc50f6608dc3d3646d54ab276f175935776add002883c738.scope"
      }
    ],
    "ips": [
      "10.95.0.233"
    ],
    "name": "coredns-cc6ccd49c-xwwwp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode4870ffe_72d3_431a_9ff7_270277ed9351.slice/cri-containerd-31bcd01e949e52cef807dc39a1ee759838793fba12d66bec067c603b3d61b9a3.scope"
      }
    ],
    "ips": [
      "10.95.0.147"
    ],
    "name": "coredns-cc6ccd49c-bg4hg",
    "namespace": "kube-system"
  }
]

