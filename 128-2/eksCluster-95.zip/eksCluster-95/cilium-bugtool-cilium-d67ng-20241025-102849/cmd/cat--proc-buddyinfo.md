Node 0, zone      DMA     63     98     13     38     16     10      1      2      1      3    164 
Node 0, zone   Normal    254      8      1      2      6      9      3      1      0      1      9 
