USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         636  0.0  0.3 1240176 15620 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         667  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         625  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         607  0.0  0.0 1228744 3596 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  2.9  7.1 1538292 281276 ?      Ssl  10:14   0:25 cilium-agent --config-dir=/tmp/cilium/config-map
root         416  0.0  0.1 1228848 5540 ?        Sl   10:14   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
