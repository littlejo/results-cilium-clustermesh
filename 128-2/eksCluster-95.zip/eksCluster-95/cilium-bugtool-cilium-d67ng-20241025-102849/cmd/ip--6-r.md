fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxc608a005cb9f0 proto kernel metric 256 pref medium
fe80::/64 dev lxce931f930a064 proto kernel metric 256 pref medium
fe80::/64 dev lxcbab9562bb0c0 proto kernel metric 256 pref medium
