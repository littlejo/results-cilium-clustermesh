1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:67:65:91:3a:61 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.207.111/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2701sec preferred_lft 2701sec
    inet6 fe80::867:65ff:fe91:3a61/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST> mtu 1500 qdisc noop state DOWN group default qlen 1000
    link/ether 0a:af:9f:4a:28:f3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:06:c2:b9:a3:eb brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8806:c2ff:feb9:a3eb/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:c2:b0:d8:d9:bf brd ff:ff:ff:ff:ff:ff
    inet 10.95.0.84/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::ccc2:b0ff:fed8:d9bf/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 12:8b:4f:7a:8c:dc brd ff:ff:ff:ff:ff:ff
    inet6 fe80::108b:4fff:fe7a:8cdc/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:86:d5:3a:dc:04 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::e086:d5ff:fe3a:dc04/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc608a005cb9f0@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:0d:3d:49:67:ae brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::9c0d:3dff:fe49:67ae/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce931f930a064@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:fb:2b:a3:5e:f6 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::3cfb:2bff:fea3:5ef6/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcbab9562bb0c0@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:79:3e:67:45:d9 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::8079:3eff:fe67:45d9/64 scope link 
       valid_lft forever preferred_lft forever
