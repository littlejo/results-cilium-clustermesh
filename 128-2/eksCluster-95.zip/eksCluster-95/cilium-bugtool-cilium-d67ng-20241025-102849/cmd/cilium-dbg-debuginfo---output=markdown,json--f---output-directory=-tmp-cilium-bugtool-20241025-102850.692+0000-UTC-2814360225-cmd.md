markdown output at /tmp/cilium-bugtool-20241025-102850.692+0000-UTC-2814360225/cmd/cilium-debuginfo-20241025-102921.221+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102850.692+0000-UTC-2814360225/cmd/cilium-debuginfo-20241025-102921.221+0000-UTC.json
