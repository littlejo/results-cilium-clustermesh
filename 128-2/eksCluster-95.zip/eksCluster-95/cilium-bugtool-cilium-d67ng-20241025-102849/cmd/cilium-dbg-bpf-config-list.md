KEY             VALUE
AgentLiveness   939195990920
UTimeOffset     3378615667968750
