KEY             VALUE
AgentLiveness   953871821046
UTimeOffset     3378615632812500
