[
  {
    "containers": [
      {
        "cgroup-id": 8711,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod10c592c3_2eae_4366_be6a_cf88f137d656.slice/cri-containerd-46b9da6a28eb96a4c165a49e9e9146243eca70418a1e030fa91ff4de76b10cac.scope"
      },
      {
        "cgroup-id": 8627,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod10c592c3_2eae_4366_be6a_cf88f137d656.slice/cri-containerd-1ac662cf9297b850b09d5ffbaa09d9136fdf965ccc7fb516f2e141c85a600a2b.scope"
      },
      {
        "cgroup-id": 8795,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod10c592c3_2eae_4366_be6a_cf88f137d656.slice/cri-containerd-f03349a1cb2ffb270e74a7b075f312db96184f716ee9c2bb79452adce0e5bff2.scope"
      }
    ],
    "ips": [
      "10.67.0.141"
    ],
    "name": "clustermesh-apiserver-546c656c9b-k46jt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7283,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podae7dbf75_bebf_4ba1_a9f0_7ac3126add21.slice/cri-containerd-2440be8606001b84f4f39b817f790c08001a7ee87d5ff97446ecd0403e43765c.scope"
      }
    ],
    "ips": [
      "10.67.0.129"
    ],
    "name": "coredns-cc6ccd49c-q8cgb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7199,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf8ae9380_b601_4681_a9ed_e00dd034fccd.slice/cri-containerd-43bd345cd2ab71d11736d2cbd1b5f9561fff3a9f94937abd2fa239ffa975868f.scope"
      }
    ],
    "ips": [
      "10.67.0.107"
    ],
    "name": "coredns-cc6ccd49c-c26s9",
    "namespace": "kube-system"
  }
]

