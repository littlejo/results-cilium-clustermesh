{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:27.315Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.217.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:27.315Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:31.597Z",
  "value": "id=3306  sec_id=4     flags=0x0000 ifindex=7   mac=A2:39:67:20:01:CB nodemac=B2:13:71:AA:30:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:31.600Z",
  "value": "id=1229  sec_id=4514958 flags=0x0000 ifindex=9   mac=62:3A:71:C0:81:E8 nodemac=3A:E6:98:F2:97:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:31.661Z",
  "value": "id=3306  sec_id=4     flags=0x0000 ifindex=7   mac=A2:39:67:20:01:CB nodemac=B2:13:71:AA:30:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:31.663Z",
  "value": "id=1255  sec_id=4514958 flags=0x0000 ifindex=11  mac=5A:B1:15:0F:C6:58 nodemac=9E:87:81:C2:BA:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:13.048Z",
  "value": "id=3306  sec_id=4     flags=0x0000 ifindex=7   mac=A2:39:67:20:01:CB nodemac=B2:13:71:AA:30:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:13.049Z",
  "value": "id=1229  sec_id=4514958 flags=0x0000 ifindex=9   mac=62:3A:71:C0:81:E8 nodemac=3A:E6:98:F2:97:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:13.050Z",
  "value": "id=1255  sec_id=4514958 flags=0x0000 ifindex=11  mac=5A:B1:15:0F:C6:58 nodemac=9E:87:81:C2:BA:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:13.077Z",
  "value": "id=1582  sec_id=4474565 flags=0x0000 ifindex=13  mac=56:0E:25:2A:24:F1 nodemac=32:D3:1E:77:51:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:14.047Z",
  "value": "id=1229  sec_id=4514958 flags=0x0000 ifindex=9   mac=62:3A:71:C0:81:E8 nodemac=3A:E6:98:F2:97:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:14.047Z",
  "value": "id=1582  sec_id=4474565 flags=0x0000 ifindex=13  mac=56:0E:25:2A:24:F1 nodemac=32:D3:1E:77:51:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:14.047Z",
  "value": "id=1255  sec_id=4514958 flags=0x0000 ifindex=11  mac=5A:B1:15:0F:C6:58 nodemac=9E:87:81:C2:BA:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:14.047Z",
  "value": "id=3306  sec_id=4     flags=0x0000 ifindex=7   mac=A2:39:67:20:01:CB nodemac=B2:13:71:AA:30:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:11.864Z",
  "value": "id=1278  sec_id=4474565 flags=0x0000 ifindex=15  mac=BA:03:D4:38:1B:45 nodemac=46:73:C0:0E:5A:40"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.67.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:22.192Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:22.275Z",
  "value": "id=1255  sec_id=4514958 flags=0x0000 ifindex=11  mac=5A:B1:15:0F:C6:58 nodemac=9E:87:81:C2:BA:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:22.276Z",
  "value": "id=1278  sec_id=4474565 flags=0x0000 ifindex=15  mac=BA:03:D4:38:1B:45 nodemac=46:73:C0:0E:5A:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:22.277Z",
  "value": "id=3306  sec_id=4     flags=0x0000 ifindex=7   mac=A2:39:67:20:01:CB nodemac=B2:13:71:AA:30:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:22.278Z",
  "value": "id=1229  sec_id=4514958 flags=0x0000 ifindex=9   mac=62:3A:71:C0:81:E8 nodemac=3A:E6:98:F2:97:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:23.273Z",
  "value": "id=3306  sec_id=4     flags=0x0000 ifindex=7   mac=A2:39:67:20:01:CB nodemac=B2:13:71:AA:30:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:23.274Z",
  "value": "id=1278  sec_id=4474565 flags=0x0000 ifindex=15  mac=BA:03:D4:38:1B:45 nodemac=46:73:C0:0E:5A:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:23.274Z",
  "value": "id=1229  sec_id=4514958 flags=0x0000 ifindex=9   mac=62:3A:71:C0:81:E8 nodemac=3A:E6:98:F2:97:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:23.274Z",
  "value": "id=1255  sec_id=4514958 flags=0x0000 ifindex=11  mac=5A:B1:15:0F:C6:58 nodemac=9E:87:81:C2:BA:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.274Z",
  "value": "id=1255  sec_id=4514958 flags=0x0000 ifindex=11  mac=5A:B1:15:0F:C6:58 nodemac=9E:87:81:C2:BA:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.274Z",
  "value": "id=1229  sec_id=4514958 flags=0x0000 ifindex=9   mac=62:3A:71:C0:81:E8 nodemac=3A:E6:98:F2:97:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.274Z",
  "value": "id=3306  sec_id=4     flags=0x0000 ifindex=7   mac=A2:39:67:20:01:CB nodemac=B2:13:71:AA:30:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.274Z",
  "value": "id=1278  sec_id=4474565 flags=0x0000 ifindex=15  mac=BA:03:D4:38:1B:45 nodemac=46:73:C0:0E:5A:40"
}

