CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf8ae9380_b601_4681_a9ed_e00dd034fccd.slice/cri-containerd-43bd345cd2ab71d11736d2cbd1b5f9561fff3a9f94937abd2fa239ffa975868f.scope
    556      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf8ae9380_b601_4681_a9ed_e00dd034fccd.slice/cri-containerd-bb986bb648f5b25ec1605978dbdf42baccbf22a4ff79af02b2fc65c60bdd6614.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod912115ab_3f16_4020_92e5_f9d1bc16db74.slice/cri-containerd-6c8ae6aa2482b8fbc2c3663f5944e260272cd097acd0b0aa7fcb841d4e36f909.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod912115ab_3f16_4020_92e5_f9d1bc16db74.slice/cri-containerd-fcab64e042248ee9f2c27ddf63f7e949b0e3a39c231a41a8aa6f27100db53363.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podae7dbf75_bebf_4ba1_a9f0_7ac3126add21.slice/cri-containerd-2440be8606001b84f4f39b817f790c08001a7ee87d5ff97446ecd0403e43765c.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podae7dbf75_bebf_4ba1_a9f0_7ac3126add21.slice/cri-containerd-10b1a59c83ff592e67bcb3a949798fecb2113b0bb8fef45644a8e3d87b99d267.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9fd9bc30_bf0e_48cf_94ab_902f523e6a0a.slice/cri-containerd-375999d7b22c957cfa9fec6a9438df7e34fe43f9b3f071d34e7f032fce3ca51a.scope
    114      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9fd9bc30_bf0e_48cf_94ab_902f523e6a0a.slice/cri-containerd-dc309fa2dde1878ee0715ac3a5ad35a0b47c29ab52f0ae774a5bcde4e36b9249.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode913519a_ebec_48e8_97b5_ea4f66f78960.slice/cri-containerd-a033e4defd5f70f4808ccf1624eda4493c5fb8479e3176827b04e6a71322c73a.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode913519a_ebec_48e8_97b5_ea4f66f78960.slice/cri-containerd-0aca64dca8c67dca3dc5a14c2cce2fcc9a0b70240e773433c52477c17cf35020.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod10c592c3_2eae_4366_be6a_cf88f137d656.slice/cri-containerd-46b9da6a28eb96a4c165a49e9e9146243eca70418a1e030fa91ff4de76b10cac.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod10c592c3_2eae_4366_be6a_cf88f137d656.slice/cri-containerd-1ac662cf9297b850b09d5ffbaa09d9136fdf965ccc7fb516f2e141c85a600a2b.scope
    630      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod10c592c3_2eae_4366_be6a_cf88f137d656.slice/cri-containerd-09a7e8b90a7893fcf4cb9617f8f2173fc05564ebc7ed5aafe0b561189ea0b3dc.scope
    614      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod10c592c3_2eae_4366_be6a_cf88f137d656.slice/cri-containerd-f03349a1cb2ffb270e74a7b075f312db96184f716ee9c2bb79452adce0e5bff2.scope
    638      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3bea98d2_d1cb_4a6f_8dcd_61eca30e8629.slice/cri-containerd-39c0e083610cc5a25a25bdcf388935c56daa7e8cfc0e8af88136106436b45815.scope
    72       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3bea98d2_d1cb_4a6f_8dcd_61eca30e8629.slice/cri-containerd-215c991afc5e45767c34a221e850ec7a383da436b25a0022c6a9eaefa5e4761b.scope
    83       cgroup_device   multi                                          
