key: cd 04 00 00  value: e2 01 00 00
key: e7 04 00 00  value: 1c 02 00 00
key: fe 04 00 00  value: 5d 02 00 00
key: ea 0c 00 00  value: 17 02 00 00
Found 4 elements
