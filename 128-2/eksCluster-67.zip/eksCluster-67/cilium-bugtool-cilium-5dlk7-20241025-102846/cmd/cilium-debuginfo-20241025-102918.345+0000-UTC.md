# Cilium debug information

#### Cilium environment keys

```
endpoint-gc-interval:5m0s
ingress-secrets-namespace:
bpf-lb-mode:snat
enable-k8s-endpoint-slice:true
bpf-root:/sys/fs/bpf
bpf-lb-sock-terminate-pod-connections:false
hubble-redact-kafka-apikey:false
encryption-strict-mode-allow-remote-node-identities:false
cluster-name:cmesh68
proxy-max-requests-per-connection:0
identity-restore-grace-period:30s
envoy-keep-cap-netbindservice:false
bpf-lb-affinity-map-max:0
bpf-filter-priority:1
encrypt-interface:
cluster-health-port:4240
kvstore-max-consecutive-quorum-errors:2
proxy-portrange-min:10000
node-port-acceleration:disabled
fixed-identity-mapping:
ipv6-node:auto
restore:true
unmanaged-pod-watcher-interval:15
enable-health-check-nodeport:true
clustermesh-ip-identities-sync-timeout:1m0s
enable-host-firewall:false
enable-tracing:false
node-port-bind-protection:true
hubble-drop-events:false
cflags:
hubble-redact-http-userinfo:true
vtep-mac:
bgp-config-path:/var/lib/cilium/bgp/config.yaml
allow-localhost:auto
kvstore-lease-ttl:15m0s
enable-l2-pod-announcements:false
bpf-lb-algorithm:random
controller-group-metrics:
iptables-random-fully:false
log-opt:
enable-k8s-networkpolicy:true
bpf-sock-rev-map-max:262144
enable-health-checking:true
http-request-timeout:3600
join-cluster:false
state-dir:/var/run/cilium
ipam-default-ip-pool:default
enable-k8s-terminating-endpoint:true
enable-ipip-termination:false
node-labels:
enable-node-selector-labels:false
enable-active-connection-tracking:false
bpf-lb-sock:false
hubble-metrics-server:
enable-ipv6:false
bpf-ct-global-tcp-max:524288
enable-policy:default
hubble-recorder-storage-path:/var/run/cilium/pcaps
enable-ipsec-key-watcher:true
tofqdns-pre-cache:
mesh-auth-mutual-connect-timeout:5s
trace-payloadlen:128
remove-cilium-node-taints:true
l2-announcements-renew-deadline:5s
multicast-enabled:false
kube-proxy-replacement-healthz-bind-address:
tofqdns-idle-connection-grace-period:0s
hubble-event-buffer-capacity:4095
envoy-log:
keep-config:false
mesh-auth-rotated-identities-queue-size:1024
exclude-node-label-patterns:
node-port-range:
disable-endpoint-crd:false
config:
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
bpf-lb-acceleration:disabled
enable-vtep:false
ipv6-range:auto
bpf-map-event-buffers:
endpoint-queue-size:25
hubble-disable-tls:false
hubble-prefer-ipv6:false
debug-verbose:
enable-bpf-clock-probe:false
hubble-export-file-compress:false
enable-l2-announcements:false
static-cnp-path:
enable-auto-protect-node-port-range:true
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
enable-ipv4:true
hubble-export-fieldmask:
enable-wireguard-userspace-fallback:false
enable-mke:false
hubble-export-denylist:
auto-direct-node-routes:false
bpf-ct-global-any-max:262144
tofqdns-endpoint-max-ip-per-hostname:50
enable-ipv6-masquerade:true
tofqdns-dns-reject-response-code:refused
bpf-events-trace-enabled:true
k8s-service-proxy-name:
hubble-export-allowlist:
ip-masq-agent-config-path:/etc/config/ip-masq-agent
dnsproxy-socket-linger-timeout:10
mesh-auth-mutual-listener-port:0
monitor-aggregation-interval:5s
ipv6-service-range:auto
bgp-announce-pod-cidr:false
encryption-strict-mode-cidr:
bpf-lb-maglev-map-max:0
enable-recorder:false
proxy-admin-port:0
enable-ip-masq-agent:false
bpf-ct-timeout-regular-tcp-fin:10s
install-iptables-rules:true
enable-well-known-identities:false
bpf-fragments-map-max:8192
bpf-lb-rss-ipv6-src-cidr:
monitor-aggregation-flags:all
nodeport-addresses:
labels:
dnsproxy-insecure-skip-transparent-mode-check:false
enable-bgp-control-plane:false
bpf-lb-service-backend-map-max:0
enable-custom-calls:false
ipv4-range:auto
bpf-lb-source-range-map-max:0
bpf-ct-timeout-regular-tcp-syn:1m0s
bpf-ct-timeout-regular-tcp:2h13m20s
cni-chaining-target:
max-internal-timer-delay:0s
ipv6-cluster-alloc-cidr:f00d::/64
bpf-ct-timeout-service-tcp:2h13m20s
log-driver:
hubble-export-file-max-backups:5
cmdref:
nodes-gc-interval:5m0s
dnsproxy-enable-transparent-mode:true
auto-create-cilium-node-resource:true
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
external-envoy-proxy:true
bpf-nat-global-max:524288
route-metric:0
hubble-flowlogs-config-path:
iptables-lock-timeout:5s
enable-bbr:false
bpf-ct-timeout-service-tcp-grace:1m0s
enable-external-ips:false
enable-ipv4-fragment-tracking:true
bpf-events-drop-enabled:true
hubble-export-file-path:
enable-icmp-rules:true
enable-local-node-route:true
hubble-metrics:
policy-cidr-match-mode:
enable-unreachable-routes:false
arping-refresh-period:30s
metrics:
pprof-port:6060
vtep-endpoint:
mesh-auth-spiffe-trust-domain:spiffe.cilium
enable-srv6:false
nat-map-stats-interval:30s
enable-ipv4-big-tcp:false
endpoint-bpf-prog-watchdog-interval:30s
proxy-gid:1337
l2-announcements-retry-period:2s
derive-masq-ip-addr-from-device:
dnsproxy-concurrency-processing-grace-period:0s
bpf-lb-sock-hostns-only:false
operator-api-serve-addr:127.0.0.1:9234
enable-stale-cilium-endpoint-cleanup:true
egress-gateway-reconciliation-trigger-interval:1s
enable-service-topology:false
hubble-redact-enabled:false
envoy-base-id:0
enable-bandwidth-manager:false
prometheus-serve-addr:
enable-cilium-endpoint-slice:false
ipv6-pod-subnets:
hubble-recorder-sink-queue-size:1024
enable-identity-mark:true
enable-cilium-api-server-access:
http-retry-timeout:0
ipv4-node:auto
agent-labels:
enable-endpoint-health-checking:true
direct-routing-skip-unreachable:false
ipam-cilium-node-update-rate:15s
routing-mode:tunnel
ipsec-key-file:
cni-exclusive:true
enable-ipv4-masquerade:true
pprof-address:localhost
enable-nat46x64-gateway:false
gops-port:9890
http-normalize-path:true
tofqdns-min-ttl:0
config-dir:/tmp/cilium/config-map
policy-accounting:true
local-max-addr-scope:252
enable-pmtu-discovery:false
annotate-k8s-node:false
enable-monitor:true
enable-endpoint-routes:false
preallocate-bpf-maps:false
enable-ipsec-xfrm-state-caching:true
bpf-ct-timeout-service-any:1m0s
k8s-heartbeat-timeout:30s
enable-k8s:true
k8s-kubeconfig-path:
enable-ipv4-egress-gateway:false
proxy-idle-timeout-seconds:60
vlan-bpf-bypass:
k8s-client-connection-keep-alive:30s
dnsproxy-concurrency-limit:0
hubble-event-queue-size:0
bpf-map-dynamic-size-ratio:0.0025
conntrack-gc-max-interval:0s
k8s-service-cache-size:128
cluster-id:68
config-sources:config-map:kube-system/cilium-config
cgroup-root:/run/cilium/cgroupv2
pprof:false
enable-xt-socket-fallback:true
k8s-client-qps:10
certificates-directory:/var/run/cilium/certs
gateway-api-secrets-namespace:
install-no-conntrack-iptables-rules:false
identity-allocation-mode:crd
monitor-queue-size:0
hubble-socket-path:/var/run/cilium/hubble.sock
hubble-redact-http-urlquery:false
enable-runtime-device-detection:true
http-max-grpc-timeout:0
socket-path:/var/run/cilium/cilium.sock
exclude-local-address:
bpf-lb-dsr-l4-xlate:frontend
vtep-mask:
enable-health-check-loadbalancer-ip:false
bpf-policy-map-max:16384
enable-session-affinity:false
bpf-policy-map-full-reconciliation-interval:15m0s
kvstore:
hubble-redact-http-headers-allow:
kvstore-opt:
clustermesh-sync-timeout:1m0s
proxy-connect-timeout:2
policy-queue-size:100
cluster-pool-ipv4-cidr:10.67.0.0/16
tofqdns-proxy-port:0
enable-local-redirect-policy:false
cni-log-file:/var/run/cilium/cilium-cni.log
local-router-ipv6:
k8s-require-ipv4-pod-cidr:false
k8s-namespace:kube-system
enable-ipsec-encrypted-overlay:false
ipsec-key-rotation-duration:5m0s
proxy-xff-num-trusted-hops-ingress:0
bpf-auth-map-max:524288
crd-wait-timeout:5m0s
custom-cni-conf:false
cilium-endpoint-gc-interval:5m0s
srv6-encap-mode:reduced
k8s-require-ipv6-pod-cidr:false
enable-host-legacy-routing:false
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
enable-envoy-config:false
mesh-auth-gc-interval:5m0s
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
enable-node-port:false
dnsproxy-lock-count:131
mesh-auth-enabled:true
ipv4-pod-subnets:
enable-encryption-strict-mode:false
mesh-auth-spire-admin-socket:
envoy-secrets-namespace:
enable-masquerade-to-route-source:false
node-port-mode:snat
enable-svc-source-range-check:true
monitor-aggregation:medium
allow-icmp-frag-needed:true
mtu:0
lib-dir:/var/lib/cilium
enable-cilium-health-api-server-access:
mesh-auth-signal-backoff-duration:1s
prepend-iptables-chains:true
k8s-client-burst:20
synchronize-k8s-nodes:true
enable-high-scale-ipcache:false
identity-gc-interval:15m0s
proxy-max-connection-duration-seconds:0
agent-liveness-update-interval:1s
dns-policy-unload-on-shutdown:false
hubble-skip-unknown-cgroup-ids:true
enable-l2-neigh-discovery:true
proxy-portrange-max:20000
debug:false
vtep-cidr:
kube-proxy-replacement:false
enable-ingress-controller:false
bpf-lb-dsr-dispatch:opt
bpf-lb-rev-nat-map-max:0
tofqdns-enable-dns-compression:true
bpf-lb-rss-ipv4-src-cidr:
force-device-detection:false
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
mesh-auth-queue-size:1024
operator-prometheus-serve-addr::9963
ipv6-mcast-device:
enable-ipsec:false
hubble-monitor-events:
enable-bpf-masquerade:false
max-controller-interval:0
l2-announcements-lease-duration:15s
http-idle-timeout:0
http-retry-count:3
set-cilium-is-up-condition:true
hubble-redact-http-headers-deny:
bpf-lb-maglev-table-size:16381
dns-max-ips-per-restored-rule:1000
bpf-neigh-global-max:524288
clustermesh-config:/var/lib/cilium/clustermesh/
cni-external-routing:false
cluster-pool-ipv4-mask-size:24
encrypt-node:false
procfs:/host/proc
proxy-prometheus-port:0
ipam:cluster-pool
k8s-client-connection-timeout:30s
bypass-ip-availability-upon-restore:false
bpf-events-policy-verdict-enabled:true
ipv4-service-loopback-address:169.254.42.1
use-full-tls-context:false
clustermesh-enable-mcs-api:false
bpf-lb-external-clusterip:false
enable-ipv6-big-tcp:false
conntrack-gc-interval:0s
kvstore-periodic-sync:5m0s
max-connected-clusters:255
l2-pod-announcements-interface:
api-rate-limit:
hubble-listen-address::4244
devices:
enable-hubble-recorder-api:true
proxy-xff-num-trusted-hops-egress:0
hubble-drop-events-interval:2m0s
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
enable-ipv6-ndp:false
agent-health-port:9879
k8s-sync-timeout:3m0s
trace-sock:true
local-router-ipv4:
set-cilium-node-taints:true
mke-cgroup-mount:
tofqdns-proxy-response-max-delay:100ms
wireguard-persistent-keepalive:0s
enable-xdp-prefilter:false
tunnel-port:0
enable-gateway-api:false
use-cilium-internal-ip-for-ipsec:false
container-ip-local-reserved-ports:auto
ipam-multi-pool-pre-allocation:
node-port-algorithm:random
ipv6-native-routing-cidr:
policy-audit-mode:false
bpf-node-map-max:16384
version:false
bgp-announce-lb-ip:false
identity-heartbeat-timeout:30m0s
enable-tcx:true
disable-iptables-feeder-rules:
hubble-drop-events-reasons:auth_required,policy_denied
read-cni-conf:
identity-change-grace-period:5s
datapath-mode:veth
bpf-lb-service-map-max:0
k8s-api-server:
enable-host-port:false
fqdn-regex-compile-lru-size:1024
enable-wireguard:false
nat-map-stats-entries:32
cni-chaining-mode:none
tunnel-protocol:vxlan
enable-hubble:true
ipv4-native-routing-cidr:
enable-l7-proxy:true
disable-envoy-version-check:false
log-system-load:false
ipv4-service-range:auto
bpf-lb-map-max:65536
enable-bpf-tproxy:false
enable-sctp:false
kvstore-connectivity-timeout:2m0s
enable-route-mtu-for-cni-chaining:false
direct-routing-device:
label-prefix-file:
allocator-list-timeout:3m0s
egress-multi-home-ip-rule-compat:false
bpf-ct-timeout-regular-any:1m0s
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
clustermesh-enable-endpoint-sync:false
enable-metrics:true
disable-external-ip-mitigation:false
enable-k8s-api-discovery:false
dnsproxy-lock-timeout:500ms
envoy-config-timeout:2m0s
egress-gateway-policy-map-max:16384
service-no-backend-response:reject
policy-trigger-interval:1s
hubble-export-file-max-size-mb:10
tofqdns-max-deferred-connection-deletes:10000
envoy-config-retry-interval:15s
egress-masquerade-interfaces:ens+
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
1229       Disabled           Disabled          4514958    k8s:eks.amazonaws.com/component=coredns                                             10.67.0.107   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh68                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
1255       Disabled           Disabled          4514958    k8s:eks.amazonaws.com/component=coredns                                             10.67.0.129   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh68                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
1278       Disabled           Disabled          4474565    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.67.0.141   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh68                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
2189       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                
                                                           reserved:host                                                                                             
3306       Disabled           Disabled          4          reserved:health                                                                     10.67.0.5     ready   
```

#### BPF Policy Get 1229

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    82921   952       0        
Allow    Egress      0          ANY          NONE         disabled    14469   152       0        

```


#### BPF CT List 1229

```
Invalid argument: unknown type 1229
```


#### Endpoint Get 1229

```
[
  {
    "id": 1229,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1229-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "00cd7894-6180-4a44-bfab-13fcad30286a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1229",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:28.894Z",
            "success-count": 3
          },
          "uuid": "3c996e69-c9b6-45fe-b438-8512ed702dca"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-c26s9",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:28.893Z",
            "success-count": 1
          },
          "uuid": "582d7744-e576-40fb-a2dc-7ba7cb24c94d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1229",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:31.602Z",
            "success-count": 1
          },
          "uuid": "ee65d08f-164a-4a1e-a38e-572a9ec743cb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1229)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:08.969Z",
            "success-count": 90
          },
          "uuid": "c1c3b587-6cbc-41c2-987d-c9a931559d6c"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "bb986bb648f5b25ec1605978dbdf42baccbf22a4ff79af02b2fc65c60bdd6614:eth0",
        "container-id": "bb986bb648f5b25ec1605978dbdf42baccbf22a4ff79af02b2fc65c60bdd6614",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-c26s9",
        "pod-name": "kube-system/coredns-cc6ccd49c-c26s9"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4514958,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh68",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh68",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:24Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.67.0.107",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "3a:e6:98:f2:97:ff",
        "interface-index": 9,
        "interface-name": "lxc6cf0ed929fe0",
        "mac": "62:3a:71:c0:81:e8"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4514958,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4514958,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1229

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1229

```
Timestamp              Status    State                   Message
2024-10-25T10:22:24Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:24Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:24Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:22:24Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:23Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:23Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:23Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:23Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:22Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:22Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:22Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:22Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:14Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:14Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:14Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:14Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:13Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:13Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:13Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:13Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:31Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:31Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:30Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:29Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:14:29Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:28Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:28Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:14:28Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:28Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 4514958

```
ID        LABELS
4514958   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh68
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1255

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83684   960       0        
Allow    Egress      0          ANY          NONE         disabled    13945   147       0        

```


#### BPF CT List 1255

```
Invalid argument: unknown type 1255
```


#### Endpoint Get 1255

```
[
  {
    "id": 1255,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1255-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5be13abb-a719-4efd-87b7-8a2e8baca0f3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1255",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:28.960Z",
            "success-count": 3
          },
          "uuid": "5a365ac2-cbb5-49bb-8179-91aa4536ff9c"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-q8cgb",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:28.957Z",
            "success-count": 1
          },
          "uuid": "84e49da3-51b7-4c80-b140-deebf6e12f2d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1255",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:31.664Z",
            "success-count": 1
          },
          "uuid": "a4e158be-32fe-427a-8334-bf2e0abbc424"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1255)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:09.033Z",
            "success-count": 90
          },
          "uuid": "f560983a-f3d8-4729-9bf6-4a3c895b5f2d"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "10b1a59c83ff592e67bcb3a949798fecb2113b0bb8fef45644a8e3d87b99d267:eth0",
        "container-id": "10b1a59c83ff592e67bcb3a949798fecb2113b0bb8fef45644a8e3d87b99d267",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-q8cgb",
        "pod-name": "kube-system/coredns-cc6ccd49c-q8cgb"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4514958,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh68",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh68",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:24Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.67.0.129",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "9e:87:81:c2:ba:f8",
        "interface-index": 11,
        "interface-name": "lxceab4c19095f8",
        "mac": "5a:b1:15:0f:c6:58"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4514958,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4514958,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1255

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1255

```
Timestamp              Status   State                   Message
2024-10-25T10:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:24Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:31Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:29Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:14:29Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:28Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:28Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4514958

```
ID        LABELS
4514958   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh68
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1278

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3813781   36484     0        
Allow    Ingress     1          ANY          NONE         disabled    3259744   33148     0        
Allow    Egress      0          ANY          NONE         disabled    5446593   50015     0        

```


#### BPF CT List 1278

```
Invalid argument: unknown type 1278
```


#### Endpoint Get 1278

```
[
  {
    "id": 1278,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1278-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7519c395-5b2c-4614-848e-45f042131231"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1278",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:11.830Z",
            "success-count": 2
          },
          "uuid": "4e289466-7be1-45d2-85c3-7046e94900e8"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-546c656c9b-k46jt",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:11.829Z",
            "success-count": 1
          },
          "uuid": "c303cb63-89af-4471-b5fa-79851e2ceae7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1278",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:11.865Z",
            "success-count": 1
          },
          "uuid": "2b59ba79-5c92-4473-bf7a-019148c2c850"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1278)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:11.873Z",
            "success-count": 50
          },
          "uuid": "ddcee1d4-24a8-4812-bca5-0ca863257b40"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "09a7e8b90a7893fcf4cb9617f8f2173fc05564ebc7ed5aafe0b561189ea0b3dc:eth0",
        "container-id": "09a7e8b90a7893fcf4cb9617f8f2173fc05564ebc7ed5aafe0b561189ea0b3dc",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-546c656c9b-k46jt",
        "pod-name": "kube-system/clustermesh-apiserver-546c656c9b-k46jt"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4474565,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh68",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=546c656c9b"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh68",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:24Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.67.0.141",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "46:73:c0:0e:5a:40",
        "interface-index": 15,
        "interface-name": "lxce7461d2f6775",
        "mac": "ba:03:d4:38:1b:45"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4474565,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4474565,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1278

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1278

```
Timestamp              Status   State                   Message
2024-10-25T10:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:24Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:11Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:11Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:11Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4474565

```
ID        LABELS
4474565   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh68
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 2189

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2189

```
Invalid argument: unknown type 2189
```


#### Endpoint Get 2189

```
[
  {
    "id": 2189,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2189-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b15d57bd-41c4-416d-bc53-0d96c10ed857"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2189",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:27.509Z",
            "success-count": 3
          },
          "uuid": "e99e804c-8240-4361-96b6-c18ef1fecd88"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2189",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:28.533Z",
            "success-count": 1
          },
          "uuid": "1942a5c2-eba4-4b97-b503-9d7baa9fd180"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:24Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "e2:3e:e3:47:e3:6c",
        "interface-name": "cilium_host",
        "mac": "e2:3e:e3:47:e3:6c"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2189

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2189

```
Timestamp              Status   State                   Message
2024-10-25T10:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:24Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:14:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:31Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:14:30Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:29Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:14:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:14:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:27Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:27Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:27Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 3306

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    439696   5632      0        
Allow    Ingress     1          ANY          NONE         disabled    12190    143       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 3306

```
Invalid argument: unknown type 3306
```


#### Endpoint Get 3306

```
[
  {
    "id": 3306,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3306-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "3e9531bf-4614-491d-8a04-bc5b9247a542"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3306",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:28.575Z",
            "success-count": 3
          },
          "uuid": "eddfe967-eb85-4aaa-9aa2-611d12aec83d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3306",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:31.597Z",
            "success-count": 1
          },
          "uuid": "152ef17d-5794-47f5-af28-e959c99ab246"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:24Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.67.0.5",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "b2:13:71:aa:30:02",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "a2:39:67:20:01:cb"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3306

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3306

```
Timestamp              Status   State                   Message
2024-10-25T10:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:24Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:31Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:29Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:14:29Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:28Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:28Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:27Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.192.221:443 (active)    
                                          2 => 172.31.142.167:443 (active)    
2    10.100.110.117:443    ClusterIP      1 => 172.31.217.208:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.67.0.129:53 (active)        
                                          2 => 10.67.0.107:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.67.0.129:9153 (active)      
                                          2 => 10.67.0.107:9153 (active)      
5    10.100.151.215:2379   ClusterIP      1 => 10.67.0.141:2379 (active)      
```

#### Policy get

```
:
 []
Revision: 1

```


#### Cilium encryption



#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.67.0.0/24, 
Allocated addresses:
  10.67.0.107 (kube-system/coredns-cc6ccd49c-c26s9)
  10.67.0.129 (kube-system/coredns-cc6ccd49c-q8cgb)
  10.67.0.141 (kube-system/clustermesh-apiserver-546c656c9b-k46jt)
  10.67.0.236 (router)
  10.67.0.5 (health)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: c5af86b6e7eab3b1
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    51s ago        never        0       no error   
  ct-map-pressure                                                     22s ago        never        0       no error   
  daemon-validate-config                                              38s ago        never        0       no error   
  dns-garbage-collector-job                                           54s ago        never        0       no error   
  endpoint-1229-regeneration-recovery                                 never          never        0       no error   
  endpoint-1255-regeneration-recovery                                 never          never        0       no error   
  endpoint-1278-regeneration-recovery                                 never          never        0       no error   
  endpoint-2189-regeneration-recovery                                 never          never        0       no error   
  endpoint-3306-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                         4m55s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                22s ago        never        0       no error   
  ipcache-inject-labels                                               52s ago        never        0       no error   
  k8s-heartbeat                                                       25s ago        never        0       no error   
  link-cache                                                          7s ago         never        0       no error   
  local-identity-checkpoint                                           14m52s ago     never        0       no error   
  node-neighbor-link-updater                                          2s ago         never        0       no error   
  remote-etcd-cmesh1                                                  6m57s ago      never        0       no error   
  remote-etcd-cmesh10                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh100                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh101                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh102                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh103                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh104                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh105                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh106                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh107                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh108                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh109                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh11                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh110                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh111                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh112                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh113                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh114                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh115                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh116                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh117                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh118                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh119                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh12                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh120                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh121                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh122                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh123                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh124                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh125                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh126                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh127                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh128                                                6m57s ago      never        0       no error   
  remote-etcd-cmesh13                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh14                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh15                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh16                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh17                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh18                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh19                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh2                                                  6m57s ago      never        0       no error   
  remote-etcd-cmesh20                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh21                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh22                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh23                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh24                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh25                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh26                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh27                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh28                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh29                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh3                                                  6m57s ago      never        0       no error   
  remote-etcd-cmesh30                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh31                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh32                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh33                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh34                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh35                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh36                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh37                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh38                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh39                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh4                                                  6m57s ago      never        0       no error   
  remote-etcd-cmesh40                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh41                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh42                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh43                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh44                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh45                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh46                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh47                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh48                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh49                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh5                                                  6m57s ago      never        0       no error   
  remote-etcd-cmesh50                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh51                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh52                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh53                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh54                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh55                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh56                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh57                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh58                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh59                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh6                                                  6m57s ago      never        0       no error   
  remote-etcd-cmesh60                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh61                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh62                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh63                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh64                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh65                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh66                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh67                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh69                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh7                                                  6m57s ago      never        0       no error   
  remote-etcd-cmesh70                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh71                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh72                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh73                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh74                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh75                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh76                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh77                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh78                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh79                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh8                                                  6m57s ago      never        0       no error   
  remote-etcd-cmesh80                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh81                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh82                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh83                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh84                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh85                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh86                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh87                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh88                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh89                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh9                                                  6m57s ago      never        0       no error   
  remote-etcd-cmesh90                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh91                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh92                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh93                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh94                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh95                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh96                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh97                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh98                                                 6m57s ago      never        0       no error   
  remote-etcd-cmesh99                                                 6m57s ago      never        0       no error   
  resolve-identity-1229                                               4m51s ago      never        0       no error   
  resolve-identity-1255                                               4m50s ago      never        0       no error   
  resolve-identity-1278                                               3m8s ago       never        0       no error   
  resolve-identity-2189                                               4m52s ago      never        0       no error   
  resolve-identity-3306                                               4m51s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-546c656c9b-k46jt   8m8s ago       never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-c26s9                  14m51s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-q8cgb                  14m50s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      14m52s ago     never        0       no error   
  sync-policymap-1229                                                 14m48s ago     never        0       no error   
  sync-policymap-1255                                                 14m48s ago     never        0       no error   
  sync-policymap-1278                                                 8m8s ago       never        0       no error   
  sync-policymap-2189                                                 14m51s ago     never        0       no error   
  sync-policymap-3306                                                 14m48s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (1229)                                   10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1255)                                   10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1278)                                   8s ago         never        0       no error   
  sync-utime                                                          52s ago        never        0       no error   
  write-cni-file                                                      14m55s ago     never        0       no error   
Proxy Status:            OK, ip 10.67.0.236, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 4456448, max 4521983
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 75.35   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 6309331                           /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 6309331                           /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 6309331                           /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400c400000 rw-p 00000000 00:00 0 
400c400000-4010000000 ---p 00000000 00:00 0 
ffff59c1b000-ffff59e21000 rw-p 00000000 00:00 0 
ffff59e29000-ffff59f4a000 rw-p 00000000 00:00 0 
ffff59f4a000-ffff59f8b000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff59f8b000-ffff59fcc000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff59fcc000-ffff59fce000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff59fce000-ffff59fd0000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff59fd0000-ffff5a597000 rw-p 00000000 00:00 0 
ffff5a597000-ffff5a697000 rw-p 00000000 00:00 0 
ffff5a697000-ffff5a6a8000 rw-p 00000000 00:00 0 
ffff5a6a8000-ffff5c6a8000 rw-p 00000000 00:00 0 
ffff5c6a8000-ffff5c728000 ---p 00000000 00:00 0 
ffff5c728000-ffff5c729000 rw-p 00000000 00:00 0 
ffff5c729000-ffff7c728000 ---p 00000000 00:00 0 
ffff7c728000-ffff7c729000 rw-p 00000000 00:00 0 
ffff7c729000-ffff9c6b8000 ---p 00000000 00:00 0 
ffff9c6b8000-ffff9c6b9000 rw-p 00000000 00:00 0 
ffff9c6b9000-ffffa06aa000 ---p 00000000 00:00 0 
ffffa06aa000-ffffa06ab000 rw-p 00000000 00:00 0 
ffffa06ab000-ffffa0ea8000 ---p 00000000 00:00 0 
ffffa0ea8000-ffffa0ea9000 rw-p 00000000 00:00 0 
ffffa0ea9000-ffffa0fa8000 ---p 00000000 00:00 0 
ffffa0fa8000-ffffa1008000 rw-p 00000000 00:00 0 
ffffa1008000-ffffa100a000 r--p 00000000 00:00 0                          [vvar]
ffffa100a000-ffffa100b000 r-xp 00000000 00:00 0                          [vdso]
fffff3411000-fffff3432000 rw-p 00000000 00:00 0                          [stack]

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.67.0.141": (string) (len=50) "kube-system/clustermesh-apiserver-546c656c9b-k46jt",
  (string) (len=11) "10.67.0.236": (string) (len=6) "router",
  (string) (len=9) "10.67.0.5": (string) (len=6) "health",
  (string) (len=11) "10.67.0.107": (string) (len=35) "kube-system/coredns-cc6ccd49c-c26s9",
  (string) (len=11) "10.67.0.129": (string) (len=35) "kube-system/coredns-cc6ccd49c-q8cgb"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.217.208": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001b8c4d0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x40024a8cc0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x40024a8cc0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x40013ab340)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4003848370)(frontends:[]/ports=[kvmesh-metrics etcd-metrics apiserv-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4003848420)(frontends:[10.100.151.215]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x40013ab1e0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x40013ab290)(frontends:[10.100.110.117]/ports=[peer-service]/selector=map[k8s-app:cilium])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x40019930e8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40023d7e10)(172.31.142.167:443/TCP,172.31.192.221:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x40019930f0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-92r27": (*k8s.Endpoints)(0x40012175f0)(172.31.217.208:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x40019930f8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-l2mtg": (*k8s.Endpoints)(0x4002fb7930)(10.67.0.107:53/TCP[eu-west-3b],10.67.0.107:53/UDP[eu-west-3b],10.67.0.107:9153/TCP[eu-west-3b],10.67.0.129:53/TCP[eu-west-3b],10.67.0.129:53/UDP[eu-west-3b],10.67.0.129:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001992698)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-fhb7q": (*k8s.Endpoints)(0x40038a4270)(10.67.0.141:2379/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001a2fc70)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x400083ba90)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x40012cb878
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4002289080,
  gcExited: (chan struct {}) 0x40022890e0,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001e4c080)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000f04b20)({
      MetricVec: (*prometheus.MetricVec)(0x4001e45980)({
       metricMap: (*prometheus.metricMap)(0x4001e459b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b974a0)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001e4c100)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000f04b28)({
      MetricVec: (*prometheus.MetricVec)(0x4001e45a10)({
       metricMap: (*prometheus.metricMap)(0x4001e45a40)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b97500)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001e4c180)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000f04b30)({
      MetricVec: (*prometheus.MetricVec)(0x4001e45aa0)({
       metricMap: (*prometheus.metricMap)(0x4001e45ad0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b97560)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001e4c200)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000f04b38)({
      MetricVec: (*prometheus.MetricVec)(0x4001e45b30)({
       metricMap: (*prometheus.metricMap)(0x4001e45b60)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b975c0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001e4c280)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000f04b40)({
      MetricVec: (*prometheus.MetricVec)(0x4001e45bc0)({
       metricMap: (*prometheus.metricMap)(0x4001e45bf0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b97620)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001e4c300)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000f04b48)({
      MetricVec: (*prometheus.MetricVec)(0x4001e45c50)({
       metricMap: (*prometheus.metricMap)(0x4001e45c80)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b97680)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001e4c380)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000f04b50)({
      MetricVec: (*prometheus.MetricVec)(0x4001e45ce0)({
       metricMap: (*prometheus.metricMap)(0x4001e45d10)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b976e0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001e4c400)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000f04b58)({
      MetricVec: (*prometheus.MetricVec)(0x4001e45d70)({
       metricMap: (*prometheus.metricMap)(0x4001e45da0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b97740)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001e4c480)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000f04b60)({
      MetricVec: (*prometheus.MetricVec)(0x4001e45e00)({
       metricMap: (*prometheus.metricMap)(0x4001e45e30)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b977a0)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001a2fc70)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001e6e690)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4000db1ad0)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 197ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   },
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```

