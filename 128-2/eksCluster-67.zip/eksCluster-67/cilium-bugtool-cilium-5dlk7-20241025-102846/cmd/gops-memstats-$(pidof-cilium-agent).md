alloc: 77.66MB (81431696 bytes)
total-alloc: 1.36GB (1462685032 bytes)
sys: 202.32MB (212146500 bytes)
lookups: 0
mallocs: 48353654
frees: 47706424
heap-alloc: 77.66MB (81431696 bytes)
heap-sys: 157.35MB (164995072 bytes)
heap-idle: 42.37MB (44425216 bytes)
heap-in-use: 114.98MB (120569856 bytes)
heap-released: 1.03MB (1081344 bytes)
heap-objects: 647230
stack-in-use: 34.62MB (36306944 bytes)
stack-sys: 34.62MB (36306944 bytes)
stack-mspan-inuse: 1.92MB (2016480 bytes)
stack-mspan-sys: 2.44MB (2562240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 925.08KB (947281 bytes)
gc-sys: 5.10MB (5342496 bytes)
next-gc: when heap-alloc >= 146.62MB (153743304 bytes)
last-gc: 2024-10-25 10:29:03.546353917 +0000 UTC
gc-pause-total: 17.96025ms
gc-pause: 103394
gc-pause-end: 1729852143546353917
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00033801226109986504
enable-gc: true
debug-gc: false
