1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:92:3f:cf:5b:e9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.217.208/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2686sec preferred_lft 2686sec
    inet6 fe80::892:3fff:fecf:5be9/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:95:31:5f:1d:78 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::fc95:31ff:fe5f:1d78/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:3e:e3:47:e3:6c brd ff:ff:ff:ff:ff:ff
    inet 10.67.0.236/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::e03e:e3ff:fe47:e36c/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether a2:8b:b3:e4:f8:53 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a08b:b3ff:fee4:f853/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:13:71:aa:30:02 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::b013:71ff:feaa:3002/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc6cf0ed929fe0@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:e6:98:f2:97:ff brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::38e6:98ff:fef2:97ff/64 scope link 
       valid_lft forever preferred_lft forever
11: lxceab4c19095f8@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:87:81:c2:ba:f8 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::9c87:81ff:fec2:baf8/64 scope link 
       valid_lft forever preferred_lft forever
15: lxce7461d2f6775@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:73:c0:0e:5a:40 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::4473:c0ff:fe0e:5a40/64 scope link 
       valid_lft forever preferred_lft forever
