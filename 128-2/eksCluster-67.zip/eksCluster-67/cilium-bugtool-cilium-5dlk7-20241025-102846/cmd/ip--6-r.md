fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxc6cf0ed929fe0 proto kernel metric 256 pref medium
fe80::/64 dev lxceab4c19095f8 proto kernel metric 256 pref medium
fe80::/64 dev lxce7461d2f6775 proto kernel metric 256 pref medium
