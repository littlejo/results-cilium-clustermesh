Node 0, zone      DMA      1      1      2      1     16     10      5      2      2      2    168 
Node 0, zone   Normal    165     31     11     10     21      7      3      1      1      4      7 
