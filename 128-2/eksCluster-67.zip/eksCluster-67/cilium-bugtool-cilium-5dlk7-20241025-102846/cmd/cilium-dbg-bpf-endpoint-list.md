IP ADDRESS         LOCAL ENDPOINT INFO
10.67.0.107:0      id=1229  sec_id=4514958 flags=0x0000 ifindex=9   mac=62:3A:71:C0:81:E8 nodemac=3A:E6:98:F2:97:FF   
10.67.0.236:0      (localhost)                                                                                        
10.67.0.141:0      id=1278  sec_id=4474565 flags=0x0000 ifindex=15  mac=BA:03:D4:38:1B:45 nodemac=46:73:C0:0E:5A:40   
10.67.0.129:0      id=1255  sec_id=4514958 flags=0x0000 ifindex=11  mac=5A:B1:15:0F:C6:58 nodemac=9E:87:81:C2:BA:F8   
10.67.0.5:0        id=3306  sec_id=4     flags=0x0000 ifindex=7   mac=A2:39:67:20:01:CB nodemac=B2:13:71:AA:30:02     
172.31.217.208:0   (localhost)                                                                                        
