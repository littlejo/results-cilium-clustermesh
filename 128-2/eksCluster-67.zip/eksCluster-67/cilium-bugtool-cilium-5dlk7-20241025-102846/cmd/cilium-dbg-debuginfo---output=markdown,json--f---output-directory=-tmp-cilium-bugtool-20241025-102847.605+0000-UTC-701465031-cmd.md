markdown output at /tmp/cilium-bugtool-20241025-102847.605+0000-UTC-701465031/cmd/cilium-debuginfo-20241025-102918.345+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102847.605+0000-UTC-701465031/cmd/cilium-debuginfo-20241025-102918.345+0000-UTC.json
