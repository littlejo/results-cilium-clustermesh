29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:27+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:27+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:27+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:27+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:27+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:27+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
69: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
72: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
80: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
83: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
111: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
114: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
455: sched_cls  name tail_handle_ipv4  tag 464d5fdf9b3b19c4  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 71,70,77,72,93
	btf_id 115
456: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 116
457: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 72,93
	btf_id 117
458: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 118
482: sched_cls  name handle_policy  tag 42998cafb83f47d0  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,104,78,79,105,37,76,101,35,80,71,36,33,34
	btf_id 147
483: sched_cls  name __send_drop_notify  tag 3172ae000134d5fd  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 149
488: sched_cls  name tail_ipv4_to_endpoint  tag 5bb4cb724879f5af  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,105,37,78,79,76,101,35,104,36,33,34
	btf_id 151
489: sched_cls  name cil_from_container  tag 94a5c5c2f8df5ee9  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 104,72
	btf_id 155
493: sched_cls  name tail_handle_ipv4  tag 3247e948a55206f9  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,104
	btf_id 156
495: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,104
	btf_id 160
496: sched_cls  name tail_handle_ipv4_cont  tag 46816c6dca110485  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,105,37,101,78,79,35,72,70,73,104,36,33,34,77
	btf_id 162
499: sched_cls  name tail_ipv4_ct_egress  tag 9854d63a8dcc1f3a  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,104,78,79,105,80
	btf_id 163
500: sched_cls  name cil_from_container  tag 1ca59f635b132369  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 108,72
	btf_id 167
501: sched_cls  name tail_ipv4_ct_ingress  tag fdbcbaab2ab5b98f  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,104,78,79,105,80
	btf_id 165
502: sched_cls  name tail_handle_arp  tag 7748344d00337bd7  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,104
	btf_id 169
503: sched_cls  name __send_drop_notify  tag 4eff3685ce605f50  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 171
504: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 172
506: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,109
	btf_id 174
507: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 72,71,109
	btf_id 175
509: sched_cls  name tail_handle_ipv4_from_host  tag 27994925b7c53e1f  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,109
	btf_id 177
510: sched_cls  name __send_drop_notify  tag 4eff3685ce605f50  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 179
511: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 180
513: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,112
	btf_id 182
516: sched_cls  name tail_ipv4_ct_ingress  tag 5271d8ace7795511  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,108,78,79,107,80
	btf_id 168
517: sched_cls  name tail_handle_ipv4_from_host  tag 27994925b7c53e1f  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,112
	btf_id 185
518: sched_cls  name __send_drop_notify  tag 4eff3685ce605f50  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 188
520: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 72,114,71
	btf_id 190
521: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,114
	btf_id 191
524: sched_cls  name tail_handle_ipv4_from_host  tag 27994925b7c53e1f  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,114
	btf_id 194
525: sched_cls  name cil_from_container  tag b64bc9d4ebeec1c6  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 116,72
	btf_id 196
526: sched_cls  name tail_handle_ipv4  tag ebc2c1edd9907492  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,108
	btf_id 186
527: sched_cls  name tail_handle_arp  tag 7b9ba6afb1bf79f9  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,108
	btf_id 198
528: sched_cls  name tail_ipv4_to_endpoint  tag 88d3449917cd7e63  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 71,72,115,37,78,79,76,94,35,116,36,33,34
	btf_id 197
529: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,108
	btf_id 199
530: sched_cls  name tail_handle_ipv4_cont  tag e934555b8dadf9f8  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 71,115,37,94,78,79,35,72,70,73,116,36,33,34,77
	btf_id 200
532: sched_cls  name tail_handle_ipv4_cont  tag aab560b4e254dccf  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,107,37,106,78,79,35,72,70,73,108,36,33,34,77
	btf_id 202
534: sched_cls  name tail_ipv4_to_endpoint  tag 9f413e688eda5365  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,107,37,78,79,76,106,35,108,36,33,34
	btf_id 205
535: sched_cls  name handle_policy  tag c77ea18f9266968d  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 72,116,78,79,115,37,76,94,35,80,71,36,33,34
	btf_id 203
536: sched_cls  name tail_ipv4_ct_ingress  tag 43489090399c80d0  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 72,116,78,79,115,80
	btf_id 207
537: sched_cls  name __send_drop_notify  tag adc0902695150898  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 208
538: sched_cls  name tail_handle_ipv4  tag 5aea56d9d4909b2f  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,116
	btf_id 209
539: sched_cls  name tail_handle_arp  tag ebda84e38325d22d  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,116
	btf_id 210
540: sched_cls  name handle_policy  tag d5daa94a40f04442  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,108,78,79,107,37,76,106,35,80,71,36,33,34
	btf_id 206
541: sched_cls  name __send_drop_notify  tag 30c5b5267e82c795  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 212
542: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 72,116,78,79,115,80
	btf_id 211
543: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,116
	btf_id 214
544: sched_cls  name tail_ipv4_ct_egress  tag 9854d63a8dcc1f3a  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,108,78,79,107,80
	btf_id 213
545: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
548: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
549: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
552: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
553: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
556: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
557: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
560: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
600: sched_cls  name tail_ipv4_ct_egress  tag 6e04918bfa9baf02  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,133,78,79,132,80
	btf_id 229
602: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,133
	btf_id 231
603: sched_cls  name cil_from_container  tag 00db636eb8bdb8c8  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 133,72
	btf_id 232
604: sched_cls  name __send_drop_notify  tag 8ad29f5ab3720b24  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 233
605: sched_cls  name handle_policy  tag a4c3d7f4652fc316  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,133,78,79,132,37,76,131,35,80,71,36,33,34
	btf_id 234
606: sched_cls  name tail_handle_ipv4  tag 10f57d71fab99879  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,133
	btf_id 235
607: sched_cls  name tail_handle_arp  tag 89c33c918762350d  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,133
	btf_id 236
608: sched_cls  name tail_ipv4_to_endpoint  tag 1544de16c69d02e3  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,132,37,78,79,76,131,35,133,36,33,34
	btf_id 237
609: sched_cls  name tail_handle_ipv4_cont  tag cd485486fa5e1d2c  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,132,37,131,78,79,35,72,70,73,133,36,33,34,77
	btf_id 238
610: sched_cls  name tail_ipv4_ct_ingress  tag 3e693cb3ca32560f  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,133,78,79,132,80
	btf_id 239
611: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
614: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
627: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
630: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
631: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
634: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
635: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
638: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
