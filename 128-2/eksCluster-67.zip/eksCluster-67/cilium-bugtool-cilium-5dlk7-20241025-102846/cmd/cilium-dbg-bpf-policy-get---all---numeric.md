Endpoint ID: 1229
Path: /sys/fs/bpf/tc/globals/cilium_policy_01229

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83882   963       0        
Allow    Egress      0          ANY          NONE         disabled    14469   152       0        


Endpoint ID: 1255
Path: /sys/fs/bpf/tc/globals/cilium_policy_01255

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83684   960       0        
Allow    Egress      0          ANY          NONE         disabled    13945   147       0        


Endpoint ID: 1278
Path: /sys/fs/bpf/tc/globals/cilium_policy_01278

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3826385   36623     0        
Allow    Ingress     1          ANY          NONE         disabled    3304632   33644     0        
Allow    Egress      0          ANY          NONE         disabled    5453937   50097     0        


Endpoint ID: 2189
Path: /sys/fs/bpf/tc/globals/cilium_policy_02189

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3306
Path: /sys/fs/bpf/tc/globals/cilium_policy_03306

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    441266   5651      0        
Allow    Ingress     1          ANY          NONE         disabled    12190    143       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


