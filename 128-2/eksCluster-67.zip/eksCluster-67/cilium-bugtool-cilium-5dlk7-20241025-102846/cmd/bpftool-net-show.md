xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 520
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 511
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 504
cilium_host(4) clsact/egress cil_from_host-cilium_host id 507
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 457
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 456
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 525
lxc6cf0ed929fe0(9) clsact/ingress cil_from_container-lxc6cf0ed929fe0 id 489
lxceab4c19095f8(11) clsact/ingress cil_from_container-lxceab4c19095f8 id 500
lxce7461d2f6775(15) clsact/ingress cil_from_container-lxce7461d2f6775 id 603

flow_dissector:

netfilter:

