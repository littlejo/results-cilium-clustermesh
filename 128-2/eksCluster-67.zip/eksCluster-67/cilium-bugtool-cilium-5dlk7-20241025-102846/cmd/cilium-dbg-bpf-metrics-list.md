REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     10249     800582      677    bpf_overlay.c
Interface                 INGRESS     227810    101904946   1132   bpf_host.c
Success                   EGRESS      10484     818441      53     encap.h
Success                   EGRESS      5288      406520      1694   bpf_host.c
Success                   EGRESS      97750     12716074    1308   bpf_lxc.c
Success                   INGRESS     107758    13373895    86     l3.h
Success                   INGRESS     113368    13811863    235    trace.h
Unsupported L3 protocol   EGRESS      36        2672        1492   bpf_lxc.c
