ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.192.221:443 (active)    
                                          2 => 172.31.142.167:443 (active)    
2    10.100.110.117:443    ClusterIP      1 => 172.31.217.208:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.67.0.129:53 (active)        
                                          2 => 10.67.0.107:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.67.0.129:9153 (active)      
                                          2 => 10.67.0.107:9153 (active)      
5    10.100.151.215:2379   ClusterIP      1 => 10.67.0.141:2379 (active)      
