Node 0, zone      DMA      4     65     22     37     14      6      3      2      3      4    161 
Node 0, zone   Normal    708     38     30     48     10      3      0      0      0      4      7 
