Endpoint ID: 86
Path: /sys/fs/bpf/tc/globals/cilium_policy_00086

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3816546   36557     0        
Allow    Ingress     1          ANY          NONE         disabled    3964805   39283     0        
Allow    Egress      0          ANY          NONE         disabled    5449324   50151     0        


Endpoint ID: 364
Path: /sys/fs/bpf/tc/globals/cilium_policy_00364

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    434266   5549      0        
Allow    Ingress     1          ANY          NONE         disabled    9842     113       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 387
Path: /sys/fs/bpf/tc/globals/cilium_policy_00387

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    67611   777       0        
Allow    Egress      0          ANY          NONE         disabled    11844   119       0        


Endpoint ID: 2365
Path: /sys/fs/bpf/tc/globals/cilium_policy_02365

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3347
Path: /sys/fs/bpf/tc/globals/cilium_policy_03347

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    67677   778       0        
Allow    Egress      0          ANY          NONE         disabled    12428   126       0        


