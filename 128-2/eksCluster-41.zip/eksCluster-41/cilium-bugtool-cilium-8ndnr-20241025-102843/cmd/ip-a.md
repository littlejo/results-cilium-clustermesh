1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:20:ea:bc:20:95 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.249.77/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2810sec preferred_lft 2810sec
    inet6 fe80::820:eaff:febc:2095/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:24:f8:56:11:d9 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.203.251/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::824:f8ff:fe56:11d9/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:4a:c2:85:c4:89 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e84a:c2ff:fe85:c489/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:b4:b1:48:62:08 brd ff:ff:ff:ff:ff:ff
    inet 10.41.0.69/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::3cb4:b1ff:fe48:6208/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ce:04:22:3c:e5:63 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::cc04:22ff:fe3c:e563/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:29:6f:0a:12:cc brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::ac29:6fff:fe0a:12cc/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc297fb20fb350@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:76:d4:c4:a3:0e brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::2c76:d4ff:fec4:a30e/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc8071a33b7e1c@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:a3:03:18:dd:1f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::eca3:3ff:fe18:dd1f/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcfb461dd7365c@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:3f:3a:1b:13:af brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::a43f:3aff:fe1b:13af/64 scope link 
       valid_lft forever preferred_lft forever
