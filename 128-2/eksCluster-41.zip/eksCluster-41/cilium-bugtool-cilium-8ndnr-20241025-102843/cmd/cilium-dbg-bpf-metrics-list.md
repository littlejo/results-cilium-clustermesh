REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10710     840932     677    bpf_overlay.c
Interface                 INGRESS     240117    87539487   1132   bpf_host.c
Success                   EGRESS      106462    13960716   1308   bpf_lxc.c
Success                   EGRESS      11261     882071     53     encap.h
Success                   EGRESS      5823      451523     1694   bpf_host.c
Success                   INGRESS     118069    14625200   86     l3.h
Success                   INGRESS     123605    15058515   235    trace.h
Unsupported L3 protocol   EGRESS      36        2696       1492   bpf_lxc.c
