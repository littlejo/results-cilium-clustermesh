[
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5789c91_6daf_4ffc_9ff2_705404cb1d03.slice/cri-containerd-484f91659fa7b49952de64c29e23ff91ced8da6c5b0c40af1d558dcc1cc84efa.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5789c91_6daf_4ffc_9ff2_705404cb1d03.slice/cri-containerd-575a19094ba4d17abb7db8c6559a6ac499bdc98542f5b45d3180e814db60fa79.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5789c91_6daf_4ffc_9ff2_705404cb1d03.slice/cri-containerd-ae20204483ab2ead8500f66e7ac2c670274e862cadb0ec39818b042a51588891.scope"
      }
    ],
    "ips": [
      "10.41.0.30"
    ],
    "name": "clustermesh-apiserver-d9b79b9c-7rdw7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod44130845_4d84_455d_90d7_a528f906a984.slice/cri-containerd-98e01696b28789f0303ce270d80df90a9ab8ead8785de9fddbbbac3b8c377be0.scope"
      }
    ],
    "ips": [
      "10.41.0.113"
    ],
    "name": "coredns-cc6ccd49c-nz7jf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod21c8ef8c_ba91_42e0_9228_a1c9da8e6cad.slice/cri-containerd-d63669de1168d7093133263dcf4f01a17c3d4da1fc3b15130a32508bc7571128.scope"
      }
    ],
    "ips": [
      "10.41.0.225"
    ],
    "name": "coredns-cc6ccd49c-sdtfj",
    "namespace": "kube-system"
  }
]

