{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:09.356Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.203.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:09.356Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.249.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:09.356Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:13.629Z",
  "value": "id=364   sec_id=4     flags=0x0000 ifindex=10  mac=76:97:57:12:F6:87 nodemac=AE:29:6F:0A:12:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:13.632Z",
  "value": "id=387   sec_id=2754028 flags=0x0000 ifindex=12  mac=B6:C5:04:E3:8F:27 nodemac=2E:76:D4:C4:A3:0E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:13.667Z",
  "value": "id=364   sec_id=4     flags=0x0000 ifindex=10  mac=76:97:57:12:F6:87 nodemac=AE:29:6F:0A:12:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:13.669Z",
  "value": "id=387   sec_id=2754028 flags=0x0000 ifindex=12  mac=B6:C5:04:E3:8F:27 nodemac=2E:76:D4:C4:A3:0E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:13.706Z",
  "value": "id=3347  sec_id=2754028 flags=0x0000 ifindex=14  mac=02:D3:0D:BA:C3:02 nodemac=EE:A3:03:18:DD:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:25.901Z",
  "value": "id=3347  sec_id=2754028 flags=0x0000 ifindex=14  mac=02:D3:0D:BA:C3:02 nodemac=EE:A3:03:18:DD:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:25.901Z",
  "value": "id=364   sec_id=4     flags=0x0000 ifindex=10  mac=76:97:57:12:F6:87 nodemac=AE:29:6F:0A:12:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:25.902Z",
  "value": "id=387   sec_id=2754028 flags=0x0000 ifindex=12  mac=B6:C5:04:E3:8F:27 nodemac=2E:76:D4:C4:A3:0E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:25.927Z",
  "value": "id=2618  sec_id=2816506 flags=0x0000 ifindex=16  mac=DE:C3:73:4C:BC:40 nodemac=B6:E9:62:9D:21:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:25.927Z",
  "value": "id=2618  sec_id=2816506 flags=0x0000 ifindex=16  mac=DE:C3:73:4C:BC:40 nodemac=B6:E9:62:9D:21:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:26.896Z",
  "value": "id=364   sec_id=4     flags=0x0000 ifindex=10  mac=76:97:57:12:F6:87 nodemac=AE:29:6F:0A:12:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:26.896Z",
  "value": "id=2618  sec_id=2816506 flags=0x0000 ifindex=16  mac=DE:C3:73:4C:BC:40 nodemac=B6:E9:62:9D:21:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:26.896Z",
  "value": "id=3347  sec_id=2754028 flags=0x0000 ifindex=14  mac=02:D3:0D:BA:C3:02 nodemac=EE:A3:03:18:DD:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:26.896Z",
  "value": "id=387   sec_id=2754028 flags=0x0000 ifindex=12  mac=B6:C5:04:E3:8F:27 nodemac=2E:76:D4:C4:A3:0E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:11.690Z",
  "value": "id=86    sec_id=2816506 flags=0x0000 ifindex=18  mac=12:CF:7E:62:B8:A8 nodemac=A6:3F:3A:1B:13:AF"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.41.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:22.277Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:22.483Z",
  "value": "id=364   sec_id=4     flags=0x0000 ifindex=10  mac=76:97:57:12:F6:87 nodemac=AE:29:6F:0A:12:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:22.484Z",
  "value": "id=387   sec_id=2754028 flags=0x0000 ifindex=12  mac=B6:C5:04:E3:8F:27 nodemac=2E:76:D4:C4:A3:0E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:22.484Z",
  "value": "id=3347  sec_id=2754028 flags=0x0000 ifindex=14  mac=02:D3:0D:BA:C3:02 nodemac=EE:A3:03:18:DD:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:22.484Z",
  "value": "id=86    sec_id=2816506 flags=0x0000 ifindex=18  mac=12:CF:7E:62:B8:A8 nodemac=A6:3F:3A:1B:13:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:23.484Z",
  "value": "id=3347  sec_id=2754028 flags=0x0000 ifindex=14  mac=02:D3:0D:BA:C3:02 nodemac=EE:A3:03:18:DD:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:23.484Z",
  "value": "id=364   sec_id=4     flags=0x0000 ifindex=10  mac=76:97:57:12:F6:87 nodemac=AE:29:6F:0A:12:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:23.485Z",
  "value": "id=387   sec_id=2754028 flags=0x0000 ifindex=12  mac=B6:C5:04:E3:8F:27 nodemac=2E:76:D4:C4:A3:0E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:23.485Z",
  "value": "id=86    sec_id=2816506 flags=0x0000 ifindex=18  mac=12:CF:7E:62:B8:A8 nodemac=A6:3F:3A:1B:13:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:24.484Z",
  "value": "id=364   sec_id=4     flags=0x0000 ifindex=10  mac=76:97:57:12:F6:87 nodemac=AE:29:6F:0A:12:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:24.485Z",
  "value": "id=3347  sec_id=2754028 flags=0x0000 ifindex=14  mac=02:D3:0D:BA:C3:02 nodemac=EE:A3:03:18:DD:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:24.485Z",
  "value": "id=86    sec_id=2816506 flags=0x0000 ifindex=18  mac=12:CF:7E:62:B8:A8 nodemac=A6:3F:3A:1B:13:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:24.485Z",
  "value": "id=387   sec_id=2754028 flags=0x0000 ifindex=12  mac=B6:C5:04:E3:8F:27 nodemac=2E:76:D4:C4:A3:0E"
}

