key: 56 00 00 00  value: 6a 02 00 00
key: 6c 01 00 00  value: 29 02 00 00
key: 83 01 00 00  value: 18 02 00 00
key: 13 0d 00 00  value: 2b 02 00 00
Found 4 elements
