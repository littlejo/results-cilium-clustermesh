ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.209.184:443 (active)   
                                          2 => 172.31.157.209:443 (active)   
2    10.100.49.128:443     ClusterIP      1 => 172.31.249.77:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.41.0.113:53 (active)       
                                          2 => 10.41.0.225:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.41.0.113:9153 (active)     
                                          2 => 10.41.0.225:9153 (active)     
5    10.100.211.126:2379   ClusterIP      1 => 10.41.0.30:2379 (active)      
