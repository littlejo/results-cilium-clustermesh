filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc8071a33b7e1c direct-action not_in_hw id 551 tag 0b645770c4ef1347 jited 
