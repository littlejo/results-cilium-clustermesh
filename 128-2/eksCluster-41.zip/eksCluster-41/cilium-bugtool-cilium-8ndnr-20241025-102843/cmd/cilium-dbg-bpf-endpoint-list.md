IP ADDRESS         LOCAL ENDPOINT INFO
10.41.0.113:0      id=387   sec_id=2754028 flags=0x0000 ifindex=12  mac=B6:C5:04:E3:8F:27 nodemac=2E:76:D4:C4:A3:0E   
10.41.0.30:0       id=86    sec_id=2816506 flags=0x0000 ifindex=18  mac=12:CF:7E:62:B8:A8 nodemac=A6:3F:3A:1B:13:AF   
10.41.0.67:0       id=364   sec_id=4     flags=0x0000 ifindex=10  mac=76:97:57:12:F6:87 nodemac=AE:29:6F:0A:12:CC     
172.31.203.251:0   (localhost)                                                                                        
172.31.249.77:0    (localhost)                                                                                        
10.41.0.225:0      id=3347  sec_id=2754028 flags=0x0000 ifindex=14  mac=02:D3:0D:BA:C3:02 nodemac=EE:A3:03:18:DD:1F   
10.41.0.69:0       (localhost)                                                                                        
