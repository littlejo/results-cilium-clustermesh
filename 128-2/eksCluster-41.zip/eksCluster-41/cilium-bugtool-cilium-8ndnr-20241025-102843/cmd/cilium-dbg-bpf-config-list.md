KEY             VALUE
AgentLiveness   830919918846
UTimeOffset     3378615867187500
