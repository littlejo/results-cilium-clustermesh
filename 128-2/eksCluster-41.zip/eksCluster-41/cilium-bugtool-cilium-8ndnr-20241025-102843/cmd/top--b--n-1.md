top - 10:28:44 up 13 min,  0 users,  load average: 0.14, 0.17, 0.17
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s):  3.4 us, 27.6 sy,  0.0 ni, 69.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    784.2 free,    909.6 used,   2142.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2757.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    637 root      20   0 1240432  16792  11484 S   6.7   0.4   0:00.03 cilium-+
      1 root      20   0 1472752 279780  76792 S   0.0   7.1   0:22.10 cilium-+
    393 root      20   0 1228848   6912   3840 S   0.0   0.2   0:00.24 cilium-+
    624 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    668 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    686 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
