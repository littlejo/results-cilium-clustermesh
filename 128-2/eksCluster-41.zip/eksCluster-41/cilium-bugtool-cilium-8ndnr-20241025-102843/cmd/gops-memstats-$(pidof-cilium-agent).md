alloc: 69.63MB (73012744 bytes)
total-alloc: 1.44GB (1545848824 bytes)
sys: 206.63MB (216671572 bytes)
lookups: 0
mallocs: 49472972
frees: 48969012
heap-alloc: 69.63MB (73012744 bytes)
heap-sys: 161.60MB (169451520 bytes)
heap-idle: 40.65MB (42622976 bytes)
heap-in-use: 120.95MB (126828544 bytes)
heap-released: 608.00KB (622592 bytes)
heap-objects: 503960
stack-in-use: 34.38MB (36044800 bytes)
stack-sys: 34.38MB (36044800 bytes)
stack-mspan-inuse: 2.06MB (2164320 bytes)
stack-mspan-sys: 2.58MB (2709120 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.02MB (1070457 bytes)
gc-sys: 5.13MB (5374064 bytes)
next-gc: when heap-alloc >= 147.36MB (154518824 bytes)
last-gc: 2024-10-25 10:29:12.542763883 +0000 UTC
gc-pause-total: 11.92791ms
gc-pause: 110384
gc-pause-end: 1729852152542763883
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00045335734542473926
enable-gc: true
debug-gc: false
