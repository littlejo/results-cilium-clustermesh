CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod21c8ef8c_ba91_42e0_9228_a1c9da8e6cad.slice/cri-containerd-83abb04025bccf9f1b6d6e7864e6d3d864a5ebda4a4cc32cd1d8c0c519a0220a.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod21c8ef8c_ba91_42e0_9228_a1c9da8e6cad.slice/cri-containerd-d63669de1168d7093133263dcf4f01a17c3d4da1fc3b15130a32508bc7571128.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod300ab7a5_2f69_4083_aaa2_3f2198d43d3b.slice/cri-containerd-745eee0cea0410a56a8bfcab1e5739cb126392f1464973da0393316f9ec93ddf.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod300ab7a5_2f69_4083_aaa2_3f2198d43d3b.slice/cri-containerd-30791c311ca2627e29a5724350444637ddf079d579dcab59499dd743016d1cb2.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod89316ee6_7fff_42d3_a945_e244c7ce11a6.slice/cri-containerd-a1723ec4bf4f2ff9ff09f87cf08822689fe8dff5ce2ee40d1de0ecedd596f3a2.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod89316ee6_7fff_42d3_a945_e244c7ce11a6.slice/cri-containerd-8c224fb30dd3f06f80e913694395623d90b3321ec7c39178e0aa426bee0ad0b4.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod44130845_4d84_455d_90d7_a528f906a984.slice/cri-containerd-98e01696b28789f0303ce270d80df90a9ab8ead8785de9fddbbbac3b8c377be0.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod44130845_4d84_455d_90d7_a528f906a984.slice/cri-containerd-343b25f98a9209578a6c8f4914add9f3157f4a94c4a7efc8cfd58917d61b73cc.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a5e198a_42a4_480d_970c_4da0cee24c4b.slice/cri-containerd-8f43e3670d897d858d8e3a8c1a7914218bc3ae9de29d7d51623308a7997f7a35.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a5e198a_42a4_480d_970c_4da0cee24c4b.slice/cri-containerd-6b02f7b60a9b5205390fa319eb4b6fcf1df28ebc32bc49a2322e8bf3913d8347.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5789c91_6daf_4ffc_9ff2_705404cb1d03.slice/cri-containerd-575a19094ba4d17abb7db8c6559a6ac499bdc98542f5b45d3180e814db60fa79.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5789c91_6daf_4ffc_9ff2_705404cb1d03.slice/cri-containerd-ae20204483ab2ead8500f66e7ac2c670274e862cadb0ec39818b042a51588891.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5789c91_6daf_4ffc_9ff2_705404cb1d03.slice/cri-containerd-fab9c91bc2647b0e56a239a9d50f0a63df93545813807f9fe7d8d2e21aeda103.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5789c91_6daf_4ffc_9ff2_705404cb1d03.slice/cri-containerd-484f91659fa7b49952de64c29e23ff91ced8da6c5b0c40af1d558dcc1cc84efa.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod220f8e32_fe92_4fa6_876a_c5b52d1efb37.slice/cri-containerd-edf0966f85361c71f8c467059aebfc3a9df04fb2a61232926bfe968c674c434f.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod220f8e32_fe92_4fa6_876a_c5b52d1efb37.slice/cri-containerd-a801e89145d564a491fa8db93604187970f81695c28406ed9e35c8d93742e4bf.scope
    101      cgroup_device   multi                                          
