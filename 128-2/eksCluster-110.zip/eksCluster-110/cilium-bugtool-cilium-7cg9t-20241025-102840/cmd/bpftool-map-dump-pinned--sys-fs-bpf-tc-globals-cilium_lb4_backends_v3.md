key: 09 00 00 00  value: 0a 6e 00 0f 23 c1 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 6e 00 0f 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f 98 6d 10 94 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f 92 9c 01 bb 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 6e 00 ac 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 6e 00 ac 00 35 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 6e 00 f3 09 4b 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f e8 0b 01 bb 00 00  00 00 00 00
Found 8 elements
