Endpoint ID: 904
Path: /sys/fs/bpf/tc/globals/cilium_policy_00904

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    71719   825       0        
Allow    Egress      0          ANY          NONE         disabled    12554   128       0        


Endpoint ID: 1111
Path: /sys/fs/bpf/tc/globals/cilium_policy_01111

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    390804   4985      0        
Allow    Ingress     1          ANY          NONE         disabled    10460    122       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2039
Path: /sys/fs/bpf/tc/globals/cilium_policy_02039

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2211
Path: /sys/fs/bpf/tc/globals/cilium_policy_02211

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    71338   817       0        
Allow    Egress      0          ANY          NONE         disabled    12897   132       0        


Endpoint ID: 2590
Path: /sys/fs/bpf/tc/globals/cilium_policy_02590

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3300217   30919     0        
Allow    Ingress     1          ANY          NONE         disabled    2601104   25757     0        
Allow    Egress      0          ANY          NONE         disabled    2765885   27338     0        


