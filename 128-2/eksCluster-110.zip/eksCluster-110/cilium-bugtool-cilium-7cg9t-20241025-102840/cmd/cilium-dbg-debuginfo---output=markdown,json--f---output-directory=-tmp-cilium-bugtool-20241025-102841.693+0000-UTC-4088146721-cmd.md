markdown output at /tmp/cilium-bugtool-20241025-102841.693+0000-UTC-4088146721/cmd/cilium-debuginfo-20241025-102842.545+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102841.693+0000-UTC-4088146721/cmd/cilium-debuginfo-20241025-102842.545+0000-UTC.json
