ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.232.11:443 (active)     
                                        2 => 172.31.146.156:443 (active)    
2    10.100.69.95:443    ClusterIP      1 => 172.31.152.109:4244 (active)   
3    10.100.0.10:9153    ClusterIP      1 => 10.110.0.172:9153 (active)     
                                        2 => 10.110.0.15:9153 (active)      
4    10.100.0.10:53      ClusterIP      1 => 10.110.0.172:53 (active)       
                                        2 => 10.110.0.15:53 (active)        
5    10.100.188.0:2379   ClusterIP      1 => 10.110.0.243:2379 (active)     
