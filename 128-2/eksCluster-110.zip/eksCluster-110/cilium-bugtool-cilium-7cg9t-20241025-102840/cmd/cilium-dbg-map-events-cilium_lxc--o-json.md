{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:56.893Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.148.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:56.893Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.152.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:56.893Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:01.548Z",
  "value": "id=904   sec_id=7318862 flags=0x0000 ifindex=12  mac=2A:51:AD:46:DD:1A nodemac=36:D2:8C:55:15:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:01.552Z",
  "value": "id=1111  sec_id=4     flags=0x0000 ifindex=10  mac=D2:A9:83:D6:1B:0D nodemac=96:AD:04:70:3C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:01.637Z",
  "value": "id=2211  sec_id=7318862 flags=0x0000 ifindex=14  mac=A6:93:82:F9:1C:6A nodemac=02:D8:5A:3B:36:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:01.677Z",
  "value": "id=904   sec_id=7318862 flags=0x0000 ifindex=12  mac=2A:51:AD:46:DD:1A nodemac=36:D2:8C:55:15:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:01.726Z",
  "value": "id=1111  sec_id=4     flags=0x0000 ifindex=10  mac=D2:A9:83:D6:1B:0D nodemac=96:AD:04:70:3C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:35.876Z",
  "value": "id=1111  sec_id=4     flags=0x0000 ifindex=10  mac=D2:A9:83:D6:1B:0D nodemac=96:AD:04:70:3C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:35.877Z",
  "value": "id=904   sec_id=7318862 flags=0x0000 ifindex=12  mac=2A:51:AD:46:DD:1A nodemac=36:D2:8C:55:15:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:35.877Z",
  "value": "id=2211  sec_id=7318862 flags=0x0000 ifindex=14  mac=A6:93:82:F9:1C:6A nodemac=02:D8:5A:3B:36:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:35.908Z",
  "value": "id=478   sec_id=7307047 flags=0x0000 ifindex=16  mac=EE:1F:CD:DD:A1:BE nodemac=72:7A:97:90:D0:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:36.877Z",
  "value": "id=1111  sec_id=4     flags=0x0000 ifindex=10  mac=D2:A9:83:D6:1B:0D nodemac=96:AD:04:70:3C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:36.877Z",
  "value": "id=478   sec_id=7307047 flags=0x0000 ifindex=16  mac=EE:1F:CD:DD:A1:BE nodemac=72:7A:97:90:D0:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:36.877Z",
  "value": "id=904   sec_id=7318862 flags=0x0000 ifindex=12  mac=2A:51:AD:46:DD:1A nodemac=36:D2:8C:55:15:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:36.878Z",
  "value": "id=2211  sec_id=7318862 flags=0x0000 ifindex=14  mac=A6:93:82:F9:1C:6A nodemac=02:D8:5A:3B:36:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:13.562Z",
  "value": "id=2590  sec_id=7307047 flags=0x0000 ifindex=18  mac=12:1F:45:9D:EB:01 nodemac=C2:39:8A:9B:EF:74"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.110.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:19.787Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:36.475Z",
  "value": "id=2211  sec_id=7318862 flags=0x0000 ifindex=14  mac=A6:93:82:F9:1C:6A nodemac=02:D8:5A:3B:36:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:36.476Z",
  "value": "id=2590  sec_id=7307047 flags=0x0000 ifindex=18  mac=12:1F:45:9D:EB:01 nodemac=C2:39:8A:9B:EF:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:36.477Z",
  "value": "id=1111  sec_id=4     flags=0x0000 ifindex=10  mac=D2:A9:83:D6:1B:0D nodemac=96:AD:04:70:3C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:36.477Z",
  "value": "id=904   sec_id=7318862 flags=0x0000 ifindex=12  mac=2A:51:AD:46:DD:1A nodemac=36:D2:8C:55:15:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:37.467Z",
  "value": "id=2211  sec_id=7318862 flags=0x0000 ifindex=14  mac=A6:93:82:F9:1C:6A nodemac=02:D8:5A:3B:36:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:37.467Z",
  "value": "id=2590  sec_id=7307047 flags=0x0000 ifindex=18  mac=12:1F:45:9D:EB:01 nodemac=C2:39:8A:9B:EF:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:37.467Z",
  "value": "id=1111  sec_id=4     flags=0x0000 ifindex=10  mac=D2:A9:83:D6:1B:0D nodemac=96:AD:04:70:3C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:37.468Z",
  "value": "id=904   sec_id=7318862 flags=0x0000 ifindex=12  mac=2A:51:AD:46:DD:1A nodemac=36:D2:8C:55:15:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:38.467Z",
  "value": "id=1111  sec_id=4     flags=0x0000 ifindex=10  mac=D2:A9:83:D6:1B:0D nodemac=96:AD:04:70:3C:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:38.467Z",
  "value": "id=2590  sec_id=7307047 flags=0x0000 ifindex=18  mac=12:1F:45:9D:EB:01 nodemac=C2:39:8A:9B:EF:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:38.467Z",
  "value": "id=904   sec_id=7318862 flags=0x0000 ifindex=12  mac=2A:51:AD:46:DD:1A nodemac=36:D2:8C:55:15:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:38.468Z",
  "value": "id=2211  sec_id=7318862 flags=0x0000 ifindex=14  mac=A6:93:82:F9:1C:6A nodemac=02:D8:5A:3B:36:A8"
}

