Node 0, zone      DMA      2      3      2      3      0      2      3      2      4      2    177 
Node 0, zone   Normal     93     12      5     10     17      7      3      3      1      0      9 
