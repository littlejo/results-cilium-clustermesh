1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:32:92:47:93:5d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.152.109/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2749sec preferred_lft 2749sec
    inet6 fe80::432:92ff:fe47:935d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:8e:c1:a1:cc:c7 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.148.220/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::48e:c1ff:fea1:ccc7/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:35:83:c7:a7:7d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2035:83ff:fec7:a77d/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:7f:b6:71:68:88 brd ff:ff:ff:ff:ff:ff
    inet 10.110.0.39/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::847f:b6ff:fe71:6888/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 22:36:e2:af:e3:dd brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2036:e2ff:feaf:e3dd/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:ad:04:70:3c:74 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::94ad:4ff:fe70:3c74/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcb0b6b3541eb8@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:d2:8c:55:15:68 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::34d2:8cff:fe55:1568/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc994ea69cdd38@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:d8:5a:3b:36:a8 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d8:5aff:fe3b:36a8/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc5f96cc0de22f@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:39:8a:9b:ef:74 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c039:8aff:fe9b:ef74/64 scope link 
       valid_lft forever preferred_lft forever
