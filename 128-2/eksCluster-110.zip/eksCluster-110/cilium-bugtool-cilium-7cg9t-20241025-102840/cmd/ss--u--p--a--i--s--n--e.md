Total: 567
TCP:   1084 (estab 304, closed 761, orphaned 0, timewait 291)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  323       314       9        
INET	  333       320       13       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                  172.31.152.109%ens5:68         0.0.0.0:*    uid:192 ino:15058 sk:1001 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:25301 sk:1002 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:14880 sk:1003 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:35587      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=41)) ino:24225 sk:1004 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:25300 sk:1005 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:14881 sk:1006 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::432:92ff:fe47:935d]%ens5:546           [::]:*    uid:192 ino:15056 sk:1007 cgroup:unreachable:c4e v6only:1 <->                   
