IP ADDRESS         LOCAL ENDPOINT INFO
10.110.0.73:0      id=1111  sec_id=4     flags=0x0000 ifindex=10  mac=D2:A9:83:D6:1B:0D nodemac=96:AD:04:70:3C:74     
10.110.0.39:0      (localhost)                                                                                        
10.110.0.15:0      id=904   sec_id=7318862 flags=0x0000 ifindex=12  mac=2A:51:AD:46:DD:1A nodemac=36:D2:8C:55:15:68   
172.31.152.109:0   (localhost)                                                                                        
10.110.0.243:0     id=2590  sec_id=7307047 flags=0x0000 ifindex=18  mac=12:1F:45:9D:EB:01 nodemac=C2:39:8A:9B:EF:74   
172.31.148.220:0   (localhost)                                                                                        
10.110.0.172:0     id=2211  sec_id=7318862 flags=0x0000 ifindex=14  mac=A6:93:82:F9:1C:6A nodemac=02:D8:5A:3B:36:A8   
