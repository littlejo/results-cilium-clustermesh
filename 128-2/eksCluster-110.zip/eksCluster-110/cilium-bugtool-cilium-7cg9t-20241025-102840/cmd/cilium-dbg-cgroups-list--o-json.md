[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd6c20034_525d_41e2_9cb9_fe46375f070f.slice/cri-containerd-176bb02aa2ff886ebee60c8b52f0641daf74d996f0b34d9c6a6c3df443383861.scope"
      }
    ],
    "ips": [
      "10.110.0.172"
    ],
    "name": "coredns-cc6ccd49c-z6gpf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod09e0c332_8ace_4088_8226_1f3efa9b3fbb.slice/cri-containerd-9f77c26d616ad01333772f2e9d29adf828072dfdac963000e50f86cba3ad463e.scope"
      }
    ],
    "ips": [
      "10.110.0.15"
    ],
    "name": "coredns-cc6ccd49c-7lp8l",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfc699322_9a30_41cd_ba52_35eefa8a4812.slice/cri-containerd-5502a00223748c8156237a2d76ebef0a50cda0c1087c86492c7767606263cf3a.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfc699322_9a30_41cd_ba52_35eefa8a4812.slice/cri-containerd-ac63645ac4b9141598d53f92deacf0da515f91f2f884af901e0c663156be03f9.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfc699322_9a30_41cd_ba52_35eefa8a4812.slice/cri-containerd-8ae3ce4a181128f7b496e133bb7d0146e54b3d35539e1e6931baa8749708c186.scope"
      }
    ],
    "ips": [
      "10.110.0.243"
    ],
    "name": "clustermesh-apiserver-b49584847-6cvm5",
    "namespace": "kube-system"
  }
]

