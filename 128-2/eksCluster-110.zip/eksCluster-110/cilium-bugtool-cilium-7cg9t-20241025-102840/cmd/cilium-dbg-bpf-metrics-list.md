REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     180563    79649773   1132   bpf_host.c
Interface                 INGRESS     8193      638906     677    bpf_overlay.c
Success                   EGRESS      3902      295464     1694   bpf_host.c
Success                   EGRESS      75489     10217694   1308   bpf_lxc.c
Success                   EGRESS      7901      617336     53     encap.h
Success                   INGRESS     85984     10122414   86     l3.h
Success                   INGRESS     90924     10509762   235    trace.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
