CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3b62b983_3684_44b7_8242_4cfdf9b6396b.slice/cri-containerd-a033f1d613e2d883726c5cc10a881e630487071cd4f45d7405b7eebab14dd42a.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3b62b983_3684_44b7_8242_4cfdf9b6396b.slice/cri-containerd-1b1c9368751304b896fea4b63dd66c8fd2a0d772d06024e93a8735b09cd6785c.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd402334c_6b06_42e4_93f2_ac8ca5a7eb6d.slice/cri-containerd-f43e658765a755c1d512f934f230f2ccb848ff214441621ef76659c340b6a74f.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd402334c_6b06_42e4_93f2_ac8ca5a7eb6d.slice/cri-containerd-fba620f75db756ced42d4ef14cf35751d2c0eff66ef02dc39c5f33c998b19cbc.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod09e0c332_8ace_4088_8226_1f3efa9b3fbb.slice/cri-containerd-f634d50bb08ff8c31dfaaf1ecbadd54815305e0f26c1194f83dd13abfedd3fdb.scope
    520      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod09e0c332_8ace_4088_8226_1f3efa9b3fbb.slice/cri-containerd-9f77c26d616ad01333772f2e9d29adf828072dfdac963000e50f86cba3ad463e.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd6c20034_525d_41e2_9cb9_fe46375f070f.slice/cri-containerd-2ee86fa999c97c941b4514c55d51d05d3eef23c0b90b757db9a5264d495afdd3.scope
    547      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd6c20034_525d_41e2_9cb9_fe46375f070f.slice/cri-containerd-176bb02aa2ff886ebee60c8b52f0641daf74d996f0b34d9c6a6c3df443383861.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd2d19e65_bcdd_4acc_bc05_c4b36ca1a8ed.slice/cri-containerd-788df47e0040bb09904835f9c4085996b8c450ecd65663908f5c43562705839c.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd2d19e65_bcdd_4acc_bc05_c4b36ca1a8ed.slice/cri-containerd-5e9dc19bd8fb7ae9ce524a16244fa1c04123f49025d09feb5fe67657131bbc2a.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfc699322_9a30_41cd_ba52_35eefa8a4812.slice/cri-containerd-b411681c02947385cbac2a14ce8b56c008738902539814c3e6e4f6658ac8f8a0.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfc699322_9a30_41cd_ba52_35eefa8a4812.slice/cri-containerd-5502a00223748c8156237a2d76ebef0a50cda0c1087c86492c7767606263cf3a.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfc699322_9a30_41cd_ba52_35eefa8a4812.slice/cri-containerd-8ae3ce4a181128f7b496e133bb7d0146e54b3d35539e1e6931baa8749708c186.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfc699322_9a30_41cd_ba52_35eefa8a4812.slice/cri-containerd-ac63645ac4b9141598d53f92deacf0da515f91f2f884af901e0c663156be03f9.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57b4500d_8bd9_4207_ac52_7648df6ebea0.slice/cri-containerd-ea199d9b32a0ebda0848f554560cd82da26a5954b69f324931729bc1c39b21d7.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod57b4500d_8bd9_4207_ac52_7648df6ebea0.slice/cri-containerd-1c19abc91e7fb8b1d25cbf6914985bcfcc8849086aaa7f954e01aae4d3515784.scope
    98       cgroup_device   multi                                          
