key: 88 03 00 00  value: 0a 02 00 00
key: 57 04 00 00  value: 16 02 00 00
key: a3 08 00 00  value: 01 02 00 00
key: 1e 0a 00 00  value: 74 02 00 00
Found 4 elements
