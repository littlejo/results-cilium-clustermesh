alloc: 102.20MB (107164784 bytes)
total-alloc: 1.25GB (1342491072 bytes)
sys: 202.38MB (212212036 bytes)
lookups: 0
mallocs: 46519270
frees: 45485064
heap-alloc: 102.20MB (107164784 bytes)
heap-sys: 157.51MB (165158912 bytes)
heap-idle: 35.88MB (37617664 bytes)
heap-in-use: 121.63MB (127541248 bytes)
heap-released: 1.44MB (1507328 bytes)
heap-objects: 1034206
stack-in-use: 34.47MB (36143104 bytes)
stack-sys: 34.47MB (36143104 bytes)
stack-mspan-inuse: 1.99MB (2082080 bytes)
stack-mspan-sys: 2.44MB (2562240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 910.39KB (932241 bytes)
gc-sys: 5.15MB (5401912 bytes)
next-gc: when heap-alloc >= 142.99MB (149933256 bytes)
last-gc: 2024-10-25 10:27:59.548392208 +0000 UTC
gc-pause-total: 7.207896ms
gc-pause: 89438
gc-pause-end: 1729852079548392208
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.0003527606115231018
enable-gc: true
debug-gc: false
