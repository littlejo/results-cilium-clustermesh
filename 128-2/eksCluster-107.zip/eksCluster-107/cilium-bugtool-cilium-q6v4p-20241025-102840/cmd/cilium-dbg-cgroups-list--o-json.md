[
  {
    "containers": [
      {
        "cgroup-id": 7026,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod440c38ab_c866_4cc5_9812_8fe659b83af5.slice/cri-containerd-1c19296682158d94c4c3a437cabc5cdbc1c9b620ce9c4511b9c9c7a542ec771b.scope"
      }
    ],
    "ips": [
      "10.107.0.165"
    ],
    "name": "coredns-cc6ccd49c-ks5k9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7110,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode9f85011_dada_420c_a9b4_5c6ca3885ca0.slice/cri-containerd-362906ab376debac19066431f17b8801f10e75f8130bbea24f6b97f310cbe527.scope"
      }
    ],
    "ips": [
      "10.107.0.235"
    ],
    "name": "coredns-cc6ccd49c-tsptq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8538,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf376e5e7_e478_470f_8e37_c3f76e19f95a.slice/cri-containerd-c0efda791b443e2d42dd3259e193d83bf55233598e901d66a432ed5aec74465e.scope"
      },
      {
        "cgroup-id": 8454,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf376e5e7_e478_470f_8e37_c3f76e19f95a.slice/cri-containerd-98d3c67bcf048065c5c6640d0a110167be048a5e09fa59098fe03936b83845db.scope"
      },
      {
        "cgroup-id": 8622,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf376e5e7_e478_470f_8e37_c3f76e19f95a.slice/cri-containerd-b3d677a4ae4c9356cf68cfd2d25b0f352bf8a8ef2c4e5d1ca9807ba9d0f78a2b.scope"
      }
    ],
    "ips": [
      "10.107.0.220"
    ],
    "name": "clustermesh-apiserver-d7bcff55b-w2q6b",
    "namespace": "kube-system"
  }
]

