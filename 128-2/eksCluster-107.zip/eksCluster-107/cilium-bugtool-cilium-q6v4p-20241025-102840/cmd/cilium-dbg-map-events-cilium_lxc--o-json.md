{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:53.939Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.238.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:53.939Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:58.198Z",
  "value": "id=331   sec_id=7085474 flags=0x0000 ifindex=9   mac=7A:1D:4F:B6:64:39 nodemac=EE:08:FD:8E:51:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:58.201Z",
  "value": "id=3720  sec_id=4     flags=0x0000 ifindex=7   mac=B2:52:01:85:7D:09 nodemac=12:19:6F:B5:0D:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:58.202Z",
  "value": "id=331   sec_id=7085474 flags=0x0000 ifindex=9   mac=7A:1D:4F:B6:64:39 nodemac=EE:08:FD:8E:51:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:58.236Z",
  "value": "id=3720  sec_id=4     flags=0x0000 ifindex=7   mac=B2:52:01:85:7D:09 nodemac=12:19:6F:B5:0D:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:58.244Z",
  "value": "id=80    sec_id=7085474 flags=0x0000 ifindex=11  mac=62:70:BB:8A:A3:5A nodemac=BE:73:B5:4D:3C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:29.923Z",
  "value": "id=331   sec_id=7085474 flags=0x0000 ifindex=9   mac=7A:1D:4F:B6:64:39 nodemac=EE:08:FD:8E:51:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:29.924Z",
  "value": "id=80    sec_id=7085474 flags=0x0000 ifindex=11  mac=62:70:BB:8A:A3:5A nodemac=BE:73:B5:4D:3C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:29.924Z",
  "value": "id=3720  sec_id=4     flags=0x0000 ifindex=7   mac=B2:52:01:85:7D:09 nodemac=12:19:6F:B5:0D:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:29.953Z",
  "value": "id=713   sec_id=7117408 flags=0x0000 ifindex=13  mac=8A:D5:B8:F0:C4:B3 nodemac=D2:93:2B:16:2D:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:30.924Z",
  "value": "id=713   sec_id=7117408 flags=0x0000 ifindex=13  mac=8A:D5:B8:F0:C4:B3 nodemac=D2:93:2B:16:2D:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:30.924Z",
  "value": "id=3720  sec_id=4     flags=0x0000 ifindex=7   mac=B2:52:01:85:7D:09 nodemac=12:19:6F:B5:0D:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:30.924Z",
  "value": "id=80    sec_id=7085474 flags=0x0000 ifindex=11  mac=62:70:BB:8A:A3:5A nodemac=BE:73:B5:4D:3C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:30.925Z",
  "value": "id=331   sec_id=7085474 flags=0x0000 ifindex=9   mac=7A:1D:4F:B6:64:39 nodemac=EE:08:FD:8E:51:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:27.371Z",
  "value": "id=309   sec_id=7117408 flags=0x0000 ifindex=15  mac=86:03:2E:58:BA:14 nodemac=82:15:BD:BF:60:BD"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.107.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:37.562Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.940Z",
  "value": "id=3720  sec_id=4     flags=0x0000 ifindex=7   mac=B2:52:01:85:7D:09 nodemac=12:19:6F:B5:0D:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.941Z",
  "value": "id=331   sec_id=7085474 flags=0x0000 ifindex=9   mac=7A:1D:4F:B6:64:39 nodemac=EE:08:FD:8E:51:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.941Z",
  "value": "id=80    sec_id=7085474 flags=0x0000 ifindex=11  mac=62:70:BB:8A:A3:5A nodemac=BE:73:B5:4D:3C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.941Z",
  "value": "id=309   sec_id=7117408 flags=0x0000 ifindex=15  mac=86:03:2E:58:BA:14 nodemac=82:15:BD:BF:60:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.940Z",
  "value": "id=309   sec_id=7117408 flags=0x0000 ifindex=15  mac=86:03:2E:58:BA:14 nodemac=82:15:BD:BF:60:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.941Z",
  "value": "id=3720  sec_id=4     flags=0x0000 ifindex=7   mac=B2:52:01:85:7D:09 nodemac=12:19:6F:B5:0D:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.941Z",
  "value": "id=331   sec_id=7085474 flags=0x0000 ifindex=9   mac=7A:1D:4F:B6:64:39 nodemac=EE:08:FD:8E:51:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.941Z",
  "value": "id=80    sec_id=7085474 flags=0x0000 ifindex=11  mac=62:70:BB:8A:A3:5A nodemac=BE:73:B5:4D:3C:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:03.941Z",
  "value": "id=309   sec_id=7117408 flags=0x0000 ifindex=15  mac=86:03:2E:58:BA:14 nodemac=82:15:BD:BF:60:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:03.941Z",
  "value": "id=3720  sec_id=4     flags=0x0000 ifindex=7   mac=B2:52:01:85:7D:09 nodemac=12:19:6F:B5:0D:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:03.942Z",
  "value": "id=331   sec_id=7085474 flags=0x0000 ifindex=9   mac=7A:1D:4F:B6:64:39 nodemac=EE:08:FD:8E:51:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:03.942Z",
  "value": "id=80    sec_id=7085474 flags=0x0000 ifindex=11  mac=62:70:BB:8A:A3:5A nodemac=BE:73:B5:4D:3C:02"
}

