29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:07+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:07+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:07+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:07+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:07+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:13+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
61: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
64: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
69: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
72: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
73: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
76: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
77: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
80: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
104: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
107: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
448: sched_cls  name tail_handle_ipv4  tag 4a3a5055cd364307  gpl
	loaded_at 2024-10-25T10:13:55+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 69,68,75,70,91
	btf_id 112
449: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:55+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 70,91
	btf_id 113
450: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:55+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 114
451: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:55+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 115
452: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 70,69,93
	btf_id 117
454: sched_cls  name __send_drop_notify  tag 7174c653712d3dc9  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 119
455: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 120
457: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,93
	btf_id 122
458: sched_cls  name tail_handle_ipv4_from_host  tag 6ae1c810679d020f  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,93
	btf_id 123
459: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 125
461: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,95
	btf_id 127
462: sched_cls  name tail_handle_ipv4_from_host  tag 6ae1c810679d020f  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,95
	btf_id 128
465: sched_cls  name __send_drop_notify  tag 7174c653712d3dc9  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 131
468: sched_cls  name __send_drop_notify  tag 7174c653712d3dc9  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 135
470: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 70,98,69
	btf_id 137
471: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,98
	btf_id 138
472: sched_cls  name tail_handle_ipv4_from_host  tag 6ae1c810679d020f  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,98
	btf_id 139
473: sched_cls  name cil_from_container  tag d94d39a404004acd  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 103,70
	btf_id 143
474: sched_cls  name tail_handle_ipv4_cont  tag 3c4bb587fffc0a5e  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,102,35,99,76,77,33,70,68,71,103,34,31,32,75
	btf_id 144
477: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,103
	btf_id 147
480: sched_cls  name handle_policy  tag fd6b54a90f516fe9  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,103,76,77,102,35,74,99,33,78,69,34,31,32
	btf_id 148
481: sched_cls  name tail_handle_arp  tag e8feb7217a5d662b  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,103
	btf_id 151
485: sched_cls  name tail_ipv4_ct_egress  tag f2a7446690e240f6  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,103,76,77,102,78
	btf_id 152
486: sched_cls  name __send_drop_notify  tag dfa7ffc3d9141638  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 156
488: sched_cls  name tail_ipv4_to_endpoint  tag 66d5f086692131b6  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,102,35,76,77,74,99,33,103,34,31,32
	btf_id 157
489: sched_cls  name tail_handle_ipv4  tag 44b6c772d7eddfc2  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,103
	btf_id 159
492: sched_cls  name tail_ipv4_ct_ingress  tag d7c5214227dfcab3  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,103,76,77,102,78
	btf_id 160
495: sched_cls  name tail_handle_arp  tag 5e58f4e9991be73c  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,107
	btf_id 167
496: sched_cls  name tail_ipv4_ct_ingress  tag 111a4096e36c0477  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 70,106,76,77,105,78
	btf_id 165
497: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,106
	btf_id 169
498: sched_cls  name tail_handle_ipv4  tag 84b6a11d81f4e244  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,107
	btf_id 168
499: sched_cls  name tail_handle_ipv4_cont  tag 104fd3a67638f3de  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 69,105,35,92,76,77,33,70,68,71,106,34,31,32,75
	btf_id 170
500: sched_cls  name tail_ipv4_ct_ingress  tag 0ed6db3b8013e7c9  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,107,76,77,108,78
	btf_id 171
501: sched_cls  name cil_from_container  tag f0b9700438a87ecd  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 107,70
	btf_id 173
502: sched_cls  name __send_drop_notify  tag d36f43d370cdcf8e  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 174
503: sched_cls  name tail_ipv4_to_endpoint  tag 9fcef5b570d278dd  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 69,70,105,35,76,77,74,92,33,106,34,31,32
	btf_id 172
504: sched_cls  name tail_ipv4_to_endpoint  tag 8b221d06a450e9ad  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,108,35,76,77,74,104,33,107,34,31,32
	btf_id 175
505: sched_cls  name handle_policy  tag bb8f38450f9b6cc4  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 70,106,76,77,105,35,74,92,33,78,69,34,31,32
	btf_id 176
507: sched_cls  name __send_drop_notify  tag e35ad554dd745a01  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 179
508: sched_cls  name cil_from_container  tag 1016fc7768722a74  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 106,70
	btf_id 180
509: sched_cls  name tail_handle_arp  tag 441b78f79480096d  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,106
	btf_id 181
510: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 70,106,76,77,105,78
	btf_id 182
511: sched_cls  name handle_policy  tag d980f916a9071888  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,107,76,77,108,35,74,104,33,78,69,34,31,32
	btf_id 177
512: sched_cls  name tail_handle_ipv4  tag 972ba9b11da18546  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,106
	btf_id 183
513: sched_cls  name tail_handle_ipv4_cont  tag b3eba9822bf6de6e  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,108,35,104,76,77,33,70,68,71,107,34,31,32,75
	btf_id 184
514: sched_cls  name tail_ipv4_ct_egress  tag f2a7446690e240f6  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,107,76,77,108,78
	btf_id 185
516: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,107
	btf_id 187
517: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
520: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
521: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
524: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
525: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
528: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
529: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
532: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
572: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,125
	btf_id 203
573: sched_cls  name __send_drop_notify  tag f6734028520deab3  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 204
574: sched_cls  name tail_handle_ipv4_cont  tag bc22b436544e7ae9  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,124,35,123,76,77,33,70,68,71,125,34,31,32,75
	btf_id 205
575: sched_cls  name cil_from_container  tag d1eab8ae1ac9e534  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 125,70
	btf_id 206
577: sched_cls  name tail_ipv4_ct_egress  tag c7d4d469a171b917  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,125,76,77,124,78
	btf_id 208
578: sched_cls  name tail_handle_ipv4  tag 102061619d6aed68  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,125
	btf_id 209
579: sched_cls  name tail_ipv4_to_endpoint  tag d40def371bfcf410  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,124,35,76,77,74,123,33,125,34,31,32
	btf_id 210
580: sched_cls  name handle_policy  tag cef4ea903c63bba4  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,125,76,77,124,35,74,123,33,78,69,34,31,32
	btf_id 211
581: sched_cls  name tail_handle_arp  tag 9083034532cde2f2  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,125
	btf_id 212
582: sched_cls  name tail_ipv4_ct_ingress  tag 08332039308bf84a  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,125,76,77,124,78
	btf_id 213
583: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
586: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
599: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
602: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
603: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
606: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
607: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
610: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
