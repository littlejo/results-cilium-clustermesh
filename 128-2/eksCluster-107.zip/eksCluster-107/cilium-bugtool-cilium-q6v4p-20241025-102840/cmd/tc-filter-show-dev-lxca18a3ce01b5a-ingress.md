filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxca18a3ce01b5a direct-action not_in_hw id 473 tag d94d39a404004acd jited 
