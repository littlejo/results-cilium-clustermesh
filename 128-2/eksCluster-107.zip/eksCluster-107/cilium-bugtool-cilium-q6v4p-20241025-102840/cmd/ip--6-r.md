fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxca18a3ce01b5a proto kernel metric 256 pref medium
fe80::/64 dev lxcba2de8b8a3f7 proto kernel metric 256 pref medium
fe80::/64 dev lxc6ecc2ea36041 proto kernel metric 256 pref medium
