Endpoint ID: 80
Path: /sys/fs/bpf/tc/globals/cilium_policy_00080

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    87023   999       0        
Allow    Egress      0          ANY          NONE         disabled    14582   153       0        


Endpoint ID: 309
Path: /sys/fs/bpf/tc/globals/cilium_policy_00309

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3824361   36411     0        
Allow    Ingress     1          ANY          NONE         disabled    3369665   34330     0        
Allow    Egress      0          ANY          NONE         disabled    5196810   47742     0        


Endpoint ID: 331
Path: /sys/fs/bpf/tc/globals/cilium_policy_00331

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    86319   990       0        
Allow    Egress      0          ANY          NONE         disabled    14113   148       0        


Endpoint ID: 646
Path: /sys/fs/bpf/tc/globals/cilium_policy_00646

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3720
Path: /sys/fs/bpf/tc/globals/cilium_policy_03720

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    432674   5511      0        
Allow    Ingress     1          ANY          NONE         disabled    12868    149       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


