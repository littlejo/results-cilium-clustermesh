filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcba2de8b8a3f7 direct-action not_in_hw id 501 tag f0b9700438a87ecd jited 
