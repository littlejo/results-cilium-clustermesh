key: 50 00 00 00  value: ff 01 00 00
key: 35 01 00 00  value: 44 02 00 00
key: 4b 01 00 00  value: e0 01 00 00
key: 88 0e 00 00  value: f9 01 00 00
Found 4 elements
