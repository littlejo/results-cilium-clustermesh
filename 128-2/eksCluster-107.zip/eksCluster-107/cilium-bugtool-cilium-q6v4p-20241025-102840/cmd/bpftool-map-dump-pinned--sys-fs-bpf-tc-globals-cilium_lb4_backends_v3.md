key: 04 00 00 00  value: 0a 6b 00 eb 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: 0a 6b 00 a5 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 6b 00 dc 09 4b 00 00  00 00 00 00
key: 03 00 00 00  value: 0a 6b 00 eb 00 35 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 6b 00 a5 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f ee b7 10 94 00 00  00 00 00 00
key: 07 00 00 00  value: ac 1f c5 44 01 bb 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f b6 bd 01 bb 00 00  00 00 00 00
Found 8 elements
