IP ADDRESS         LOCAL ENDPOINT INFO
172.31.238.183:0   (localhost)                                                                                        
10.107.0.111:0     (localhost)                                                                                        
10.107.0.109:0     id=3720  sec_id=4     flags=0x0000 ifindex=7   mac=B2:52:01:85:7D:09 nodemac=12:19:6F:B5:0D:54     
10.107.0.220:0     id=309   sec_id=7117408 flags=0x0000 ifindex=15  mac=86:03:2E:58:BA:14 nodemac=82:15:BD:BF:60:BD   
10.107.0.165:0     id=80    sec_id=7085474 flags=0x0000 ifindex=11  mac=62:70:BB:8A:A3:5A nodemac=BE:73:B5:4D:3C:02   
10.107.0.235:0     id=331   sec_id=7085474 flags=0x0000 ifindex=9   mac=7A:1D:4F:B6:64:39 nodemac=EE:08:FD:8E:51:CC   
