KEY             VALUE
AgentLiveness   966503224172
UTimeOffset     3378615595703125
