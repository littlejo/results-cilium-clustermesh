top - 10:28:41 up 15 min,  0 users,  load average: 0.01, 0.11, 0.11
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s):  6.9 us, 27.6 sy,  0.0 ni, 65.5 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1014.1 free,    904.0 used,   1918.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2763.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 278956  78404 S   0.0   7.1   0:21.45 cilium-+
    391 root      20   0 1228848   6320   3060 S   0.0   0.2   0:00.24 cilium-+
    633 root      20   0 1240432  16304  11356 S   0.0   0.4   0:00.02 cilium-+
    677 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    688 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    707 root      20   0 1228744   3656   2976 S   0.0   0.1   0:00.00 gops
