1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:81:30:3c:59:a5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.238.183/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2674sec preferred_lft 2674sec
    inet6 fe80::881:30ff:fe3c:59a5/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:3c:d4:c5:08:2e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::83c:d4ff:fec5:82e/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:5e:ed:6b:f5:9c brd ff:ff:ff:ff:ff:ff
    inet 10.107.0.111/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::f85e:edff:fe6b:f59c/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ca:cd:bc:3f:13:7a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c8cd:bcff:fe3f:137a/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:19:6f:b5:0d:54 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::1019:6fff:feb5:d54/64 scope link 
       valid_lft forever preferred_lft forever
9: lxca18a3ce01b5a@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:08:fd:8e:51:cc brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::ec08:fdff:fe8e:51cc/64 scope link 
       valid_lft forever preferred_lft forever
11: lxcba2de8b8a3f7@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:73:b5:4d:3c:02 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::bc73:b5ff:fe4d:3c02/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc6ecc2ea36041@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:15:bd:bf:60:bd brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::8015:bdff:febf:60bd/64 scope link 
       valid_lft forever preferred_lft forever
