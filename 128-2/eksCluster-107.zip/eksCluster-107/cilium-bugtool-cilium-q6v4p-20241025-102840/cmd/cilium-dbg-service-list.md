ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.182.189:443 (active)    
                                          2 => 172.31.197.68:443 (active)     
2    10.100.137.176:443    ClusterIP      1 => 172.31.238.183:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.107.0.235:53 (active)       
                                          2 => 10.107.0.165:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.107.0.235:9153 (active)     
                                          2 => 10.107.0.165:9153 (active)     
5    10.100.193.113:2379   ClusterIP      1 => 10.107.0.220:2379 (active)     
