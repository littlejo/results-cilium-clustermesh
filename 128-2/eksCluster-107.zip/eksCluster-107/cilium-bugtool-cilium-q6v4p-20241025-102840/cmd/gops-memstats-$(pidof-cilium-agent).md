alloc: 99.02MB (103832416 bytes)
total-alloc: 1.37GB (1472296784 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 48409263
frees: 47401923
heap-alloc: 99.02MB (103832416 bytes)
heap-sys: 165.07MB (173088768 bytes)
heap-idle: 44.22MB (46366720 bytes)
heap-in-use: 120.85MB (126722048 bytes)
heap-released: 3.62MB (3792896 bytes)
heap-objects: 1007340
stack-in-use: 34.91MB (36601856 bytes)
stack-sys: 34.91MB (36601856 bytes)
stack-mspan-inuse: 2.01MB (2106880 bytes)
stack-mspan-sys: 2.44MB (2562240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 919.92KB (941993 bytes)
gc-sys: 5.16MB (5409144 bytes)
next-gc: when heap-alloc >= 147.64MB (154814568 bytes)
last-gc: 2024-10-25 10:28:48.301783318 +0000 UTC
gc-pause-total: 9.657629ms
gc-pause: 66109
gc-pause-end: 1729852128301783318
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.00031083200684917285
enable-gc: true
debug-gc: false
