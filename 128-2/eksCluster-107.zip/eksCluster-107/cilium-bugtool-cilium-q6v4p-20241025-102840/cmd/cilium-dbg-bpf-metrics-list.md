REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     10138     794072      677    bpf_overlay.c
Interface                 INGRESS     227002    101748446   1132   bpf_host.c
Success                   EGRESS      10374     810546      53     encap.h
Success                   EGRESS      5291      406500      1694   bpf_host.c
Success                   EGRESS      96692     12693743    1308   bpf_lxc.c
Success                   INGRESS     108059    13314860    86     l3.h
Success                   INGRESS     113555    13746338    235    trace.h
Unsupported L3 protocol   EGRESS      37        2762        1492   bpf_lxc.c
