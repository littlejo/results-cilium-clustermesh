CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod440c38ab_c866_4cc5_9812_8fe659b83af5.slice/cri-containerd-1c19296682158d94c4c3a437cabc5cdbc1c9b620ce9c4511b9c9c7a542ec771b.scope
    528      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod440c38ab_c866_4cc5_9812_8fe659b83af5.slice/cri-containerd-0cf04a610606d4ceba5fc83bd589f2b14eea28567e021171279d6470fd7d9783.scope
    524      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod68f27cf4_2157_44c8_8801_f2e9a0ef4964.slice/cri-containerd-d99c0b48363d93e9028d433c85d501c0ca2b8154bef092be1974f48c491eb7e0.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod68f27cf4_2157_44c8_8801_f2e9a0ef4964.slice/cri-containerd-a7d197ed3930e8ed2c09380f36fb0c9a11c671b0c56a96ad1672d463331b6a69.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod46dcc238_4083_4ac9_a122_c24a6e563b50.slice/cri-containerd-a853d13058d81aa4bd9f343ffc810f0134546cdb1f7bda5d77443b65e730c062.scope
    107      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod46dcc238_4083_4ac9_a122_c24a6e563b50.slice/cri-containerd-3e13623580356c5814dd5fb7cac24823847ba74eaf861b0b1a0fc3ed4690a432.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode9f85011_dada_420c_a9b4_5c6ca3885ca0.slice/cri-containerd-8b40c6d15d8380aef1ecda02a4efec2e1c634d881b11333f5fb051550faa2bb1.scope
    520      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode9f85011_dada_420c_a9b4_5c6ca3885ca0.slice/cri-containerd-362906ab376debac19066431f17b8801f10e75f8130bbea24f6b97f310cbe527.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf376e5e7_e478_470f_8e37_c3f76e19f95a.slice/cri-containerd-c0efda791b443e2d42dd3259e193d83bf55233598e901d66a432ed5aec74465e.scope
    606      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf376e5e7_e478_470f_8e37_c3f76e19f95a.slice/cri-containerd-b3d677a4ae4c9356cf68cfd2d25b0f352bf8a8ef2c4e5d1ca9807ba9d0f78a2b.scope
    610      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf376e5e7_e478_470f_8e37_c3f76e19f95a.slice/cri-containerd-47b51c6fb1143a0ccd1306001993b6804d34ecaa2a8105cc94e77d264c96e963.scope
    586      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf376e5e7_e478_470f_8e37_c3f76e19f95a.slice/cri-containerd-98d3c67bcf048065c5c6640d0a110167be048a5e09fa59098fe03936b83845db.scope
    602      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod219778c4_3da3_4928_8943_b820fd835b8d.slice/cri-containerd-6da6116c29e2ec075921cfbb3634fec9256b1f1816607ac63ccad021ab7492e4.scope
    72       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod219778c4_3da3_4928_8943_b820fd835b8d.slice/cri-containerd-3eeab94076ee0c4e87d5b44b04c8305cbb0c92800c536f2068fbfeaf44468e94.scope
    80       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9df64862_c43a_4271_ade9_3e10c2108b58.slice/cri-containerd-01c93c58646092a58bcdc08f271791f88ab7a905eb2bb53b2ccbeca90ddc9c13.scope
    64       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9df64862_c43a_4271_ade9_3e10c2108b58.slice/cri-containerd-cac03baec8dbcc9d64d4ce8fe5c85d3cd026060949a072ac6fb2f38c45b84330.scope
    76       cgroup_device   multi                                          
