xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 470
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 459
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 455
cilium_host(4) clsact/egress cil_from_host-cilium_host id 452
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 449
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 450
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 508
lxca18a3ce01b5a(9) clsact/ingress cil_from_container-lxca18a3ce01b5a id 473
lxcba2de8b8a3f7(11) clsact/ingress cil_from_container-lxcba2de8b8a3f7 id 501
lxc6ecc2ea36041(15) clsact/ingress cil_from_container-lxc6ecc2ea36041 id 575

flow_dissector:

netfilter:

