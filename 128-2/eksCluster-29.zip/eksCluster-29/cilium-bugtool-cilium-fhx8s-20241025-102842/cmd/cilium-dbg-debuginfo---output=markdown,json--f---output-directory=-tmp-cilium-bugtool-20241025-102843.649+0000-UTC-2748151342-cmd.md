markdown output at /tmp/cilium-bugtool-20241025-102843.649+0000-UTC-2748151342/cmd/cilium-debuginfo-20241025-102914.291+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102843.649+0000-UTC-2748151342/cmd/cilium-debuginfo-20241025-102914.291+0000-UTC.json
