Endpoint ID: 456
Path: /sys/fs/bpf/tc/globals/cilium_policy_00456

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    435944   5559      0        
Allow    Ingress     1          ANY          NONE         disabled    12418    143       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 810
Path: /sys/fs/bpf/tc/globals/cilium_policy_00810

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    89017   1023      0        
Allow    Egress      0          ANY          NONE         disabled    14648   155       0        


Endpoint ID: 1359
Path: /sys/fs/bpf/tc/globals/cilium_policy_01359

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3849555   35373     0        
Allow    Ingress     1          ANY          NONE         disabled    2727679   27137     0        
Allow    Egress      0          ANY          NONE         disabled    3733765   34904     0        


Endpoint ID: 1612
Path: /sys/fs/bpf/tc/globals/cilium_policy_01612

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2846
Path: /sys/fs/bpf/tc/globals/cilium_policy_02846

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    88951   1022      0        
Allow    Egress      0          ANY          NONE         disabled    15184   160       0        


