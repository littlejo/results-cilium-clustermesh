filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcb8d7d32195bf direct-action not_in_hw id 493 tag 22a68e1761785a17 jited 
