ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.132.178:443 (active)   
                                         2 => 172.31.248.255:443 (active)   
2    10.100.153.116:443   ClusterIP      1 => 172.31.243.59:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.29.0.226:53 (active)       
                                         2 => 10.29.0.245:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.29.0.226:9153 (active)     
                                         2 => 10.29.0.245:9153 (active)     
5    10.100.240.64:2379   ClusterIP      1 => 10.29.0.44:2379 (active)      
