Total: 534
TCP:   1045 (estab 289, closed 737, orphaned 0, timewait 286)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  308       299       9        
INET	  318       305       13       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                   172.31.243.59%ens5:68         0.0.0.0:*    uid:192 ino:16411 sk:1001 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:22022 sk:1002 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15167 sk:1003 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:43789      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:20952 sk:1004 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:22021 sk:1005 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15168 sk:1006 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::8c4:fdff:fe3f:d505]%ens5:546           [::]:*    uid:192 ino:16409 sk:1007 cgroup:unreachable:c4e v6only:1 <->                   
