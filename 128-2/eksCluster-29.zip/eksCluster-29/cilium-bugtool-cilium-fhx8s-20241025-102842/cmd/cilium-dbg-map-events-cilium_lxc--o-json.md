{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:28.154Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.243.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:28.154Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:32.984Z",
  "value": "id=456   sec_id=4     flags=0x0000 ifindex=7   mac=8A:97:6C:0E:72:5C nodemac=82:11:23:BA:7D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:33.008Z",
  "value": "id=810   sec_id=1970653 flags=0x0000 ifindex=9   mac=FE:D2:4D:5A:E2:33 nodemac=B2:1F:10:43:3C:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:33.046Z",
  "value": "id=2846  sec_id=1970653 flags=0x0000 ifindex=11  mac=0E:A1:FB:8E:5D:B8 nodemac=F2:08:61:0B:85:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:33.054Z",
  "value": "id=456   sec_id=4     flags=0x0000 ifindex=7   mac=8A:97:6C:0E:72:5C nodemac=82:11:23:BA:7D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:51.503Z",
  "value": "id=456   sec_id=4     flags=0x0000 ifindex=7   mac=8A:97:6C:0E:72:5C nodemac=82:11:23:BA:7D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:51.504Z",
  "value": "id=810   sec_id=1970653 flags=0x0000 ifindex=9   mac=FE:D2:4D:5A:E2:33 nodemac=B2:1F:10:43:3C:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:51.505Z",
  "value": "id=2846  sec_id=1970653 flags=0x0000 ifindex=11  mac=0E:A1:FB:8E:5D:B8 nodemac=F2:08:61:0B:85:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:51.535Z",
  "value": "id=3761  sec_id=1978426 flags=0x0000 ifindex=13  mac=32:C4:2E:F1:80:13 nodemac=E6:E4:32:03:5A:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.504Z",
  "value": "id=456   sec_id=4     flags=0x0000 ifindex=7   mac=8A:97:6C:0E:72:5C nodemac=82:11:23:BA:7D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.504Z",
  "value": "id=2846  sec_id=1970653 flags=0x0000 ifindex=11  mac=0E:A1:FB:8E:5D:B8 nodemac=F2:08:61:0B:85:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.504Z",
  "value": "id=810   sec_id=1970653 flags=0x0000 ifindex=9   mac=FE:D2:4D:5A:E2:33 nodemac=B2:1F:10:43:3C:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.504Z",
  "value": "id=3761  sec_id=1978426 flags=0x0000 ifindex=13  mac=32:C4:2E:F1:80:13 nodemac=E6:E4:32:03:5A:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:00.120Z",
  "value": "id=1359  sec_id=1978426 flags=0x0000 ifindex=15  mac=96:65:A4:B5:AF:B8 nodemac=E2:B6:A9:DD:9B:D8"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.29.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:10.441Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:46.731Z",
  "value": "id=1359  sec_id=1978426 flags=0x0000 ifindex=15  mac=96:65:A4:B5:AF:B8 nodemac=E2:B6:A9:DD:9B:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:46.732Z",
  "value": "id=2846  sec_id=1970653 flags=0x0000 ifindex=11  mac=0E:A1:FB:8E:5D:B8 nodemac=F2:08:61:0B:85:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:46.733Z",
  "value": "id=456   sec_id=4     flags=0x0000 ifindex=7   mac=8A:97:6C:0E:72:5C nodemac=82:11:23:BA:7D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:46.733Z",
  "value": "id=810   sec_id=1970653 flags=0x0000 ifindex=9   mac=FE:D2:4D:5A:E2:33 nodemac=B2:1F:10:43:3C:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:47.729Z",
  "value": "id=1359  sec_id=1978426 flags=0x0000 ifindex=15  mac=96:65:A4:B5:AF:B8 nodemac=E2:B6:A9:DD:9B:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:47.729Z",
  "value": "id=810   sec_id=1970653 flags=0x0000 ifindex=9   mac=FE:D2:4D:5A:E2:33 nodemac=B2:1F:10:43:3C:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:47.730Z",
  "value": "id=456   sec_id=4     flags=0x0000 ifindex=7   mac=8A:97:6C:0E:72:5C nodemac=82:11:23:BA:7D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:47.730Z",
  "value": "id=2846  sec_id=1970653 flags=0x0000 ifindex=11  mac=0E:A1:FB:8E:5D:B8 nodemac=F2:08:61:0B:85:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:48.730Z",
  "value": "id=2846  sec_id=1970653 flags=0x0000 ifindex=11  mac=0E:A1:FB:8E:5D:B8 nodemac=F2:08:61:0B:85:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:48.731Z",
  "value": "id=1359  sec_id=1978426 flags=0x0000 ifindex=15  mac=96:65:A4:B5:AF:B8 nodemac=E2:B6:A9:DD:9B:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:48.731Z",
  "value": "id=456   sec_id=4     flags=0x0000 ifindex=7   mac=8A:97:6C:0E:72:5C nodemac=82:11:23:BA:7D:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.29.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:48.732Z",
  "value": "id=810   sec_id=1970653 flags=0x0000 ifindex=9   mac=FE:D2:4D:5A:E2:33 nodemac=B2:1F:10:43:3C:F2"
}

