alloc: 120.46MB (126306728 bytes)
total-alloc: 1.31GB (1410559944 bytes)
sys: 218.38MB (228992340 bytes)
lookups: 0
mallocs: 47421853
frees: 46229386
heap-alloc: 120.46MB (126306728 bytes)
heap-sys: 173.33MB (181747712 bytes)
heap-idle: 30.76MB (32251904 bytes)
heap-in-use: 142.57MB (149495808 bytes)
heap-released: 1.47MB (1540096 bytes)
heap-objects: 1192467
stack-in-use: 34.62MB (36306944 bytes)
stack-sys: 34.62MB (36306944 bytes)
stack-mspan-inuse: 2.22MB (2332480 bytes)
stack-mspan-sys: 2.46MB (2578560 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 892.49KB (913913 bytes)
gc-sys: 5.19MB (5439792 bytes)
next-gc: when heap-alloc >= 149.86MB (157135704 bytes)
last-gc: 2024-10-25 10:28:43.710996679 +0000 UTC
gc-pause-total: 7.796004ms
gc-pause: 63867
gc-pause-end: 1729852123710996679
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00034393567149813267
enable-gc: true
debug-gc: false
