xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 466
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 459
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 452
cilium_host(4) clsact/egress cil_from_host-cilium_host id 456
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 448
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 449
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 498
lxcb8d7d32195bf(9) clsact/ingress cil_from_container-lxcb8d7d32195bf id 493
lxcead568d41490(11) clsact/ingress cil_from_container-lxcead568d41490 id 508
lxc962efed553e2(15) clsact/ingress cil_from_container-lxc962efed553e2 id 572

flow_dissector:

netfilter:

