CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf87feedc_5a2f_4237_8dab_981bc5a01437.slice/cri-containerd-d741f4d262e2abb4edbe2eeaea4b9599cf908e4a58107efa9a69b8ddbdcb9346.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf87feedc_5a2f_4237_8dab_981bc5a01437.slice/cri-containerd-800cd27bca4ae348a235534e052d0e973ec9529650e9e1abe7b6b17401946422.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod84bae698_a3ea_4dee_a2f8_e14b59422bbf.slice/cri-containerd-95592784344c75e6d418d7460e591c757a98ff660f115f224478476b515eb972.scope
    531      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod84bae698_a3ea_4dee_a2f8_e14b59422bbf.slice/cri-containerd-571368b59be91cd3c9730019e6097f2774b98dddaf3f89bb4a31f679b6c12491.scope
    519      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfe01632e_0251_4817_afec_c75eeaeb4e6f.slice/cri-containerd-d3479f19ab875cd88d9da51caeb48224f810dcc03ff0e8971e35263b0aa257c4.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfe01632e_0251_4817_afec_c75eeaeb4e6f.slice/cri-containerd-4de2160bd35eb105e779d86b7d54d68283df8c038f7361944824c9303c30f4c4.scope
    71       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod06512a14_108e_4bbd_b400_12a69dd2927f.slice/cri-containerd-7dde0f2609706f27c2f72ff3f5876e5fb388564da8da35e645ab490283463a4b.scope
    527      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod06512a14_108e_4bbd_b400_12a69dd2927f.slice/cri-containerd-4c36d47015b0d0278b6d00bb8a73a01c2a7341e4f78ca3f600e6c1f769887f90.scope
    523      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b282112_51c4_43de_9402_6d622f947095.slice/cri-containerd-3d1d8383adadb516e3886148f02d2b1ad9bdd40323285a12c9de8ec31bfdd7fc.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b282112_51c4_43de_9402_6d622f947095.slice/cri-containerd-4f647a8729adf92d12fa428ee47fde6d03416e3c85a19bb7e5254e6106e943b2.scope
    64       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod02752f98_78fa_4a2e_a0ec_ec25b9b69907.slice/cri-containerd-94a287ff00556851f3cada63848071cf65ed5e9acd71cb1570cb787cfcd411f8.scope
    605      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod02752f98_78fa_4a2e_a0ec_ec25b9b69907.slice/cri-containerd-bdc1be4d8b6d72905e4d6fd7d5db9999c8be5338deb5da10755e2c687f4cfc63.scope
    601      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod02752f98_78fa_4a2e_a0ec_ec25b9b69907.slice/cri-containerd-821ba0d5c23b7abe95a9d01ef5ec669be1bc8e73c4821dff49c2a0f4c1354ad1.scope
    609      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod02752f98_78fa_4a2e_a0ec_ec25b9b69907.slice/cri-containerd-0fae65fc5d55d91dbbc0fd98604036bf564cda51f82622cf9c3864cacf2c1925.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod123dc58a_0b9d_424a_be97_4137c8a6d91b.slice/cri-containerd-3c0a0bc59836b1825b085f9c3409875a9660f4c291366675adb21ecd610f4390.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod123dc58a_0b9d_424a_be97_4137c8a6d91b.slice/cri-containerd-3f5c05afbeb95f9f25c5caf5378e6d76446eb6935ca7aa8d73232cb339efb521.scope
    75       cgroup_device   multi                                          
