[
  {
    "containers": [
      {
        "cgroup-id": 8370,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod02752f98_78fa_4a2e_a0ec_ec25b9b69907.slice/cri-containerd-821ba0d5c23b7abe95a9d01ef5ec669be1bc8e73c4821dff49c2a0f4c1354ad1.scope"
      },
      {
        "cgroup-id": 8286,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod02752f98_78fa_4a2e_a0ec_ec25b9b69907.slice/cri-containerd-94a287ff00556851f3cada63848071cf65ed5e9acd71cb1570cb787cfcd411f8.scope"
      },
      {
        "cgroup-id": 8202,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod02752f98_78fa_4a2e_a0ec_ec25b9b69907.slice/cri-containerd-bdc1be4d8b6d72905e4d6fd7d5db9999c8be5338deb5da10755e2c687f4cfc63.scope"
      }
    ],
    "ips": [
      "10.29.0.44"
    ],
    "name": "clustermesh-apiserver-857f579f48-99dsz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6858,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod06512a14_108e_4bbd_b400_12a69dd2927f.slice/cri-containerd-7dde0f2609706f27c2f72ff3f5876e5fb388564da8da35e645ab490283463a4b.scope"
      }
    ],
    "ips": [
      "10.29.0.226"
    ],
    "name": "coredns-cc6ccd49c-57fs8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6774,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod84bae698_a3ea_4dee_a2f8_e14b59422bbf.slice/cri-containerd-95592784344c75e6d418d7460e591c757a98ff660f115f224478476b515eb972.scope"
      }
    ],
    "ips": [
      "10.29.0.245"
    ],
    "name": "coredns-cc6ccd49c-jssgv",
    "namespace": "kube-system"
  }
]

