fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxcb8d7d32195bf proto kernel metric 256 pref medium
fe80::/64 dev lxcead568d41490 proto kernel metric 256 pref medium
fe80::/64 dev lxc962efed553e2 proto kernel metric 256 pref medium
