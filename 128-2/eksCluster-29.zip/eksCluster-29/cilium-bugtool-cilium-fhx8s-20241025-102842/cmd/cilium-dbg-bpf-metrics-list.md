REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     209863    99252846   1132   bpf_host.c
Interface                 INGRESS     8768      683968     677    bpf_overlay.c
Success                   EGRESS      3888      294444     1694   bpf_host.c
Success                   EGRESS      8304      649318     53     encap.h
Success                   EGRESS      87487     11971405   1308   bpf_lxc.c
Success                   INGRESS     103638    12371530   235    trace.h
Success                   INGRESS     98109     11938100   86     l3.h
Unsupported L3 protocol   EGRESS      38        2832       1492   bpf_lxc.c
