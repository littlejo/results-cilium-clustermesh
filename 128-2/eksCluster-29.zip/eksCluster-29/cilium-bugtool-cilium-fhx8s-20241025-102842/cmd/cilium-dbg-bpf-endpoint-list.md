IP ADDRESS        LOCAL ENDPOINT INFO
10.29.0.151:0     (localhost)                                                                                        
10.29.0.241:0     id=456   sec_id=4     flags=0x0000 ifindex=7   mac=8A:97:6C:0E:72:5C nodemac=82:11:23:BA:7D:52     
172.31.243.59:0   (localhost)                                                                                        
10.29.0.226:0     id=2846  sec_id=1970653 flags=0x0000 ifindex=11  mac=0E:A1:FB:8E:5D:B8 nodemac=F2:08:61:0B:85:92   
10.29.0.245:0     id=810   sec_id=1970653 flags=0x0000 ifindex=9   mac=FE:D2:4D:5A:E2:33 nodemac=B2:1F:10:43:3C:F2   
10.29.0.44:0      id=1359  sec_id=1978426 flags=0x0000 ifindex=15  mac=96:65:A4:B5:AF:B8 nodemac=E2:B6:A9:DD:9B:D8   
