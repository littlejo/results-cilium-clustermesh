key: c8 01 00 00  value: fb 01 00 00
key: 2a 03 00 00  value: da 01 00 00
key: 4f 05 00 00  value: 41 02 00 00
key: 1e 0b 00 00  value: f9 01 00 00
Found 4 elements
