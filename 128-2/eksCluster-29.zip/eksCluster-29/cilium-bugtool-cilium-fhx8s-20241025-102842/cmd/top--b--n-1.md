top - 10:28:43 up 16 min,  0 users,  load average: 0.07, 0.08, 0.09
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s):  3.4 us, 51.7 sy,  0.0 ni, 41.4 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   3836.2 total,   1183.7 free,    897.7 used,   1754.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2770.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 288552  79232 S   0.0   7.3   0:24.72 cilium-+
    390 root      20   0 1228848   6660   3836 S   0.0   0.2   0:00.27 cilium-+
    617 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    629 root      20   0 1240432  16500  11356 S   0.0   0.4   0:00.02 cilium-+
    640 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    681 root      20   0    6576   2416   2092 R   0.0   0.1   0:00.00 top
    694 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    715 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
    720 root      20   0 1691848   8436   6336 S   0.0   0.2   0:00.00 runc:[2+
