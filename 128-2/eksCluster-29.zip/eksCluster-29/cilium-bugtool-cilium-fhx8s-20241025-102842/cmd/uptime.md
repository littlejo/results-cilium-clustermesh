 10:28:43 up 16 min,  0 users,  load average: 0.07, 0.08, 0.09
