KEY             VALUE
AgentLiveness   991713500702
UTimeOffset     3378615550781250
