Endpoint ID: 80
Path: /sys/fs/bpf/tc/globals/cilium_policy_00080

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 178
Path: /sys/fs/bpf/tc/globals/cilium_policy_00178

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    438959   5616      0        
Allow    Ingress     1          ANY          NONE         disabled    12350    145       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 466
Path: /sys/fs/bpf/tc/globals/cilium_policy_00466

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3820419   36350     0        
Allow    Ingress     1          ANY          NONE         disabled    3536050   36198     0        
Allow    Egress      0          ANY          NONE         disabled    5207448   47862     0        


Endpoint ID: 2740
Path: /sys/fs/bpf/tc/globals/cilium_policy_02740

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    80335   926       0        
Allow    Egress      0          ANY          NONE         disabled    14424   152       0        


Endpoint ID: 3624
Path: /sys/fs/bpf/tc/globals/cilium_policy_03624

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    80716   930       0        
Allow    Egress      0          ANY          NONE         disabled    14499   152       0        


