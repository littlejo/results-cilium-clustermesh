IP ADDRESS         LOCAL ENDPOINT INFO
10.54.0.92:0       id=178   sec_id=4     flags=0x0000 ifindex=10  mac=D2:47:68:73:22:1F nodemac=72:9E:6A:86:27:0D     
172.31.145.45:0    (localhost)                                                                                        
10.54.0.211:0      (localhost)                                                                                        
172.31.172.206:0   (localhost)                                                                                        
10.54.0.151:0      id=466   sec_id=3609450 flags=0x0000 ifindex=18  mac=DE:43:C9:6B:DC:C1 nodemac=16:89:74:05:40:55   
10.54.0.57:0       id=2740  sec_id=3611620 flags=0x0000 ifindex=12  mac=C2:4F:B3:CE:BF:9A nodemac=AE:A8:FD:99:F3:42   
10.54.0.53:0       id=3624  sec_id=3611620 flags=0x0000 ifindex=14  mac=2A:89:C9:70:20:7D nodemac=4A:DF:DF:26:2C:91   
