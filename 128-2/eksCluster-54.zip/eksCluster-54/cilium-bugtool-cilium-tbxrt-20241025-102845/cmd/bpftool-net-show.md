xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 505
ens6(5) clsact/ingress cil_from_netdev-ens6 id 506
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 498
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 491
cilium_host(7) clsact/egress cil_from_host-cilium_host id 488
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 482
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 483
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 539
lxc1cafd23a932d(12) clsact/ingress cil_from_container-lxc1cafd23a932d id 535
lxc8f42b69d0381(14) clsact/ingress cil_from_container-lxc8f42b69d0381 id 559
lxc70565406ead0(18) clsact/ingress cil_from_container-lxc70565406ead0 id 621

flow_dissector:

netfilter:

