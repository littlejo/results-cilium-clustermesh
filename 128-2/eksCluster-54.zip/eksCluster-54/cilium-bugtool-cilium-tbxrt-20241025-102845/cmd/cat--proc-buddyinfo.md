Node 0, zone      DMA    165     64      8      7     14     64     21      4      2      5    160 
Node 0, zone   Normal      1      0      1     15     36      2     12      4      2      2      7 
