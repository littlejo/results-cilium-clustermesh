USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         670  0.0  0.4 1240432 16244 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         685  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         687  0.0  0.4 1240432 16244 ?       R    10:28   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         661  0.0  0.0 1228744 3716 ?        Ssl  10:28   0:00 /bin/gops memstats 1
root         632  0.0  0.1 1228744 4040 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         623  0.0  0.1 1228744 4036 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root         622  0.0  0.0 1228744 3660 ?        Ssl  10:28   0:00 /bin/gops stack 1
root           1  3.1  7.1 1538420 282048 ?      Ssl  10:14   0:26 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.0  0.1 1228848 5764 ?        Sl   10:14   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
