REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10736     843274     677    bpf_overlay.c
Interface                 INGRESS     229601    86796893   1132   bpf_host.c
Success                   EGRESS      11313     885884     53     encap.h
Success                   EGRESS      5789      449618     1694   bpf_host.c
Success                   EGRESS      97306     12755720   1308   bpf_lxc.c
Success                   INGRESS     109238    13425688   86     l3.h
Success                   INGRESS     114834    13863250   235    trace.h
Unsupported L3 protocol   EGRESS      42        3188       1492   bpf_lxc.c
