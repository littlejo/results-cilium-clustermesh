alloc: 105.60MB (110728728 bytes)
total-alloc: 1.39GB (1487392784 bytes)
sys: 210.70MB (220931412 bytes)
lookups: 0
mallocs: 48654346
frees: 47595824
heap-alloc: 105.60MB (110728728 bytes)
heap-sys: 165.02MB (173031424 bytes)
heap-idle: 36.88MB (38674432 bytes)
heap-in-use: 128.13MB (134356992 bytes)
heap-released: 1.00MB (1048576 bytes)
heap-objects: 1058522
stack-in-use: 34.94MB (36634624 bytes)
stack-sys: 34.94MB (36634624 bytes)
stack-mspan-inuse: 2.11MB (2208960 bytes)
stack-mspan-sys: 2.58MB (2709120 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1017.62KB (1042041 bytes)
gc-sys: 5.25MB (5507424 bytes)
next-gc: when heap-alloc >= 147.20MB (154349720 bytes)
last-gc: 2024-10-25 10:28:51.725844003 +0000 UTC
gc-pause-total: 8.53331ms
gc-pause: 1476996
gc-pause-end: 1729852131725844003
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00032518238031012387
enable-gc: true
debug-gc: false
