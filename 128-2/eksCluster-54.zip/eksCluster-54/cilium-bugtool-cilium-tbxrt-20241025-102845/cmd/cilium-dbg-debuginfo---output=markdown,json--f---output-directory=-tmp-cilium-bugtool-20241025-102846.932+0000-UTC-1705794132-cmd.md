markdown output at /tmp/cilium-bugtool-20241025-102846.932+0000-UTC-1705794132/cmd/cilium-debuginfo-20241025-102917.677+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102846.932+0000-UTC-1705794132/cmd/cilium-debuginfo-20241025-102917.677+0000-UTC.json
