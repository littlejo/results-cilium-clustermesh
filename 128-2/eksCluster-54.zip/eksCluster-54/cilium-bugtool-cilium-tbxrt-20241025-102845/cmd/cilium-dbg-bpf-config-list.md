KEY             VALUE
AgentLiveness   927180746820
UTimeOffset     3378615683593750
