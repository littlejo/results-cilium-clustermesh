ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.191.189:443 (active)   
                                          2 => 172.31.193.64:443 (active)    
2    10.100.75.51:443      ClusterIP      1 => 172.31.145.45:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.54.0.57:53 (active)        
                                          2 => 10.54.0.53:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.54.0.57:9153 (active)      
                                          2 => 10.54.0.53:9153 (active)      
5    10.100.125.199:2379   ClusterIP      1 => 10.54.0.151:2379 (active)     
