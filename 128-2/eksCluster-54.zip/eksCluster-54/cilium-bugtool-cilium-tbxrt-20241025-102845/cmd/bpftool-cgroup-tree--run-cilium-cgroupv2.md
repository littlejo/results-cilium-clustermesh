CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddaf769a9_ba79_4367_b1e3_1dbbfc15edc9.slice/cri-containerd-8403f2e1cde52900d008d593990b10ecbaaa90ce2c5081ba5b47408241c638b5.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddaf769a9_ba79_4367_b1e3_1dbbfc15edc9.slice/cri-containerd-e1fc25bc1ee89435654f89f2bf0e94ad64149a110ac1e0f9aad7f974f2e74059.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1bfa5547_05c4_491e_b11b_979d7b97594b.slice/cri-containerd-22a3ed1ae32dce681aae3cd462d870102ac40b32887d00ca5872ede1418b740f.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1bfa5547_05c4_491e_b11b_979d7b97594b.slice/cri-containerd-9cbe463e0c1a333b9f8fdd4d1a4c50c905db2b21299bbda2e3415eac83d0f860.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaed58d4f_71bf_4d47_bb1f_5e2dc3f312f3.slice/cri-containerd-058915a0aa8dbd3cf362f6f7c740938e4ebb8dd4d6e2b67fea7ada00a8838cf5.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaed58d4f_71bf_4d47_bb1f_5e2dc3f312f3.slice/cri-containerd-76f68687e905471e5526819e1024bb0c660c86a2b5e44268fbaf6860876583e0.scope
    553      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e6c282c_01cd_4d9d_9b51_1919d7ead519.slice/cri-containerd-0e28eebb95e928001a9729d386b8c7a2ded66b194451d3b964da083dff4d5749.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e6c282c_01cd_4d9d_9b51_1919d7ead519.slice/cri-containerd-3ef59718e9d6d9f10b6e093175e4b07e846f77981dd0f64714dc1e196ffc7bad.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda72127bf_f2d1_4aa3_bc38_b7057627694b.slice/cri-containerd-66e57c8ab22e2d0e382ab1de680a52702f549e6158770a916b62ac02055511a5.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda72127bf_f2d1_4aa3_bc38_b7057627694b.slice/cri-containerd-07d8aedcefe8d52ef693bb9c826e90c361ce508a10266d0bbe18ce1b36bcab36.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb91c6ef9_235f_4317_983b_7ab5b5cd22a4.slice/cri-containerd-a0b57cfbc48bb26f93d1aa1382a695f804c11c83e9917ef9fc096f49ce40f463.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb91c6ef9_235f_4317_983b_7ab5b5cd22a4.slice/cri-containerd-f235457d853c964d71f28b5ce06948d75fdb2b4147383989edea46b4dfc1c571.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb91c6ef9_235f_4317_983b_7ab5b5cd22a4.slice/cri-containerd-ce0d97d92f70786b9cca798df105444d11c8a7d34075336c6b4d7fef62e31781.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb91c6ef9_235f_4317_983b_7ab5b5cd22a4.slice/cri-containerd-909248ac36165357c58fe6a2b84af845889f652d1d105cf6ccb9e36600f688f4.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7580b19d_f92f_4c6d_975d_9d8c7ea3d88a.slice/cri-containerd-6bc86e88d5731e6ab984d9795acc39445d0c8183084155dbbac9ddac13371982.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7580b19d_f92f_4c6d_975d_9d8c7ea3d88a.slice/cri-containerd-62ccfdd12e7a877e71d3ac878160ebc280b1c29012e1767a05a9f6dde947814d.scope
    106      cgroup_device   multi                                          
