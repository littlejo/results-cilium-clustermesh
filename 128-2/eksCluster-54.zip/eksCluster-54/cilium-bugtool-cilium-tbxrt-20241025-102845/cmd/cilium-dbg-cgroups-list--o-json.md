[
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb91c6ef9_235f_4317_983b_7ab5b5cd22a4.slice/cri-containerd-f235457d853c964d71f28b5ce06948d75fdb2b4147383989edea46b4dfc1c571.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb91c6ef9_235f_4317_983b_7ab5b5cd22a4.slice/cri-containerd-ce0d97d92f70786b9cca798df105444d11c8a7d34075336c6b4d7fef62e31781.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb91c6ef9_235f_4317_983b_7ab5b5cd22a4.slice/cri-containerd-909248ac36165357c58fe6a2b84af845889f652d1d105cf6ccb9e36600f688f4.scope"
      }
    ],
    "ips": [
      "10.54.0.151"
    ],
    "name": "clustermesh-apiserver-6466cff77-lss49",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7535,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaed58d4f_71bf_4d47_bb1f_5e2dc3f312f3.slice/cri-containerd-76f68687e905471e5526819e1024bb0c660c86a2b5e44268fbaf6860876583e0.scope"
      }
    ],
    "ips": [
      "10.54.0.57"
    ],
    "name": "coredns-cc6ccd49c-zckmt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddaf769a9_ba79_4367_b1e3_1dbbfc15edc9.slice/cri-containerd-e1fc25bc1ee89435654f89f2bf0e94ad64149a110ac1e0f9aad7f974f2e74059.scope"
      }
    ],
    "ips": [
      "10.54.0.53"
    ],
    "name": "coredns-cc6ccd49c-jbhtj",
    "namespace": "kube-system"
  }
]

