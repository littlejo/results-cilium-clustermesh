top - 10:28:47 up 14 min,  0 users,  load average: 0.73, 0.51, 0.30
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 28.6 us, 28.6 sy,  0.0 ni, 42.9 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    782.4 free,    911.4 used,   2142.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2755.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538420 285744  78192 S  13.3   7.3   0:26.43 cilium-+
    670 root      20   0 1240432  16548  11356 S  13.3   0.4   0:00.03 cilium-+
    396 root      20   0 1228848   5764   2868 S   0.0   0.1   0:00.27 cilium-+
    623 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    632 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    661 root      20   0 1228744   3716   3040 S   0.0   0.1   0:00.00 gops
    697 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    717 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
