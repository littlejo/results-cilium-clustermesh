{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:57.621Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.145.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:57.621Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.172.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:57.621Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:02.345Z",
  "value": "id=178   sec_id=4     flags=0x0000 ifindex=10  mac=D2:47:68:73:22:1F nodemac=72:9E:6A:86:27:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:02.357Z",
  "value": "id=2740  sec_id=3611620 flags=0x0000 ifindex=12  mac=C2:4F:B3:CE:BF:9A nodemac=AE:A8:FD:99:F3:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:02.359Z",
  "value": "id=2740  sec_id=3611620 flags=0x0000 ifindex=12  mac=C2:4F:B3:CE:BF:9A nodemac=AE:A8:FD:99:F3:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:02.376Z",
  "value": "id=178   sec_id=4     flags=0x0000 ifindex=10  mac=D2:47:68:73:22:1F nodemac=72:9E:6A:86:27:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:08.433Z",
  "value": "id=3624  sec_id=3611620 flags=0x0000 ifindex=14  mac=2A:89:C9:70:20:7D nodemac=4A:DF:DF:26:2C:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:53.965Z",
  "value": "id=178   sec_id=4     flags=0x0000 ifindex=10  mac=D2:47:68:73:22:1F nodemac=72:9E:6A:86:27:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:53.965Z",
  "value": "id=2740  sec_id=3611620 flags=0x0000 ifindex=12  mac=C2:4F:B3:CE:BF:9A nodemac=AE:A8:FD:99:F3:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:53.965Z",
  "value": "id=3624  sec_id=3611620 flags=0x0000 ifindex=14  mac=2A:89:C9:70:20:7D nodemac=4A:DF:DF:26:2C:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:53.998Z",
  "value": "id=2673  sec_id=3609450 flags=0x0000 ifindex=16  mac=42:14:49:BD:58:89 nodemac=56:AC:4E:05:DA:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:54.965Z",
  "value": "id=2673  sec_id=3609450 flags=0x0000 ifindex=16  mac=42:14:49:BD:58:89 nodemac=56:AC:4E:05:DA:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:54.965Z",
  "value": "id=178   sec_id=4     flags=0x0000 ifindex=10  mac=D2:47:68:73:22:1F nodemac=72:9E:6A:86:27:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:54.965Z",
  "value": "id=2740  sec_id=3611620 flags=0x0000 ifindex=12  mac=C2:4F:B3:CE:BF:9A nodemac=AE:A8:FD:99:F3:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:54.966Z",
  "value": "id=3624  sec_id=3611620 flags=0x0000 ifindex=14  mac=2A:89:C9:70:20:7D nodemac=4A:DF:DF:26:2C:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:27.975Z",
  "value": "id=466   sec_id=3609450 flags=0x0000 ifindex=18  mac=DE:43:C9:6B:DC:C1 nodemac=16:89:74:05:40:55"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.54.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:33.191Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:37.481Z",
  "value": "id=3624  sec_id=3611620 flags=0x0000 ifindex=14  mac=2A:89:C9:70:20:7D nodemac=4A:DF:DF:26:2C:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:37.482Z",
  "value": "id=466   sec_id=3609450 flags=0x0000 ifindex=18  mac=DE:43:C9:6B:DC:C1 nodemac=16:89:74:05:40:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:37.483Z",
  "value": "id=178   sec_id=4     flags=0x0000 ifindex=10  mac=D2:47:68:73:22:1F nodemac=72:9E:6A:86:27:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:37.484Z",
  "value": "id=2740  sec_id=3611620 flags=0x0000 ifindex=12  mac=C2:4F:B3:CE:BF:9A nodemac=AE:A8:FD:99:F3:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:38.481Z",
  "value": "id=466   sec_id=3609450 flags=0x0000 ifindex=18  mac=DE:43:C9:6B:DC:C1 nodemac=16:89:74:05:40:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:38.481Z",
  "value": "id=178   sec_id=4     flags=0x0000 ifindex=10  mac=D2:47:68:73:22:1F nodemac=72:9E:6A:86:27:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:38.482Z",
  "value": "id=2740  sec_id=3611620 flags=0x0000 ifindex=12  mac=C2:4F:B3:CE:BF:9A nodemac=AE:A8:FD:99:F3:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:38.482Z",
  "value": "id=3624  sec_id=3611620 flags=0x0000 ifindex=14  mac=2A:89:C9:70:20:7D nodemac=4A:DF:DF:26:2C:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:39.482Z",
  "value": "id=466   sec_id=3609450 flags=0x0000 ifindex=18  mac=DE:43:C9:6B:DC:C1 nodemac=16:89:74:05:40:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:39.482Z",
  "value": "id=178   sec_id=4     flags=0x0000 ifindex=10  mac=D2:47:68:73:22:1F nodemac=72:9E:6A:86:27:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:39.482Z",
  "value": "id=2740  sec_id=3611620 flags=0x0000 ifindex=12  mac=C2:4F:B3:CE:BF:9A nodemac=AE:A8:FD:99:F3:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:39.482Z",
  "value": "id=3624  sec_id=3611620 flags=0x0000 ifindex=14  mac=2A:89:C9:70:20:7D nodemac=4A:DF:DF:26:2C:91"
}

