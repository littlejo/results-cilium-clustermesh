 10:28:47 up 14 min,  0 users,  load average: 0.73, 0.51, 0.30
