key: b2 00 00 00  value: 15 02 00 00
key: d2 01 00 00  value: 66 02 00 00
key: b4 0a 00 00  value: 0d 02 00 00
key: 28 0e 00 00  value: 2e 02 00 00
Found 4 elements
