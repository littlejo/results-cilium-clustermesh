1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:12:5a:66:c7:2d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.145.45/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2713sec preferred_lft 2713sec
    inet6 fe80::412:5aff:fe66:c72d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:21:cc:56:28:b1 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.172.206/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::421:ccff:fe56:28b1/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:76:f3:f9:74:88 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4476:f3ff:fef9:7488/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:67:4d:38:ab:f6 brd ff:ff:ff:ff:ff:ff
    inet 10.54.0.211/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b467:4dff:fe38:abf6/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 92:64:d0:f2:4b:a2 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9064:d0ff:fef2:4ba2/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:9e:6a:86:27:0d brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::709e:6aff:fe86:270d/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc1cafd23a932d@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:a8:fd:99:f3:42 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::aca8:fdff:fe99:f342/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc8f42b69d0381@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:df:df:26:2c:91 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::48df:dfff:fe26:2c91/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc70565406ead0@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:89:74:05:40:55 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::1489:74ff:fe05:4055/64 scope link 
       valid_lft forever preferred_lft forever
