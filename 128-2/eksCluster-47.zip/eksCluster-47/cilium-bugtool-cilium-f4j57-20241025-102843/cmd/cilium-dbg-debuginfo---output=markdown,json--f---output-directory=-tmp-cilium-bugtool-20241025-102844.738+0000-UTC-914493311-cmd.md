markdown output at /tmp/cilium-bugtool-20241025-102844.738+0000-UTC-914493311/cmd/cilium-debuginfo-20241025-102845.495+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102844.738+0000-UTC-914493311/cmd/cilium-debuginfo-20241025-102845.495+0000-UTC.json
