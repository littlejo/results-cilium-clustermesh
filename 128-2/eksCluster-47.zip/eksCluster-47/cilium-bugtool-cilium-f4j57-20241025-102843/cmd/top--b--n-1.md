top - 10:28:44 up 14 min,  0 users,  load average: 0.36, 0.28, 0.30
Tasks:   5 total,   1 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 35.7 us, 21.4 sy,  0.0 ni, 42.9 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    814.5 free,    909.6 used,   2112.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2757.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538356 281560  78584 S  40.0   7.2   0:18.96 cilium-+
    623 root      20   0 1240432  15524  10768 S   6.7   0.4   0:00.03 cilium-+
    393 root      20   0 1228848   5788   2872 S   0.0   0.1   0:00.24 cilium-+
    660 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    684 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
