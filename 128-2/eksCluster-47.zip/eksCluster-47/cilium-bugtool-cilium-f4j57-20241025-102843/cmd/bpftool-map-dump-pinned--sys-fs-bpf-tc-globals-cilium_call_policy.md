key: 5d 00 00 00  value: 38 02 00 00
key: 64 09 00 00  value: fd 01 00 00
key: da 09 00 00  value: 73 02 00 00
key: 37 0d 00 00  value: 0a 02 00 00
Found 4 elements
