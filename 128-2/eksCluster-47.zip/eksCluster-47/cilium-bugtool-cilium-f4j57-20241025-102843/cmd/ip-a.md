1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:23:79:d3:00:cb brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.206.43/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2753sec preferred_lft 2753sec
    inet6 fe80::823:79ff:fed3:cb/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:00:35:6e:cf:2f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.236.187/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::800:35ff:fe6e:cf2f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:df:7a:9f:8a:7c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f4df:7aff:fe9f:8a7c/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:b2:7a:42:a5:5d brd ff:ff:ff:ff:ff:ff
    inet 10.47.0.74/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::60b2:7aff:fe42:a55d/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 72:ec:da:17:3b:13 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::70ec:daff:fe17:3b13/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:d2:c4:ef:5c:26 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::f0d2:c4ff:feef:5c26/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcc85e2b30d4b0@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:61:4b:70:14:e8 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::8c61:4bff:fe70:14e8/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc851ec316fb75@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:27:81:90:52:06 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::c027:81ff:fe90:5206/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcb7c8a242aae4@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:3a:08:48:e6:cb brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::183a:8ff:fe48:e6cb/64 scope link 
       valid_lft forever preferred_lft forever
