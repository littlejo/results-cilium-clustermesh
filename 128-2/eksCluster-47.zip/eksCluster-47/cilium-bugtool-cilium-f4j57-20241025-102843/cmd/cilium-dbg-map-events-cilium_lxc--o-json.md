{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:12.446Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.206.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:12.446Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.236.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:12.446Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:16.672Z",
  "value": "id=2404  sec_id=3187487 flags=0x0000 ifindex=12  mac=3E:C7:F6:FB:8D:37 nodemac=8E:61:4B:70:14:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:16.672Z",
  "value": "id=3383  sec_id=4     flags=0x0000 ifindex=10  mac=C2:E9:B8:BD:9A:31 nodemac=F2:D2:C4:EF:5C:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:16.739Z",
  "value": "id=2404  sec_id=3187487 flags=0x0000 ifindex=12  mac=3E:C7:F6:FB:8D:37 nodemac=8E:61:4B:70:14:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:16.824Z",
  "value": "id=3383  sec_id=4     flags=0x0000 ifindex=10  mac=C2:E9:B8:BD:9A:31 nodemac=F2:D2:C4:EF:5C:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:25.316Z",
  "value": "id=93    sec_id=3187487 flags=0x0000 ifindex=14  mac=12:C0:69:B1:EC:96 nodemac=C2:27:81:90:52:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:43.948Z",
  "value": "id=3383  sec_id=4     flags=0x0000 ifindex=10  mac=C2:E9:B8:BD:9A:31 nodemac=F2:D2:C4:EF:5C:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:43.948Z",
  "value": "id=2404  sec_id=3187487 flags=0x0000 ifindex=12  mac=3E:C7:F6:FB:8D:37 nodemac=8E:61:4B:70:14:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:43.949Z",
  "value": "id=93    sec_id=3187487 flags=0x0000 ifindex=14  mac=12:C0:69:B1:EC:96 nodemac=C2:27:81:90:52:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:43.980Z",
  "value": "id=1762  sec_id=3178929 flags=0x0000 ifindex=16  mac=7E:CD:BA:EF:B5:59 nodemac=9A:C8:1F:D2:7F:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:44.949Z",
  "value": "id=2404  sec_id=3187487 flags=0x0000 ifindex=12  mac=3E:C7:F6:FB:8D:37 nodemac=8E:61:4B:70:14:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:44.949Z",
  "value": "id=1762  sec_id=3178929 flags=0x0000 ifindex=16  mac=7E:CD:BA:EF:B5:59 nodemac=9A:C8:1F:D2:7F:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:44.949Z",
  "value": "id=3383  sec_id=4     flags=0x0000 ifindex=10  mac=C2:E9:B8:BD:9A:31 nodemac=F2:D2:C4:EF:5C:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:44.949Z",
  "value": "id=93    sec_id=3187487 flags=0x0000 ifindex=14  mac=12:C0:69:B1:EC:96 nodemac=C2:27:81:90:52:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:16.864Z",
  "value": "id=2522  sec_id=3178929 flags=0x0000 ifindex=18  mac=C2:8E:53:C7:45:68 nodemac=1A:3A:08:48:E6:CB"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.47.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:27.206Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:28.071Z",
  "value": "id=2404  sec_id=3187487 flags=0x0000 ifindex=12  mac=3E:C7:F6:FB:8D:37 nodemac=8E:61:4B:70:14:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:28.071Z",
  "value": "id=3383  sec_id=4     flags=0x0000 ifindex=10  mac=C2:E9:B8:BD:9A:31 nodemac=F2:D2:C4:EF:5C:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:28.072Z",
  "value": "id=93    sec_id=3187487 flags=0x0000 ifindex=14  mac=12:C0:69:B1:EC:96 nodemac=C2:27:81:90:52:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:28.072Z",
  "value": "id=2522  sec_id=3178929 flags=0x0000 ifindex=18  mac=C2:8E:53:C7:45:68 nodemac=1A:3A:08:48:E6:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:29.012Z",
  "value": "id=3383  sec_id=4     flags=0x0000 ifindex=10  mac=C2:E9:B8:BD:9A:31 nodemac=F2:D2:C4:EF:5C:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:29.012Z",
  "value": "id=93    sec_id=3187487 flags=0x0000 ifindex=14  mac=12:C0:69:B1:EC:96 nodemac=C2:27:81:90:52:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:29.013Z",
  "value": "id=2522  sec_id=3178929 flags=0x0000 ifindex=18  mac=C2:8E:53:C7:45:68 nodemac=1A:3A:08:48:E6:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:29.013Z",
  "value": "id=2404  sec_id=3187487 flags=0x0000 ifindex=12  mac=3E:C7:F6:FB:8D:37 nodemac=8E:61:4B:70:14:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:30.013Z",
  "value": "id=93    sec_id=3187487 flags=0x0000 ifindex=14  mac=12:C0:69:B1:EC:96 nodemac=C2:27:81:90:52:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:30.013Z",
  "value": "id=2522  sec_id=3178929 flags=0x0000 ifindex=18  mac=C2:8E:53:C7:45:68 nodemac=1A:3A:08:48:E6:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:30.014Z",
  "value": "id=2404  sec_id=3187487 flags=0x0000 ifindex=12  mac=3E:C7:F6:FB:8D:37 nodemac=8E:61:4B:70:14:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:30.014Z",
  "value": "id=3383  sec_id=4     flags=0x0000 ifindex=10  mac=C2:E9:B8:BD:9A:31 nodemac=F2:D2:C4:EF:5C:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:31.013Z",
  "value": "id=2522  sec_id=3178929 flags=0x0000 ifindex=18  mac=C2:8E:53:C7:45:68 nodemac=1A:3A:08:48:E6:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:31.014Z",
  "value": "id=2404  sec_id=3187487 flags=0x0000 ifindex=12  mac=3E:C7:F6:FB:8D:37 nodemac=8E:61:4B:70:14:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:31.014Z",
  "value": "id=3383  sec_id=4     flags=0x0000 ifindex=10  mac=C2:E9:B8:BD:9A:31 nodemac=F2:D2:C4:EF:5C:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.47.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:31.015Z",
  "value": "id=93    sec_id=3187487 flags=0x0000 ifindex=14  mac=12:C0:69:B1:EC:96 nodemac=C2:27:81:90:52:06"
}

