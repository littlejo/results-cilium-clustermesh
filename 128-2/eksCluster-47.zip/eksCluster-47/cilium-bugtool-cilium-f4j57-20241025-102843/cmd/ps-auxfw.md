USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         623  0.0  0.3 1240176 15524 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         649  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         650  0.0  0.0   3852  1292 ?        R    10:28   0:00  \_ bash -c hostname
root           1  2.4  7.1 1538356 280472 ?      Ssl  10:16   0:18 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.1 1228848 5788 ?        Sl   10:16   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
