Node 0, zone      DMA     38     42      4     12      6      3      8      5      7      3    167 
Node 0, zone   Normal    982    146     30      1      7     21     12      7      5      1      5 
