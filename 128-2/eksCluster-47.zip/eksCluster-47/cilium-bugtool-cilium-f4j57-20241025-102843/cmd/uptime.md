 10:28:44 up 14 min,  0 users,  load average: 0.36, 0.28, 0.30
