alloc: 64.92MB (68068448 bytes)
total-alloc: 1.32GB (1416361688 bytes)
sys: 210.63MB (220865876 bytes)
lookups: 0
mallocs: 47468681
frees: 46982479
heap-alloc: 64.92MB (68068448 bytes)
heap-sys: 166.09MB (174161920 bytes)
heap-idle: 47.41MB (49709056 bytes)
heap-in-use: 118.69MB (124452864 bytes)
heap-released: 3.50MB (3670016 bytes)
heap-objects: 486202
stack-in-use: 33.91MB (35553280 bytes)
stack-sys: 33.91MB (35553280 bytes)
stack-mspan-inuse: 2.09MB (2186400 bytes)
stack-mspan-sys: 2.54MB (2660160 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1014.67KB (1039025 bytes)
gc-sys: 5.17MB (5421552 bytes)
next-gc: when heap-alloc >= 142.98MB (149925736 bytes)
last-gc: 2024-10-25 10:28:44.159113147 +0000 UTC
gc-pause-total: 15.500896ms
gc-pause: 78622
gc-pause-end: 1729852124159113147
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0004075062773510493
enable-gc: true
debug-gc: false
