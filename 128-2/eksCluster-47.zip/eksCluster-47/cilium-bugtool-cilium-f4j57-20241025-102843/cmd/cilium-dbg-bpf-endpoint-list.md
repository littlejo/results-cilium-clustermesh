IP ADDRESS         LOCAL ENDPOINT INFO
10.47.0.19:0       id=2522  sec_id=3178929 flags=0x0000 ifindex=18  mac=C2:8E:53:C7:45:68 nodemac=1A:3A:08:48:E6:CB   
10.47.0.133:0      id=2404  sec_id=3187487 flags=0x0000 ifindex=12  mac=3E:C7:F6:FB:8D:37 nodemac=8E:61:4B:70:14:E8   
10.47.0.74:0       (localhost)                                                                                        
10.47.0.158:0      id=3383  sec_id=4     flags=0x0000 ifindex=10  mac=C2:E9:B8:BD:9A:31 nodemac=F2:D2:C4:EF:5C:26     
172.31.236.187:0   (localhost)                                                                                        
172.31.206.43:0    (localhost)                                                                                        
10.47.0.236:0      id=93    sec_id=3187487 flags=0x0000 ifindex=14  mac=12:C0:69:B1:EC:96 nodemac=C2:27:81:90:52:06   
