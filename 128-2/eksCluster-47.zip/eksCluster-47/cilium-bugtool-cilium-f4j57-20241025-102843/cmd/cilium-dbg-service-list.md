ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.143.3:443 (active)     
                                         2 => 172.31.234.79:443 (active)    
2    10.100.189.120:443   ClusterIP      1 => 172.31.206.43:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.47.0.133:53 (active)       
                                         2 => 10.47.0.236:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.47.0.133:9153 (active)     
                                         2 => 10.47.0.236:9153 (active)     
5    10.100.16.19:2379    ClusterIP      1 => 10.47.0.19:2379 (active)      
