CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod936dbf00_977e_455e_8e0e_ced2b3c78715.slice/cri-containerd-62b7725e256982b818df10fae36583719d717a29905ae9470b0eca4712efef25.scope
    583      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod936dbf00_977e_455e_8e0e_ced2b3c78715.slice/cri-containerd-3e7c966ec5eb2cc96b72229b3136e51cd6faf0853c94a95f2c7b39841445039d.scope
    579      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod33e97318_c8cb_4173_9306_c34a1fefa9d3.slice/cri-containerd-ecd86eb5d44300422194a88e4603e37954ca34bd649f0aa0e5bd1f65651540e3.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod33e97318_c8cb_4173_9306_c34a1fefa9d3.slice/cri-containerd-12ccd511d80ffc9684e983cdfa1f33e912961b2a2b575b0a09c690c23a3ced95.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddfc35677_b0b6_4b81_be68_62fee73a99af.slice/cri-containerd-49b7057356d889630b29caefb42e753a594609334c0a0677c99f89546654f5db.scope
    521      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddfc35677_b0b6_4b81_be68_62fee73a99af.slice/cri-containerd-69e1a0dd78c789d75833f2213546a7d3bb4e367de448bccc9388087c5281ffcc.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod28c72c84_b28e_4a19_b6f3_e03a5e36ee4d.slice/cri-containerd-4f36245b88696c6b35834b3c1ff134ffb3c2db8641622620864852ae9ec8ea11.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod28c72c84_b28e_4a19_b6f3_e03a5e36ee4d.slice/cri-containerd-a97297335b008ffa082d552687c9a885589b8bf9124385fa36e92e3a47d84b34.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podde94e5c0_bb4e_4d17_9c60_0ba70a53ea3e.slice/cri-containerd-60e2c17bd2f5a0a55ae3aadba7a877d7dfb044217891bfdda5b19cc12c2aee58.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podde94e5c0_bb4e_4d17_9c60_0ba70a53ea3e.slice/cri-containerd-4874dab7352eff46be3e2329e4f775dff361fc282f955ab692dfccb93599cf3c.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podde94e5c0_bb4e_4d17_9c60_0ba70a53ea3e.slice/cri-containerd-95ef9b06336bc6eb250c14cf83cae1caa139768b7c7a7f7f9fce51a7140c3331.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podde94e5c0_bb4e_4d17_9c60_0ba70a53ea3e.slice/cri-containerd-f2b1bcb68d6b6202c67721f132a13d05c10cee90ef5e51eb5e272cbe55b55a03.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2d907f1e_7a29_4ed0_94be_e3a995fce6d4.slice/cri-containerd-a81f69546353280cc6f326b03d1e4239b7657838b352046666096d6b32a089e8.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2d907f1e_7a29_4ed0_94be_e3a995fce6d4.slice/cri-containerd-2704ff13608e5a1e18176ee4c2cf31dd8bed4c688cd57fa2a5707d85f76b761f.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod20e39ae1_c76b_4d36_8cd2_4125122aca1d.slice/cri-containerd-2b8b4b9d6da9713a7f887ce3ce93ed6e7f16e6189d8165f0de72a517ba78f271.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod20e39ae1_c76b_4d36_8cd2_4125122aca1d.slice/cri-containerd-c94bffe13e32e8e670c3b2a64a6f23b7abd8a7060d0f4b4d84d42f4abe9cb9e2.scope
    98       cgroup_device   multi                                          
