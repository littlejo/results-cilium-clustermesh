REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     185705    80341759   1132   bpf_host.c
Interface                 INGRESS     8158      637056     677    bpf_overlay.c
Success                   EGRESS      3905      295638     1694   bpf_host.c
Success                   EGRESS      7862      615020     53     encap.h
Success                   EGRESS      85584     11518978   1308   bpf_lxc.c
Success                   INGRESS     100586    11709230   235    trace.h
Success                   INGRESS     95684     11323906   86     l3.h
Unsupported L3 protocol   EGRESS      41        3098       1492   bpf_lxc.c
