[
  {
    "containers": [
      {
        "cgroup-id": 7535,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddfc35677_b0b6_4b81_be68_62fee73a99af.slice/cri-containerd-69e1a0dd78c789d75833f2213546a7d3bb4e367de448bccc9388087c5281ffcc.scope"
      }
    ],
    "ips": [
      "10.47.0.133"
    ],
    "name": "coredns-cc6ccd49c-dnk27",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod936dbf00_977e_455e_8e0e_ced2b3c78715.slice/cri-containerd-62b7725e256982b818df10fae36583719d717a29905ae9470b0eca4712efef25.scope"
      }
    ],
    "ips": [
      "10.47.0.236"
    ],
    "name": "coredns-cc6ccd49c-ld8gz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podde94e5c0_bb4e_4d17_9c60_0ba70a53ea3e.slice/cri-containerd-60e2c17bd2f5a0a55ae3aadba7a877d7dfb044217891bfdda5b19cc12c2aee58.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podde94e5c0_bb4e_4d17_9c60_0ba70a53ea3e.slice/cri-containerd-f2b1bcb68d6b6202c67721f132a13d05c10cee90ef5e51eb5e272cbe55b55a03.scope"
      },
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podde94e5c0_bb4e_4d17_9c60_0ba70a53ea3e.slice/cri-containerd-95ef9b06336bc6eb250c14cf83cae1caa139768b7c7a7f7f9fce51a7140c3331.scope"
      }
    ],
    "ips": [
      "10.47.0.19"
    ],
    "name": "clustermesh-apiserver-85b7cb6cdf-g6ch7",
    "namespace": "kube-system"
  }
]

