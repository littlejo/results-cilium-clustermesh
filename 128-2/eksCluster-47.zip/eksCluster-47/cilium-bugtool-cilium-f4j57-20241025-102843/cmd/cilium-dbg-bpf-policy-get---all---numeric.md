Endpoint ID: 93
Path: /sys/fs/bpf/tc/globals/cilium_policy_00093

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69915   803       0        
Allow    Egress      0          ANY          NONE         disabled    11929   121       0        


Endpoint ID: 1448
Path: /sys/fs/bpf/tc/globals/cilium_policy_01448

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2404
Path: /sys/fs/bpf/tc/globals/cilium_policy_02404

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    70824   815       0        
Allow    Egress      0          ANY          NONE         disabled    13347   137       0        


Endpoint ID: 2522
Path: /sys/fs/bpf/tc/globals/cilium_policy_02522

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3182567   30207     0        
Allow    Ingress     1          ANY          NONE         disabled    3049116   28867     0        
Allow    Egress      0          ANY          NONE         disabled    2741534   27293     0        


Endpoint ID: 3383
Path: /sys/fs/bpf/tc/globals/cilium_policy_03383

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    387594   4932      0        
Allow    Ingress     1          ANY          NONE         disabled    10122    117       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


