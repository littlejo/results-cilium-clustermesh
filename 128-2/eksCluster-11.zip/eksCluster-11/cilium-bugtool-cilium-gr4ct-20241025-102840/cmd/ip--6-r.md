fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxcc9e4c62711fd proto kernel metric 256 pref medium
fe80::/64 dev lxc3f303adc6b3d proto kernel metric 256 pref medium
fe80::/64 dev lxc70fa55ba3ae5 proto kernel metric 256 pref medium
