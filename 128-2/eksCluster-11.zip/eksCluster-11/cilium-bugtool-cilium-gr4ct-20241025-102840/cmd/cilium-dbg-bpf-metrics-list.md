REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     201569    98120015   1132   bpf_host.c
Interface                 INGRESS     8118      631839     677    bpf_overlay.c
Success                   EGRESS      3126      234687     1694   bpf_host.c
Success                   EGRESS      7072      554821     53     encap.h
Success                   EGRESS      84929     11681583   1308   bpf_lxc.c
Success                   INGRESS     93534     11443645   86     l3.h
Success                   INGRESS     99176     11884773   235    trace.h
Unsupported L3 protocol   EGRESS      37        2742       1492   bpf_lxc.c
