35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:27+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:27+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:27+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:27+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:27+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:12:27+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:12:28+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:12:28+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:28+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:28+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:12:28+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:28+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:12:33+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
61: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
64: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
71: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:12:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
72: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
75: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
458: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
461: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
462: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:20+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 124
463: sched_cls  name tail_handle_ipv4  tag b3e6c4d2644395f5  gpl
	loaded_at 2024-10-25T10:13:20+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,93
	btf_id 125
464: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:20+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,93
	btf_id 126
465: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:20+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
466: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
469: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
492: sched_cls  name tail_ipv4_ct_ingress  tag 5cdac8fc9ec645cb  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,101,74,75,102,76
	btf_id 154
493: sched_cls  name __send_drop_notify  tag 1d8672c60d8683a1  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 155
494: sched_cls  name tail_handle_ipv4  tag 552e495a4bffb96a  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,101
	btf_id 156
495: sched_cls  name tail_ipv4_to_endpoint  tag 1c54bbedc7319819  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,102,33,74,75,72,83,31,101,32,29,30
	btf_id 157
496: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,101
	btf_id 158
497: sched_cls  name handle_policy  tag a04d258f1c35b73c  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,101,74,75,102,33,72,83,31,76,67,32,29,30
	btf_id 159
499: sched_cls  name tail_handle_arp  tag a8d447ab066afb28  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,101
	btf_id 161
500: sched_cls  name cil_from_container  tag 891514f46192291b  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 101,68
	btf_id 162
501: sched_cls  name tail_handle_ipv4_cont  tag 7e7c5782fa90ab83  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,102,33,83,74,75,31,68,66,69,101,32,29,30,73
	btf_id 163
502: sched_cls  name tail_ipv4_ct_egress  tag 4d554f6a39fa1562  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,101,74,75,102,76
	btf_id 164
504: sched_cls  name tail_ipv4_ct_ingress  tag ce5778f5a6bce883  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,103,74,75,104,76
	btf_id 167
505: sched_cls  name __send_drop_notify  tag 47d84ea1ebe5aa8d  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 168
506: sched_cls  name tail_ipv4_to_endpoint  tag 19ba8ce8cff58934  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,104,33,74,75,72,94,31,103,32,29,30
	btf_id 169
507: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
510: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
511: sched_cls  name tail_handle_ipv4  tag 2088a72a64cf1976  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,103
	btf_id 170
512: sched_cls  name tail_handle_arp  tag 10c20dad0e490ca3  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,103
	btf_id 171
513: sched_cls  name tail_handle_ipv4_cont  tag 4fa02daddc0bd7ad  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,104,33,94,74,75,31,68,66,69,103,32,29,30,73
	btf_id 172
514: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,103,74,75,104,76
	btf_id 173
515: sched_cls  name handle_policy  tag f4fd5134324606f6  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,103,74,75,104,33,72,94,31,76,67,32,29,30
	btf_id 174
516: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,103
	btf_id 175
517: sched_cls  name cil_from_container  tag a3185ecd19c25480  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 103,68
	btf_id 176
518: sched_cls  name tail_ipv4_ct_egress  tag 4d554f6a39fa1562  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,107,74,75,106,76
	btf_id 178
519: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,107
	btf_id 179
520: sched_cls  name tail_ipv4_ct_ingress  tag 08bf176fdeacd76a  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,107,74,75,106,76
	btf_id 180
521: sched_cls  name __send_drop_notify  tag 6743c2d619d8f384  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 181
522: sched_cls  name tail_ipv4_to_endpoint  tag 7593ef24d5be69d5  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,106,33,74,75,72,95,31,107,32,29,30
	btf_id 182
523: sched_cls  name handle_policy  tag 28a3bb23145619a3  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,107,74,75,106,33,72,95,31,76,67,32,29,30
	btf_id 183
524: sched_cls  name tail_handle_ipv4_cont  tag 8ccbae259d053360  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,106,33,95,74,75,31,68,66,69,107,32,29,30,73
	btf_id 184
525: sched_cls  name tail_handle_ipv4  tag 140381e31628a727  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,107
	btf_id 185
526: sched_cls  name cil_from_container  tag 5ff055d6b0aa9e0e  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 107,68
	btf_id 186
528: sched_cls  name tail_handle_arp  tag 0756060e956df14d  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,107
	btf_id 188
529: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
532: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
533: sched_cls  name tail_handle_ipv4_from_host  tag eedd4834ea5bf3f0  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,110
	btf_id 191
534: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,110
	btf_id 192
535: sched_cls  name __send_drop_notify  tag 2e6ff79b628c442e  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 193
537: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 195
539: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,110
	btf_id 197
540: sched_cls  name __send_drop_notify  tag 2e6ff79b628c442e  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 199
542: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 201
544: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,111
	btf_id 203
545: sched_cls  name tail_handle_ipv4_from_host  tag eedd4834ea5bf3f0  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,111
	btf_id 204
549: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,114,67
	btf_id 209
550: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,114
	btf_id 210
551: sched_cls  name tail_handle_ipv4_from_host  tag eedd4834ea5bf3f0  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,114
	btf_id 211
553: sched_cls  name __send_drop_notify  tag 2e6ff79b628c442e  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 213
593: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:23:14+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,127
	btf_id 227
594: sched_cls  name tail_ipv4_ct_egress  tag 977e66497973feec  gpl
	loaded_at 2024-10-25T10:23:14+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,127,74,75,126,76
	btf_id 228
595: sched_cls  name __send_drop_notify  tag de05fcb6f26cd1c5  gpl
	loaded_at 2024-10-25T10:23:14+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 229
597: sched_cls  name tail_handle_ipv4  tag e3e7bccf63bbdc1d  gpl
	loaded_at 2024-10-25T10:23:14+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,127
	btf_id 231
598: sched_cls  name tail_ipv4_ct_ingress  tag a898f52fffcd4145  gpl
	loaded_at 2024-10-25T10:23:14+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,127,74,75,126,76
	btf_id 232
599: sched_cls  name handle_policy  tag c5f40b3790d5d9fd  gpl
	loaded_at 2024-10-25T10:23:14+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,127,74,75,126,33,72,125,31,76,67,32,29,30
	btf_id 233
600: sched_cls  name tail_handle_arp  tag 80fa18e78c4fe1ed  gpl
	loaded_at 2024-10-25T10:23:14+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,127
	btf_id 234
601: sched_cls  name tail_ipv4_to_endpoint  tag 21c700a925284541  gpl
	loaded_at 2024-10-25T10:23:14+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,126,33,74,75,72,125,31,127,32,29,30
	btf_id 235
602: sched_cls  name cil_from_container  tag 5ab2a4dd3516482c  gpl
	loaded_at 2024-10-25T10:23:14+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 127,68
	btf_id 236
603: sched_cls  name tail_handle_ipv4_cont  tag 4cb2292e972f77b4  gpl
	loaded_at 2024-10-25T10:23:14+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,126,33,125,74,75,31,68,66,69,127,32,29,30,73
	btf_id 237
604: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
607: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
620: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
623: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
624: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
627: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
628: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
631: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
