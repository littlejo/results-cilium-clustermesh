top - 10:28:42 up 16 min,  0 users,  load average: 0.72, 0.27, 0.18
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 31.0 us, 27.6 sy,  0.0 ni, 41.4 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1199.6 free,    880.8 used,   1755.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2787.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    798 root      20   0 1244084  19376  13700 S  20.0   0.5   0:00.03 hubble
    742 root      20   0 1240432  16640  11484 S   6.7   0.4   0:00.03 cilium-+
      1 root      20   0 1538164 280456  78204 S   0.0   7.1   0:24.07 cilium-+
    413 root      20   0 1228848   6900   3844 S   0.0   0.2   0:00.27 cilium-+
    695 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    731 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    768 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    786 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
    792 root      20   0    2208    792    716 S   0.0   0.0   0:00.00 timeout
