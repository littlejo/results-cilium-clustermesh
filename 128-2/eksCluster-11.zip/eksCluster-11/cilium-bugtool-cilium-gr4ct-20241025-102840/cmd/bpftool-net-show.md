xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 549
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 542
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 537
cilium_host(4) clsact/egress cil_from_host-cilium_host id 534
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 464
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 465
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 517
lxcc9e4c62711fd(9) clsact/ingress cil_from_container-lxcc9e4c62711fd id 500
lxc3f303adc6b3d(11) clsact/ingress cil_from_container-lxc3f303adc6b3d id 526
lxc70fa55ba3ae5(15) clsact/ingress cil_from_container-lxc70fa55ba3ae5 id 602

flow_dissector:

netfilter:

