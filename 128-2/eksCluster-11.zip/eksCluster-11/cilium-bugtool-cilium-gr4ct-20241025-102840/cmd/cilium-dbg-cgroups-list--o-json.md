[
  {
    "containers": [
      {
        "cgroup-id": 8306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb1b43911_9b9f_449e_af98_4b5de707025c.slice/cri-containerd-1516890f46107ca6d30e9c75e200fd2054ef61a4aee0d33ee8620e0ea8b828e7.scope"
      },
      {
        "cgroup-id": 8222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb1b43911_9b9f_449e_af98_4b5de707025c.slice/cri-containerd-6f31aeb035a628016d806cc79e1e0b466253b042a99f559de886c0f1384358de.scope"
      },
      {
        "cgroup-id": 8390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb1b43911_9b9f_449e_af98_4b5de707025c.slice/cri-containerd-532c268a7f8847a4f542cda0d1b713c802f88b86e8a3cf89ef3926b51db8a953.scope"
      }
    ],
    "ips": [
      "10.11.0.185"
    ],
    "name": "clustermesh-apiserver-67769f67d8-7k4xb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6710,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10885e0d_5a00_4ce8_b48c_1142e6ff447b.slice/cri-containerd-5f5b8c33bd54da34bd89305b27ab58a7167bf533c7c728fa35a91afc6e57545e.scope"
      }
    ],
    "ips": [
      "10.11.0.146"
    ],
    "name": "coredns-cc6ccd49c-f4cnk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6878,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa88c25d_692e_45d5_a1a9_db4da0237613.slice/cri-containerd-65dfef4f257bad689c3edc920cb9e5a9432ef30bc904b6ec2753ae6110ce37d4.scope"
      }
    ],
    "ips": [
      "10.11.0.143"
    ],
    "name": "coredns-cc6ccd49c-mxps6",
    "namespace": "kube-system"
  }
]

