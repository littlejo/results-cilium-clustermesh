1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:19:29:90:5c:e1 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.197.79/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2634sec preferred_lft 2634sec
    inet6 fe80::819:29ff:fe90:5ce1/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:5e:14:9c:47:6e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f85e:14ff:fe9c:476e/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:6d:32:da:6a:62 brd ff:ff:ff:ff:ff:ff
    inet 10.11.0.96/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::3c6d:32ff:feda:6a62/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether a2:0e:c7:38:98:30 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a00e:c7ff:fe38:9830/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:18:20:46:09:90 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::3018:20ff:fe46:990/64 scope link 
       valid_lft forever preferred_lft forever
9: lxcc9e4c62711fd@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:af:82:92:8b:fe brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::f4af:82ff:fe92:8bfe/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc3f303adc6b3d@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:78:33:b0:d3:e2 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::4878:33ff:feb0:d3e2/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc70fa55ba3ae5@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:3c:6a:a3:67:c8 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::743c:6aff:fea3:67c8/64 scope link 
       valid_lft forever preferred_lft forever
