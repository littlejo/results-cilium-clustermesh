ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.179.197:443 (active)   
                                          2 => 172.31.246.148:443 (active)   
2    10.100.64.144:443     ClusterIP      1 => 172.31.197.79:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.11.0.146:53 (active)       
                                          2 => 10.11.0.143:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.11.0.146:9153 (active)     
                                          2 => 10.11.0.143:9153 (active)     
5    10.100.115.218:2379   ClusterIP      1 => 10.11.0.185:2379 (active)     
