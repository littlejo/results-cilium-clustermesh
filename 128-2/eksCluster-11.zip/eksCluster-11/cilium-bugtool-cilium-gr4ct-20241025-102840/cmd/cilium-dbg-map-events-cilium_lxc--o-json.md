{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:15.736Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.197.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:15.736Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:19.058Z",
  "value": "id=1482  sec_id=824053 flags=0x0000 ifindex=9   mac=92:03:D6:EB:A2:A8 nodemac=F6:AF:82:92:8B:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:22.476Z",
  "value": "id=1778  sec_id=4     flags=0x0000 ifindex=7   mac=7A:3E:2D:97:EC:99 nodemac=32:18:20:46:09:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:22.489Z",
  "value": "id=3065  sec_id=824053 flags=0x0000 ifindex=11  mac=9A:7E:78:18:DF:12 nodemac=4A:78:33:B0:D3:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:22.553Z",
  "value": "id=1482  sec_id=824053 flags=0x0000 ifindex=9   mac=92:03:D6:EB:A2:A8 nodemac=F6:AF:82:92:8B:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:22.614Z",
  "value": "id=1778  sec_id=4     flags=0x0000 ifindex=7   mac=7A:3E:2D:97:EC:99 nodemac=32:18:20:46:09:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:22.715Z",
  "value": "id=3065  sec_id=824053 flags=0x0000 ifindex=11  mac=9A:7E:78:18:DF:12 nodemac=4A:78:33:B0:D3:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.046Z",
  "value": "id=3065  sec_id=824053 flags=0x0000 ifindex=11  mac=9A:7E:78:18:DF:12 nodemac=4A:78:33:B0:D3:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.047Z",
  "value": "id=1778  sec_id=4     flags=0x0000 ifindex=7   mac=7A:3E:2D:97:EC:99 nodemac=32:18:20:46:09:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.048Z",
  "value": "id=1482  sec_id=824053 flags=0x0000 ifindex=9   mac=92:03:D6:EB:A2:A8 nodemac=F6:AF:82:92:8B:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.079Z",
  "value": "id=1008  sec_id=812112 flags=0x0000 ifindex=13  mac=C6:26:5A:DB:EC:E7 nodemac=EA:AA:57:9E:12:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.079Z",
  "value": "id=1008  sec_id=812112 flags=0x0000 ifindex=13  mac=C6:26:5A:DB:EC:E7 nodemac=EA:AA:57:9E:12:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:39.046Z",
  "value": "id=3065  sec_id=824053 flags=0x0000 ifindex=11  mac=9A:7E:78:18:DF:12 nodemac=4A:78:33:B0:D3:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:39.046Z",
  "value": "id=1008  sec_id=812112 flags=0x0000 ifindex=13  mac=C6:26:5A:DB:EC:E7 nodemac=EA:AA:57:9E:12:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:39.046Z",
  "value": "id=1778  sec_id=4     flags=0x0000 ifindex=7   mac=7A:3E:2D:97:EC:99 nodemac=32:18:20:46:09:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:39.047Z",
  "value": "id=1482  sec_id=824053 flags=0x0000 ifindex=9   mac=92:03:D6:EB:A2:A8 nodemac=F6:AF:82:92:8B:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:14.240Z",
  "value": "id=587   sec_id=812112 flags=0x0000 ifindex=15  mac=9A:60:85:C2:8D:5D nodemac=76:3C:6A:A3:67:C8"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.11.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:24.805Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:35.439Z",
  "value": "id=3065  sec_id=824053 flags=0x0000 ifindex=11  mac=9A:7E:78:18:DF:12 nodemac=4A:78:33:B0:D3:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:35.439Z",
  "value": "id=587   sec_id=812112 flags=0x0000 ifindex=15  mac=9A:60:85:C2:8D:5D nodemac=76:3C:6A:A3:67:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:35.440Z",
  "value": "id=1778  sec_id=4     flags=0x0000 ifindex=7   mac=7A:3E:2D:97:EC:99 nodemac=32:18:20:46:09:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:35.440Z",
  "value": "id=1482  sec_id=824053 flags=0x0000 ifindex=9   mac=92:03:D6:EB:A2:A8 nodemac=F6:AF:82:92:8B:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:36.437Z",
  "value": "id=3065  sec_id=824053 flags=0x0000 ifindex=11  mac=9A:7E:78:18:DF:12 nodemac=4A:78:33:B0:D3:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:36.437Z",
  "value": "id=587   sec_id=812112 flags=0x0000 ifindex=15  mac=9A:60:85:C2:8D:5D nodemac=76:3C:6A:A3:67:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:36.437Z",
  "value": "id=1778  sec_id=4     flags=0x0000 ifindex=7   mac=7A:3E:2D:97:EC:99 nodemac=32:18:20:46:09:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:36.438Z",
  "value": "id=1482  sec_id=824053 flags=0x0000 ifindex=9   mac=92:03:D6:EB:A2:A8 nodemac=F6:AF:82:92:8B:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:37.438Z",
  "value": "id=1482  sec_id=824053 flags=0x0000 ifindex=9   mac=92:03:D6:EB:A2:A8 nodemac=F6:AF:82:92:8B:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:37.438Z",
  "value": "id=1778  sec_id=4     flags=0x0000 ifindex=7   mac=7A:3E:2D:97:EC:99 nodemac=32:18:20:46:09:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:37.438Z",
  "value": "id=3065  sec_id=824053 flags=0x0000 ifindex=11  mac=9A:7E:78:18:DF:12 nodemac=4A:78:33:B0:D3:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:37.438Z",
  "value": "id=587   sec_id=812112 flags=0x0000 ifindex=15  mac=9A:60:85:C2:8D:5D nodemac=76:3C:6A:A3:67:C8"
}

