Endpoint ID: 587
Path: /sys/fs/bpf/tc/globals/cilium_policy_00587

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3823990   34781     0        
Allow    Ingress     1          ANY          NONE         disabled    2402857   23572     0        
Allow    Egress      0          ANY          NONE         disabled    3478560   32544     0        


Endpoint ID: 1482
Path: /sys/fs/bpf/tc/globals/cilium_policy_01482

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    89252   1023      0        
Allow    Egress      0          ANY          NONE         disabled    13486   142       0        


Endpoint ID: 1778
Path: /sys/fs/bpf/tc/globals/cilium_policy_01778

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    442182   5655      0        
Allow    Ingress     1          ANY          NONE         disabled    12542    145       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3065
Path: /sys/fs/bpf/tc/globals/cilium_policy_03065

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    89582   1028      0        
Allow    Egress      0          ANY          NONE         disabled    15326   162       0        


Endpoint ID: 3740
Path: /sys/fs/bpf/tc/globals/cilium_policy_03740

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


