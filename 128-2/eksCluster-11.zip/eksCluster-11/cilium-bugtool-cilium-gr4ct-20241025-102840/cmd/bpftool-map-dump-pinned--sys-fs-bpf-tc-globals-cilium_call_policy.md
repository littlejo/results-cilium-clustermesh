key: 4b 02 00 00  value: 57 02 00 00
key: ca 05 00 00  value: f1 01 00 00
key: f2 06 00 00  value: 03 02 00 00
key: f9 0b 00 00  value: 0b 02 00 00
Found 4 elements
