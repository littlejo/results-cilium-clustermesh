alloc: 110.76MB (116136600 bytes)
total-alloc: 1.29GB (1387595280 bytes)
sys: 210.45MB (220669268 bytes)
lookups: 0
mallocs: 47028088
frees: 45887244
heap-alloc: 110.76MB (116136600 bytes)
heap-sys: 165.67MB (173719552 bytes)
heap-idle: 37.92MB (39763968 bytes)
heap-in-use: 127.75MB (133955584 bytes)
heap-released: 2.01MB (2105344 bytes)
heap-objects: 1140844
stack-in-use: 34.28MB (35946496 bytes)
stack-sys: 34.28MB (35946496 bytes)
stack-mspan-inuse: 2.06MB (2163360 bytes)
stack-mspan-sys: 2.46MB (2578560 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 923.76KB (945929 bytes)
gc-sys: 5.22MB (5474464 bytes)
next-gc: when heap-alloc >= 147.50MB (154664072 bytes)
last-gc: 2024-10-25 10:28:42.640981129 +0000 UTC
gc-pause-total: 12.051661ms
gc-pause: 277359
gc-pause-end: 1729852122640981129
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00035568816461607945
enable-gc: true
debug-gc: false
