 10:28:41 up 16 min,  0 users,  load average: 0.72, 0.27, 0.18
