USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         742  0.0  0.4 1240176 16640 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         756  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         758  0.0  0.0   3728   488 ?        R    10:28   0:00  \_ bash -c hostname
root         731  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         695  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  2.5  7.1 1538164 280456 ?      Ssl  10:13   0:24 cilium-agent --config-dir=/tmp/cilium/config-map
root         413  0.0  0.1 1228848 6900 ?        Sl   10:13   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
