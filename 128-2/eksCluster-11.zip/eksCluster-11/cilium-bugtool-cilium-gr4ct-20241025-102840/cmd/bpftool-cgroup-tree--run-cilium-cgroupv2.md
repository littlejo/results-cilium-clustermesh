CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10885e0d_5a00_4ce8_b48c_1142e6ff447b.slice/cri-containerd-20ed9a622c48e439e0af11103f119e251eaf2f6e8dd60827fe71b9ca728852c9.scope
    461      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10885e0d_5a00_4ce8_b48c_1142e6ff447b.slice/cri-containerd-5f5b8c33bd54da34bd89305b27ab58a7167bf533c7c728fa35a91afc6e57545e.scope
    469      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa88c25d_692e_45d5_a1a9_db4da0237613.slice/cri-containerd-59ee6a64a52cc097b8d6f3d2c80fbbafe78de3d0134f9c7f72257a814b136275.scope
    510      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa88c25d_692e_45d5_a1a9_db4da0237613.slice/cri-containerd-65dfef4f257bad689c3edc920cb9e5a9432ef30bc904b6ec2753ae6110ce37d4.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode06d984f_c6c1_439b_9574_29182a49781f.slice/cri-containerd-24cf7f8ccc88524015cb525def6b8a87beee221f851decd85a9895cbabbe7ee2.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode06d984f_c6c1_439b_9574_29182a49781f.slice/cri-containerd-73960a68066b644b5d7a638812da564db68f5942d7f3eac9e931bed89db4411b.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf8768311_4f04_4b30_b918_45c716c7e3d4.slice/cri-containerd-6a697bbb234cd13d3a77f529ddd06538106150434c97b3772618950899836d2d.scope
    71       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf8768311_4f04_4b30_b918_45c716c7e3d4.slice/cri-containerd-439778b88568142e58b14ecd15bd36ba93ba394c91fd58462d692773f3a73be3.scope
    64       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb1b43911_9b9f_449e_af98_4b5de707025c.slice/cri-containerd-6f31aeb035a628016d806cc79e1e0b466253b042a99f559de886c0f1384358de.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb1b43911_9b9f_449e_af98_4b5de707025c.slice/cri-containerd-6e7c9dfecb99c1563c31069b31a20533843885f92e21a362ea9487a23e9d2f58.scope
    607      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb1b43911_9b9f_449e_af98_4b5de707025c.slice/cri-containerd-532c268a7f8847a4f542cda0d1b713c802f88b86e8a3cf89ef3926b51db8a953.scope
    631      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb1b43911_9b9f_449e_af98_4b5de707025c.slice/cri-containerd-1516890f46107ca6d30e9c75e200fd2054ef61a4aee0d33ee8620e0ea8b828e7.scope
    627      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9cab0be_d1bf_4780_88b2_cf56dd553ba1.slice/cri-containerd-2eb0cde7801cf4b8d2235786e908923eef16dc8f311e7e35eb905a676e663299.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9cab0be_d1bf_4780_88b2_cf56dd553ba1.slice/cri-containerd-14db6c61432e7557fa60cdf8b3368e909aa7865c75f720a5a756a2cc15a77ee0.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8aaea8dc_a3cc_4146_b2c9_ae2fc3f06e54.slice/cri-containerd-176f90ff4cf17d0f9bef58ad33fd1ab212bb42b8686d670dc3822af5b985547e.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8aaea8dc_a3cc_4146_b2c9_ae2fc3f06e54.slice/cri-containerd-a418d829aae19f67bb670606036248dd6d91720fdd422548c2d261563a60520d.scope
    56       cgroup_device   multi                                          
