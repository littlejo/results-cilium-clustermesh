IP ADDRESS        LOCAL ENDPOINT INFO
10.11.0.96:0      (localhost)                                                                                       
10.11.0.146:0     id=1482  sec_id=824053 flags=0x0000 ifindex=9   mac=92:03:D6:EB:A2:A8 nodemac=F6:AF:82:92:8B:FE   
172.31.197.79:0   (localhost)                                                                                       
10.11.0.143:0     id=3065  sec_id=824053 flags=0x0000 ifindex=11  mac=9A:7E:78:18:DF:12 nodemac=4A:78:33:B0:D3:E2   
10.11.0.185:0     id=587   sec_id=812112 flags=0x0000 ifindex=15  mac=9A:60:85:C2:8D:5D nodemac=76:3C:6A:A3:67:C8   
10.11.0.129:0     id=1778  sec_id=4     flags=0x0000 ifindex=7   mac=7A:3E:2D:97:EC:99 nodemac=32:18:20:46:09:90    
