Node 0, zone      DMA      5      6      4      4     10      9      8      7      6      6    222 
Node 0, zone   Normal    178      9      1      0      2      3      9      1      2      3     54 
