32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:27+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:27+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:27+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
58: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
61: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
62: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
65: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
70: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
73: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
76: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:15:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
77: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
80: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
444: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:16:32+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 113
445: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:16:32+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 114
446: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:16:32+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 115
447: sched_cls  name tail_handle_ipv4  tag 68053a3914574f63  gpl
	loaded_at 2024-10-25T10:16:32+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 116
449: sched_cls  name __send_drop_notify  tag 29a7a0f73cfae75c  gpl
	loaded_at 2024-10-25T10:16:33+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 119
450: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:16:33+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,91
	btf_id 120
451: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:16:33+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 121
453: sched_cls  name tail_handle_ipv4_from_host  tag 2b75b56007934e9a  gpl
	loaded_at 2024-10-25T10:16:33+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,91
	btf_id 123
454: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:16:33+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,91
	btf_id 124
456: sched_cls  name tail_handle_ipv4_from_host  tag 2b75b56007934e9a  gpl
	loaded_at 2024-10-25T10:16:33+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,94
	btf_id 127
457: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:16:33+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,94
	btf_id 128
459: sched_cls  name __send_drop_notify  tag 29a7a0f73cfae75c  gpl
	loaded_at 2024-10-25T10:16:33+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 130
461: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:16:33+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 132
462: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:16:33+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,96
	btf_id 134
464: sched_cls  name __send_drop_notify  tag 29a7a0f73cfae75c  gpl
	loaded_at 2024-10-25T10:16:33+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 136
467: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:16:33+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,96,67
	btf_id 139
468: sched_cls  name tail_handle_ipv4_from_host  tag 2b75b56007934e9a  gpl
	loaded_at 2024-10-25T10:16:33+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,96
	btf_id 140
480: sched_cls  name __send_drop_notify  tag 11442a97202a29a1  gpl
	loaded_at 2024-10-25T10:16:34+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 154
481: sched_cls  name cil_from_container  tag 7db4e57d68c60920  gpl
	loaded_at 2024-10-25T10:16:34+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 99,68
	btf_id 155
482: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:16:34+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,99,74,75,100,76
	btf_id 156
483: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:16:34+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,99
	btf_id 157
485: sched_cls  name tail_ipv4_ct_ingress  tag fc9c02d38ac524e0  gpl
	loaded_at 2024-10-25T10:16:34+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,99,74,75,100,76
	btf_id 159
486: sched_cls  name tail_handle_ipv4_cont  tag 19c0cba9179efe32  gpl
	loaded_at 2024-10-25T10:16:34+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,100,33,90,74,75,31,68,66,69,99,32,29,30,73
	btf_id 160
487: sched_cls  name tail_ipv4_to_endpoint  tag a73760e4b62daa7b  gpl
	loaded_at 2024-10-25T10:16:34+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,100,33,74,75,72,90,31,99,32,29,30
	btf_id 161
488: sched_cls  name tail_handle_ipv4  tag 3196f90ddb2d98eb  gpl
	loaded_at 2024-10-25T10:16:34+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,99
	btf_id 162
489: sched_cls  name tail_handle_arp  tag ce5e63855c2e865f  gpl
	loaded_at 2024-10-25T10:16:34+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,99
	btf_id 163
490: sched_cls  name handle_policy  tag 305189e51bef5227  gpl
	loaded_at 2024-10-25T10:16:34+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,99,74,75,100,33,72,90,31,76,67,32,29,30
	btf_id 164
491: sched_cls  name tail_handle_ipv4  tag 79a702f0fea5a12d  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,103
	btf_id 166
492: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,103
	btf_id 167
493: sched_cls  name handle_policy  tag e5f3b7d9edb6580f  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,103,74,75,102,33,72,101,31,76,67,32,29,30
	btf_id 168
494: sched_cls  name tail_ipv4_to_endpoint  tag 388fc64cfe24a7fb  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,102,33,74,75,72,101,31,103,32,29,30
	btf_id 169
495: sched_cls  name tail_handle_ipv4_cont  tag 82134816bcc47271  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,102,33,101,74,75,31,68,66,69,103,32,29,30,73
	btf_id 170
496: sched_cls  name tail_handle_arp  tag 8d718d57ee4a819e  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,103
	btf_id 171
497: sched_cls  name tail_ipv4_ct_egress  tag 93dc88c3f0f52ca8  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,103,74,75,102,76
	btf_id 172
499: sched_cls  name __send_drop_notify  tag 0e68b28ab35718b9  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 174
500: sched_cls  name tail_ipv4_ct_ingress  tag 3697a38c70a4976d  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,103,74,75,102,76
	btf_id 175
501: sched_cls  name cil_from_container  tag 25186fce2cbfe585  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 103,68
	btf_id 176
502: sched_cls  name tail_handle_arp  tag 650d7396096251bd  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,105
	btf_id 178
503: sched_cls  name cil_from_container  tag e7ff69649247c3cb  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 105,68
	btf_id 179
504: sched_cls  name __send_drop_notify  tag 9d89963f25d73992  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 180
505: sched_cls  name tail_ipv4_ct_ingress  tag 50beb274b4ecdc5d  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,105,74,75,106,76
	btf_id 181
506: sched_cls  name tail_handle_ipv4_cont  tag 25db5f08302fd28b  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,106,33,104,74,75,31,68,66,69,105,32,29,30,73
	btf_id 182
507: sched_cls  name tail_ipv4_to_endpoint  tag 0ef76233dadff510  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,106,33,74,75,72,104,31,105,32,29,30
	btf_id 183
508: sched_cls  name tail_ipv4_ct_egress  tag 93dc88c3f0f52ca8  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,105,74,75,106,76
	btf_id 184
509: sched_cls  name tail_handle_ipv4  tag f83701c142f71869  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,105
	btf_id 185
510: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,105
	btf_id 186
511: sched_cls  name handle_policy  tag ff7f4b2a769089a9  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,105,74,75,106,33,72,104,31,76,67,32,29,30
	btf_id 187
513: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
516: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
517: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
520: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
521: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
524: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:37+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
525: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
528: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:37+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
568: sched_cls  name tail_handle_ipv4_cont  tag bd6c2e0d5fd35c44  gpl
	loaded_at 2024-10-25T10:22:59+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,123,33,121,74,75,31,68,66,69,122,32,29,30,73
	btf_id 203
569: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:59+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,122
	btf_id 204
571: sched_cls  name cil_from_container  tag 3d14ec41ae29c622  gpl
	loaded_at 2024-10-25T10:22:59+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 122,68
	btf_id 206
572: sched_cls  name tail_ipv4_ct_egress  tag fb670b0b78fb0ed7  gpl
	loaded_at 2024-10-25T10:22:59+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,122,74,75,123,76
	btf_id 207
573: sched_cls  name __send_drop_notify  tag 1e9d019324433f59  gpl
	loaded_at 2024-10-25T10:22:59+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 208
574: sched_cls  name tail_ipv4_to_endpoint  tag b846fd97f84e1bfa  gpl
	loaded_at 2024-10-25T10:22:59+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,123,33,74,75,72,121,31,122,32,29,30
	btf_id 209
575: sched_cls  name tail_handle_arp  tag f5ea6408f9f7895b  gpl
	loaded_at 2024-10-25T10:22:59+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,122
	btf_id 210
576: sched_cls  name handle_policy  tag 4d0749c773ddc7be  gpl
	loaded_at 2024-10-25T10:22:59+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,122,74,75,123,33,72,121,31,76,67,32,29,30
	btf_id 211
577: sched_cls  name tail_handle_ipv4  tag 1030646c387833b9  gpl
	loaded_at 2024-10-25T10:22:59+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,122
	btf_id 212
578: sched_cls  name tail_ipv4_ct_ingress  tag 5bcf60eba89eac99  gpl
	loaded_at 2024-10-25T10:22:59+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,122,74,75,123,76
	btf_id 213
579: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
582: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
595: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
598: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
599: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
602: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
603: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
606: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
