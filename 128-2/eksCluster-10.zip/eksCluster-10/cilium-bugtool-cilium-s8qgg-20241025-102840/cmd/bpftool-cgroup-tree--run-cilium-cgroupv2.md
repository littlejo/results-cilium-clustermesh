CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod87f6bd74_7de9_45f7_9072_ebd2cf68fc14.slice/cri-containerd-7a97b36699ea18d3cde310080484c1065e973c7f94f4d4f1050aa9f6b37d21e1.scope
    520      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod87f6bd74_7de9_45f7_9072_ebd2cf68fc14.slice/cri-containerd-7f3b38ba66f76c23d13aa1e33fae5f985c5dce3c3d6ab6667be47ce8c5909aaf.scope
    528      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode8372243_4206_4d3d_9153_f2ac06f7d4e2.slice/cri-containerd-c0dec8ee13db4fe74ad7f5f2828890cf3068c5ae80cc6204cbd7dba559163251.scope
    76       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode8372243_4206_4d3d_9153_f2ac06f7d4e2.slice/cri-containerd-1f58fa94038879a8b53b1d56b2bf65c98b63ef88d0408b3020c6083c8b0feffe.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ae3b891_32d8_402a_8a37_aa2d243b285a.slice/cri-containerd-5daeaab551e2597f279778015bf382a87eda382a15811e8898534da6c5622f7a.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ae3b891_32d8_402a_8a37_aa2d243b285a.slice/cri-containerd-4762630e3a56cac07c6321ec68f5b0d6be0515322487acdc7c1060bc0e122109.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2697b814_0da6_41a2_a05e_89555848d82a.slice/cri-containerd-9c2e28c258ab3d6224391c0246c9a6f2f7969b0d3817e9cb1389cf1e237ee09c.scope
    524      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2697b814_0da6_41a2_a05e_89555848d82a.slice/cri-containerd-b95beb4f285cc80a49ef83c84036a8803bb87a3f35564eb0e574b11c82845f4e.scope
    516      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4d465ffb_9ea2_4ea6_8d6e_7ffb1bfe6177.slice/cri-containerd-bc223efd08e36a7bf0fb8ae2b4bb3051c1d19dc9c153d761fb115e1942b283e6.scope
    73       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4d465ffb_9ea2_4ea6_8d6e_7ffb1bfe6177.slice/cri-containerd-8630c41880f48f33e57021f78f91c46f97bd3540d90f020ffc2bc4d53c553e0a.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode24fd857_543b_4680_b67e_2d11d72cf2d3.slice/cri-containerd-9b81310a19ba8e43b863e5db2084e97b702c5b95617b51c81db5c942f832c1be.scope
    598      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode24fd857_543b_4680_b67e_2d11d72cf2d3.slice/cri-containerd-ae7498f110e3b3893cd31ee85951c54d286aee580db8a533f637b55cf449c19e.scope
    606      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode24fd857_543b_4680_b67e_2d11d72cf2d3.slice/cri-containerd-b7d15fdcde70d71eea98b1d3f802c1a483e4a4c1b561ad85166abadaf79d315b.scope
    582      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode24fd857_543b_4680_b67e_2d11d72cf2d3.slice/cri-containerd-5f9c861e3cf12dea9946ed962cdbe91db20f0b4ce2e24da512a3d3e28c7230a8.scope
    602      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6a326308_5448_4637_9fde_913ccd76d690.slice/cri-containerd-2d961390f7e25b22abe1d47d7e851474c56bcf9cd636a888245812d45f16f94b.scope
    61       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6a326308_5448_4637_9fde_913ccd76d690.slice/cri-containerd-d5772da81682f2c4c450ef35f732669ae1f8916d80f0d7b8f2ab1a3caf80cdaa.scope
    80       cgroup_device   multi                                          
