alloc: 135.88MB (142481416 bytes)
total-alloc: 1.31GB (1408041992 bytes)
sys: 206.45MB (216474964 bytes)
lookups: 0
mallocs: 47456003
frees: 46042333
heap-alloc: 135.88MB (142481416 bytes)
heap-sys: 160.39MB (168181760 bytes)
heap-idle: 10.02MB (10510336 bytes)
heap-in-use: 150.37MB (157671424 bytes)
heap-released: 2.93MB (3072000 bytes)
heap-objects: 1413670
stack-in-use: 35.44MB (37158912 bytes)
stack-sys: 35.44MB (37158912 bytes)
stack-mspan-inuse: 2.35MB (2464000 bytes)
stack-mspan-sys: 2.47MB (2594880 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 947.99KB (970745 bytes)
gc-sys: 5.31MB (5572648 bytes)
next-gc: when heap-alloc >= 145.87MB (152951272 bytes)
last-gc: 2024-10-25 10:28:32.63017906 +0000 UTC
gc-pause-total: 13.596849ms
gc-pause: 60637
gc-pause-end: 1729852112630179060
num-gc: 71
num-forced-gc: 0
gc-cpu-fraction: 0.0003339689577369922
enable-gc: true
debug-gc: false
