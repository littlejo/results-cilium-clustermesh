1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:08:c7:b9:c6:95 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.155.27/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2693sec preferred_lft 2693sec
    inet6 fe80::408:c7ff:feb9:c695/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:fd:05:09:d2:3b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::7cfd:5ff:fe09:d23b/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:90:f8:11:b1:00 brd ff:ff:ff:ff:ff:ff
    inet 10.10.0.102/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::2490:f8ff:fe11:b100/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether e2:0b:4f:f3:81:9f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e00b:4fff:fef3:819f/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:d0:81:c0:61:f9 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c4d0:81ff:fec0:61f9/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc02a2ce637f4d@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:f5:dc:97:b2:66 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::7cf5:dcff:fe97:b266/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc6e75a4b3b21a@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:0e:c8:bc:20:d8 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c0e:c8ff:febc:20d8/64 scope link 
       valid_lft forever preferred_lft forever
15: lxcafced212f977@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:82:ab:0b:f5:da brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::fc82:abff:fe0b:f5da/64 scope link 
       valid_lft forever preferred_lft forever
