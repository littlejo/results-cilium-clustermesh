key: 48 00 00 00  value: ed 01 00 00
key: 66 04 00 00  value: 40 02 00 00
key: a3 0a 00 00  value: ea 01 00 00
key: 00 0d 00 00  value: ff 01 00 00
Found 4 elements
