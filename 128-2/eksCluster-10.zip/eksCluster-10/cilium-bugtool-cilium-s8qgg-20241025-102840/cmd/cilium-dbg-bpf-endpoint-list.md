IP ADDRESS        LOCAL ENDPOINT INFO
10.10.0.124:0     id=1126  sec_id=785668 flags=0x0000 ifindex=15  mac=AA:C8:1F:3F:1B:4E nodemac=FE:82:AB:0B:F5:DA   
10.10.0.104:0     id=2723  sec_id=4     flags=0x0000 ifindex=7   mac=6A:38:06:55:EA:4D nodemac=C6:D0:81:C0:61:F9    
10.10.0.102:0     (localhost)                                                                                       
172.31.155.27:0   (localhost)                                                                                       
10.10.0.137:0     id=72    sec_id=741304 flags=0x0000 ifindex=9   mac=EE:97:54:4B:20:5D nodemac=7E:F5:DC:97:B2:66   
10.10.0.95:0      id=3328  sec_id=741304 flags=0x0000 ifindex=11  mac=1A:AC:9A:33:6B:06 nodemac=0E:0E:C8:BC:20:D8   
