USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         643  0.0  0.4 1240432 15848 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         661  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         623  0.0  0.0 1228744 3780 ?        Ssl  10:28   0:00 /bin/gops memstats 1
root         598  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops stats 1
root         591  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops stack 1
root           1  2.9  6.9 1472560 274736 ?      Ssl  10:16   0:21 cilium-agent --config-dir=/tmp/cilium/config-map
root         391  0.0  0.1 1228848 6656 ?        Sl   10:16   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
