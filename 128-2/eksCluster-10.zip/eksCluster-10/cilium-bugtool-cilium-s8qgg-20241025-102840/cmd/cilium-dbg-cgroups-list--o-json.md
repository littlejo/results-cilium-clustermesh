[
  {
    "containers": [
      {
        "cgroup-id": 8291,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode24fd857_543b_4680_b67e_2d11d72cf2d3.slice/cri-containerd-5f9c861e3cf12dea9946ed962cdbe91db20f0b4ce2e24da512a3d3e28c7230a8.scope"
      },
      {
        "cgroup-id": 8207,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode24fd857_543b_4680_b67e_2d11d72cf2d3.slice/cri-containerd-9b81310a19ba8e43b863e5db2084e97b702c5b95617b51c81db5c942f832c1be.scope"
      },
      {
        "cgroup-id": 8375,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode24fd857_543b_4680_b67e_2d11d72cf2d3.slice/cri-containerd-ae7498f110e3b3893cd31ee85951c54d286aee580db8a533f637b55cf449c19e.scope"
      }
    ],
    "ips": [
      "10.10.0.124"
    ],
    "name": "clustermesh-apiserver-db5ccd4fb-zqxjd",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6779,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2697b814_0da6_41a2_a05e_89555848d82a.slice/cri-containerd-9c2e28c258ab3d6224391c0246c9a6f2f7969b0d3817e9cb1389cf1e237ee09c.scope"
      }
    ],
    "ips": [
      "10.10.0.137"
    ],
    "name": "coredns-cc6ccd49c-7fxhf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6863,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod87f6bd74_7de9_45f7_9072_ebd2cf68fc14.slice/cri-containerd-7f3b38ba66f76c23d13aa1e33fae5f985c5dce3c3d6ab6667be47ce8c5909aaf.scope"
      }
    ],
    "ips": [
      "10.10.0.95"
    ],
    "name": "coredns-cc6ccd49c-p4m4t",
    "namespace": "kube-system"
  }
]

