 10:28:41 up 15 min,  0 users,  load average: 0.02, 0.15, 0.16
