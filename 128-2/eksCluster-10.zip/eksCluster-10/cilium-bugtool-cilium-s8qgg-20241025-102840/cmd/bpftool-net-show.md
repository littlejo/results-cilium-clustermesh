xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 467
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 461
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 451
cilium_host(4) clsact/egress cil_from_host-cilium_host id 450
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 444
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 445
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 481
lxc02a2ce637f4d(9) clsact/ingress cil_from_container-lxc02a2ce637f4d id 501
lxc6e75a4b3b21a(11) clsact/ingress cil_from_container-lxc6e75a4b3b21a id 503
lxcafced212f977(15) clsact/ingress cil_from_container-lxcafced212f977 id 571

flow_dissector:

netfilter:

