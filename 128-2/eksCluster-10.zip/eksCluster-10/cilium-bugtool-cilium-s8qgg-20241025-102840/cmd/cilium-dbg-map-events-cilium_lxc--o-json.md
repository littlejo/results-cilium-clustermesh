{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:30.315Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.155.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:30.315Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:34.849Z",
  "value": "id=2723  sec_id=4     flags=0x0000 ifindex=7   mac=6A:38:06:55:EA:4D nodemac=C6:D0:81:C0:61:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:34.880Z",
  "value": "id=2723  sec_id=4     flags=0x0000 ifindex=7   mac=6A:38:06:55:EA:4D nodemac=C6:D0:81:C0:61:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:36.506Z",
  "value": "id=2723  sec_id=4     flags=0x0000 ifindex=7   mac=6A:38:06:55:EA:4D nodemac=C6:D0:81:C0:61:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:36.584Z",
  "value": "id=72    sec_id=741304 flags=0x0000 ifindex=9   mac=EE:97:54:4B:20:5D nodemac=7E:F5:DC:97:B2:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:36.626Z",
  "value": "id=3328  sec_id=741304 flags=0x0000 ifindex=11  mac=1A:AC:9A:33:6B:06 nodemac=0E:0E:C8:BC:20:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:37.507Z",
  "value": "id=72    sec_id=741304 flags=0x0000 ifindex=9   mac=EE:97:54:4B:20:5D nodemac=7E:F5:DC:97:B2:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:37.508Z",
  "value": "id=3328  sec_id=741304 flags=0x0000 ifindex=11  mac=1A:AC:9A:33:6B:06 nodemac=0E:0E:C8:BC:20:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:37.508Z",
  "value": "id=2723  sec_id=4     flags=0x0000 ifindex=7   mac=6A:38:06:55:EA:4D nodemac=C6:D0:81:C0:61:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:52.485Z",
  "value": "id=3328  sec_id=741304 flags=0x0000 ifindex=11  mac=1A:AC:9A:33:6B:06 nodemac=0E:0E:C8:BC:20:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:52.485Z",
  "value": "id=2723  sec_id=4     flags=0x0000 ifindex=7   mac=6A:38:06:55:EA:4D nodemac=C6:D0:81:C0:61:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:52.486Z",
  "value": "id=72    sec_id=741304 flags=0x0000 ifindex=9   mac=EE:97:54:4B:20:5D nodemac=7E:F5:DC:97:B2:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:52.519Z",
  "value": "id=2223  sec_id=785668 flags=0x0000 ifindex=13  mac=B6:E3:F3:D7:DF:71 nodemac=76:06:76:E8:74:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:59.716Z",
  "value": "id=1126  sec_id=785668 flags=0x0000 ifindex=15  mac=AA:C8:1F:3F:1B:4E nodemac=FE:82:AB:0B:F5:DA"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.10.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:05.777Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.640Z",
  "value": "id=72    sec_id=741304 flags=0x0000 ifindex=9   mac=EE:97:54:4B:20:5D nodemac=7E:F5:DC:97:B2:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.641Z",
  "value": "id=3328  sec_id=741304 flags=0x0000 ifindex=11  mac=1A:AC:9A:33:6B:06 nodemac=0E:0E:C8:BC:20:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.641Z",
  "value": "id=2723  sec_id=4     flags=0x0000 ifindex=7   mac=6A:38:06:55:EA:4D nodemac=C6:D0:81:C0:61:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.641Z",
  "value": "id=1126  sec_id=785668 flags=0x0000 ifindex=15  mac=AA:C8:1F:3F:1B:4E nodemac=FE:82:AB:0B:F5:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:10.636Z",
  "value": "id=1126  sec_id=785668 flags=0x0000 ifindex=15  mac=AA:C8:1F:3F:1B:4E nodemac=FE:82:AB:0B:F5:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:10.637Z",
  "value": "id=2723  sec_id=4     flags=0x0000 ifindex=7   mac=6A:38:06:55:EA:4D nodemac=C6:D0:81:C0:61:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:10.637Z",
  "value": "id=72    sec_id=741304 flags=0x0000 ifindex=9   mac=EE:97:54:4B:20:5D nodemac=7E:F5:DC:97:B2:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:10.637Z",
  "value": "id=3328  sec_id=741304 flags=0x0000 ifindex=11  mac=1A:AC:9A:33:6B:06 nodemac=0E:0E:C8:BC:20:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:11.637Z",
  "value": "id=3328  sec_id=741304 flags=0x0000 ifindex=11  mac=1A:AC:9A:33:6B:06 nodemac=0E:0E:C8:BC:20:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:11.637Z",
  "value": "id=1126  sec_id=785668 flags=0x0000 ifindex=15  mac=AA:C8:1F:3F:1B:4E nodemac=FE:82:AB:0B:F5:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:11.638Z",
  "value": "id=72    sec_id=741304 flags=0x0000 ifindex=9   mac=EE:97:54:4B:20:5D nodemac=7E:F5:DC:97:B2:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:11.638Z",
  "value": "id=2723  sec_id=4     flags=0x0000 ifindex=7   mac=6A:38:06:55:EA:4D nodemac=C6:D0:81:C0:61:F9"
}

