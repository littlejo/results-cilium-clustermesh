REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     212198    99434312   1132   bpf_host.c
Interface                 INGRESS     9496      741365     677    bpf_overlay.c
Success                   EGRESS      4688      356953     1694   bpf_host.c
Success                   EGRESS      87981     12223840   1308   bpf_lxc.c
Success                   EGRESS      9360      731291     53     encap.h
Success                   INGRESS     104974    12534405   235    trace.h
Success                   INGRESS     99517     12106087   86     l3.h
Unsupported L3 protocol   EGRESS      46        3524       1492   bpf_lxc.c
