top - 10:28:41 up 15 min,  0 users,  load average: 0.02, 0.15, 0.16
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 36.4 us, 27.3 sy,  0.0 ni, 36.4 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1213.4 free,    866.5 used,   1756.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2801.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538164 278696  77816 S  12.5   7.1   0:21.70 cilium-+
    643 root      20   0 1240432  15848  11100 S   6.2   0.4   0:00.03 cilium-+
    391 root      20   0 1228848   6656   3840 S   0.0   0.2   0:00.26 cilium-+
    666 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    675 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    692 root      20   0    6576   2412   2088 R   0.0   0.1   0:00.00 top
    710 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
