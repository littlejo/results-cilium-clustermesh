Endpoint ID: 72
Path: /sys/fs/bpf/tc/globals/cilium_policy_00072

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69570   796       0        
Allow    Egress      0          ANY          NONE         disabled    13434   138       0        


Endpoint ID: 1126
Path: /sys/fs/bpf/tc/globals/cilium_policy_01126

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3904026   35837     0        
Allow    Ingress     1          ANY          NONE         disabled    2912872   29187     0        
Allow    Egress      0          ANY          NONE         disabled    3721481   34625     0        


Endpoint ID: 2216
Path: /sys/fs/bpf/tc/globals/cilium_policy_02216

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2723
Path: /sys/fs/bpf/tc/globals/cilium_policy_02723

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    429072   5467      0        
Allow    Ingress     1          ANY          NONE         disabled    10584    124       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3328
Path: /sys/fs/bpf/tc/globals/cilium_policy_03328

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69821   802       0        
Allow    Egress      0          ANY          NONE         disabled    12672   130       0        


