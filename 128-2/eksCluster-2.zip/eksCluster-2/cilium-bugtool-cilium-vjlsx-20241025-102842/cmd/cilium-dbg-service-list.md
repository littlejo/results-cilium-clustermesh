ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.183.109:443 (active)    
                                          2 => 172.31.195.54:443 (active)     
2    10.100.65.115:443     ClusterIP      1 => 172.31.169.175:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.2.0.188:53 (active)         
                                          2 => 10.2.0.87:53 (active)          
4    10.100.0.10:9153      ClusterIP      1 => 10.2.0.188:9153 (active)       
                                          2 => 10.2.0.87:9153 (active)        
5    10.100.237.128:2379   ClusterIP      1 => 10.2.0.169:2379 (active)       
