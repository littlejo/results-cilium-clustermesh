top - 10:28:43 up 16 min,  0 users,  load average: 0.20, 0.21, 0.18
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s):  7.1 us, 25.0 sy,  0.0 ni, 67.9 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1199.4 free,    880.6 used,   1756.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2787.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 282480  78268 S   0.0   7.2   0:24.94 cilium-+
    403 root      20   0 1228848   6920   3840 S   0.0   0.2   0:00.27 cilium-+
    661 root      20   0 1228744   3604   2912 S   0.0   0.1   0:00.00 gops
    662 root      20   0 1228744   3604   2912 S   0.0   0.1   0:00.00 gops
    682 root      20   0 1240432  16752  11548 S   0.0   0.4   0:00.02 cilium-+
    687 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    718 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    736 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
