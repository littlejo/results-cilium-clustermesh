markdown output at /tmp/cilium-bugtool-20241025-102843.393+0000-UTC-680507432/cmd/cilium-debuginfo-20241025-102913.973+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102843.393+0000-UTC-680507432/cmd/cilium-debuginfo-20241025-102913.973+0000-UTC.json
