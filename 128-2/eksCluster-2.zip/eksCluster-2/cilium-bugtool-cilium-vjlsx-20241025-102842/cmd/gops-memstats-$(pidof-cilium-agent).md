alloc: 89.95MB (94315040 bytes)
total-alloc: 1.36GB (1455299064 bytes)
sys: 206.38MB (216409428 bytes)
lookups: 0
mallocs: 48087461
frees: 47285587
heap-alloc: 89.95MB (94315040 bytes)
heap-sys: 161.61MB (169459712 bytes)
heap-idle: 39.48MB (41402368 bytes)
heap-in-use: 122.12MB (128057344 bytes)
heap-released: 608.00KB (622592 bytes)
heap-objects: 801874
stack-in-use: 34.34MB (36012032 bytes)
stack-sys: 34.34MB (36012032 bytes)
stack-mspan-inuse: 2.00MB (2098880 bytes)
stack-mspan-sys: 2.52MB (2643840 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 845.77KB (866065 bytes)
gc-sys: 5.17MB (5419264 bytes)
next-gc: when heap-alloc >= 146.45MB (153567320 bytes)
last-gc: 2024-10-25 10:28:53.332816308 +0000 UTC
gc-pause-total: 7.061733ms
gc-pause: 466862
gc-pause-end: 1729852133332816308
num-gc: 75
num-forced-gc: 0
gc-cpu-fraction: 0.0002699929004321009
enable-gc: true
debug-gc: false
