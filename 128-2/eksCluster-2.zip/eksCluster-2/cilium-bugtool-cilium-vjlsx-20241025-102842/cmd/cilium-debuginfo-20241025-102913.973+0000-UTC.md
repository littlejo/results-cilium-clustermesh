# Cilium debug information

#### Cilium environment keys

```
read-cni-conf:
kvstore-max-consecutive-quorum-errors:2
bpf-lb-rev-nat-map-max:0
bpf-lb-dsr-dispatch:opt
nodeport-addresses:
enable-l2-neigh-discovery:true
hubble-export-file-max-backups:5
enable-node-port:false
enable-wireguard-userspace-fallback:false
mesh-auth-queue-size:1024
proxy-xff-num-trusted-hops-egress:0
exclude-local-address:
node-port-algorithm:random
enable-health-checking:true
bgp-config-path:/var/lib/cilium/bgp/config.yaml
bpf-lb-service-map-max:0
route-metric:0
proxy-xff-num-trusted-hops-ingress:0
policy-audit-mode:false
enable-svc-source-range-check:true
auto-create-cilium-node-resource:true
use-full-tls-context:false
max-internal-timer-delay:0s
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
hubble-export-denylist:
k8s-api-server:
labels:
gateway-api-secrets-namespace:
hubble-disable-tls:false
enable-bgp-control-plane:false
enable-ipv4-masquerade:true
enable-l2-pod-announcements:false
hubble-listen-address::4244
bpf-lb-map-max:65536
dnsproxy-lock-timeout:500ms
kvstore-opt:
bpf-ct-timeout-regular-tcp-fin:10s
unmanaged-pod-watcher-interval:15
ipv6-mcast-device:
force-device-detection:false
enable-pmtu-discovery:false
tofqdns-endpoint-max-ip-per-hostname:50
label-prefix-file:
kvstore-connectivity-timeout:2m0s
monitor-aggregation-interval:5s
policy-trigger-interval:1s
endpoint-gc-interval:5m0s
max-connected-clusters:255
set-cilium-node-taints:true
enable-ipsec-key-watcher:true
service-no-backend-response:reject
enable-gateway-api:false
clustermesh-config:/var/lib/cilium/clustermesh/
envoy-config-retry-interval:15s
encryption-strict-mode-cidr:
bpf-lb-rss-ipv6-src-cidr:
cluster-name:cmesh3
monitor-queue-size:0
enable-icmp-rules:true
disable-iptables-feeder-rules:
pprof:false
enable-recorder:false
k8s-client-burst:20
local-router-ipv6:
keep-config:false
bpf-ct-timeout-regular-tcp-syn:1m0s
mesh-auth-enabled:true
enable-hubble:true
cilium-endpoint-gc-interval:5m0s
kvstore:
enable-host-legacy-routing:false
enable-ipv4:true
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
ipv6-range:auto
ipv6-cluster-alloc-cidr:f00d::/64
arping-refresh-period:30s
node-port-mode:snat
bpf-lb-dsr-l4-xlate:frontend
l2-announcements-retry-period:2s
trace-payloadlen:128
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
http-normalize-path:true
policy-accounting:true
state-dir:/var/run/cilium
enable-service-topology:false
conntrack-gc-max-interval:0s
allow-localhost:auto
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
cluster-id:3
bpf-ct-timeout-regular-tcp:2h13m20s
enable-ipv4-big-tcp:false
enable-ipsec-xfrm-state-caching:true
operator-prometheus-serve-addr::9963
enable-l7-proxy:true
api-rate-limit:
enable-envoy-config:false
enable-well-known-identities:false
hubble-redact-http-headers-deny:
log-system-load:false
hubble-recorder-sink-queue-size:1024
enable-cilium-api-server-access:
bpf-map-event-buffers:
preallocate-bpf-maps:false
version:false
bpf-policy-map-full-reconciliation-interval:15m0s
mesh-auth-spire-admin-socket:
encrypt-node:false
allocator-list-timeout:3m0s
clustermesh-ip-identities-sync-timeout:1m0s
metrics:
bpf-node-map-max:16384
bpf-lb-algorithm:random
egress-gateway-policy-map-max:16384
node-port-range:
clustermesh-enable-endpoint-sync:false
set-cilium-is-up-condition:true
iptables-random-fully:false
tofqdns-min-ttl:0
config:
monitor-aggregation-flags:all
egress-gateway-reconciliation-trigger-interval:1s
enable-wireguard:false
bpf-lb-maglev-table-size:16381
enable-bpf-tproxy:false
enable-l2-announcements:false
cflags:
trace-sock:true
enable-bbr:false
enable-session-affinity:false
mesh-auth-signal-backoff-duration:1s
local-max-addr-scope:252
direct-routing-skip-unreachable:false
enable-ipv4-egress-gateway:false
endpoint-bpf-prog-watchdog-interval:30s
bpf-lb-mode:snat
enable-nat46x64-gateway:false
bpf-ct-timeout-regular-any:1m0s
hubble-redact-http-headers-allow:
bgp-announce-pod-cidr:false
enable-route-mtu-for-cni-chaining:false
bpf-neigh-global-max:524288
http-retry-count:3
disable-external-ip-mitigation:false
routing-mode:tunnel
k8s-kubeconfig-path:
enable-ipip-termination:false
vtep-mask:
node-port-bind-protection:true
enable-ipsec-encrypted-overlay:false
enable-vtep:false
bpf-fragments-map-max:8192
wireguard-persistent-keepalive:0s
http-request-timeout:3600
ipv4-pod-subnets:
dns-policy-unload-on-shutdown:false
bpf-ct-global-tcp-max:524288
enable-ipv6-masquerade:true
bpf-filter-priority:1
devices:
envoy-base-id:0
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
tofqdns-enable-dns-compression:true
bpf-lb-sock-terminate-pod-connections:false
procfs:/host/proc
enable-ipv4-fragment-tracking:true
bpf-map-dynamic-size-ratio:0.0025
mke-cgroup-mount:
cluster-pool-ipv4-mask-size:24
k8s-client-connection-timeout:30s
vtep-cidr:
identity-change-grace-period:5s
identity-gc-interval:15m0s
remove-cilium-node-taints:true
restore:true
enable-hubble-recorder-api:true
external-envoy-proxy:true
hubble-socket-path:/var/run/cilium/hubble.sock
annotate-k8s-node:false
fixed-identity-mapping:
k8s-client-connection-keep-alive:30s
k8s-heartbeat-timeout:30s
static-cnp-path:
node-port-acceleration:disabled
kvstore-lease-ttl:15m0s
dnsproxy-socket-linger-timeout:10
identity-heartbeat-timeout:30m0s
cmdref:
bpf-lb-sock:false
cni-exclusive:true
hubble-metrics:
enable-local-node-route:true
cni-log-file:/var/run/cilium/cilium-cni.log
hubble-export-file-max-size-mb:10
bpf-sock-rev-map-max:262144
hubble-redact-enabled:false
enable-tcx:true
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
enable-external-ips:false
ipv4-range:auto
allow-icmp-frag-needed:true
hubble-drop-events-interval:2m0s
lib-dir:/var/lib/cilium
ipam-multi-pool-pre-allocation:
enable-active-connection-tracking:false
dnsproxy-enable-transparent-mode:true
hubble-monitor-events:
enable-monitor:true
pprof-port:6060
kube-proxy-replacement-healthz-bind-address:
l2-announcements-lease-duration:15s
proxy-max-connection-duration-seconds:0
synchronize-k8s-nodes:true
mesh-auth-mutual-listener-port:0
monitor-aggregation:medium
node-labels:
k8s-client-qps:10
dnsproxy-insecure-skip-transparent-mode-check:false
vtep-mac:
nat-map-stats-entries:32
join-cluster:false
enable-bpf-clock-probe:false
enable-host-port:false
enable-masquerade-to-route-source:false
disable-endpoint-crd:false
enable-health-check-nodeport:true
bpf-lb-sock-hostns-only:false
dnsproxy-concurrency-processing-grace-period:0s
enable-stale-cilium-endpoint-cleanup:true
prometheus-serve-addr:
cni-chaining-mode:none
datapath-mode:veth
l2-announcements-renew-deadline:5s
hubble-flowlogs-config-path:
proxy-max-requests-per-connection:0
bpf-lb-acceleration:disabled
hubble-redact-http-userinfo:true
enable-xdp-prefilter:false
bpf-events-drop-enabled:true
bpf-lb-rss-ipv4-src-cidr:
hubble-drop-events:false
enable-k8s:true
enable-bandwidth-manager:false
enable-ingress-controller:false
enable-k8s-networkpolicy:true
encrypt-interface:
mesh-auth-rotated-identities-queue-size:1024
cluster-health-port:4240
enable-host-firewall:false
bpf-events-trace-enabled:true
ipam-cilium-node-update-rate:15s
enable-metrics:true
ipv6-node:auto
enable-k8s-endpoint-slice:true
http-max-grpc-timeout:0
ipv4-service-range:auto
bypass-ip-availability-upon-restore:false
ipv6-pod-subnets:
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
l2-pod-announcements-interface:
proxy-idle-timeout-seconds:60
ipv6-service-range:auto
enable-high-scale-ipcache:false
egress-masquerade-interfaces:ens+
enable-cilium-endpoint-slice:false
bgp-announce-lb-ip:false
egress-multi-home-ip-rule-compat:false
envoy-config-timeout:2m0s
endpoint-queue-size:25
bpf-ct-timeout-service-tcp:2h13m20s
proxy-portrange-min:10000
enable-runtime-device-detection:true
enable-identity-mark:true
enable-ipv6-big-tcp:false
enable-auto-protect-node-port-range:true
enable-k8s-terminating-endpoint:true
local-router-ipv4:
tofqdns-pre-cache:
kvstore-periodic-sync:5m0s
ipam-default-ip-pool:default
policy-queue-size:100
dns-max-ips-per-restored-rule:1000
enable-ip-masq-agent:false
hubble-recorder-storage-path:/var/run/cilium/pcaps
tofqdns-max-deferred-connection-deletes:10000
k8s-require-ipv6-pod-cidr:false
agent-health-port:9879
custom-cni-conf:false
k8s-sync-timeout:3m0s
http-retry-timeout:0
exclude-node-label-patterns:
envoy-keep-cap-netbindservice:false
disable-envoy-version-check:false
hubble-export-fieldmask:
bpf-root:/sys/fs/bpf
bpf-ct-global-any-max:262144
derive-masq-ip-addr-from-device:
envoy-log:
install-iptables-rules:true
enable-tracing:false
bpf-ct-timeout-service-any:1m0s
hubble-event-buffer-capacity:4095
hubble-redact-kafka-apikey:false
mtu:0
enable-custom-calls:false
tofqdns-proxy-response-max-delay:100ms
cni-chaining-target:
dnsproxy-concurrency-limit:0
bpf-ct-timeout-service-tcp-grace:1m0s
enable-mke:false
enable-policy:default
enable-ipv6-ndp:false
conntrack-gc-interval:0s
nat-map-stats-interval:30s
direct-routing-device:
ipv4-service-loopback-address:169.254.42.1
k8s-service-cache-size:128
enable-sctp:false
multicast-enabled:false
mesh-auth-mutual-connect-timeout:5s
kube-proxy-replacement:false
enable-encryption-strict-mode:false
enable-endpoint-health-checking:true
crd-wait-timeout:5m0s
mesh-auth-gc-interval:5m0s
log-opt:
clustermesh-enable-mcs-api:false
enable-endpoint-routes:false
k8s-namespace:kube-system
debug-verbose:
ipam:cluster-pool
enable-xt-socket-fallback:true
dnsproxy-lock-count:131
cni-external-routing:false
hubble-export-allowlist:
vlan-bpf-bypass:
bpf-lb-affinity-map-max:0
bpf-lb-maglev-map-max:0
k8s-service-proxy-name:
proxy-gid:1337
container-ip-local-reserved-ports:auto
bpf-lb-service-backend-map-max:0
ip-masq-agent-config-path:/etc/config/ip-masq-agent
nodes-gc-interval:5m0s
hubble-event-queue-size:0
pprof-address:localhost
iptables-lock-timeout:5s
use-cilium-internal-ip-for-ipsec:false
cgroup-root:/run/cilium/cgroupv2
fqdn-regex-compile-lru-size:1024
tunnel-protocol:vxlan
enable-local-redirect-policy:false
vtep-endpoint:
hubble-skip-unknown-cgroup-ids:true
agent-labels:
ipv4-node:auto
max-controller-interval:0
proxy-prometheus-port:0
ipv6-native-routing-cidr:
bpf-policy-map-max:16384
config-dir:/tmp/cilium/config-map
bpf-nat-global-max:524288
socket-path:/var/run/cilium/cilium.sock
bpf-auth-map-max:524288
srv6-encap-mode:reduced
hubble-export-file-path:
envoy-secrets-namespace:
proxy-admin-port:0
encryption-strict-mode-allow-remote-node-identities:false
bpf-events-policy-verdict-enabled:true
hubble-metrics-server:
proxy-portrange-max:20000
log-driver:
clustermesh-sync-timeout:1m0s
config-sources:config-map:kube-system/cilium-config
certificates-directory:/var/run/cilium/certs
prepend-iptables-chains:true
enable-health-check-loadbalancer-ip:false
ipsec-key-rotation-duration:5m0s
hubble-prefer-ipv6:false
http-idle-timeout:0
tofqdns-idle-connection-grace-period:0s
enable-k8s-api-discovery:false
identity-restore-grace-period:30s
ipv4-native-routing-cidr:
mesh-auth-spiffe-trust-domain:spiffe.cilium
cluster-pool-ipv4-cidr:10.2.0.0/16
auto-direct-node-routes:false
tofqdns-dns-reject-response-code:refused
hubble-export-file-compress:false
k8s-require-ipv4-pod-cidr:false
operator-api-serve-addr:127.0.0.1:9234
install-no-conntrack-iptables-rules:false
ipsec-key-file:
enable-srv6:false
policy-cidr-match-mode:
agent-liveness-update-interval:1s
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
tofqdns-proxy-port:0
identity-allocation-mode:crd
enable-cilium-health-api-server-access:
hubble-drop-events-reasons:auth_required,policy_denied
enable-unreachable-routes:false
controller-group-metrics:
hubble-redact-http-urlquery:false
gops-port:9890
tunnel-port:0
enable-node-selector-labels:false
ingress-secrets-namespace:
debug:false
enable-bpf-masquerade:false
bpf-lb-external-clusterip:false
bpf-lb-source-range-map-max:0
proxy-connect-timeout:2
enable-ipv6:false
enable-ipsec:false
```


#### Policy get

```
:
 []
Revision: 1

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.2.0.169": (string) (len=50) "kube-system/clustermesh-apiserver-78b75cd744-wxc4j",
  (string) (len=10) "10.2.0.244": (string) (len=6) "router",
  (string) (len=10) "10.2.0.139": (string) (len=6) "health",
  (string) (len=10) "10.2.0.188": (string) (len=35) "kube-system/coredns-cc6ccd49c-42gpd",
  (string) (len=9) "10.2.0.87": (string) (len=35) "kube-system/coredns-cc6ccd49c-4dqbw"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.169.175": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001be2630)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001e528a0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001e528a0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x40026473f0)(frontends:[]/ports=[etcd-metrics apiserv-metrics kvmesh-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4001329550)(frontends:[10.100.237.128]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4002646d10)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4002646dc0)(frontends:[10.100.65.115]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4002646f20)(frontends:[10.100.0.10]/ports=[metrics dns dns-tcp]/selector=map[k8s-app:kube-dns])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x40016ea4b0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-wz5b7": (*k8s.Endpoints)(0x4000ff75f0)(172.31.169.175:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x40016ea4b8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-rvspr": (*k8s.Endpoints)(0x4002ee71e0)(10.2.0.188:53/TCP[eu-west-3a],10.2.0.188:53/UDP[eu-west-3a],10.2.0.188:9153/TCP[eu-west-3a],10.2.0.87:53/TCP[eu-west-3a],10.2.0.87:53/UDP[eu-west-3a],10.2.0.87:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001124d88)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-5lzfm": (*k8s.Endpoints)(0x4002d78000)(10.2.0.169:2379/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x40016ea4a8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4002d88680)(172.31.183.109:443/TCP,172.31.195.54:443/TCP)
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4002488620)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40022aba90)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4006e6a708
  },
  gcTrigger: (chan struct {}) (cap=1) 0x40022a7ce0,
  gcExited: (chan struct {}) 0x40022a7d40,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4002350400)({
     ObserverVec: (*prometheus.HistogramVec)(0x40016ea818)({
      MetricVec: (*prometheus.MetricVec)(0x4001e88870)({
       metricMap: (*prometheus.metricMap)(0x4001e888a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a5a000)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4002350480)({
     ObserverVec: (*prometheus.HistogramVec)(0x40016ea820)({
      MetricVec: (*prometheus.MetricVec)(0x4001e88900)({
       metricMap: (*prometheus.metricMap)(0x4001e88930)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a5a060)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4002350500)({
     GaugeVec: (*prometheus.GaugeVec)(0x40016ea828)({
      MetricVec: (*prometheus.MetricVec)(0x4001e88990)({
       metricMap: (*prometheus.metricMap)(0x4001e889c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a5a0c0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4002350580)({
     GaugeVec: (*prometheus.GaugeVec)(0x40016ea830)({
      MetricVec: (*prometheus.MetricVec)(0x4001e88a20)({
       metricMap: (*prometheus.metricMap)(0x4001e88a50)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a5a120)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4002350600)({
     GaugeVec: (*prometheus.GaugeVec)(0x40016ea838)({
      MetricVec: (*prometheus.MetricVec)(0x4001e88ab0)({
       metricMap: (*prometheus.metricMap)(0x4001e88ae0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a5a180)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4002350680)({
     GaugeVec: (*prometheus.GaugeVec)(0x40016ea840)({
      MetricVec: (*prometheus.MetricVec)(0x4001e88b40)({
       metricMap: (*prometheus.metricMap)(0x4001e88b70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a5a1e0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4002350700)({
     GaugeVec: (*prometheus.GaugeVec)(0x40016ea848)({
      MetricVec: (*prometheus.MetricVec)(0x4001e88bd0)({
       metricMap: (*prometheus.metricMap)(0x4001e88c00)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a5a240)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4002350780)({
     GaugeVec: (*prometheus.GaugeVec)(0x40016ea850)({
      MetricVec: (*prometheus.MetricVec)(0x4001e88c60)({
       metricMap: (*prometheus.metricMap)(0x4001e88c90)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a5a2a0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4002350800)({
     ObserverVec: (*prometheus.HistogramVec)(0x40016ea858)({
      MetricVec: (*prometheus.MetricVec)(0x4001e88cf0)({
       metricMap: (*prometheus.metricMap)(0x4001e88d20)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a5a300)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4002488620)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40024897a0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x40023fdfb0)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 345ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1
  }
 })
})

```


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.2.0.0/24, 
Allocated addresses:
  10.2.0.139 (health)
  10.2.0.169 (kube-system/clustermesh-apiserver-78b75cd744-wxc4j)
  10.2.0.188 (kube-system/coredns-cc6ccd49c-42gpd)
  10.2.0.244 (router)
  10.2.0.87 (kube-system/coredns-cc6ccd49c-4dqbw)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 13e7efdce0fe1394
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    22s ago        never        0       no error   
  ct-map-pressure                                                     25s ago        never        0       no error   
  daemon-validate-config                                              9s ago         never        0       no error   
  dns-garbage-collector-job                                           27s ago        never        0       no error   
  endpoint-1875-regeneration-recovery                                 never          never        0       no error   
  endpoint-2622-regeneration-recovery                                 never          never        0       no error   
  endpoint-4017-regeneration-recovery                                 never          never        0       no error   
  endpoint-573-regeneration-recovery                                  never          never        0       no error   
  endpoint-950-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         1m27s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                25s ago        never        0       no error   
  ipcache-inject-labels                                               25s ago        never        0       no error   
  k8s-heartbeat                                                       27s ago        never        0       no error   
  link-cache                                                          9s ago         never        0       no error   
  local-identity-checkpoint                                           15m32s ago     never        0       no error   
  node-neighbor-link-updater                                          5s ago         never        0       no error   
  remote-etcd-cmesh1                                                  6m24s ago      never        0       no error   
  remote-etcd-cmesh10                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh100                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh101                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh102                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh103                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh104                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh105                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh106                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh107                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh108                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh109                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh11                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh110                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh111                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh112                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh113                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh114                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh115                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh116                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh117                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh118                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh119                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh12                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh120                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh121                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh122                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh123                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh124                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh125                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh126                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh127                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh128                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh13                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh14                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh15                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh16                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh17                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh18                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh19                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh2                                                  6m24s ago      never        0       no error   
  remote-etcd-cmesh20                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh21                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh22                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh23                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh24                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh25                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh26                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh27                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh28                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh29                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh30                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh31                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh32                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh33                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh34                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh35                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh36                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh37                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh38                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh39                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh4                                                  6m24s ago      never        0       no error   
  remote-etcd-cmesh40                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh41                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh42                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh43                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh44                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh45                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh46                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh47                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh48                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh49                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh5                                                  6m24s ago      never        0       no error   
  remote-etcd-cmesh50                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh51                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh52                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh53                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh54                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh55                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh56                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh57                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh58                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh59                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh6                                                  6m24s ago      never        0       no error   
  remote-etcd-cmesh60                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh61                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh62                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh63                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh64                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh65                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh66                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh67                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh68                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh69                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh7                                                  6m24s ago      never        0       no error   
  remote-etcd-cmesh70                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh71                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh72                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh73                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh74                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh75                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh76                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh77                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh78                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh79                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh8                                                  6m24s ago      never        0       no error   
  remote-etcd-cmesh80                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh81                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh82                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh83                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh84                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh85                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh86                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh87                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh88                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh89                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh9                                                  6m24s ago      never        0       no error   
  remote-etcd-cmesh90                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh91                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh92                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh93                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh94                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh95                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh96                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh97                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh98                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh99                                                 6m24s ago      never        0       no error   
  resolve-identity-1875                                               1m24s ago      never        0       no error   
  resolve-identity-2622                                               1m38s ago      never        0       no error   
  resolve-identity-4017                                               1m22s ago      never        0       no error   
  resolve-identity-573                                                1m22s ago      never        0       no error   
  resolve-identity-950                                                1m25s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-78b75cd744-wxc4j   6m38s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-42gpd                  16m22s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-4dqbw                  16m22s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      16m25s ago     never        0       no error   
  sync-policymap-1875                                                 1m19s ago      never        0       no error   
  sync-policymap-2622                                                 6m38s ago      never        0       no error   
  sync-policymap-4017                                                 1m19s ago      never        0       no error   
  sync-policymap-573                                                  1m19s ago      never        0       no error   
  sync-policymap-950                                                  1m23s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (2622)                                   8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (4017)                                   12s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (573)                                    12s ago        never        0       no error   
  sync-utime                                                          25s ago        never        0       no error   
  write-cni-file                                                      16m27s ago     never        0       no error   
Proxy Status:            OK, ip 10.2.0.244, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 196608, max 262143
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 64.18   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4         STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                   
573        Disabled           Disabled          202977     k8s:eks.amazonaws.com/component=coredns                                             10.2.0.188   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh3                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                          
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                              
                                                           k8s:k8s-app=kube-dns                                                                                     
950        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                  ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                    
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                              
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                               
                                                           reserved:host                                                                                            
1875       Disabled           Disabled          4          reserved:health                                                                     10.2.0.139   ready   
2622       Disabled           Disabled          240185     k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.2.0.169   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh3                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                              
                                                           k8s:k8s-app=clustermesh-apiserver                                                                        
4017       Disabled           Disabled          202977     k8s:eks.amazonaws.com/component=coredns                                             10.2.0.87    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh3                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                          
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                              
                                                           k8s:k8s-app=kube-dns                                                                                     
```

#### BPF Policy Get 573

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    92802   1069      0        
Allow    Egress      0          ANY          NONE         disabled    14627   155       0        

```


#### BPF CT List 573

```
Invalid argument: unknown type 573
```


#### Endpoint Get 573

```
[
  {
    "id": 573,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-573-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d2acca04-f160-45be-b95f-bb2d636beb68"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-573",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:51.589Z",
            "success-count": 4
          },
          "uuid": "ef990d0a-e71c-4181-819c-b19a82ef76c8"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-42gpd",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:12:51.587Z",
            "success-count": 1
          },
          "uuid": "10df758d-a148-4f06-9e28-124bed08ad52"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-573",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:54.011Z",
            "success-count": 2
          },
          "uuid": "1fd71e89-6104-47e7-8f75-d5333b96b36d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (573)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:11.680Z",
            "success-count": 100
          },
          "uuid": "5a15923e-6ac8-4076-b1ee-4cdf9d367dd5"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "950d0b3dc256547785cec1aabdefe61475977a5efc5ebbd2e9fffc25c73739d2:eth0",
        "container-id": "950d0b3dc256547785cec1aabdefe61475977a5efc5ebbd2e9fffc25c73739d2",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-42gpd",
        "pod-name": "kube-system/coredns-cc6ccd49c-42gpd"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 202977,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh3",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh3",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:51Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.2.0.188",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "3e:17:8a:00:b7:ff",
        "interface-index": 9,
        "interface-name": "lxc7c98947bfbe9",
        "mac": "e6:76:1f:0d:a8:95"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 202977,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 202977,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 573

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 573

```
Timestamp              Status   State                   Message
2024-10-25T10:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:51Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:12:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:12:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:12:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:12:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:12:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:12:52Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:12:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:12:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:12:51Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:12:51Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 202977

```
ID       LABELS
202977   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh3
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 950

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 950

```
Invalid argument: unknown type 950
```


#### Endpoint Get 950

```
[
  {
    "id": 950,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-950-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "6ec8f889-beb5-4ece-a07a-0f2b6dd45d8b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-950",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:48.880Z",
            "success-count": 4
          },
          "uuid": "dedf6b17-ff74-4037-8bc9-d688926be049"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-950",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:50.100Z",
            "success-count": 2
          },
          "uuid": "5df4f930-bd6a-4220-af43-e05fe8b7a179"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:51Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "36:85:0f:1d:9b:0a",
        "interface-name": "cilium_host",
        "mac": "36:85:0f:1d:9b:0a"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 950

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 950

```
Timestamp              Status   State                   Message
2024-10-25T10:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:51Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:12:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:12:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:12:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:12:52Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:12:52Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:12:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:12:51Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:12:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:12:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:12:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:12:48Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:12:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:12:48Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:12:48Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 1875

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    436875   5593      0        
Allow    Ingress     1          ANY          NONE         disabled    13596    158       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 1875

```
Invalid argument: unknown type 1875
```


#### Endpoint Get 1875

```
[
  {
    "id": 1875,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1875-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "e1e95867-c62f-4543-b40a-c2bad33e6040"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1875",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:49.932Z",
            "success-count": 4
          },
          "uuid": "db56fd3e-a5f6-45fd-a351-0dcf31741627"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1875",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:54.011Z",
            "success-count": 2
          },
          "uuid": "f7231f28-f68c-47f1-a89f-a066fd8e122a"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:51Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.2.0.139",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "6e:c4:0e:86:52:6b",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "f2:d8:61:7d:11:fa"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1875

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1875

```
Timestamp              Status   State                   Message
2024-10-25T10:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:51Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:12:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:12:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:12:54Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:12:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:12:52Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:12:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:12:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:12:49Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:12:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:12:49Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:12:48Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 2622

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3907146   36390     0        
Allow    Ingress     1          ANY          NONE         disabled    3055139   30734     0        
Allow    Egress      0          ANY          NONE         disabled    4077932   37968     0        

```


#### BPF CT List 2622

```
Invalid argument: unknown type 2622
```


#### Endpoint Get 2622

```
[
  {
    "id": 2622,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2622-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c9df48cc-b404-4f29-800b-c41bc52eca1d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2622",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:35.422Z",
            "success-count": 2
          },
          "uuid": "d5d61a51-5e96-4514-8580-29699f3647a0"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-78b75cd744-wxc4j",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:35.421Z",
            "success-count": 1
          },
          "uuid": "6d5d7aa0-2991-4fb5-a9c8-461466af1cd0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2622",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:35.463Z",
            "success-count": 1
          },
          "uuid": "cf00e120-6d71-4de6-b83e-a313d041c972"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2622)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:05.476Z",
            "success-count": 41
          },
          "uuid": "2e71652b-baf7-4084-bfdc-c4dc5aad31f9"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "80df4bc6e01605cbe8cd6732dadcf0f884b38f72fb526d1e60baefed1c0257ed:eth0",
        "container-id": "80df4bc6e01605cbe8cd6732dadcf0f884b38f72fb526d1e60baefed1c0257ed",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-78b75cd744-wxc4j",
        "pod-name": "kube-system/clustermesh-apiserver-78b75cd744-wxc4j"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 240185,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh3",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=78b75cd744"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh3",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:51Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.2.0.169",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "66:8e:9c:d4:0c:8a",
        "interface-index": 15,
        "interface-name": "lxc334e67273f48",
        "mac": "2e:91:e1:10:dc:7e"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 240185,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 240185,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2622

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2622

```
Timestamp              Status   State                   Message
2024-10-25T10:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:51Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:22:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:35Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:22:35Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:22:35Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 240185

```
ID       LABELS
240185   k8s:app.kubernetes.io/name=clustermesh-apiserver
         k8s:app.kubernetes.io/part-of=cilium
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh3
         k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 4017

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    92611   1069      0        
Allow    Egress      0          ANY          NONE         disabled    14467   152       0        

```


#### BPF CT List 4017

```
Invalid argument: unknown type 4017
```


#### Endpoint Get 4017

```
[
  {
    "id": 4017,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-4017-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7d324fde-e814-48df-8675-9b51b4911056"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-4017",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:51.690Z",
            "success-count": 4
          },
          "uuid": "3e8aadc8-d380-4158-bb8e-b9271f4e6538"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-4dqbw",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:12:51.688Z",
            "success-count": 1
          },
          "uuid": "1382e7d7-96ea-49a0-b4fe-20a081e99f89"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-4017",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:54.085Z",
            "success-count": 2
          },
          "uuid": "c54e9659-d2f7-4cb2-a22d-cbd101d3ff96"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (4017)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:11.766Z",
            "success-count": 100
          },
          "uuid": "de2fcef7-f076-47a0-8634-81aa88cefae8"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "714a25fe489ffc87703e86f89c435e4ee5cba1d5de9473f7143a9dac5b80d385:eth0",
        "container-id": "714a25fe489ffc87703e86f89c435e4ee5cba1d5de9473f7143a9dac5b80d385",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-4dqbw",
        "pod-name": "kube-system/coredns-cc6ccd49c-4dqbw"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 202977,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh3",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh3",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:51Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.2.0.87",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "b6:6b:b6:2e:b9:aa",
        "interface-index": 11,
        "interface-name": "lxc8d51ee350110",
        "mac": "56:aa:34:f1:50:b0"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 202977,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 202977,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 4017

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 4017

```
Timestamp              Status   State                   Message
2024-10-25T10:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:51Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:50Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:12:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:12:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:12:54Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:12:52Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:12:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:12:51Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:12:51Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 202977

```
ID       LABELS
202977   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh3
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.183.109:443 (active)    
                                          2 => 172.31.195.54:443 (active)     
2    10.100.65.115:443     ClusterIP      1 => 172.31.169.175:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.2.0.188:53 (active)         
                                          2 => 10.2.0.87:53 (active)          
4    10.100.0.10:9153      ClusterIP      1 => 10.2.0.188:9153 (active)       
                                          2 => 10.2.0.87:9153 (active)        
5    10.100.237.128:2379   ClusterIP      1 => 10.2.0.169:2379 (active)       
```

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 37768267                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 37768267                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 37768267                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400c800000 rw-p 00000000 00:00 0 
400c800000-4010000000 ---p 00000000 00:00 0 
ffff61748000-ffff6195e000 rw-p 00000000 00:00 0 
ffff61966000-ffff61a47000 rw-p 00000000 00:00 0 
ffff61a47000-ffff61a88000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff61a88000-ffff61ac9000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff61ac9000-ffff61b09000 rw-p 00000000 00:00 0 
ffff61b09000-ffff61b0b000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff61b0b000-ffff61b0d000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff61b0d000-ffff620c4000 rw-p 00000000 00:00 0 
ffff620c4000-ffff621c4000 rw-p 00000000 00:00 0 
ffff621c4000-ffff621d5000 rw-p 00000000 00:00 0 
ffff621d5000-ffff641d5000 rw-p 00000000 00:00 0 
ffff641d5000-ffff64255000 ---p 00000000 00:00 0 
ffff64255000-ffff64256000 rw-p 00000000 00:00 0 
ffff64256000-ffff84255000 ---p 00000000 00:00 0 
ffff84255000-ffff84256000 rw-p 00000000 00:00 0 
ffff84256000-ffffa41e5000 ---p 00000000 00:00 0 
ffffa41e5000-ffffa41e6000 rw-p 00000000 00:00 0 
ffffa41e6000-ffffa81d7000 ---p 00000000 00:00 0 
ffffa81d7000-ffffa81d8000 rw-p 00000000 00:00 0 
ffffa81d8000-ffffa89d5000 ---p 00000000 00:00 0 
ffffa89d5000-ffffa89d6000 rw-p 00000000 00:00 0 
ffffa89d6000-ffffa8ad5000 ---p 00000000 00:00 0 
ffffa8ad5000-ffffa8b35000 rw-p 00000000 00:00 0 
ffffa8b35000-ffffa8b37000 r--p 00000000 00:00 0                          [vvar]
ffffa8b37000-ffffa8b38000 r-xp 00000000 00:00 0                          [vdso]
ffffe1c49000-ffffe1c6a000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium encryption



#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```

