IP ADDRESS         LOCAL ENDPOINT INFO
10.2.0.244:0       (localhost)                                                                                       
10.2.0.188:0       id=573   sec_id=202977 flags=0x0000 ifindex=9   mac=E6:76:1F:0D:A8:95 nodemac=3E:17:8A:00:B7:FF   
172.31.169.175:0   (localhost)                                                                                       
10.2.0.139:0       id=1875  sec_id=4     flags=0x0000 ifindex=7   mac=F2:D8:61:7D:11:FA nodemac=6E:C4:0E:86:52:6B    
10.2.0.169:0       id=2622  sec_id=240185 flags=0x0000 ifindex=15  mac=2E:91:E1:10:DC:7E nodemac=66:8E:9C:D4:0C:8A   
10.2.0.87:0        id=4017  sec_id=202977 flags=0x0000 ifindex=11  mac=56:AA:34:F1:50:B0 nodemac=B6:6B:B6:2E:B9:AA   
