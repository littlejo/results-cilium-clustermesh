[
  {
    "containers": [
      {
        "cgroup-id": 8370,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3af946e4_51f4_4a38_ae92_d293f9267b6a.slice/cri-containerd-05e284ea387c9743efb2b0c295b684163c744e6b95aa53c49be7583ae78b3a58.scope"
      },
      {
        "cgroup-id": 8286,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3af946e4_51f4_4a38_ae92_d293f9267b6a.slice/cri-containerd-ec1cec8f1fa04a74fab22f2417a1b755876a212a24276e1025de36d0c9921c49.scope"
      },
      {
        "cgroup-id": 8202,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3af946e4_51f4_4a38_ae92_d293f9267b6a.slice/cri-containerd-ab9c1e5dd45c5e675b3861ca31f69d072a4bf4e53840028f4f4bbff98a156b2d.scope"
      }
    ],
    "ips": [
      "10.2.0.169"
    ],
    "name": "clustermesh-apiserver-78b75cd744-wxc4j",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6858,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode9fbe115_72ed_43a7_92aa_882607118d95.slice/cri-containerd-a2bd1d9bca25a6cf9d3f8e192a5a71420e6c8289a975172e3920cc4292fe30d3.scope"
      }
    ],
    "ips": [
      "10.2.0.87"
    ],
    "name": "coredns-cc6ccd49c-4dqbw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6774,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3d56073d_afc4_41ef_b97a_954fea0252bb.slice/cri-containerd-39e604c247f1eb21b44fb5e442fd3aa9ff72b2d4f132f204c1d7b44dc157ebd7.scope"
      }
    ],
    "ips": [
      "10.2.0.188"
    ],
    "name": "coredns-cc6ccd49c-42gpd",
    "namespace": "kube-system"
  }
]

