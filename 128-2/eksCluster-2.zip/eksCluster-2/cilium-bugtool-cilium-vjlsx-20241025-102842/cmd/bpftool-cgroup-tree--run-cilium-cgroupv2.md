CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9e3fc720_4792_4831_acee_c764e5c14efc.slice/cri-containerd-00bd897ebb13f0e756760ca946c014d38342948ff0884c9a47720776a52ba928.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9e3fc720_4792_4831_acee_c764e5c14efc.slice/cri-containerd-d9870808566610e1669d5497a4eff856559b89f260221e4078be083ebc644b64.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3d56073d_afc4_41ef_b97a_954fea0252bb.slice/cri-containerd-39e604c247f1eb21b44fb5e442fd3aa9ff72b2d4f132f204c1d7b44dc157ebd7.scope
    521      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3d56073d_afc4_41ef_b97a_954fea0252bb.slice/cri-containerd-950d0b3dc256547785cec1aabdefe61475977a5efc5ebbd2e9fffc25c73739d2.scope
    513      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod695c48de_c178_4051_9dcc_4569546a208c.slice/cri-containerd-4dd119790422b283c665f97638ed39f6bd1dad872dd41171e2e1c5f55bb2acb7.scope
    100      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod695c48de_c178_4051_9dcc_4569546a208c.slice/cri-containerd-6e7876b15eb6902191c8c4421c271ab14ae548d3f509bd4c69fbd594e275100a.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode9fbe115_72ed_43a7_92aa_882607118d95.slice/cri-containerd-a2bd1d9bca25a6cf9d3f8e192a5a71420e6c8289a975172e3920cc4292fe30d3.scope
    525      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode9fbe115_72ed_43a7_92aa_882607118d95.slice/cri-containerd-714a25fe489ffc87703e86f89c435e4ee5cba1d5de9473f7143a9dac5b80d385.scope
    517      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod172a9e49_337c_4211_9176_6ab2ae747ac0.slice/cri-containerd-76c8a1c886750c0aa249f64907fa45231ce5d9ba54a7ee2fc1a5eb480063ffc5.scope
    62       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod172a9e49_337c_4211_9176_6ab2ae747ac0.slice/cri-containerd-539def54fa78387f9d7c894547411921fde28cc6229efa37c19c6c440f296e15.scope
    69       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3af946e4_51f4_4a38_ae92_d293f9267b6a.slice/cri-containerd-05e284ea387c9743efb2b0c295b684163c744e6b95aa53c49be7583ae78b3a58.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3af946e4_51f4_4a38_ae92_d293f9267b6a.slice/cri-containerd-ec1cec8f1fa04a74fab22f2417a1b755876a212a24276e1025de36d0c9921c49.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3af946e4_51f4_4a38_ae92_d293f9267b6a.slice/cri-containerd-ab9c1e5dd45c5e675b3861ca31f69d072a4bf4e53840028f4f4bbff98a156b2d.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3af946e4_51f4_4a38_ae92_d293f9267b6a.slice/cri-containerd-80df4bc6e01605cbe8cd6732dadcf0f884b38f72fb526d1e60baefed1c0257ed.scope
    579      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod91f7379d_e993_43d9_be4a_6ac901fe6d53.slice/cri-containerd-6101dea2c52c6f55ed3ea6f204958d87b178163b227b411d8c683791c0a79f74.scope
    73       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod91f7379d_e993_43d9_be4a_6ac901fe6d53.slice/cri-containerd-0175a6678421e814d06253d0383ef021801b718f5d325418bf07d47c1a686d91.scope
    58       cgroup_device   multi                                          
