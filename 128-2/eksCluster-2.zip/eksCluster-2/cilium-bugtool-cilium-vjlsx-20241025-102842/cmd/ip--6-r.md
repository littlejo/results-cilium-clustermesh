fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxc7c98947bfbe9 proto kernel metric 256 pref medium
fe80::/64 dev lxc8d51ee350110 proto kernel metric 256 pref medium
fe80::/64 dev lxc334e67273f48 proto kernel metric 256 pref medium
