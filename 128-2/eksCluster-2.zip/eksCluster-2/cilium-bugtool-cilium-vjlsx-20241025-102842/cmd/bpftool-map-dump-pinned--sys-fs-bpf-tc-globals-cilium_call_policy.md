key: 3d 02 00 00  value: e1 01 00 00
key: 53 07 00 00  value: fb 01 00 00
key: 3e 0a 00 00  value: 36 02 00 00
key: b1 0f 00 00  value: f2 01 00 00
Found 4 elements
