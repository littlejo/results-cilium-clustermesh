xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 462
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 453
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 447
cilium_host(4) clsact/egress cil_from_host-cilium_host id 450
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 441
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 442
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 508
lxc7c98947bfbe9(9) clsact/ingress cil_from_container-lxc7c98947bfbe9 id 472
lxc8d51ee350110(11) clsact/ingress cil_from_container-lxc8d51ee350110 id 488
lxc334e67273f48(15) clsact/ingress cil_from_container-lxc334e67273f48 id 571

flow_dissector:

netfilter:

