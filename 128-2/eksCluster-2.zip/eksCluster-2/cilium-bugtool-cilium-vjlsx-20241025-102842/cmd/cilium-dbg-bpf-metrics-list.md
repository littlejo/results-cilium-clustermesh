REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     10166     794883      677    bpf_overlay.c
Interface                 INGRESS     220926    100616693   1132   bpf_host.c
Success                   EGRESS      10379     811240      53     encap.h
Success                   EGRESS      5233      402725      1694   bpf_host.c
Success                   EGRESS      90232     12179761    1308   bpf_lxc.c
Success                   INGRESS     101950    12364135    86     l3.h
Success                   INGRESS     107532    12800199    235    trace.h
Unsupported L3 protocol   EGRESS      37        2742        1492   bpf_lxc.c
