{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:12:48.695Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.169.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:12:48.695Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:12:54.009Z",
  "value": "id=1875  sec_id=4     flags=0x0000 ifindex=7   mac=F2:D8:61:7D:11:FA nodemac=6E:C4:0E:86:52:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:12:54.010Z",
  "value": "id=573   sec_id=202977 flags=0x0000 ifindex=9   mac=E6:76:1F:0D:A8:95 nodemac=3E:17:8A:00:B7:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:12:54.084Z",
  "value": "id=4017  sec_id=202977 flags=0x0000 ifindex=11  mac=56:AA:34:F1:50:B0 nodemac=B6:6B:B6:2E:B9:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:12:54.086Z",
  "value": "id=573   sec_id=202977 flags=0x0000 ifindex=9   mac=E6:76:1F:0D:A8:95 nodemac=3E:17:8A:00:B7:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:12:54.094Z",
  "value": "id=1875  sec_id=4     flags=0x0000 ifindex=7   mac=F2:D8:61:7D:11:FA nodemac=6E:C4:0E:86:52:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:09.365Z",
  "value": "id=1875  sec_id=4     flags=0x0000 ifindex=7   mac=F2:D8:61:7D:11:FA nodemac=6E:C4:0E:86:52:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:09.365Z",
  "value": "id=573   sec_id=202977 flags=0x0000 ifindex=9   mac=E6:76:1F:0D:A8:95 nodemac=3E:17:8A:00:B7:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:09.365Z",
  "value": "id=4017  sec_id=202977 flags=0x0000 ifindex=11  mac=56:AA:34:F1:50:B0 nodemac=B6:6B:B6:2E:B9:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:09.394Z",
  "value": "id=3471  sec_id=240185 flags=0x0000 ifindex=13  mac=72:86:66:32:CF:0F nodemac=E6:80:BF:D9:72:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:09.394Z",
  "value": "id=3471  sec_id=240185 flags=0x0000 ifindex=13  mac=72:86:66:32:CF:0F nodemac=E6:80:BF:D9:72:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:10.365Z",
  "value": "id=3471  sec_id=240185 flags=0x0000 ifindex=13  mac=72:86:66:32:CF:0F nodemac=E6:80:BF:D9:72:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:10.365Z",
  "value": "id=573   sec_id=202977 flags=0x0000 ifindex=9   mac=E6:76:1F:0D:A8:95 nodemac=3E:17:8A:00:B7:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:10.365Z",
  "value": "id=1875  sec_id=4     flags=0x0000 ifindex=7   mac=F2:D8:61:7D:11:FA nodemac=6E:C4:0E:86:52:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:10.366Z",
  "value": "id=4017  sec_id=202977 flags=0x0000 ifindex=11  mac=56:AA:34:F1:50:B0 nodemac=B6:6B:B6:2E:B9:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:35.462Z",
  "value": "id=2622  sec_id=240185 flags=0x0000 ifindex=15  mac=2E:91:E1:10:DC:7E nodemac=66:8E:9C:D4:0C:8A"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.2.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:40.688Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:49.179Z",
  "value": "id=1875  sec_id=4     flags=0x0000 ifindex=7   mac=F2:D8:61:7D:11:FA nodemac=6E:C4:0E:86:52:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:49.179Z",
  "value": "id=573   sec_id=202977 flags=0x0000 ifindex=9   mac=E6:76:1F:0D:A8:95 nodemac=3E:17:8A:00:B7:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:49.180Z",
  "value": "id=4017  sec_id=202977 flags=0x0000 ifindex=11  mac=56:AA:34:F1:50:B0 nodemac=B6:6B:B6:2E:B9:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:49.180Z",
  "value": "id=2622  sec_id=240185 flags=0x0000 ifindex=15  mac=2E:91:E1:10:DC:7E nodemac=66:8E:9C:D4:0C:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:50.180Z",
  "value": "id=2622  sec_id=240185 flags=0x0000 ifindex=15  mac=2E:91:E1:10:DC:7E nodemac=66:8E:9C:D4:0C:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:50.180Z",
  "value": "id=1875  sec_id=4     flags=0x0000 ifindex=7   mac=F2:D8:61:7D:11:FA nodemac=6E:C4:0E:86:52:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:50.181Z",
  "value": "id=4017  sec_id=202977 flags=0x0000 ifindex=11  mac=56:AA:34:F1:50:B0 nodemac=B6:6B:B6:2E:B9:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:50.181Z",
  "value": "id=573   sec_id=202977 flags=0x0000 ifindex=9   mac=E6:76:1F:0D:A8:95 nodemac=3E:17:8A:00:B7:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:51.185Z",
  "value": "id=4017  sec_id=202977 flags=0x0000 ifindex=11  mac=56:AA:34:F1:50:B0 nodemac=B6:6B:B6:2E:B9:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:51.186Z",
  "value": "id=2622  sec_id=240185 flags=0x0000 ifindex=15  mac=2E:91:E1:10:DC:7E nodemac=66:8E:9C:D4:0C:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:51.186Z",
  "value": "id=1875  sec_id=4     flags=0x0000 ifindex=7   mac=F2:D8:61:7D:11:FA nodemac=6E:C4:0E:86:52:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:51.187Z",
  "value": "id=573   sec_id=202977 flags=0x0000 ifindex=9   mac=E6:76:1F:0D:A8:95 nodemac=3E:17:8A:00:B7:FF"
}

