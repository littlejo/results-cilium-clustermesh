Endpoint ID: 573
Path: /sys/fs/bpf/tc/globals/cilium_policy_00573

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    92802   1069      0        
Allow    Egress      0          ANY          NONE         disabled    14627   155       0        


Endpoint ID: 950
Path: /sys/fs/bpf/tc/globals/cilium_policy_00950

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1875
Path: /sys/fs/bpf/tc/globals/cilium_policy_01875

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    438871   5617      0        
Allow    Ingress     1          ANY          NONE         disabled    13596    158       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2622
Path: /sys/fs/bpf/tc/globals/cilium_policy_02622

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3907146   36390     0        
Allow    Ingress     1          ANY          NONE         disabled    3056165   30746     0        
Allow    Egress      0          ANY          NONE         disabled    4080314   37995     0        


Endpoint ID: 4017
Path: /sys/fs/bpf/tc/globals/cilium_policy_04017

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    92611   1069      0        
Allow    Egress      0          ANY          NONE         disabled    14467   152       0        


