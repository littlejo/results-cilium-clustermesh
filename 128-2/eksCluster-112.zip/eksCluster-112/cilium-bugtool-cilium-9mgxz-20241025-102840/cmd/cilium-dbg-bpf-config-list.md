KEY             VALUE
AgentLiveness   669042041272
UTimeOffset     3378616177734375
