35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:18:05+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:18:05+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:18:06+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:18:06+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:18:06+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:18:06+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:18:10+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
61: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
64: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
69: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
72: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
75: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:18:23+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
447: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:18:49+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 112
448: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:18:49+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 113
449: sched_cls  name tail_handle_ipv4  tag 527e403e377c91f8  gpl
	loaded_at 2024-10-25T10:18:49+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 114
450: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:18:49+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 115
473: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,98
	btf_id 141
474: sched_cls  name tail_ipv4_to_endpoint  tag 4180064eb478c976  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,97,33,74,75,72,96,31,98,32,29,30
	btf_id 142
475: sched_cls  name tail_handle_ipv4  tag fc776d2903b71c5f  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,98
	btf_id 143
476: sched_cls  name tail_ipv4_ct_ingress  tag 78c060985fefa389  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,98,74,75,97,76
	btf_id 144
477: sched_cls  name cil_from_container  tag 6bb88700ac458a1d  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 98,68
	btf_id 145
478: sched_cls  name tail_handle_arp  tag 2cd308d867555bed  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,98
	btf_id 146
480: sched_cls  name handle_policy  tag 2c341767d865ba22  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,98,74,75,97,33,72,96,31,76,67,32,29,30
	btf_id 148
481: sched_cls  name tail_handle_ipv4_cont  tag 3c904dfe893c3960  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,97,33,96,74,75,31,68,66,69,98,32,29,30,73
	btf_id 149
482: sched_cls  name tail_ipv4_ct_egress  tag 102744a7abe51bc4  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,98,74,75,97,76
	btf_id 150
483: sched_cls  name __send_drop_notify  tag 1ca29764ef599013  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 151
484: sched_cls  name tail_ipv4_ct_egress  tag 102744a7abe51bc4  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,99,74,75,100,76
	btf_id 153
486: sched_cls  name tail_handle_ipv4  tag e991f405f550ba3a  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,99
	btf_id 155
487: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,99
	btf_id 156
488: sched_cls  name tail_ipv4_ct_ingress  tag 1eaf29069cfca79b  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,99,74,75,100,76
	btf_id 157
489: sched_cls  name cil_from_container  tag 7a2b8260c09c84d0  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 99,68
	btf_id 158
490: sched_cls  name tail_handle_arp  tag f3d7a926f8146bc9  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,99
	btf_id 159
491: sched_cls  name tail_handle_ipv4_cont  tag b58173e88ab83cef  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,100,33,90,74,75,31,68,66,69,99,32,29,30,73
	btf_id 160
492: sched_cls  name tail_ipv4_to_endpoint  tag 010ce8ccf84ea4c5  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,100,33,74,75,72,90,31,99,32,29,30
	btf_id 161
493: sched_cls  name handle_policy  tag a0e3d91338f00e0e  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,99,74,75,100,33,72,90,31,76,67,32,29,30
	btf_id 162
494: sched_cls  name __send_drop_notify  tag 2113bd83ef9f44e3  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 163
495: sched_cls  name tail_ipv4_to_endpoint  tag a8a0a4463f1e550f  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,102,33,74,75,72,91,31,101,32,29,30
	btf_id 165
497: sched_cls  name __send_drop_notify  tag e5f0c278073391be  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 167
498: sched_cls  name tail_handle_arp  tag f86e840c7759c5ef  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,101
	btf_id 168
499: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
502: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
503: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,101
	btf_id 169
504: sched_cls  name cil_from_container  tag c54b4da8c2e9c491  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 101,68
	btf_id 170
505: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
508: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
509: sched_cls  name tail_handle_ipv4  tag 5e25e211a997a425  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,101
	btf_id 171
510: sched_cls  name tail_handle_ipv4_cont  tag 27574e9d308e9448  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,102,33,91,74,75,31,68,66,69,101,32,29,30,73
	btf_id 172
511: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,101,74,75,102,76
	btf_id 173
512: sched_cls  name handle_policy  tag c3e819944be082fc  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,101,74,75,102,33,72,91,31,76,67,32,29,30
	btf_id 174
513: sched_cls  name tail_ipv4_ct_ingress  tag be5d6236bac24e7a  gpl
	loaded_at 2024-10-25T10:18:51+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,101,74,75,102,76
	btf_id 175
514: sched_cls  name tail_handle_ipv4_from_host  tag 20cac4945d340d3a  gpl
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,106
	btf_id 177
516: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,106
	btf_id 179
517: sched_cls  name __send_drop_notify  tag b2d2563c39a0e16b  gpl
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 180
519: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 182
520: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,106
	btf_id 183
522: sched_cls  name __send_drop_notify  tag b2d2563c39a0e16b  gpl
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 186
524: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 188
525: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,107
	btf_id 189
526: sched_cls  name tail_handle_ipv4_from_host  tag 20cac4945d340d3a  gpl
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,107
	btf_id 190
528: sched_cls  name __send_drop_notify  tag b2d2563c39a0e16b  gpl
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 193
531: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,109
	btf_id 196
532: sched_cls  name tail_handle_ipv4_from_host  tag 20cac4945d340d3a  gpl
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,109
	btf_id 197
533: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,109,67
	btf_id 198
535: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
538: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
539: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
542: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
582: sched_cls  name handle_policy  tag ff568b034bc7299f  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,125,74,75,124,33,72,123,31,76,67,32,29,30
	btf_id 215
583: sched_cls  name tail_ipv4_ct_ingress  tag d7358a97a160d0b0  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,125,74,75,124,76
	btf_id 216
584: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,125
	btf_id 217
586: sched_cls  name tail_ipv4_ct_egress  tag a0ae5176eb1b92f2  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,125,74,75,124,76
	btf_id 219
587: sched_cls  name tail_handle_ipv4  tag 5699af1c254ebd39  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,125
	btf_id 220
588: sched_cls  name tail_handle_ipv4_cont  tag ca3d1d413c4a8dfc  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,124,33,123,74,75,31,68,66,69,125,32,29,30,73
	btf_id 221
589: sched_cls  name cil_from_container  tag 47692cb93d54a502  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 125,68
	btf_id 222
590: sched_cls  name __send_drop_notify  tag f27f6e27779f53d5  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 223
591: sched_cls  name tail_ipv4_to_endpoint  tag 95ec025dda9b11ff  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,124,33,74,75,72,123,31,125,32,29,30
	btf_id 224
592: sched_cls  name tail_handle_arp  tag e9efd5f9cb5f8b92  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,125
	btf_id 225
593: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
596: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
609: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
612: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
613: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
616: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
617: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
620: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
