# Cilium debug information

#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001ae48f0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001d334a0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001d334a0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4001fc6c60)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4001fc6d10)(frontends:[10.100.110.200]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4001fc6dc0)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x400379e160)(frontends:[]/ports=[etcd-metrics apiserv-metrics kvmesh-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40032d5970)(frontends:[10.100.187.60]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4001cb8148)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-qqx49": (*k8s.Endpoints)(0x40031aedd0)(172.31.179.165:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4001cb8150)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-jb4b5": (*k8s.Endpoints)(0x40035b1d40)(10.112.0.168:53/TCP[eu-west-3a],10.112.0.168:53/UDP[eu-west-3a],10.112.0.168:9153/TCP[eu-west-3a],10.112.0.68:53/TCP[eu-west-3a],10.112.0.68:53/UDP[eu-west-3a],10.112.0.68:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40011149c8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-fgkpl": (*k8s.Endpoints)(0x40056cd930)(10.112.0.199:2379/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4001cb8140)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x400331cb60)(172.31.165.85:443/TCP,172.31.253.241:443/TCP)
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x40019f9650)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40022fa140)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400a5f7bd8
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4001dd39e0,
  gcExited: (chan struct {}) 0x4001dd3a40,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001ae1500)({
     ObserverVec: (*prometheus.HistogramVec)(0x400196b5f8)({
      MetricVec: (*prometheus.MetricVec)(0x4001ce0390)({
       metricMap: (*prometheus.metricMap)(0x4001ce03c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001abcd20)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001ae1580)({
     ObserverVec: (*prometheus.HistogramVec)(0x400196b600)({
      MetricVec: (*prometheus.MetricVec)(0x4001ce0420)({
       metricMap: (*prometheus.metricMap)(0x4001ce0450)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001abcd80)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001ae1600)({
     GaugeVec: (*prometheus.GaugeVec)(0x400196b608)({
      MetricVec: (*prometheus.MetricVec)(0x4001ce04b0)({
       metricMap: (*prometheus.metricMap)(0x4001ce04e0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001abcde0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001ae1680)({
     GaugeVec: (*prometheus.GaugeVec)(0x400196b610)({
      MetricVec: (*prometheus.MetricVec)(0x4001ce0540)({
       metricMap: (*prometheus.metricMap)(0x4001ce0570)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001abce40)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001ae1700)({
     GaugeVec: (*prometheus.GaugeVec)(0x400196b618)({
      MetricVec: (*prometheus.MetricVec)(0x4001ce05d0)({
       metricMap: (*prometheus.metricMap)(0x4001ce0600)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001abcea0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001ae1780)({
     GaugeVec: (*prometheus.GaugeVec)(0x400196b620)({
      MetricVec: (*prometheus.MetricVec)(0x4001ce0660)({
       metricMap: (*prometheus.metricMap)(0x4001ce0690)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001abcf00)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001ae1800)({
     GaugeVec: (*prometheus.GaugeVec)(0x400196b628)({
      MetricVec: (*prometheus.MetricVec)(0x4001ce06f0)({
       metricMap: (*prometheus.metricMap)(0x4001ce0720)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001abcf60)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001ae1880)({
     GaugeVec: (*prometheus.GaugeVec)(0x400196b630)({
      MetricVec: (*prometheus.MetricVec)(0x4001ce0780)({
       metricMap: (*prometheus.metricMap)(0x4001ce07b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001abcfc0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001ae1900)({
     ObserverVec: (*prometheus.HistogramVec)(0x400196b638)({
      MetricVec: (*prometheus.MetricVec)(0x4001ce0810)({
       metricMap: (*prometheus.metricMap)(0x4001ce0840)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001abd020)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x40019f9650)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001d20850)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001cc78f0)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 156ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=12) "10.112.0.163": (string) (len=6) "router",
  (string) (len=12) "10.112.0.135": (string) (len=6) "health",
  (string) (len=12) "10.112.0.168": (string) (len=35) "kube-system/coredns-cc6ccd49c-8twpf",
  (string) (len=11) "10.112.0.68": (string) (len=35) "kube-system/coredns-cc6ccd49c-99xv9",
  (string) (len=12) "10.112.0.199": (string) (len=50) "kube-system/clustermesh-apiserver-7bd95d4974-jqnw8"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.179.165": (string) (len=7) "node-ip"
}

```


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.112.0.0/24, 
Allocated addresses:
  10.112.0.135 (health)
  10.112.0.163 (router)
  10.112.0.168 (kube-system/coredns-cc6ccd49c-8twpf)
  10.112.0.199 (kube-system/clustermesh-apiserver-7bd95d4974-jqnw8)
  10.112.0.68 (kube-system/coredns-cc6ccd49c-99xv9)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m37s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m36s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 231e4400f20f7cfd
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    23s ago        never        0       no error   
  ct-map-pressure                                                     24s ago        never        0       no error   
  daemon-validate-config                                              14s ago        never        0       no error   
  dns-garbage-collector-job                                           27s ago        never        0       no error   
  endpoint-2206-regeneration-recovery                                 never          never        0       no error   
  endpoint-227-regeneration-recovery                                  never          never        0       no error   
  endpoint-3798-regeneration-recovery                                 never          never        0       no error   
  endpoint-4063-regeneration-recovery                                 never          never        0       no error   
  endpoint-476-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         27s ago        never        0       no error   
  ep-bpf-prog-watchdog                                                24s ago        never        0       no error   
  ipcache-inject-labels                                               24s ago        never        0       no error   
  k8s-heartbeat                                                       27s ago        never        0       no error   
  link-cache                                                          9s ago         never        0       no error   
  local-identity-checkpoint                                           9m54s ago      never        0       no error   
  node-neighbor-link-updater                                          4s ago         never        0       no error   
  remote-etcd-cmesh1                                                  7m36s ago      never        0       no error   
  remote-etcd-cmesh10                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh100                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh101                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh102                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh103                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh104                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh105                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh106                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh107                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh108                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh109                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh11                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh110                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh111                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh112                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh114                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh115                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh116                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh117                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh118                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh119                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh12                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh120                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh121                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh122                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh123                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh124                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh125                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh126                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh127                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh128                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh13                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh14                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh15                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh16                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh17                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh18                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh19                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh2                                                  7m36s ago      never        0       no error   
  remote-etcd-cmesh20                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh21                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh22                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh23                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh24                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh25                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh26                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh27                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh28                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh29                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh3                                                  7m36s ago      never        0       no error   
  remote-etcd-cmesh30                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh31                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh32                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh33                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh34                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh35                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh36                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh37                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh38                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh39                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh4                                                  7m36s ago      never        0       no error   
  remote-etcd-cmesh40                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh41                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh42                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh43                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh44                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh45                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh46                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh47                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh48                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh49                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh5                                                  7m36s ago      never        0       no error   
  remote-etcd-cmesh50                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh51                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh52                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh53                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh54                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh55                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh56                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh57                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh58                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh59                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh6                                                  7m36s ago      never        0       no error   
  remote-etcd-cmesh60                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh61                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh62                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh63                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh64                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh65                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh66                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh67                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh68                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh69                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh7                                                  7m36s ago      never        0       no error   
  remote-etcd-cmesh70                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh71                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh72                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh73                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh74                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh75                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh76                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh77                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh78                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh79                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh8                                                  7m36s ago      never        0       no error   
  remote-etcd-cmesh80                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh81                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh82                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh83                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh84                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh85                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh86                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh87                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh88                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh89                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh9                                                  7m36s ago      never        0       no error   
  remote-etcd-cmesh90                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh91                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh92                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh93                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh94                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh95                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh96                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh97                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh98                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh99                                                 7m36s ago      never        0       no error   
  resolve-identity-2206                                               24s ago        never        0       no error   
  resolve-identity-227                                                2m43s ago      never        0       no error   
  resolve-identity-3798                                               23s ago        never        0       no error   
  resolve-identity-4063                                               23s ago        never        0       no error   
  resolve-identity-476                                                23s ago        never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-7bd95d4974-jqnw8   7m43s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-8twpf                  10m23s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-99xv9                  10m23s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      10m24s ago     never        0       no error   
  sync-policymap-2206                                                 10m23s ago     never        0       no error   
  sync-policymap-227                                                  7m43s ago      never        0       no error   
  sync-policymap-3798                                                 10m20s ago     never        0       no error   
  sync-policymap-4063                                                 10m20s ago     never        0       no error   
  sync-policymap-476                                                  10m20s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (227)                                    13s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (3798)                                   13s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (4063)                                   13s ago        never        0       no error   
  sync-utime                                                          24s ago        never        0       no error   
  write-cni-file                                                      10m27s ago     never        0       no error   
Proxy Status:            OK, ip 10.112.0.163, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 7405568, max 7471103
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 110.28   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
egress-masquerade-interfaces:ens+
encrypt-interface:
tofqdns-enable-dns-compression:true
enable-pmtu-discovery:false
enable-monitor:true
bpf-fragments-map-max:8192
bpf-events-drop-enabled:true
monitor-aggregation:medium
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
kvstore-max-consecutive-quorum-errors:2
k8s-heartbeat-timeout:30s
bpf-neigh-global-max:524288
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
ipv6-service-range:auto
bpf-lb-acceleration:disabled
cmdref:
local-router-ipv4:
ipv4-node:auto
cluster-health-port:4240
mesh-auth-rotated-identities-queue-size:1024
bpf-lb-map-max:65536
srv6-encap-mode:reduced
log-system-load:false
bpf-lb-sock-terminate-pod-connections:false
envoy-keep-cap-netbindservice:false
bpf-lb-external-clusterip:false
bpf-lb-rss-ipv6-src-cidr:
nat-map-stats-interval:30s
vtep-endpoint:
bpf-policy-map-full-reconciliation-interval:15m0s
mesh-auth-spiffe-trust-domain:spiffe.cilium
ipam-multi-pool-pre-allocation:
enable-k8s-terminating-endpoint:true
policy-accounting:true
hubble-socket-path:/var/run/cilium/hubble.sock
bpf-sock-rev-map-max:262144
encryption-strict-mode-allow-remote-node-identities:false
hubble-drop-events-interval:2m0s
bgp-config-path:/var/lib/cilium/bgp/config.yaml
enable-envoy-config:false
debug-verbose:
ipv6-mcast-device:
enable-host-firewall:false
bpf-node-map-max:16384
bypass-ip-availability-upon-restore:false
enable-runtime-device-detection:true
enable-endpoint-health-checking:true
auto-create-cilium-node-resource:true
envoy-secrets-namespace:
dnsproxy-insecure-skip-transparent-mode-check:false
local-max-addr-scope:252
enable-xdp-prefilter:false
enable-k8s:true
annotate-k8s-node:false
proxy-xff-num-trusted-hops-egress:0
ipv4-service-range:auto
ingress-secrets-namespace:
ipv6-node:auto
nodes-gc-interval:5m0s
mesh-auth-enabled:true
log-driver:
enable-mke:false
arping-refresh-period:30s
enable-k8s-api-discovery:false
ipv6-native-routing-cidr:
tunnel-protocol:vxlan
identity-allocation-mode:crd
bpf-lb-sock:false
disable-external-ip-mitigation:false
bpf-lb-affinity-map-max:0
node-port-range:
enable-ipv6-big-tcp:false
lib-dir:/var/lib/cilium
policy-audit-mode:false
proxy-xff-num-trusted-hops-ingress:0
hubble-disable-tls:false
config:
prepend-iptables-chains:true
dnsproxy-socket-linger-timeout:10
identity-change-grace-period:5s
hubble-event-buffer-capacity:4095
hubble-export-denylist:
envoy-config-retry-interval:15s
proxy-gid:1337
proxy-idle-timeout-seconds:60
tofqdns-proxy-port:0
hubble-prefer-ipv6:false
http-retry-timeout:0
tofqdns-pre-cache:
bpf-lb-rss-ipv4-src-cidr:
enable-recorder:false
tofqdns-dns-reject-response-code:refused
hubble-export-file-path:
enable-gateway-api:false
pprof-address:localhost
bpf-events-trace-enabled:true
synchronize-k8s-nodes:true
remove-cilium-node-taints:true
bpf-ct-timeout-service-tcp-grace:1m0s
allow-icmp-frag-needed:true
vtep-mask:
enable-k8s-endpoint-slice:true
bpf-nat-global-max:524288
disable-envoy-version-check:false
bpf-map-event-buffers:
kvstore-opt:
bpf-root:/sys/fs/bpf
http-request-timeout:3600
force-device-detection:false
envoy-config-timeout:2m0s
container-ip-local-reserved-ports:auto
bpf-events-policy-verdict-enabled:true
enable-ipv4-masquerade:true
k8s-require-ipv4-pod-cidr:false
enable-high-scale-ipcache:false
conntrack-gc-max-interval:0s
bpf-ct-global-tcp-max:524288
mesh-auth-queue-size:1024
set-cilium-is-up-condition:true
kube-proxy-replacement:false
mesh-auth-gc-interval:5m0s
enable-tcx:true
dnsproxy-lock-count:131
mesh-auth-spire-admin-socket:
allow-localhost:auto
proxy-admin-port:0
mesh-auth-mutual-listener-port:0
mke-cgroup-mount:
bpf-lb-maglev-map-max:0
hubble-monitor-events:
bpf-ct-timeout-regular-tcp-fin:10s
ipv4-native-routing-cidr:
bpf-lb-maglev-table-size:16381
enable-ipv4-big-tcp:false
tofqdns-endpoint-max-ip-per-hostname:50
gateway-api-secrets-namespace:
enable-svc-source-range-check:true
tofqdns-idle-connection-grace-period:0s
bpf-lb-algorithm:random
enable-host-port:false
tofqdns-min-ttl:0
ipsec-key-rotation-duration:5m0s
enable-endpoint-routes:false
enable-external-ips:false
k8s-client-connection-keep-alive:30s
state-dir:/var/run/cilium
enable-unreachable-routes:false
enable-ipv6-ndp:false
ipam:cluster-pool
controller-group-metrics:
hubble-recorder-storage-path:/var/run/cilium/pcaps
encryption-strict-mode-cidr:
version:false
proxy-connect-timeout:2
ipv6-cluster-alloc-cidr:f00d::/64
monitor-queue-size:0
hubble-drop-events-reasons:auth_required,policy_denied
enable-local-redirect-policy:false
enable-ipv4-egress-gateway:false
read-cni-conf:
k8s-client-connection-timeout:30s
ipv6-pod-subnets:
http-max-grpc-timeout:0
k8s-api-server:
enable-ipv6:false
enable-ingress-controller:false
enable-k8s-networkpolicy:true
hubble-redact-enabled:false
enable-vtep:false
enable-custom-calls:false
ipsec-key-file:
enable-service-topology:false
socket-path:/var/run/cilium/cilium.sock
iptables-lock-timeout:5s
install-no-conntrack-iptables-rules:false
metrics:
cluster-pool-ipv4-cidr:10.112.0.0/16
max-connected-clusters:255
hubble-redact-http-urlquery:false
restore:true
bpf-ct-timeout-regular-tcp:2h13m20s
use-cilium-internal-ip-for-ipsec:false
egress-gateway-policy-map-max:16384
kvstore-connectivity-timeout:2m0s
fixed-identity-mapping:
envoy-base-id:0
hubble-redact-kafka-apikey:false
auto-direct-node-routes:false
enable-bandwidth-manager:false
enable-tracing:false
local-router-ipv6:
enable-health-check-nodeport:true
enable-ipip-termination:false
mtu:0
encrypt-node:false
enable-encryption-strict-mode:false
monitor-aggregation-flags:all
hubble-redact-http-userinfo:true
kvstore:
enable-bpf-clock-probe:false
hubble-export-file-compress:false
enable-bpf-tproxy:false
dnsproxy-concurrency-processing-grace-period:0s
cni-log-file:/var/run/cilium/cilium-cni.log
ipv6-range:auto
set-cilium-node-taints:true
l2-announcements-retry-period:2s
cluster-name:cmesh113
clustermesh-sync-timeout:1m0s
proxy-prometheus-port:0
enable-health-check-loadbalancer-ip:false
enable-bbr:false
egress-gateway-reconciliation-trigger-interval:1s
clustermesh-config:/var/lib/cilium/clustermesh/
enable-node-selector-labels:false
tunnel-port:0
kvstore-lease-ttl:15m0s
endpoint-queue-size:25
preallocate-bpf-maps:false
k8s-client-qps:10
proxy-portrange-max:20000
vtep-cidr:
enable-nat46x64-gateway:false
bpf-lb-dsr-dispatch:opt
node-port-acceleration:disabled
hubble-drop-events:false
kube-proxy-replacement-healthz-bind-address:
log-opt:
bpf-lb-source-range-map-max:0
enable-bgp-control-plane:false
enable-route-mtu-for-cni-chaining:false
bpf-lb-service-map-max:0
enable-active-connection-tracking:false
bpf-map-dynamic-size-ratio:0.0025
dns-policy-unload-on-shutdown:false
iptables-random-fully:false
enable-ipsec-encrypted-overlay:false
vlan-bpf-bypass:
proxy-portrange-min:10000
unmanaged-pod-watcher-interval:15
enable-cilium-health-api-server-access:
ip-masq-agent-config-path:/etc/config/ip-masq-agent
exclude-node-label-patterns:
direct-routing-skip-unreachable:false
enable-auto-protect-node-port-range:true
bpf-lb-dsr-l4-xlate:frontend
hubble-skip-unknown-cgroup-ids:true
enable-bpf-masquerade:false
policy-trigger-interval:1s
bpf-policy-map-max:16384
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
agent-health-port:9879
external-envoy-proxy:true
bpf-lb-rev-nat-map-max:0
exclude-local-address:
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
identity-heartbeat-timeout:30m0s
enable-cilium-endpoint-slice:false
crd-wait-timeout:5m0s
hubble-flowlogs-config-path:
clustermesh-enable-endpoint-sync:false
enable-l2-announcements:false
bgp-announce-pod-cidr:false
node-port-mode:snat
enable-xt-socket-fallback:true
k8s-kubeconfig-path:
enable-ipsec-xfrm-state-caching:true
pprof:false
bpf-ct-timeout-regular-tcp-syn:1m0s
hubble-export-fieldmask:
clustermesh-ip-identities-sync-timeout:1m0s
cluster-pool-ipv4-mask-size:24
labels:
endpoint-gc-interval:5m0s
devices:
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
bgp-announce-lb-ip:false
route-metric:0
cflags:
keep-config:false
hubble-event-queue-size:0
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
identity-restore-grace-period:30s
operator-prometheus-serve-addr::9963
cni-external-routing:false
enable-cilium-api-server-access:
bpf-ct-timeout-service-tcp:2h13m20s
k8s-client-burst:20
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
tofqdns-max-deferred-connection-deletes:10000
hubble-recorder-sink-queue-size:1024
max-controller-interval:0
kvstore-periodic-sync:5m0s
pprof-port:6060
egress-multi-home-ip-rule-compat:false
node-port-bind-protection:true
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
proxy-max-connection-duration-seconds:0
use-full-tls-context:false
gops-port:9890
enable-ip-masq-agent:false
enable-stale-cilium-endpoint-cleanup:true
enable-icmp-rules:true
enable-ipv6-masquerade:true
k8s-service-proxy-name:
enable-session-affinity:false
node-port-algorithm:random
disable-endpoint-crd:false
fqdn-regex-compile-lru-size:1024
k8s-service-cache-size:128
cluster-id:113
ipv4-range:auto
enable-masquerade-to-route-source:false
cgroup-root:/run/cilium/cgroupv2
hubble-metrics-server:
enable-health-checking:true
clustermesh-enable-mcs-api:false
enable-l2-pod-announcements:false
ipam-cilium-node-update-rate:15s
enable-l2-neigh-discovery:true
enable-srv6:false
max-internal-timer-delay:0s
trace-payloadlen:128
bpf-lb-service-backend-map-max:0
enable-ipv4-fragment-tracking:true
allocator-list-timeout:3m0s
direct-routing-device:
agent-labels:
k8s-namespace:kube-system
hubble-export-file-max-backups:5
enable-hubble:true
routing-mode:tunnel
enable-ipv4:true
enable-node-port:false
l2-pod-announcements-interface:
custom-cni-conf:false
ipv4-pod-subnets:
datapath-mode:veth
hubble-listen-address::4244
mesh-auth-signal-backoff-duration:1s
hubble-redact-http-headers-deny:
node-labels:
enable-local-node-route:true
nodeport-addresses:
procfs:/host/proc
enable-policy:default
http-retry-count:3
bpf-ct-timeout-service-any:1m0s
http-idle-timeout:0
k8s-sync-timeout:3m0s
ipam-default-ip-pool:default
hubble-metrics:
hubble-export-file-max-size-mb:10
endpoint-bpf-prog-watchdog-interval:30s
bpf-filter-priority:1
bpf-ct-global-any-max:262144
dnsproxy-lock-timeout:500ms
bpf-auth-map-max:524288
k8s-require-ipv6-pod-cidr:false
bpf-ct-timeout-regular-any:1m0s
join-cluster:false
proxy-max-requests-per-connection:0
identity-gc-interval:15m0s
operator-api-serve-addr:127.0.0.1:9234
enable-ipsec:false
enable-l7-proxy:true
hubble-export-allowlist:
l2-announcements-renew-deadline:5s
ipv4-service-loopback-address:169.254.42.1
tofqdns-proxy-response-max-delay:100ms
l2-announcements-lease-duration:15s
config-dir:/tmp/cilium/config-map
mesh-auth-mutual-connect-timeout:5s
wireguard-persistent-keepalive:0s
debug:false
prometheus-serve-addr:
api-rate-limit:
dnsproxy-enable-transparent-mode:true
enable-hubble-recorder-api:true
enable-identity-mark:true
service-no-backend-response:reject
cni-exclusive:true
dns-max-ips-per-restored-rule:1000
trace-sock:true
cni-chaining-mode:none
nat-map-stats-entries:32
enable-host-legacy-routing:false
cilium-endpoint-gc-interval:5m0s
enable-wireguard:false
enable-sctp:false
derive-masq-ip-addr-from-device:
config-sources:config-map:kube-system/cilium-config
policy-queue-size:100
policy-cidr-match-mode:
static-cnp-path:
bpf-lb-mode:snat
conntrack-gc-interval:0s
enable-wireguard-userspace-fallback:false
enable-well-known-identities:false
monitor-aggregation-interval:5s
vtep-mac:
http-normalize-path:true
bpf-lb-sock-hostns-only:false
agent-liveness-update-interval:1s
hubble-redact-http-headers-allow:
enable-ipsec-key-watcher:true
envoy-log:
multicast-enabled:false
label-prefix-file:
dnsproxy-concurrency-limit:0
certificates-directory:/var/run/cilium/certs
enable-metrics:true
disable-iptables-feeder-rules:
cni-chaining-target:
install-iptables-rules:true
```


#### Service list

```
ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.165.85:443 (active)     
                                         2 => 172.31.253.241:443 (active)    
2    10.100.110.200:443   ClusterIP      1 => 172.31.179.165:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.112.0.168:53 (active)       
                                         2 => 10.112.0.68:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.112.0.168:9153 (active)     
                                         2 => 10.112.0.68:9153 (active)      
5    10.100.187.60:2379   ClusterIP      1 => 10.112.0.199:2379 (active)     
```

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 37764495                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 37764495                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 37764495                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d400000 rw-p 00000000 00:00 0 
400d400000-4010000000 ---p 00000000 00:00 0 
ffff41a0d000-ffff41c13000 rw-p 00000000 00:00 0 
ffff41c1b000-ffff41d3c000 rw-p 00000000 00:00 0 
ffff41d3c000-ffff41d7d000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff41d7d000-ffff41dbe000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff41dbe000-ffff41dc0000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff41dc0000-ffff41dc2000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff41dc2000-ffff423c9000 rw-p 00000000 00:00 0 
ffff423c9000-ffff424c9000 rw-p 00000000 00:00 0 
ffff424c9000-ffff424da000 rw-p 00000000 00:00 0 
ffff424da000-ffff444da000 rw-p 00000000 00:00 0 
ffff444da000-ffff4455a000 ---p 00000000 00:00 0 
ffff4455a000-ffff4455b000 rw-p 00000000 00:00 0 
ffff4455b000-ffff6455a000 ---p 00000000 00:00 0 
ffff6455a000-ffff6455b000 rw-p 00000000 00:00 0 
ffff6455b000-ffff844ea000 ---p 00000000 00:00 0 
ffff844ea000-ffff844eb000 rw-p 00000000 00:00 0 
ffff844eb000-ffff884dc000 ---p 00000000 00:00 0 
ffff884dc000-ffff884dd000 rw-p 00000000 00:00 0 
ffff884dd000-ffff88cda000 ---p 00000000 00:00 0 
ffff88cda000-ffff88cdb000 rw-p 00000000 00:00 0 
ffff88cdb000-ffff88dda000 ---p 00000000 00:00 0 
ffff88dda000-ffff88e3a000 rw-p 00000000 00:00 0 
ffff88e3a000-ffff88e3c000 r--p 00000000 00:00 0                          [vvar]
ffff88e3c000-ffff88e3d000 r-xp 00000000 00:00 0                          [vdso]
ffffc8bcc000-ffffc8bed000 rw-p 00000000 00:00 0                          [stack]

```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4           STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                     
227        Disabled           Disabled          7430613    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.112.0.199   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh113                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                              
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=clustermesh-apiserver                                                                          
476        Disabled           Disabled          4          reserved:health                                                                     10.112.0.135   ready   
2206       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                    ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                      
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                                
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                 
                                                           reserved:host                                                                                              
3798       Disabled           Disabled          7435919    k8s:eks.amazonaws.com/component=coredns                                             10.112.0.68    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh113                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
4063       Disabled           Disabled          7435919    k8s:eks.amazonaws.com/component=coredns                                             10.112.0.168   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh113                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
```

#### BPF Policy Get 227

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3837328   36535     0        
Allow    Ingress     1          ANY          NONE         disabled    3821132   37552     0        
Allow    Egress      0          ANY          NONE         disabled    5179573   47697     0        

```


#### BPF CT List 227

```
Invalid argument: unknown type 227
```


#### Endpoint Get 227

```
[
  {
    "id": 227,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-227-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d8119194-1bbd-4206-a3f3-f3f9b9b0c1e3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-227",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:28.822Z",
            "success-count": 2
          },
          "uuid": "c82f98e6-83d9-42bb-ae4e-0fe89f48012b"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-7bd95d4974-jqnw8",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:28.820Z",
            "success-count": 1
          },
          "uuid": "b0eb8135-d70f-4fc2-939a-18e79b79c5cc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-227",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:28.852Z",
            "success-count": 1
          },
          "uuid": "924e58b8-b1cd-456e-b47a-a736cc1fc6ce"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (227)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:08.871Z",
            "success-count": 48
          },
          "uuid": "9c4c0391-9871-49b1-9574-32928a270d52"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "2810716117e830e462251028ca1e40c304f45f0ceeaf065b3a711202f6ed6b99:eth0",
        "container-id": "2810716117e830e462251028ca1e40c304f45f0ceeaf065b3a711202f6ed6b99",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-7bd95d4974-jqnw8",
        "pod-name": "kube-system/clustermesh-apiserver-7bd95d4974-jqnw8"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7430613,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh113",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7bd95d4974"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh113",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:37Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.112.0.199",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "fe:5e:a8:0c:f2:d5",
        "interface-index": 15,
        "interface-name": "lxccf3ba7995927",
        "mac": "2a:5a:00:64:a8:46"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7430613,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7430613,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 227

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 227

```
Timestamp              Status   State                   Message
2024-10-25T10:21:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:37Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:28Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:28Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:28Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 7430613

```
ID        LABELS
7430613   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh113
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 476

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    431579   5498      0        
Allow    Ingress     1          ANY          NONE         disabled    8982     105       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 476

```
Invalid argument: unknown type 476
```


#### Endpoint Get 476

```
[
  {
    "id": 476,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-476-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "e45f5afa-4fc6-4f90-9cd0-01358be36d1e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-476",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:48.664Z",
            "success-count": 3
          },
          "uuid": "79711ca0-5a6a-4f7d-8f4d-abc7066863df"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-476",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:18:51.535Z",
            "success-count": 1
          },
          "uuid": "b41798d3-b317-437c-8ba8-37622c2132e9"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:37Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.112.0.135",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "0e:2e:ff:f9:22:dd",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "3e:1a:d1:99:77:f2"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 476

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 476

```
Timestamp              Status   State                   Message
2024-10-25T10:21:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:37Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:18:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:18:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:18:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:18:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:18:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:18:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:48Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:18:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:18:48Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:18:47Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 2206

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2206

```
Invalid argument: unknown type 2206
```


#### Endpoint Get 2206

```
[
  {
    "id": 2206,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2206-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "82cc8f37-0b89-45c9-b5fb-9019891fac20"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2206",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:47.600Z",
            "success-count": 3
          },
          "uuid": "a530f371-82d4-4362-b112-4f32da478ae4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2206",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:18:48.566Z",
            "success-count": 1
          },
          "uuid": "2e70fa93-1ed1-496f-bfa6-22f161a12536"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:37Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "5a:9d:df:c2:46:e5",
        "interface-name": "cilium_host",
        "mac": "5a:9d:df:c2:46:e5"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2206

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2206

```
Timestamp              Status   State                   Message
2024-10-25T10:21:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:37Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:18:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:18:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:18:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:18:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:18:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:18:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:18:47Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:18:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:18:47Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:18:47Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 3798

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    57935   666       0        
Allow    Egress      0          ANY          NONE         disabled    11943   120       0        

```


#### BPF CT List 3798

```
Invalid argument: unknown type 3798
```


#### Endpoint Get 3798

```
[
  {
    "id": 3798,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3798-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "0ddde111-49fb-4ed6-a0fb-6242795ebac6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3798",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:49.007Z",
            "success-count": 3
          },
          "uuid": "0236c62b-4cdc-4f45-9490-d353c494ce0e"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-99xv9",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:18:49.005Z",
            "success-count": 1
          },
          "uuid": "5d5494e2-f1a9-4ac1-96bc-b87f4d7f7bc9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3798",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:18:51.569Z",
            "success-count": 1
          },
          "uuid": "a4319af6-3d76-478e-8bd1-3a7f71341707"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3798)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:09.069Z",
            "success-count": 64
          },
          "uuid": "14243870-ee79-4a1e-a018-d8dbce1dc6a8"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "fada8cb28a5ee36c06027cd55ebab69d5f35f0c82074cafbfd3c048756174599:eth0",
        "container-id": "fada8cb28a5ee36c06027cd55ebab69d5f35f0c82074cafbfd3c048756174599",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-99xv9",
        "pod-name": "kube-system/coredns-cc6ccd49c-99xv9"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7435919,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh113",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh113",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:37Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.112.0.68",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ca:1f:e7:1c:15:b2",
        "interface-index": 11,
        "interface-name": "lxc3999f75f07d5",
        "mac": "da:f9:b1:e9:0e:43"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7435919,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7435919,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3798

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3798

```
Timestamp              Status   State                   Message
2024-10-25T10:21:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:37Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:18:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:18:51Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:18:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:18:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:18:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:18:49Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:18:49Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 7435919

```
ID        LABELS
7435919   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh113
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 4063

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    58120   667       0        
Allow    Egress      0          ANY          NONE         disabled    11669   117       0        

```


#### BPF CT List 4063

```
Invalid argument: unknown type 4063
```


#### Endpoint Get 4063

```
[
  {
    "id": 4063,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-4063-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "46af28cb-0084-4b6a-8e23-4b7f5608123a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-4063",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:48.910Z",
            "success-count": 3
          },
          "uuid": "c1d8af9e-0d88-4c76-9dce-0367b27ffe8c"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-8twpf",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:18:48.909Z",
            "success-count": 1
          },
          "uuid": "15dac2ae-a803-4ed0-b172-b22255b04213"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-4063",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:18:51.516Z",
            "success-count": 1
          },
          "uuid": "3154ac51-6156-40cf-ade8-c4d2371ef176"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (4063)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:08.974Z",
            "success-count": 64
          },
          "uuid": "3c7f4548-8600-4fc9-ab1a-b34d452693dd"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "7aa70fdb9092a1a5af9802b7119774f56d4b4cc702900e18959937e551b6c349:eth0",
        "container-id": "7aa70fdb9092a1a5af9802b7119774f56d4b4cc702900e18959937e551b6c349",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-8twpf",
        "pod-name": "kube-system/coredns-cc6ccd49c-8twpf"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7435919,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh113",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh113",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:37Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.112.0.168",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "7a:bd:1c:e2:7d:76",
        "interface-index": 9,
        "interface-name": "lxcf6eb36248885",
        "mac": "5a:41:76:89:e6:a5"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7435919,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7435919,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 4063

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 4063

```
Timestamp              Status   State                   Message
2024-10-25T10:21:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:37Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:18:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:18:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:18:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:18:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:18:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:18:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:48Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:18:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:18:48Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:18:48Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 7435919

```
ID        LABELS
7435919   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh113
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### Policy get

```
:
 []
Revision: 1

```

