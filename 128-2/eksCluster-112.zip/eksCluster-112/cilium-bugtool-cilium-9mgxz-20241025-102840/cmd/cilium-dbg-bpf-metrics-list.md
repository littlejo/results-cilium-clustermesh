REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     10635     837186      677    bpf_overlay.c
Interface                 INGRESS     234179    101826533   1132   bpf_host.c
Success                   EGRESS      103116    13650238    1308   bpf_lxc.c
Success                   EGRESS      11248     880859      53     encap.h
Success                   EGRESS      5786      449513      1694   bpf_host.c
Success                   INGRESS     114513    14194025    86     l3.h
Success                   INGRESS     120011    14625604    235    trace.h
Unsupported L3 protocol   EGRESS      36        2692        1492   bpf_lxc.c
