fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxcf6eb36248885 proto kernel metric 256 pref medium
fe80::/64 dev lxc3999f75f07d5 proto kernel metric 256 pref medium
fe80::/64 dev lxccf3ba7995927 proto kernel metric 256 pref medium
