CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb2cfd88f_6630_48ae_84ae_254d426ad729.slice/cri-containerd-7aa70fdb9092a1a5af9802b7119774f56d4b4cc702900e18959937e551b6c349.scope
    502      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb2cfd88f_6630_48ae_84ae_254d426ad729.slice/cri-containerd-698f6058f1fa4b01d360fb1b171b3e064daf55d8dd8b095d5d1f96b454f92c0c.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod441f0488_673c_4d87_8c1a_1fadf563b6c8.slice/cri-containerd-abe5a33a125cb6e92c2ef3aa4cc05b02407faf571ed180cca10d7de834e57826.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod441f0488_673c_4d87_8c1a_1fadf563b6c8.slice/cri-containerd-029abf42a1f8e150ea505b73574477faa82175461fcef4da0713e012ede07db4.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb68014c7_9e98_4b34_8d85_59b5f00b005c.slice/cri-containerd-559c2c5605932b777b17ef7fff71df70079142c26ff3a83bac47f24b2cf3b3c4.scope
    542      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb68014c7_9e98_4b34_8d85_59b5f00b005c.slice/cri-containerd-fada8cb28a5ee36c06027cd55ebab69d5f35f0c82074cafbfd3c048756174599.scope
    508      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod674eade3_b250_4380_a171_f1499ec103bf.slice/cri-containerd-395344859a4ac03e2f1184b59f51015ba1fbab50878e833840df3b54f5c6a410.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod674eade3_b250_4380_a171_f1499ec103bf.slice/cri-containerd-d6560830b9dcfd30383b6e55934e31795d81cc45e8e5d5b46b4a8e3656054f32.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda6457b57_c273_465d_a8cf_4797669a4f79.slice/cri-containerd-f08cff51f785bf64e372fd851b119f6bbf4fe14f13f05200ab3c2c595f787f21.scope
    72       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda6457b57_c273_465d_a8cf_4797669a4f79.slice/cri-containerd-5938ae115f8cc73577736dcb1af88bb4075aaad6a15539dc7826565edd38ecf7.scope
    64       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86407db6_2d9d_4c7e_b7f6_064202e45cd8.slice/cri-containerd-dc0e7060ceb60c93ef662197c70d436b8f274fcf72870129800749f1fc5807a8.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86407db6_2d9d_4c7e_b7f6_064202e45cd8.slice/cri-containerd-66c09749911999b76d04233cb80022652de8e566815298290035df412b0e0dd9.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod81a316af_c75e_4c30_b2f4_f61fae8d1208.slice/cri-containerd-88e9d6d5c7ef2661b5ed549dd2e1fcfb5e09e634e01bfe7ad314fb8f0b199f18.scope
    620      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod81a316af_c75e_4c30_b2f4_f61fae8d1208.slice/cri-containerd-95d320a281b8f567a0aeedc11c52224693cc4810c824805aa18a5e364a1d7c74.scope
    612      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod81a316af_c75e_4c30_b2f4_f61fae8d1208.slice/cri-containerd-2810716117e830e462251028ca1e40c304f45f0ceeaf065b3a711202f6ed6b99.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod81a316af_c75e_4c30_b2f4_f61fae8d1208.slice/cri-containerd-69df501799dbc888c6d1ea83dce62c3d9486fc81ad4d0f5861d62b9ad7c169b4.scope
    616      cgroup_device   multi                                          
