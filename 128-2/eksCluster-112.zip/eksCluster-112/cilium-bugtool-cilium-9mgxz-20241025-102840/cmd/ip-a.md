1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:33:b4:cc:4b:9d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.179.165/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2970sec preferred_lft 2970sec
    inet6 fe80::433:b4ff:fecc:4b9d/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:4a:20:13:5f:ae brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ac4a:20ff:fe13:5fae/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:9d:df:c2:46:e5 brd ff:ff:ff:ff:ff:ff
    inet 10.112.0.163/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::589d:dfff:fec2:46e5/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ea:f4:80:38:da:e0 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e8f4:80ff:fe38:dae0/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:2e:ff:f9:22:dd brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c2e:ffff:fef9:22dd/64 scope link 
       valid_lft forever preferred_lft forever
9: lxcf6eb36248885@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:bd:1c:e2:7d:76 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::78bd:1cff:fee2:7d76/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc3999f75f07d5@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:1f:e7:1c:15:b2 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c81f:e7ff:fe1c:15b2/64 scope link 
       valid_lft forever preferred_lft forever
15: lxccf3ba7995927@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:5e:a8:0c:f2:d5 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::fc5e:a8ff:fe0c:f2d5/64 scope link 
       valid_lft forever preferred_lft forever
