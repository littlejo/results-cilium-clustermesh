markdown output at /tmp/cilium-bugtool-20241025-102841.706+0000-UTC-2347085021/cmd/cilium-debuginfo-20241025-102912.293+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102841.706+0000-UTC-2347085021/cmd/cilium-debuginfo-20241025-102912.293+0000-UTC.json
