{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:47.485Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.179.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:47.485Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:51.515Z",
  "value": "id=4063  sec_id=7435919 flags=0x0000 ifindex=9   mac=5A:41:76:89:E6:A5 nodemac=7A:BD:1C:E2:7D:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:51.525Z",
  "value": "id=476   sec_id=4     flags=0x0000 ifindex=7   mac=3E:1A:D1:99:77:F2 nodemac=0E:2E:FF:F9:22:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:51.565Z",
  "value": "id=3798  sec_id=7435919 flags=0x0000 ifindex=11  mac=DA:F9:B1:E9:0E:43 nodemac=CA:1F:E7:1C:15:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:51.618Z",
  "value": "id=4063  sec_id=7435919 flags=0x0000 ifindex=9   mac=5A:41:76:89:E6:A5 nodemac=7A:BD:1C:E2:7D:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:51.681Z",
  "value": "id=476   sec_id=4     flags=0x0000 ifindex=7   mac=3E:1A:D1:99:77:F2 nodemac=0E:2E:FF:F9:22:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:00.859Z",
  "value": "id=476   sec_id=4     flags=0x0000 ifindex=7   mac=3E:1A:D1:99:77:F2 nodemac=0E:2E:FF:F9:22:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:00.859Z",
  "value": "id=4063  sec_id=7435919 flags=0x0000 ifindex=9   mac=5A:41:76:89:E6:A5 nodemac=7A:BD:1C:E2:7D:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:00.860Z",
  "value": "id=3798  sec_id=7435919 flags=0x0000 ifindex=11  mac=DA:F9:B1:E9:0E:43 nodemac=CA:1F:E7:1C:15:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:00.898Z",
  "value": "id=1016  sec_id=7430613 flags=0x0000 ifindex=13  mac=52:28:E9:D9:E8:19 nodemac=B2:32:54:FC:FA:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:01.860Z",
  "value": "id=1016  sec_id=7430613 flags=0x0000 ifindex=13  mac=52:28:E9:D9:E8:19 nodemac=B2:32:54:FC:FA:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:01.860Z",
  "value": "id=476   sec_id=4     flags=0x0000 ifindex=7   mac=3E:1A:D1:99:77:F2 nodemac=0E:2E:FF:F9:22:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:01.861Z",
  "value": "id=4063  sec_id=7435919 flags=0x0000 ifindex=9   mac=5A:41:76:89:E6:A5 nodemac=7A:BD:1C:E2:7D:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:01.861Z",
  "value": "id=3798  sec_id=7435919 flags=0x0000 ifindex=11  mac=DA:F9:B1:E9:0E:43 nodemac=CA:1F:E7:1C:15:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:28.851Z",
  "value": "id=227   sec_id=7430613 flags=0x0000 ifindex=15  mac=2A:5A:00:64:A8:46 nodemac=FE:5E:A8:0C:F2:D5"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.112.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:35.268Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:35.531Z",
  "value": "id=3798  sec_id=7435919 flags=0x0000 ifindex=11  mac=DA:F9:B1:E9:0E:43 nodemac=CA:1F:E7:1C:15:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:35.531Z",
  "value": "id=227   sec_id=7430613 flags=0x0000 ifindex=15  mac=2A:5A:00:64:A8:46 nodemac=FE:5E:A8:0C:F2:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:35.532Z",
  "value": "id=476   sec_id=4     flags=0x0000 ifindex=7   mac=3E:1A:D1:99:77:F2 nodemac=0E:2E:FF:F9:22:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:35.532Z",
  "value": "id=4063  sec_id=7435919 flags=0x0000 ifindex=9   mac=5A:41:76:89:E6:A5 nodemac=7A:BD:1C:E2:7D:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:36.530Z",
  "value": "id=476   sec_id=4     flags=0x0000 ifindex=7   mac=3E:1A:D1:99:77:F2 nodemac=0E:2E:FF:F9:22:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:36.531Z",
  "value": "id=4063  sec_id=7435919 flags=0x0000 ifindex=9   mac=5A:41:76:89:E6:A5 nodemac=7A:BD:1C:E2:7D:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:36.531Z",
  "value": "id=227   sec_id=7430613 flags=0x0000 ifindex=15  mac=2A:5A:00:64:A8:46 nodemac=FE:5E:A8:0C:F2:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:36.531Z",
  "value": "id=3798  sec_id=7435919 flags=0x0000 ifindex=11  mac=DA:F9:B1:E9:0E:43 nodemac=CA:1F:E7:1C:15:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:37.531Z",
  "value": "id=476   sec_id=4     flags=0x0000 ifindex=7   mac=3E:1A:D1:99:77:F2 nodemac=0E:2E:FF:F9:22:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:37.531Z",
  "value": "id=227   sec_id=7430613 flags=0x0000 ifindex=15  mac=2A:5A:00:64:A8:46 nodemac=FE:5E:A8:0C:F2:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:37.532Z",
  "value": "id=4063  sec_id=7435919 flags=0x0000 ifindex=9   mac=5A:41:76:89:E6:A5 nodemac=7A:BD:1C:E2:7D:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:37.532Z",
  "value": "id=3798  sec_id=7435919 flags=0x0000 ifindex=11  mac=DA:F9:B1:E9:0E:43 nodemac=CA:1F:E7:1C:15:B2"
}

