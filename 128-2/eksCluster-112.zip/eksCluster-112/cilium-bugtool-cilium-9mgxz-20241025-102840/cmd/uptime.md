 10:28:41 up 10 min,  0 users,  load average: 0.06, 0.12, 0.12
