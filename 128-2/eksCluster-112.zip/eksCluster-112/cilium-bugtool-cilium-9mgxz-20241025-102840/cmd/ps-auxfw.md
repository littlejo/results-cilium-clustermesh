USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         670  0.0  0.0 1228744 3780 ?        Ssl  10:28   0:00 /bin/gops memstats 1
root         639  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root         637  0.0  0.4 1240432 16704 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         677  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         632  0.0  0.0 1228744 3596 ?        Ssl  10:28   0:00 /bin/gops stack 1
root           1  3.2  7.2 1538356 284468 ?      Ssl  10:18   0:19 cilium-agent --config-dir=/tmp/cilium/config-map
root         392  0.0  0.1 1228848 6644 ?        Sl   10:18   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
