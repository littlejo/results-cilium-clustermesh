top - 10:28:41 up 10 min,  0 users,  load average: 0.06, 0.12, 0.12
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 14.8 us, 18.5 sy,  0.0 ni, 66.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1182.6 free,    896.8 used,   1756.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2771.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538356 284468  78628 S   6.7   7.2   0:19.37 cilium-+
    637 root      20   0 1240432  16704  11484 S   6.7   0.4   0:00.02 cilium-+
    392 root      20   0 1228848   6644   3836 S   0.0   0.2   0:00.22 cilium-+
    632 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    639 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    670 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
    697 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    715 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
