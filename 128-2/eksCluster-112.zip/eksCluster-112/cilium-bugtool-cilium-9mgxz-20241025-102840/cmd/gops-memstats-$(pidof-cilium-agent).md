alloc: 115.31MB (120912312 bytes)
total-alloc: 1.42GB (1525408600 bytes)
sys: 214.63MB (225060180 bytes)
lookups: 0
mallocs: 49083847
frees: 47895818
heap-alloc: 115.31MB (120912312 bytes)
heap-sys: 166.63MB (174727168 bytes)
heap-idle: 26.97MB (28278784 bytes)
heap-in-use: 139.66MB (146448384 bytes)
heap-released: 2.85MB (2990080 bytes)
heap-objects: 1188029
stack-in-use: 37.34MB (39157760 bytes)
stack-sys: 37.34MB (39157760 bytes)
stack-mspan-inuse: 2.25MB (2356480 bytes)
stack-mspan-sys: 2.54MB (2660160 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1009.16KB (1033377 bytes)
gc-sys: 5.19MB (5442032 bytes)
next-gc: when heap-alloc >= 146.26MB (153367576 bytes)
last-gc: 2024-10-25 10:28:44.711928249 +0000 UTC
gc-pause-total: 8.253909ms
gc-pause: 67685
gc-pause-end: 1729852124711928249
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.0005077688567007025
enable-gc: true
debug-gc: false
