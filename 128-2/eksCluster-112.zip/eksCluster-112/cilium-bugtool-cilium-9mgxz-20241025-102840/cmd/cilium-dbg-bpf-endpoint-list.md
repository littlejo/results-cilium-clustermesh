IP ADDRESS         LOCAL ENDPOINT INFO
10.112.0.168:0     id=4063  sec_id=7435919 flags=0x0000 ifindex=9   mac=5A:41:76:89:E6:A5 nodemac=7A:BD:1C:E2:7D:76   
10.112.0.68:0      id=3798  sec_id=7435919 flags=0x0000 ifindex=11  mac=DA:F9:B1:E9:0E:43 nodemac=CA:1F:E7:1C:15:B2   
10.112.0.163:0     (localhost)                                                                                        
10.112.0.135:0     id=476   sec_id=4     flags=0x0000 ifindex=7   mac=3E:1A:D1:99:77:F2 nodemac=0E:2E:FF:F9:22:DD     
172.31.179.165:0   (localhost)                                                                                        
10.112.0.199:0     id=227   sec_id=7430613 flags=0x0000 ifindex=15  mac=2A:5A:00:64:A8:46 nodemac=FE:5E:A8:0C:F2:D5   
