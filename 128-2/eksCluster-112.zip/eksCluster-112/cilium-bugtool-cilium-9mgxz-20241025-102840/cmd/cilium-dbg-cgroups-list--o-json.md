[
  {
    "containers": [
      {
        "cgroup-id": 8296,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod81a316af_c75e_4c30_b2f4_f61fae8d1208.slice/cri-containerd-69df501799dbc888c6d1ea83dce62c3d9486fc81ad4d0f5861d62b9ad7c169b4.scope"
      },
      {
        "cgroup-id": 8212,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod81a316af_c75e_4c30_b2f4_f61fae8d1208.slice/cri-containerd-95d320a281b8f567a0aeedc11c52224693cc4810c824805aa18a5e364a1d7c74.scope"
      },
      {
        "cgroup-id": 8380,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod81a316af_c75e_4c30_b2f4_f61fae8d1208.slice/cri-containerd-88e9d6d5c7ef2661b5ed549dd2e1fcfb5e09e634e01bfe7ad314fb8f0b199f18.scope"
      }
    ],
    "ips": [
      "10.112.0.199"
    ],
    "name": "clustermesh-apiserver-7bd95d4974-jqnw8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6784,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb2cfd88f_6630_48ae_84ae_254d426ad729.slice/cri-containerd-698f6058f1fa4b01d360fb1b171b3e064daf55d8dd8b095d5d1f96b454f92c0c.scope"
      }
    ],
    "ips": [
      "10.112.0.168"
    ],
    "name": "coredns-cc6ccd49c-8twpf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6868,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb68014c7_9e98_4b34_8d85_59b5f00b005c.slice/cri-containerd-559c2c5605932b777b17ef7fff71df70079142c26ff3a83bac47f24b2cf3b3c4.scope"
      }
    ],
    "ips": [
      "10.112.0.68"
    ],
    "name": "coredns-cc6ccd49c-99xv9",
    "namespace": "kube-system"
  }
]

