Endpoint ID: 227
Path: /sys/fs/bpf/tc/globals/cilium_policy_00227

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3841672   36583     0        
Allow    Ingress     1          ANY          NONE         disabled    3821132   37552     0        
Allow    Egress      0          ANY          NONE         disabled    5187425   47784     0        


Endpoint ID: 476
Path: /sys/fs/bpf/tc/globals/cilium_policy_00476

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    432635   5511      0        
Allow    Ingress     1          ANY          NONE         disabled    8982     105       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2206
Path: /sys/fs/bpf/tc/globals/cilium_policy_02206

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3798
Path: /sys/fs/bpf/tc/globals/cilium_policy_03798

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    57935   666       0        
Allow    Egress      0          ANY          NONE         disabled    11943   120       0        


Endpoint ID: 4063
Path: /sys/fs/bpf/tc/globals/cilium_policy_04063

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    58120   667       0        
Allow    Egress      0          ANY          NONE         disabled    11669   117       0        


