key: e3 00 00 00  value: 46 02 00 00
key: dc 01 00 00  value: 00 02 00 00
key: d6 0e 00 00  value: e0 01 00 00
key: df 0f 00 00  value: ed 01 00 00
Found 4 elements
