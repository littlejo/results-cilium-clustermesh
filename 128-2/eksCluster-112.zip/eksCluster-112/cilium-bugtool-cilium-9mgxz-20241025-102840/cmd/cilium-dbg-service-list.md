ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.165.85:443 (active)     
                                         2 => 172.31.253.241:443 (active)    
2    10.100.110.200:443   ClusterIP      1 => 172.31.179.165:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.112.0.168:53 (active)       
                                         2 => 10.112.0.68:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.112.0.168:9153 (active)     
                                         2 => 10.112.0.68:9153 (active)      
5    10.100.187.60:2379   ClusterIP      1 => 10.112.0.199:2379 (active)     
