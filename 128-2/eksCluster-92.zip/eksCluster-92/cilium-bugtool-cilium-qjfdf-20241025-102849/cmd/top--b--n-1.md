top - 10:28:51 up 14 min,  0 users,  load average: 0.56, 0.31, 0.21
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 20.0 us, 30.0 sy,  0.0 ni, 46.7 id,  0.0 wa,  0.0 hi,  0.0 si,  3.3 st
MiB Mem :   3836.2 total,    773.8 free,    921.0 used,   2141.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2746.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 281972  79104 S   6.7   7.2   0:23.35 cilium-+
    691 root      20   0 1240432  16176  10960 S   6.7   0.4   0:00.03 cilium-+
    415 root      20   0 1228848   6684   3844 S   0.0   0.2   0:00.27 cilium-+
    677 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    723 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    742 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    748 root      20   0 1615752   8304   6236 S   0.0   0.2   0:00.00 runc:[2+
    754 root      20   0 1616520   8736   6236 S   0.0   0.2   0:00.00 runc:[2+
