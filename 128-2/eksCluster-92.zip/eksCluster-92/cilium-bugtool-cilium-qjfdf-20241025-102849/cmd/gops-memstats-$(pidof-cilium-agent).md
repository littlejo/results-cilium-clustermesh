alloc: 82.90MB (86930312 bytes)
total-alloc: 1.33GB (1430283744 bytes)
sys: 206.38MB (216409428 bytes)
lookups: 0
mallocs: 47795978
frees: 47060555
heap-alloc: 82.90MB (86930312 bytes)
heap-sys: 161.51MB (169353216 bytes)
heap-idle: 45.55MB (47759360 bytes)
heap-in-use: 115.96MB (121593856 bytes)
heap-released: 1.89MB (1982464 bytes)
heap-objects: 735423
stack-in-use: 34.47MB (36143104 bytes)
stack-sys: 34.47MB (36143104 bytes)
stack-mspan-inuse: 1.94MB (2031840 bytes)
stack-mspan-sys: 2.51MB (2627520 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 906.70KB (928457 bytes)
gc-sys: 5.13MB (5384376 bytes)
next-gc: when heap-alloc >= 147.34MB (154499112 bytes)
last-gc: 2024-10-25 10:29:00.854227177 +0000 UTC
gc-pause-total: 7.997436ms
gc-pause: 110352
gc-pause-end: 1729852140854227177
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0003011986574702672
enable-gc: true
debug-gc: false
