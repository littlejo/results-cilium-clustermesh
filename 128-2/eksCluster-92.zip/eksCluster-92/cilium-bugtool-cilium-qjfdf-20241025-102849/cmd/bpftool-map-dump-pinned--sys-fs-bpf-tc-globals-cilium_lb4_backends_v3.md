key: 08 00 00 00  value: 0a 5c 00 a6 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 5c 00 a3 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 5c 00 9b 09 4b 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 5c 00 a3 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f b4 c6 01 bb 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f ec 28 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f 81 b8 10 94 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 5c 00 a6 23 c1 00 00  00 00 00 00
Found 8 elements
