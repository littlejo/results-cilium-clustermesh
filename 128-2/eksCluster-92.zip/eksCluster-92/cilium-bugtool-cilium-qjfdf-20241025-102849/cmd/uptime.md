 10:28:51 up 14 min,  0 users,  load average: 0.56, 0.31, 0.21
