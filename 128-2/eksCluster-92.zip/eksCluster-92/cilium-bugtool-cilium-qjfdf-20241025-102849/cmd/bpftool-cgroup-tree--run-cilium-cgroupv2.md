CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod64e473f1_0309_45ff_9131_5d08d27b2a46.slice/cri-containerd-e2a120d1f1ede8865f0df97e7ec0b939309ff651fe4f8843030841d074f77ddb.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod64e473f1_0309_45ff_9131_5d08d27b2a46.slice/cri-containerd-4c58681bdcd85eeba8af1cd967413d3624da3b8f01f6601d653417968e2ba6b1.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3d50c8ca_54ec_45a6_909c_1df3ca1344ae.slice/cri-containerd-d8599d08fdcddd4f648492a50a17409cab88972f151da41eb08135e2f3fc8b57.scope
    543      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3d50c8ca_54ec_45a6_909c_1df3ca1344ae.slice/cri-containerd-02d92f56a581ee23af6edfeeb876b1c21536467cccdad170a6fe208271516457.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda8b8687c_8ce5_42df_9a7b_d0c66c36157e.slice/cri-containerd-527ab1c3cd8663bfb1d53048cc0ed7e4978c43def9e9307746d51f3f3212dd78.scope
    523      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda8b8687c_8ce5_42df_9a7b_d0c66c36157e.slice/cri-containerd-88b20660108033bfdb51c1d699fec2e6b87b23c37044b99173cee87fa1b1c40f.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf9e87bd8_5464_4c57_92cf_6e2819946690.slice/cri-containerd-bd77820a019456e9a2e667875a96ab86bc8d437f4bdc65d8e41f827368c68306.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf9e87bd8_5464_4c57_92cf_6e2819946690.slice/cri-containerd-94c3a4f1152695f351481f0ef6982de3a9c39fd8dc43a825005f25b234fb4fa4.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod895bad87_a848_451b_b60d_472ec417e44f.slice/cri-containerd-6763872ffbcece761b025ed7cc52340697dd3356c2ec27bfc00b676baa0dce5b.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod895bad87_a848_451b_b60d_472ec417e44f.slice/cri-containerd-60b7014e6848a462fa91657fa8a26a493f4c56abad043929a1dffdb5ee86ddbd.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod27422c7e_4e7e_4a64_ab8a_3ef155d67760.slice/cri-containerd-03167861fde907cd8edb2f3c04f10f9cd880e289d5c6470d044b85a53357fd35.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod27422c7e_4e7e_4a64_ab8a_3ef155d67760.slice/cri-containerd-4c821336a8eea7e12378d905721c134a3da104abf0a27de765ca6265b4acf52c.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56987404_d288_4ff7_90b2_7df41ca74ca4.slice/cri-containerd-c2932cd5b6458aabdee86755c20f2ec5a9607f5618f33327ad635d3694e93ff4.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56987404_d288_4ff7_90b2_7df41ca74ca4.slice/cri-containerd-29da779d7847407eaa28cf0759d213f9e1d3849cfbbbbb1d4bb0435b397a111e.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56987404_d288_4ff7_90b2_7df41ca74ca4.slice/cri-containerd-0dbd2c1f4f390e7897eb6934f53c9d7bba9f82f72132e6ef75017984c28cf0fa.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56987404_d288_4ff7_90b2_7df41ca74ca4.slice/cri-containerd-12c0301aa26d8c8b0cc1b6c3fcfa522021b33889cd28570323f65101ed8d1836.scope
    637      cgroup_device   multi                                          
