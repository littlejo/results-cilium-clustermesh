{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:29.255Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.129.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:29.255Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.141.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:29.255Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:33.984Z",
  "value": "id=2410  sec_id=4     flags=0x0000 ifindex=10  mac=96:E6:F4:33:04:E2 nodemac=B6:57:00:56:70:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:33.990Z",
  "value": "id=327   sec_id=6133973 flags=0x0000 ifindex=12  mac=2E:45:E6:DB:92:D7 nodemac=CA:70:AB:1D:86:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:34.060Z",
  "value": "id=475   sec_id=6133973 flags=0x0000 ifindex=14  mac=7A:7E:15:4F:BB:4A nodemac=4E:BC:C5:D2:A1:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:34.150Z",
  "value": "id=2410  sec_id=4     flags=0x0000 ifindex=10  mac=96:E6:F4:33:04:E2 nodemac=B6:57:00:56:70:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:34.219Z",
  "value": "id=327   sec_id=6133973 flags=0x0000 ifindex=12  mac=2E:45:E6:DB:92:D7 nodemac=CA:70:AB:1D:86:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:17.910Z",
  "value": "id=2410  sec_id=4     flags=0x0000 ifindex=10  mac=96:E6:F4:33:04:E2 nodemac=B6:57:00:56:70:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:17.910Z",
  "value": "id=327   sec_id=6133973 flags=0x0000 ifindex=12  mac=2E:45:E6:DB:92:D7 nodemac=CA:70:AB:1D:86:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:17.910Z",
  "value": "id=475   sec_id=6133973 flags=0x0000 ifindex=14  mac=7A:7E:15:4F:BB:4A nodemac=4E:BC:C5:D2:A1:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:17.941Z",
  "value": "id=2161  sec_id=6096447 flags=0x0000 ifindex=16  mac=F2:30:C1:C5:81:CA nodemac=AA:F6:D3:DF:78:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:18.910Z",
  "value": "id=2410  sec_id=4     flags=0x0000 ifindex=10  mac=96:E6:F4:33:04:E2 nodemac=B6:57:00:56:70:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:18.910Z",
  "value": "id=2161  sec_id=6096447 flags=0x0000 ifindex=16  mac=F2:30:C1:C5:81:CA nodemac=AA:F6:D3:DF:78:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:18.910Z",
  "value": "id=327   sec_id=6133973 flags=0x0000 ifindex=12  mac=2E:45:E6:DB:92:D7 nodemac=CA:70:AB:1D:86:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:18.910Z",
  "value": "id=475   sec_id=6133973 flags=0x0000 ifindex=14  mac=7A:7E:15:4F:BB:4A nodemac=4E:BC:C5:D2:A1:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:16.753Z",
  "value": "id=833   sec_id=6096447 flags=0x0000 ifindex=18  mac=12:1E:1D:2E:98:98 nodemac=AE:07:68:ED:21:58"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.92.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:27.045Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:10.030Z",
  "value": "id=327   sec_id=6133973 flags=0x0000 ifindex=12  mac=2E:45:E6:DB:92:D7 nodemac=CA:70:AB:1D:86:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:10.031Z",
  "value": "id=475   sec_id=6133973 flags=0x0000 ifindex=14  mac=7A:7E:15:4F:BB:4A nodemac=4E:BC:C5:D2:A1:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:10.031Z",
  "value": "id=833   sec_id=6096447 flags=0x0000 ifindex=18  mac=12:1E:1D:2E:98:98 nodemac=AE:07:68:ED:21:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:10.032Z",
  "value": "id=2410  sec_id=4     flags=0x0000 ifindex=10  mac=96:E6:F4:33:04:E2 nodemac=B6:57:00:56:70:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:11.032Z",
  "value": "id=2410  sec_id=4     flags=0x0000 ifindex=10  mac=96:E6:F4:33:04:E2 nodemac=B6:57:00:56:70:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:11.032Z",
  "value": "id=327   sec_id=6133973 flags=0x0000 ifindex=12  mac=2E:45:E6:DB:92:D7 nodemac=CA:70:AB:1D:86:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:11.032Z",
  "value": "id=475   sec_id=6133973 flags=0x0000 ifindex=14  mac=7A:7E:15:4F:BB:4A nodemac=4E:BC:C5:D2:A1:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:11.033Z",
  "value": "id=833   sec_id=6096447 flags=0x0000 ifindex=18  mac=12:1E:1D:2E:98:98 nodemac=AE:07:68:ED:21:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:12.040Z",
  "value": "id=2410  sec_id=4     flags=0x0000 ifindex=10  mac=96:E6:F4:33:04:E2 nodemac=B6:57:00:56:70:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:12.041Z",
  "value": "id=327   sec_id=6133973 flags=0x0000 ifindex=12  mac=2E:45:E6:DB:92:D7 nodemac=CA:70:AB:1D:86:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:12.041Z",
  "value": "id=475   sec_id=6133973 flags=0x0000 ifindex=14  mac=7A:7E:15:4F:BB:4A nodemac=4E:BC:C5:D2:A1:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:12.042Z",
  "value": "id=833   sec_id=6096447 flags=0x0000 ifindex=18  mac=12:1E:1D:2E:98:98 nodemac=AE:07:68:ED:21:58"
}

