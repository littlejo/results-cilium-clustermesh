filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc3bce6d3e5c01 direct-action not_in_hw id 633 tag 336319fd8dea7041 jited 
