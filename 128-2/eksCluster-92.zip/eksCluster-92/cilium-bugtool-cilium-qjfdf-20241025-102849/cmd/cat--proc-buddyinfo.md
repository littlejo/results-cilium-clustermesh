Node 0, zone      DMA     89     25      3     12      6      2      3      1      3      2    165 
Node 0, zone   Normal     95     16     27     22     33      7      4      3      3      2      7 
