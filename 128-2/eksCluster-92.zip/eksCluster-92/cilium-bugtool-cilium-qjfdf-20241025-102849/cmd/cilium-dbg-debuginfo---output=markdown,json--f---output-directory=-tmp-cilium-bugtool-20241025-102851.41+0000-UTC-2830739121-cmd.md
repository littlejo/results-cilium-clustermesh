markdown output at /tmp/cilium-bugtool-20241025-102851.41+0000-UTC-2830739121/cmd/cilium-debuginfo-20241025-102921.83+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102851.41+0000-UTC-2830739121/cmd/cilium-debuginfo-20241025-102921.83+0000-UTC.json
