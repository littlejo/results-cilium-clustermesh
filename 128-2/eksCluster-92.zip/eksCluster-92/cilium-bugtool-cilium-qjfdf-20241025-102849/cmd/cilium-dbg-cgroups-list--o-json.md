[
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56987404_d288_4ff7_90b2_7df41ca74ca4.slice/cri-containerd-0dbd2c1f4f390e7897eb6934f53c9d7bba9f82f72132e6ef75017984c28cf0fa.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56987404_d288_4ff7_90b2_7df41ca74ca4.slice/cri-containerd-c2932cd5b6458aabdee86755c20f2ec5a9607f5618f33327ad635d3694e93ff4.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56987404_d288_4ff7_90b2_7df41ca74ca4.slice/cri-containerd-29da779d7847407eaa28cf0759d213f9e1d3849cfbbbbb1d4bb0435b397a111e.scope"
      }
    ],
    "ips": [
      "10.92.0.155"
    ],
    "name": "clustermesh-apiserver-7d6dcdb66c-26bq5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda8b8687c_8ce5_42df_9a7b_d0c66c36157e.slice/cri-containerd-88b20660108033bfdb51c1d699fec2e6b87b23c37044b99173cee87fa1b1c40f.scope"
      }
    ],
    "ips": [
      "10.92.0.163"
    ],
    "name": "coredns-cc6ccd49c-jqmgf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3d50c8ca_54ec_45a6_909c_1df3ca1344ae.slice/cri-containerd-02d92f56a581ee23af6edfeeb876b1c21536467cccdad170a6fe208271516457.scope"
      }
    ],
    "ips": [
      "10.92.0.166"
    ],
    "name": "coredns-cc6ccd49c-24hr7",
    "namespace": "kube-system"
  }
]

