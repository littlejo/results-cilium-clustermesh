ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.236.40:443 (active)     
                                          2 => 172.31.180.198:443 (active)    
2    10.100.68.176:443     ClusterIP      1 => 172.31.129.184:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.92.0.163:53 (active)        
                                          2 => 10.92.0.166:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.92.0.163:9153 (active)      
                                          2 => 10.92.0.166:9153 (active)      
5    10.100.187.145:2379   ClusterIP      1 => 10.92.0.155:2379 (active)      
