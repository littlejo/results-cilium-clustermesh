xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 573
ens6(5) clsact/ingress cil_from_netdev-ens6 id 583
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 568
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 561
cilium_host(7) clsact/egress cil_from_host-cilium_host id 556
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 529
lxceee847651472(12) clsact/ingress cil_from_container-lxceee847651472 id 534
lxc95b16dd4701c(14) clsact/ingress cil_from_container-lxc95b16dd4701c id 513
lxc3bce6d3e5c01(18) clsact/ingress cil_from_container-lxc3bce6d3e5c01 id 633

flow_dissector:

netfilter:

