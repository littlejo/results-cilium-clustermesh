key: 47 01 00 00  value: 17 02 00 00
key: db 01 00 00  value: 02 02 00 00
key: 41 03 00 00  value: 78 02 00 00
key: 6a 09 00 00  value: 12 02 00 00
Found 4 elements
