# Cilium debug information

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 37816031                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 37816031                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 37816031                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d400000 rw-p 00000000 00:00 0 
400d400000-4010000000 ---p 00000000 00:00 0 
ffff6f2d7000-ffff6f4bd000 rw-p 00000000 00:00 0 
ffff6f4c5000-ffff6f5e6000 rw-p 00000000 00:00 0 
ffff6f5e6000-ffff6f627000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff6f627000-ffff6f668000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff6f668000-ffff6f6a8000 rw-p 00000000 00:00 0 
ffff6f6a8000-ffff6f6aa000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff6f6aa000-ffff6f6ac000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff6f6ac000-ffff6fc53000 rw-p 00000000 00:00 0 
ffff6fc53000-ffff6fd53000 rw-p 00000000 00:00 0 
ffff6fd53000-ffff6fd64000 rw-p 00000000 00:00 0 
ffff6fd64000-ffff71d64000 rw-p 00000000 00:00 0 
ffff71d64000-ffff71de4000 ---p 00000000 00:00 0 
ffff71de4000-ffff71de5000 rw-p 00000000 00:00 0 
ffff71de5000-ffff91de4000 ---p 00000000 00:00 0 
ffff91de4000-ffff91de5000 rw-p 00000000 00:00 0 
ffff91de5000-ffffb1d74000 ---p 00000000 00:00 0 
ffffb1d74000-ffffb1d75000 rw-p 00000000 00:00 0 
ffffb1d75000-ffffb5d66000 ---p 00000000 00:00 0 
ffffb5d66000-ffffb5d67000 rw-p 00000000 00:00 0 
ffffb5d67000-ffffb6564000 ---p 00000000 00:00 0 
ffffb6564000-ffffb6565000 rw-p 00000000 00:00 0 
ffffb6565000-ffffb6664000 ---p 00000000 00:00 0 
ffffb6664000-ffffb66c4000 rw-p 00000000 00:00 0 
ffffb66c4000-ffffb66c6000 r--p 00000000 00:00 0                          [vvar]
ffffb66c6000-ffffb66c7000 r-xp 00000000 00:00 0                          [vdso]
ffffc587c000-ffffc589d000 rw-p 00000000 00:00 0                          [stack]

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.13.0.204": (string) (len=50) "kube-system/clustermesh-apiserver-6d5c89b589-97jrw",
  (string) (len=10) "10.13.0.68": (string) (len=6) "router",
  (string) (len=11) "10.13.0.139": (string) (len=6) "health",
  (string) (len=11) "10.13.0.156": (string) (len=35) "kube-system/coredns-cc6ccd49c-lbvdz",
  (string) (len=11) "10.13.0.254": (string) (len=35) "kube-system/coredns-cc6ccd49c-lvxsf"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.226.178": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40023e7c30)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4002252240,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4002252240,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x40021ab4a0)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40021ab550)(frontends:[10.100.252.182]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4001a9d080)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4001a9d130)(frontends:[10.100.131.26]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4001a9d290)(frontends:[10.100.0.10]/ports=[metrics dns dns-tcp]/selector=map[k8s-app:kube-dns])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4000ec9e98)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-bxjjf": (*k8s.Endpoints)(0x40016376c0)(172.31.226.178:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4000ec9ea0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-b79x4": (*k8s.Endpoints)(0x40037cfad0)(10.13.0.156:53/TCP[eu-west-3b],10.13.0.156:53/UDP[eu-west-3b],10.13.0.156:9153/TCP[eu-west-3b],10.13.0.254:53/TCP[eu-west-3b],10.13.0.254:53/UDP[eu-west-3b],10.13.0.254:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4000ec9058)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-vmjbh": (*k8s.Endpoints)(0x4003664d00)(10.13.0.204:2379/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4000ec9e90)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40016372b0)(172.31.134.69:443/TCP,172.31.210.92:443/TCP)
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4000284e00)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4002908f50)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400ac970c8
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4000ca7380,
  gcExited: (chan struct {}) 0x4000ca73e0,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4000177180)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001910690)({
      MetricVec: (*prometheus.MetricVec)(0x4000e46540)({
       metricMap: (*prometheus.metricMap)(0x4000e46570)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40008492c0)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4000177200)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001910698)({
      MetricVec: (*prometheus.MetricVec)(0x4000e465d0)({
       metricMap: (*prometheus.metricMap)(0x4000e46600)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000849320)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4000177280)({
     GaugeVec: (*prometheus.GaugeVec)(0x40019106a0)({
      MetricVec: (*prometheus.MetricVec)(0x4000e46660)({
       metricMap: (*prometheus.metricMap)(0x4000e46690)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000849380)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4000177300)({
     GaugeVec: (*prometheus.GaugeVec)(0x40019106a8)({
      MetricVec: (*prometheus.MetricVec)(0x4000e466f0)({
       metricMap: (*prometheus.metricMap)(0x4000e46720)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000849440)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4000177380)({
     GaugeVec: (*prometheus.GaugeVec)(0x40019106b0)({
      MetricVec: (*prometheus.MetricVec)(0x4000e46780)({
       metricMap: (*prometheus.metricMap)(0x4000e467b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40008494a0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4000177400)({
     GaugeVec: (*prometheus.GaugeVec)(0x40019106b8)({
      MetricVec: (*prometheus.MetricVec)(0x4000e46810)({
       metricMap: (*prometheus.metricMap)(0x4000e46870)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000849500)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4000177480)({
     GaugeVec: (*prometheus.GaugeVec)(0x40019106c0)({
      MetricVec: (*prometheus.MetricVec)(0x4000e468d0)({
       metricMap: (*prometheus.metricMap)(0x4000e46900)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000849560)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4000177500)({
     GaugeVec: (*prometheus.GaugeVec)(0x40019106c8)({
      MetricVec: (*prometheus.MetricVec)(0x4000e46960)({
       metricMap: (*prometheus.metricMap)(0x4000e46990)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40008495c0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4000177580)({
     ObserverVec: (*prometheus.HistogramVec)(0x40019106d0)({
      MetricVec: (*prometheus.MetricVec)(0x4000e469f0)({
       metricMap: (*prometheus.metricMap)(0x4000e46a20)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000849620)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4000284e00)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40002a4380)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4000f415a8)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 689ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.13.0.0/24, 
Allocated addresses:
  10.13.0.139 (health)
  10.13.0.156 (kube-system/coredns-cc6ccd49c-lbvdz)
  10.13.0.204 (kube-system/clustermesh-apiserver-6d5c89b589-97jrw)
  10.13.0.254 (kube-system/coredns-cc6ccd49c-lvxsf)
  10.13.0.68 (router)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb2b6ab34e92fcd0
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    54s ago        never        0       no error   
  ct-map-pressure                                                     26s ago        never        0       no error   
  daemon-validate-config                                              41s ago        never        0       no error   
  dns-garbage-collector-job                                           58s ago        never        0       no error   
  endpoint-1556-regeneration-recovery                                 never          never        0       no error   
  endpoint-303-regeneration-recovery                                  never          never        0       no error   
  endpoint-514-regeneration-recovery                                  never          never        0       no error   
  endpoint-67-regeneration-recovery                                   never          never        0       no error   
  endpoint-92-regeneration-recovery                                   never          never        0       no error   
  endpoint-gc                                                         58s ago        never        0       no error   
  ep-bpf-prog-watchdog                                                26s ago        never        0       no error   
  ipcache-inject-labels                                               56s ago        never        0       no error   
  k8s-heartbeat                                                       29s ago        never        0       no error   
  link-cache                                                          11s ago        never        0       no error   
  local-identity-checkpoint                                           15m44s ago     never        0       no error   
  node-neighbor-link-updater                                          6s ago         never        0       no error   
  remote-etcd-cmesh1                                                  6m38s ago      never        0       no error   
  remote-etcd-cmesh10                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh100                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh101                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh102                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh103                                                6m39s ago      never        0       no error   
  remote-etcd-cmesh104                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh105                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh106                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh107                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh108                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh109                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh11                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh110                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh111                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh112                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh113                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh114                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh115                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh116                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh117                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh118                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh119                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh12                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh120                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh121                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh122                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh123                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh124                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh125                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh126                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh127                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh128                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh13                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh15                                                 6m39s ago      never        0       no error   
  remote-etcd-cmesh16                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh17                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh18                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh19                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh2                                                  6m38s ago      never        0       no error   
  remote-etcd-cmesh20                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh21                                                 6m39s ago      never        0       no error   
  remote-etcd-cmesh22                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh23                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh24                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh25                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh26                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh27                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh28                                                 6m39s ago      never        0       no error   
  remote-etcd-cmesh29                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh3                                                  6m38s ago      never        0       no error   
  remote-etcd-cmesh30                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh31                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh32                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh33                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh34                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh35                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh36                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh37                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh38                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh39                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh4                                                  6m38s ago      never        0       no error   
  remote-etcd-cmesh40                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh41                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh42                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh43                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh44                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh45                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh46                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh47                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh48                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh49                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh5                                                  6m38s ago      never        0       no error   
  remote-etcd-cmesh50                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh51                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh52                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh53                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh54                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh55                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh56                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh57                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh58                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh59                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh6                                                  6m38s ago      never        0       no error   
  remote-etcd-cmesh60                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh61                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh62                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh63                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh64                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh65                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh66                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh67                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh68                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh69                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh7                                                  6m38s ago      never        0       no error   
  remote-etcd-cmesh70                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh71                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh72                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh73                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh74                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh75                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh76                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh77                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh78                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh79                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh8                                                  6m38s ago      never        0       no error   
  remote-etcd-cmesh80                                                 6m39s ago      never        0       no error   
  remote-etcd-cmesh81                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh82                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh83                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh84                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh85                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh86                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh87                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh88                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh89                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh9                                                  6m38s ago      never        0       no error   
  remote-etcd-cmesh90                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh91                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh92                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh93                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh94                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh95                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh96                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh97                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh98                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh99                                                 6m38s ago      never        0       no error   
  resolve-identity-1556                                               55s ago        never        0       no error   
  resolve-identity-303                                                2m44s ago      never        0       no error   
  resolve-identity-514                                                55s ago        never        0       no error   
  resolve-identity-67                                                 56s ago        never        0       no error   
  resolve-identity-92                                                 55s ago        never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-6d5c89b589-97jrw   7m44s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-lbvdz                  15m55s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-lvxsf                  15m55s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      15m56s ago     never        0       no error   
  sync-policymap-1556                                                 53s ago        never        0       no error   
  sync-policymap-303                                                  7m44s ago      never        0       no error   
  sync-policymap-514                                                  50s ago        never        0       no error   
  sync-policymap-67                                                   55s ago        never        0       no error   
  sync-policymap-92                                                   50s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1556)                                   5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (303)                                    4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (92)                                     5s ago         never        0       no error   
  sync-utime                                                          56s ago        never        0       no error   
  write-cni-file                                                      15m59s ago     never        0       no error   
Proxy Status:            OK, ip 10.13.0.68, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 917504, max 983039
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 67.90   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
hubble-metrics:
enable-bbr:false
metrics:
enable-envoy-config:false
debug-verbose:
proxy-xff-num-trusted-hops-egress:0
socket-path:/var/run/cilium/cilium.sock
tofqdns-min-ttl:0
bpf-lb-dsr-dispatch:opt
label-prefix-file:
enable-ipv6:false
hubble-redact-http-headers-allow:
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
monitor-aggregation-flags:all
proxy-max-requests-per-connection:0
enable-ipv6-ndp:false
egress-gateway-policy-map-max:16384
proxy-admin-port:0
policy-queue-size:100
multicast-enabled:false
bpf-auth-map-max:524288
hubble-export-file-max-size-mb:10
enable-bpf-masquerade:false
kvstore-opt:
service-no-backend-response:reject
enable-metrics:true
bpf-lb-source-range-map-max:0
http-retry-timeout:0
wireguard-persistent-keepalive:0s
agent-liveness-update-interval:1s
enable-session-affinity:false
k8s-service-proxy-name:
max-controller-interval:0
proxy-max-connection-duration-seconds:0
log-opt:
enable-route-mtu-for-cni-chaining:false
preallocate-bpf-maps:false
unmanaged-pod-watcher-interval:15
bpf-lb-maglev-map-max:0
use-cilium-internal-ip-for-ipsec:false
hubble-export-file-path:
crd-wait-timeout:5m0s
kvstore-connectivity-timeout:2m0s
ipv4-service-loopback-address:169.254.42.1
cni-log-file:/var/run/cilium/cilium-cni.log
k8s-kubeconfig-path:
bpf-lb-maglev-table-size:16381
hubble-drop-events-reasons:auth_required,policy_denied
policy-accounting:true
tofqdns-endpoint-max-ip-per-hostname:50
identity-restore-grace-period:30s
proxy-connect-timeout:2
hubble-flowlogs-config-path:
bpf-neigh-global-max:524288
mesh-auth-signal-backoff-duration:1s
nat-map-stats-entries:32
restore:true
enable-ipv6-big-tcp:false
hubble-redact-http-userinfo:true
max-connected-clusters:255
hubble-recorder-sink-queue-size:1024
dnsproxy-lock-count:131
hubble-export-file-max-backups:5
enable-ipv4:true
nodeport-addresses:
ipv6-service-range:auto
version:false
dns-max-ips-per-restored-rule:1000
proxy-prometheus-port:0
enable-active-connection-tracking:false
conntrack-gc-max-interval:0s
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
nodes-gc-interval:5m0s
enable-identity-mark:true
kvstore:
enable-svc-source-range-check:true
enable-ipv4-egress-gateway:false
proxy-portrange-min:10000
certificates-directory:/var/run/cilium/certs
bpf-sock-rev-map-max:262144
clustermesh-enable-endpoint-sync:false
enable-k8s-networkpolicy:true
custom-cni-conf:false
enable-well-known-identities:false
disable-endpoint-crd:false
trace-payloadlen:128
enable-ipv4-fragment-tracking:true
dnsproxy-concurrency-limit:0
mesh-auth-gc-interval:5m0s
endpoint-queue-size:25
exclude-local-address:
trace-sock:true
ipv4-node:auto
bpf-root:/sys/fs/bpf
join-cluster:false
identity-gc-interval:15m0s
enable-k8s-terminating-endpoint:true
pprof-port:6060
mesh-auth-spiffe-trust-domain:spiffe.cilium
datapath-mode:veth
bpf-ct-global-any-max:262144
tofqdns-proxy-response-max-delay:100ms
dnsproxy-enable-transparent-mode:true
hubble-monitor-events:
clustermesh-ip-identities-sync-timeout:1m0s
local-router-ipv6:
use-full-tls-context:false
envoy-log:
enable-ipsec-xfrm-state-caching:true
proxy-idle-timeout-seconds:60
bpf-map-event-buffers:
bpf-nat-global-max:524288
bpf-lb-sock-terminate-pod-connections:false
monitor-queue-size:0
mtu:0
install-iptables-rules:true
bpf-ct-timeout-regular-tcp-fin:10s
local-router-ipv4:
enable-wireguard:false
iptables-lock-timeout:5s
procfs:/host/proc
enable-host-legacy-routing:false
routing-mode:tunnel
identity-change-grace-period:5s
pprof-address:localhost
k8s-heartbeat-timeout:30s
enable-recorder:false
bpf-lb-affinity-map-max:0
enable-policy:default
egress-gateway-reconciliation-trigger-interval:1s
kvstore-periodic-sync:5m0s
enable-stale-cilium-endpoint-cleanup:true
ipv4-service-range:auto
hubble-export-denylist:
hubble-export-file-compress:false
policy-cidr-match-mode:
api-rate-limit:
prepend-iptables-chains:true
bpf-policy-map-max:16384
enable-ipsec-key-watcher:true
operator-prometheus-serve-addr::9963
hubble-redact-http-headers-deny:
l2-announcements-renew-deadline:5s
bpf-events-policy-verdict-enabled:true
hubble-prefer-ipv6:false
enable-ipv4-big-tcp:false
hubble-export-fieldmask:
cluster-pool-ipv4-cidr:10.13.0.0/16
bpf-ct-timeout-service-tcp:2h13m20s
enable-mke:false
static-cnp-path:
enable-health-check-nodeport:true
auto-direct-node-routes:false
srv6-encap-mode:reduced
cflags:
cluster-health-port:4240
k8s-client-connection-keep-alive:30s
ip-masq-agent-config-path:/etc/config/ip-masq-agent
hubble-listen-address::4244
bgp-config-path:/var/lib/cilium/bgp/config.yaml
enable-ipsec:false
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
agent-health-port:9879
bypass-ip-availability-upon-restore:false
tofqdns-max-deferred-connection-deletes:10000
enable-tcx:true
bpf-ct-timeout-regular-tcp-syn:1m0s
enable-l2-announcements:false
enable-health-check-loadbalancer-ip:false
ipam-cilium-node-update-rate:15s
cmdref:
allocator-list-timeout:3m0s
k8s-service-cache-size:128
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
bpf-filter-priority:1
install-no-conntrack-iptables-rules:false
envoy-base-id:0
bpf-ct-timeout-service-any:1m0s
dns-policy-unload-on-shutdown:false
enable-custom-calls:false
kube-proxy-replacement:false
bpf-lb-service-map-max:0
route-metric:0
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
tofqdns-proxy-port:0
http-normalize-path:true
egress-masquerade-interfaces:ens+
enable-high-scale-ipcache:false
mesh-auth-queue-size:1024
k8s-require-ipv6-pod-cidr:false
bpf-lb-rev-nat-map-max:0
mesh-auth-rotated-identities-queue-size:1024
bpf-lb-dsr-l4-xlate:frontend
enable-xt-socket-fallback:true
tofqdns-enable-dns-compression:true
http-max-grpc-timeout:0
ipv6-range:auto
debug:false
envoy-config-retry-interval:15s
enable-ip-masq-agent:false
enable-gateway-api:false
endpoint-gc-interval:5m0s
vtep-mac:
bpf-lb-sock:false
config-dir:/tmp/cilium/config-map
enable-auto-protect-node-port-range:true
enable-host-firewall:false
auto-create-cilium-node-resource:true
bpf-lb-sock-hostns-only:false
encryption-strict-mode-cidr:
tunnel-protocol:vxlan
enable-cilium-api-server-access:
enable-external-ips:false
ipsec-key-file:
bpf-fragments-map-max:8192
endpoint-bpf-prog-watchdog-interval:30s
k8s-client-burst:20
hubble-event-queue-size:0
prometheus-serve-addr:
enable-xdp-prefilter:false
l2-announcements-lease-duration:15s
disable-envoy-version-check:false
local-max-addr-scope:252
enable-local-redirect-policy:false
enable-srv6:false
ipam:cluster-pool
enable-pmtu-discovery:false
fqdn-regex-compile-lru-size:1024
agent-labels:
enable-host-port:false
ipam-multi-pool-pre-allocation:
allow-icmp-frag-needed:true
hubble-drop-events-interval:2m0s
http-retry-count:3
enable-service-topology:false
enable-k8s:true
mesh-auth-spire-admin-socket:
l2-announcements-retry-period:2s
hubble-event-buffer-capacity:4095
bpf-lb-external-clusterip:false
kvstore-max-consecutive-quorum-errors:2
hubble-socket-path:/var/run/cilium/hubble.sock
log-driver:
devices:
ipv4-pod-subnets:
enable-vtep:false
bpf-lb-rss-ipv4-src-cidr:
ipv4-range:auto
bpf-ct-timeout-regular-tcp:2h13m20s
k8s-sync-timeout:3m0s
bpf-events-trace-enabled:true
enable-endpoint-health-checking:true
bgp-announce-pod-cidr:false
external-envoy-proxy:true
dnsproxy-insecure-skip-transparent-mode-check:false
k8s-client-connection-timeout:30s
hubble-drop-events:false
ipv6-node:auto
vtep-cidr:
bpf-ct-global-tcp-max:524288
enable-nat46x64-gateway:false
monitor-aggregation-interval:5s
enable-unreachable-routes:false
mesh-auth-mutual-listener-port:0
enable-hubble-recorder-api:true
hubble-skip-unknown-cgroup-ids:true
cni-external-routing:false
gops-port:9890
max-internal-timer-delay:0s
disable-iptables-feeder-rules:
pprof:false
hubble-disable-tls:false
enable-local-node-route:true
policy-audit-mode:false
direct-routing-skip-unreachable:false
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
node-labels:
proxy-gid:1337
mesh-auth-mutual-connect-timeout:5s
fixed-identity-mapping:
ipv6-native-routing-cidr:
enable-sctp:false
encrypt-node:false
disable-external-ip-mitigation:false
derive-masq-ip-addr-from-device:
enable-cilium-endpoint-slice:false
enable-masquerade-to-route-source:false
enable-encryption-strict-mode:false
hubble-redact-kafka-apikey:false
synchronize-k8s-nodes:true
cni-chaining-target:
ipv4-native-routing-cidr:
policy-trigger-interval:1s
node-port-range:
hubble-metrics-server:
enable-runtime-device-detection:true
enable-k8s-api-discovery:false
bpf-map-dynamic-size-ratio:0.0025
cilium-endpoint-gc-interval:5m0s
envoy-keep-cap-netbindservice:false
mesh-auth-enabled:true
bpf-ct-timeout-service-tcp-grace:1m0s
enable-ipsec-encrypted-overlay:false
node-port-bind-protection:true
tofqdns-idle-connection-grace-period:0s
ipv6-mcast-device:
labels:
enable-k8s-endpoint-slice:true
allow-localhost:auto
k8s-client-qps:10
enable-bgp-control-plane:false
ipv6-cluster-alloc-cidr:f00d::/64
clustermesh-config:/var/lib/cilium/clustermesh/
state-dir:/var/run/cilium
cluster-name:cmesh14
config-sources:config-map:kube-system/cilium-config
cluster-pool-ipv4-mask-size:24
cgroup-root:/run/cilium/cgroupv2
enable-bandwidth-manager:false
node-port-acceleration:disabled
exclude-node-label-patterns:
enable-hubble:true
bpf-lb-mode:snat
enable-tracing:false
config:
read-cni-conf:
bpf-ct-timeout-regular-any:1m0s
bgp-announce-lb-ip:false
monitor-aggregation:medium
enable-endpoint-routes:false
set-cilium-node-taints:true
force-device-detection:false
container-ip-local-reserved-ports:auto
annotate-k8s-node:false
keep-config:false
operator-api-serve-addr:127.0.0.1:9234
tofqdns-pre-cache:
k8s-require-ipv4-pod-cidr:false
enable-bpf-tproxy:false
enable-l7-proxy:true
enable-l2-neigh-discovery:true
nat-map-stats-interval:30s
vtep-endpoint:
http-idle-timeout:0
iptables-random-fully:false
kube-proxy-replacement-healthz-bind-address:
l2-pod-announcements-interface:
enable-l2-pod-announcements:false
enable-ipv6-masquerade:true
enable-ipip-termination:false
hubble-redact-http-urlquery:false
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
remove-cilium-node-taints:true
bpf-node-map-max:16384
hubble-export-allowlist:
ipv6-pod-subnets:
identity-allocation-mode:crd
envoy-config-timeout:2m0s
envoy-secrets-namespace:
log-system-load:false
dnsproxy-socket-linger-timeout:10
enable-node-selector-labels:false
enable-node-port:false
bpf-lb-rss-ipv6-src-cidr:
k8s-namespace:kube-system
bpf-policy-map-full-reconciliation-interval:15m0s
egress-multi-home-ip-rule-compat:false
cni-chaining-mode:none
tofqdns-dns-reject-response-code:refused
identity-heartbeat-timeout:30m0s
node-port-algorithm:random
encryption-strict-mode-allow-remote-node-identities:false
k8s-api-server:
lib-dir:/var/lib/cilium
encrypt-interface:
bpf-lb-acceleration:disabled
mke-cgroup-mount:
ipam-default-ip-pool:default
proxy-portrange-max:20000
enable-wireguard-userspace-fallback:false
http-request-timeout:3600
enable-icmp-rules:true
enable-cilium-health-api-server-access:
bpf-lb-map-max:65536
clustermesh-sync-timeout:1m0s
clustermesh-enable-mcs-api:false
bpf-events-drop-enabled:true
enable-ingress-controller:false
set-cilium-is-up-condition:true
conntrack-gc-interval:0s
enable-ipv4-masquerade:true
enable-health-checking:true
tunnel-port:0
kvstore-lease-ttl:15m0s
ingress-secrets-namespace:
enable-bpf-clock-probe:false
node-port-mode:snat
dnsproxy-concurrency-processing-grace-period:0s
vlan-bpf-bypass:
hubble-recorder-storage-path:/var/run/cilium/pcaps
dnsproxy-lock-timeout:500ms
bpf-lb-algorithm:random
gateway-api-secrets-namespace:
ipsec-key-rotation-duration:5m0s
proxy-xff-num-trusted-hops-ingress:0
direct-routing-device:
vtep-mask:
arping-refresh-period:30s
cni-exclusive:true
enable-monitor:true
controller-group-metrics:
bpf-lb-service-backend-map-max:0
cluster-id:14
hubble-redact-enabled:false
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
67         Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                
                                                           reserved:host                                                                                             
92         Disabled           Disabled          973353     k8s:eks.amazonaws.com/component=coredns                                             10.13.0.254   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh14                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
303        Disabled           Disabled          956136     k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.13.0.204   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh14                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
514        Disabled           Disabled          4          reserved:health                                                                     10.13.0.139   ready   
1556       Disabled           Disabled          973353     k8s:eks.amazonaws.com/component=coredns                                             10.13.0.156   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh14                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
```

#### BPF Policy Get 67

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 67

```
Invalid argument: unknown type 67
```


#### Endpoint Get 67

```
[
  {
    "id": 67,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-67-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "62da187d-1565-4d89-8888-3453fccdc6d8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-67",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:16.699Z",
            "success-count": 4
          },
          "uuid": "328aca6a-d586-432a-b8d4-ec03bc89f760"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-67",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:17.919Z",
            "success-count": 2
          },
          "uuid": "811a4a1e-0ba8-45ca-8161-e192050a2d08"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:36Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "ba:12:ac:d0:5e:63",
        "interface-name": "cilium_host",
        "mac": "ba:12:ac:d0:5e:63"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 67

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 67

```
Timestamp              Status   State                   Message
2024-10-25T10:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:36Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:13:18Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:13:17Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:16Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:16Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:16Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 92

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    88988   1019      0        
Allow    Egress      0          ANY          NONE         disabled    15410   163       0        

```


#### BPF CT List 92

```
Invalid argument: unknown type 92
```


#### Endpoint Get 92

```
[
  {
    "id": 92,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-92-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "199ca7a3-9d91-4838-8113-5eca5344c4fb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-92",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:17.463Z",
            "success-count": 4
          },
          "uuid": "91b91e02-e3b7-4ad5-997b-14236d6609ec"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-lvxsf",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:13:17.460Z",
            "success-count": 1
          },
          "uuid": "1c71bdc6-8ff7-48ad-a7fe-0635c766a475"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-92",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:23.020Z",
            "success-count": 2
          },
          "uuid": "d46be452-878b-4c1b-9db6-1d0622e73e6f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (92)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:07.554Z",
            "success-count": 97
          },
          "uuid": "7cd0a010-453e-43b3-8a62-b6f16759887d"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "716b53acea2a14fb63829f8a7fbdd3aeb7ab14bb5a79db1c518abb0f84c82ab7:eth0",
        "container-id": "716b53acea2a14fb63829f8a7fbdd3aeb7ab14bb5a79db1c518abb0f84c82ab7",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-lvxsf",
        "pod-name": "kube-system/coredns-cc6ccd49c-lvxsf"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 973353,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh14",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh14",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:36Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.13.0.254",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ce:4b:d7:4d:74:59",
        "interface-index": 11,
        "interface-name": "lxc0a528b9c8c0c",
        "mac": "22:7d:7a:81:68:80"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 973353,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 973353,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 92

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 92

```
Timestamp              Status   State                   Message
2024-10-25T10:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:36Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:23Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:13:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:17Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:17Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:17Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 973353

```
ID       LABELS
973353   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh14
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 303

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3823563   36400     0        
Allow    Ingress     1          ANY          NONE         disabled    3146255   31881     0        
Allow    Egress      0          ANY          NONE         disabled    5143385   47323     0        

```


#### BPF CT List 303

```
Invalid argument: unknown type 303
```


#### Endpoint Get 303

```
[
  {
    "id": 303,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-303-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "a49187ba-0c33-4ea2-95e7-232dc01a7cd8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-303",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:28.226Z",
            "success-count": 2
          },
          "uuid": "22afbd1f-4582-4e35-8b62-7b8beabea1a2"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-6d5c89b589-97jrw",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:28.224Z",
            "success-count": 1
          },
          "uuid": "415564bd-0abc-44c4-95b7-3b81b92e8d38"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-303",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:28.265Z",
            "success-count": 1
          },
          "uuid": "9ae105b1-5552-40c6-9a09-1f96a96113f8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (303)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:08.277Z",
            "success-count": 48
          },
          "uuid": "1669167a-36ca-4e84-b399-12ff0c4207a2"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "3e2a0623de9b642144489a1d6eb4120f6499b49767b155ed0535927810287919:eth0",
        "container-id": "3e2a0623de9b642144489a1d6eb4120f6499b49767b155ed0535927810287919",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-6d5c89b589-97jrw",
        "pod-name": "kube-system/clustermesh-apiserver-6d5c89b589-97jrw"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 956136,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh14",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6d5c89b589"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh14",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:36Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.13.0.204",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "8a:da:2f:96:9d:7f",
        "interface-index": 15,
        "interface-name": "lxc548dbce01d14",
        "mac": "f6:fe:4d:63:e1:83"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 956136,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 956136,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 303

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 303

```
Timestamp              Status   State                   Message
2024-10-25T10:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:36Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:28Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:28Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:28Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 956136

```
ID       LABELS
956136   k8s:app.kubernetes.io/name=clustermesh-apiserver
         k8s:app.kubernetes.io/part-of=cilium
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh14
         k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 514

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    434390   5544      0        
Allow    Ingress     1          ANY          NONE         disabled    12764    148       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 514

```
Invalid argument: unknown type 514
```


#### Endpoint Get 514

```
[
  {
    "id": 514,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-514-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c1e29b9d-d204-435e-92fc-eb0661bcc79c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-514",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:17.775Z",
            "success-count": 4
          },
          "uuid": "cd5cac32-8556-41fe-b438-3fb41f31ec10"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-514",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:23.012Z",
            "success-count": 2
          },
          "uuid": "1ca4acb8-0138-4c8a-a175-24f35f7ec4f4"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:36Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.13.0.139",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "ba:e6:c1:26:0e:d8",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "6e:a9:59:4c:32:fa"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 514

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 514

```
Timestamp              Status   State                   Message
2024-10-25T10:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:36Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:13:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:23Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:13:23Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:13:19Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:18Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:13:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:17Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:16Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 1556

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    89384   1025      0        
Allow    Egress      0          ANY          NONE         disabled    15011   158       0        

```


#### BPF CT List 1556

```
Invalid argument: unknown type 1556
```


#### Endpoint Get 1556

```
[
  {
    "id": 1556,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1556-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7fb81bbd-7eef-40d3-920a-b599a5284f63"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1556",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:17.371Z",
            "success-count": 4
          },
          "uuid": "e9181676-5bdd-418a-987b-9522d9649513"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-lbvdz",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:13:17.367Z",
            "success-count": 1
          },
          "uuid": "1f430cac-467a-41c7-9f33-7fc5e3c00848"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1556",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:19.705Z",
            "success-count": 2
          },
          "uuid": "2cbf7503-249a-4ac3-95fc-3fb7eb4c948e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1556)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:07.447Z",
            "success-count": 97
          },
          "uuid": "b5b1b6c1-52c5-418f-bf51-c845a20f7a43"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "b4b6f21d522826d7c0007adc6ad03691b8bf4621e40a25db7ee7d21bfd5d4d2a:eth0",
        "container-id": "b4b6f21d522826d7c0007adc6ad03691b8bf4621e40a25db7ee7d21bfd5d4d2a",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-lbvdz",
        "pod-name": "kube-system/coredns-cc6ccd49c-lbvdz"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 973353,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh14",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh14",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:36Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.13.0.156",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "f2:85:5a:f0:ae:6a",
        "interface-index": 9,
        "interface-name": "lxc228bf49ebec3",
        "mac": "f6:a1:5c:c2:9b:68"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 973353,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 973353,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1556

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1556

```
Timestamp              Status    State                   Message
2024-10-25T10:22:36Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:36Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:36Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:22:36Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:35Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:35Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:35Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:35Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:34Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:34Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:34Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:34Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:43Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:42Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:42Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:42Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:42Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:23Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:23Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:23Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:20Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:13:19Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:18Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:17Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:17Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:17Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:13:17Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:17Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 973353

```
ID       LABELS
973353   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh14
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.134.69:443 (active)     
                                          2 => 172.31.210.92:443 (active)     
2    10.100.131.26:443     ClusterIP      1 => 172.31.226.178:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.13.0.156:53 (active)        
                                          2 => 10.13.0.254:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.13.0.156:9153 (active)      
                                          2 => 10.13.0.254:9153 (active)      
5    10.100.252.182:2379   ClusterIP      1 => 10.13.0.204:2379 (active)      
```

#### Policy get

```
:
 []
Revision: 1

```


#### Cilium encryption


