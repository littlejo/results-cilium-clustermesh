filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc228bf49ebec3 direct-action not_in_hw id 493 tag c6d56808a8351826 jited 
