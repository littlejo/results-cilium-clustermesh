IP ADDRESS         LOCAL ENDPOINT INFO
10.13.0.68:0       (localhost)                                                                                       
10.13.0.254:0      id=92    sec_id=973353 flags=0x0000 ifindex=11  mac=22:7D:7A:81:68:80 nodemac=CE:4B:D7:4D:74:59   
10.13.0.139:0      id=514   sec_id=4     flags=0x0000 ifindex=7   mac=6E:A9:59:4C:32:FA nodemac=BA:E6:C1:26:0E:D8    
10.13.0.204:0      id=303   sec_id=956136 flags=0x0000 ifindex=15  mac=F6:FE:4D:63:E1:83 nodemac=8A:DA:2F:96:9D:7F   
10.13.0.156:0      id=1556  sec_id=973353 flags=0x0000 ifindex=9   mac=F6:A1:5C:C2:9B:68 nodemac=F2:85:5A:F0:AE:6A   
172.31.226.178:0   (localhost)                                                                                       
