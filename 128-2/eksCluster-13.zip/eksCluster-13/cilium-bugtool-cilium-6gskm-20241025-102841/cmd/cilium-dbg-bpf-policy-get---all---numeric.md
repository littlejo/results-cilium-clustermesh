Endpoint ID: 67
Path: /sys/fs/bpf/tc/globals/cilium_policy_00067

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 92
Path: /sys/fs/bpf/tc/globals/cilium_policy_00092

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    88988   1019      0        
Allow    Egress      0          ANY          NONE         disabled    15410   163       0        


Endpoint ID: 303
Path: /sys/fs/bpf/tc/globals/cilium_policy_00303

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3826821   36436     0        
Allow    Ingress     1          ANY          NONE         disabled    3191419   32379     0        
Allow    Egress      0          ANY          NONE         disabled    5147321   47367     0        


Endpoint ID: 514
Path: /sys/fs/bpf/tc/globals/cilium_policy_00514

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    435070   5553      0        
Allow    Ingress     1          ANY          NONE         disabled    12764    148       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1556
Path: /sys/fs/bpf/tc/globals/cilium_policy_01556

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    89384   1025      0        
Allow    Egress      0          ANY          NONE         disabled    15011   158       0        


