ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.134.69:443 (active)     
                                          2 => 172.31.210.92:443 (active)     
2    10.100.131.26:443     ClusterIP      1 => 172.31.226.178:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.13.0.156:53 (active)        
                                          2 => 10.13.0.254:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.13.0.156:9153 (active)      
                                          2 => 10.13.0.254:9153 (active)      
5    10.100.252.182:2379   ClusterIP      1 => 10.13.0.204:2379 (active)      
