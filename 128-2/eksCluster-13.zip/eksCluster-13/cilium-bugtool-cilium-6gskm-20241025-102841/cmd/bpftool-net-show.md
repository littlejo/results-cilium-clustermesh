xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 552
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 544
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 538
cilium_host(4) clsact/egress cil_from_host-cilium_host id 533
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 464
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 465
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 515
lxc228bf49ebec3(9) clsact/ingress cil_from_container-lxc228bf49ebec3 id 493
lxc0a528b9c8c0c(11) clsact/ingress cil_from_container-lxc0a528b9c8c0c id 526
lxc548dbce01d14(15) clsact/ingress cil_from_container-lxc548dbce01d14 id 595

flow_dissector:

netfilter:

