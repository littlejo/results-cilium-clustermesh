{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:16.523Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.226.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:16.523Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:19.704Z",
  "value": "id=1556  sec_id=973353 flags=0x0000 ifindex=9   mac=F6:A1:5C:C2:9B:68 nodemac=F2:85:5A:F0:AE:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:23.011Z",
  "value": "id=514   sec_id=4     flags=0x0000 ifindex=7   mac=6E:A9:59:4C:32:FA nodemac=BA:E6:C1:26:0E:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:23.013Z",
  "value": "id=92    sec_id=973353 flags=0x0000 ifindex=11  mac=22:7D:7A:81:68:80 nodemac=CE:4B:D7:4D:74:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:23.098Z",
  "value": "id=1556  sec_id=973353 flags=0x0000 ifindex=9   mac=F6:A1:5C:C2:9B:68 nodemac=F2:85:5A:F0:AE:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:23.143Z",
  "value": "id=514   sec_id=4     flags=0x0000 ifindex=7   mac=6E:A9:59:4C:32:FA nodemac=BA:E6:C1:26:0E:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:23.191Z",
  "value": "id=92    sec_id=973353 flags=0x0000 ifindex=11  mac=22:7D:7A:81:68:80 nodemac=CE:4B:D7:4D:74:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:42.678Z",
  "value": "id=92    sec_id=973353 flags=0x0000 ifindex=11  mac=22:7D:7A:81:68:80 nodemac=CE:4B:D7:4D:74:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:42.678Z",
  "value": "id=1556  sec_id=973353 flags=0x0000 ifindex=9   mac=F6:A1:5C:C2:9B:68 nodemac=F2:85:5A:F0:AE:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:42.679Z",
  "value": "id=514   sec_id=4     flags=0x0000 ifindex=7   mac=6E:A9:59:4C:32:FA nodemac=BA:E6:C1:26:0E:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:42.713Z",
  "value": "id=1548  sec_id=956136 flags=0x0000 ifindex=13  mac=02:E3:80:EE:30:45 nodemac=BE:04:17:02:70:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:43.679Z",
  "value": "id=514   sec_id=4     flags=0x0000 ifindex=7   mac=6E:A9:59:4C:32:FA nodemac=BA:E6:C1:26:0E:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:43.679Z",
  "value": "id=1548  sec_id=956136 flags=0x0000 ifindex=13  mac=02:E3:80:EE:30:45 nodemac=BE:04:17:02:70:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:43.680Z",
  "value": "id=1556  sec_id=973353 flags=0x0000 ifindex=9   mac=F6:A1:5C:C2:9B:68 nodemac=F2:85:5A:F0:AE:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:43.680Z",
  "value": "id=92    sec_id=973353 flags=0x0000 ifindex=11  mac=22:7D:7A:81:68:80 nodemac=CE:4B:D7:4D:74:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:28.265Z",
  "value": "id=303   sec_id=956136 flags=0x0000 ifindex=15  mac=F6:FE:4D:63:E1:83 nodemac=8A:DA:2F:96:9D:7F"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.13.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:38.804Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:34.132Z",
  "value": "id=303   sec_id=956136 flags=0x0000 ifindex=15  mac=F6:FE:4D:63:E1:83 nodemac=8A:DA:2F:96:9D:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:34.133Z",
  "value": "id=1556  sec_id=973353 flags=0x0000 ifindex=9   mac=F6:A1:5C:C2:9B:68 nodemac=F2:85:5A:F0:AE:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:34.134Z",
  "value": "id=92    sec_id=973353 flags=0x0000 ifindex=11  mac=22:7D:7A:81:68:80 nodemac=CE:4B:D7:4D:74:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:34.135Z",
  "value": "id=514   sec_id=4     flags=0x0000 ifindex=7   mac=6E:A9:59:4C:32:FA nodemac=BA:E6:C1:26:0E:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:35.105Z",
  "value": "id=514   sec_id=4     flags=0x0000 ifindex=7   mac=6E:A9:59:4C:32:FA nodemac=BA:E6:C1:26:0E:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:35.105Z",
  "value": "id=1556  sec_id=973353 flags=0x0000 ifindex=9   mac=F6:A1:5C:C2:9B:68 nodemac=F2:85:5A:F0:AE:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:35.105Z",
  "value": "id=303   sec_id=956136 flags=0x0000 ifindex=15  mac=F6:FE:4D:63:E1:83 nodemac=8A:DA:2F:96:9D:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:35.105Z",
  "value": "id=92    sec_id=973353 flags=0x0000 ifindex=11  mac=22:7D:7A:81:68:80 nodemac=CE:4B:D7:4D:74:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:36.105Z",
  "value": "id=1556  sec_id=973353 flags=0x0000 ifindex=9   mac=F6:A1:5C:C2:9B:68 nodemac=F2:85:5A:F0:AE:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:36.105Z",
  "value": "id=303   sec_id=956136 flags=0x0000 ifindex=15  mac=F6:FE:4D:63:E1:83 nodemac=8A:DA:2F:96:9D:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:36.105Z",
  "value": "id=92    sec_id=973353 flags=0x0000 ifindex=11  mac=22:7D:7A:81:68:80 nodemac=CE:4B:D7:4D:74:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.13.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:36.105Z",
  "value": "id=514   sec_id=4     flags=0x0000 ifindex=7   mac=6E:A9:59:4C:32:FA nodemac=BA:E6:C1:26:0E:D8"
}

