KEY             VALUE
AgentLiveness   1012087509248
UTimeOffset     3378615509765625
