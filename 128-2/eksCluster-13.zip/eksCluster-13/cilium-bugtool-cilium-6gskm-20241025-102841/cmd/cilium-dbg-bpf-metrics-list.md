REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     221983    101137366   1132   bpf_host.c
Interface                 INGRESS     9606      748965      677    bpf_overlay.c
Success                   EGRESS      4718      359057      1694   bpf_host.c
Success                   EGRESS      9533      742531      53     encap.h
Success                   EGRESS      95390     12535228    1308   bpf_lxc.c
Success                   INGRESS     105321    13036598    86     l3.h
Success                   INGRESS     110859    13470482    235    trace.h
Unsupported L3 protocol   EGRESS      35        2602        1492   bpf_lxc.c
