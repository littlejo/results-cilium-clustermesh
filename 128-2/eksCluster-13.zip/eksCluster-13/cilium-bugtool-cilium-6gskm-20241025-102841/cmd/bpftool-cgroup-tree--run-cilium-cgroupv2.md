CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod344fdfd3_d869_4780_b61e_818631ae2ed9.slice/cri-containerd-59ab2741533f0f38d5bdf0fee46f925e89abceb5a22af9d4efa07440449e0eb0.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod344fdfd3_d869_4780_b61e_818631ae2ed9.slice/cri-containerd-716b53acea2a14fb63829f8a7fbdd3aeb7ab14bb5a79db1c518abb0f84c82ab7.scope
    513      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod85dee9c9_9a61_41b9_bfb2_b25dc697cb48.slice/cri-containerd-43b8a3e656e350799a66c779a1da0378ee739669bf095d6d2ee51f1b52c6f44e.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod85dee9c9_9a61_41b9_bfb2_b25dc697cb48.slice/cri-containerd-1f7260e0efce6997d2ca86be90dcd9f8befe03fabf0ddab150639fa1e34c8598.scope
    71       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod83dd5b9f_2a4f_4abd_b02f_26a4a1e4c666.slice/cri-containerd-c2c92bd0af25723a97ff058ad08eddad6c3ad94b2966cdef91c98fc13b725135.scope
    469      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod83dd5b9f_2a4f_4abd_b02f_26a4a1e4c666.slice/cri-containerd-b4b6f21d522826d7c0007adc6ad03691b8bf4621e40a25db7ee7d21bfd5d4d2a.scope
    461      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod33afa003_72af_4c8d_909e_d5d2d94e6ece.slice/cri-containerd-b8b5b4f674ca90c002fdb2fcbb15176a75496b4821760002b704875e05329236.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod33afa003_72af_4c8d_909e_d5d2d94e6ece.slice/cri-containerd-0a276663451d041dbc566eda9c34759a943eb8dfd823d6518f2e0b238e0d385e.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb2592bc_05ca_475a_85a7_ba60d87ffd74.slice/cri-containerd-c123ea2452465fd102c517ff73adbae8b6acb94117f96a6fc04f5830468ddef6.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb2592bc_05ca_475a_85a7_ba60d87ffd74.slice/cri-containerd-6d5db0aaf529f7f35256b73e4bc9ce7f837e6299429675d861722ba9709d3492.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4d9088f9_8ba0_49fe_bda0_6799d5278976.slice/cri-containerd-830d9823c361c32cf8ec381bf09366ad3281dfb964605afadae3897535a6c81d.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4d9088f9_8ba0_49fe_bda0_6799d5278976.slice/cri-containerd-2320fae794a60be57f206cd5f9bd557d40ea3f83df0d3139642bfd7c6a6a5534.scope
    64       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda3d7a3e_f5f5_4ca7_8409_b6090216b3ac.slice/cri-containerd-99d198622bc1978a9c3fd864be7493fca6a4b96d9caf1f4a69c3b7f20f5c3277.scope
    631      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda3d7a3e_f5f5_4ca7_8409_b6090216b3ac.slice/cri-containerd-9ccd809d4612131ce6d4a6888b68965c1fbd7cac1ee0cf6d24c56f2597c3c47d.scope
    627      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda3d7a3e_f5f5_4ca7_8409_b6090216b3ac.slice/cri-containerd-3e2a0623de9b642144489a1d6eb4120f6499b49767b155ed0535927810287919.scope
    607      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda3d7a3e_f5f5_4ca7_8409_b6090216b3ac.slice/cri-containerd-3e4173fd081d8a08ee8d0301fa9b5ba6edcbd11fcfc52b80dd7eac39dda75318.scope
    623      cgroup_device   multi                                          
