top - 10:28:42 up 16 min,  0 users,  load average: 0.16, 0.14, 0.15
Tasks:   9 total,   2 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 28.1 us, 40.6 sy,  0.0 ni, 25.0 id,  0.0 wa,  0.0 hi,  6.2 si,  0.0 st
MiB Mem :   3836.2 total,   1176.0 free,    903.9 used,   1756.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2764.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    754 root      20   0 1244340  20844  13760 R  25.0   0.5   0:00.04 hubble
      1 root      20   0 1538100 282600  78208 S   6.2   7.2   0:27.57 cilium-+
    412 root      20   0 1228848   6884   3840 S   0.0   0.2   0:00.28 cilium-+
    678 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    688 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
    698 root      20   0 1240432  16504  11420 S   0.0   0.4   0:00.02 cilium-+
    724 root      20   0    6576   2416   2092 R   0.0   0.1   0:00.00 top
    742 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    748 root      20   0    2208    792    716 S   0.0   0.0   0:00.00 timeout
