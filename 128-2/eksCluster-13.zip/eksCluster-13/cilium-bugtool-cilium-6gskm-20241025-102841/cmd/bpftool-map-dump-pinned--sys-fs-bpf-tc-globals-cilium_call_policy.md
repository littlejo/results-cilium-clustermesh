key: 5c 00 00 00  value: 07 02 00 00
key: 2f 01 00 00  value: 56 02 00 00
key: 02 02 00 00  value: f8 01 00 00
key: 14 06 00 00  value: ef 01 00 00
Found 4 elements
