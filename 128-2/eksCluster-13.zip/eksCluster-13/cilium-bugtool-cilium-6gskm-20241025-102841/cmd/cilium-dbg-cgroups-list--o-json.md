[
  {
    "containers": [
      {
        "cgroup-id": 8202,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda3d7a3e_f5f5_4ca7_8409_b6090216b3ac.slice/cri-containerd-3e4173fd081d8a08ee8d0301fa9b5ba6edcbd11fcfc52b80dd7eac39dda75318.scope"
      },
      {
        "cgroup-id": 8370,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda3d7a3e_f5f5_4ca7_8409_b6090216b3ac.slice/cri-containerd-99d198622bc1978a9c3fd864be7493fca6a4b96d9caf1f4a69c3b7f20f5c3277.scope"
      },
      {
        "cgroup-id": 8286,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda3d7a3e_f5f5_4ca7_8409_b6090216b3ac.slice/cri-containerd-9ccd809d4612131ce6d4a6888b68965c1fbd7cac1ee0cf6d24c56f2597c3c47d.scope"
      }
    ],
    "ips": [
      "10.13.0.204"
    ],
    "name": "clustermesh-apiserver-6d5c89b589-97jrw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6690,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod83dd5b9f_2a4f_4abd_b02f_26a4a1e4c666.slice/cri-containerd-c2c92bd0af25723a97ff058ad08eddad6c3ad94b2966cdef91c98fc13b725135.scope"
      }
    ],
    "ips": [
      "10.13.0.156"
    ],
    "name": "coredns-cc6ccd49c-lbvdz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6858,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod344fdfd3_d869_4780_b61e_818631ae2ed9.slice/cri-containerd-59ab2741533f0f38d5bdf0fee46f925e89abceb5a22af9d4efa07440449e0eb0.scope"
      }
    ],
    "ips": [
      "10.13.0.254"
    ],
    "name": "coredns-cc6ccd49c-lvxsf",
    "namespace": "kube-system"
  }
]

