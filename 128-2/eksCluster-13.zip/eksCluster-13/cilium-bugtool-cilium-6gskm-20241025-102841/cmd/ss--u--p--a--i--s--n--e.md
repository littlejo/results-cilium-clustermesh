Total: 538
TCP:   1054 (estab 292, closed 743, orphaned 0, timewait 289)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  311       302       9        
INET	  321       308       13       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.226.178%ens5:68         0.0.0.0:*    uid:192 ino:15230 sk:250 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:22682 sk:251 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15685 sk:252 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:38375      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:21626 sk:253 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:22681 sk:254 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15686 sk:255 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::826:b1ff:fe84:5851]%ens5:546           [::]:*    uid:192 ino:15228 sk:256 cgroup:unreachable:c4e v6only:1 <->                   
