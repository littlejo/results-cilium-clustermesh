alloc: 121.82MB (127736536 bytes)
total-alloc: 1.36GB (1462539648 bytes)
sys: 214.38MB (224798036 bytes)
lookups: 0
mallocs: 48224742
frees: 47037169
heap-alloc: 121.82MB (127736536 bytes)
heap-sys: 169.52MB (177750016 bytes)
heap-idle: 27.27MB (28598272 bytes)
heap-in-use: 142.24MB (149151744 bytes)
heap-released: 8.90MB (9330688 bytes)
heap-objects: 1187573
stack-in-use: 34.44MB (36110336 bytes)
stack-sys: 34.44MB (36110336 bytes)
stack-mspan-inuse: 2.20MB (2302240 bytes)
stack-mspan-sys: 2.43MB (2545920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 946.91KB (969633 bytes)
gc-sys: 5.16MB (5406904 bytes)
next-gc: when heap-alloc >= 142.17MB (149075112 bytes)
last-gc: 2024-10-25 10:28:41.695980749 +0000 UTC
gc-pause-total: 7.384309ms
gc-pause: 144720
gc-pause-end: 1729852121695980749
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.0003043142291903038
enable-gc: true
debug-gc: false
