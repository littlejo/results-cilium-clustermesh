35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:24+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:24+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:24+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:24+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:24+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:12:24+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:12:25+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:12:25+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:12:25+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:25+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:12:31+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
61: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
64: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
71: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:12:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
72: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
75: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
458: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
461: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
462: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:20+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 124
463: sched_cls  name tail_handle_ipv4  tag 7c4741c6702fed76  gpl
	loaded_at 2024-10-25T10:13:20+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,93
	btf_id 125
464: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:20+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,93
	btf_id 126
465: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:20+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
466: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
469: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
492: sched_cls  name tail_handle_ipv4  tag 4be440ad0e3f1de0  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,102
	btf_id 154
493: sched_cls  name cil_from_container  tag c6d56808a8351826  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 102,68
	btf_id 155
495: sched_cls  name handle_policy  tag 2a87ee6a5b718b68  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,102,74,75,101,33,72,83,31,76,67,32,29,30
	btf_id 157
496: sched_cls  name tail_ipv4_to_endpoint  tag 3d02b66a42eb3ec6  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,101,33,74,75,72,83,31,102,32,29,30
	btf_id 158
497: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,102
	btf_id 159
498: sched_cls  name tail_handle_arp  tag bf418f0dcb018741  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,102
	btf_id 160
499: sched_cls  name tail_ipv4_ct_egress  tag fc9ffac9b3fc5e09  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,102,74,75,101,76
	btf_id 161
500: sched_cls  name tail_handle_ipv4_cont  tag 3e0713d2d4d83f51  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,101,33,83,74,75,31,68,66,69,102,32,29,30,73
	btf_id 162
501: sched_cls  name __send_drop_notify  tag eae8268779129fb7  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 163
502: sched_cls  name tail_ipv4_ct_ingress  tag 815795805d7b77fd  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,102,74,75,101,76
	btf_id 164
503: sched_cls  name tail_handle_ipv4  tag f60e78194bd8ac6d  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,103
	btf_id 166
504: sched_cls  name handle_policy  tag fe2edb85dedfb164  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,103,74,75,104,33,72,95,31,76,67,32,29,30
	btf_id 167
505: sched_cls  name __send_drop_notify  tag 931d44b7a65de0d0  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 168
506: sched_cls  name tail_handle_arp  tag a2eef0aac021af66  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,103
	btf_id 169
507: sched_cls  name tail_handle_ipv4_cont  tag a7481746e51bc3ce  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,104,33,95,74,75,31,68,66,69,103,32,29,30,73
	btf_id 170
508: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,103,74,75,104,76
	btf_id 171
509: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,103
	btf_id 172
510: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
513: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
514: sched_cls  name tail_ipv4_to_endpoint  tag 7f697d1c62929251  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,104,33,74,75,72,95,31,103,32,29,30
	btf_id 173
515: sched_cls  name cil_from_container  tag 1dbf0d74a12a4e49  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 103,68
	btf_id 174
516: sched_cls  name tail_ipv4_ct_ingress  tag 32e26179f79342dd  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,103,74,75,104,76
	btf_id 175
518: sched_cls  name tail_handle_ipv4  tag d1420cc8a50cc10f  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,106
	btf_id 178
519: sched_cls  name handle_policy  tag 287060525c63b9af  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,106,74,75,107,33,72,94,31,76,67,32,29,30
	btf_id 179
520: sched_cls  name tail_ipv4_ct_egress  tag fc9ffac9b3fc5e09  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,106,74,75,107,76
	btf_id 180
521: sched_cls  name __send_drop_notify  tag 7a4bc2479cb6f81e  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 181
522: sched_cls  name tail_handle_ipv4_cont  tag c0f560f92ca4263e  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,107,33,94,74,75,31,68,66,69,106,32,29,30,73
	btf_id 182
523: sched_cls  name tail_handle_arp  tag 16871fa83f091f0d  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,106
	btf_id 183
525: sched_cls  name tail_ipv4_ct_ingress  tag d2dd2574c5d9fbc8  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,106,74,75,107,76
	btf_id 185
526: sched_cls  name cil_from_container  tag 5b2acb2623122ce8  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 106,68
	btf_id 186
527: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,106
	btf_id 187
528: sched_cls  name tail_ipv4_to_endpoint  tag 720ae1aa6a1cfcc4  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,107,33,74,75,72,94,31,106,32,29,30
	btf_id 188
529: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
532: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
533: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,110
	btf_id 191
534: sched_cls  name __send_drop_notify  tag 205f57bba684f67e  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 192
535: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,110
	btf_id 193
538: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 196
539: sched_cls  name tail_handle_ipv4_from_host  tag f559cd3e0508ad3f  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,110
	btf_id 197
540: sched_cls  name __send_drop_notify  tag 205f57bba684f67e  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 199
541: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,111
	btf_id 200
544: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 203
545: sched_cls  name tail_handle_ipv4_from_host  tag f559cd3e0508ad3f  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,111
	btf_id 204
548: sched_cls  name tail_handle_ipv4_from_host  tag f559cd3e0508ad3f  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,114
	btf_id 208
550: sched_cls  name __send_drop_notify  tag 205f57bba684f67e  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 210
551: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,114
	btf_id 211
552: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,114,67
	btf_id 212
593: sched_cls  name tail_ipv4_ct_egress  tag 63fafd24ae5f0255  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,127,74,75,126,76
	btf_id 227
594: sched_cls  name __send_drop_notify  tag b82087d76c5d5434  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 228
595: sched_cls  name cil_from_container  tag 43dc3fe9ea8392ad  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 127,68
	btf_id 229
596: sched_cls  name tail_ipv4_ct_ingress  tag ba6dd4ba5f915bfd  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,127,74,75,126,76
	btf_id 230
597: sched_cls  name tail_handle_ipv4  tag 9fd9e3e97fc66a1f  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,127
	btf_id 231
598: sched_cls  name handle_policy  tag 7b144c8ae4be1303  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,127,74,75,126,33,72,125,31,76,67,32,29,30
	btf_id 232
599: sched_cls  name tail_ipv4_to_endpoint  tag 936b876f7a3e624d  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,126,33,74,75,72,125,31,127,32,29,30
	btf_id 233
600: sched_cls  name tail_handle_ipv4_cont  tag c4c0a4798a39a7d1  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,126,33,125,74,75,31,68,66,69,127,32,29,30,73
	btf_id 234
602: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,127
	btf_id 236
603: sched_cls  name tail_handle_arp  tag c6f9dc73ae8458a4  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,127
	btf_id 237
604: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
607: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
620: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
623: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
624: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
627: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
628: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
631: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
