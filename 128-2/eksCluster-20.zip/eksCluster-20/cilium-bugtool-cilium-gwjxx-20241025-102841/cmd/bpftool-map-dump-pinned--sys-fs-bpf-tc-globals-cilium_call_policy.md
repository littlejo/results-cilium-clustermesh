key: f6 00 00 00  value: 44 02 00 00
key: a5 06 00 00  value: f5 01 00 00
key: 0d 0b 00 00  value: f0 01 00 00
key: e5 0f 00 00  value: fc 01 00 00
Found 4 elements
