ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.246.123:443 (active)    
                                         2 => 172.31.168.107:443 (active)    
2    10.100.103.129:443   ClusterIP      1 => 172.31.169.166:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.20.0.41:53 (active)         
                                         2 => 10.20.0.245:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.20.0.41:9153 (active)       
                                         2 => 10.20.0.245:9153 (active)      
5    10.100.159.51:2379   ClusterIP      1 => 10.20.0.234:2379 (active)      
