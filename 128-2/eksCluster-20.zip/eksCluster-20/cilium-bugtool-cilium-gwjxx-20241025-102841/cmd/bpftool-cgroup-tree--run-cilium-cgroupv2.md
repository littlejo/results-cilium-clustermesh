CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod689ab67e_6548_4a5b_be6f_dde4d532fd15.slice/cri-containerd-de261b6f8c14361fcff46c3710847bd209f7d2ecbcd13f8506c09c320f8b2062.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod689ab67e_6548_4a5b_be6f_dde4d532fd15.slice/cri-containerd-3fa56da96d1cb6de8f6d5ecee2b42c840b08ff4ccec522b1dd38d845fb54ba07.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7c31093a_c4db_4b86_922c_57761d39947c.slice/cri-containerd-152688dd166e02d9dc3dc55c7955fa2c3f2c9db0c3ba9a02545f21c3e75ff672.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7c31093a_c4db_4b86_922c_57761d39947c.slice/cri-containerd-fdd347f4291549888b709031ab37c598a1567181b414992afc65d4b31834af3d.scope
    530      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67887fe2_b50d_436b_9158_72c504b60c18.slice/cri-containerd-fab5847c82c8212dac060ff50df15142d23d8067addb22777770f942b44cb989.scope
    74       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67887fe2_b50d_436b_9158_72c504b60c18.slice/cri-containerd-7f96004d91382805cfa3829a3c0c61d162b9360ac996a673db4f0ed81817bc6e.scope
    113      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod321fef2a_939e_4123_9cd5_bc89c2d290f3.slice/cri-containerd-00a19e6a18fdab1cb648cf200a6ae69ceec193ce92f8b377cb723eec63713b0f.scope
    526      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod321fef2a_939e_4123_9cd5_bc89c2d290f3.slice/cri-containerd-77d41056f89f0281db7716a4782a2bf35f6f78a3996912c3197233b68df3c5ea.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9f4b959_072c_47ec_b9be_cb56eb1c2787.slice/cri-containerd-9abedce24677ec283e253b6ec136d7ae5a4114071e79ec3a76cac73cf77dfe76.scope
    616      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9f4b959_072c_47ec_b9be_cb56eb1c2787.slice/cri-containerd-fb76150cdefb77bfad7e056278eccac716317dab512ef1b4c16bbbfb74264275.scope
    608      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9f4b959_072c_47ec_b9be_cb56eb1c2787.slice/cri-containerd-fd49e8c8ac66cc4c73e8685b61d5ed5e8f2dd857a284c0fde69a1de05e2f830e.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9f4b959_072c_47ec_b9be_cb56eb1c2787.slice/cri-containerd-7f63e3eb869e7c4a325a63a94c8bc5e3d5e5ef90b57680e56893e993827e4680.scope
    612      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c61ac1e_f128_4ae8_9b53_9932a49f5fc5.slice/cri-containerd-9a1c583f7a71c3d6bf268922ef506eab32fb332c95ec528485d9621684e3e325.scope
    82       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c61ac1e_f128_4ae8_9b53_9932a49f5fc5.slice/cri-containerd-4f40281d8e0e4809ac8de61bc2a71688202d9e76082be2cfe6eca768d14a98bf.scope
    70       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod19026eba_06ba_4451_b5ec_5eedfc3ed5e4.slice/cri-containerd-2b817a325f23c80341fbbebed30baddbcd96674e4212711954ad6cc390ee03bf.scope
    86       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod19026eba_06ba_4451_b5ec_5eedfc3ed5e4.slice/cri-containerd-0a168ce811c25ffc5582bd7302867f1854d944ff512a4036bb2815ec032cec3d.scope
    78       cgroup_device   multi                                          
