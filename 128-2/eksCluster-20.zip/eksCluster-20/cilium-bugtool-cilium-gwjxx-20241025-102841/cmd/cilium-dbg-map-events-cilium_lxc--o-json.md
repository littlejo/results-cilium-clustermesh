{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:47.574Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.169.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:47.574Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.075Z",
  "value": "id=4069  sec_id=4     flags=0x0000 ifindex=7   mac=96:28:33:79:88:18 nodemac=46:7F:FC:BD:2E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.086Z",
  "value": "id=2829  sec_id=1436627 flags=0x0000 ifindex=9   mac=86:F5:31:93:F4:51 nodemac=9E:F8:6F:A7:BF:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.115Z",
  "value": "id=1701  sec_id=1436627 flags=0x0000 ifindex=11  mac=F2:5D:5D:F1:1A:1B nodemac=8A:B4:02:3B:DA:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.118Z",
  "value": "id=2829  sec_id=1436627 flags=0x0000 ifindex=9   mac=86:F5:31:93:F4:51 nodemac=9E:F8:6F:A7:BF:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.119Z",
  "value": "id=1701  sec_id=1436627 flags=0x0000 ifindex=11  mac=F2:5D:5D:F1:1A:1B nodemac=8A:B4:02:3B:DA:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.127Z",
  "value": "id=4069  sec_id=4     flags=0x0000 ifindex=7   mac=96:28:33:79:88:18 nodemac=46:7F:FC:BD:2E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.128Z",
  "value": "id=4069  sec_id=4     flags=0x0000 ifindex=7   mac=96:28:33:79:88:18 nodemac=46:7F:FC:BD:2E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:16.450Z",
  "value": "id=2829  sec_id=1436627 flags=0x0000 ifindex=9   mac=86:F5:31:93:F4:51 nodemac=9E:F8:6F:A7:BF:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:16.451Z",
  "value": "id=4069  sec_id=4     flags=0x0000 ifindex=7   mac=96:28:33:79:88:18 nodemac=46:7F:FC:BD:2E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:16.451Z",
  "value": "id=1701  sec_id=1436627 flags=0x0000 ifindex=11  mac=F2:5D:5D:F1:1A:1B nodemac=8A:B4:02:3B:DA:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:16.479Z",
  "value": "id=3981  sec_id=1426970 flags=0x0000 ifindex=13  mac=0E:DA:E2:54:02:77 nodemac=96:35:7A:D9:1F:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:16.480Z",
  "value": "id=3981  sec_id=1426970 flags=0x0000 ifindex=13  mac=0E:DA:E2:54:02:77 nodemac=96:35:7A:D9:1F:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:17.450Z",
  "value": "id=4069  sec_id=4     flags=0x0000 ifindex=7   mac=96:28:33:79:88:18 nodemac=46:7F:FC:BD:2E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:17.451Z",
  "value": "id=3981  sec_id=1426970 flags=0x0000 ifindex=13  mac=0E:DA:E2:54:02:77 nodemac=96:35:7A:D9:1F:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:17.451Z",
  "value": "id=1701  sec_id=1436627 flags=0x0000 ifindex=11  mac=F2:5D:5D:F1:1A:1B nodemac=8A:B4:02:3B:DA:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:17.451Z",
  "value": "id=2829  sec_id=1436627 flags=0x0000 ifindex=9   mac=86:F5:31:93:F4:51 nodemac=9E:F8:6F:A7:BF:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:26.550Z",
  "value": "id=246   sec_id=1426970 flags=0x0000 ifindex=15  mac=5A:5A:00:81:9C:A2 nodemac=72:E0:BB:2E:9F:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:32.278Z",
  "value": "id=2829  sec_id=1436627 flags=0x0000 ifindex=9   mac=86:F5:31:93:F4:51 nodemac=9E:F8:6F:A7:BF:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:32.278Z",
  "value": "id=1701  sec_id=1436627 flags=0x0000 ifindex=11  mac=F2:5D:5D:F1:1A:1B nodemac=8A:B4:02:3B:DA:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:32.279Z",
  "value": "id=3981  sec_id=1426970 flags=0x0000 ifindex=13  mac=0E:DA:E2:54:02:77 nodemac=96:35:7A:D9:1F:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:32.279Z",
  "value": "id=246   sec_id=1426970 flags=0x0000 ifindex=15  mac=5A:5A:00:81:9C:A2 nodemac=72:E0:BB:2E:9F:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:32.281Z",
  "value": "id=4069  sec_id=4     flags=0x0000 ifindex=7   mac=96:28:33:79:88:18 nodemac=46:7F:FC:BD:2E:B7"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.20.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:32.732Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:33.282Z",
  "value": "id=2829  sec_id=1436627 flags=0x0000 ifindex=9   mac=86:F5:31:93:F4:51 nodemac=9E:F8:6F:A7:BF:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:33.282Z",
  "value": "id=1701  sec_id=1436627 flags=0x0000 ifindex=11  mac=F2:5D:5D:F1:1A:1B nodemac=8A:B4:02:3B:DA:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:33.283Z",
  "value": "id=4069  sec_id=4     flags=0x0000 ifindex=7   mac=96:28:33:79:88:18 nodemac=46:7F:FC:BD:2E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:33.283Z",
  "value": "id=246   sec_id=1426970 flags=0x0000 ifindex=15  mac=5A:5A:00:81:9C:A2 nodemac=72:E0:BB:2E:9F:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:34.278Z",
  "value": "id=4069  sec_id=4     flags=0x0000 ifindex=7   mac=96:28:33:79:88:18 nodemac=46:7F:FC:BD:2E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:34.278Z",
  "value": "id=2829  sec_id=1436627 flags=0x0000 ifindex=9   mac=86:F5:31:93:F4:51 nodemac=9E:F8:6F:A7:BF:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:34.279Z",
  "value": "id=1701  sec_id=1436627 flags=0x0000 ifindex=11  mac=F2:5D:5D:F1:1A:1B nodemac=8A:B4:02:3B:DA:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:34.279Z",
  "value": "id=246   sec_id=1426970 flags=0x0000 ifindex=15  mac=5A:5A:00:81:9C:A2 nodemac=72:E0:BB:2E:9F:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:35.279Z",
  "value": "id=2829  sec_id=1436627 flags=0x0000 ifindex=9   mac=86:F5:31:93:F4:51 nodemac=9E:F8:6F:A7:BF:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:35.279Z",
  "value": "id=4069  sec_id=4     flags=0x0000 ifindex=7   mac=96:28:33:79:88:18 nodemac=46:7F:FC:BD:2E:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:35.279Z",
  "value": "id=1701  sec_id=1436627 flags=0x0000 ifindex=11  mac=F2:5D:5D:F1:1A:1B nodemac=8A:B4:02:3B:DA:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:35.280Z",
  "value": "id=246   sec_id=1426970 flags=0x0000 ifindex=15  mac=5A:5A:00:81:9C:A2 nodemac=72:E0:BB:2E:9F:59"
}

