KEY             VALUE
AgentLiveness   975132497242
UTimeOffset     3378615582031250
