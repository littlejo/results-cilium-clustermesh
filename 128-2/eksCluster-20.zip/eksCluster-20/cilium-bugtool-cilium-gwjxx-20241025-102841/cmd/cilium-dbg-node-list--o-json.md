[
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.21.0.180"
      },
      "ipv6": {}
    },
    "name": "cmesh22/ip-172-31-247-164.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.21.0.0/24",
        "enabled": true,
        "ip": "172.31.247.164"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.21.0.211"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.22.0.208"
      },
      "ipv6": {}
    },
    "name": "cmesh23/ip-172-31-180-212.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.22.0.0/24",
        "enabled": true,
        "ip": "172.31.180.212"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.22.0.195"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.78.0.60"
      },
      "ipv6": {}
    },
    "name": "cmesh79/ip-172-31-133-70.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.78.0.0/24",
        "enabled": true,
        "ip": "172.31.133.70"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.78.0.235"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.39.0.180"
      },
      "ipv6": {}
    },
    "name": "cmesh40/ip-172-31-246-192.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.39.0.0/24",
        "enabled": true,
        "ip": "172.31.246.192"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.39.0.23"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.72.0.184"
      },
      "ipv6": {}
    },
    "name": "cmesh73/ip-172-31-168-162.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.72.0.0/24",
        "enabled": true,
        "ip": "172.31.168.162"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.72.0.140"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.120.0.130"
      },
      "ipv6": {}
    },
    "name": "cmesh121/ip-172-31-149-225.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.120.0.0/24",
        "enabled": true,
        "ip": "172.31.149.225"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.120.0.242"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.53.0.68"
      },
      "ipv6": {}
    },
    "name": "cmesh54/ip-172-31-222-147.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.53.0.0/24",
        "enabled": true,
        "ip": "172.31.222.147"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.53.0.181"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.56.0.186"
      },
      "ipv6": {}
    },
    "name": "cmesh57/ip-172-31-158-50.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.56.0.0/24",
        "enabled": true,
        "ip": "172.31.158.50"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.56.0.43"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.36.0.163"
      },
      "ipv6": {}
    },
    "name": "cmesh37/ip-172-31-142-96.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.36.0.0/24",
        "enabled": true,
        "ip": "172.31.142.96"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.36.0.35"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.51.0.173"
      },
      "ipv6": {}
    },
    "name": "cmesh52/ip-172-31-245-66.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.51.0.0/24",
        "enabled": true,
        "ip": "172.31.245.66"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.51.0.216"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.79.0.183"
      },
      "ipv6": {}
    },
    "name": "cmesh80/ip-172-31-217-236.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.79.0.0/24",
        "enabled": true,
        "ip": "172.31.217.236"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.79.0.164"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.87.0.179"
      },
      "ipv6": {}
    },
    "name": "cmesh88/ip-172-31-209-17.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.87.0.0/24",
        "enabled": true,
        "ip": "172.31.209.17"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.87.0.121"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.34.0.202"
      },
      "ipv6": {}
    },
    "name": "cmesh35/ip-172-31-189-5.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.34.0.0/24",
        "enabled": true,
        "ip": "172.31.189.5"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.34.0.2"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.69.0.170"
      },
      "ipv6": {}
    },
    "name": "cmesh70/ip-172-31-197-74.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.69.0.0/24",
        "enabled": true,
        "ip": "172.31.197.74"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.69.0.61"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.13.0.139"
      },
      "ipv6": {}
    },
    "name": "cmesh14/ip-172-31-226-178.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.13.0.0/24",
        "enabled": true,
        "ip": "172.31.226.178"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.13.0.68"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.24.0.252"
      },
      "ipv6": {}
    },
    "name": "cmesh25/ip-172-31-148-101.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.24.0.0/24",
        "enabled": true,
        "ip": "172.31.148.101"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.24.0.180"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.125.0.108"
      },
      "ipv6": {}
    },
    "name": "cmesh126/ip-172-31-220-135.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.125.0.0/24",
        "enabled": true,
        "ip": "172.31.220.135"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.125.0.30"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.97.0.22"
      },
      "ipv6": {}
    },
    "name": "cmesh98/ip-172-31-225-158.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.97.0.0/24",
        "enabled": true,
        "ip": "172.31.225.158"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.97.0.95"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.71.0.183"
      },
      "ipv6": {}
    },
    "name": "cmesh72/ip-172-31-244-208.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.71.0.0/24",
        "enabled": true,
        "ip": "172.31.244.208"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.71.0.214"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.8.0.247"
      },
      "ipv6": {}
    },
    "name": "cmesh9/ip-172-31-191-155.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.8.0.0/24",
        "enabled": true,
        "ip": "172.31.191.155"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.8.0.129"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.18.0.213"
      },
      "ipv6": {}
    },
    "name": "cmesh19/ip-172-31-161-89.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.18.0.0/24",
        "enabled": true,
        "ip": "172.31.161.89"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.18.0.160"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.16.0.81"
      },
      "ipv6": {}
    },
    "name": "cmesh17/ip-172-31-154-239.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.16.0.0/24",
        "enabled": true,
        "ip": "172.31.154.239"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.16.0.226"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.17.0.178"
      },
      "ipv6": {}
    },
    "name": "cmesh18/ip-172-31-247-244.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.17.0.0/24",
        "enabled": true,
        "ip": "172.31.247.244"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.17.0.65"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.104.0.154"
      },
      "ipv6": {}
    },
    "name": "cmesh105/ip-172-31-188-169.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.104.0.0/24",
        "enabled": true,
        "ip": "172.31.188.169"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.104.0.34"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.45.0.161"
      },
      "ipv6": {}
    },
    "name": "cmesh46/ip-172-31-210-97.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.45.0.0/24",
        "enabled": true,
        "ip": "172.31.210.97"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.45.0.89"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.58.0.234"
      },
      "ipv6": {}
    },
    "name": "cmesh59/ip-172-31-172-29.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.58.0.0/24",
        "enabled": true,
        "ip": "172.31.172.29"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.58.0.38"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.108.0.127"
      },
      "ipv6": {}
    },
    "name": "cmesh109/ip-172-31-173-246.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.108.0.0/24",
        "enabled": true,
        "ip": "172.31.173.246"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.108.0.5"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.82.0.139"
      },
      "ipv6": {}
    },
    "name": "cmesh83/ip-172-31-139-233.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.82.0.0/24",
        "enabled": true,
        "ip": "172.31.139.233"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.82.0.146"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.3.0.169"
      },
      "ipv6": {}
    },
    "name": "cmesh4/ip-172-31-250-86.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.3.0.0/24",
        "enabled": true,
        "ip": "172.31.250.86"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.3.0.60"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.57.0.30"
      },
      "ipv6": {}
    },
    "name": "cmesh58/ip-172-31-231-209.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.57.0.0/24",
        "enabled": true,
        "ip": "172.31.231.209"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.57.0.76"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.127.0.153"
      },
      "ipv6": {}
    },
    "name": "cmesh128/ip-172-31-246-169.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.127.0.0/24",
        "enabled": true,
        "ip": "172.31.246.169"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.127.0.198"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.115.0.242"
      },
      "ipv6": {}
    },
    "name": "cmesh116/ip-172-31-197-216.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.115.0.0/24",
        "enabled": true,
        "ip": "172.31.197.216"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.115.0.166"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.54.0.92"
      },
      "ipv6": {}
    },
    "name": "cmesh55/ip-172-31-145-45.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.54.0.0/24",
        "enabled": true,
        "ip": "172.31.145.45"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.54.0.211"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.66.0.31"
      },
      "ipv6": {}
    },
    "name": "cmesh67/ip-172-31-170-17.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.66.0.0/24",
        "enabled": true,
        "ip": "172.31.170.17"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.66.0.101"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.107.0.109"
      },
      "ipv6": {}
    },
    "name": "cmesh108/ip-172-31-238-183.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.107.0.0/24",
        "enabled": true,
        "ip": "172.31.238.183"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.107.0.111"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.93.0.4"
      },
      "ipv6": {}
    },
    "name": "cmesh94/ip-172-31-250-1.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.93.0.0/24",
        "enabled": true,
        "ip": "172.31.250.1"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.93.0.125"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.1.0.172"
      },
      "ipv6": {}
    },
    "name": "cmesh2/ip-172-31-197-251.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.1.0.0/24",
        "enabled": true,
        "ip": "172.31.197.251"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.1.0.212"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.49.0.28"
      },
      "ipv6": {}
    },
    "name": "cmesh50/ip-172-31-231-255.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.49.0.0/24",
        "enabled": true,
        "ip": "172.31.231.255"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.49.0.108"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.124.0.160"
      },
      "ipv6": {}
    },
    "name": "cmesh125/ip-172-31-147-32.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.124.0.0/24",
        "enabled": true,
        "ip": "172.31.147.32"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.124.0.136"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.110.0.73"
      },
      "ipv6": {}
    },
    "name": "cmesh111/ip-172-31-152-109.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.110.0.0/24",
        "enabled": true,
        "ip": "172.31.152.109"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.110.0.39"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.11.0.129"
      },
      "ipv6": {}
    },
    "name": "cmesh12/ip-172-31-197-79.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.11.0.0/24",
        "enabled": true,
        "ip": "172.31.197.79"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.11.0.96"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.94.0.74"
      },
      "ipv6": {}
    },
    "name": "cmesh95/ip-172-31-186-243.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.94.0.0/24",
        "enabled": true,
        "ip": "172.31.186.243"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.94.0.119"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.81.0.31"
      },
      "ipv6": {}
    },
    "name": "cmesh82/ip-172-31-195-150.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.81.0.0/24",
        "enabled": true,
        "ip": "172.31.195.150"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.81.0.5"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.74.0.148"
      },
      "ipv6": {}
    },
    "name": "cmesh75/ip-172-31-135-32.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.74.0.0/24",
        "enabled": true,
        "ip": "172.31.135.32"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.74.0.98"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.84.0.106"
      },
      "ipv6": {}
    },
    "name": "cmesh85/ip-172-31-140-168.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.84.0.0/24",
        "enabled": true,
        "ip": "172.31.140.168"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.84.0.62"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.7.0.135"
      },
      "ipv6": {}
    },
    "name": "cmesh8/ip-172-31-194-36.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.7.0.0/24",
        "enabled": true,
        "ip": "172.31.194.36"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.7.0.150"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.76.0.172"
      },
      "ipv6": {}
    },
    "name": "cmesh77/ip-172-31-158-228.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.76.0.0/24",
        "enabled": true,
        "ip": "172.31.158.228"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.76.0.156"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.6.0.79"
      },
      "ipv6": {}
    },
    "name": "cmesh7/ip-172-31-174-163.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.6.0.0/24",
        "enabled": true,
        "ip": "172.31.174.163"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.6.0.9"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.32.0.29"
      },
      "ipv6": {}
    },
    "name": "cmesh33/ip-172-31-186-90.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.32.0.0/24",
        "enabled": true,
        "ip": "172.31.186.90"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.32.0.142"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.15.0.157"
      },
      "ipv6": {}
    },
    "name": "cmesh16/ip-172-31-234-25.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.15.0.0/24",
        "enabled": true,
        "ip": "172.31.234.25"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.15.0.116"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.126.0.44"
      },
      "ipv6": {}
    },
    "name": "cmesh127/ip-172-31-181-107.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.126.0.0/24",
        "enabled": true,
        "ip": "172.31.181.107"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.126.0.166"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.12.0.142"
      },
      "ipv6": {}
    },
    "name": "cmesh13/ip-172-31-170-139.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.12.0.0/24",
        "enabled": true,
        "ip": "172.31.170.139"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.12.0.155"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.80.0.8"
      },
      "ipv6": {}
    },
    "name": "cmesh81/ip-172-31-133-51.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.80.0.0/24",
        "enabled": true,
        "ip": "172.31.133.51"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.80.0.211"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.26.0.233"
      },
      "ipv6": {}
    },
    "name": "cmesh27/ip-172-31-147-228.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.26.0.0/24",
        "enabled": true,
        "ip": "172.31.147.228"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.26.0.72"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.50.0.227"
      },
      "ipv6": {}
    },
    "name": "cmesh51/ip-172-31-144-60.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.50.0.0/24",
        "enabled": true,
        "ip": "172.31.144.60"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.50.0.31"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.98.0.126"
      },
      "ipv6": {}
    },
    "name": "cmesh99/ip-172-31-173-171.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.98.0.0/24",
        "enabled": true,
        "ip": "172.31.173.171"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.98.0.55"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.83.0.53"
      },
      "ipv6": {}
    },
    "name": "cmesh84/ip-172-31-231-66.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.83.0.0/24",
        "enabled": true,
        "ip": "172.31.231.66"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.83.0.221"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.38.0.236"
      },
      "ipv6": {}
    },
    "name": "cmesh39/ip-172-31-172-183.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.38.0.0/24",
        "enabled": true,
        "ip": "172.31.172.183"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.38.0.205"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.111.0.105"
      },
      "ipv6": {}
    },
    "name": "cmesh112/ip-172-31-227-62.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.111.0.0/24",
        "enabled": true,
        "ip": "172.31.227.62"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.111.0.43"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.20.0.10"
      },
      "ipv6": {}
    },
    "name": "cmesh21/ip-172-31-169-166.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.20.0.0/24",
        "enabled": true,
        "ip": "172.31.169.166"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.20.0.15"
      }
    ],
    "source": "local"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.67.0.5"
      },
      "ipv6": {}
    },
    "name": "cmesh68/ip-172-31-217-208.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.67.0.0/24",
        "enabled": true,
        "ip": "172.31.217.208"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.67.0.236"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.14.0.22"
      },
      "ipv6": {}
    },
    "name": "cmesh15/ip-172-31-147-77.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.14.0.0/24",
        "enabled": true,
        "ip": "172.31.147.77"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.14.0.231"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.121.0.254"
      },
      "ipv6": {}
    },
    "name": "cmesh122/ip-172-31-220-42.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.121.0.0/24",
        "enabled": true,
        "ip": "172.31.220.42"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.121.0.119"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.47.0.158"
      },
      "ipv6": {}
    },
    "name": "cmesh48/ip-172-31-206-43.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.47.0.0/24",
        "enabled": true,
        "ip": "172.31.206.43"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.47.0.74"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.44.0.59"
      },
      "ipv6": {}
    },
    "name": "cmesh45/ip-172-31-140-221.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.44.0.0/24",
        "enabled": true,
        "ip": "172.31.140.221"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.44.0.60"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.65.0.128"
      },
      "ipv6": {}
    },
    "name": "cmesh66/ip-172-31-232-182.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.65.0.0/24",
        "enabled": true,
        "ip": "172.31.232.182"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.65.0.135"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.19.0.84"
      },
      "ipv6": {}
    },
    "name": "cmesh20/ip-172-31-210-89.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.19.0.0/24",
        "enabled": true,
        "ip": "172.31.210.89"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.19.0.12"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.70.0.18"
      },
      "ipv6": {}
    },
    "name": "cmesh71/ip-172-31-176-0.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.70.0.0/24",
        "enabled": true,
        "ip": "172.31.176.0"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.70.0.37"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.23.0.202"
      },
      "ipv6": {}
    },
    "name": "cmesh24/ip-172-31-206-64.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.23.0.0/24",
        "enabled": true,
        "ip": "172.31.206.64"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.23.0.5"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.9.0.233"
      },
      "ipv6": {}
    },
    "name": "cmesh10/ip-172-31-208-120.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.9.0.0/24",
        "enabled": true,
        "ip": "172.31.208.120"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.9.0.186"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.123.0.42"
      },
      "ipv6": {}
    },
    "name": "cmesh124/ip-172-31-226-176.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.123.0.0/24",
        "enabled": true,
        "ip": "172.31.226.176"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.123.0.109"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.35.0.90"
      },
      "ipv6": {}
    },
    "name": "cmesh36/ip-172-31-193-211.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.35.0.0/24",
        "enabled": true,
        "ip": "172.31.193.211"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.35.0.180"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.41.0.67"
      },
      "ipv6": {}
    },
    "name": "cmesh42/ip-172-31-249-77.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.41.0.0/24",
        "enabled": true,
        "ip": "172.31.249.77"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.41.0.69"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.5.0.44"
      },
      "ipv6": {}
    },
    "name": "cmesh6/ip-172-31-239-114.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.5.0.0/24",
        "enabled": true,
        "ip": "172.31.239.114"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.5.0.166"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.30.0.87"
      },
      "ipv6": {}
    },
    "name": "cmesh31/ip-172-31-161-158.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.30.0.0/24",
        "enabled": true,
        "ip": "172.31.161.158"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.30.0.203"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.4.0.207"
      },
      "ipv6": {}
    },
    "name": "cmesh5/ip-172-31-172-128.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.4.0.0/24",
        "enabled": true,
        "ip": "172.31.172.128"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.4.0.4"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.29.0.241"
      },
      "ipv6": {}
    },
    "name": "cmesh30/ip-172-31-243-59.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.29.0.0/24",
        "enabled": true,
        "ip": "172.31.243.59"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.29.0.151"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.0.0.126"
      },
      "ipv6": {}
    },
    "name": "cmesh1/ip-172-31-188-219.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.0.0.0/24",
        "enabled": true,
        "ip": "172.31.188.219"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.0.0.5"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.114.0.223"
      },
      "ipv6": {}
    },
    "name": "cmesh115/ip-172-31-143-66.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.114.0.0/24",
        "enabled": true,
        "ip": "172.31.143.66"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.114.0.17"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.106.0.5"
      },
      "ipv6": {}
    },
    "name": "cmesh107/ip-172-31-178-197.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.106.0.0/24",
        "enabled": true,
        "ip": "172.31.178.197"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.106.0.59"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.90.0.141"
      },
      "ipv6": {}
    },
    "name": "cmesh91/ip-172-31-162-75.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.90.0.0/24",
        "enabled": true,
        "ip": "172.31.162.75"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.90.0.226"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.40.0.37"
      },
      "ipv6": {}
    },
    "name": "cmesh41/ip-172-31-175-121.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.40.0.0/24",
        "enabled": true,
        "ip": "172.31.175.121"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.40.0.144"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.60.0.93"
      },
      "ipv6": {}
    },
    "name": "cmesh61/ip-172-31-184-13.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.60.0.0/24",
        "enabled": true,
        "ip": "172.31.184.13"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.60.0.24"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.95.0.25"
      },
      "ipv6": {}
    },
    "name": "cmesh96/ip-172-31-207-111.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.95.0.0/24",
        "enabled": true,
        "ip": "172.31.207.111"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.95.0.84"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.86.0.92"
      },
      "ipv6": {}
    },
    "name": "cmesh87/ip-172-31-156-163.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.86.0.0/24",
        "enabled": true,
        "ip": "172.31.156.163"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.86.0.197"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.96.0.231"
      },
      "ipv6": {}
    },
    "name": "cmesh97/ip-172-31-129-241.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.96.0.0/24",
        "enabled": true,
        "ip": "172.31.129.241"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.96.0.197"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.100.0.204"
      },
      "ipv6": {}
    },
    "name": "cmesh101/ip-172-31-165-24.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.100.0.0/24",
        "enabled": true,
        "ip": "172.31.165.24"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.100.0.85"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.99.0.170"
      },
      "ipv6": {}
    },
    "name": "cmesh100/ip-172-31-201-30.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.99.0.0/24",
        "enabled": true,
        "ip": "172.31.201.30"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.99.0.78"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.109.0.196"
      },
      "ipv6": {}
    },
    "name": "cmesh110/ip-172-31-224-45.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.109.0.0/24",
        "enabled": true,
        "ip": "172.31.224.45"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.109.0.243"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.42.0.249"
      },
      "ipv6": {}
    },
    "name": "cmesh43/ip-172-31-149-98.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.42.0.0/24",
        "enabled": true,
        "ip": "172.31.149.98"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.42.0.95"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.85.0.63"
      },
      "ipv6": {}
    },
    "name": "cmesh86/ip-172-31-228-79.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.85.0.0/24",
        "enabled": true,
        "ip": "172.31.228.79"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.85.0.154"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.103.0.166"
      },
      "ipv6": {}
    },
    "name": "cmesh104/ip-172-31-216-37.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.103.0.0/24",
        "enabled": true,
        "ip": "172.31.216.37"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.103.0.65"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.37.0.134"
      },
      "ipv6": {}
    },
    "name": "cmesh38/ip-172-31-235-234.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.37.0.0/24",
        "enabled": true,
        "ip": "172.31.235.234"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.37.0.251"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.52.0.161"
      },
      "ipv6": {}
    },
    "name": "cmesh53/ip-172-31-143-87.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.52.0.0/24",
        "enabled": true,
        "ip": "172.31.143.87"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.52.0.154"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.92.0.87"
      },
      "ipv6": {}
    },
    "name": "cmesh93/ip-172-31-129-184.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.92.0.0/24",
        "enabled": true,
        "ip": "172.31.129.184"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.92.0.92"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.102.0.61"
      },
      "ipv6": {}
    },
    "name": "cmesh103/ip-172-31-184-93.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.102.0.0/24",
        "enabled": true,
        "ip": "172.31.184.93"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.102.0.20"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.48.0.31"
      },
      "ipv6": {}
    },
    "name": "cmesh49/ip-172-31-149-115.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.48.0.0/24",
        "enabled": true,
        "ip": "172.31.149.115"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.48.0.47"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.31.0.66"
      },
      "ipv6": {}
    },
    "name": "cmesh32/ip-172-31-247-172.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.31.0.0/24",
        "enabled": true,
        "ip": "172.31.247.172"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.31.0.199"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.116.0.248"
      },
      "ipv6": {}
    },
    "name": "cmesh117/ip-172-31-163-31.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.116.0.0/24",
        "enabled": true,
        "ip": "172.31.163.31"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.116.0.139"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.28.0.191"
      },
      "ipv6": {}
    },
    "name": "cmesh29/ip-172-31-144-216.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.28.0.0/24",
        "enabled": true,
        "ip": "172.31.144.216"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.28.0.214"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.59.0.133"
      },
      "ipv6": {}
    },
    "name": "cmesh60/ip-172-31-249-105.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.59.0.0/24",
        "enabled": true,
        "ip": "172.31.249.105"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.59.0.86"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.101.0.168"
      },
      "ipv6": {}
    },
    "name": "cmesh102/ip-172-31-195-223.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.101.0.0/24",
        "enabled": true,
        "ip": "172.31.195.223"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.101.0.8"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.91.0.78"
      },
      "ipv6": {}
    },
    "name": "cmesh92/ip-172-31-225-137.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.91.0.0/24",
        "enabled": true,
        "ip": "172.31.225.137"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.91.0.194"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.43.0.137"
      },
      "ipv6": {}
    },
    "name": "cmesh44/ip-172-31-251-101.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.43.0.0/24",
        "enabled": true,
        "ip": "172.31.251.101"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.43.0.254"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.105.0.237"
      },
      "ipv6": {}
    },
    "name": "cmesh106/ip-172-31-227-91.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.105.0.0/24",
        "enabled": true,
        "ip": "172.31.227.91"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.105.0.35"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.64.0.169"
      },
      "ipv6": {}
    },
    "name": "cmesh65/ip-172-31-129-220.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.64.0.0/24",
        "enabled": true,
        "ip": "172.31.129.220"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.64.0.112"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.75.0.18"
      },
      "ipv6": {}
    },
    "name": "cmesh76/ip-172-31-198-153.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.75.0.0/24",
        "enabled": true,
        "ip": "172.31.198.153"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.75.0.67"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.55.0.64"
      },
      "ipv6": {}
    },
    "name": "cmesh56/ip-172-31-246-231.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.55.0.0/24",
        "enabled": true,
        "ip": "172.31.246.231"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.55.0.200"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.33.0.206"
      },
      "ipv6": {}
    },
    "name": "cmesh34/ip-172-31-229-207.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.33.0.0/24",
        "enabled": true,
        "ip": "172.31.229.207"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.33.0.3"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.46.0.246"
      },
      "ipv6": {}
    },
    "name": "cmesh47/ip-172-31-190-180.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.46.0.0/24",
        "enabled": true,
        "ip": "172.31.190.180"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.46.0.170"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.63.0.92"
      },
      "ipv6": {}
    },
    "name": "cmesh64/ip-172-31-240-216.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.63.0.0/24",
        "enabled": true,
        "ip": "172.31.240.216"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.63.0.115"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.61.0.165"
      },
      "ipv6": {}
    },
    "name": "cmesh62/ip-172-31-242-183.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.61.0.0/24",
        "enabled": true,
        "ip": "172.31.242.183"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.61.0.25"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.118.0.76"
      },
      "ipv6": {}
    },
    "name": "cmesh119/ip-172-31-169-120.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.118.0.0/24",
        "enabled": true,
        "ip": "172.31.169.120"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.118.0.139"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.119.0.129"
      },
      "ipv6": {}
    },
    "name": "cmesh120/ip-172-31-250-55.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.119.0.0/24",
        "enabled": true,
        "ip": "172.31.250.55"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.119.0.245"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.2.0.139"
      },
      "ipv6": {}
    },
    "name": "cmesh3/ip-172-31-169-175.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.2.0.0/24",
        "enabled": true,
        "ip": "172.31.169.175"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.2.0.244"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.25.0.72"
      },
      "ipv6": {}
    },
    "name": "cmesh26/ip-172-31-217-133.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.25.0.0/24",
        "enabled": true,
        "ip": "172.31.217.133"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.25.0.193"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.89.0.97"
      },
      "ipv6": {}
    },
    "name": "cmesh90/ip-172-31-234-174.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.89.0.0/24",
        "enabled": true,
        "ip": "172.31.234.174"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.89.0.237"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.73.0.193"
      },
      "ipv6": {}
    },
    "name": "cmesh74/ip-172-31-213-46.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.73.0.0/24",
        "enabled": true,
        "ip": "172.31.213.46"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.73.0.43"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.112.0.135"
      },
      "ipv6": {}
    },
    "name": "cmesh113/ip-172-31-179-165.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.112.0.0/24",
        "enabled": true,
        "ip": "172.31.179.165"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.112.0.163"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.27.0.220"
      },
      "ipv6": {}
    },
    "name": "cmesh28/ip-172-31-253-235.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.27.0.0/24",
        "enabled": true,
        "ip": "172.31.253.235"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.27.0.236"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.77.0.185"
      },
      "ipv6": {}
    },
    "name": "cmesh78/ip-172-31-236-177.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.77.0.0/24",
        "enabled": true,
        "ip": "172.31.236.177"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.77.0.192"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.88.0.151"
      },
      "ipv6": {}
    },
    "name": "cmesh89/ip-172-31-167-92.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.88.0.0/24",
        "enabled": true,
        "ip": "172.31.167.92"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.88.0.157"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.113.0.198"
      },
      "ipv6": {}
    },
    "name": "cmesh114/ip-172-31-195-97.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.113.0.0/24",
        "enabled": true,
        "ip": "172.31.195.97"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.113.0.127"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.68.0.164"
      },
      "ipv6": {}
    },
    "name": "cmesh69/ip-172-31-137-105.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.68.0.0/24",
        "enabled": true,
        "ip": "172.31.137.105"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.68.0.19"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.122.0.37"
      },
      "ipv6": {}
    },
    "name": "cmesh123/ip-172-31-144-245.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.122.0.0/24",
        "enabled": true,
        "ip": "172.31.144.245"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.122.0.103"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.62.0.73"
      },
      "ipv6": {}
    },
    "name": "cmesh63/ip-172-31-134-163.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.62.0.0/24",
        "enabled": true,
        "ip": "172.31.134.163"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.62.0.19"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.10.0.104"
      },
      "ipv6": {}
    },
    "name": "cmesh11/ip-172-31-155-27.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.10.0.0/24",
        "enabled": true,
        "ip": "172.31.155.27"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.10.0.102"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.117.0.145"
      },
      "ipv6": {}
    },
    "name": "cmesh118/ip-172-31-209-231.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.117.0.0/24",
        "enabled": true,
        "ip": "172.31.209.231"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.117.0.238"
      }
    ],
    "source": "clustermesh"
  }
]

