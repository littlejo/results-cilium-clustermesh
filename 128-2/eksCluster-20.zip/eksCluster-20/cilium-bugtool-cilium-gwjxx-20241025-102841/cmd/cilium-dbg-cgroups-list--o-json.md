[
  {
    "containers": [
      {
        "cgroup-id": 8538,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9f4b959_072c_47ec_b9be_cb56eb1c2787.slice/cri-containerd-7f63e3eb869e7c4a325a63a94c8bc5e3d5e5ef90b57680e56893e993827e4680.scope"
      },
      {
        "cgroup-id": 8454,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9f4b959_072c_47ec_b9be_cb56eb1c2787.slice/cri-containerd-fb76150cdefb77bfad7e056278eccac716317dab512ef1b4c16bbbfb74264275.scope"
      },
      {
        "cgroup-id": 8622,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9f4b959_072c_47ec_b9be_cb56eb1c2787.slice/cri-containerd-9abedce24677ec283e253b6ec136d7ae5a4114071e79ec3a76cac73cf77dfe76.scope"
      }
    ],
    "ips": [
      "10.20.0.234"
    ],
    "name": "clustermesh-apiserver-55f8d8cb74-d5kk7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7110,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7c31093a_c4db_4b86_922c_57761d39947c.slice/cri-containerd-152688dd166e02d9dc3dc55c7955fa2c3f2c9db0c3ba9a02545f21c3e75ff672.scope"
      }
    ],
    "ips": [
      "10.20.0.245"
    ],
    "name": "coredns-cc6ccd49c-k9sqh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7026,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod321fef2a_939e_4123_9cd5_bc89c2d290f3.slice/cri-containerd-77d41056f89f0281db7716a4782a2bf35f6f78a3996912c3197233b68df3c5ea.scope"
      }
    ],
    "ips": [
      "10.20.0.41"
    ],
    "name": "coredns-cc6ccd49c-7fjv4",
    "namespace": "kube-system"
  }
]

