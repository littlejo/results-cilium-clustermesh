35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:01+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:01+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:01+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:01+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:01+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:01+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:02+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:02+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:02+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:02+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:06+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
67: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
70: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
71: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
74: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
75: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
78: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
79: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
82: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
83: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
86: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
110: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
113: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
454: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:49+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 112
455: sched_cls  name tail_handle_ipv4  tag 73a0441dc901ec6a  gpl
	loaded_at 2024-10-25T10:13:49+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 69,68,75,70,91
	btf_id 113
456: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:49+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 114
457: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:49+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 70,91
	btf_id 115
459: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 70,69,94
	btf_id 118
460: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 119
461: sched_cls  name tail_handle_ipv4_from_host  tag dad5794d72431985  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,94
	btf_id 120
463: sched_cls  name __send_drop_notify  tag 3170ca5275bd534e  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 122
464: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,94
	btf_id 123
466: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 126
467: sched_cls  name tail_handle_ipv4_from_host  tag dad5794d72431985  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,95
	btf_id 127
469: sched_cls  name __send_drop_notify  tag 3170ca5275bd534e  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 129
470: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,95
	btf_id 130
472: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,98
	btf_id 133
473: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 70,98,69
	btf_id 134
476: sched_cls  name tail_handle_ipv4_from_host  tag dad5794d72431985  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,98
	btf_id 137
478: sched_cls  name __send_drop_notify  tag 3170ca5275bd534e  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 139
479: sched_cls  name cil_from_container  tag 43a1898815a0ccb9  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 102,70
	btf_id 143
480: sched_cls  name tail_ipv4_ct_ingress  tag 58163fd0db7fbd93  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,102,76,77,103,78
	btf_id 144
483: sched_cls  name tail_ipv4_to_endpoint  tag 25b2d86b1510211d  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,103,35,76,77,74,99,33,102,34,31,32
	btf_id 145
490: sched_cls  name tail_handle_ipv4  tag 3f06e98c3b63344f  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,102
	btf_id 148
492: sched_cls  name __send_drop_notify  tag 8bb6249ee388ffde  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 156
496: sched_cls  name handle_policy  tag 71fdba461dd42366  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,102,76,77,103,35,74,99,33,78,69,34,31,32
	btf_id 157
497: sched_cls  name tail_ipv4_ct_egress  tag 52ebf65598dc32fd  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,102,76,77,103,78
	btf_id 162
498: sched_cls  name tail_handle_ipv4_cont  tag 40419f653ced6933  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,103,35,99,76,77,33,70,68,71,102,34,31,32,75
	btf_id 163
499: sched_cls  name tail_handle_arp  tag c3bb4f25a4bef577  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,102
	btf_id 164
500: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,102
	btf_id 165
501: sched_cls  name handle_policy  tag c82815d5fc03ebcd  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,106,76,77,105,35,74,104,33,78,69,34,31,32
	btf_id 161
502: sched_cls  name __send_drop_notify  tag 258a7197cca03e23  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 166
503: sched_cls  name tail_handle_ipv4  tag 77c0eea729578c9d  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,106
	btf_id 167
504: sched_cls  name tail_handle_arp  tag b787956182bd6580  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,106
	btf_id 170
505: sched_cls  name cil_from_container  tag 965879cc990c7088  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 106,70
	btf_id 171
506: sched_cls  name tail_ipv4_ct_ingress  tag ef25e50033ca00d6  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,106,76,77,105,78
	btf_id 172
507: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,106
	btf_id 173
508: sched_cls  name handle_policy  tag a67ecb5083dd6f2e  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 70,107,76,77,108,35,74,92,33,78,69,34,31,32
	btf_id 169
509: sched_cls  name __send_drop_notify  tag 722cfe29fd84b19f  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 175
510: sched_cls  name tail_ipv4_ct_egress  tag 52ebf65598dc32fd  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,106,76,77,105,78
	btf_id 174
512: sched_cls  name tail_handle_ipv4_cont  tag cc3c5f7d1a19df54  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,105,35,104,76,77,33,70,68,71,106,34,31,32,75
	btf_id 178
513: sched_cls  name tail_ipv4_to_endpoint  tag 973e3845567c81a9  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 69,70,108,35,76,77,74,92,33,107,34,31,32
	btf_id 176
514: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 70,107,76,77,108,78
	btf_id 179
515: sched_cls  name tail_handle_arp  tag 430ac1d2595d7a77  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,107
	btf_id 180
516: sched_cls  name tail_handle_ipv4_cont  tag cbfc86d5591d4a97  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 69,108,35,92,76,77,33,70,68,71,107,34,31,32,75
	btf_id 181
517: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,107
	btf_id 183
518: sched_cls  name tail_ipv4_to_endpoint  tag 12ef6a765c782bb8  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,105,35,76,77,74,104,33,106,34,31,32
	btf_id 182
519: sched_cls  name tail_handle_ipv4  tag f13fc707370f23f6  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,107
	btf_id 184
520: sched_cls  name tail_ipv4_ct_ingress  tag ebac55c2ee0d7292  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 70,107,76,77,108,78
	btf_id 185
521: sched_cls  name cil_from_container  tag f6056929e23581a3  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 107,70
	btf_id 186
523: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
526: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
527: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
530: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
531: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
534: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
535: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
538: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
578: sched_cls  name cil_from_container  tag 0ad413dff9168a4f  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 125,70
	btf_id 203
579: sched_cls  name tail_handle_arp  tag 91c02597062a2744  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,125
	btf_id 204
580: sched_cls  name handle_policy  tag 73769d70a9316237  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,125,76,77,124,35,74,123,33,78,69,34,31,32
	btf_id 205
581: sched_cls  name tail_handle_ipv4  tag ccdf65b0bf9fbd33  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,125
	btf_id 206
582: sched_cls  name tail_ipv4_ct_ingress  tag b924f0c225a8d4f1  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,125,76,77,124,78
	btf_id 207
584: sched_cls  name tail_handle_ipv4_cont  tag 5897a0cad246a25a  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,124,35,123,76,77,33,70,68,71,125,34,31,32,75
	btf_id 209
585: sched_cls  name tail_ipv4_ct_egress  tag 0b09bc88efae7f5c  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,125,76,77,124,78
	btf_id 210
586: sched_cls  name tail_ipv4_to_endpoint  tag 7236a34195b754bd  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,124,35,76,77,74,123,33,125,34,31,32
	btf_id 211
587: sched_cls  name __send_drop_notify  tag ad4dbeb8ab6bcf3c  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 212
588: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,125
	btf_id 213
589: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
592: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
605: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
608: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
609: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
612: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
613: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
616: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
