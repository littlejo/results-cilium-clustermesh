top - 10:28:42 up 15 min,  0 users,  load average: 0.24, 0.15, 0.11
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 17.6 us, 17.6 sy,  0.0 ni, 64.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1027.4 free,    891.1 used,   1917.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2776.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    664 root      20   0 1240432  16088  11420 S   6.7   0.4   0:00.03 cilium-+
      1 root      20   0 1538100 286800  77632 S   0.0   7.3   0:24.75 cilium-+
    391 root      20   0 1228848   5904   3056 S   0.0   0.2   0:00.27 cilium-+
    644 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    645 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    690 root      20   0    6576   2408   2084 R   0.0   0.1   0:00.00 top
    708 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
