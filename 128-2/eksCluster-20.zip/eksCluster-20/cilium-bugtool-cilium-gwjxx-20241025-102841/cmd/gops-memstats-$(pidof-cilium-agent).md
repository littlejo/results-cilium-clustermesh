alloc: 74.76MB (78388992 bytes)
total-alloc: 1.39GB (1487639568 bytes)
sys: 214.38MB (224798036 bytes)
lookups: 0
mallocs: 48459641
frees: 47927232
heap-alloc: 74.76MB (78388992 bytes)
heap-sys: 170.61MB (178896896 bytes)
heap-idle: 53.02MB (55599104 bytes)
heap-in-use: 117.59MB (123297792 bytes)
heap-released: 7.68MB (8052736 bytes)
heap-objects: 532409
stack-in-use: 33.34MB (34963456 bytes)
stack-sys: 33.34MB (34963456 bytes)
stack-mspan-inuse: 1.93MB (2020000 bytes)
stack-mspan-sys: 2.44MB (2562240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 896.81KB (918329 bytes)
gc-sys: 5.18MB (5435744 bytes)
next-gc: when heap-alloc >= 146.40MB (153515336 bytes)
last-gc: 2024-10-25 10:29:09.626095859 +0000 UTC
gc-pause-total: 10.008736ms
gc-pause: 72321
gc-pause-end: 1729852149626095859
num-gc: 75
num-forced-gc: 0
gc-cpu-fraction: 0.00034757158387307545
enable-gc: true
debug-gc: false
