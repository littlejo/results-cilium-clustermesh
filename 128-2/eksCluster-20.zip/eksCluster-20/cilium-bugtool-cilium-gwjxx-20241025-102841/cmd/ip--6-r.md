fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxc8f66c728f41f proto kernel metric 256 pref medium
fe80::/64 dev lxc2b8724b6c77a proto kernel metric 256 pref medium
fe80::/64 dev lxc467593dba65a proto kernel metric 256 pref medium
