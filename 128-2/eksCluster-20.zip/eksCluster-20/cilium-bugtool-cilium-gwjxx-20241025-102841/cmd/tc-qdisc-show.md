qdisc noqueue 0: dev lo root refcnt 2 
qdisc mq 0: dev ens5 root 
qdisc fq_codel 0: dev ens5 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens5 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens5 parent ffff:fff1 
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
qdisc clsact ffff: dev cilium_vxlan parent ffff:fff1 
qdisc noqueue 0: dev lxc_health root refcnt 2 
qdisc clsact ffff: dev lxc_health parent ffff:fff1 
qdisc noqueue 0: dev lxc8f66c728f41f root refcnt 2 
qdisc clsact ffff: dev lxc8f66c728f41f parent ffff:fff1 
qdisc noqueue 0: dev lxc2b8724b6c77a root refcnt 2 
qdisc clsact ffff: dev lxc2b8724b6c77a parent ffff:fff1 
qdisc noqueue 0: dev lxc467593dba65a root refcnt 2 
qdisc clsact ffff: dev lxc467593dba65a parent ffff:fff1 
