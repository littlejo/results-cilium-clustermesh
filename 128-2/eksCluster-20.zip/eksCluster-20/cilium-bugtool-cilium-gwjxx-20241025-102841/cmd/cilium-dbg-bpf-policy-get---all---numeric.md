Endpoint ID: 246
Path: /sys/fs/bpf/tc/globals/cilium_policy_00246

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3944899   36782     0        
Allow    Ingress     1          ANY          NONE         disabled    3225559   32265     0        
Allow    Egress      0          ANY          NONE         disabled    4254749   39514     0        


Endpoint ID: 1701
Path: /sys/fs/bpf/tc/globals/cilium_policy_01701

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    87227   1003      0        
Allow    Egress      0          ANY          NONE         disabled    14015   147       0        


Endpoint ID: 2793
Path: /sys/fs/bpf/tc/globals/cilium_policy_02793

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2829
Path: /sys/fs/bpf/tc/globals/cilium_policy_02829

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    86850   1000      0        
Allow    Egress      0          ANY          NONE         disabled    14592   154       0        


Endpoint ID: 4069
Path: /sys/fs/bpf/tc/globals/cilium_policy_04069

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    436319   5582      0        
Allow    Ingress     1          ANY          NONE         disabled    12676    147       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


