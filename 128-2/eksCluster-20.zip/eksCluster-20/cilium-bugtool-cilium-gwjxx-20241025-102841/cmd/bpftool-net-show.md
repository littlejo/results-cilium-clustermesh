xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 473
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 466
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 460
cilium_host(4) clsact/egress cil_from_host-cilium_host id 459
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 457
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 456
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 521
lxc8f66c728f41f(9) clsact/ingress cil_from_container-lxc8f66c728f41f id 479
lxc2b8724b6c77a(11) clsact/ingress cil_from_container-lxc2b8724b6c77a id 505
lxc467593dba65a(15) clsact/ingress cil_from_container-lxc467593dba65a id 578

flow_dissector:

netfilter:

