REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     10110     791129      677    bpf_overlay.c
Interface                 INGRESS     223726    101118987   1132   bpf_host.c
Success                   EGRESS      10345     808839      53     encap.h
Success                   EGRESS      5206      401030      1694   bpf_host.c
Success                   EGRESS      94519     12943795    1308   bpf_lxc.c
Success                   INGRESS     105872    12999262    86     l3.h
Success                   INGRESS     111426    13433337    235    trace.h
Unsupported L3 protocol   EGRESS      43        3242        1492   bpf_lxc.c
