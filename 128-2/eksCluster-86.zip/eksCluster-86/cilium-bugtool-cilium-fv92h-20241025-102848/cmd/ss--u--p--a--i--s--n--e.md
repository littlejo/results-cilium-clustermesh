Total: 559
TCP:   1098 (estab 308, closed 771, orphaned 0, timewait 305)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  327       316       11       
INET	  337       322       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.156.163%ens5:68         0.0.0.0:*    uid:192 ino:15729 sk:26e cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:24802 sk:26f cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15190 sk:270 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:43637      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:24772 sk:271 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:24801 sk:272 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15191 sk:273 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::438:daff:fe0f:6dff]%ens5:546           [::]:*    uid:192 ino:15720 sk:274 cgroup:unreachable:c4e v6only:1 <->                   
