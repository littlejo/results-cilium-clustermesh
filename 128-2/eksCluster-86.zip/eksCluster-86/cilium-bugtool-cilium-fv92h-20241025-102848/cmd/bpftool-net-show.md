xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 559
ens6(5) clsact/ingress cil_from_netdev-ens6 id 569
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 556
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 541
cilium_host(7) clsact/egress cil_from_host-cilium_host id 545
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 572
lxca9ae03edf777(12) clsact/ingress cil_from_container-lxca9ae03edf777 id 524
lxc7218135bb224(14) clsact/ingress cil_from_container-lxc7218135bb224 id 576
lxcb58650e4e597(18) clsact/ingress cil_from_container-lxcb58650e4e597 id 653

flow_dissector:

netfilter:

