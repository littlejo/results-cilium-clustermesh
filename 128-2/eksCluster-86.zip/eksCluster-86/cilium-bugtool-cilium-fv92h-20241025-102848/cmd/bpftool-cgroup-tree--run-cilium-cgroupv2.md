CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6242c880_64b2_4870_91de_21f53f7f3339.slice/cri-containerd-8cd8f4f43f0a2766d6e4d5e497d4acbb3de8ae5eea74152381a6c47e8c64401e.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6242c880_64b2_4870_91de_21f53f7f3339.slice/cri-containerd-4542b9299acfc3b74e22d3247e4a63e8a8316d8d33e98c7718cf22d1eed8ffc5.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod523b9937_9c4e_441a_a9db_c64cb2e8f118.slice/cri-containerd-c52d9dd704a6b1e2fbc1ef28e6333932c727feed783f0fadc2861d9d8c0b4fb2.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod523b9937_9c4e_441a_a9db_c64cb2e8f118.slice/cri-containerd-c04b0770bffe44467f7543806e02ccb4e2d3c53fc9ba99cfe8ff862b7b393827.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a97c6aa_7e33_48a0_8e82_f292688696fa.slice/cri-containerd-704f9c9cc7043c9aa578e084e109498d60ca5c85ac9697e6628db477d379dc91.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a97c6aa_7e33_48a0_8e82_f292688696fa.slice/cri-containerd-7e1928876ade3a591925af54ddc64d01306f751a69b2af2f021c6188d8c1d330.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod656d8753_94f0_4e93_ab50_ec35811dc567.slice/cri-containerd-46fa9bca257b9577d18522552f01ec0a0453b502e2b1bd6052b34137a110de5b.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod656d8753_94f0_4e93_ab50_ec35811dc567.slice/cri-containerd-3cf81611618df4656735dd17b757612b33e53b58f87fedef34fb8c401530035d.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda47bcb94_cef3_4e9d_93f8_b28048c63fda.slice/cri-containerd-ce19db788b08d14b66fee171d37cb14dee4b38fedd56b1873b47b06cb98bd518.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda47bcb94_cef3_4e9d_93f8_b28048c63fda.slice/cri-containerd-08751267a651a547999b98469fb02dbd4d64e69cfa8c338f7257f2204a3f4600.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7afc16ff_b0f2_4a4b_b323_756f6ef99fc9.slice/cri-containerd-8816ab2285dc192b7cb91b8727bf8b120fd68b79dcc9abdf19b558408858f3e8.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7afc16ff_b0f2_4a4b_b323_756f6ef99fc9.slice/cri-containerd-ac3f001b207877bd79f4b28cbd41c043a1b70c2e73ad2ecfce795250e835faca.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7afc16ff_b0f2_4a4b_b323_756f6ef99fc9.slice/cri-containerd-39cf9fe7d1912f3e61787efa5d5d73d8ff581f93822ae7f8836af108aeeb7843.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7afc16ff_b0f2_4a4b_b323_756f6ef99fc9.slice/cri-containerd-32ce8656baa737964a13d4e995be8e356d1ff17a32f2191b80fb161211282e56.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb64070ba_ebcd_4694_bb12_3be64340056f.slice/cri-containerd-6e1e343901e10acc4f2ce8520805835901799b33c92f921fb42b643cc0c4c453.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb64070ba_ebcd_4694_bb12_3be64340056f.slice/cri-containerd-e90efb67b030cbcd96996fc4fec3cf0fa25f7baa6bef7f601e1ea1d63d0fe01c.scope
    101      cgroup_device   multi                                          
