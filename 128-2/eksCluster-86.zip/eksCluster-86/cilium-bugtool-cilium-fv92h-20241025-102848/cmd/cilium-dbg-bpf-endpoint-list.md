IP ADDRESS         LOCAL ENDPOINT INFO
10.86.0.197:0      (localhost)                                                                                        
10.86.0.48:0       id=3508  sec_id=5765474 flags=0x0000 ifindex=12  mac=7E:48:C1:53:14:2A nodemac=CA:F1:2F:16:CD:00   
172.31.175.56:0    (localhost)                                                                                        
172.31.156.163:0   (localhost)                                                                                        
10.86.0.39:0       id=2924  sec_id=5702245 flags=0x0000 ifindex=18  mac=F2:54:B9:D2:20:EB nodemac=92:B8:86:4C:85:33   
10.86.0.92:0       id=1684  sec_id=4     flags=0x0000 ifindex=10  mac=3A:4A:B3:69:20:9C nodemac=26:CC:95:DD:C4:53     
10.86.0.1:0        id=1258  sec_id=5765474 flags=0x0000 ifindex=14  mac=DE:EE:0A:4B:31:55 nodemac=D6:4E:35:C8:A3:40   
