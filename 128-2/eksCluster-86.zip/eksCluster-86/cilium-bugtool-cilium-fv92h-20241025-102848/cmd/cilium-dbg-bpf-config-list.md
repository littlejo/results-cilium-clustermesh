KEY             VALUE
AgentLiveness   915263508106
UTimeOffset     3378615714843750
