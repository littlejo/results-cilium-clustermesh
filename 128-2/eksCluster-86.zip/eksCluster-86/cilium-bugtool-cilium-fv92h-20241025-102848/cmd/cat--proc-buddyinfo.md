Node 0, zone      DMA    254     44     14      5     54     57     16      4      2      4    171 
Node 0, zone   Normal    613     67     17     12     30      8      2      2      2      2      7 
