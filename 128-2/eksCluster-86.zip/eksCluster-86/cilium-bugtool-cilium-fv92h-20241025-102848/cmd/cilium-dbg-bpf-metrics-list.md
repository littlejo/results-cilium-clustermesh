REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     205439    83528509   1132   bpf_host.c
Interface                 INGRESS     8957      697496     677    bpf_overlay.c
Success                   EGRESS      3965      299598     1694   bpf_host.c
Success                   EGRESS      8426      658902     53     encap.h
Success                   EGRESS      87180     11883294   1308   bpf_lxc.c
Success                   INGRESS     102789    12336979   235    trace.h
Success                   INGRESS     97148     11895175   86     l3.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
