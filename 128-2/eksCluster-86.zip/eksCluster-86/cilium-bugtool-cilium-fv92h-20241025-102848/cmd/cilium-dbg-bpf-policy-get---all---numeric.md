Endpoint ID: 178
Path: /sys/fs/bpf/tc/globals/cilium_policy_00178

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1258
Path: /sys/fs/bpf/tc/globals/cilium_policy_01258

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    79147   914       0        
Allow    Egress      0          ANY          NONE         disabled    13270   139       0        


Endpoint ID: 1684
Path: /sys/fs/bpf/tc/globals/cilium_policy_01684

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    442631   5652      0        
Allow    Ingress     1          ANY          NONE         disabled    11465    133       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2924
Path: /sys/fs/bpf/tc/globals/cilium_policy_02924

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3896237   36009     0        
Allow    Ingress     1          ANY          NONE         disabled    2667181   26537     0        
Allow    Egress      0          ANY          NONE         disabled    3910107   36600     0        


Endpoint ID: 3508
Path: /sys/fs/bpf/tc/globals/cilium_policy_03508

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    79508   917       0        
Allow    Egress      0          ANY          NONE         disabled    14717   154       0        


