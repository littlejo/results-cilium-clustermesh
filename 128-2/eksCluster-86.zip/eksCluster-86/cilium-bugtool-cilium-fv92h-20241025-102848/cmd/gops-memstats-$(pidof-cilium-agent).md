alloc: 69.70MB (73088504 bytes)
total-alloc: 1.30GB (1400184544 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 47318805
frees: 46798426
heap-alloc: 69.70MB (73088504 bytes)
heap-sys: 168.01MB (176168960 bytes)
heap-idle: 57.34MB (60129280 bytes)
heap-in-use: 110.66MB (116039680 bytes)
heap-released: 1.84MB (1933312 bytes)
heap-objects: 520379
stack-in-use: 31.97MB (33521664 bytes)
stack-sys: 31.97MB (33521664 bytes)
stack-mspan-inuse: 1.87MB (1961920 bytes)
stack-mspan-sys: 2.44MB (2562240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 936.52KB (958993 bytes)
gc-sys: 5.13MB (5380304 bytes)
next-gc: when heap-alloc >= 145.69MB (152768120 bytes)
last-gc: 2024-10-25 10:29:16.728947523 +0000 UTC
gc-pause-total: 12.5858ms
gc-pause: 111024
gc-pause-end: 1729852156728947523
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00032413274268064683
enable-gc: true
debug-gc: false
