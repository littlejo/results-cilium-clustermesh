[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod523b9937_9c4e_441a_a9db_c64cb2e8f118.slice/cri-containerd-c04b0770bffe44467f7543806e02ccb4e2d3c53fc9ba99cfe8ff862b7b393827.scope"
      }
    ],
    "ips": [
      "10.86.0.48"
    ],
    "name": "coredns-cc6ccd49c-72vnv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7afc16ff_b0f2_4a4b_b323_756f6ef99fc9.slice/cri-containerd-ac3f001b207877bd79f4b28cbd41c043a1b70c2e73ad2ecfce795250e835faca.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7afc16ff_b0f2_4a4b_b323_756f6ef99fc9.slice/cri-containerd-8816ab2285dc192b7cb91b8727bf8b120fd68b79dcc9abdf19b558408858f3e8.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7afc16ff_b0f2_4a4b_b323_756f6ef99fc9.slice/cri-containerd-39cf9fe7d1912f3e61787efa5d5d73d8ff581f93822ae7f8836af108aeeb7843.scope"
      }
    ],
    "ips": [
      "10.86.0.39"
    ],
    "name": "clustermesh-apiserver-7c8779c849-xlpfc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a97c6aa_7e33_48a0_8e82_f292688696fa.slice/cri-containerd-7e1928876ade3a591925af54ddc64d01306f751a69b2af2f021c6188d8c1d330.scope"
      }
    ],
    "ips": [
      "10.86.0.1"
    ],
    "name": "coredns-cc6ccd49c-kq7nt",
    "namespace": "kube-system"
  }
]

