markdown output at /tmp/cilium-bugtool-20241025-102850.401+0000-UTC-1077774781/cmd/cilium-debuginfo-20241025-102921.215+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102850.401+0000-UTC-1077774781/cmd/cilium-debuginfo-20241025-102921.215+0000-UTC.json
