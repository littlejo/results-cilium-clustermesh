1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:38:da:0f:6d:ff brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.156.163/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2725sec preferred_lft 2725sec
    inet6 fe80::438:daff:fe0f:6dff/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ca:c6:6d:7e:35 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.175.56/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4ca:c6ff:fe6d:7e35/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:e9:2e:16:8e:00 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d0e9:2eff:fe16:8e00/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:11:68:47:44:60 brd ff:ff:ff:ff:ff:ff
    inet 10.86.0.197/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::3411:68ff:fe47:4460/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether c6:a4:41:98:c5:ba brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c4a4:41ff:fe98:c5ba/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:cc:95:dd:c4:53 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::24cc:95ff:fedd:c453/64 scope link 
       valid_lft forever preferred_lft forever
12: lxca9ae03edf777@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:f1:2f:16:cd:00 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::c8f1:2fff:fe16:cd00/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc7218135bb224@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:4e:35:c8:a3:40 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d44e:35ff:fec8:a340/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcb58650e4e597@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:b8:86:4c:85:33 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::90b8:86ff:fe4c:8533/64 scope link 
       valid_lft forever preferred_lft forever
