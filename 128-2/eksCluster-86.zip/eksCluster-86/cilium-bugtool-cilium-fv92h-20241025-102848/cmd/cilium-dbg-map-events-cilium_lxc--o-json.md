{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:20.704Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.156.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:20.704Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.175.56:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:20.704Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:25.194Z",
  "value": "id=1684  sec_id=4     flags=0x0000 ifindex=10  mac=3A:4A:B3:69:20:9C nodemac=26:CC:95:DD:C4:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:25.199Z",
  "value": "id=3508  sec_id=5765474 flags=0x0000 ifindex=12  mac=7E:48:C1:53:14:2A nodemac=CA:F1:2F:16:CD:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:25.259Z",
  "value": "id=1258  sec_id=5765474 flags=0x0000 ifindex=14  mac=DE:EE:0A:4B:31:55 nodemac=D6:4E:35:C8:A3:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:25.274Z",
  "value": "id=1684  sec_id=4     flags=0x0000 ifindex=10  mac=3A:4A:B3:69:20:9C nodemac=26:CC:95:DD:C4:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:09.336Z",
  "value": "id=1684  sec_id=4     flags=0x0000 ifindex=10  mac=3A:4A:B3:69:20:9C nodemac=26:CC:95:DD:C4:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:09.337Z",
  "value": "id=3508  sec_id=5765474 flags=0x0000 ifindex=12  mac=7E:48:C1:53:14:2A nodemac=CA:F1:2F:16:CD:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:09.338Z",
  "value": "id=1258  sec_id=5765474 flags=0x0000 ifindex=14  mac=DE:EE:0A:4B:31:55 nodemac=D6:4E:35:C8:A3:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:09.368Z",
  "value": "id=866   sec_id=5702245 flags=0x0000 ifindex=16  mac=7A:38:93:81:44:76 nodemac=66:D4:C0:6F:B6:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:10.337Z",
  "value": "id=3508  sec_id=5765474 flags=0x0000 ifindex=12  mac=7E:48:C1:53:14:2A nodemac=CA:F1:2F:16:CD:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:10.338Z",
  "value": "id=866   sec_id=5702245 flags=0x0000 ifindex=16  mac=7A:38:93:81:44:76 nodemac=66:D4:C0:6F:B6:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:10.338Z",
  "value": "id=1258  sec_id=5765474 flags=0x0000 ifindex=14  mac=DE:EE:0A:4B:31:55 nodemac=D6:4E:35:C8:A3:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:10.338Z",
  "value": "id=1684  sec_id=4     flags=0x0000 ifindex=10  mac=3A:4A:B3:69:20:9C nodemac=26:CC:95:DD:C4:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:50.481Z",
  "value": "id=2924  sec_id=5702245 flags=0x0000 ifindex=18  mac=F2:54:B9:D2:20:EB nodemac=92:B8:86:4C:85:33"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.86.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:00.971Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:00.232Z",
  "value": "id=2924  sec_id=5702245 flags=0x0000 ifindex=18  mac=F2:54:B9:D2:20:EB nodemac=92:B8:86:4C:85:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:00.233Z",
  "value": "id=1684  sec_id=4     flags=0x0000 ifindex=10  mac=3A:4A:B3:69:20:9C nodemac=26:CC:95:DD:C4:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:00.233Z",
  "value": "id=3508  sec_id=5765474 flags=0x0000 ifindex=12  mac=7E:48:C1:53:14:2A nodemac=CA:F1:2F:16:CD:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:00.234Z",
  "value": "id=1258  sec_id=5765474 flags=0x0000 ifindex=14  mac=DE:EE:0A:4B:31:55 nodemac=D6:4E:35:C8:A3:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:01.232Z",
  "value": "id=3508  sec_id=5765474 flags=0x0000 ifindex=12  mac=7E:48:C1:53:14:2A nodemac=CA:F1:2F:16:CD:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:01.233Z",
  "value": "id=1684  sec_id=4     flags=0x0000 ifindex=10  mac=3A:4A:B3:69:20:9C nodemac=26:CC:95:DD:C4:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:01.233Z",
  "value": "id=1258  sec_id=5765474 flags=0x0000 ifindex=14  mac=DE:EE:0A:4B:31:55 nodemac=D6:4E:35:C8:A3:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:01.233Z",
  "value": "id=2924  sec_id=5702245 flags=0x0000 ifindex=18  mac=F2:54:B9:D2:20:EB nodemac=92:B8:86:4C:85:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:02.233Z",
  "value": "id=3508  sec_id=5765474 flags=0x0000 ifindex=12  mac=7E:48:C1:53:14:2A nodemac=CA:F1:2F:16:CD:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:02.233Z",
  "value": "id=2924  sec_id=5702245 flags=0x0000 ifindex=18  mac=F2:54:B9:D2:20:EB nodemac=92:B8:86:4C:85:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:02.234Z",
  "value": "id=1258  sec_id=5765474 flags=0x0000 ifindex=14  mac=DE:EE:0A:4B:31:55 nodemac=D6:4E:35:C8:A3:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:02.234Z",
  "value": "id=1684  sec_id=4     flags=0x0000 ifindex=10  mac=3A:4A:B3:69:20:9C nodemac=26:CC:95:DD:C4:53"
}

