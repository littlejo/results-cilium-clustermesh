USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         637  0.0  0.1 1228744 4040 ?        Ssl  10:28   0:00 /bin/gops stack 1
root         615  2.0  0.3 1240432 15708 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         658  0.0  0.0   6408  1632 ?        R    10:28   0:00  \_ ps auxfw
root         659  0.0  0.3 1240432 15708 ?       R    10:28   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  2.7  7.0 1538100 275064 ?      Ssl  10:15   0:22 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.0  0.1 1228848 5984 ?        Sl   10:15   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
