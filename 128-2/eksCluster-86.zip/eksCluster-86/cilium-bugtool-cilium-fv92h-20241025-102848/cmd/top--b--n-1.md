top - 10:28:50 up 14 min,  0 users,  load average: 0.22, 0.30, 0.18
Tasks:   7 total,   2 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 63.3 us, 33.3 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   3836.2 total,    800.4 free,    895.1 used,   2140.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2772.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 284224  80452 S  60.0   7.2   0:22.79 cilium-+
    615 root      20   0 1240432  15708  10704 S   6.7   0.4   0:00.03 cilium-+
    396 root      20   0 1228848   5984   2872 S   0.0   0.2   0:00.27 cilium-+
    670 root      20   0    6576   2424   2100 R   0.0   0.1   0:00.00 top
    674 root      20   0 1229000   5008   3876 R   0.0   0.1   0:00.00 gops
    682 root      20   0 1228744   3660   2976 S   0.0   0.1   0:00.00 gops
    712 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
