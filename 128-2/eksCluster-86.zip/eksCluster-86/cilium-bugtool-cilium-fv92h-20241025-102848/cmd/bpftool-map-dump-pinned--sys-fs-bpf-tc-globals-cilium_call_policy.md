key: ea 04 00 00  value: 43 02 00 00
key: 94 06 00 00  value: 45 02 00 00
key: 6c 0b 00 00  value: 84 02 00 00
key: b4 0d 00 00  value: 19 02 00 00
Found 4 elements
