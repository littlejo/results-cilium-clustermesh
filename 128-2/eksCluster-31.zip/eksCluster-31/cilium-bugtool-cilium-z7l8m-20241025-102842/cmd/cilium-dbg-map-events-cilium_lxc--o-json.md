{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:02.927Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.244.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:02.928Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.247.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:02.928Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:08.186Z",
  "value": "id=897   sec_id=4     flags=0x0000 ifindex=10  mac=D6:CB:C6:40:8C:39 nodemac=CA:58:95:33:C4:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:08.191Z",
  "value": "id=2432  sec_id=2106273 flags=0x0000 ifindex=12  mac=3A:BF:16:F3:57:97 nodemac=92:88:89:C2:95:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:08.243Z",
  "value": "id=897   sec_id=4     flags=0x0000 ifindex=10  mac=D6:CB:C6:40:8C:39 nodemac=CA:58:95:33:C4:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:14.483Z",
  "value": "id=3082  sec_id=2106273 flags=0x0000 ifindex=14  mac=DE:C8:5F:F4:7D:BB nodemac=6A:8D:BE:22:5A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:53.847Z",
  "value": "id=897   sec_id=4     flags=0x0000 ifindex=10  mac=D6:CB:C6:40:8C:39 nodemac=CA:58:95:33:C4:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:53.848Z",
  "value": "id=2432  sec_id=2106273 flags=0x0000 ifindex=12  mac=3A:BF:16:F3:57:97 nodemac=92:88:89:C2:95:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:53.848Z",
  "value": "id=3082  sec_id=2106273 flags=0x0000 ifindex=14  mac=DE:C8:5F:F4:7D:BB nodemac=6A:8D:BE:22:5A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:53.880Z",
  "value": "id=719   sec_id=2106292 flags=0x0000 ifindex=16  mac=7E:46:07:45:A8:87 nodemac=9E:8F:36:A0:C1:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:11.791Z",
  "value": "id=3912  sec_id=2106292 flags=0x0000 ifindex=18  mac=42:80:3D:8C:78:50 nodemac=6A:33:59:F3:0F:98"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.31.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:18.354Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:18.548Z",
  "value": "id=897   sec_id=4     flags=0x0000 ifindex=10  mac=D6:CB:C6:40:8C:39 nodemac=CA:58:95:33:C4:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:18.548Z",
  "value": "id=2432  sec_id=2106273 flags=0x0000 ifindex=12  mac=3A:BF:16:F3:57:97 nodemac=92:88:89:C2:95:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:18.557Z",
  "value": "id=3082  sec_id=2106273 flags=0x0000 ifindex=14  mac=DE:C8:5F:F4:7D:BB nodemac=6A:8D:BE:22:5A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:18.558Z",
  "value": "id=3912  sec_id=2106292 flags=0x0000 ifindex=18  mac=42:80:3D:8C:78:50 nodemac=6A:33:59:F3:0F:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:19.533Z",
  "value": "id=3912  sec_id=2106292 flags=0x0000 ifindex=18  mac=42:80:3D:8C:78:50 nodemac=6A:33:59:F3:0F:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:19.537Z",
  "value": "id=897   sec_id=4     flags=0x0000 ifindex=10  mac=D6:CB:C6:40:8C:39 nodemac=CA:58:95:33:C4:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:19.537Z",
  "value": "id=2432  sec_id=2106273 flags=0x0000 ifindex=12  mac=3A:BF:16:F3:57:97 nodemac=92:88:89:C2:95:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:19.538Z",
  "value": "id=3082  sec_id=2106273 flags=0x0000 ifindex=14  mac=DE:C8:5F:F4:7D:BB nodemac=6A:8D:BE:22:5A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:20.532Z",
  "value": "id=2432  sec_id=2106273 flags=0x0000 ifindex=12  mac=3A:BF:16:F3:57:97 nodemac=92:88:89:C2:95:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:20.533Z",
  "value": "id=3082  sec_id=2106273 flags=0x0000 ifindex=14  mac=DE:C8:5F:F4:7D:BB nodemac=6A:8D:BE:22:5A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:20.533Z",
  "value": "id=3912  sec_id=2106292 flags=0x0000 ifindex=18  mac=42:80:3D:8C:78:50 nodemac=6A:33:59:F3:0F:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:20.534Z",
  "value": "id=897   sec_id=4     flags=0x0000 ifindex=10  mac=D6:CB:C6:40:8C:39 nodemac=CA:58:95:33:C4:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:21.533Z",
  "value": "id=3082  sec_id=2106273 flags=0x0000 ifindex=14  mac=DE:C8:5F:F4:7D:BB nodemac=6A:8D:BE:22:5A:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:21.534Z",
  "value": "id=3912  sec_id=2106292 flags=0x0000 ifindex=18  mac=42:80:3D:8C:78:50 nodemac=6A:33:59:F3:0F:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:21.534Z",
  "value": "id=2432  sec_id=2106273 flags=0x0000 ifindex=12  mac=3A:BF:16:F3:57:97 nodemac=92:88:89:C2:95:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:21.534Z",
  "value": "id=897   sec_id=4     flags=0x0000 ifindex=10  mac=D6:CB:C6:40:8C:39 nodemac=CA:58:95:33:C4:4A"
}

