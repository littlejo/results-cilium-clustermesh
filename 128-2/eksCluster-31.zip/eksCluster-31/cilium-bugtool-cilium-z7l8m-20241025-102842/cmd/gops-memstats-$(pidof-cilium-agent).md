alloc: 72.38MB (75895392 bytes)
total-alloc: 1.39GB (1497708880 bytes)
sys: 210.63MB (220865876 bytes)
lookups: 0
mallocs: 48736560
frees: 48129648
heap-alloc: 72.38MB (75895392 bytes)
heap-sys: 163.69MB (171638784 bytes)
heap-idle: 40.79MB (42770432 bytes)
heap-in-use: 122.90MB (128868352 bytes)
heap-released: 3.00MB (3145728 bytes)
heap-objects: 606912
stack-in-use: 36.31MB (38076416 bytes)
stack-sys: 36.31MB (38076416 bytes)
stack-mspan-inuse: 2.14MB (2245600 bytes)
stack-mspan-sys: 2.68MB (2807040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 945.36KB (968049 bytes)
gc-sys: 5.11MB (5361920 bytes)
next-gc: when heap-alloc >= 143.27MB (150233880 bytes)
last-gc: 2024-10-25 10:28:33.596460439 +0000 UTC
gc-pause-total: 19.76907ms
gc-pause: 75604
gc-pause-end: 1729852113596460439
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.000427038942029293
enable-gc: true
debug-gc: false
