markdown output at /tmp/cilium-bugtool-20241025-102843.394+0000-UTC-1273535653/cmd/cilium-debuginfo-20241025-102844.239+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102843.394+0000-UTC-1273535653/cmd/cilium-debuginfo-20241025-102844.239+0000-UTC.json
