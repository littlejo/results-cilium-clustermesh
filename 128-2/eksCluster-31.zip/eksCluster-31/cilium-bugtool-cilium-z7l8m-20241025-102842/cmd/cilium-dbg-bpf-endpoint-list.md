IP ADDRESS         LOCAL ENDPOINT INFO
172.31.244.170:0   (localhost)                                                                                        
10.31.0.168:0      id=3912  sec_id=2106292 flags=0x0000 ifindex=18  mac=42:80:3D:8C:78:50 nodemac=6A:33:59:F3:0F:98   
10.31.0.199:0      (localhost)                                                                                        
10.31.0.171:0      id=3082  sec_id=2106273 flags=0x0000 ifindex=14  mac=DE:C8:5F:F4:7D:BB nodemac=6A:8D:BE:22:5A:66   
10.31.0.66:0       id=897   sec_id=4     flags=0x0000 ifindex=10  mac=D6:CB:C6:40:8C:39 nodemac=CA:58:95:33:C4:4A     
10.31.0.241:0      id=2432  sec_id=2106273 flags=0x0000 ifindex=12  mac=3A:BF:16:F3:57:97 nodemac=92:88:89:C2:95:F5   
172.31.247.172:0   (localhost)                                                                                        
