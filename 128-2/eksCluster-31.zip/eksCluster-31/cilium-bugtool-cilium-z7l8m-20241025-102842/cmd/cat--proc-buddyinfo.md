Node 0, zone      DMA    149     33     13     27      9      8      4      4      2      2    166 
Node 0, zone   Normal    283      5      8      0      4      3      0      4      2      2      8 
