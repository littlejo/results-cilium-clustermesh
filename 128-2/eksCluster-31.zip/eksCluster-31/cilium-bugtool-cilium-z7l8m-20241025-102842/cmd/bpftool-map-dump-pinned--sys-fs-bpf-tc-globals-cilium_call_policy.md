key: 81 03 00 00  value: 26 02 00 00
key: 80 09 00 00  value: 09 02 00 00
key: 0a 0c 00 00  value: 47 02 00 00
key: 48 0f 00 00  value: 80 02 00 00
Found 4 elements
