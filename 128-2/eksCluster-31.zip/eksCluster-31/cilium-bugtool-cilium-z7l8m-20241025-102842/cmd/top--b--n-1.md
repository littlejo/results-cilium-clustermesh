top - 10:28:43 up 15 min,  0 users,  load average: 0.20, 0.26, 0.35
Tasks:   6 total,   2 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 25.0 us, 32.1 sy,  0.0 ni, 39.3 id,  0.0 wa,  0.0 hi,  3.6 si,  0.0 st
MiB Mem :   3836.2 total,    770.4 free,    919.7 used,   2146.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2747.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538356 287844  77488 R  33.3   7.3   0:29.58 cilium-+
    593 root      20   0 1240432  16336  11356 S   6.7   0.4   0:00.03 cilium-+
    394 root      20   0 1228848   5756   2868 S   0.0   0.1   0:00.26 cilium-+
    620 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    643 root      20   0 1228744   3604   2912 S   0.0   0.1   0:00.00 gops
    649 root      20   0 1616264   8832   6328 S   0.0   0.2   0:00.00 runc:[2+
