Endpoint ID: 897
Path: /sys/fs/bpf/tc/globals/cilium_policy_00897

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    390832   4994      0        
Allow    Ingress     1          ANY          NONE         disabled    11488    135       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2432
Path: /sys/fs/bpf/tc/globals/cilium_policy_02432

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    76957   883       0        
Allow    Egress      0          ANY          NONE         disabled    14730   154       0        


Endpoint ID: 2929
Path: /sys/fs/bpf/tc/globals/cilium_policy_02929

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3082
Path: /sys/fs/bpf/tc/globals/cilium_policy_03082

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    76906   884       0        
Allow    Egress      0          ANY          NONE         disabled    13916   145       0        


Endpoint ID: 3912
Path: /sys/fs/bpf/tc/globals/cilium_policy_03912

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3226448   31891     0        
Allow    Ingress     1          ANY          NONE         disabled    3798887   37258     0        
Allow    Egress      0          ANY          NONE         disabled    4697711   44575     0        


