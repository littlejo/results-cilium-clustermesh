1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:b8:49:11:2e:4d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.247.172/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2695sec preferred_lft 2695sec
    inet6 fe80::8b8:49ff:fe11:2e4d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:b5:e8:23:3a:51 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.244.170/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8b5:e8ff:fe23:3a51/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:7c:c1:ef:9b:ba brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ac7c:c1ff:feef:9bba/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:61:a8:58:33:73 brd ff:ff:ff:ff:ff:ff
    inet 10.31.0.199/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::1861:a8ff:fe58:3373/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 06:f1:b6:9b:c3:af brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4f1:b6ff:fe9b:c3af/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:58:95:33:c4:4a brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c858:95ff:fe33:c44a/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc561ed43767ef@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:88:89:c2:95:f5 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::9088:89ff:fec2:95f5/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc3c76aea57fc2@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:8d:be:22:5a:66 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::688d:beff:fe22:5a66/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc04c65fad03b3@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:33:59:f3:0f:98 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::6833:59ff:fef3:f98/64 scope link 
       valid_lft forever preferred_lft forever
