USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         593  0.0  0.4 1240432 16336 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         608  0.0  0.0   6408  1640 ?        R    10:28   0:00  \_ ps auxfw
root           1  3.5  7.2 1538356 285176 ?      Ssl  10:14   0:29 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.0  0.1 1228848 5756 ?        Sl   10:15   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
