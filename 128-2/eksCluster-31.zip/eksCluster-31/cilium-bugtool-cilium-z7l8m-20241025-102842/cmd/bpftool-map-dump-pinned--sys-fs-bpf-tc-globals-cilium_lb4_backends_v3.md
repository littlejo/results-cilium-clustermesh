key: 08 00 00 00  value: 0a 1f 00 f1 00 35 00 00  00 00 00 00
key: 0a 00 00 00  value: 0a 1f 00 ab 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: ac 1f f7 ac 10 94 00 00  00 00 00 00
key: 0d 00 00 00  value: 0a 1f 00 a8 09 4b 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 1f 00 f1 23 c1 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 81 a5 01 bb 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 1f 00 ab 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f ff 69 01 bb 00 00  00 00 00 00
Found 8 elements
