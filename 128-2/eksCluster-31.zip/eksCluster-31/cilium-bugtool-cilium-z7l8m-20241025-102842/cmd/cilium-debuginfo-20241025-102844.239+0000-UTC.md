# Cilium debug information

#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.31.0.0/24, 
Allocated addresses:
  10.31.0.168 (kube-system/clustermesh-apiserver-6d59957dcd-75vsf)
  10.31.0.171 (kube-system/coredns-cc6ccd49c-2x4s9)
  10.31.0.199 (router)
  10.31.0.241 (kube-system/coredns-cc6ccd49c-hzjjb)
  10.31.0.66 (health)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m24s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 48b9bdce82fad2e7
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    39s ago        never        0       no error   
  ct-map-pressure                                                     11s ago        never        0       no error   
  daemon-validate-config                                              28s ago        never        0       no error   
  dns-garbage-collector-job                                           43s ago        never        0       no error   
  endpoint-2432-regeneration-recovery                                 never          never        0       no error   
  endpoint-2929-regeneration-recovery                                 never          never        0       no error   
  endpoint-3082-regeneration-recovery                                 never          never        0       no error   
  endpoint-3912-regeneration-recovery                                 never          never        0       no error   
  endpoint-897-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         3m43s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                11s ago        never        0       no error   
  ipcache-inject-labels                                               41s ago        never        0       no error   
  k8s-heartbeat                                                       14s ago        never        0       no error   
  link-cache                                                          11s ago        never        0       no error   
  local-identity-checkpoint                                           13m41s ago     never        0       no error   
  node-neighbor-link-updater                                          1s ago         never        0       no error   
  remote-etcd-cmesh1                                                  7m24s ago      never        0       no error   
  remote-etcd-cmesh10                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh100                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh101                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh102                                                7m24s ago      never        0       no error   
  remote-etcd-cmesh103                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh104                                                7m24s ago      never        0       no error   
  remote-etcd-cmesh105                                                7m24s ago      never        0       no error   
  remote-etcd-cmesh106                                                7m24s ago      never        0       no error   
  remote-etcd-cmesh107                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh108                                                7m24s ago      never        0       no error   
  remote-etcd-cmesh109                                                7m24s ago      never        0       no error   
  remote-etcd-cmesh11                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh110                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh111                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh112                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh113                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh114                                                7m24s ago      never        0       no error   
  remote-etcd-cmesh115                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh116                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh117                                                7m24s ago      never        0       no error   
  remote-etcd-cmesh118                                                7m24s ago      never        0       no error   
  remote-etcd-cmesh119                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh12                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh120                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh121                                                7m24s ago      never        0       no error   
  remote-etcd-cmesh122                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh123                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh124                                                7m24s ago      never        0       no error   
  remote-etcd-cmesh125                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh126                                                7m24s ago      never        0       no error   
  remote-etcd-cmesh127                                                7m24s ago      never        0       no error   
  remote-etcd-cmesh128                                                7m24s ago      never        0       no error   
  remote-etcd-cmesh13                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh14                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh15                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh16                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh17                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh18                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh19                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh2                                                  7m25s ago      never        0       no error   
  remote-etcd-cmesh20                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh21                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh22                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh23                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh24                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh25                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh26                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh27                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh28                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh29                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh3                                                  7m25s ago      never        0       no error   
  remote-etcd-cmesh30                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh31                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh33                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh34                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh35                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh36                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh37                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh38                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh39                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh4                                                  7m24s ago      never        0       no error   
  remote-etcd-cmesh40                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh41                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh42                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh43                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh44                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh45                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh46                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh47                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh48                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh49                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh5                                                  7m25s ago      never        0       no error   
  remote-etcd-cmesh50                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh51                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh52                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh53                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh54                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh55                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh56                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh57                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh58                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh59                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh6                                                  7m24s ago      never        0       no error   
  remote-etcd-cmesh60                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh61                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh62                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh63                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh64                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh65                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh66                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh67                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh68                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh69                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh7                                                  7m25s ago      never        0       no error   
  remote-etcd-cmesh70                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh71                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh72                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh73                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh74                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh75                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh76                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh77                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh78                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh79                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh8                                                  7m24s ago      never        0       no error   
  remote-etcd-cmesh80                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh81                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh82                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh83                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh84                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh85                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh86                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh87                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh88                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh89                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh9                                                  7m25s ago      never        0       no error   
  remote-etcd-cmesh90                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh91                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh92                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh93                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh94                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh95                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh96                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh97                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh98                                                 7m24s ago      never        0       no error   
  remote-etcd-cmesh99                                                 7m25s ago      never        0       no error   
  resolve-identity-2432                                               3m38s ago      never        0       no error   
  resolve-identity-2929                                               3m41s ago      never        0       no error   
  resolve-identity-3082                                               3m29s ago      never        0       no error   
  resolve-identity-3912                                               2m32s ago      never        0       no error   
  resolve-identity-897                                                3m40s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-6d59957dcd-75vsf   7m32s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-2x4s9                  13m29s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-hzjjb                  13m38s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      13m41s ago     never        0       no error   
  sync-policymap-2432                                                 13m36s ago     never        0       no error   
  sync-policymap-2929                                                 13m39s ago     never        0       no error   
  sync-policymap-3082                                                 13m29s ago     never        0       no error   
  sync-policymap-3912                                                 7m32s ago      never        0       no error   
  sync-policymap-897                                                  13m36s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (2432)                                   8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3082)                                   9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3912)                                   2s ago         never        0       no error   
  sync-utime                                                          41s ago        never        0       no error   
  write-cni-file                                                      13m43s ago     never        0       no error   
Proxy Status:            OK, ip 10.31.0.199, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 2097152, max 2162687
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 74.99   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
897        Disabled           Disabled          4          reserved:health                                                                     10.31.0.66    ready   
2432       Disabled           Disabled          2106273    k8s:eks.amazonaws.com/component=coredns                                             10.31.0.241   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh32                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
2929       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                
                                                           reserved:host                                                                                             
3082       Disabled           Disabled          2106273    k8s:eks.amazonaws.com/component=coredns                                             10.31.0.171   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh32                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
3912       Disabled           Disabled          2106292    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.31.0.168   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh32                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
```

#### BPF Policy Get 897

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    385866   4931      0        
Allow    Ingress     1          ANY          NONE         disabled    11488    135       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 897

```
Invalid argument: unknown type 897
```


#### Endpoint Get 897

```
[
  {
    "id": 897,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-897-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f858790f-4963-42a8-afc5-897d2f5c6e51"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-897",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:04.205Z",
            "success-count": 3
          },
          "uuid": "79189800-edf2-414b-a9c9-f893d38b2e0c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-897",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:08.190Z",
            "success-count": 1
          },
          "uuid": "2a8dc9da-8f3d-41d5-bf2d-62f45ca3d859"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:21Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.31.0.66",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "ca:58:95:33:c4:4a",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "d6:cb:c6:40:8c:39"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 897

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 897

```
Timestamp              Status   State                   Message
2024-10-25T10:21:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:21Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:08Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:06Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:15:05Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:04Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:04Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:03Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 2432

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    76957   883       0        
Allow    Egress      0          ANY          NONE         disabled    14730   154       0        

```


#### BPF CT List 2432

```
Invalid argument: unknown type 2432
```


#### Endpoint Get 2432

```
[
  {
    "id": 2432,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2432-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "6ef47404-3864-4b14-8499-ad74836d0e80"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2432",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:05.267Z",
            "success-count": 3
          },
          "uuid": "009c2efe-42d9-4020-a231-eff0335475a5"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-hzjjb",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:05.266Z",
            "success-count": 1
          },
          "uuid": "41a9c3fd-561d-4c68-84f1-f39e4eda1f8e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2432",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:08.192Z",
            "success-count": 1
          },
          "uuid": "100f7067-0936-4b44-b53e-495bd3ed841a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2432)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:45.347Z",
            "success-count": 84
          },
          "uuid": "6de2ecbd-9ee0-4920-a51b-d1457edd64bc"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "ae72915a43e3f4b918ad4c9250178d72e2d13736a6c639750a58a63a2de3fdee:eth0",
        "container-id": "ae72915a43e3f4b918ad4c9250178d72e2d13736a6c639750a58a63a2de3fdee",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-hzjjb",
        "pod-name": "kube-system/coredns-cc6ccd49c-hzjjb"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2106273,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh32",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh32",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:21Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.31.0.241",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "92:88:89:c2:95:f5",
        "interface-index": 12,
        "interface-name": "lxc561ed43767ef",
        "mac": "3a:bf:16:f3:57:97"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2106273,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2106273,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2432

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2432

```
Timestamp              Status    State                   Message
2024-10-25T10:21:21Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:21Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:21Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:21:21Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:20Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:20Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:20Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:20Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:19Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:19Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:19Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:19Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:18Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:18Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:18Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:18Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:53Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:08Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:08Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:06Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:06Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:15:05Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:05Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:05Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:15:05Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:05Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 2106273

```
ID        LABELS
2106273   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh32
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 2929

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2929

```
Invalid argument: unknown type 2929
```


#### Endpoint Get 2929

```
[
  {
    "id": 2929,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2929-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7ee6639d-d6f2-4429-b32f-86c37ac07e90"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2929",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:03.130Z",
            "success-count": 3
          },
          "uuid": "b965b299-82a5-4f71-a39f-186d3670b447"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2929",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:04.637Z",
            "success-count": 1
          },
          "uuid": "4c3c5bf5-66a8-40b4-9ff3-f0685cd98ed2"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:21Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "1a:61:a8:58:33:73",
        "interface-name": "cilium_host",
        "mac": "1a:61:a8:58:33:73"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2929

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2929

```
Timestamp              Status   State                   Message
2024-10-25T10:21:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:21Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:15:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:08Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:15:06Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:06Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:15:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:15:05Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:03Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:03Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:03Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 3082

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    76906   884       0        
Allow    Egress      0          ANY          NONE         disabled    13916   145       0        

```


#### BPF CT List 3082

```
Invalid argument: unknown type 3082
```


#### Endpoint Get 3082

```
[
  {
    "id": 3082,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3082-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "52c2704f-c4ed-433e-8cdf-9cb5aaa6e747"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3082",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:14.450Z",
            "success-count": 3
          },
          "uuid": "d6bc7343-bab4-42c3-8fb0-35252058232d"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-2x4s9",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:14.448Z",
            "success-count": 1
          },
          "uuid": "90bc8309-ef90-48fa-9368-39d47802c327"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3082",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:14.484Z",
            "success-count": 1
          },
          "uuid": "54465937-e137-4a2f-b4ce-274c0c498787"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3082)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:44.519Z",
            "success-count": 83
          },
          "uuid": "2cd117fb-12e6-4be9-9ea4-a068c5d312b4"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "7079d8ca9d4a6e2f88fa96ac1f558f62563452ed140250ef114db25eea74b3ff:eth0",
        "container-id": "7079d8ca9d4a6e2f88fa96ac1f558f62563452ed140250ef114db25eea74b3ff",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-2x4s9",
        "pod-name": "kube-system/coredns-cc6ccd49c-2x4s9"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2106273,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh32",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh32",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:21Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.31.0.171",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "6a:8d:be:22:5a:66",
        "interface-index": 14,
        "interface-name": "lxc3c76aea57fc2",
        "mac": "de:c8:5f:f4:7d:bb"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2106273,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2106273,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3082

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3082

```
Timestamp              Status   State                   Message
2024-10-25T10:21:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:21Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:14Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:14Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:14Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2106273

```
ID        LABELS
2106273   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh32
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 3912

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3175207   31527     0        
Allow    Ingress     1          ANY          NONE         disabled    3798887   37258     0        
Allow    Egress      0          ANY          NONE         disabled    4696375   44560     0        

```


#### BPF CT List 3912

```
Invalid argument: unknown type 3912
```


#### Endpoint Get 3912

```
[
  {
    "id": 3912,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3912-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "1afb8cec-f9ce-4318-98a7-e7ab2fbaff7a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3912",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:11.749Z",
            "success-count": 2
          },
          "uuid": "96c9f6b0-3e25-42ea-9ebc-02c6846eb2ae"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-6d59957dcd-75vsf",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:11.747Z",
            "success-count": 1
          },
          "uuid": "7a2ad6d8-f87a-46b7-a57a-0f19e67ca2b3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3912",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:11.791Z",
            "success-count": 1
          },
          "uuid": "65d06e35-e7fa-4f52-ae0d-c5441219fad3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3912)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:41.803Z",
            "success-count": 47
          },
          "uuid": "0a84966e-1c64-4208-abf1-5d2556853e95"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "bafd0a8a36311298910940016e77117b0d1cccbcb89b0488b3a01e75f6ac359b:eth0",
        "container-id": "bafd0a8a36311298910940016e77117b0d1cccbcb89b0488b3a01e75f6ac359b",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-6d59957dcd-75vsf",
        "pod-name": "kube-system/clustermesh-apiserver-6d59957dcd-75vsf"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2106292,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh32",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6d59957dcd"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh32",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:21Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.31.0.168",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "6a:33:59:f3:0f:98",
        "interface-index": 18,
        "interface-name": "lxc04c65fad03b3",
        "mac": "42:80:3d:8c:78:50"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2106292,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2106292,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3912

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3912

```
Timestamp              Status   State                   Message
2024-10-25T10:21:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:21Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:11Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:11Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:11Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2106292

```
ID        LABELS
2106292   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh32
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.129.165:443 (active)    
                                          2 => 172.31.255.105:443 (active)    
2    10.100.252.145:443    ClusterIP      1 => 172.31.247.172:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.31.0.241:53 (active)        
                                          2 => 10.31.0.171:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.31.0.241:9153 (active)      
                                          2 => 10.31.0.171:9153 (active)      
5    10.100.164.178:2379   ClusterIP      1 => 10.31.0.168:2379 (active)      
```

#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 33857382                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 33857382                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 33857382                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d400000 rw-p 00000000 00:00 0 
400d400000-4010000000 ---p 00000000 00:00 0 
ffff427ff000-ffff42a75000 rw-p 00000000 00:00 0 
ffff42a7d000-ffff42b9e000 rw-p 00000000 00:00 0 
ffff42b9e000-ffff42bdf000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff42bdf000-ffff42c20000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff42c20000-ffff42c22000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff42c22000-ffff42c24000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff42c24000-ffff431bb000 rw-p 00000000 00:00 0 
ffff431bb000-ffff432bb000 rw-p 00000000 00:00 0 
ffff432bb000-ffff432cc000 rw-p 00000000 00:00 0 
ffff432cc000-ffff452cc000 rw-p 00000000 00:00 0 
ffff452cc000-ffff4534c000 ---p 00000000 00:00 0 
ffff4534c000-ffff4534d000 rw-p 00000000 00:00 0 
ffff4534d000-ffff6534c000 ---p 00000000 00:00 0 
ffff6534c000-ffff6534d000 rw-p 00000000 00:00 0 
ffff6534d000-ffff852dc000 ---p 00000000 00:00 0 
ffff852dc000-ffff852dd000 rw-p 00000000 00:00 0 
ffff852dd000-ffff892ce000 ---p 00000000 00:00 0 
ffff892ce000-ffff892cf000 rw-p 00000000 00:00 0 
ffff892cf000-ffff89acc000 ---p 00000000 00:00 0 
ffff89acc000-ffff89acd000 rw-p 00000000 00:00 0 
ffff89acd000-ffff89bcc000 ---p 00000000 00:00 0 
ffff89bcc000-ffff89c2c000 rw-p 00000000 00:00 0 
ffff89c2c000-ffff89c2e000 r--p 00000000 00:00 0                          [vvar]
ffff89c2e000-ffff89c2f000 r-xp 00000000 00:00 0                          [vdso]
fffff4bc9000-fffff4bea000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.31.0.199": (string) (len=6) "router",
  (string) (len=10) "10.31.0.66": (string) (len=6) "health",
  (string) (len=11) "10.31.0.241": (string) (len=35) "kube-system/coredns-cc6ccd49c-hzjjb",
  (string) (len=11) "10.31.0.171": (string) (len=35) "kube-system/coredns-cc6ccd49c-2x4s9",
  (string) (len=11) "10.31.0.168": (string) (len=50) "kube-system/clustermesh-apiserver-6d59957dcd-75vsf"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.247.172": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001420f20)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001d121e0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001d121e0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40029ee4d0)(frontends:[10.100.164.178]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4001420790)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4001420840)(frontends:[10.100.252.145]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x40014209a0)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x40029ee420)(frontends:[]/ports=[kvmesh-metrics etcd-metrics apiserv-metrics]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x400157b3f8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-pk7bc": (*k8s.Endpoints)(0x4002ceb110)(10.31.0.171:53/TCP[eu-west-3b],10.31.0.171:53/UDP[eu-west-3b],10.31.0.171:9153/TCP[eu-west-3b],10.31.0.241:53/TCP[eu-west-3b],10.31.0.241:53/UDP[eu-west-3b],10.31.0.241:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x400193fa60)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-9pm7j": (*k8s.Endpoints)(0x40039bc8f0)(10.31.0.168:2379/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x400157b3d8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4002bfa8f0)(172.31.129.165:443/TCP,172.31.255.105:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x400157b3e8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-g8244": (*k8s.Endpoints)(0x4001fb0750)(172.31.247.172:4244/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x400160fc70)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40006495e0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4000467d40
  },
  gcTrigger: (chan struct {}) (cap=1) 0x40019618c0,
  gcExited: (chan struct {}) 0x4001961920,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001b5e200)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001053e48)({
      MetricVec: (*prometheus.MetricVec)(0x4001b6bad0)({
       metricMap: (*prometheus.metricMap)(0x4001b6bb00)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b8e000)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001b5e280)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001053e50)({
      MetricVec: (*prometheus.MetricVec)(0x4001b6bb60)({
       metricMap: (*prometheus.metricMap)(0x4001b6bb90)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b8e060)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001b5e300)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001053e58)({
      MetricVec: (*prometheus.MetricVec)(0x4001b6bbf0)({
       metricMap: (*prometheus.metricMap)(0x4001b6bc20)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b8e0c0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001b5e380)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001053e60)({
      MetricVec: (*prometheus.MetricVec)(0x4001b6bc80)({
       metricMap: (*prometheus.metricMap)(0x4001b6bcb0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b8e120)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001b5e400)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001053e68)({
      MetricVec: (*prometheus.MetricVec)(0x4001b6bd10)({
       metricMap: (*prometheus.metricMap)(0x4001b6bd40)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b8e180)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001b5e480)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001053e70)({
      MetricVec: (*prometheus.MetricVec)(0x4001b6bda0)({
       metricMap: (*prometheus.metricMap)(0x4001b6bdd0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b8e1e0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001b5e500)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001053e78)({
      MetricVec: (*prometheus.MetricVec)(0x4001b6be30)({
       metricMap: (*prometheus.metricMap)(0x4001b6be60)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b8e240)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001b5e580)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001053e80)({
      MetricVec: (*prometheus.MetricVec)(0x4001b6bec0)({
       metricMap: (*prometheus.metricMap)(0x4001b6bef0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b8e2a0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001b5e600)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001053e88)({
      MetricVec: (*prometheus.MetricVec)(0x4001b6bf50)({
       metricMap: (*prometheus.metricMap)(0x4001b92000)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b8e300)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x400160fc70)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x400150b1f0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001d080a8)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 377ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium environment keys

```
bpf-ct-global-tcp-max:524288
crd-wait-timeout:5m0s
bpf-filter-priority:1
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
enable-icmp-rules:true
ipsec-key-file:
version:false
gateway-api-secrets-namespace:
clustermesh-enable-mcs-api:false
http-retry-count:3
enable-envoy-config:false
kvstore-lease-ttl:15m0s
egress-gateway-policy-map-max:16384
hubble-event-queue-size:0
enable-node-port:false
kube-proxy-replacement-healthz-bind-address:
http-idle-timeout:0
enable-bpf-masquerade:false
mtu:0
bpf-nat-global-max:524288
k8s-require-ipv4-pod-cidr:false
disable-endpoint-crd:false
disable-envoy-version-check:false
enable-masquerade-to-route-source:false
enable-bbr:false
enable-gateway-api:false
lib-dir:/var/lib/cilium
local-max-addr-scope:252
enable-metrics:true
cluster-id:32
enable-ipv6-masquerade:true
proxy-gid:1337
kvstore:
hubble-drop-events-reasons:auth_required,policy_denied
enable-k8s:true
bpf-neigh-global-max:524288
enable-local-redirect-policy:false
bpf-fragments-map-max:8192
identity-allocation-mode:crd
hubble-export-allowlist:
use-full-tls-context:false
node-port-bind-protection:true
k8s-api-server:
enable-health-check-nodeport:true
mesh-auth-enabled:true
enable-stale-cilium-endpoint-cleanup:true
custom-cni-conf:false
exclude-local-address:
bpf-ct-timeout-service-tcp-grace:1m0s
enable-bandwidth-manager:false
node-port-acceleration:disabled
enable-srv6:false
kube-proxy-replacement:false
http-max-grpc-timeout:0
labels:
socket-path:/var/run/cilium/cilium.sock
set-cilium-node-taints:true
ip-masq-agent-config-path:/etc/config/ip-masq-agent
encrypt-interface:
bpf-lb-maglev-map-max:0
k8s-service-proxy-name:
ipam-cilium-node-update-rate:15s
read-cni-conf:
bpf-ct-timeout-regular-tcp-fin:10s
enable-k8s-api-discovery:false
label-prefix-file:
enable-xt-socket-fallback:true
node-port-algorithm:random
encryption-strict-mode-cidr:
http-request-timeout:3600
enable-ipsec-encrypted-overlay:false
proxy-portrange-min:10000
mesh-auth-queue-size:1024
vtep-cidr:
dnsproxy-lock-timeout:500ms
bpf-lb-dsr-dispatch:opt
hubble-listen-address::4244
enable-unreachable-routes:false
l2-announcements-renew-deadline:5s
enable-ipv4-masquerade:true
hubble-recorder-storage-path:/var/run/cilium/pcaps
k8s-service-cache-size:128
dnsproxy-insecure-skip-transparent-mode-check:false
dns-max-ips-per-restored-rule:1000
ipv4-range:auto
install-iptables-rules:true
iptables-lock-timeout:5s
mesh-auth-signal-backoff-duration:1s
enable-host-port:false
policy-queue-size:100
enable-recorder:false
ipsec-key-rotation-duration:5m0s
conntrack-gc-max-interval:0s
hubble-drop-events-interval:2m0s
certificates-directory:/var/run/cilium/certs
http-normalize-path:true
enable-active-connection-tracking:false
bpf-ct-timeout-regular-tcp:2h13m20s
bgp-announce-pod-cidr:false
bgp-config-path:/var/lib/cilium/bgp/config.yaml
proxy-connect-timeout:2
config-sources:config-map:kube-system/cilium-config
ipam:cluster-pool
identity-restore-grace-period:30s
encrypt-node:false
bpf-lb-sock-terminate-pod-connections:false
bpf-lb-external-clusterip:false
enable-k8s-networkpolicy:true
local-router-ipv6:
dnsproxy-concurrency-processing-grace-period:0s
node-port-range:
bpf-lb-acceleration:disabled
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
identity-heartbeat-timeout:30m0s
proxy-xff-num-trusted-hops-ingress:0
monitor-aggregation-flags:all
enable-wireguard:false
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
tunnel-protocol:vxlan
ipv6-native-routing-cidr:
unmanaged-pod-watcher-interval:15
monitor-aggregation-interval:5s
dnsproxy-lock-count:131
enable-cilium-api-server-access:
mesh-auth-mutual-listener-port:0
pprof:false
procfs:/host/proc
proxy-prometheus-port:0
bpf-ct-timeout-service-tcp:2h13m20s
endpoint-gc-interval:5m0s
l2-announcements-retry-period:2s
egress-gateway-reconciliation-trigger-interval:1s
ipv4-native-routing-cidr:
enable-auto-protect-node-port-range:true
k8s-client-qps:10
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
enable-bgp-control-plane:false
enable-ipsec-xfrm-state-caching:true
ipv6-cluster-alloc-cidr:f00d::/64
enable-route-mtu-for-cni-chaining:false
container-ip-local-reserved-ports:auto
srv6-encap-mode:reduced
identity-change-grace-period:5s
enable-l2-announcements:false
hubble-redact-http-headers-deny:
arping-refresh-period:30s
enable-tracing:false
ipv4-node:auto
enable-tcx:true
policy-cidr-match-mode:
ipv6-range:auto
routing-mode:tunnel
cgroup-root:/run/cilium/cgroupv2
envoy-config-timeout:2m0s
allow-localhost:auto
join-cluster:false
hubble-export-fieldmask:
monitor-queue-size:0
k8s-heartbeat-timeout:30s
bpf-events-policy-verdict-enabled:true
nat-map-stats-entries:32
metrics:
identity-gc-interval:15m0s
monitor-aggregation:medium
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
enable-cilium-endpoint-slice:false
enable-ipv6-ndp:false
state-dir:/var/run/cilium
dnsproxy-enable-transparent-mode:true
enable-custom-calls:false
hubble-redact-http-headers-allow:
bpf-ct-global-any-max:262144
vtep-mac:
ipv6-node:auto
hubble-monitor-events:
max-connected-clusters:255
force-device-detection:false
bpf-lb-map-max:65536
prometheus-serve-addr:
bpf-auth-map-max:524288
hubble-disable-tls:false
enable-nat46x64-gateway:false
enable-mke:false
enable-ipv4-fragment-tracking:true
enable-host-legacy-routing:false
clustermesh-sync-timeout:1m0s
egress-masquerade-interfaces:ens+
http-retry-timeout:0
cni-chaining-target:
tofqdns-proxy-response-max-delay:100ms
nodes-gc-interval:5m0s
enable-ipsec-key-watcher:true
vlan-bpf-bypass:
bpf-events-trace-enabled:true
enable-local-node-route:true
hubble-event-buffer-capacity:4095
exclude-node-label-patterns:
endpoint-queue-size:25
local-router-ipv4:
enable-cilium-health-api-server-access:
datapath-mode:veth
enable-encryption-strict-mode:false
hubble-prefer-ipv6:false
bpf-lb-algorithm:random
enable-external-ips:false
enable-identity-mark:true
proxy-max-connection-duration-seconds:0
k8s-client-burst:20
policy-accounting:true
enable-ip-masq-agent:false
enable-ipv4-big-tcp:false
envoy-secrets-namespace:
mesh-auth-spiffe-trust-domain:spiffe.cilium
max-controller-interval:0
enable-sctp:false
envoy-base-id:0
iptables-random-fully:false
bpf-lb-sock-hostns-only:false
agent-labels:
mesh-auth-spire-admin-socket:
kvstore-opt:
enable-ipv4:true
bpf-lb-service-map-max:0
cilium-endpoint-gc-interval:5m0s
tofqdns-endpoint-max-ip-per-hostname:50
prepend-iptables-chains:true
api-rate-limit:
bpf-events-drop-enabled:true
ipv6-service-range:auto
mesh-auth-rotated-identities-queue-size:1024
envoy-log:
hubble-export-file-max-size-mb:10
k8s-client-connection-timeout:30s
hubble-redact-enabled:false
fixed-identity-mapping:
enable-ipv4-egress-gateway:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
enable-host-firewall:false
policy-audit-mode:false
bpf-lb-rss-ipv6-src-cidr:
proxy-idle-timeout-seconds:60
use-cilium-internal-ip-for-ipsec:false
kvstore-connectivity-timeout:2m0s
enable-monitor:true
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
cluster-pool-ipv4-cidr:10.31.0.0/16
enable-ipip-termination:false
log-driver:
bpf-lb-mode:snat
mesh-auth-mutual-connect-timeout:5s
proxy-xff-num-trusted-hops-egress:0
hubble-socket-path:/var/run/cilium/hubble.sock
log-opt:
debug:false
cluster-health-port:4240
bpf-policy-map-max:16384
hubble-drop-events:false
enable-l2-neigh-discovery:true
set-cilium-is-up-condition:true
bpf-policy-map-full-reconciliation-interval:15m0s
bpf-node-map-max:16384
l2-announcements-lease-duration:15s
enable-vtep:false
tofqdns-enable-dns-compression:true
k8s-client-connection-keep-alive:30s
auto-direct-node-routes:false
direct-routing-skip-unreachable:false
envoy-keep-cap-netbindservice:false
clustermesh-ip-identities-sync-timeout:1m0s
enable-k8s-endpoint-slice:true
dns-policy-unload-on-shutdown:false
bpf-lb-dsr-l4-xlate:frontend
bpf-lb-maglev-table-size:16381
hubble-redact-http-urlquery:false
bpf-lb-service-backend-map-max:0
ipv4-service-loopback-address:169.254.42.1
hubble-flowlogs-config-path:
multicast-enabled:false
enable-ipv6-big-tcp:false
preallocate-bpf-maps:false
operator-prometheus-serve-addr::9963
dnsproxy-concurrency-limit:0
tofqdns-max-deferred-connection-deletes:10000
tofqdns-dns-reject-response-code:refused
agent-liveness-update-interval:1s
policy-trigger-interval:1s
enable-k8s-terminating-endpoint:true
enable-hubble-recorder-api:true
enable-endpoint-health-checking:true
cni-external-routing:false
trace-payloadlen:128
tofqdns-min-ttl:0
service-no-backend-response:reject
controller-group-metrics:
cni-log-file:/var/run/cilium/cilium-cni.log
enable-ipv6:false
proxy-portrange-max:20000
envoy-config-retry-interval:15s
cluster-pool-ipv4-mask-size:24
mesh-auth-gc-interval:5m0s
auto-create-cilium-node-resource:true
hubble-metrics:
fqdn-regex-compile-lru-size:1024
bpf-lb-rss-ipv4-src-cidr:
wireguard-persistent-keepalive:0s
disable-external-ip-mitigation:false
node-labels:
enable-hubble:true
hubble-redact-http-userinfo:true
bpf-lb-source-range-map-max:0
keep-config:false
bpf-lb-affinity-map-max:0
agent-health-port:9879
bpf-root:/sys/fs/bpf
hubble-export-file-compress:false
hubble-skip-unknown-cgroup-ids:true
pprof-port:6060
bpf-lb-rev-nat-map-max:0
cflags:
bpf-map-dynamic-size-ratio:0.0025
k8s-kubeconfig-path:
enable-l7-proxy:true
enable-svc-source-range-check:true
operator-api-serve-addr:127.0.0.1:9234
install-no-conntrack-iptables-rules:false
enable-high-scale-ipcache:false
enable-pmtu-discovery:false
annotate-k8s-node:false
kvstore-max-consecutive-quorum-errors:2
hubble-metrics-server:
ipam-default-ip-pool:default
hubble-export-denylist:
nodeport-addresses:
tofqdns-proxy-port:0
tofqdns-idle-connection-grace-period:0s
l2-pod-announcements-interface:
tunnel-port:0
enable-endpoint-routes:false
synchronize-k8s-nodes:true
endpoint-bpf-prog-watchdog-interval:30s
proxy-admin-port:0
allocator-list-timeout:3m0s
ipam-multi-pool-pre-allocation:
ipv4-service-range:auto
enable-ingress-controller:false
k8s-namespace:kube-system
enable-ipsec:false
bpf-ct-timeout-regular-tcp-syn:1m0s
enable-wireguard-userspace-fallback:false
enable-policy:default
cluster-name:cmesh32
log-system-load:false
vtep-endpoint:
config:
bpf-map-event-buffers:
enable-session-affinity:false
allow-icmp-frag-needed:true
vtep-mask:
hubble-export-file-max-backups:5
external-envoy-proxy:true
debug-verbose:
max-internal-timer-delay:0s
remove-cilium-node-taints:true
conntrack-gc-interval:0s
bpf-lb-sock:false
clustermesh-enable-endpoint-sync:false
hubble-export-file-path:
clustermesh-config:/var/lib/cilium/clustermesh/
bpf-ct-timeout-regular-any:1m0s
derive-masq-ip-addr-from-device:
ipv6-pod-subnets:
direct-routing-device:
k8s-require-ipv6-pod-cidr:false
enable-xdp-prefilter:false
k8s-sync-timeout:3m0s
mke-cgroup-mount:
devices:
hubble-recorder-sink-queue-size:1024
enable-bpf-tproxy:false
ipv4-pod-subnets:
enable-runtime-device-detection:true
disable-iptables-feeder-rules:
dnsproxy-socket-linger-timeout:10
ipv6-mcast-device:
enable-l2-pod-announcements:false
config-dir:/tmp/cilium/config-map
cni-exclusive:true
hubble-redact-kafka-apikey:false
pprof-address:localhost
node-port-mode:snat
enable-health-check-loadbalancer-ip:false
enable-bpf-clock-probe:false
bypass-ip-availability-upon-restore:false
kvstore-periodic-sync:5m0s
enable-well-known-identities:false
bpf-sock-rev-map-max:262144
egress-multi-home-ip-rule-compat:false
enable-health-checking:true
enable-service-topology:false
cni-chaining-mode:none
trace-sock:true
bgp-announce-lb-ip:false
route-metric:0
proxy-max-requests-per-connection:0
bpf-ct-timeout-service-any:1m0s
ingress-secrets-namespace:
encryption-strict-mode-allow-remote-node-identities:false
enable-node-selector-labels:false
cmdref:
nat-map-stats-interval:30s
gops-port:9890
static-cnp-path:
restore:true
tofqdns-pre-cache:
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
```

