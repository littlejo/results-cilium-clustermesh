ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.129.165:443 (active)    
                                          2 => 172.31.255.105:443 (active)    
2    10.100.252.145:443    ClusterIP      1 => 172.31.247.172:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.31.0.241:53 (active)        
                                          2 => 10.31.0.171:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.31.0.241:9153 (active)      
                                          2 => 10.31.0.171:9153 (active)      
5    10.100.164.178:2379   ClusterIP      1 => 10.31.0.168:2379 (active)      
