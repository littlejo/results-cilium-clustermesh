KEY             VALUE
AgentLiveness   918485889046
UTimeOffset     3378615638671875
