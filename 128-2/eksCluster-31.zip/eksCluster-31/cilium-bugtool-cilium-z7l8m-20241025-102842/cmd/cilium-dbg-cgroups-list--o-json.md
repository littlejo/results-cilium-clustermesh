[
  {
    "containers": [
      {
        "cgroup-id": 7530,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc2c687ef_0337_4adc_90ba_42cc168ed402.slice/cri-containerd-4af12c247d590c37f8076f86b0aff9eb14038879188d9a97523e23c9ff2329f2.scope"
      }
    ],
    "ips": [
      "10.31.0.241"
    ],
    "name": "coredns-cc6ccd49c-hzjjb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2ad66bb4_c066_43ed_8522_9310c96d8ad1.slice/cri-containerd-4c9f12ca3b4ac9b35e655f1b20073f608f13fddf8d688712ac370a6367d48ff5.scope"
      }
    ],
    "ips": [
      "10.31.0.171"
    ],
    "name": "coredns-cc6ccd49c-2x4s9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a5e0bfe_81fc_4372_b8bc_fb43c95fc2e1.slice/cri-containerd-fe8a968b1e630e18c23f24f0bb2ebc1b30ad69cdcdc8999d6d67a37a05c90cde.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a5e0bfe_81fc_4372_b8bc_fb43c95fc2e1.slice/cri-containerd-a42f9d2e1eada3625db8bd3ae35a691ea65b5609c2b1c311171c8afbd30a8ff5.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a5e0bfe_81fc_4372_b8bc_fb43c95fc2e1.slice/cri-containerd-504cb8c6782c073bf651d87a7c771a7cf26b7357afbe60849f6aeecab50d2345.scope"
      }
    ],
    "ips": [
      "10.31.0.168"
    ],
    "name": "clustermesh-apiserver-6d59957dcd-75vsf",
    "namespace": "kube-system"
  }
]

