CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc2c687ef_0337_4adc_90ba_42cc168ed402.slice/cri-containerd-4af12c247d590c37f8076f86b0aff9eb14038879188d9a97523e23c9ff2329f2.scope
    581      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc2c687ef_0337_4adc_90ba_42cc168ed402.slice/cri-containerd-ae72915a43e3f4b918ad4c9250178d72e2d13736a6c639750a58a63a2de3fdee.scope
    577      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2ad66bb4_c066_43ed_8522_9310c96d8ad1.slice/cri-containerd-7079d8ca9d4a6e2f88fa96ac1f558f62563452ed140250ef114db25eea74b3ff.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2ad66bb4_c066_43ed_8522_9310c96d8ad1.slice/cri-containerd-4c9f12ca3b4ac9b35e655f1b20073f608f13fddf8d688712ac370a6367d48ff5.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1e7a8f1d_9b92_4dec_a60b_b90233164723.slice/cri-containerd-876e696822862fff38d72380ce77d16def9a80ce198b3a2f5f1099a88470b227.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1e7a8f1d_9b92_4dec_a60b_b90233164723.slice/cri-containerd-d6a7fcbaa4b3b4bfa179fdfbf02b769f18b22b28eabbd4771a4ce1b31a3a067c.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod25dac75d_9a3f_459e_bca9_ea1f52a22b79.slice/cri-containerd-720719ceafbb45ba003ca492a8d66d8a150bdea81195b73ccbd6d8cb2c2019bb.scope
    67       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod25dac75d_9a3f_459e_bca9_ea1f52a22b79.slice/cri-containerd-48efe609d800ec441f852a48fb5b5b023f00ba463dc13eac0e40393d7948012d.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod373d7046_da9a_4f83_8b3b_fe032b8463d6.slice/cri-containerd-6a7cd21c2610313a1cdac9bb46a7e0b0e5236b454c4d42783e54624580fc277b.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod373d7046_da9a_4f83_8b3b_fe032b8463d6.slice/cri-containerd-127a6ab4808750a271095edb2344e7c15aadd9926a9900a4d31b4b42422cb5ce.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a5e0bfe_81fc_4372_b8bc_fb43c95fc2e1.slice/cri-containerd-504cb8c6782c073bf651d87a7c771a7cf26b7357afbe60849f6aeecab50d2345.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a5e0bfe_81fc_4372_b8bc_fb43c95fc2e1.slice/cri-containerd-a42f9d2e1eada3625db8bd3ae35a691ea65b5609c2b1c311171c8afbd30a8ff5.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a5e0bfe_81fc_4372_b8bc_fb43c95fc2e1.slice/cri-containerd-fe8a968b1e630e18c23f24f0bb2ebc1b30ad69cdcdc8999d6d67a37a05c90cde.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a5e0bfe_81fc_4372_b8bc_fb43c95fc2e1.slice/cri-containerd-bafd0a8a36311298910940016e77117b0d1cccbcb89b0488b3a01e75f6ac359b.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd54e1ee2_d0dd_48df_9a76_94a633342cab.slice/cri-containerd-d07c538835f6f377d153192f5ab5e4c370f6bc5c7199df2cde61abfc5e8e5602.scope
    71       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd54e1ee2_d0dd_48df_9a76_94a633342cab.slice/cri-containerd-4c98d2c6e20bc02d3a5ec289d24cf40d745a1677fa0d1a9c5ccd1ff6cc3c4bc1.scope
    91       cgroup_device   multi                                          
