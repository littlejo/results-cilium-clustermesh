[
  {
    "containers": [
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod97116044_44a0_4bd8_9ad0_503692b3c7c6.slice/cri-containerd-faffa0f496d577591eb1f16c1a578e46ced2e305412e6746ddb98cbb8d5ccda5.scope"
      },
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod97116044_44a0_4bd8_9ad0_503692b3c7c6.slice/cri-containerd-6382112da86fb6b21b09c779ef8623143b773ebab5f5bff22b46acca2301befc.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod97116044_44a0_4bd8_9ad0_503692b3c7c6.slice/cri-containerd-18d23d46d63e1533334fc49629c1ac90f3d1b3cb66d4830915e0832f1be54303.scope"
      }
    ],
    "ips": [
      "10.60.0.244"
    ],
    "name": "clustermesh-apiserver-77c47f9d8b-zv4dx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0809990d_4647_4dde_87ca_14a388597305.slice/cri-containerd-934cfa836889755389ea362b262c481df60a34a9aa68b94835511700d89233a8.scope"
      }
    ],
    "ips": [
      "10.60.0.236"
    ],
    "name": "coredns-cc6ccd49c-lz5hq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod352f20b0_92f4_4b4d_8452_0af88ed75d87.slice/cri-containerd-7407112b28da3ed5cb5a3b532f6eaf73f38b3f3644f6febbdf741f71e7f7e597.scope"
      }
    ],
    "ips": [
      "10.60.0.19"
    ],
    "name": "coredns-cc6ccd49c-w7nlp",
    "namespace": "kube-system"
  }
]

