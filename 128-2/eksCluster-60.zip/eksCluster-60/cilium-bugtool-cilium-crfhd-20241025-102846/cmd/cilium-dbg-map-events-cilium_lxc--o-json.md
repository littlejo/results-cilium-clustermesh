{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:30.493Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.143.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:30.493Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.184.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:30.493Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:35.218Z",
  "value": "id=1281  sec_id=4     flags=0x0000 ifindex=10  mac=DE:6B:FC:22:F5:A9 nodemac=FA:15:3A:E1:D8:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:35.220Z",
  "value": "id=438   sec_id=4034097 flags=0x0000 ifindex=12  mac=BA:16:55:69:70:CA nodemac=8A:27:82:86:62:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:35.306Z",
  "value": "id=3891  sec_id=4034097 flags=0x0000 ifindex=14  mac=5A:C6:26:DC:8D:FE nodemac=76:E8:DC:37:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:35.331Z",
  "value": "id=1281  sec_id=4     flags=0x0000 ifindex=10  mac=DE:6B:FC:22:F5:A9 nodemac=FA:15:3A:E1:D8:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:17.955Z",
  "value": "id=1281  sec_id=4     flags=0x0000 ifindex=10  mac=DE:6B:FC:22:F5:A9 nodemac=FA:15:3A:E1:D8:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:17.956Z",
  "value": "id=438   sec_id=4034097 flags=0x0000 ifindex=12  mac=BA:16:55:69:70:CA nodemac=8A:27:82:86:62:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:17.956Z",
  "value": "id=3891  sec_id=4034097 flags=0x0000 ifindex=14  mac=5A:C6:26:DC:8D:FE nodemac=76:E8:DC:37:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:17.989Z",
  "value": "id=3156  sec_id=4003608 flags=0x0000 ifindex=16  mac=AA:D2:B3:04:8D:3F nodemac=FA:AB:1F:4F:75:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:18.956Z",
  "value": "id=3156  sec_id=4003608 flags=0x0000 ifindex=16  mac=AA:D2:B3:04:8D:3F nodemac=FA:AB:1F:4F:75:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:18.956Z",
  "value": "id=3891  sec_id=4034097 flags=0x0000 ifindex=14  mac=5A:C6:26:DC:8D:FE nodemac=76:E8:DC:37:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:18.957Z",
  "value": "id=438   sec_id=4034097 flags=0x0000 ifindex=12  mac=BA:16:55:69:70:CA nodemac=8A:27:82:86:62:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:18.957Z",
  "value": "id=1281  sec_id=4     flags=0x0000 ifindex=10  mac=DE:6B:FC:22:F5:A9 nodemac=FA:15:3A:E1:D8:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:43.733Z",
  "value": "id=3621  sec_id=4003608 flags=0x0000 ifindex=18  mac=9A:63:49:3F:EE:76 nodemac=D2:0A:C8:F8:DA:73"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.60.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:54.061Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:06.870Z",
  "value": "id=3621  sec_id=4003608 flags=0x0000 ifindex=18  mac=9A:63:49:3F:EE:76 nodemac=D2:0A:C8:F8:DA:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:06.871Z",
  "value": "id=1281  sec_id=4     flags=0x0000 ifindex=10  mac=DE:6B:FC:22:F5:A9 nodemac=FA:15:3A:E1:D8:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:06.872Z",
  "value": "id=438   sec_id=4034097 flags=0x0000 ifindex=12  mac=BA:16:55:69:70:CA nodemac=8A:27:82:86:62:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:06.872Z",
  "value": "id=3891  sec_id=4034097 flags=0x0000 ifindex=14  mac=5A:C6:26:DC:8D:FE nodemac=76:E8:DC:37:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.870Z",
  "value": "id=1281  sec_id=4     flags=0x0000 ifindex=10  mac=DE:6B:FC:22:F5:A9 nodemac=FA:15:3A:E1:D8:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.871Z",
  "value": "id=3891  sec_id=4034097 flags=0x0000 ifindex=14  mac=5A:C6:26:DC:8D:FE nodemac=76:E8:DC:37:35:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.871Z",
  "value": "id=3621  sec_id=4003608 flags=0x0000 ifindex=18  mac=9A:63:49:3F:EE:76 nodemac=D2:0A:C8:F8:DA:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.871Z",
  "value": "id=438   sec_id=4034097 flags=0x0000 ifindex=12  mac=BA:16:55:69:70:CA nodemac=8A:27:82:86:62:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:08.871Z",
  "value": "id=3621  sec_id=4003608 flags=0x0000 ifindex=18  mac=9A:63:49:3F:EE:76 nodemac=D2:0A:C8:F8:DA:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:08.871Z",
  "value": "id=1281  sec_id=4     flags=0x0000 ifindex=10  mac=DE:6B:FC:22:F5:A9 nodemac=FA:15:3A:E1:D8:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:08.872Z",
  "value": "id=438   sec_id=4034097 flags=0x0000 ifindex=12  mac=BA:16:55:69:70:CA nodemac=8A:27:82:86:62:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.60.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:08.872Z",
  "value": "id=3891  sec_id=4034097 flags=0x0000 ifindex=14  mac=5A:C6:26:DC:8D:FE nodemac=76:E8:DC:37:35:26"
}

