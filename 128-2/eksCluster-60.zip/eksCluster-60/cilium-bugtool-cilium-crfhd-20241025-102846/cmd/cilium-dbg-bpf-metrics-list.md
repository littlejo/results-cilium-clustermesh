REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10337     807272     677    bpf_overlay.c
Interface                 INGRESS     227065    85881672   1132   bpf_host.c
Success                   EGRESS      10558     823414     53     encap.h
Success                   EGRESS      5361      411250     1694   bpf_host.c
Success                   EGRESS      95439     12632056   1308   bpf_lxc.c
Success                   INGRESS     107372    13183010   86     l3.h
Success                   INGRESS     112997    13622938   235    trace.h
Unsupported L3 protocol   EGRESS      35        2586       1492   bpf_lxc.c
