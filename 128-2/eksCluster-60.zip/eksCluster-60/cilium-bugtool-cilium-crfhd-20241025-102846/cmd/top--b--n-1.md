top - 10:28:48 up 14 min,  0 users,  load average: 0.02, 0.12, 0.13
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s):  3.4 us, 27.6 sy,  0.0 ni, 69.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    779.5 free,    914.2 used,   2142.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2752.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 277168  77320 S   6.7   7.1   0:24.81 cilium-+
    615 root      20   0 1240432  16424  11356 S   6.7   0.4   0:00.02 cilium-+
    394 root      20   0 1228848   7332   4036 S   0.0   0.2   0:00.27 cilium-+
    626 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    632 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    650 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    663 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    671 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    695 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    713 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
