CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0809990d_4647_4dde_87ca_14a388597305.slice/cri-containerd-934cfa836889755389ea362b262c481df60a34a9aa68b94835511700d89233a8.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0809990d_4647_4dde_87ca_14a388597305.slice/cri-containerd-43fc73d2b5289f5beb77bd9dee2ee6f7b31bec3ccb3047733f291e6963a7e79d.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod352f20b0_92f4_4b4d_8452_0af88ed75d87.slice/cri-containerd-95cd64ce3a85b112a5930c6a94f8b81068d35514a33eabb2a5506b073a6cbcdf.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod352f20b0_92f4_4b4d_8452_0af88ed75d87.slice/cri-containerd-7407112b28da3ed5cb5a3b532f6eaf73f38b3f3644f6febbdf741f71e7f7e597.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf2930f3e_4d27_4987_808b_7104a9521ada.slice/cri-containerd-14f6209291da185d7cf4949ae172488fc825f76f0e157c5a08ea96a4d1b1dcb2.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf2930f3e_4d27_4987_808b_7104a9521ada.slice/cri-containerd-2cb0832b5b67c1314972f83208dd16bc2a877ea357ea6c936c21099190c9ab01.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfe26f4aa_a443_457d_a224_ea8855402d7f.slice/cri-containerd-f65b9c2838d63ef4928e7cc08c72a22f26cfcc28d19dfffad442bf88f457dca7.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfe26f4aa_a443_457d_a224_ea8855402d7f.slice/cri-containerd-a6bce4b59253ee5e178105d11f2478f6182d48b60a191a3b841b30a5c58b3181.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd8fd2aa7_18df_4cab_8d1e_80a8d05f8a27.slice/cri-containerd-ad220d121068723f65d8666b37f336967b53851dd188965e32ed6dcba9e9f349.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd8fd2aa7_18df_4cab_8d1e_80a8d05f8a27.slice/cri-containerd-2834a493bd8782d2f31dd6af9b8033617f2481977d6d5e37e148e9d63a0eeb66.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7db237d1_0a8d_4cb8_b247_eb7507c40471.slice/cri-containerd-1a3c49563ca2354dd56a4ee5d8498c41a15d35b4425c6d9a0fdaec9c85777673.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7db237d1_0a8d_4cb8_b247_eb7507c40471.slice/cri-containerd-9d99d7d1ec799edd4a335d102cd03958379d2b3c9e74e030eb9775eb9450ee54.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod97116044_44a0_4bd8_9ad0_503692b3c7c6.slice/cri-containerd-faffa0f496d577591eb1f16c1a578e46ced2e305412e6746ddb98cbb8d5ccda5.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod97116044_44a0_4bd8_9ad0_503692b3c7c6.slice/cri-containerd-eda41c3a8042398d1efd31b2696a3bc5c859b3d5998a6008baaf1e358af77a61.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod97116044_44a0_4bd8_9ad0_503692b3c7c6.slice/cri-containerd-18d23d46d63e1533334fc49629c1ac90f3d1b3cb66d4830915e0832f1be54303.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod97116044_44a0_4bd8_9ad0_503692b3c7c6.slice/cri-containerd-6382112da86fb6b21b09c779ef8623143b773ebab5f5bff22b46acca2301befc.scope
    677      cgroup_device   multi                                          
