Node 0, zone      DMA     19     56      2     29     30     13      9      2      2      3    161 
Node 0, zone   Normal    194     46      2      3      2      1      8      3      1      2      8 
