IP ADDRESS         LOCAL ENDPOINT INFO
10.60.0.93:0       id=1281  sec_id=4     flags=0x0000 ifindex=10  mac=DE:6B:FC:22:F5:A9 nodemac=FA:15:3A:E1:D8:06     
10.60.0.24:0       (localhost)                                                                                        
10.60.0.19:0       id=438   sec_id=4034097 flags=0x0000 ifindex=12  mac=BA:16:55:69:70:CA nodemac=8A:27:82:86:62:B4   
172.31.184.13:0    (localhost)                                                                                        
10.60.0.244:0      id=3621  sec_id=4003608 flags=0x0000 ifindex=18  mac=9A:63:49:3F:EE:76 nodemac=D2:0A:C8:F8:DA:73   
10.60.0.236:0      id=3891  sec_id=4034097 flags=0x0000 ifindex=14  mac=5A:C6:26:DC:8D:FE nodemac=76:E8:DC:37:35:26   
172.31.143.223:0   (localhost)                                                                                        
