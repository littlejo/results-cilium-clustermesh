1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:0c:38:8c:99:1b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.184.13/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2731sec preferred_lft 2731sec
    inet6 fe80::40c:38ff:fe8c:991b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:37:d2:d9:b4:ab brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.143.223/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::437:d2ff:fed9:b4ab/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:bf:28:39:3d:c9 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b8bf:28ff:fe39:3dc9/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:8a:43:e0:a7:4d brd ff:ff:ff:ff:ff:ff
    inet 10.60.0.24/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::908a:43ff:fee0:a74d/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 86:da:bb:9f:f2:9a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::84da:bbff:fe9f:f29a/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:15:3a:e1:d8:06 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f815:3aff:fee1:d806/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcb31e800cf128@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:27:82:86:62:b4 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::8827:82ff:fe86:62b4/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc5aaa81dbf656@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:e8:dc:37:35:26 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::74e8:dcff:fe37:3526/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc9c9090460634@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:0a:c8:f8:da:73 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::d00a:c8ff:fef8:da73/64 scope link 
       valid_lft forever preferred_lft forever
