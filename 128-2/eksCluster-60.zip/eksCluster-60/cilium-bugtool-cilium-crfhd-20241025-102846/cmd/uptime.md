 10:28:48 up 14 min,  0 users,  load average: 0.02, 0.12, 0.13
