alloc: 90.13MB (94505264 bytes)
total-alloc: 1.36GB (1463916496 bytes)
sys: 214.38MB (224798036 bytes)
lookups: 0
mallocs: 48313669
frees: 47635742
heap-alloc: 90.13MB (94505264 bytes)
heap-sys: 169.33MB (177553408 bytes)
heap-idle: 41.56MB (43581440 bytes)
heap-in-use: 127.77MB (133971968 bytes)
heap-released: 5.91MB (6201344 bytes)
heap-objects: 677927
stack-in-use: 34.62MB (36306944 bytes)
stack-sys: 34.62MB (36306944 bytes)
stack-mspan-inuse: 1.98MB (2078240 bytes)
stack-mspan-sys: 2.55MB (2676480 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 814.69KB (834241 bytes)
gc-sys: 5.17MB (5421312 bytes)
next-gc: when heap-alloc >= 146.52MB (153640312 bytes)
last-gc: 2024-10-25 10:29:03.781553097 +0000 UTC
gc-pause-total: 15.1699ms
gc-pause: 61366
gc-pause-end: 1729852143781553097
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.0003946730403982915
enable-gc: true
debug-gc: false
