Endpoint ID: 438
Path: /sys/fs/bpf/tc/globals/cilium_policy_00438

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    76732   882       0        
Allow    Egress      0          ANY          NONE         disabled    14004   146       0        


Endpoint ID: 1281
Path: /sys/fs/bpf/tc/globals/cilium_policy_01281

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    443256   5666      0        
Allow    Ingress     1          ANY          NONE         disabled    10952    127       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2238
Path: /sys/fs/bpf/tc/globals/cilium_policy_02238

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3621
Path: /sys/fs/bpf/tc/globals/cilium_policy_03621

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3883463   36817     0        
Allow    Ingress     1          ANY          NONE         disabled    3352566   34085     0        
Allow    Egress      0          ANY          NONE         disabled    4976663   45829     0        


Endpoint ID: 3891
Path: /sys/fs/bpf/tc/globals/cilium_policy_03891

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    76759   880       0        
Allow    Egress      0          ANY          NONE         disabled    13593   141       0        


