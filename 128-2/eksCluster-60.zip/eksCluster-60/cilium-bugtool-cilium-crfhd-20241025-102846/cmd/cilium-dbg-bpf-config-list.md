KEY             VALUE
AgentLiveness   912055387692
UTimeOffset     3378615716796875
