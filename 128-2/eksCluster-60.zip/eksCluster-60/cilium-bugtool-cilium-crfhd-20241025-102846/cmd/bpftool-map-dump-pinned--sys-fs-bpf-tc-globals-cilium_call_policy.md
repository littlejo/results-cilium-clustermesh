key: b6 01 00 00  value: 0a 02 00 00
key: 01 05 00 00  value: 47 02 00 00
key: 25 0e 00 00  value: 89 02 00 00
key: 33 0f 00 00  value: 31 02 00 00
Found 4 elements
