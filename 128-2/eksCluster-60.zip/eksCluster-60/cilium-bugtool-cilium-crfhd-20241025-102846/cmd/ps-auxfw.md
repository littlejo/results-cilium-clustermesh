USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         671  0.0  0.2 1484936 8108 ?        Rsl  10:28   0:00 /usr/sbin/runc init
root         663  0.0  0.2 1616264 8808 ?        Ssl  10:28   0:00 /usr/sbin/runc init
root         650  0.0  0.1 1228744 4036 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         632  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root         626  0.0  0.0 1228744 3596 ?        Ssl  10:28   0:00 /bin/gops stack 1
root         615  0.0  0.4 1240432 16424 ?       Rsl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         669  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root           1  3.0  7.0 1538100 277168 ?      Ssl  10:15   0:24 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.0  0.1 1228848 7332 ?        Sl   10:15   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
