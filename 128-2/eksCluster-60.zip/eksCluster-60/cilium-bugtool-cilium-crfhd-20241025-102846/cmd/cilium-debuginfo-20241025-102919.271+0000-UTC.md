# Cilium debug information

#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.60.0.0/24, 
Allocated addresses:
  10.60.0.19 (kube-system/coredns-cc6ccd49c-w7nlp)
  10.60.0.236 (kube-system/coredns-cc6ccd49c-lz5hq)
  10.60.0.24 (router)
  10.60.0.244 (kube-system/clustermesh-apiserver-77c47f9d8b-zv4dx)
  10.60.0.93 (health)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d7896ddd45bd9c32
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    46s ago        never        0       no error   
  ct-map-pressure                                                     18s ago        never        0       no error   
  daemon-validate-config                                              35s ago        never        0       no error   
  dns-garbage-collector-job                                           51s ago        never        0       no error   
  endpoint-1281-regeneration-recovery                                 never          never        0       no error   
  endpoint-2238-regeneration-recovery                                 never          never        0       no error   
  endpoint-3621-regeneration-recovery                                 never          never        0       no error   
  endpoint-3891-regeneration-recovery                                 never          never        0       no error   
  endpoint-438-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         3m51s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                18s ago        never        0       no error   
  ipcache-inject-labels                                               48s ago        never        0       no error   
  k8s-heartbeat                                                       21s ago        never        0       no error   
  link-cache                                                          3s ago         never        0       no error   
  local-identity-checkpoint                                           13m48s ago     never        0       no error   
  node-neighbor-link-updater                                          8s ago         never        0       no error   
  remote-etcd-cmesh1                                                  7m12s ago      never        0       no error   
  remote-etcd-cmesh10                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh100                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh101                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh102                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh103                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh104                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh105                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh106                                                7m11s ago      never        0       no error   
  remote-etcd-cmesh107                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh108                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh109                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh11                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh110                                                7m11s ago      never        0       no error   
  remote-etcd-cmesh111                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh112                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh113                                                7m11s ago      never        0       no error   
  remote-etcd-cmesh114                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh115                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh116                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh117                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh118                                                7m11s ago      never        0       no error   
  remote-etcd-cmesh119                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh12                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh120                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh121                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh122                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh123                                                7m11s ago      never        0       no error   
  remote-etcd-cmesh124                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh125                                                7m11s ago      never        0       no error   
  remote-etcd-cmesh126                                                7m11s ago      never        0       no error   
  remote-etcd-cmesh127                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh128                                                7m12s ago      never        0       no error   
  remote-etcd-cmesh13                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh14                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh15                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh16                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh17                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh18                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh19                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh2                                                  7m12s ago      never        0       no error   
  remote-etcd-cmesh20                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh21                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh22                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh23                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh24                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh25                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh26                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh27                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh28                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh29                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh3                                                  7m11s ago      never        0       no error   
  remote-etcd-cmesh30                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh31                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh32                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh33                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh34                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh35                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh36                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh37                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh38                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh39                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh4                                                  7m11s ago      never        0       no error   
  remote-etcd-cmesh40                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh41                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh42                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh43                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh44                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh45                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh46                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh47                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh48                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh49                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh5                                                  7m12s ago      never        0       no error   
  remote-etcd-cmesh50                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh51                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh52                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh53                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh54                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh55                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh56                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh57                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh58                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh59                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh6                                                  7m11s ago      never        0       no error   
  remote-etcd-cmesh60                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh62                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh63                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh64                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh65                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh66                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh67                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh68                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh69                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh7                                                  7m12s ago      never        0       no error   
  remote-etcd-cmesh70                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh71                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh72                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh73                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh74                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh75                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh76                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh77                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh78                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh79                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh8                                                  7m12s ago      never        0       no error   
  remote-etcd-cmesh80                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh81                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh82                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh83                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh84                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh85                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh86                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh87                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh88                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh89                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh9                                                  7m12s ago      never        0       no error   
  remote-etcd-cmesh90                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh91                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh92                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh93                                                 7m12s ago      never        0       no error   
  remote-etcd-cmesh94                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh95                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh96                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh97                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh98                                                 7m11s ago      never        0       no error   
  remote-etcd-cmesh99                                                 7m12s ago      never        0       no error   
  resolve-identity-1281                                               3m47s ago      never        0       no error   
  resolve-identity-2238                                               3m48s ago      never        0       no error   
  resolve-identity-3621                                               2m35s ago      never        0       no error   
  resolve-identity-3891                                               3m47s ago      never        0       no error   
  resolve-identity-438                                                3m47s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-77c47f9d8b-zv4dx   7m35s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-lz5hq                  13m47s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-w7nlp                  13m47s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      13m48s ago     never        0       no error   
  sync-policymap-1281                                                 13m44s ago     never        0       no error   
  sync-policymap-2238                                                 13m47s ago     never        0       no error   
  sync-policymap-3621                                                 7m35s ago      never        0       no error   
  sync-policymap-3891                                                 13m43s ago     never        0       no error   
  sync-policymap-438                                                  13m44s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (3621)                                   5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3891)                                   7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (438)                                    7s ago         never        0       no error   
  sync-utime                                                          48s ago        never        0       no error   
  write-cni-file                                                      13m51s ago     never        0       no error   
Proxy Status:            OK, ip 10.60.0.24, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 3997696, max 4063231
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 79.90   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 33635245                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 33635245                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 33635245                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d400000 rw-p 00000000 00:00 0 
400d400000-4010000000 ---p 00000000 00:00 0 
ffff49075000-ffff4927a000 rw-p 00000000 00:00 0 
ffff49281000-ffff493a3000 rw-p 00000000 00:00 0 
ffff493a3000-ffff493e4000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff493e4000-ffff49425000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff49425000-ffff49427000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff49427000-ffff49429000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff49429000-ffff499f0000 rw-p 00000000 00:00 0 
ffff499f0000-ffff49af0000 rw-p 00000000 00:00 0 
ffff49af0000-ffff49b01000 rw-p 00000000 00:00 0 
ffff49b01000-ffff4bb01000 rw-p 00000000 00:00 0 
ffff4bb01000-ffff4bb81000 ---p 00000000 00:00 0 
ffff4bb81000-ffff4bb82000 rw-p 00000000 00:00 0 
ffff4bb82000-ffff6bb81000 ---p 00000000 00:00 0 
ffff6bb81000-ffff6bb82000 rw-p 00000000 00:00 0 
ffff6bb82000-ffff8bb11000 ---p 00000000 00:00 0 
ffff8bb11000-ffff8bb12000 rw-p 00000000 00:00 0 
ffff8bb12000-ffff8fb03000 ---p 00000000 00:00 0 
ffff8fb03000-ffff8fb04000 rw-p 00000000 00:00 0 
ffff8fb04000-ffff90301000 ---p 00000000 00:00 0 
ffff90301000-ffff90302000 rw-p 00000000 00:00 0 
ffff90302000-ffff90401000 ---p 00000000 00:00 0 
ffff90401000-ffff90461000 rw-p 00000000 00:00 0 
ffff90461000-ffff90463000 r--p 00000000 00:00 0                          [vvar]
ffff90463000-ffff90464000 r-xp 00000000 00:00 0                          [vdso]
ffffd77d5000-ffffd77f6000 rw-p 00000000 00:00 0                          [stack]

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.60.0.244": (string) (len=50) "kube-system/clustermesh-apiserver-77c47f9d8b-zv4dx",
  (string) (len=10) "10.60.0.24": (string) (len=6) "router",
  (string) (len=10) "10.60.0.93": (string) (len=6) "health",
  (string) (len=10) "10.60.0.19": (string) (len=35) "kube-system/coredns-cc6ccd49c-w7nlp",
  (string) (len=11) "10.60.0.236": (string) (len=35) "kube-system/coredns-cc6ccd49c-lz5hq"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.184.13": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4002369550)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001bc7020,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001bc7020,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4001a25a20)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4001a25ad0)(frontends:[10.100.3.205]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4001a25c30)(frontends:[10.100.0.10]/ports=[metrics dns dns-tcp]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4001a24210)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4001a242c0)(frontends:[10.100.70.24]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4000233eb8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4001f0a4e0)(172.31.148.229:443/TCP,172.31.201.189:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4000233ec0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-lcl6d": (*k8s.Endpoints)(0x40023d2dd0)(172.31.184.13:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4000233ec8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-kqnt5": (*k8s.Endpoints)(0x40038cf450)(10.60.0.19:53/TCP[eu-west-3a],10.60.0.19:53/UDP[eu-west-3a],10.60.0.19:9153/TCP[eu-west-3a],10.60.0.236:53/TCP[eu-west-3a],10.60.0.236:53/UDP[eu-west-3a],10.60.0.236:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40017f4bd8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-q5wmp": (*k8s.Endpoints)(0x4002863450)(10.60.0.244:2379/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4000ff2540)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4000c4b0e0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x40023fb950
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4001ad8420,
  gcExited: (chan struct {}) 0x4001ad8540,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4000c29d80)({
     ObserverVec: (*prometheus.HistogramVec)(0x400195d740)({
      MetricVec: (*prometheus.MetricVec)(0x40015fca20)({
       metricMap: (*prometheus.metricMap)(0x40015fca50)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001ef0360)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4000c29e00)({
     ObserverVec: (*prometheus.HistogramVec)(0x400195d748)({
      MetricVec: (*prometheus.MetricVec)(0x40015fcab0)({
       metricMap: (*prometheus.metricMap)(0x40015fcae0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001ef03c0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4000c29e80)({
     GaugeVec: (*prometheus.GaugeVec)(0x400195d750)({
      MetricVec: (*prometheus.MetricVec)(0x40015fcb40)({
       metricMap: (*prometheus.metricMap)(0x40015fcb70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001ef0420)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4000c29f00)({
     GaugeVec: (*prometheus.GaugeVec)(0x400195d758)({
      MetricVec: (*prometheus.MetricVec)(0x40015fcbd0)({
       metricMap: (*prometheus.metricMap)(0x40015fcc00)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001ef0480)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x400161a000)({
     GaugeVec: (*prometheus.GaugeVec)(0x400195d760)({
      MetricVec: (*prometheus.MetricVec)(0x40015fcc60)({
       metricMap: (*prometheus.metricMap)(0x40015fcc90)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001ef04e0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x400161a080)({
     GaugeVec: (*prometheus.GaugeVec)(0x400195d768)({
      MetricVec: (*prometheus.MetricVec)(0x40015fccf0)({
       metricMap: (*prometheus.metricMap)(0x40015fcd20)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001ef0540)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x400161a100)({
     GaugeVec: (*prometheus.GaugeVec)(0x400195d770)({
      MetricVec: (*prometheus.MetricVec)(0x40015fcd80)({
       metricMap: (*prometheus.metricMap)(0x40015fcdb0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001ef05a0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x400161a180)({
     GaugeVec: (*prometheus.GaugeVec)(0x400195d778)({
      MetricVec: (*prometheus.MetricVec)(0x40015fce10)({
       metricMap: (*prometheus.metricMap)(0x40015fce40)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001ef0600)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x400161a200)({
     ObserverVec: (*prometheus.HistogramVec)(0x400195d780)({
      MetricVec: (*prometheus.MetricVec)(0x40015fcea0)({
       metricMap: (*prometheus.metricMap)(0x40015fced0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001ef0660)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4000ff2540)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4000ff36c0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x40016aecc0)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 525ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5
  }
 })
})

```


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium environment keys

```
cmdref:
k8s-kubeconfig-path:
proxy-prometheus-port:0
nodes-gc-interval:5m0s
tofqdns-endpoint-max-ip-per-hostname:50
enable-runtime-device-detection:true
clustermesh-ip-identities-sync-timeout:1m0s
bpf-events-policy-verdict-enabled:true
procfs:/host/proc
bpf-map-event-buffers:
enable-cilium-health-api-server-access:
hubble-redact-enabled:false
enable-high-scale-ipcache:false
hubble-export-file-max-backups:5
hubble-drop-events-reasons:auth_required,policy_denied
bpf-lb-service-map-max:0
routing-mode:tunnel
hubble-monitor-events:
encryption-strict-mode-allow-remote-node-identities:false
http-max-grpc-timeout:0
hubble-prefer-ipv6:false
allocator-list-timeout:3m0s
enable-service-topology:false
bgp-config-path:/var/lib/cilium/bgp/config.yaml
mesh-auth-gc-interval:5m0s
kvstore-max-consecutive-quorum-errors:2
unmanaged-pod-watcher-interval:15
ipv6-cluster-alloc-cidr:f00d::/64
proxy-xff-num-trusted-hops-ingress:0
datapath-mode:veth
disable-external-ip-mitigation:false
proxy-connect-timeout:2
state-dir:/var/run/cilium
bpf-root:/sys/fs/bpf
policy-accounting:true
config-dir:/tmp/cilium/config-map
iptables-random-fully:false
enable-xt-socket-fallback:true
enable-tcx:true
trace-sock:true
http-normalize-path:true
identity-change-grace-period:5s
vtep-cidr:
ipv4-pod-subnets:
clustermesh-config:/var/lib/cilium/clustermesh/
bpf-events-trace-enabled:true
enable-ipv6-masquerade:true
bpf-lb-dsr-l4-xlate:frontend
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
hubble-recorder-storage-path:/var/run/cilium/pcaps
cni-log-file:/var/run/cilium/cilium-cni.log
bpf-lb-maglev-table-size:16381
l2-announcements-renew-deadline:5s
hubble-disable-tls:false
ipam-cilium-node-update-rate:15s
hubble-redact-http-userinfo:true
mesh-auth-mutual-listener-port:0
ipv6-pod-subnets:
ipsec-key-rotation-duration:5m0s
ipam-default-ip-pool:default
enable-identity-mark:true
tunnel-port:0
debug-verbose:
mesh-auth-enabled:true
envoy-keep-cap-netbindservice:false
enable-l2-announcements:false
envoy-log:
tofqdns-max-deferred-connection-deletes:10000
kvstore-lease-ttl:15m0s
enable-cilium-api-server-access:
enable-cilium-endpoint-slice:false
bpf-lb-rss-ipv6-src-cidr:
bpf-auth-map-max:524288
hubble-drop-events:false
vtep-endpoint:
l2-pod-announcements-interface:
bpf-lb-external-clusterip:false
endpoint-gc-interval:5m0s
enable-k8s-networkpolicy:true
k8s-api-server:
policy-audit-mode:false
mesh-auth-spire-admin-socket:
pprof-address:localhost
kvstore-connectivity-timeout:2m0s
agent-health-port:9879
enable-ipv4-fragment-tracking:true
k8s-client-connection-timeout:30s
vtep-mac:
endpoint-queue-size:25
ipv4-range:auto
ipam:cluster-pool
envoy-base-id:0
gops-port:9890
remove-cilium-node-taints:true
enable-ip-masq-agent:false
derive-masq-ip-addr-from-device:
tofqdns-proxy-port:0
enable-ipv6:false
bpf-lb-dsr-dispatch:opt
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
enable-custom-calls:false
conntrack-gc-interval:0s
enable-vtep:false
enable-bpf-clock-probe:false
route-metric:0
enable-hubble-recorder-api:true
monitor-queue-size:0
hubble-export-file-compress:false
restore:true
enable-icmp-rules:true
enable-l2-neigh-discovery:true
k8s-namespace:kube-system
hubble-export-file-max-size-mb:10
hubble-export-file-path:
container-ip-local-reserved-ports:auto
bpf-ct-timeout-regular-any:1m0s
node-port-range:
bpf-lb-source-range-map-max:0
crd-wait-timeout:5m0s
bpf-fragments-map-max:8192
enable-svc-source-range-check:true
bgp-announce-pod-cidr:false
proxy-admin-port:0
operator-api-serve-addr:127.0.0.1:9234
envoy-config-timeout:2m0s
bpf-lb-service-backend-map-max:0
vtep-mask:
hubble-drop-events-interval:2m0s
metrics:
egress-gateway-reconciliation-trigger-interval:1s
k8s-client-connection-keep-alive:30s
enable-node-selector-labels:false
tofqdns-proxy-response-max-delay:100ms
label-prefix-file:
tofqdns-idle-connection-grace-period:0s
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
bpf-ct-timeout-service-tcp:2h13m20s
tofqdns-enable-dns-compression:true
exclude-local-address:
bpf-lb-affinity-map-max:0
dnsproxy-enable-transparent-mode:true
identity-gc-interval:15m0s
enable-host-firewall:false
local-max-addr-scope:252
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
enable-ipv4-big-tcp:false
cni-chaining-mode:none
hubble-metrics:
cluster-pool-ipv4-mask-size:24
proxy-idle-timeout-seconds:60
http-retry-count:3
dns-policy-unload-on-shutdown:false
enable-hubble:true
trace-payloadlen:128
hubble-redact-http-headers-allow:
gateway-api-secrets-namespace:
bypass-ip-availability-upon-restore:false
ipv4-service-loopback-address:169.254.42.1
k8s-service-cache-size:128
k8s-require-ipv4-pod-cidr:false
devices:
vlan-bpf-bypass:
envoy-secrets-namespace:
policy-cidr-match-mode:
prometheus-serve-addr:
bpf-lb-sock-hostns-only:false
egress-multi-home-ip-rule-compat:false
max-controller-interval:0
bpf-nat-global-max:524288
mesh-auth-mutual-connect-timeout:5s
hubble-export-denylist:
version:false
bpf-policy-map-full-reconciliation-interval:15m0s
node-labels:
envoy-config-retry-interval:15s
ipv4-node:auto
multicast-enabled:false
direct-routing-skip-unreachable:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
hubble-export-allowlist:
identity-restore-grace-period:30s
http-retry-timeout:0
enable-stale-cilium-endpoint-cleanup:true
direct-routing-device:
bpf-lb-acceleration:disabled
external-envoy-proxy:true
bpf-ct-global-any-max:262144
dnsproxy-concurrency-processing-grace-period:0s
enable-health-checking:true
dnsproxy-lock-timeout:500ms
bpf-lb-rev-nat-map-max:0
install-iptables-rules:true
kvstore-opt:
hubble-listen-address::4244
dnsproxy-socket-linger-timeout:10
exclude-node-label-patterns:
dnsproxy-lock-count:131
enable-metrics:true
ipv6-range:auto
static-cnp-path:
enable-session-affinity:false
bpf-lb-map-max:65536
cflags:
bpf-ct-timeout-service-tcp-grace:1m0s
enable-k8s-endpoint-slice:true
wireguard-persistent-keepalive:0s
socket-path:/var/run/cilium/cilium.sock
node-port-mode:snat
enable-active-connection-tracking:false
hubble-redact-http-headers-deny:
enable-bpf-tproxy:false
hubble-flowlogs-config-path:
agent-liveness-update-interval:1s
hubble-skip-unknown-cgroup-ids:true
local-router-ipv4:
bpf-neigh-global-max:524288
pprof-port:6060
enable-unreachable-routes:false
enable-ingress-controller:false
max-internal-timer-delay:0s
arping-refresh-period:30s
lib-dir:/var/lib/cilium
ipv6-service-range:auto
hubble-redact-http-urlquery:false
install-no-conntrack-iptables-rules:false
cluster-health-port:4240
monitor-aggregation-interval:5s
bpf-ct-global-tcp-max:524288
enable-wireguard:false
monitor-aggregation:medium
hubble-metrics-server:
encrypt-interface:
ipv6-mcast-device:
enable-k8s-api-discovery:false
dnsproxy-concurrency-limit:0
encrypt-node:false
http-request-timeout:3600
enable-well-known-identities:false
enable-ipsec-encrypted-overlay:false
set-cilium-node-taints:true
enable-health-check-nodeport:true
enable-bbr:false
bpf-map-dynamic-size-ratio:0.0025
fixed-identity-mapping:
enable-ipip-termination:false
nat-map-stats-interval:30s
endpoint-bpf-prog-watchdog-interval:30s
disable-iptables-feeder-rules:
ipv4-service-range:auto
bpf-events-drop-enabled:true
allow-localhost:auto
enable-l2-pod-announcements:false
kvstore-periodic-sync:5m0s
max-connected-clusters:255
node-port-acceleration:disabled
ingress-secrets-namespace:
mtu:0
dns-max-ips-per-restored-rule:1000
mesh-auth-rotated-identities-queue-size:1024
hubble-event-queue-size:0
config-sources:config-map:kube-system/cilium-config
local-router-ipv6:
hubble-recorder-sink-queue-size:1024
enable-ipsec-xfrm-state-caching:true
bpf-filter-priority:1
certificates-directory:/var/run/cilium/certs
bpf-ct-timeout-regular-tcp:2h13m20s
cni-chaining-target:
enable-host-port:false
k8s-service-proxy-name:
ipv4-native-routing-cidr:
set-cilium-is-up-condition:true
node-port-bind-protection:true
enable-ipv4-egress-gateway:false
clustermesh-sync-timeout:1m0s
enable-endpoint-health-checking:true
bpf-ct-timeout-regular-tcp-syn:1m0s
cluster-pool-ipv4-cidr:10.60.0.0/16
agent-labels:
bpf-lb-sock-terminate-pod-connections:false
k8s-sync-timeout:3m0s
enable-local-redirect-policy:false
identity-heartbeat-timeout:30m0s
cgroup-root:/run/cilium/cgroupv2
enable-ipv4:true
enable-envoy-config:false
tofqdns-min-ttl:0
bpf-ct-timeout-service-any:1m0s
enable-ipv6-ndp:false
labels:
ipv6-native-routing-cidr:
enable-wireguard-userspace-fallback:false
identity-allocation-mode:crd
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
bpf-lb-maglev-map-max:0
cluster-id:61
controller-group-metrics:
l2-announcements-lease-duration:15s
egress-gateway-policy-map-max:16384
enable-sctp:false
clustermesh-enable-mcs-api:false
enable-monitor:true
ip-masq-agent-config-path:/etc/config/ip-masq-agent
mesh-auth-spiffe-trust-domain:spiffe.cilium
bpf-node-map-max:16384
policy-queue-size:100
mesh-auth-signal-backoff-duration:1s
node-port-algorithm:random
k8s-require-ipv6-pod-cidr:false
use-full-tls-context:false
enable-pmtu-discovery:false
enable-encryption-strict-mode:false
proxy-xff-num-trusted-hops-egress:0
enable-policy:default
read-cni-conf:
nodeport-addresses:
conntrack-gc-max-interval:0s
enable-bandwidth-manager:false
policy-trigger-interval:1s
mke-cgroup-mount:
srv6-encap-mode:reduced
bpf-policy-map-max:16384
enable-ipsec:false
join-cluster:false
allow-icmp-frag-needed:true
disable-envoy-version-check:false
hubble-export-fieldmask:
hubble-redact-kafka-apikey:false
bpf-lb-algorithm:random
enable-health-check-loadbalancer-ip:false
enable-tracing:false
monitor-aggregation-flags:all
k8s-client-qps:10
enable-bpf-masquerade:false
nat-map-stats-entries:32
service-no-backend-response:reject
enable-nat46x64-gateway:false
hubble-socket-path:/var/run/cilium/hubble.sock
bgp-announce-lb-ip:false
cluster-name:cmesh61
log-driver:
cni-exclusive:true
enable-xdp-prefilter:false
ipv6-node:auto
iptables-lock-timeout:5s
enable-ipsec-key-watcher:true
kube-proxy-replacement-healthz-bind-address:
enable-ipv4-masquerade:true
proxy-portrange-max:20000
ipam-multi-pool-pre-allocation:
disable-endpoint-crd:false
enable-local-node-route:true
enable-auto-protect-node-port-range:true
ipsec-key-file:
prepend-iptables-chains:true
keep-config:false
egress-masquerade-interfaces:ens+
preallocate-bpf-maps:false
proxy-gid:1337
enable-k8s-terminating-endpoint:true
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
kvstore:
enable-external-ips:false
pprof:false
api-rate-limit:
enable-recorder:false
bpf-lb-sock:false
dnsproxy-insecure-skip-transparent-mode-check:false
custom-cni-conf:false
bpf-sock-rev-map-max:262144
mesh-auth-queue-size:1024
enable-route-mtu-for-cni-chaining:false
tunnel-protocol:vxlan
clustermesh-enable-endpoint-sync:false
enable-ipv6-big-tcp:false
enable-mke:false
kube-proxy-replacement:false
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
log-opt:
encryption-strict-mode-cidr:
enable-gateway-api:false
proxy-max-connection-duration-seconds:0
enable-host-legacy-routing:false
tofqdns-dns-reject-response-code:refused
tofqdns-pre-cache:
bpf-lb-rss-ipv4-src-cidr:
enable-masquerade-to-route-source:false
k8s-heartbeat-timeout:30s
use-cilium-internal-ip-for-ipsec:false
annotate-k8s-node:false
enable-l7-proxy:true
l2-announcements-retry-period:2s
bpf-lb-mode:snat
log-system-load:false
proxy-portrange-min:10000
config:
http-idle-timeout:0
auto-direct-node-routes:false
enable-srv6:false
k8s-client-burst:20
force-device-detection:false
cni-external-routing:false
enable-endpoint-routes:false
cilium-endpoint-gc-interval:5m0s
enable-bgp-control-plane:false
bpf-ct-timeout-regular-tcp-fin:10s
enable-k8s:true
auto-create-cilium-node-resource:true
fqdn-regex-compile-lru-size:1024
operator-prometheus-serve-addr::9963
debug:false
hubble-event-buffer-capacity:4095
enable-node-port:false
synchronize-k8s-nodes:true
proxy-max-requests-per-connection:0
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
438        Disabled           Disabled          4034097    k8s:eks.amazonaws.com/component=coredns                                             10.60.0.19    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh61                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
1281       Disabled           Disabled          4          reserved:health                                                                     10.60.0.93    ready   
2238       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                
                                                           reserved:host                                                                                             
3621       Disabled           Disabled          4003608    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.60.0.244   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh61                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
3891       Disabled           Disabled          4034097    k8s:eks.amazonaws.com/component=coredns                                             10.60.0.236   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh61                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
```

#### BPF Policy Get 438

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    76732   882       0        
Allow    Egress      0          ANY          NONE         disabled    14004   146       0        

```


#### BPF CT List 438

```
Invalid argument: unknown type 438
```


#### Endpoint Get 438

```
[
  {
    "id": 438,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-438-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "509151c2-ff61-40a5-aeb8-abf92f1f6df0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-438",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:31.962Z",
            "success-count": 3
          },
          "uuid": "adbea8f0-e3e8-4148-9c31-51ab18bd2485"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-w7nlp",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:31.960Z",
            "success-count": 1
          },
          "uuid": "31acdbe5-6039-48ec-8155-56732f6cf09d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-438",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:35.226Z",
            "success-count": 1
          },
          "uuid": "e1f68055-9f0f-462a-81bd-70f190619658"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (438)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:12.038Z",
            "success-count": 84
          },
          "uuid": "6ccb86a3-0b73-4331-bfc3-917124ea1cb8"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "95cd64ce3a85b112a5930c6a94f8b81068d35514a33eabb2a5506b073a6cbcdf:eth0",
        "container-id": "95cd64ce3a85b112a5930c6a94f8b81068d35514a33eabb2a5506b073a6cbcdf",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-w7nlp",
        "pod-name": "kube-system/coredns-cc6ccd49c-w7nlp"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4034097,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh61",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh61",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:08Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.60.0.19",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "8a:27:82:86:62:b4",
        "interface-index": 12,
        "interface-name": "lxcb31e800cf128",
        "mac": "ba:16:55:69:70:ca"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4034097,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4034097,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 438

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 438

```
Timestamp              Status    State                   Message
2024-10-25T10:22:08Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:08Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:08Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:22:08Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:07Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:07Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:07Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:07Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:06Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:06Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:06Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:06Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:18Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:18Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:18Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:18Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:17Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:17Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:17Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:17Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:35Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:35Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:33Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:32Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:15:32Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:31Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:31Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:15:31Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:31Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 4034097

```
ID        LABELS
4034097   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh61
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1281

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    439928   5625      0        
Allow    Ingress     1          ANY          NONE         disabled    10952    127       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 1281

```
Invalid argument: unknown type 1281
```


#### Endpoint Get 1281

```
[
  {
    "id": 1281,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1281-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "2c4e6d17-d20e-48b1-9071-391b6e59f417"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1281",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:31.673Z",
            "success-count": 3
          },
          "uuid": "f233416f-1536-424a-8db8-d51a87597215"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1281",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:35.219Z",
            "success-count": 1
          },
          "uuid": "c9519343-5c8b-49d0-9181-3c9b6b247c65"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:08Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.60.0.93",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "fa:15:3a:e1:d8:06",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "de:6b:fc:22:f5:a9"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1281

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1281

```
Timestamp              Status   State                   Message
2024-10-25T10:22:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:08Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:07Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:35Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:32Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:15:32Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:31Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:31Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:30Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 2238

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2238

```
Invalid argument: unknown type 2238
```


#### Endpoint Get 2238

```
[
  {
    "id": 2238,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2238-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "54df1952-a28f-4524-9174-d2f4351bd2ab"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2238",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:30.624Z",
            "success-count": 3
          },
          "uuid": "53d2e54c-6ad3-49ad-97cb-e6766123bbee"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2238",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:31.774Z",
            "success-count": 1
          },
          "uuid": "c4bc3ce2-c4a9-48cd-b298-020a15f16696"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:08Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "92:8a:43:e0:a7:4d",
        "interface-name": "cilium_host",
        "mac": "92:8a:43:e0:a7:4d"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2238

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2238

```
Timestamp              Status   State                   Message
2024-10-25T10:22:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:08Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:07Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:15:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:35Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:15:33Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:32Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:15:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:15:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:30Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:30Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:30Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 3621

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3881357   36794     0        
Allow    Ingress     1          ANY          NONE         disabled    3351480   34073     0        
Allow    Egress      0          ANY          NONE         disabled    4972991   45787     0        

```


#### BPF CT List 3621

```
Invalid argument: unknown type 3621
```


#### Endpoint Get 3621

```
[
  {
    "id": 3621,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3621-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f70c68e4-1b6b-4df4-bbfc-8c423348113a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3621",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:43.698Z",
            "success-count": 2
          },
          "uuid": "610c582c-4e1b-49b8-946d-f5cf48f2d9c3"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-77c47f9d8b-zv4dx",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:43.696Z",
            "success-count": 1
          },
          "uuid": "2d4e2bce-c959-4111-b8e2-974f4b9baad9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3621",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:43.733Z",
            "success-count": 1
          },
          "uuid": "658f6d89-a2f6-4510-86d7-085377516f2e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3621)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:13.758Z",
            "success-count": 47
          },
          "uuid": "ca7e6313-9456-4758-8e0d-65194bb83d2e"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "eda41c3a8042398d1efd31b2696a3bc5c859b3d5998a6008baaf1e358af77a61:eth0",
        "container-id": "eda41c3a8042398d1efd31b2696a3bc5c859b3d5998a6008baaf1e358af77a61",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-77c47f9d8b-zv4dx",
        "pod-name": "kube-system/clustermesh-apiserver-77c47f9d8b-zv4dx"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4003608,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh61",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=77c47f9d8b"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh61",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:08Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.60.0.244",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "d2:0a:c8:f8:da:73",
        "interface-index": 18,
        "interface-name": "lxc9c9090460634",
        "mac": "9a:63:49:3f:ee:76"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4003608,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4003608,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3621

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3621

```
Timestamp              Status   State                   Message
2024-10-25T10:22:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:08Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:07Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:43Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:43Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:43Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4003608

```
ID        LABELS
4003608   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh61
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 3891

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    76759   880       0        
Allow    Egress      0          ANY          NONE         disabled    13593   141       0        

```


#### BPF CT List 3891

```
Invalid argument: unknown type 3891
```


#### Endpoint Get 3891

```
[
  {
    "id": 3891,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3891-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "e1ea4269-b9e9-4fbb-90f3-bbb99b4267ca"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3891",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:32.047Z",
            "success-count": 3
          },
          "uuid": "66f2cacd-99d8-4a64-a26e-b96dac101a2c"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-lz5hq",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:32.045Z",
            "success-count": 1
          },
          "uuid": "b3a9a25e-5741-4409-ad11-1d4b9d80e04e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3891",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:35.307Z",
            "success-count": 1
          },
          "uuid": "2579619b-a6b2-4ae8-ad23-be7b13a9081c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3891)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:12.113Z",
            "success-count": 84
          },
          "uuid": "6891266f-2196-4a5b-a371-1c8a3a937cbd"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "43fc73d2b5289f5beb77bd9dee2ee6f7b31bec3ccb3047733f291e6963a7e79d:eth0",
        "container-id": "43fc73d2b5289f5beb77bd9dee2ee6f7b31bec3ccb3047733f291e6963a7e79d",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-lz5hq",
        "pod-name": "kube-system/coredns-cc6ccd49c-lz5hq"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4034097,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh61",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh61",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:08Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.60.0.236",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "76:e8:dc:37:35:26",
        "interface-index": 14,
        "interface-name": "lxc5aaa81dbf656",
        "mac": "5a:c6:26:dc:8d:fe"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4034097,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4034097,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3891

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3891

```
Timestamp              Status   State                   Message
2024-10-25T10:22:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:08Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:07Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:35Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:32Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:15:32Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:32Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:32Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4034097

```
ID        LABELS
4034097   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh61
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### Service list

```
ID   Frontend            Service Type   Backend                            
1    10.100.0.1:443      ClusterIP      1 => 172.31.201.189:443 (active)   
                                        2 => 172.31.148.229:443 (active)   
2    10.100.3.205:443    ClusterIP      1 => 172.31.184.13:4244 (active)   
3    10.100.0.10:9153    ClusterIP      1 => 10.60.0.19:9153 (active)      
                                        2 => 10.60.0.236:9153 (active)     
4    10.100.0.10:53      ClusterIP      1 => 10.60.0.19:53 (active)        
                                        2 => 10.60.0.236:53 (active)       
5    10.100.70.24:2379   ClusterIP      1 => 10.60.0.244:2379 (active)     
```
