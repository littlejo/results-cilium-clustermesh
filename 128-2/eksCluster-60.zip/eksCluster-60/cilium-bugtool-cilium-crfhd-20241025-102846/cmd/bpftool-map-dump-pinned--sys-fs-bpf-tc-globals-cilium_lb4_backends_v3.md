key: 08 00 00 00  value: 0a 3c 00 ec 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 3c 00 ec 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f c9 bd 01 bb 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 3c 00 13 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 3c 00 f4 09 4b 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f 94 e5 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 3c 00 13 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f b8 0d 10 94 00 00  00 00 00 00
Found 8 elements
