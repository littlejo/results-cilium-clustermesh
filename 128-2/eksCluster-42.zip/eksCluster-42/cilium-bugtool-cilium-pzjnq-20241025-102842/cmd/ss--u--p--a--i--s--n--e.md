Total: 560
TCP:   1094 (estab 311, closed 764, orphaned 0, timewait 301)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  330       319       11       
INET	  340       325       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:42851      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:24549 sk:278 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.149.98%ens5:68         0.0.0.0:*    uid:192 ino:15076 sk:279 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:25014 sk:27a cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15801 sk:27b cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:25013 sk:27c cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15802 sk:27d cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::443:fdff:fe76:4611]%ens5:546           [::]:*    uid:192 ino:15072 sk:27e cgroup:unreachable:c4e v6only:1 <->                   
