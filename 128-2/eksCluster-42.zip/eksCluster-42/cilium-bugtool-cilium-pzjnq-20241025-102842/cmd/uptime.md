 10:28:44 up 13 min,  0 users,  load average: 1.29, 0.67, 0.40
