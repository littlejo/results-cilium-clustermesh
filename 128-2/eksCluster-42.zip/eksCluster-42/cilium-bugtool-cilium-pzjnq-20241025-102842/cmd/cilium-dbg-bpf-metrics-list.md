REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     206366    83659586   1132   bpf_host.c
Interface                 INGRESS     8680      678570     677    bpf_overlay.c
Success                   EGRESS      3822      290168     1694   bpf_host.c
Success                   EGRESS      8209      643521     53     encap.h
Success                   EGRESS      87162     11831262   1308   bpf_lxc.c
Success                   INGRESS     102038    12364206   235    trace.h
Success                   INGRESS     96531     11931898   86     l3.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
