[
  {
    "containers": [
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod88d619fc_600f_46fe_b198_39cc36223480.slice/cri-containerd-a25518d893b9c53b5f399fd3ac09d9a194c6e868756b47025cd328a2d97f9cab.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod88d619fc_600f_46fe_b198_39cc36223480.slice/cri-containerd-a25399a5d3b80cb34297c4a9a01cff7e4cc681e3ea11c407a9407a4721482e55.scope"
      },
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod88d619fc_600f_46fe_b198_39cc36223480.slice/cri-containerd-8ba2a5584431500e4df69c50706d8154f1b62859cb6c6d0a0e8aa21fa5c52755.scope"
      }
    ],
    "ips": [
      "10.42.0.169"
    ],
    "name": "clustermesh-apiserver-54f8c6679b-27cq9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd4ff82d0_ddf4_4812_8c15_cb9047d87d13.slice/cri-containerd-37c5c88843eb96f290780f623b499a76ee87960c17fb8273984140c36bda28fb.scope"
      }
    ],
    "ips": [
      "10.42.0.29"
    ],
    "name": "coredns-cc6ccd49c-bx695",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6886206e_3b6a_44e6_bd1a_b9bef3964f4f.slice/cri-containerd-581f41f5101f4c6988a02cff54a5ff17b3d666a1927c9934f67d7ca7f7f47734.scope"
      }
    ],
    "ips": [
      "10.42.0.183"
    ],
    "name": "coredns-cc6ccd49c-svx22",
    "namespace": "kube-system"
  }
]

