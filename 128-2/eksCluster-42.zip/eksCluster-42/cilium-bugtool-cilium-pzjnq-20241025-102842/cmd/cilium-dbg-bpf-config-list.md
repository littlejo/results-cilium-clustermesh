KEY             VALUE
AgentLiveness   847655111259
UTimeOffset     3378615833984375
