top - 10:28:44 up 13 min,  0 users,  load average: 1.29, 0.67, 0.40
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 11.1 us, 22.2 sy,  0.0 ni, 63.0 id,  0.0 wa,  0.0 hi,  3.7 si,  0.0 st
MiB Mem :   3836.2 total,    799.6 free,    894.2 used,   2142.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2773.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1472496 279236  77628 S   6.7   7.1   0:21.49 cilium-+
    641 root      20   0 1240432  16492  11420 S   6.7   0.4   0:00.03 cilium-+
    394 root      20   0 1228848   5556   2932 S   0.0   0.1   0:00.26 cilium-+
    653 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    665 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    696 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    715 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
