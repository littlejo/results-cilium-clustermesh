Endpoint ID: 236
Path: /sys/fs/bpf/tc/globals/cilium_policy_00236

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69467   798       0        
Allow    Egress      0          ANY          NONE         disabled    12921   132       0        


Endpoint ID: 432
Path: /sys/fs/bpf/tc/globals/cilium_policy_00432

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1759
Path: /sys/fs/bpf/tc/globals/cilium_policy_01759

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    433144   5518      0        
Allow    Ingress     1          ANY          NONE         disabled    10254    119       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2142
Path: /sys/fs/bpf/tc/globals/cilium_policy_02142

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69522   801       0        
Allow    Egress      0          ANY          NONE         disabled    13003   133       0        


Endpoint ID: 2386
Path: /sys/fs/bpf/tc/globals/cilium_policy_02386

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3875507   36065     0        
Allow    Ingress     1          ANY          NONE         disabled    2641591   26156     0        
Allow    Egress      0          ANY          NONE         disabled    4170143   38675     0        


