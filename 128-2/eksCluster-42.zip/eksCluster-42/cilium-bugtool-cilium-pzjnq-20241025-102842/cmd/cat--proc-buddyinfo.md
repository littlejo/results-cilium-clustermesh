Node 0, zone      DMA     75     34      3      9      5      8     14      8      6      4    169 
Node 0, zone   Normal    362     78     34     13     35     25      7      2      1      3      6 
