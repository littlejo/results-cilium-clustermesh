1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:43:fd:76:46:11 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.149.98/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2794sec preferred_lft 2794sec
    inet6 fe80::443:fdff:fe76:4611/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ed:4b:79:cc:dd brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.164.219/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4ed:4bff:fe79:ccdd/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:1f:14:11:eb:74 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3c1f:14ff:fe11:eb74/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:22:72:58:e7:a5 brd ff:ff:ff:ff:ff:ff
    inet 10.42.0.95/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::4c22:72ff:fe58:e7a5/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 2e:7f:bd:fa:fd:e7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2c7f:bdff:fefa:fde7/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:72:98:2c:35:01 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::e072:98ff:fe2c:3501/64 scope link 
       valid_lft forever preferred_lft forever
12: lxce9b8928c3d2b@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:a2:a6:c1:8c:c4 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::18a2:a6ff:fec1:8cc4/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcec88a65b2216@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:e6:f3:fb:f9:4f brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::2ce6:f3ff:fefb:f94f/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc08e947c46d5f@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:d7:4e:ac:14:8e brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::e0d7:4eff:feac:148e/64 scope link 
       valid_lft forever preferred_lft forever
