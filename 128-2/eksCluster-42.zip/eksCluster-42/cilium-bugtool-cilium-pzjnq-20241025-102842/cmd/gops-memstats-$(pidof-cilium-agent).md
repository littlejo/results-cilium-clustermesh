alloc: 97.52MB (102253328 bytes)
total-alloc: 1.29GB (1388550488 bytes)
sys: 202.32MB (212146500 bytes)
lookups: 0
mallocs: 47166544
frees: 46181098
heap-alloc: 97.52MB (102253328 bytes)
heap-sys: 157.79MB (165453824 bytes)
heap-idle: 37.52MB (39346176 bytes)
heap-in-use: 120.27MB (126107648 bytes)
heap-released: 168.00KB (172032 bytes)
heap-objects: 985446
stack-in-use: 34.19MB (35848192 bytes)
stack-sys: 34.19MB (35848192 bytes)
stack-mspan-inuse: 2.01MB (2104640 bytes)
stack-mspan-sys: 2.47MB (2594880 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 944.09KB (966753 bytes)
gc-sys: 5.04MB (5286912 bytes)
next-gc: when heap-alloc >= 148.38MB (155585752 bytes)
last-gc: 2024-10-25 10:28:49.519245437 +0000 UTC
gc-pause-total: 6.043642ms
gc-pause: 106516
gc-pause-end: 1729852129519245437
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0003237489950509628
enable-gc: true
debug-gc: false
