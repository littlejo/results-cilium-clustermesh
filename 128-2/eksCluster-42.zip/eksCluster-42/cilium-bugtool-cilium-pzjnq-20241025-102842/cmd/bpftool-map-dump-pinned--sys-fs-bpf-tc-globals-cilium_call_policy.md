key: ec 00 00 00  value: 1e 02 00 00
key: df 06 00 00  value: 0a 02 00 00
key: 5e 08 00 00  value: 02 02 00 00
key: 52 09 00 00  value: 76 02 00 00
Found 4 elements
