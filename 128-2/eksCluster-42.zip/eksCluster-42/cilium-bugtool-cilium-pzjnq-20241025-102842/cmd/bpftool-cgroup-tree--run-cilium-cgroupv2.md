CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6886206e_3b6a_44e6_bd1a_b9bef3964f4f.slice/cri-containerd-f91eaa8c7cbcf4b1c565ac956846ca46098880d8435a623eb0bcc5e911a97919.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6886206e_3b6a_44e6_bd1a_b9bef3964f4f.slice/cri-containerd-581f41f5101f4c6988a02cff54a5ff17b3d666a1927c9934f67d7ca7f7f47734.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd4ff82d0_ddf4_4812_8c15_cb9047d87d13.slice/cri-containerd-37c5c88843eb96f290780f623b499a76ee87960c17fb8273984140c36bda28fb.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd4ff82d0_ddf4_4812_8c15_cb9047d87d13.slice/cri-containerd-b2134dd2276189065af111a9266e3c8f6ee706213cf194ae675e7982a8907179.scope
    541      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod82281b86_fe9b_408a_b75d_e3ff058f3d8d.slice/cri-containerd-4314dbef157291e07bb0b026cc075e3307f483519310146f49045875e73bd483.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod82281b86_fe9b_408a_b75d_e3ff058f3d8d.slice/cri-containerd-b03179d5e4eb72cf70b85a7c2063d5b0312a1c504dc98e2b35bc35a43eb9aec3.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod38fa6175_68f2_4298_8649_d77c5385c97d.slice/cri-containerd-bbac5b4ab30487658edc1fcb21f922fe2c305f1253ca3e7d3889405695750d46.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod38fa6175_68f2_4298_8649_d77c5385c97d.slice/cri-containerd-6ebde7edeb1528b61363ecf70dd951135df684138251b10bd62c47b6501af998.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf45941fd_29bf_4254_b35d_65f4a677f075.slice/cri-containerd-898431ef3ace47ef4eda59bf9472cec0bccd93d525d5041b0d1956a7758c42f8.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf45941fd_29bf_4254_b35d_65f4a677f075.slice/cri-containerd-5cb8b7c59560717a6092bed2690e5beae489246f7b344173a951e4fa744b3b68.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64bf17c8_46c2_4050_89e1_30d1926a21e7.slice/cri-containerd-a8ecd84fe8fc3d67afa170b7b9a3067b994252ec50f1906705deb564212c4f97.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod64bf17c8_46c2_4050_89e1_30d1926a21e7.slice/cri-containerd-666a6b95e6e2be07befff7d9afe125439545d8559df88f92183475b8850020e5.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod88d619fc_600f_46fe_b198_39cc36223480.slice/cri-containerd-a25399a5d3b80cb34297c4a9a01cff7e4cc681e3ea11c407a9407a4721482e55.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod88d619fc_600f_46fe_b198_39cc36223480.slice/cri-containerd-3e97e481797149c9df1410c30fb4daea348deaae929ecba5a6ef1ef8db97ffc5.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod88d619fc_600f_46fe_b198_39cc36223480.slice/cri-containerd-8ba2a5584431500e4df69c50706d8154f1b62859cb6c6d0a0e8aa21fa5c52755.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod88d619fc_600f_46fe_b198_39cc36223480.slice/cri-containerd-a25518d893b9c53b5f399fd3ac09d9a194c6e868756b47025cd328a2d97f9cab.scope
    656      cgroup_device   multi                                          
