ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.158.88:443 (active)    
                                         2 => 172.31.233.217:443 (active)   
2    10.100.207.59:443    ClusterIP      1 => 172.31.149.98:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.42.0.29:53 (active)        
                                         2 => 10.42.0.183:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.42.0.29:9153 (active)      
                                         2 => 10.42.0.183:9153 (active)     
5    10.100.37.230:2379   ClusterIP      1 => 10.42.0.169:2379 (active)     
