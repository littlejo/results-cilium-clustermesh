{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:47.096Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.149.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:47.096Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.164.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:47.096Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:51.728Z",
  "value": "id=1759  sec_id=4     flags=0x0000 ifindex=10  mac=86:E3:3B:0D:14:8A nodemac=E2:72:98:2C:35:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:51.729Z",
  "value": "id=236   sec_id=2857503 flags=0x0000 ifindex=12  mac=1E:EB:1D:D4:16:DE nodemac=1A:A2:A6:C1:8C:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:51.806Z",
  "value": "id=2142  sec_id=2857503 flags=0x0000 ifindex=14  mac=2A:E0:E0:24:80:9E nodemac=2E:E6:F3:FB:F9:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:51.873Z",
  "value": "id=1759  sec_id=4     flags=0x0000 ifindex=10  mac=86:E3:3B:0D:14:8A nodemac=E2:72:98:2C:35:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:51.953Z",
  "value": "id=236   sec_id=2857503 flags=0x0000 ifindex=12  mac=1E:EB:1D:D4:16:DE nodemac=1A:A2:A6:C1:8C:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:01.164Z",
  "value": "id=1759  sec_id=4     flags=0x0000 ifindex=10  mac=86:E3:3B:0D:14:8A nodemac=E2:72:98:2C:35:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:01.164Z",
  "value": "id=236   sec_id=2857503 flags=0x0000 ifindex=12  mac=1E:EB:1D:D4:16:DE nodemac=1A:A2:A6:C1:8C:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:01.165Z",
  "value": "id=2142  sec_id=2857503 flags=0x0000 ifindex=14  mac=2A:E0:E0:24:80:9E nodemac=2E:E6:F3:FB:F9:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:01.196Z",
  "value": "id=508   sec_id=2865109 flags=0x0000 ifindex=16  mac=D6:C1:88:6B:0A:18 nodemac=82:81:C7:5F:86:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.164Z",
  "value": "id=2142  sec_id=2857503 flags=0x0000 ifindex=14  mac=2A:E0:E0:24:80:9E nodemac=2E:E6:F3:FB:F9:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.164Z",
  "value": "id=1759  sec_id=4     flags=0x0000 ifindex=10  mac=86:E3:3B:0D:14:8A nodemac=E2:72:98:2C:35:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.165Z",
  "value": "id=508   sec_id=2865109 flags=0x0000 ifindex=16  mac=D6:C1:88:6B:0A:18 nodemac=82:81:C7:5F:86:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.165Z",
  "value": "id=236   sec_id=2857503 flags=0x0000 ifindex=12  mac=1E:EB:1D:D4:16:DE nodemac=1A:A2:A6:C1:8C:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:32.080Z",
  "value": "id=2386  sec_id=2865109 flags=0x0000 ifindex=18  mac=EA:54:EB:0D:3A:D4 nodemac=E2:D7:4E:AC:14:8E"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.42.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:38.752Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:53.769Z",
  "value": "id=2142  sec_id=2857503 flags=0x0000 ifindex=14  mac=2A:E0:E0:24:80:9E nodemac=2E:E6:F3:FB:F9:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:53.769Z",
  "value": "id=2386  sec_id=2865109 flags=0x0000 ifindex=18  mac=EA:54:EB:0D:3A:D4 nodemac=E2:D7:4E:AC:14:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:53.770Z",
  "value": "id=1759  sec_id=4     flags=0x0000 ifindex=10  mac=86:E3:3B:0D:14:8A nodemac=E2:72:98:2C:35:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:53.770Z",
  "value": "id=236   sec_id=2857503 flags=0x0000 ifindex=12  mac=1E:EB:1D:D4:16:DE nodemac=1A:A2:A6:C1:8C:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:54.764Z",
  "value": "id=2142  sec_id=2857503 flags=0x0000 ifindex=14  mac=2A:E0:E0:24:80:9E nodemac=2E:E6:F3:FB:F9:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:54.765Z",
  "value": "id=2386  sec_id=2865109 flags=0x0000 ifindex=18  mac=EA:54:EB:0D:3A:D4 nodemac=E2:D7:4E:AC:14:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:54.765Z",
  "value": "id=1759  sec_id=4     flags=0x0000 ifindex=10  mac=86:E3:3B:0D:14:8A nodemac=E2:72:98:2C:35:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:54.765Z",
  "value": "id=236   sec_id=2857503 flags=0x0000 ifindex=12  mac=1E:EB:1D:D4:16:DE nodemac=1A:A2:A6:C1:8C:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:55.764Z",
  "value": "id=1759  sec_id=4     flags=0x0000 ifindex=10  mac=86:E3:3B:0D:14:8A nodemac=E2:72:98:2C:35:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:55.764Z",
  "value": "id=2386  sec_id=2865109 flags=0x0000 ifindex=18  mac=EA:54:EB:0D:3A:D4 nodemac=E2:D7:4E:AC:14:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:55.765Z",
  "value": "id=236   sec_id=2857503 flags=0x0000 ifindex=12  mac=1E:EB:1D:D4:16:DE nodemac=1A:A2:A6:C1:8C:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.42.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:55.765Z",
  "value": "id=2142  sec_id=2857503 flags=0x0000 ifindex=14  mac=2A:E0:E0:24:80:9E nodemac=2E:E6:F3:FB:F9:4F"
}

