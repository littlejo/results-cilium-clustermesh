IP ADDRESS         LOCAL ENDPOINT INFO
10.42.0.169:0      id=2386  sec_id=2865109 flags=0x0000 ifindex=18  mac=EA:54:EB:0D:3A:D4 nodemac=E2:D7:4E:AC:14:8E   
172.31.164.219:0   (localhost)                                                                                        
10.42.0.95:0       (localhost)                                                                                        
172.31.149.98:0    (localhost)                                                                                        
10.42.0.29:0       id=2142  sec_id=2857503 flags=0x0000 ifindex=14  mac=2A:E0:E0:24:80:9E nodemac=2E:E6:F3:FB:F9:4F   
10.42.0.249:0      id=1759  sec_id=4     flags=0x0000 ifindex=10  mac=86:E3:3B:0D:14:8A nodemac=E2:72:98:2C:35:01     
10.42.0.183:0      id=236   sec_id=2857503 flags=0x0000 ifindex=12  mac=1E:EB:1D:D4:16:DE nodemac=1A:A2:A6:C1:8C:C4   
