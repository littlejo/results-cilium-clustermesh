[
  {
    "containers": [
      {
        "cgroup-id": 8286,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff66db98_fc96_4d6f_bf2a_f2efff6d7016.slice/cri-containerd-92b742358ca1967636ec63eccecf587072f75daaddb2c8a8f07d7f8e59857b40.scope"
      },
      {
        "cgroup-id": 8202,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff66db98_fc96_4d6f_bf2a_f2efff6d7016.slice/cri-containerd-307b53ed2e2cf5f72fa30a3929b80293a2cf2fed15f2c1c14de8e60682577be5.scope"
      },
      {
        "cgroup-id": 8370,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff66db98_fc96_4d6f_bf2a_f2efff6d7016.slice/cri-containerd-50ac5a5b2d76c3f634d321ea16d657dd00aaf80904e1a07724519ba5bc13c3f0.scope"
      }
    ],
    "ips": [
      "10.1.0.46"
    ],
    "name": "clustermesh-apiserver-6f65fcb5cc-qhmjp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6774,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode7d7b83c_be13_4820_a9f8_9e1dffae52e8.slice/cri-containerd-1f6adeb288ca40bb3cc4b9831309c5e3be3bb708585946c3ea6b3fd96dbe85e5.scope"
      }
    ],
    "ips": [
      "10.1.0.71"
    ],
    "name": "coredns-cc6ccd49c-rdkcg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6858,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6a7ed771_cc0b_401d_8471_10aab0a03730.slice/cri-containerd-7c7abd66cb03d22f089cc739d180472293d5317de0faa5bedaab299021bba0e5.scope"
      }
    ],
    "ips": [
      "10.1.0.180"
    ],
    "name": "coredns-cc6ccd49c-bsslx",
    "namespace": "kube-system"
  }
]

