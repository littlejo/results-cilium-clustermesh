Endpoint ID: 596
Path: /sys/fs/bpf/tc/globals/cilium_policy_00596

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    427336   5450      0        
Allow    Ingress     1          ANY          NONE         disabled    12536    145       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 849
Path: /sys/fs/bpf/tc/globals/cilium_policy_00849

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    87562   1010      0        
Allow    Egress      0          ANY          NONE         disabled    14253   149       0        


Endpoint ID: 1390
Path: /sys/fs/bpf/tc/globals/cilium_policy_01390

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3842398   36468     0        
Allow    Ingress     1          ANY          NONE         disabled    3187854   32320     0        
Allow    Egress      0          ANY          NONE         disabled    4931152   45375     0        


Endpoint ID: 1462
Path: /sys/fs/bpf/tc/globals/cilium_policy_01462

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    86951   998       0        
Allow    Egress      0          ANY          NONE         disabled    12502   130       0        


Endpoint ID: 1834
Path: /sys/fs/bpf/tc/globals/cilium_policy_01834

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


