35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:52+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:52+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:52+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:52+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:52+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:12:52+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:12:53+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:12:53+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:53+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:53+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:12:53+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:53+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
61: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
64: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
71: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:11+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
72: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
75: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
447: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 112
448: sched_cls  name tail_handle_ipv4  tag 7406737d1cab5c5a  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 113
449: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 114
450: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 115
477: sched_cls  name tail_ipv4_to_endpoint  tag 260086d08d5f08da  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,101,33,74,75,72,97,31,100,32,29,30
	btf_id 143
479: sched_cls  name tail_ipv4_ct_egress  tag 40200df9ba637b14  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,100,74,75,101,76
	btf_id 149
480: sched_cls  name tail_handle_arp  tag 62faf993550fe16f  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,100
	btf_id 151
481: sched_cls  name tail_ipv4_ct_ingress  tag 70a73f522779e9d8  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,100,74,75,101,76
	btf_id 152
485: sched_cls  name tail_handle_ipv4  tag f6611503a618c370  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,100
	btf_id 154
488: sched_cls  name handle_policy  tag 7e860400a529a619  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,100,74,75,101,33,72,97,31,76,67,32,29,30
	btf_id 157
489: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,100
	btf_id 160
490: sched_cls  name cil_from_container  tag 08c5dacc3bff35bc  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 100,68
	btf_id 161
492: sched_cls  name tail_handle_ipv4_cont  tag 1bcaf4e9817b3438  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,101,33,97,74,75,31,68,66,69,100,32,29,30,73
	btf_id 162
493: sched_cls  name cil_from_container  tag c4ed21e407a0e290  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 103,68
	btf_id 164
494: sched_cls  name __send_drop_notify  tag 06488c603adf19d3  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 165
495: sched_cls  name tail_ipv4_ct_egress  tag 40200df9ba637b14  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,103,74,75,104,76
	btf_id 166
496: sched_cls  name tail_handle_ipv4_from_host  tag 94b814fbb405d80f  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,106
	btf_id 169
497: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,106
	btf_id 170
498: sched_cls  name tail_ipv4_to_endpoint  tag 56c10f799c547897  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,104,33,74,75,72,102,31,103,32,29,30
	btf_id 167
499: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,106
	btf_id 171
501: sched_cls  name __send_drop_notify  tag 198d1ae63c6ed493  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 174
502: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 175
504: sched_cls  name handle_policy  tag f4ad5aadb2f27201  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,103,74,75,104,33,72,102,31,76,67,32,29,30
	btf_id 172
505: sched_cls  name __send_drop_notify  tag 218eda88c3afdb82  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 177
507: sched_cls  name tail_handle_ipv4  tag a7307a01ae776097  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,103
	btf_id 179
508: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,103
	btf_id 182
510: sched_cls  name tail_handle_ipv4_cont  tag ace62dd7c3412fc1  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,104,33,102,74,75,31,68,66,69,103,32,29,30,73
	btf_id 183
512: sched_cls  name __send_drop_notify  tag 198d1ae63c6ed493  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 186
513: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 187
515: sched_cls  name tail_ipv4_ct_ingress  tag eae8e25f3627d9e0  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,103,74,75,104,76
	btf_id 185
516: sched_cls  name tail_handle_ipv4_from_host  tag 94b814fbb405d80f  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,108
	btf_id 189
517: sched_cls  name tail_handle_arp  tag 6ee43f8ef8ab2147  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,103
	btf_id 190
518: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,108
	btf_id 191
519: sched_cls  name tail_handle_arp  tag 5092d583cde36143  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,112
	btf_id 195
520: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,112,74,75,111,76
	btf_id 196
521: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,110,67
	btf_id 193
522: sched_cls  name tail_handle_ipv4_from_host  tag 94b814fbb405d80f  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,110
	btf_id 198
523: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,110
	btf_id 199
526: sched_cls  name __send_drop_notify  tag 198d1ae63c6ed493  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 202
528: sched_cls  name tail_handle_ipv4  tag 2d0eedc20299f7f3  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,112
	btf_id 197
529: sched_cls  name tail_ipv4_ct_ingress  tag 44128701ab900135  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,112,74,75,111,76
	btf_id 204
530: sched_cls  name __send_drop_notify  tag d95ed931e38d7301  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 205
531: sched_cls  name tail_ipv4_to_endpoint  tag e3f1644d46e6fa36  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,111,33,74,75,72,90,31,112,32,29,30
	btf_id 206
532: sched_cls  name cil_from_container  tag 9cf6485ca77a520d  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 112,68
	btf_id 207
533: sched_cls  name tail_handle_ipv4_cont  tag c398d76d1bd5de6d  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,111,33,90,74,75,31,68,66,69,112,32,29,30,73
	btf_id 208
535: sched_cls  name handle_policy  tag 80478373ae439ab0  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,112,74,75,111,33,72,90,31,76,67,32,29,30
	btf_id 210
536: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,112
	btf_id 211
537: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
540: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
541: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
544: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
545: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
548: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
549: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
552: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
593: sched_cls  name tail_ipv4_ct_ingress  tag 2eba7d885ec28154  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,128,74,75,129,76
	btf_id 228
594: sched_cls  name __send_drop_notify  tag b32368a10043dc93  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 229
595: sched_cls  name tail_ipv4_ct_egress  tag 9725ffbf8adcfc23  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,128,74,75,129,76
	btf_id 230
596: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,128
	btf_id 231
597: sched_cls  name tail_handle_arp  tag 81827ec8653ff25c  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,128
	btf_id 232
598: sched_cls  name handle_policy  tag 165c0be7816ef56d  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,128,74,75,129,33,72,127,31,76,67,32,29,30
	btf_id 233
599: sched_cls  name tail_ipv4_to_endpoint  tag 9ebe843200340098  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,129,33,74,75,72,127,31,128,32,29,30
	btf_id 234
600: sched_cls  name tail_handle_ipv4_cont  tag 60b5469a05b4c057  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,129,33,127,74,75,31,68,66,69,128,32,29,30,73
	btf_id 235
601: sched_cls  name tail_handle_ipv4  tag 50aed2ee0c1f2ae5  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,128
	btf_id 236
602: sched_cls  name cil_from_container  tag e688e522e40d0f2c  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 128,68
	btf_id 237
603: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
606: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
619: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
622: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
623: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
626: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
627: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
630: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
