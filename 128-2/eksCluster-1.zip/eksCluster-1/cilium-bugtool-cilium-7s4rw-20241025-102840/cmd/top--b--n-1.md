top - 10:28:41 up 15 min,  0 users,  load average: 1.15, 0.31, 0.16
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s):  3.7 us, 22.2 sy,  0.0 ni, 74.1 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1196.8 free,    882.6 used,   1756.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2785.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1472496 278060  78400 S   0.0   7.1   0:26.21 cilium-+
    411 root      20   0 1228848   6052   2928 S   0.0   0.2   0:00.27 cilium-+
    656 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    666 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    675 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    685 root      20   0 1240432  16200  11292 S   0.0   0.4   0:00.02 cilium-+
    711 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    729 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
