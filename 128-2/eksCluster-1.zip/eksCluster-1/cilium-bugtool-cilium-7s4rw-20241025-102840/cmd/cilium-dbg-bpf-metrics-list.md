REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     224048    101090326   1132   bpf_host.c
Interface                 INGRESS     9963      781398      677    bpf_overlay.c
Success                   EGRESS      10204     799618      53     encap.h
Success                   EGRESS      5177      399160      1694   bpf_host.c
Success                   EGRESS      94059     12437131    1308   bpf_lxc.c
Success                   INGRESS     104908    12916714    86     l3.h
Success                   INGRESS     110343    13342858    235    trace.h
Unsupported L3 protocol   EGRESS      36        2672        1492   bpf_lxc.c
