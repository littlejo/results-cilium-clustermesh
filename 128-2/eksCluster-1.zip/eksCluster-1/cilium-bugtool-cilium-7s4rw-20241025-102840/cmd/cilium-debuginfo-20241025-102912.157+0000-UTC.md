# Cilium debug information

#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.1.0.0/24, 
Allocated addresses:
  10.1.0.172 (health)
  10.1.0.180 (kube-system/coredns-cc6ccd49c-bsslx)
  10.1.0.212 (router)
  10.1.0.46 (kube-system/clustermesh-apiserver-6f65fcb5cc-qhmjp)
  10.1.0.71 (kube-system/coredns-cc6ccd49c-rdkcg)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 8e54d268737a0059
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    28s ago        never        0       no error   
  ct-map-pressure                                                     29s ago        never        0       no error   
  daemon-validate-config                                              14s ago        never        0       no error   
  dns-garbage-collector-job                                           32s ago        never        0       no error   
  endpoint-1390-regeneration-recovery                                 never          never        0       no error   
  endpoint-1462-regeneration-recovery                                 never          never        0       no error   
  endpoint-1834-regeneration-recovery                                 never          never        0       no error   
  endpoint-596-regeneration-recovery                                  never          never        0       no error   
  endpoint-849-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         32s ago        never        0       no error   
  ep-bpf-prog-watchdog                                                29s ago        never        0       no error   
  ipcache-inject-labels                                               29s ago        never        0       no error   
  k8s-heartbeat                                                       32s ago        never        0       no error   
  link-cache                                                          14s ago        never        0       no error   
  local-identity-checkpoint                                           15m19s ago     never        0       no error   
  node-neighbor-link-updater                                          9s ago         never        0       no error   
  remote-etcd-cmesh1                                                  6m30s ago      never        0       no error   
  remote-etcd-cmesh10                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh100                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh101                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh102                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh103                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh104                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh105                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh106                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh107                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh108                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh109                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh11                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh110                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh111                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh112                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh113                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh114                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh115                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh116                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh117                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh118                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh119                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh12                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh120                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh121                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh122                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh123                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh124                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh125                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh126                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh127                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh128                                                6m30s ago      never        0       no error   
  remote-etcd-cmesh13                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh14                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh15                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh16                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh17                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh18                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh19                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh20                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh21                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh22                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh23                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh24                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh25                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh26                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh27                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh28                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh29                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh3                                                  6m30s ago      never        0       no error   
  remote-etcd-cmesh30                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh31                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh32                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh33                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh34                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh35                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh36                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh37                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh38                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh39                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh4                                                  6m30s ago      never        0       no error   
  remote-etcd-cmesh40                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh41                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh42                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh43                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh44                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh45                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh46                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh47                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh48                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh49                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh5                                                  6m30s ago      never        0       no error   
  remote-etcd-cmesh50                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh51                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh52                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh53                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh54                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh55                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh56                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh57                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh58                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh59                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh6                                                  6m30s ago      never        0       no error   
  remote-etcd-cmesh60                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh61                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh62                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh63                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh64                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh65                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh66                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh67                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh68                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh69                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh7                                                  6m30s ago      never        0       no error   
  remote-etcd-cmesh70                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh71                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh72                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh73                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh74                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh75                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh76                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh77                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh78                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh79                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh8                                                  6m30s ago      never        0       no error   
  remote-etcd-cmesh80                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh81                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh82                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh83                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh84                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh85                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh86                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh87                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh88                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh89                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh9                                                  6m30s ago      never        0       no error   
  remote-etcd-cmesh90                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh91                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh92                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh93                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh94                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh95                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh96                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh97                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh98                                                 6m30s ago      never        0       no error   
  remote-etcd-cmesh99                                                 6m30s ago      never        0       no error   
  resolve-identity-1390                                               2m28s ago      never        0       no error   
  resolve-identity-1462                                               28s ago        never        0       no error   
  resolve-identity-1834                                               29s ago        never        0       no error   
  resolve-identity-596                                                28s ago        never        0       no error   
  resolve-identity-849                                                28s ago        never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-6f65fcb5cc-qhmjp   7m28s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-bsslx                  15m28s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-rdkcg                  15m28s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      15m29s ago     never        0       no error   
  sync-policymap-1390                                                 7m28s ago      never        0       no error   
  sync-policymap-1462                                                 25s ago        never        0       no error   
  sync-policymap-1834                                                 28s ago        never        0       no error   
  sync-policymap-596                                                  25s ago        never        0       no error   
  sync-policymap-849                                                  25s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1390)                                   8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1462)                                   8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (849)                                    8s ago         never        0       no error   
  sync-utime                                                          29s ago        never        0       no error   
  write-cni-file                                                      15m32s ago     never        0       no error   
Proxy Status:            OK, ip 10.1.0.212, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 131072, max 196607
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 69.34   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 37764315                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 37764315                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 37764315                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d000000 rw-p 00000000 00:00 0 
400d000000-4010000000 ---p 00000000 00:00 0 
ffff74697000-ffff748ad000 rw-p 00000000 00:00 0 
ffff748b5000-ffff749d6000 rw-p 00000000 00:00 0 
ffff749d6000-ffff74a17000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff74a17000-ffff74a58000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff74a58000-ffff74a5a000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff74a5a000-ffff74a5c000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff74a5c000-ffff75013000 rw-p 00000000 00:00 0 
ffff75013000-ffff75113000 rw-p 00000000 00:00 0 
ffff75113000-ffff75124000 rw-p 00000000 00:00 0 
ffff75124000-ffff77124000 rw-p 00000000 00:00 0 
ffff77124000-ffff771a4000 ---p 00000000 00:00 0 
ffff771a4000-ffff771a5000 rw-p 00000000 00:00 0 
ffff771a5000-ffff971a4000 ---p 00000000 00:00 0 
ffff971a4000-ffff971a5000 rw-p 00000000 00:00 0 
ffff971a5000-ffffb7134000 ---p 00000000 00:00 0 
ffffb7134000-ffffb7135000 rw-p 00000000 00:00 0 
ffffb7135000-ffffbb126000 ---p 00000000 00:00 0 
ffffbb126000-ffffbb127000 rw-p 00000000 00:00 0 
ffffbb127000-ffffbb924000 ---p 00000000 00:00 0 
ffffbb924000-ffffbb925000 rw-p 00000000 00:00 0 
ffffbb925000-ffffbba24000 ---p 00000000 00:00 0 
ffffbba24000-ffffbba84000 rw-p 00000000 00:00 0 
ffffbba84000-ffffbba86000 r--p 00000000 00:00 0                          [vvar]
ffffbba86000-ffffbba87000 r-xp 00000000 00:00 0                          [vdso]
ffffe6f98000-ffffe6fb9000 rw-p 00000000 00:00 0                          [stack]

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=9) "10.1.0.46": (string) (len=50) "kube-system/clustermesh-apiserver-6f65fcb5cc-qhmjp",
  (string) (len=10) "10.1.0.212": (string) (len=6) "router",
  (string) (len=10) "10.1.0.172": (string) (len=6) "health",
  (string) (len=9) "10.1.0.71": (string) (len=35) "kube-system/coredns-cc6ccd49c-rdkcg",
  (string) (len=10) "10.1.0.180": (string) (len=35) "kube-system/coredns-cc6ccd49c-bsslx"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.197.251": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4000e4dd90)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001ca8d80,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001ca8d80,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4000e4d1e0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4000e4d290)(frontends:[10.100.115.38]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4000e4d340)(frontends:[10.100.0.10]/ports=[dns-tcp metrics dns]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4002c40580)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4002c406e0)(frontends:[10.100.244.78]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4000b2b448)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-9l872": (*k8s.Endpoints)(0x4002cbab60)(10.1.0.180:53/TCP[eu-west-3b],10.1.0.180:53/UDP[eu-west-3b],10.1.0.180:9153/TCP[eu-west-3b],10.1.0.71:53/TCP[eu-west-3b],10.1.0.71:53/UDP[eu-west-3b],10.1.0.71:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001a6f4b8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-xkr2c": (*k8s.Endpoints)(0x4001540d00)(10.1.0.46:2379/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4000b2b438)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40014a4340)(172.31.157.33:443/TCP,172.31.202.18:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4000b2b440)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-nwvwk": (*k8s.Endpoints)(0x40026508f0)(172.31.197.251:4244/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x40017d50a0)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x400215fae0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400af60150
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4000e554a0,
  gcExited: (chan struct {}) 0x4000e555c0,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001967800)({
     ObserverVec: (*prometheus.HistogramVec)(0x400165f720)({
      MetricVec: (*prometheus.MetricVec)(0x4001bc9cb0)({
       metricMap: (*prometheus.metricMap)(0x4001bc9ce0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400196f080)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001967880)({
     ObserverVec: (*prometheus.HistogramVec)(0x400165f728)({
      MetricVec: (*prometheus.MetricVec)(0x4001bc9d40)({
       metricMap: (*prometheus.metricMap)(0x4001bc9d70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400196f0e0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001967900)({
     GaugeVec: (*prometheus.GaugeVec)(0x400165f730)({
      MetricVec: (*prometheus.MetricVec)(0x4001bc9dd0)({
       metricMap: (*prometheus.metricMap)(0x4001bc9e00)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400196f140)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001967980)({
     GaugeVec: (*prometheus.GaugeVec)(0x400165f738)({
      MetricVec: (*prometheus.MetricVec)(0x4001bc9e60)({
       metricMap: (*prometheus.metricMap)(0x4001bc9e90)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400196f1a0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001967a00)({
     GaugeVec: (*prometheus.GaugeVec)(0x400165f740)({
      MetricVec: (*prometheus.MetricVec)(0x4001bc9ef0)({
       metricMap: (*prometheus.metricMap)(0x4001bc9f20)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400196f200)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001967a80)({
     GaugeVec: (*prometheus.GaugeVec)(0x400165f748)({
      MetricVec: (*prometheus.MetricVec)(0x4001bda000)({
       metricMap: (*prometheus.metricMap)(0x4001bda030)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400196f260)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001967b00)({
     GaugeVec: (*prometheus.GaugeVec)(0x400165f750)({
      MetricVec: (*prometheus.MetricVec)(0x4001bda090)({
       metricMap: (*prometheus.metricMap)(0x4001bda0c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400196f2c0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001967b80)({
     GaugeVec: (*prometheus.GaugeVec)(0x400165f758)({
      MetricVec: (*prometheus.MetricVec)(0x4001bda120)({
       metricMap: (*prometheus.metricMap)(0x4001bda150)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400196f320)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001967c00)({
     ObserverVec: (*prometheus.HistogramVec)(0x400165f760)({
      MetricVec: (*prometheus.MetricVec)(0x4001bda1b0)({
       metricMap: (*prometheus.metricMap)(0x4001bda1e0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400196f380)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x40017d50a0)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001cec000)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4000e96f60)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 295ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium environment keys

```
dnsproxy-insecure-skip-transparent-mode-check:false
hubble-redact-http-userinfo:true
dnsproxy-concurrency-limit:0
identity-allocation-mode:crd
envoy-keep-cap-netbindservice:false
http-request-timeout:3600
enable-ipv4-fragment-tracking:true
enable-ingress-controller:false
custom-cni-conf:false
l2-announcements-lease-duration:15s
ipv4-service-loopback-address:169.254.42.1
enable-host-port:false
hubble-event-queue-size:0
enable-k8s-networkpolicy:true
encrypt-node:false
disable-iptables-feeder-rules:
mesh-auth-mutual-connect-timeout:5s
api-rate-limit:
hubble-export-fieldmask:
kvstore-opt:
dns-policy-unload-on-shutdown:false
bpf-lb-sock-hostns-only:false
restore:true
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
tofqdns-proxy-port:0
vtep-cidr:
cni-external-routing:false
enable-ipv4-masquerade:true
log-driver:
hubble-disable-tls:false
bpf-root:/sys/fs/bpf
proxy-portrange-min:10000
bpf-auth-map-max:524288
proxy-max-connection-duration-seconds:0
container-ip-local-reserved-ports:auto
node-port-bind-protection:true
enable-ipv4-egress-gateway:false
enable-vtep:false
hubble-metrics:
bpf-lb-maglev-map-max:0
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
identity-change-grace-period:5s
bgp-announce-pod-cidr:false
ipv6-native-routing-cidr:
vtep-mac:
srv6-encap-mode:reduced
enable-mke:false
ipv6-cluster-alloc-cidr:f00d::/64
enable-ip-masq-agent:false
enable-ipsec-key-watcher:true
ipv6-mcast-device:
proxy-portrange-max:20000
config-dir:/tmp/cilium/config-map
enable-route-mtu-for-cni-chaining:false
ipam-default-ip-pool:default
cni-log-file:/var/run/cilium/cilium-cni.log
enable-session-affinity:false
bgp-announce-lb-ip:false
bpf-nat-global-max:524288
enable-tcx:true
egress-multi-home-ip-rule-compat:false
enable-xt-socket-fallback:true
bpf-events-trace-enabled:true
disable-endpoint-crd:false
bpf-lb-dsr-dispatch:opt
state-dir:/var/run/cilium
k8s-service-cache-size:128
bpf-sock-rev-map-max:262144
cgroup-root:/run/cilium/cgroupv2
enable-bbr:false
enable-runtime-device-detection:true
hubble-export-file-path:
labels:
cluster-name:cmesh2
cni-chaining-target:
enable-nat46x64-gateway:false
enable-health-check-nodeport:true
bpf-ct-global-tcp-max:524288
bpf-events-policy-verdict-enabled:true
k8s-require-ipv6-pod-cidr:false
fqdn-regex-compile-lru-size:1024
local-router-ipv4:
auto-direct-node-routes:false
enable-host-firewall:false
endpoint-gc-interval:5m0s
allocator-list-timeout:3m0s
bpf-lb-dsr-l4-xlate:frontend
hubble-redact-http-headers-deny:
enable-monitor:true
bpf-policy-map-full-reconciliation-interval:15m0s
enable-l2-pod-announcements:false
local-max-addr-scope:252
kvstore-periodic-sync:5m0s
preallocate-bpf-maps:false
enable-policy:default
derive-masq-ip-addr-from-device:
operator-api-serve-addr:127.0.0.1:9234
clustermesh-enable-endpoint-sync:false
bpf-ct-timeout-service-any:1m0s
socket-path:/var/run/cilium/cilium.sock
hubble-metrics-server:
node-port-algorithm:random
endpoint-bpf-prog-watchdog-interval:30s
clustermesh-sync-timeout:1m0s
enable-envoy-config:false
clustermesh-config:/var/lib/cilium/clustermesh/
proxy-idle-timeout-seconds:60
cluster-health-port:4240
fixed-identity-mapping:
ipsec-key-rotation-duration:5m0s
identity-gc-interval:15m0s
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
policy-audit-mode:false
kube-proxy-replacement:false
monitor-aggregation-interval:5s
ipv4-native-routing-cidr:
tofqdns-max-deferred-connection-deletes:10000
bpf-lb-map-max:65536
cni-exclusive:true
max-connected-clusters:255
max-controller-interval:0
enable-ipv4:true
enable-tracing:false
identity-heartbeat-timeout:30m0s
operator-prometheus-serve-addr::9963
http-max-grpc-timeout:0
allow-icmp-frag-needed:true
vtep-endpoint:
ipv4-service-range:auto
enable-ipsec-encrypted-overlay:false
enable-service-topology:false
bpf-lb-algorithm:random
ipv6-range:auto
mesh-auth-queue-size:1024
enable-bandwidth-manager:false
proxy-xff-num-trusted-hops-ingress:0
nat-map-stats-interval:30s
hubble-drop-events-reasons:auth_required,policy_denied
dnsproxy-lock-timeout:500ms
config-sources:config-map:kube-system/cilium-config
kvstore-lease-ttl:15m0s
keep-config:false
tunnel-port:0
enable-active-connection-tracking:false
tofqdns-idle-connection-grace-period:0s
local-router-ipv6:
bpf-map-event-buffers:
hubble-export-file-max-backups:5
enable-k8s-api-discovery:false
dns-max-ips-per-restored-rule:1000
cilium-endpoint-gc-interval:5m0s
mesh-auth-mutual-listener-port:0
enable-wireguard-userspace-fallback:false
dnsproxy-enable-transparent-mode:true
proxy-xff-num-trusted-hops-egress:0
enable-ipsec-xfrm-state-caching:true
nat-map-stats-entries:32
hubble-redact-kafka-apikey:false
hubble-flowlogs-config-path:
exclude-node-label-patterns:
allow-localhost:auto
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
envoy-base-id:0
disable-external-ip-mitigation:false
vlan-bpf-bypass:
bpf-ct-timeout-service-tcp:2h13m20s
node-port-mode:snat
tofqdns-dns-reject-response-code:refused
enable-l2-neigh-discovery:true
bpf-lb-affinity-map-max:0
k8s-kubeconfig-path:
label-prefix-file:
k8s-client-burst:20
bpf-lb-rev-nat-map-max:0
enable-xdp-prefilter:false
policy-queue-size:100
enable-endpoint-routes:false
node-port-acceleration:disabled
bpf-fragments-map-max:8192
http-normalize-path:true
bpf-lb-acceleration:disabled
bpf-ct-timeout-regular-tcp-syn:1m0s
annotate-k8s-node:false
enable-metrics:true
encrypt-interface:
static-cnp-path:
proxy-connect-timeout:2
egress-masquerade-interfaces:ens+
ip-masq-agent-config-path:/etc/config/ip-masq-agent
enable-bpf-tproxy:false
hubble-recorder-sink-queue-size:1024
synchronize-k8s-nodes:true
k8s-client-connection-keep-alive:30s
procfs:/host/proc
enable-external-ips:false
enable-bpf-masquerade:false
tofqdns-pre-cache:
hubble-drop-events:false
hubble-recorder-storage-path:/var/run/cilium/pcaps
hubble-export-file-max-size-mb:10
use-cilium-internal-ip-for-ipsec:false
enable-local-node-route:true
enable-custom-calls:false
certificates-directory:/var/run/cilium/certs
dnsproxy-concurrency-processing-grace-period:0s
enable-local-redirect-policy:false
enable-l2-announcements:false
hubble-export-file-compress:false
enable-ipv6-ndp:false
ipv4-range:auto
bpf-events-drop-enabled:true
enable-unreachable-routes:false
ipv6-node:auto
k8s-sync-timeout:3m0s
dnsproxy-socket-linger-timeout:10
k8s-service-proxy-name:
enable-node-selector-labels:false
enable-endpoint-health-checking:true
pprof-address:localhost
enable-srv6:false
cmdref:
tofqdns-proxy-response-max-delay:100ms
ipv4-node:auto
enable-recorder:false
mesh-auth-enabled:true
kvstore:
bpf-policy-map-max:16384
mtu:0
iptables-random-fully:false
multicast-enabled:false
envoy-secrets-namespace:
debug:false
policy-cidr-match-mode:
cluster-id:2
proxy-max-requests-per-connection:0
k8s-require-ipv4-pod-cidr:false
debug-verbose:
ipv4-pod-subnets:
cluster-pool-ipv4-mask-size:24
remove-cilium-node-taints:true
crd-wait-timeout:5m0s
enable-pmtu-discovery:false
enable-icmp-rules:true
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
bpf-ct-timeout-regular-any:1m0s
enable-ipip-termination:false
monitor-aggregation-flags:all
l2-announcements-renew-deadline:5s
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
proxy-admin-port:0
pprof:false
enable-ipv6-big-tcp:false
http-idle-timeout:0
monitor-aggregation:medium
version:false
nodeport-addresses:
ipv6-pod-subnets:
bpf-lb-service-backend-map-max:0
bpf-lb-maglev-table-size:16381
enable-identity-mark:true
enable-ipv6-masquerade:true
enable-cilium-endpoint-slice:false
enable-high-scale-ipcache:false
bpf-ct-timeout-regular-tcp-fin:10s
enable-k8s-endpoint-slice:true
enable-cilium-api-server-access:
hubble-socket-path:/var/run/cilium/hubble.sock
enable-gateway-api:false
enable-svc-source-range-check:true
log-system-load:false
hubble-redact-http-urlquery:false
mesh-auth-rotated-identities-queue-size:1024
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
hubble-event-buffer-capacity:4095
enable-k8s-terminating-endpoint:true
hubble-export-allowlist:
cluster-pool-ipv4-cidr:10.1.0.0/16
gateway-api-secrets-namespace:
http-retry-count:3
service-no-backend-response:reject
bpf-map-dynamic-size-ratio:0.0025
enable-node-port:false
force-device-detection:false
bpf-lb-service-map-max:0
cflags:
encryption-strict-mode-allow-remote-node-identities:false
enable-ipv4-big-tcp:false
enable-encryption-strict-mode:false
bpf-lb-sock:false
config:
gops-port:9890
conntrack-gc-interval:0s
enable-bpf-clock-probe:false
enable-hubble:true
k8s-client-connection-timeout:30s
enable-auto-protect-node-port-range:true
max-internal-timer-delay:0s
http-retry-timeout:0
bpf-ct-timeout-regular-tcp:2h13m20s
ipam-cilium-node-update-rate:15s
kube-proxy-replacement-healthz-bind-address:
endpoint-queue-size:25
policy-trigger-interval:1s
enable-masquerade-to-route-source:false
bpf-filter-priority:1
tofqdns-endpoint-max-ip-per-hostname:50
set-cilium-is-up-condition:true
bypass-ip-availability-upon-restore:false
monitor-queue-size:0
clustermesh-enable-mcs-api:false
prepend-iptables-chains:true
route-metric:0
arping-refresh-period:30s
vtep-mask:
prometheus-serve-addr:
use-full-tls-context:false
iptables-lock-timeout:5s
l2-announcements-retry-period:2s
unmanaged-pod-watcher-interval:15
k8s-api-server:
join-cluster:false
encryption-strict-mode-cidr:
enable-stale-cilium-endpoint-cleanup:true
bpf-lb-source-range-map-max:0
enable-well-known-identities:false
enable-wireguard:false
routing-mode:tunnel
tofqdns-min-ttl:0
tofqdns-enable-dns-compression:true
bpf-ct-timeout-service-tcp-grace:1m0s
enable-sctp:false
bgp-config-path:/var/lib/cilium/bgp/config.yaml
enable-l7-proxy:true
k8s-heartbeat-timeout:30s
hubble-export-denylist:
enable-ipsec:false
exclude-local-address:
set-cilium-node-taints:true
lib-dir:/var/lib/cilium
mesh-auth-spire-admin-socket:
envoy-config-retry-interval:15s
trace-sock:true
agent-health-port:9879
direct-routing-skip-unreachable:false
egress-gateway-reconciliation-trigger-interval:1s
log-opt:
hubble-skip-unknown-cgroup-ids:true
mesh-auth-gc-interval:5m0s
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
disable-envoy-version-check:false
mesh-auth-signal-backoff-duration:1s
hubble-redact-http-headers-allow:
trace-payloadlen:128
wireguard-persistent-keepalive:0s
proxy-gid:1337
enable-ipv6:false
identity-restore-grace-period:30s
ingress-secrets-namespace:
agent-liveness-update-interval:1s
install-no-conntrack-iptables-rules:false
nodes-gc-interval:5m0s
hubble-monitor-events:
envoy-log:
enable-host-legacy-routing:false
enable-bgp-control-plane:false
envoy-config-timeout:2m0s
node-labels:
bpf-lb-sock-terminate-pod-connections:false
auto-create-cilium-node-resource:true
external-envoy-proxy:true
enable-hubble-recorder-api:true
bpf-node-map-max:16384
enable-k8s:true
cni-chaining-mode:none
hubble-drop-events-interval:2m0s
ipsec-key-file:
bpf-lb-rss-ipv4-src-cidr:
kvstore-max-consecutive-quorum-errors:2
bpf-ct-global-any-max:262144
hubble-redact-enabled:false
node-port-range:
clustermesh-ip-identities-sync-timeout:1m0s
bpf-neigh-global-max:524288
install-iptables-rules:true
controller-group-metrics:
dnsproxy-lock-count:131
bpf-lb-mode:snat
k8s-client-qps:10
agent-labels:
egress-gateway-policy-map-max:16384
conntrack-gc-max-interval:0s
enable-health-checking:true
devices:
bpf-lb-external-clusterip:false
enable-health-check-loadbalancer-ip:false
hubble-prefer-ipv6:false
hubble-listen-address::4244
k8s-namespace:kube-system
datapath-mode:veth
bpf-lb-rss-ipv6-src-cidr:
tunnel-protocol:vxlan
mesh-auth-spiffe-trust-domain:spiffe.cilium
ipam:cluster-pool
l2-pod-announcements-interface:
enable-cilium-health-api-server-access:
policy-accounting:true
pprof-port:6060
kvstore-connectivity-timeout:2m0s
ipam-multi-pool-pre-allocation:
direct-routing-device:
mke-cgroup-mount:
ipv6-service-range:auto
read-cni-conf:
proxy-prometheus-port:0
metrics:
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4         STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                   
596        Disabled           Disabled          4          reserved:health                                                                     10.1.0.172   ready   
849        Disabled           Disabled          135171     k8s:eks.amazonaws.com/component=coredns                                             10.1.0.71    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh2                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                          
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                              
                                                           k8s:k8s-app=kube-dns                                                                                     
1390       Disabled           Disabled          145489     k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.1.0.46    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh2                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                              
                                                           k8s:k8s-app=clustermesh-apiserver                                                                        
1462       Disabled           Disabled          135171     k8s:eks.amazonaws.com/component=coredns                                             10.1.0.180   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh2                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                          
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                              
                                                           k8s:k8s-app=kube-dns                                                                                     
1834       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                  ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                    
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                              
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                               
                                                           reserved:host                                                                                            
```

#### BPF Policy Get 596

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    425771   5431      0        
Allow    Ingress     1          ANY          NONE         disabled    12536    145       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 596

```
Invalid argument: unknown type 596
```


#### Endpoint Get 596

```
[
  {
    "id": 596,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-596-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "2ac35816-ddea-4d93-b893-03cbe50a9d77"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-596",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:43.437Z",
            "success-count": 4
          },
          "uuid": "01b55ddc-f42e-4f13-b19d-c80f7555530b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-596",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:46.731Z",
            "success-count": 2
          },
          "uuid": "3b535126-85ea-4453-841b-d6d7e7ca2383"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:43Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.1.0.172",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "56:d8:89:6e:5c:aa",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "52:e1:b8:9d:29:4d"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 596

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 596

```
Timestamp              Status   State                   Message
2024-10-25T10:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:43Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:46Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:46Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:13:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:13:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:43Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:43Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:42Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 849

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    86671   1000      0        
Allow    Egress      0          ANY          NONE         disabled    14253   149       0        

```


#### BPF CT List 849

```
Invalid argument: unknown type 849
```


#### Endpoint Get 849

```
[
  {
    "id": 849,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-849-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "efcdcbfc-598e-4b49-b039-52b71ed2eaaf"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-849",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:43.788Z",
            "success-count": 4
          },
          "uuid": "4cdd412b-0130-4554-b5cf-b8e68bc36f50"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-rdkcg",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:13:43.786Z",
            "success-count": 1
          },
          "uuid": "74c33275-3103-41fb-9c50-855b8646036a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-849",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:46.733Z",
            "success-count": 2
          },
          "uuid": "4cc24918-36db-4c75-93fe-48fc7275fcbe"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (849)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:03.875Z",
            "success-count": 94
          },
          "uuid": "443adf83-b087-4e1c-a910-22acdc018496"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "ecb23351b975ead3e22d1085b7156529a7614da26b4608e10dc0c503442884d4:eth0",
        "container-id": "ecb23351b975ead3e22d1085b7156529a7614da26b4608e10dc0c503442884d4",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-rdkcg",
        "pod-name": "kube-system/coredns-cc6ccd49c-rdkcg"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 135171,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh2",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh2",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:43Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.1.0.71",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ce:68:4f:6c:d8:b4",
        "interface-index": 9,
        "interface-name": "lxc90a7cee7e57c",
        "mac": "2e:65:eb:3a:e7:ea"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 135171,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 135171,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 849

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 849

```
Timestamp              Status    State                   Message
2024-10-25T10:22:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:43Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:22:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:42Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:42Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:42Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:42Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:41Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:41Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:41Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:41Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:15Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:15Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:15Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:15Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:14Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:14Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:14Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:14Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:46Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:46Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:45Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:44Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:13:44Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:13:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:43Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:13:43Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:43Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 135171

```
ID       LABELS
135171   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh2
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1390

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3840226   36444     0        
Allow    Ingress     1          ANY          NONE         disabled    3140856   31800     0        
Allow    Egress      0          ANY          NONE         disabled    4927512   45334     0        

```


#### BPF CT List 1390

```
Invalid argument: unknown type 1390
```


#### Endpoint Get 1390

```
[
  {
    "id": 1390,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1390-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "6ede83e0-21d6-4a72-849b-4f8cc3675a2e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1390",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:43.650Z",
            "success-count": 2
          },
          "uuid": "c918aabc-0100-4a5d-a21e-2d438a82a368"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-6f65fcb5cc-qhmjp",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:43.648Z",
            "success-count": 1
          },
          "uuid": "d84693d9-b599-45ef-93ae-45243735d38c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1390",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:43.678Z",
            "success-count": 1
          },
          "uuid": "e3ac4f24-e9a6-4c53-850e-7d33826e216c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1390)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:03.722Z",
            "success-count": 46
          },
          "uuid": "b4a02159-b081-4b75-bd8d-e6032e166f2a"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "dd879235fc7919fb0cb573fa1f4639866153de0c8adb97553a4abc05422afd79:eth0",
        "container-id": "dd879235fc7919fb0cb573fa1f4639866153de0c8adb97553a4abc05422afd79",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-6f65fcb5cc-qhmjp",
        "pod-name": "kube-system/clustermesh-apiserver-6f65fcb5cc-qhmjp"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 145489,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh2",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6f65fcb5cc"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh2",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:43Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.1.0.46",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "c2:6d:c8:6c:f9:ab",
        "interface-index": 15,
        "interface-name": "lxc2a516d0414c6",
        "mac": "c6:40:ea:25:46:19"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 145489,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 145489,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1390

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1390

```
Timestamp              Status   State                   Message
2024-10-25T10:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:43Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:43Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:43Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:43Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 145489

```
ID       LABELS
145489   k8s:app.kubernetes.io/name=clustermesh-apiserver
         k8s:app.kubernetes.io/part-of=cilium
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh2
         k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1462

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    86058   988       0        
Allow    Egress      0          ANY          NONE         disabled    12502   130       0        

```


#### BPF CT List 1462

```
Invalid argument: unknown type 1462
```


#### Endpoint Get 1462

```
[
  {
    "id": 1462,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1462-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b0e55e9c-9bb8-418e-bc47-b7ee2791d1d5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1462",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:43.790Z",
            "success-count": 4
          },
          "uuid": "14bf5418-aa8c-471a-9f72-28952d7e9c32"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-bsslx",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:13:43.786Z",
            "success-count": 1
          },
          "uuid": "988578d6-6552-4b29-99df-9bafb3fab5f5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1462",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:46.768Z",
            "success-count": 2
          },
          "uuid": "e8c172af-afa9-4a98-b6b2-b87aa7ef6451"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1462)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:03.874Z",
            "success-count": 94
          },
          "uuid": "ec4f9eec-9b00-4024-ae8e-f16f2539a953"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "8679a593a618763b162b6975a30ca0b083a078bf47fcda7bb999f4e984d0ac7c:eth0",
        "container-id": "8679a593a618763b162b6975a30ca0b083a078bf47fcda7bb999f4e984d0ac7c",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-bsslx",
        "pod-name": "kube-system/coredns-cc6ccd49c-bsslx"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 135171,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh2",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh2",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:43Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.1.0.180",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "f2:78:8e:01:5a:80",
        "interface-index": 11,
        "interface-name": "lxc3f3118319f98",
        "mac": "66:21:37:37:5a:d1"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 135171,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 135171,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1462

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1462

```
Timestamp              Status    State                   Message
2024-10-25T10:22:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:43Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:22:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:42Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:42Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:42Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:42Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:41Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:41Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:41Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:41Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:15Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:15Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:15Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:15Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:14Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:14Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:14Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:14Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:46Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:46Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:46Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:44Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:13:44Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:13:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:43Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:13:43Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:43Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 135171

```
ID       LABELS
135171   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh2
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1834

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1834

```
Invalid argument: unknown type 1834
```


#### Endpoint Get 1834

```
[
  {
    "id": 1834,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1834-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "6cc28a97-d90c-4046-a6d9-bfa8e030ac63"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1834",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:42.344Z",
            "success-count": 4
          },
          "uuid": "4f3eac5e-bf4a-49e4-84f8-fc2dfc6c17a8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1834",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:43.431Z",
            "success-count": 2
          },
          "uuid": "1156a65c-8c39-4d5a-ae23-791796f29cc7"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:43Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "c2:69:34:de:1e:5e",
        "interface-name": "cilium_host",
        "mac": "c2:69:34:de:1e:5e"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1834

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1834

```
Timestamp              Status   State                   Message
2024-10-25T10:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:43Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:13:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:46Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:13:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:13:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:13:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:42Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:42Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:42Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### Service list

```
ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.157.33:443 (active)     
                                         2 => 172.31.202.18:443 (active)     
2    10.100.115.38:443    ClusterIP      1 => 172.31.197.251:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.1.0.180:53 (active)         
                                         2 => 10.1.0.71:53 (active)          
4    10.100.0.10:9153     ClusterIP      1 => 10.1.0.180:9153 (active)       
                                         2 => 10.1.0.71:9153 (active)        
5    10.100.244.78:2379   ClusterIP      1 => 10.1.0.46:2379 (active)        
```

#### Policy get

```
:
 []
Revision: 1

```

