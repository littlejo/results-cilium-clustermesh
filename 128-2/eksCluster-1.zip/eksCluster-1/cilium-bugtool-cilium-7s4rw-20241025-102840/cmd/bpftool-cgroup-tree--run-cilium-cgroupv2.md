CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7650d8ba_9937_4959_bbe2_2b527fc547b2.slice/cri-containerd-ca878e4017d5614eb7f4a7a5bea2f7977a31f4f6fe23666bb6fdbcacf4db253b.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7650d8ba_9937_4959_bbe2_2b527fc547b2.slice/cri-containerd-ccff2e4901d114a939494589ac73964574c32b043a8fd81fbb41ba871ad0b89a.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6a7ed771_cc0b_401d_8471_10aab0a03730.slice/cri-containerd-7c7abd66cb03d22f089cc739d180472293d5317de0faa5bedaab299021bba0e5.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6a7ed771_cc0b_401d_8471_10aab0a03730.slice/cri-containerd-8679a593a618763b162b6975a30ca0b083a078bf47fcda7bb999f4e984d0ac7c.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode7d7b83c_be13_4820_a9f8_9e1dffae52e8.slice/cri-containerd-1f6adeb288ca40bb3cc4b9831309c5e3be3bb708585946c3ea6b3fd96dbe85e5.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode7d7b83c_be13_4820_a9f8_9e1dffae52e8.slice/cri-containerd-ecb23351b975ead3e22d1085b7156529a7614da26b4608e10dc0c503442884d4.scope
    540      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4bb53cfe_fa7b_409e_b6f3_9e2723efd46b.slice/cri-containerd-18ab6348293065183fb4fdd39db77fec39c975f9dab7209b1b734c0f7c820f14.scope
    71       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4bb53cfe_fa7b_409e_b6f3_9e2723efd46b.slice/cri-containerd-4f8b4377c9723eb1ed13c843b2fe3a0a239439830466d3aa016fb36490092a20.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff66db98_fc96_4d6f_bf2a_f2efff6d7016.slice/cri-containerd-307b53ed2e2cf5f72fa30a3929b80293a2cf2fed15f2c1c14de8e60682577be5.scope
    622      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff66db98_fc96_4d6f_bf2a_f2efff6d7016.slice/cri-containerd-dd879235fc7919fb0cb573fa1f4639866153de0c8adb97553a4abc05422afd79.scope
    606      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff66db98_fc96_4d6f_bf2a_f2efff6d7016.slice/cri-containerd-92b742358ca1967636ec63eccecf587072f75daaddb2c8a8f07d7f8e59857b40.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff66db98_fc96_4d6f_bf2a_f2efff6d7016.slice/cri-containerd-50ac5a5b2d76c3f634d321ea16d657dd00aaf80904e1a07724519ba5bc13c3f0.scope
    630      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a8dcc46_6dd7_4f36_a736_459d83d7616b.slice/cri-containerd-f2cc2815900bec78770df2912c85727adbd17f79f96bd874ebe09449f51356fe.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a8dcc46_6dd7_4f36_a736_459d83d7616b.slice/cri-containerd-6e4fe197e61703799bd90528a291e61406351f5876abe40874207b90a8debc45.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poded4b6317_9ab2_4f7c_94f0_cf6d5b191d54.slice/cri-containerd-56b970d21813bc779b299e709958629229b3ce25f2240c58e814a552e322dc3c.scope
    64       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poded4b6317_9ab2_4f7c_94f0_cf6d5b191d54.slice/cri-containerd-40c92904e00fdf9d6faacbb96b00eac9186ad77ff9d0b5094a72337515b530f9.scope
    75       cgroup_device   multi                                          
