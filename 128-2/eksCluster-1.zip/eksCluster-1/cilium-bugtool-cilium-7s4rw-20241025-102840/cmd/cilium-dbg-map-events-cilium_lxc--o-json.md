{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:42.187Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.197.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:42.187Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:46.729Z",
  "value": "id=596   sec_id=4     flags=0x0000 ifindex=7   mac=52:E1:B8:9D:29:4D nodemac=56:D8:89:6E:5C:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:46.732Z",
  "value": "id=849   sec_id=135171 flags=0x0000 ifindex=9   mac=2E:65:EB:3A:E7:EA nodemac=CE:68:4F:6C:D8:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:46.766Z",
  "value": "id=1462  sec_id=135171 flags=0x0000 ifindex=11  mac=66:21:37:37:5A:D1 nodemac=F2:78:8E:01:5A:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:46.818Z",
  "value": "id=596   sec_id=4     flags=0x0000 ifindex=7   mac=52:E1:B8:9D:29:4D nodemac=56:D8:89:6E:5C:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:14.371Z",
  "value": "id=596   sec_id=4     flags=0x0000 ifindex=7   mac=52:E1:B8:9D:29:4D nodemac=56:D8:89:6E:5C:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:14.372Z",
  "value": "id=849   sec_id=135171 flags=0x0000 ifindex=9   mac=2E:65:EB:3A:E7:EA nodemac=CE:68:4F:6C:D8:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:14.372Z",
  "value": "id=1462  sec_id=135171 flags=0x0000 ifindex=11  mac=66:21:37:37:5A:D1 nodemac=F2:78:8E:01:5A:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:14.402Z",
  "value": "id=883   sec_id=145489 flags=0x0000 ifindex=13  mac=4A:4C:F0:6E:6F:74 nodemac=FE:BF:3A:A8:33:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:15.372Z",
  "value": "id=883   sec_id=145489 flags=0x0000 ifindex=13  mac=4A:4C:F0:6E:6F:74 nodemac=FE:BF:3A:A8:33:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:15.372Z",
  "value": "id=596   sec_id=4     flags=0x0000 ifindex=7   mac=52:E1:B8:9D:29:4D nodemac=56:D8:89:6E:5C:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:15.372Z",
  "value": "id=849   sec_id=135171 flags=0x0000 ifindex=9   mac=2E:65:EB:3A:E7:EA nodemac=CE:68:4F:6C:D8:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:15.372Z",
  "value": "id=1462  sec_id=135171 flags=0x0000 ifindex=11  mac=66:21:37:37:5A:D1 nodemac=F2:78:8E:01:5A:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:43.677Z",
  "value": "id=1390  sec_id=145489 flags=0x0000 ifindex=15  mac=C6:40:EA:25:46:19 nodemac=C2:6D:C8:6C:F9:AB"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.1.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:54.028Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:41.695Z",
  "value": "id=1462  sec_id=135171 flags=0x0000 ifindex=11  mac=66:21:37:37:5A:D1 nodemac=F2:78:8E:01:5A:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:41.695Z",
  "value": "id=1390  sec_id=145489 flags=0x0000 ifindex=15  mac=C6:40:EA:25:46:19 nodemac=C2:6D:C8:6C:F9:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:41.696Z",
  "value": "id=596   sec_id=4     flags=0x0000 ifindex=7   mac=52:E1:B8:9D:29:4D nodemac=56:D8:89:6E:5C:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:41.696Z",
  "value": "id=849   sec_id=135171 flags=0x0000 ifindex=9   mac=2E:65:EB:3A:E7:EA nodemac=CE:68:4F:6C:D8:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:42.696Z",
  "value": "id=596   sec_id=4     flags=0x0000 ifindex=7   mac=52:E1:B8:9D:29:4D nodemac=56:D8:89:6E:5C:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:42.696Z",
  "value": "id=849   sec_id=135171 flags=0x0000 ifindex=9   mac=2E:65:EB:3A:E7:EA nodemac=CE:68:4F:6C:D8:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:42.696Z",
  "value": "id=1462  sec_id=135171 flags=0x0000 ifindex=11  mac=66:21:37:37:5A:D1 nodemac=F2:78:8E:01:5A:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:42.697Z",
  "value": "id=1390  sec_id=145489 flags=0x0000 ifindex=15  mac=C6:40:EA:25:46:19 nodemac=C2:6D:C8:6C:F9:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:43.696Z",
  "value": "id=1462  sec_id=135171 flags=0x0000 ifindex=11  mac=66:21:37:37:5A:D1 nodemac=F2:78:8E:01:5A:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:43.696Z",
  "value": "id=596   sec_id=4     flags=0x0000 ifindex=7   mac=52:E1:B8:9D:29:4D nodemac=56:D8:89:6E:5C:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:43.696Z",
  "value": "id=1390  sec_id=145489 flags=0x0000 ifindex=15  mac=C6:40:EA:25:46:19 nodemac=C2:6D:C8:6C:F9:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:43.696Z",
  "value": "id=849   sec_id=135171 flags=0x0000 ifindex=9   mac=2E:65:EB:3A:E7:EA nodemac=CE:68:4F:6C:D8:B4"
}

