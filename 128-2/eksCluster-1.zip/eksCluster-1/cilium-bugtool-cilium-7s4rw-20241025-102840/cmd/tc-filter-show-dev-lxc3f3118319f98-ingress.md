filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc3f3118319f98 direct-action not_in_hw id 493 tag c4ed21e407a0e290 jited 
