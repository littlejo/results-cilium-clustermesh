markdown output at /tmp/cilium-bugtool-20241025-102841.584+0000-UTC-572899236/cmd/cilium-debuginfo-20241025-102912.157+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102841.584+0000-UTC-572899236/cmd/cilium-debuginfo-20241025-102912.157+0000-UTC.json
