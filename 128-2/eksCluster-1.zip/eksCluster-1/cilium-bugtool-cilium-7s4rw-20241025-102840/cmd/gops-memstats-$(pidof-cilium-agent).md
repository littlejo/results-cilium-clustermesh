alloc: 126.25MB (132377856 bytes)
total-alloc: 1.36GB (1456595992 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 48145362
frees: 46889060
heap-alloc: 126.25MB (132377856 bytes)
heap-sys: 165.27MB (173293568 bytes)
heap-idle: 21.66MB (22708224 bytes)
heap-in-use: 143.61MB (150585344 bytes)
heap-released: 1.90MB (1990656 bytes)
heap-objects: 1256302
stack-in-use: 34.69MB (36372480 bytes)
stack-sys: 34.69MB (36372480 bytes)
stack-mspan-inuse: 2.23MB (2335680 bytes)
stack-mspan-sys: 2.43MB (2545920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 959.94KB (982977 bytes)
gc-sys: 5.16MB (5408976 bytes)
next-gc: when heap-alloc >= 147.71MB (154880920 bytes)
last-gc: 2024-10-25 10:28:42.550898662 +0000 UTC
gc-pause-total: 12.945831ms
gc-pause: 431265
gc-pause-end: 1729852122550898662
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00036695276384584316
enable-gc: true
debug-gc: false
