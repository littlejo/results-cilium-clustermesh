IP ADDRESS         LOCAL ENDPOINT INFO
10.1.0.172:0       id=596   sec_id=4     flags=0x0000 ifindex=7   mac=52:E1:B8:9D:29:4D nodemac=56:D8:89:6E:5C:AA    
10.1.0.71:0        id=849   sec_id=135171 flags=0x0000 ifindex=9   mac=2E:65:EB:3A:E7:EA nodemac=CE:68:4F:6C:D8:B4   
10.1.0.180:0       id=1462  sec_id=135171 flags=0x0000 ifindex=11  mac=66:21:37:37:5A:D1 nodemac=F2:78:8E:01:5A:80   
172.31.197.251:0   (localhost)                                                                                       
10.1.0.46:0        id=1390  sec_id=145489 flags=0x0000 ifindex=15  mac=C6:40:EA:25:46:19 nodemac=C2:6D:C8:6C:F9:AB   
10.1.0.212:0       (localhost)                                                                                       
