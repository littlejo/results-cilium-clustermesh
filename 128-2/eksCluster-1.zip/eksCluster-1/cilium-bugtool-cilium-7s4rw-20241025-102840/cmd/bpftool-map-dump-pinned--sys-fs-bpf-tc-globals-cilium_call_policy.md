key: 54 02 00 00  value: 17 02 00 00
key: 51 03 00 00  value: e8 01 00 00
key: 6e 05 00 00  value: 56 02 00 00
key: b6 05 00 00  value: f8 01 00 00
Found 4 elements
