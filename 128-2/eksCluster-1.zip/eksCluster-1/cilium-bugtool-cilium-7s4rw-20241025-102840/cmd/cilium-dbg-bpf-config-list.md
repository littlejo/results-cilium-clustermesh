KEY             VALUE
AgentLiveness   982746594244
UTimeOffset     3378615564453125
