CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5ab3e77b_a9c4_4d65_841c_a0a9ee055a1a.slice/cri-containerd-4e5f38fe11149e8cee50e8b9000a7e807357a30591ff26b638661e865bb3544f.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5ab3e77b_a9c4_4d65_841c_a0a9ee055a1a.slice/cri-containerd-f836d0bc5400c9d4077fe33734bafe2bed0fd98c26dfbaf2d9b09b24f94dd5a9.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbb9710fb_8f44_4363_b1c5_b0cd885598e3.slice/cri-containerd-7facbba01557c6851d7a35d87d78cdcc824a4fd109f9cc57262a4e4f0c7aef88.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbb9710fb_8f44_4363_b1c5_b0cd885598e3.slice/cri-containerd-aeeba9e605313524cc8dac291954d97c2f06a3b6dc97db9ac3eecb020d0b63c9.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbe62976c_a5ae_4943_8297_9c3e9d194017.slice/cri-containerd-6a07b69eeb1f97022f6450fc1664f78fb4dd17bd8e4444ff0881a6c8a6500758.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbe62976c_a5ae_4943_8297_9c3e9d194017.slice/cri-containerd-1dddd9292b52fcf981f86561418b6d2e0e11d3e77700c63d031ee8733628f3ef.scope
    541      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podab07bb70_8d1a_4d86_ab92_a44cdc59ed9b.slice/cri-containerd-a6339a640f29ec8788fd602e68f4990b8ca148adb1d091da2812452b77d16d79.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podab07bb70_8d1a_4d86_ab92_a44cdc59ed9b.slice/cri-containerd-b4c636a04f0537b854c74e7fe258cb7583805697e62c253f2e45da046542fe06.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podddf711d1_21af_49b8_a198_00b0c6d3244e.slice/cri-containerd-20844bea673e520b55ff8c82438a961db80a1edfe204336a5475b606d1d8004e.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podddf711d1_21af_49b8_a198_00b0c6d3244e.slice/cri-containerd-b7fa1e42507502a3b0e1412c5b8a38c9192829fc753f8eabc3fb14702eece8d3.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b55f348_60da_4063_9311_14bd301b77a5.slice/cri-containerd-5c5000a7e9c19a2004ae324dec7be852f86a11d3e8599b56b8b7458d33ad926f.scope
    113      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b55f348_60da_4063_9311_14bd301b77a5.slice/cri-containerd-9e0e1713267e2408bfd44ee6db70ebf889f13f1f29241f3991eef6965814c651.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a11efe1_94b7_47fa_9480_6a84c3425a0b.slice/cri-containerd-7b91fc9fe35e2adbf7460a4170b972ef6a7ca0bfe5974ca2a7f42f0ceb155b6c.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a11efe1_94b7_47fa_9480_6a84c3425a0b.slice/cri-containerd-6aaf096a11a9315a261f186abb2a363105d4464eb4aa18944d69026df8a17b0c.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a11efe1_94b7_47fa_9480_6a84c3425a0b.slice/cri-containerd-a72693329c850281445e8a276ce0ac481509bc4d7fcdeff47e513ff45a1971b0.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a11efe1_94b7_47fa_9480_6a84c3425a0b.slice/cri-containerd-28ab76b970a000ac65c73b86eb3f0e7f58df0a41dbfccf031ffe0487d320c2f6.scope
    640      cgroup_device   multi                                          
