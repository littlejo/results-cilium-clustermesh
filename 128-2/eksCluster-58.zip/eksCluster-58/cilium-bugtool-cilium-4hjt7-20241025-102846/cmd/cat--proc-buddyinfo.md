Node 0, zone      DMA      4      5      4     28      4      1      9      8      3      3    159 
Node 0, zone   Normal    144      4      8      2     15     12      3      2      1      2      8 
