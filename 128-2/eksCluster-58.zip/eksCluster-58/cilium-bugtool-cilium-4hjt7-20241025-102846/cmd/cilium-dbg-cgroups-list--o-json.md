[
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a11efe1_94b7_47fa_9480_6a84c3425a0b.slice/cri-containerd-6aaf096a11a9315a261f186abb2a363105d4464eb4aa18944d69026df8a17b0c.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a11efe1_94b7_47fa_9480_6a84c3425a0b.slice/cri-containerd-a72693329c850281445e8a276ce0ac481509bc4d7fcdeff47e513ff45a1971b0.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a11efe1_94b7_47fa_9480_6a84c3425a0b.slice/cri-containerd-7b91fc9fe35e2adbf7460a4170b972ef6a7ca0bfe5974ca2a7f42f0ceb155b6c.scope"
      }
    ],
    "ips": [
      "10.58.0.134"
    ],
    "name": "clustermesh-apiserver-7d9f745589-mr5g8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podab07bb70_8d1a_4d86_ab92_a44cdc59ed9b.slice/cri-containerd-a6339a640f29ec8788fd602e68f4990b8ca148adb1d091da2812452b77d16d79.scope"
      }
    ],
    "ips": [
      "10.58.0.129"
    ],
    "name": "coredns-cc6ccd49c-n27t9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbe62976c_a5ae_4943_8297_9c3e9d194017.slice/cri-containerd-6a07b69eeb1f97022f6450fc1664f78fb4dd17bd8e4444ff0881a6c8a6500758.scope"
      }
    ],
    "ips": [
      "10.58.0.84"
    ],
    "name": "coredns-cc6ccd49c-7wglv",
    "namespace": "kube-system"
  }
]

