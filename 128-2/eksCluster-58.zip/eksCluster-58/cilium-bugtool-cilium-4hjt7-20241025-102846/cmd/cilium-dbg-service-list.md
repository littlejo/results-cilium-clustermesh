ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.164.131:443 (active)   
                                          2 => 172.31.219.0:443 (active)     
2    10.100.24.61:443      ClusterIP      1 => 172.31.172.29:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.58.0.129:53 (active)       
                                          2 => 10.58.0.84:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.58.0.129:9153 (active)     
                                          2 => 10.58.0.84:9153 (active)      
5    10.100.139.166:2379   ClusterIP      1 => 10.58.0.134:2379 (active)     
