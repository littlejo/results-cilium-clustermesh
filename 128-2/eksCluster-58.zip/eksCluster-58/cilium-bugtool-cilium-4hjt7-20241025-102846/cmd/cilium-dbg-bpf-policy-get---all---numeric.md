Endpoint ID: 731
Path: /sys/fs/bpf/tc/globals/cilium_policy_00731

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    76666   881       0        
Allow    Egress      0          ANY          NONE         disabled    13752   142       0        


Endpoint ID: 1161
Path: /sys/fs/bpf/tc/globals/cilium_policy_01161

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    78409   905       0        
Allow    Egress      0          ANY          NONE         disabled    13256   137       0        


Endpoint ID: 1709
Path: /sys/fs/bpf/tc/globals/cilium_policy_01709

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3913775   36786     0        
Allow    Ingress     1          ANY          NONE         disabled    2847693   28488     0        
Allow    Egress      0          ANY          NONE         disabled    4570480   42484     0        


Endpoint ID: 3315
Path: /sys/fs/bpf/tc/globals/cilium_policy_03315

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3560
Path: /sys/fs/bpf/tc/globals/cilium_policy_03560

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    442040   5640      0        
Allow    Ingress     1          ANY          NONE         disabled    10310    117       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


