35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:14:28+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
110: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
113: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:15:37+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
485: sched_cls  name tail_handle_ipv4  tag e055a0133d49cfe3  gpl
	loaded_at 2024-10-25T10:15:37+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
486: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:15:37+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
487: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:15:37+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
510: sched_cls  name cil_from_container  tag 0ddd3f3b5311c7bd  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 108,76
	btf_id 153
511: sched_cls  name __send_drop_notify  tag 652dc1464092231b  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 154
512: sched_cls  name tail_ipv4_ct_ingress  tag 1f4edf281b55b2b9  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 155
513: sched_cls  name tail_handle_ipv4  tag 3dee2e0453b22ff1  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,108
	btf_id 156
514: sched_cls  name tail_handle_ipv4_cont  tag 364d9f3a14f2ab0a  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,107,41,106,82,83,39,76,74,77,108,40,37,38,81
	btf_id 157
515: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,108
	btf_id 158
516: sched_cls  name tail_ipv4_to_endpoint  tag 7b464a60f1963ec2  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,107,41,82,83,80,106,39,108,40,37,38
	btf_id 159
517: sched_cls  name tail_handle_arp  tag c10db3164364548d  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,108
	btf_id 160
518: sched_cls  name tail_ipv4_ct_egress  tag e1a408d71e3e1d5a  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 161
520: sched_cls  name handle_policy  tag 128da841a2b1d5b3  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,108,82,83,107,41,80,106,39,84,75,40,37,38
	btf_id 163
521: sched_cls  name tail_ipv4_ct_egress  tag e1a408d71e3e1d5a  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 165
522: sched_cls  name tail_ipv4_to_endpoint  tag 4f40ec59a278c22c  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,110,41,82,83,80,100,39,109,40,37,38
	btf_id 166
523: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,109
	btf_id 167
524: sched_cls  name handle_policy  tag 2880cc5f7b734af5  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,109,82,83,110,41,80,100,39,84,75,40,37,38
	btf_id 168
525: sched_cls  name __send_drop_notify  tag 3824ad9da964d564  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 169
526: sched_cls  name cil_from_container  tag e4338a1417edfb07  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 109,76
	btf_id 170
528: sched_cls  name tail_handle_ipv4  tag 99dcbea47e37fbc8  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,109
	btf_id 172
529: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
532: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
533: sched_cls  name tail_handle_ipv4_cont  tag bdcce53f8ded2ba2  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,110,41,100,82,83,39,76,74,77,109,40,37,38,81
	btf_id 173
534: sched_cls  name tail_handle_arp  tag 493b685ff8c84f93  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,109
	btf_id 174
535: sched_cls  name tail_ipv4_ct_ingress  tag 830d484f72095ad1  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 175
536: sched_cls  name tail_handle_ipv4  tag c73cd376fcf39ba8  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 177
538: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
541: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
542: sched_cls  name tail_ipv4_to_endpoint  tag 8f6901710bb21018  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,112,41,82,83,80,101,39,113,40,37,38
	btf_id 179
543: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 180
544: sched_cls  name tail_ipv4_ct_ingress  tag a4ce7120f8ca2bf4  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 181
545: sched_cls  name tail_handle_ipv4_cont  tag dbaf081cf15d8a37  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,112,41,101,82,83,39,76,74,77,113,40,37,38,81
	btf_id 182
546: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 183
547: sched_cls  name handle_policy  tag 198b3df7008d85e9  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,113,82,83,112,41,80,101,39,84,75,40,37,38
	btf_id 184
548: sched_cls  name __send_drop_notify  tag 4785c0b8170d3150  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 185
549: sched_cls  name cil_from_container  tag e500761f9a8bb144  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 113,76
	btf_id 186
550: sched_cls  name tail_handle_arp  tag 9186633d3e225133  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 187
551: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
554: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
555: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
558: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
559: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 189
561: sched_cls  name __send_drop_notify  tag 76ccb440b91a4cc4  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 191
562: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 192
563: sched_cls  name tail_handle_ipv4_from_host  tag 239d29c6d9bd0899  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 193
564: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 194
566: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 197
570: sched_cls  name __send_drop_notify  tag 76ccb440b91a4cc4  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
571: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 202
572: sched_cls  name tail_handle_ipv4_from_host  tag 239d29c6d9bd0899  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 203
573: sched_cls  name tail_handle_ipv4_from_host  tag 239d29c6d9bd0899  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 205
574: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 206
575: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 207
578: sched_cls  name __send_drop_notify  tag 76ccb440b91a4cc4  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 210
582: sched_cls  name __send_drop_notify  tag 76ccb440b91a4cc4  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 215
584: sched_cls  name tail_handle_ipv4_from_host  tag 239d29c6d9bd0899  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 217
585: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 218
586: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 219
626: sched_cls  name __send_drop_notify  tag 1abd1ff1359edc42  gpl
	loaded_at 2024-10-25T10:22:09+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 233
627: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:09+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 234
628: sched_cls  name tail_ipv4_ct_egress  tag 1ce4ff875f16132a  gpl
	loaded_at 2024-10-25T10:22:09+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 235
629: sched_cls  name cil_from_container  tag 04b8650552699c0d  gpl
	loaded_at 2024-10-25T10:22:09+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 236
630: sched_cls  name tail_handle_ipv4  tag ddc3447d1ccd5e3e  gpl
	loaded_at 2024-10-25T10:22:09+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 237
631: sched_cls  name tail_ipv4_ct_ingress  tag be9769328178f4c3  gpl
	loaded_at 2024-10-25T10:22:09+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 238
632: sched_cls  name tail_ipv4_to_endpoint  tag d42d47c9edec699a  gpl
	loaded_at 2024-10-25T10:22:09+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 239
633: sched_cls  name handle_policy  tag a87d0e04da1b7f05  gpl
	loaded_at 2024-10-25T10:22:09+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 240
634: sched_cls  name tail_handle_arp  tag 1920ebfda01a3b62  gpl
	loaded_at 2024-10-25T10:22:09+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 241
635: sched_cls  name tail_handle_ipv4_cont  tag 2a7f252754b7568d  gpl
	loaded_at 2024-10-25T10:22:09+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 242
637: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
640: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
653: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
656: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
657: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
660: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
