# Cilium debug information

#### Policy get

```
:
 []
Revision: 1

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.58.0.129": (string) (len=35) "kube-system/coredns-cc6ccd49c-n27t9",
  (string) (len=11) "10.58.0.134": (string) (len=50) "kube-system/clustermesh-apiserver-7d9f745589-mr5g8",
  (string) (len=10) "10.58.0.38": (string) (len=6) "router",
  (string) (len=11) "10.58.0.234": (string) (len=6) "health",
  (string) (len=10) "10.58.0.84": (string) (len=35) "kube-system/coredns-cc6ccd49c-7wglv"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.172.29": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40023089a0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x400080c300,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x400080c300,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4002308790)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4002308a50)(frontends:[10.100.24.61]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4002308bb0)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x40034f4e70)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40034f4f20)(frontends:[10.100.139.166]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x40015cc2a8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-qb7m6": (*k8s.Endpoints)(0x40033528f0)(10.58.0.129:53/TCP[eu-west-3a],10.58.0.129:53/UDP[eu-west-3a],10.58.0.129:9153/TCP[eu-west-3a],10.58.0.84:53/TCP[eu-west-3a],10.58.0.84:53/UDP[eu-west-3a],10.58.0.84:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001576ce0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-dtvpk": (*k8s.Endpoints)(0x40021f1c70)(10.58.0.134:2379/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x40015cc298)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40023fe5b0)(172.31.164.131:443/TCP,172.31.219.0:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x40015cc2a0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-wbfp8": (*k8s.Endpoints)(0x400232e8f0)(172.31.172.29:4244/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x40003c2b60)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4002843540)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400a603188
  },
  gcTrigger: (chan struct {}) (cap=1) 0x400284d0e0,
  gcExited: (chan struct {}) 0x400284d140,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x40022efb80)({
     ObserverVec: (*prometheus.HistogramVec)(0x40016999e8)({
      MetricVec: (*prometheus.MetricVec)(0x4000b85380)({
       metricMap: (*prometheus.metricMap)(0x4000b853b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000d16f00)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x40022efc00)({
     ObserverVec: (*prometheus.HistogramVec)(0x40016999f0)({
      MetricVec: (*prometheus.MetricVec)(0x4000b85440)({
       metricMap: (*prometheus.metricMap)(0x4000b85470)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000d16f60)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x40022efc80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40016999f8)({
      MetricVec: (*prometheus.MetricVec)(0x4000b854d0)({
       metricMap: (*prometheus.metricMap)(0x4000b85500)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000d16fc0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x40022efd00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001699a00)({
      MetricVec: (*prometheus.MetricVec)(0x4000b85560)({
       metricMap: (*prometheus.metricMap)(0x4000b855c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000d17020)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x40022efd80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001699a08)({
      MetricVec: (*prometheus.MetricVec)(0x4000b85620)({
       metricMap: (*prometheus.metricMap)(0x4000b85650)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000d17080)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x40022efe00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001699a10)({
      MetricVec: (*prometheus.MetricVec)(0x4000b856b0)({
       metricMap: (*prometheus.metricMap)(0x4000b856e0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000d170e0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x40022efe80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001699a18)({
      MetricVec: (*prometheus.MetricVec)(0x4000b85740)({
       metricMap: (*prometheus.metricMap)(0x4000b857a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000d17140)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x40022eff00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001699a20)({
      MetricVec: (*prometheus.MetricVec)(0x4000b85800)({
       metricMap: (*prometheus.metricMap)(0x4000b85830)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000d171a0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x40013b6000)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001699a28)({
      MetricVec: (*prometheus.MetricVec)(0x4000b85890)({
       metricMap: (*prometheus.metricMap)(0x4000b858c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000d17200)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x40003c2b60)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40003c6770)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x400165a930)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 435ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0
  }
 })
})

```


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.58.0.0/24, 
Allocated addresses:
  10.58.0.129 (kube-system/coredns-cc6ccd49c-n27t9)
  10.58.0.134 (kube-system/clustermesh-apiserver-7d9f745589-mr5g8)
  10.58.0.234 (health)
  10.58.0.38 (router)
  10.58.0.84 (kube-system/coredns-cc6ccd49c-7wglv)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 149a47d617599ece
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    42s ago        never        0       no error   
  ct-map-pressure                                                     13s ago        never        0       no error   
  daemon-validate-config                                              30s ago        never        0       no error   
  dns-garbage-collector-job                                           45s ago        never        0       no error   
  endpoint-1161-regeneration-recovery                                 never          never        0       no error   
  endpoint-1709-regeneration-recovery                                 never          never        0       no error   
  endpoint-3315-regeneration-recovery                                 never          never        0       no error   
  endpoint-3560-regeneration-recovery                                 never          never        0       no error   
  endpoint-731-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         3m46s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                13s ago        never        0       no error   
  ipcache-inject-labels                                               43s ago        never        0       no error   
  k8s-heartbeat                                                       16s ago        never        0       no error   
  link-cache                                                          13s ago        never        0       no error   
  local-identity-checkpoint                                           13m43s ago     never        0       no error   
  node-neighbor-link-updater                                          3s ago         never        0       no error   
  remote-etcd-cmesh1                                                  5m50s ago      never        0       no error   
  remote-etcd-cmesh10                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh100                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh101                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh102                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh103                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh104                                                5m50s ago      never        0       no error   
  remote-etcd-cmesh105                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh106                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh107                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh108                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh109                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh11                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh110                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh111                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh112                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh113                                                5m50s ago      never        0       no error   
  remote-etcd-cmesh114                                                5m50s ago      never        0       no error   
  remote-etcd-cmesh115                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh116                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh117                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh118                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh119                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh12                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh120                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh121                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh122                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh123                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh124                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh125                                                5m50s ago      never        0       no error   
  remote-etcd-cmesh126                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh127                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh128                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh13                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh14                                                 5m50s ago      never        0       no error   
  remote-etcd-cmesh15                                                 5m50s ago      never        0       no error   
  remote-etcd-cmesh16                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh17                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh18                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh19                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh2                                                  5m49s ago      never        0       no error   
  remote-etcd-cmesh20                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh21                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh22                                                 5m50s ago      never        0       no error   
  remote-etcd-cmesh23                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh24                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh25                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh26                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh27                                                 5m50s ago      never        0       no error   
  remote-etcd-cmesh28                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh29                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh3                                                  5m49s ago      never        0       no error   
  remote-etcd-cmesh30                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh31                                                 5m50s ago      never        0       no error   
  remote-etcd-cmesh32                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh33                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh34                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh35                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh36                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh37                                                 5m50s ago      never        0       no error   
  remote-etcd-cmesh38                                                 5m50s ago      never        0       no error   
  remote-etcd-cmesh39                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh4                                                  5m49s ago      never        0       no error   
  remote-etcd-cmesh40                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh41                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh42                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh43                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh44                                                 5m50s ago      never        0       no error   
  remote-etcd-cmesh45                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh46                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh47                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh48                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh49                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh5                                                  5m49s ago      never        0       no error   
  remote-etcd-cmesh50                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh51                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh52                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh53                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh54                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh55                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh56                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh57                                                 5m50s ago      never        0       no error   
  remote-etcd-cmesh58                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh6                                                  5m49s ago      never        0       no error   
  remote-etcd-cmesh60                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh61                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh62                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh63                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh64                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh65                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh66                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh67                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh68                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh69                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh7                                                  5m49s ago      never        0       no error   
  remote-etcd-cmesh70                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh71                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh72                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh73                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh74                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh75                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh76                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh77                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh78                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh79                                                 5m50s ago      never        0       no error   
  remote-etcd-cmesh8                                                  5m50s ago      never        0       no error   
  remote-etcd-cmesh80                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh81                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh82                                                 5m50s ago      never        0       no error   
  remote-etcd-cmesh83                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh84                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh85                                                 5m50s ago      never        0       no error   
  remote-etcd-cmesh86                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh87                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh88                                                 5m50s ago      never        0       no error   
  remote-etcd-cmesh89                                                 5m50s ago      never        0       no error   
  remote-etcd-cmesh9                                                  5m49s ago      never        0       no error   
  remote-etcd-cmesh90                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh91                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh92                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh93                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh94                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh95                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh96                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh97                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh98                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh99                                                 5m49s ago      never        0       no error   
  resolve-identity-1161                                               3m41s ago      never        0       no error   
  resolve-identity-1709                                               2m9s ago       never        0       no error   
  resolve-identity-3315                                               3m43s ago      never        0       no error   
  resolve-identity-3560                                               3m42s ago      never        0       no error   
  resolve-identity-731                                                3m41s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-7d9f745589-mr5g8   7m9s ago       never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-7wglv                  13m41s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-n27t9                  13m41s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      13m43s ago     never        0       no error   
  sync-policymap-1161                                                 13m39s ago     never        0       no error   
  sync-policymap-1709                                                 7m9s ago       never        0       no error   
  sync-policymap-3315                                                 13m42s ago     never        0       no error   
  sync-policymap-3560                                                 13m39s ago     never        0       no error   
  sync-policymap-731                                                  13m39s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (1161)                                   11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1709)                                   8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (731)                                    11s ago        never        0       no error   
  sync-utime                                                          43s ago        never        0       no error   
  write-cni-file                                                      13m46s ago     never        0       no error   
Proxy Status:            OK, ip 10.58.0.38, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 3866624, max 3932159
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 74.90   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
enable-ipv4-masquerade:true
bpf-lb-service-backend-map-max:0
k8s-service-proxy-name:
envoy-secrets-namespace:
l2-announcements-retry-period:2s
ipv6-range:auto
enable-masquerade-to-route-source:false
bpf-lb-maglev-map-max:0
clustermesh-enable-mcs-api:false
ipam-default-ip-pool:default
enable-stale-cilium-endpoint-cleanup:true
pprof:false
http-normalize-path:true
enable-k8s-terminating-endpoint:true
ipv6-node:auto
endpoint-queue-size:25
ipam:cluster-pool
proxy-connect-timeout:2
nodes-gc-interval:5m0s
cilium-endpoint-gc-interval:5m0s
egress-multi-home-ip-rule-compat:false
cni-external-routing:false
set-cilium-node-taints:true
use-full-tls-context:false
dnsproxy-concurrency-processing-grace-period:0s
hubble-export-fieldmask:
ingress-secrets-namespace:
monitor-queue-size:0
allow-icmp-frag-needed:true
enable-host-firewall:false
enable-ipv4-fragment-tracking:true
hubble-drop-events-interval:2m0s
debug-verbose:
preallocate-bpf-maps:false
auto-direct-node-routes:false
bpf-sock-rev-map-max:262144
enable-high-scale-ipcache:false
route-metric:0
hubble-export-denylist:
enable-bpf-clock-probe:false
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
node-labels:
enable-l7-proxy:true
hubble-event-queue-size:0
identity-change-grace-period:5s
mesh-auth-spiffe-trust-domain:spiffe.cilium
iptables-random-fully:false
enable-xdp-prefilter:false
dnsproxy-socket-linger-timeout:10
hubble-listen-address::4244
iptables-lock-timeout:5s
prometheus-serve-addr:
encryption-strict-mode-cidr:
enable-pmtu-discovery:false
hubble-redact-enabled:false
bpf-lb-rev-nat-map-max:0
bpf-map-dynamic-size-ratio:0.0025
enable-metrics:true
allow-localhost:auto
datapath-mode:veth
mesh-auth-gc-interval:5m0s
tofqdns-proxy-response-max-delay:100ms
bpf-events-trace-enabled:true
socket-path:/var/run/cilium/cilium.sock
pprof-port:6060
remove-cilium-node-taints:true
enable-local-redirect-policy:false
enable-ipsec-encrypted-overlay:false
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
enable-ipv6:false
fqdn-regex-compile-lru-size:1024
node-port-bind-protection:true
bpf-ct-timeout-regular-tcp-fin:10s
node-port-acceleration:disabled
bpf-lb-dsr-dispatch:opt
hubble-redact-http-headers-deny:
hubble-skip-unknown-cgroup-ids:true
identity-restore-grace-period:30s
proxy-max-requests-per-connection:0
fixed-identity-mapping:
max-connected-clusters:255
envoy-base-id:0
enable-bbr:false
bpf-lb-sock:false
enable-gateway-api:false
enable-recorder:false
enable-health-check-loadbalancer-ip:false
force-device-detection:false
tofqdns-pre-cache:
l2-pod-announcements-interface:
dnsproxy-lock-timeout:500ms
bgp-announce-lb-ip:false
prepend-iptables-chains:true
k8s-client-connection-keep-alive:30s
enable-active-connection-tracking:false
tofqdns-dns-reject-response-code:refused
enable-tcx:true
enable-cilium-endpoint-slice:false
agent-health-port:9879
mesh-auth-enabled:true
encrypt-interface:
mesh-auth-signal-backoff-duration:1s
nodeport-addresses:
bypass-ip-availability-upon-restore:false
cluster-pool-ipv4-cidr:10.58.0.0/16
bpf-ct-timeout-regular-any:1m0s
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
tofqdns-min-ttl:0
l2-announcements-renew-deadline:5s
bpf-node-map-max:16384
ipsec-key-file:
hubble-export-allowlist:
enable-endpoint-health-checking:true
enable-hubble:true
enable-local-node-route:true
enable-well-known-identities:false
cluster-pool-ipv4-mask-size:24
hubble-export-file-max-backups:5
enable-l2-neigh-discovery:true
gops-port:9890
controller-group-metrics:
enable-ipv4-big-tcp:false
enable-wireguard-userspace-fallback:false
debug:false
bpf-ct-timeout-regular-tcp:2h13m20s
state-dir:/var/run/cilium
hubble-flowlogs-config-path:
envoy-keep-cap-netbindservice:false
clustermesh-ip-identities-sync-timeout:1m0s
proxy-xff-num-trusted-hops-egress:0
endpoint-bpf-prog-watchdog-interval:30s
allocator-list-timeout:3m0s
enable-node-selector-labels:false
ipv6-mcast-device:
enable-nat46x64-gateway:false
synchronize-k8s-nodes:true
tofqdns-endpoint-max-ip-per-hostname:50
tofqdns-proxy-port:0
disable-external-ip-mitigation:false
hubble-prefer-ipv6:false
enable-host-legacy-routing:false
annotate-k8s-node:false
enable-auto-protect-node-port-range:true
node-port-range:
local-router-ipv6:
ipv4-pod-subnets:
local-router-ipv4:
http-idle-timeout:0
log-system-load:false
ipsec-key-rotation-duration:5m0s
enable-bgp-control-plane:false
http-request-timeout:3600
clustermesh-config:/var/lib/cilium/clustermesh/
bpf-ct-timeout-service-tcp:2h13m20s
enable-ip-masq-agent:false
pprof-address:localhost
bpf-fragments-map-max:8192
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
kube-proxy-replacement-healthz-bind-address:
proxy-admin-port:0
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
operator-prometheus-serve-addr::9963
bgp-config-path:/var/lib/cilium/bgp/config.yaml
proxy-xff-num-trusted-hops-ingress:0
conntrack-gc-interval:0s
mesh-auth-mutual-listener-port:0
bpf-ct-timeout-regular-tcp-syn:1m0s
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
direct-routing-device:
lib-dir:/var/lib/cilium
enable-ipv4:true
endpoint-gc-interval:5m0s
disable-iptables-feeder-rules:
enable-tracing:false
k8s-require-ipv6-pod-cidr:false
k8s-sync-timeout:3m0s
enable-k8s:true
config-dir:/tmp/cilium/config-map
disable-endpoint-crd:false
mesh-auth-mutual-connect-timeout:5s
enable-bandwidth-manager:false
mesh-auth-queue-size:1024
trace-payloadlen:128
bpf-lb-acceleration:disabled
srv6-encap-mode:reduced
policy-audit-mode:false
tunnel-protocol:vxlan
enable-route-mtu-for-cni-chaining:false
cluster-health-port:4240
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
enable-health-checking:true
bpf-ct-global-any-max:262144
hubble-recorder-storage-path:/var/run/cilium/pcaps
bpf-policy-map-max:16384
static-cnp-path:
restore:true
bpf-lb-rss-ipv4-src-cidr:
k8s-namespace:kube-system
enable-bpf-tproxy:false
envoy-config-retry-interval:15s
enable-l2-announcements:false
egress-gateway-reconciliation-trigger-interval:1s
k8s-kubeconfig-path:
k8s-api-server:
labels:
kube-proxy-replacement:false
dnsproxy-concurrency-limit:0
hubble-metrics-server:
proxy-portrange-min:10000
use-cilium-internal-ip-for-ipsec:false
cni-log-file:/var/run/cilium/cilium-cni.log
enable-ingress-controller:false
monitor-aggregation-flags:all
enable-encryption-strict-mode:false
enable-ipv6-masquerade:true
hubble-export-file-path:
certificates-directory:/var/run/cilium/certs
enable-srv6:false
operator-api-serve-addr:127.0.0.1:9234
bpf-ct-timeout-service-tcp-grace:1m0s
bpf-lb-mode:snat
trace-sock:true
hubble-redact-http-userinfo:true
enable-health-check-nodeport:true
ipv6-cluster-alloc-cidr:f00d::/64
enable-ipsec:false
enable-ipsec-xfrm-state-caching:true
ipv6-pod-subnets:
policy-trigger-interval:1s
enable-k8s-api-discovery:false
join-cluster:false
bpf-ct-timeout-service-any:1m0s
bpf-neigh-global-max:524288
conntrack-gc-max-interval:0s
monitor-aggregation:medium
enable-service-topology:false
enable-l2-pod-announcements:false
bpf-lb-source-range-map-max:0
encrypt-node:false
hubble-event-buffer-capacity:4095
cflags:
hubble-export-file-compress:false
bpf-map-event-buffers:
cluster-id:59
agent-liveness-update-interval:1s
cni-chaining-mode:none
exclude-node-label-patterns:
enable-ipv4-egress-gateway:false
custom-cni-conf:false
tofqdns-idle-connection-grace-period:0s
direct-routing-skip-unreachable:false
mesh-auth-spire-admin-socket:
enable-hubble-recorder-api:true
ip-masq-agent-config-path:/etc/config/ip-masq-agent
enable-envoy-config:false
kvstore-lease-ttl:15m0s
enable-unreachable-routes:false
enable-svc-source-range-check:true
hubble-export-file-max-size-mb:10
vlan-bpf-bypass:
ipam-multi-pool-pre-allocation:
clustermesh-sync-timeout:1m0s
install-iptables-rules:true
identity-allocation-mode:crd
local-max-addr-scope:252
bpf-lb-maglev-table-size:16381
enable-identity-mark:true
enable-bpf-masquerade:false
hubble-disable-tls:false
procfs:/host/proc
policy-accounting:true
service-no-backend-response:reject
devices:
kvstore-connectivity-timeout:2m0s
enable-cilium-health-api-server-access:
bpf-events-policy-verdict-enabled:true
arping-refresh-period:30s
proxy-gid:1337
vtep-endpoint:
bpf-lb-sock-hostns-only:false
egress-masquerade-interfaces:ens+
ipv4-service-range:auto
enable-ipv6-ndp:false
set-cilium-is-up-condition:true
ipv6-native-routing-cidr:
proxy-max-connection-duration-seconds:0
wireguard-persistent-keepalive:0s
bpf-lb-service-map-max:0
enable-xt-socket-fallback:true
unmanaged-pod-watcher-interval:15
policy-cidr-match-mode:
kvstore-max-consecutive-quorum-errors:2
bpf-filter-priority:1
dns-max-ips-per-restored-rule:1000
envoy-log:
version:false
multicast-enabled:false
enable-session-affinity:false
enable-custom-calls:false
bpf-lb-affinity-map-max:0
bpf-nat-global-max:524288
log-driver:
bpf-lb-sock-terminate-pod-connections:false
ipv4-node:auto
envoy-config-timeout:2m0s
hubble-redact-kafka-apikey:false
proxy-prometheus-port:0
dns-policy-unload-on-shutdown:false
tofqdns-max-deferred-connection-deletes:10000
bpf-events-drop-enabled:true
keep-config:false
config:
encryption-strict-mode-allow-remote-node-identities:false
node-port-mode:snat
hubble-drop-events:false
hubble-monitor-events:
kvstore:
tofqdns-enable-dns-compression:true
kvstore-periodic-sync:5m0s
bpf-ct-global-tcp-max:524288
vtep-mask:
bpf-lb-rss-ipv6-src-cidr:
nat-map-stats-interval:30s
container-ip-local-reserved-ports:auto
hubble-redact-http-headers-allow:
http-retry-timeout:0
enable-vtep:false
cgroup-root:/run/cilium/cgroupv2
enable-icmp-rules:true
bgp-announce-pod-cidr:false
proxy-portrange-max:20000
enable-runtime-device-detection:true
hubble-socket-path:/var/run/cilium/hubble.sock
max-controller-interval:0
enable-policy:default
l2-announcements-lease-duration:15s
http-retry-count:3
crd-wait-timeout:5m0s
k8s-client-qps:10
cluster-name:cmesh59
bpf-lb-map-max:65536
cni-chaining-target:
cni-exclusive:true
dnsproxy-insecure-skip-transparent-mode-check:false
hubble-recorder-sink-queue-size:1024
http-max-grpc-timeout:0
read-cni-conf:
ipv4-range:auto
agent-labels:
bpf-policy-map-full-reconciliation-interval:15m0s
monitor-aggregation-interval:5s
vtep-cidr:
log-opt:
dnsproxy-lock-count:131
config-sources:config-map:kube-system/cilium-config
proxy-idle-timeout-seconds:60
enable-monitor:true
enable-cilium-api-server-access:
k8s-heartbeat-timeout:30s
k8s-service-cache-size:128
ipv6-service-range:auto
disable-envoy-version-check:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
mtu:0
enable-wireguard:false
enable-ipsec-key-watcher:true
identity-heartbeat-timeout:30m0s
k8s-client-burst:20
hubble-drop-events-reasons:auth_required,policy_denied
hubble-metrics:
bpf-root:/sys/fs/bpf
ipv4-native-routing-cidr:
k8s-require-ipv4-pod-cidr:false
exclude-local-address:
bpf-lb-external-clusterip:false
enable-node-port:false
egress-gateway-policy-map-max:16384
max-internal-timer-delay:0s
label-prefix-file:
enable-k8s-endpoint-slice:true
enable-external-ips:false
enable-ipv6-big-tcp:false
clustermesh-enable-endpoint-sync:false
bpf-auth-map-max:524288
kvstore-opt:
external-envoy-proxy:true
auto-create-cilium-node-resource:true
install-no-conntrack-iptables-rules:false
enable-endpoint-routes:false
tunnel-port:0
dnsproxy-enable-transparent-mode:true
node-port-algorithm:random
k8s-client-connection-timeout:30s
ipv4-service-loopback-address:169.254.42.1
hubble-redact-http-urlquery:false
bpf-lb-dsr-l4-xlate:frontend
enable-k8s-networkpolicy:true
mesh-auth-rotated-identities-queue-size:1024
identity-gc-interval:15m0s
enable-host-port:false
bpf-lb-algorithm:random
policy-queue-size:100
metrics:
nat-map-stats-entries:32
derive-masq-ip-addr-from-device:
enable-sctp:false
mke-cgroup-mount:
gateway-api-secrets-namespace:
routing-mode:tunnel
cmdref:
api-rate-limit:
ipam-cilium-node-update-rate:15s
enable-mke:false
vtep-mac:
enable-ipip-termination:false
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
731        Disabled           Disabled          3921194    k8s:eks.amazonaws.com/component=coredns                                             10.58.0.84    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh59                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
1161       Disabled           Disabled          3921194    k8s:eks.amazonaws.com/component=coredns                                             10.58.0.129   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh59                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
1709       Disabled           Disabled          3906585    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.58.0.134   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh59                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
3315       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                
                                                           reserved:host                                                                                             
3560       Disabled           Disabled          4          reserved:health                                                                     10.58.0.234   ready   
```

#### BPF Policy Get 731

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    76666   881       0        
Allow    Egress      0          ANY          NONE         disabled    13752   142       0        

```


#### BPF CT List 731

```
Invalid argument: unknown type 731
```


#### Endpoint Get 731

```
[
  {
    "id": 731,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-731-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c16406f4-1f00-43b0-8fa1-8bbf35d1e7e1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-731",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:37.339Z",
            "success-count": 3
          },
          "uuid": "bfec05c4-c537-45e0-abe9-8a438811d1a6"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-7wglv",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:37.337Z",
            "success-count": 1
          },
          "uuid": "a60bcf0c-087a-4acf-93ae-54ad6d50c1fd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-731",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:39.609Z",
            "success-count": 1
          },
          "uuid": "48e3b897-c5f7-4bb0-99a0-ed9a7fdfba4e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (731)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:17.403Z",
            "success-count": 84
          },
          "uuid": "f1a22432-b6db-4613-8ef5-0bce75443100"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "1dddd9292b52fcf981f86561418b6d2e0e11d3e77700c63d031ee8733628f3ef:eth0",
        "container-id": "1dddd9292b52fcf981f86561418b6d2e0e11d3e77700c63d031ee8733628f3ef",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-7wglv",
        "pod-name": "kube-system/coredns-cc6ccd49c-7wglv"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3921194,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh59",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh59",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:30Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.58.0.84",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "32:22:59:e4:c0:0a",
        "interface-index": 12,
        "interface-name": "lxc8207b4a427c9",
        "mac": "a2:a4:eb:ef:e2:dd"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3921194,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3921194,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 731

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 731

```
Timestamp              Status   State                   Message
2024-10-25T10:23:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:30Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:39Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:38Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:15:37Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:37Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:37Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3921194

```
ID        LABELS
3921194   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh59
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1161

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    78409   905       0        
Allow    Egress      0          ANY          NONE         disabled    13190   136       0        

```


#### BPF CT List 1161

```
Invalid argument: unknown type 1161
```


#### Endpoint Get 1161

```
[
  {
    "id": 1161,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1161-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b8910d92-7031-4667-88b7-e7d253af5ffe"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1161",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:37.308Z",
            "success-count": 3
          },
          "uuid": "b44af756-7fca-4d23-bb16-d4840e639ace"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-n27t9",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:37.305Z",
            "success-count": 1
          },
          "uuid": "a604f728-a636-494f-97a1-efd35cd80011"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1161",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:39.544Z",
            "success-count": 1
          },
          "uuid": "a1464943-61ae-493e-a42d-22e212b1805e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1161)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:17.371Z",
            "success-count": 84
          },
          "uuid": "edc5ccac-66aa-478e-b509-918b222dcd5f"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "b4c636a04f0537b854c74e7fe258cb7583805697e62c253f2e45da046542fe06:eth0",
        "container-id": "b4c636a04f0537b854c74e7fe258cb7583805697e62c253f2e45da046542fe06",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-n27t9",
        "pod-name": "kube-system/coredns-cc6ccd49c-n27t9"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3921194,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh59",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh59",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:30Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.58.0.129",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ae:10:0c:6b:b1:0b",
        "interface-index": 14,
        "interface-name": "lxceb3c08e95539",
        "mac": "76:7e:99:ea:87:99"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3921194,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3921194,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1161

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1161

```
Timestamp              Status   State                   Message
2024-10-25T10:23:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:30Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:15:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:39Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:15:39Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:38Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:15:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:15:37Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:37Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:15:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:37Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:37Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3921194

```
ID        LABELS
3921194   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh59
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1709

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3911965   36766     0        
Allow    Ingress     1          ANY          NONE         disabled    2846665   28476     0        
Allow    Egress      0          ANY          NONE         disabled    4548938   42244     0        

```


#### BPF CT List 1709

```
Invalid argument: unknown type 1709
```


#### Endpoint Get 1709

```
[
  {
    "id": 1709,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1709-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "31af4d7b-1919-4d69-874c-7024cda1c361"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1709",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:09.679Z",
            "success-count": 2
          },
          "uuid": "18e102a6-7bfd-4862-a6ba-7a62dfca86fc"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-7d9f745589-mr5g8",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:09.676Z",
            "success-count": 1
          },
          "uuid": "4a4b8e8e-a0a6-4c57-81fa-aa70e3cc927a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1709",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:09.713Z",
            "success-count": 1
          },
          "uuid": "e6cb581f-0655-4aaf-99aa-45b949d46c17"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1709)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:09.732Z",
            "success-count": 44
          },
          "uuid": "d750dd05-a2d7-4970-9ff9-81d8f2932741"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "28ab76b970a000ac65c73b86eb3f0e7f58df0a41dbfccf031ffe0487d320c2f6:eth0",
        "container-id": "28ab76b970a000ac65c73b86eb3f0e7f58df0a41dbfccf031ffe0487d320c2f6",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-7d9f745589-mr5g8",
        "pod-name": "kube-system/clustermesh-apiserver-7d9f745589-mr5g8"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3906585,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh59",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7d9f745589"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh59",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:30Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.58.0.134",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "0a:13:93:9f:53:70",
        "interface-index": 18,
        "interface-name": "lxc0a64ff509add",
        "mac": "d6:12:56:c2:53:71"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3906585,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3906585,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1709

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1709

```
Timestamp              Status   State                   Message
2024-10-25T10:23:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:30Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:22:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:09Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:22:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:22:09Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:22:09Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3906585

```
ID        LABELS
3906585   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh59
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 3315

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 3315

```
Invalid argument: unknown type 3315
```


#### Endpoint Get 3315

```
[
  {
    "id": 3315,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3315-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "dc453c57-b124-4473-8f51-1153269e53df"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3315",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:35.243Z",
            "success-count": 3
          },
          "uuid": "1a736c9e-04b4-43c9-a281-09c537e71c74"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3315",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:36.340Z",
            "success-count": 1
          },
          "uuid": "3245b62a-ae27-4a0b-bb47-719ac82b1638"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:30Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "22:b0:34:4e:ad:2c",
        "interface-name": "cilium_host",
        "mac": "22:b0:34:4e:ad:2c"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3315

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3315

```
Timestamp              Status   State                   Message
2024-10-25T10:23:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:30Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:38Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:15:37Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:35Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:35Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:35Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 3560

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    441666   5636      0        
Allow    Ingress     1          ANY          NONE         disabled    10310    117       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 3560

```
Invalid argument: unknown type 3560
```


#### Endpoint Get 3560

```
[
  {
    "id": 3560,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3560-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "0bfcbb66-57b3-43d1-a315-5e796f2bbd2d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3560",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:36.296Z",
            "success-count": 3
          },
          "uuid": "b749b2d0-0d53-4053-8450-9cf3ec7ef179"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3560",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:39.556Z",
            "success-count": 1
          },
          "uuid": "c1550c49-9736-4583-88f9-d728562d30ce"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:30Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.58.0.234",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "72:84:bd:64:e6:0a",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "da:a6:8f:38:e0:5b"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3560

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3560

```
Timestamp              Status   State                   Message
2024-10-25T10:23:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:30Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:39Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:38Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:15:37Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:36Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:36Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:35Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Service list

```
ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.164.131:443 (active)   
                                          2 => 172.31.219.0:443 (active)     
2    10.100.24.61:443      ClusterIP      1 => 172.31.172.29:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.58.0.129:53 (active)       
                                          2 => 10.58.0.84:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.58.0.129:9153 (active)     
                                          2 => 10.58.0.84:9153 (active)      
5    10.100.139.166:2379   ClusterIP      1 => 10.58.0.134:2379 (active)     
```

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 41961999                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 41961999                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 41961999                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d000000 rw-p 00000000 00:00 0 
400d000000-4010000000 ---p 00000000 00:00 0 
ffff50520000-ffff50746000 rw-p 00000000 00:00 0 
ffff5074e000-ffff5086f000 rw-p 00000000 00:00 0 
ffff5086f000-ffff508b0000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff508b0000-ffff508f1000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff508f1000-ffff508f3000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff508f3000-ffff508f5000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff508f5000-ffff50e9c000 rw-p 00000000 00:00 0 
ffff50e9c000-ffff50f9c000 rw-p 00000000 00:00 0 
ffff50f9c000-ffff50fad000 rw-p 00000000 00:00 0 
ffff50fad000-ffff52fad000 rw-p 00000000 00:00 0 
ffff52fad000-ffff5302d000 ---p 00000000 00:00 0 
ffff5302d000-ffff5302e000 rw-p 00000000 00:00 0 
ffff5302e000-ffff7302d000 ---p 00000000 00:00 0 
ffff7302d000-ffff7302e000 rw-p 00000000 00:00 0 
ffff7302e000-ffff92fbd000 ---p 00000000 00:00 0 
ffff92fbd000-ffff92fbe000 rw-p 00000000 00:00 0 
ffff92fbe000-ffff96faf000 ---p 00000000 00:00 0 
ffff96faf000-ffff96fb0000 rw-p 00000000 00:00 0 
ffff96fb0000-ffff977ad000 ---p 00000000 00:00 0 
ffff977ad000-ffff977ae000 rw-p 00000000 00:00 0 
ffff977ae000-ffff978ad000 ---p 00000000 00:00 0 
ffff978ad000-ffff9790d000 rw-p 00000000 00:00 0 
ffff9790d000-ffff9790f000 r--p 00000000 00:00 0                          [vvar]
ffff9790f000-ffff97910000 r-xp 00000000 00:00 0                          [vdso]
ffffc8af9000-ffffc8b1a000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium encryption


