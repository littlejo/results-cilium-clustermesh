key: db 02 00 00  value: 08 02 00 00
key: 89 04 00 00  value: 0c 02 00 00
key: ad 06 00 00  value: 79 02 00 00
key: e8 0d 00 00  value: 23 02 00 00
Found 4 elements
