top - 10:28:48 up 14 min,  0 users,  load average: 0.32, 0.17, 0.15
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s):  9.7 us, 22.6 sy,  0.0 ni, 64.5 id,  0.0 wa,  0.0 hi,  3.2 si,  0.0 st
MiB Mem :   3836.2 total,    784.1 free,    910.4 used,   2141.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2756.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    656 root      20   0 1240432  16620  11420 S   6.7   0.4   0:00.02 cilium-+
      1 root      20   0 1472496 280280  78260 S   0.0   7.1   0:23.03 cilium-+
    393 root      20   0 1228848   5752   2868 S   0.0   0.1   0:00.27 cilium-+
    628 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    644 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    650 root      20   0 1228744   3604   2912 S   0.0   0.1   0:00.00 gops
    669 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    700 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    718 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
