alloc: 140.49MB (147319096 bytes)
total-alloc: 1.32GB (1420246096 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 47636080
frees: 46169361
heap-alloc: 140.49MB (147319096 bytes)
heap-sys: 163.20MB (171130880 bytes)
heap-idle: 7.57MB (7938048 bytes)
heap-in-use: 155.63MB (163192832 bytes)
heap-released: 1.00MB (1048576 bytes)
heap-objects: 1466719
stack-in-use: 36.56MB (38338560 bytes)
stack-sys: 36.56MB (38338560 bytes)
stack-mspan-inuse: 2.43MB (2543200 bytes)
stack-mspan-sys: 2.49MB (2611200 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 875.84KB (896857 bytes)
gc-sys: 5.36MB (5617944 bytes)
next-gc: when heap-alloc >= 145.48MB (152545560 bytes)
last-gc: 2024-10-25 10:28:34.338101562 +0000 UTC
gc-pause-total: 10.73215ms
gc-pause: 79623
gc-pause-end: 1729852114338101562
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.00033475837811525823
enable-gc: true
debug-gc: false
