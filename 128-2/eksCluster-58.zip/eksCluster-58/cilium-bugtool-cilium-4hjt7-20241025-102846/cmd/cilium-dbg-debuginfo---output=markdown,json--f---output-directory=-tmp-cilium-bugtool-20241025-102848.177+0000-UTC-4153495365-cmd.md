markdown output at /tmp/cilium-bugtool-20241025-102848.177+0000-UTC-4153495365/cmd/cilium-debuginfo-20241025-102918.728+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102848.177+0000-UTC-4153495365/cmd/cilium-debuginfo-20241025-102918.728+0000-UTC.json
