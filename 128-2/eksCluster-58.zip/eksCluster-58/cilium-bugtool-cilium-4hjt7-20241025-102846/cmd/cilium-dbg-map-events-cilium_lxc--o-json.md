{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:35.056Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.146.26:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:35.056Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.172.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:35.056Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:39.542Z",
  "value": "id=1161  sec_id=3921194 flags=0x0000 ifindex=14  mac=76:7E:99:EA:87:99 nodemac=AE:10:0C:6B:B1:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:39.555Z",
  "value": "id=3560  sec_id=4     flags=0x0000 ifindex=10  mac=DA:A6:8F:38:E0:5B nodemac=72:84:BD:64:E6:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:39.606Z",
  "value": "id=731   sec_id=3921194 flags=0x0000 ifindex=12  mac=A2:A4:EB:EF:E2:DD nodemac=32:22:59:E4:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:39.651Z",
  "value": "id=1161  sec_id=3921194 flags=0x0000 ifindex=14  mac=76:7E:99:EA:87:99 nodemac=AE:10:0C:6B:B1:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:39.764Z",
  "value": "id=3560  sec_id=4     flags=0x0000 ifindex=10  mac=DA:A6:8F:38:E0:5B nodemac=72:84:BD:64:E6:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:18.735Z",
  "value": "id=3560  sec_id=4     flags=0x0000 ifindex=10  mac=DA:A6:8F:38:E0:5B nodemac=72:84:BD:64:E6:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:18.735Z",
  "value": "id=731   sec_id=3921194 flags=0x0000 ifindex=12  mac=A2:A4:EB:EF:E2:DD nodemac=32:22:59:E4:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:18.736Z",
  "value": "id=1161  sec_id=3921194 flags=0x0000 ifindex=14  mac=76:7E:99:EA:87:99 nodemac=AE:10:0C:6B:B1:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:18.767Z",
  "value": "id=1471  sec_id=3906585 flags=0x0000 ifindex=16  mac=6A:28:6B:14:46:78 nodemac=76:6C:9B:10:E1:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:19.736Z",
  "value": "id=1161  sec_id=3921194 flags=0x0000 ifindex=14  mac=76:7E:99:EA:87:99 nodemac=AE:10:0C:6B:B1:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:19.736Z",
  "value": "id=731   sec_id=3921194 flags=0x0000 ifindex=12  mac=A2:A4:EB:EF:E2:DD nodemac=32:22:59:E4:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:19.736Z",
  "value": "id=1471  sec_id=3906585 flags=0x0000 ifindex=16  mac=6A:28:6B:14:46:78 nodemac=76:6C:9B:10:E1:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:19.737Z",
  "value": "id=3560  sec_id=4     flags=0x0000 ifindex=10  mac=DA:A6:8F:38:E0:5B nodemac=72:84:BD:64:E6:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:09.713Z",
  "value": "id=1709  sec_id=3906585 flags=0x0000 ifindex=18  mac=D6:12:56:C2:53:71 nodemac=0A:13:93:9F:53:70"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.58.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:15.741Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:28.749Z",
  "value": "id=1161  sec_id=3921194 flags=0x0000 ifindex=14  mac=76:7E:99:EA:87:99 nodemac=AE:10:0C:6B:B1:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:28.749Z",
  "value": "id=731   sec_id=3921194 flags=0x0000 ifindex=12  mac=A2:A4:EB:EF:E2:DD nodemac=32:22:59:E4:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:28.749Z",
  "value": "id=1709  sec_id=3906585 flags=0x0000 ifindex=18  mac=D6:12:56:C2:53:71 nodemac=0A:13:93:9F:53:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:28.751Z",
  "value": "id=3560  sec_id=4     flags=0x0000 ifindex=10  mac=DA:A6:8F:38:E0:5B nodemac=72:84:BD:64:E6:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:29.749Z",
  "value": "id=1709  sec_id=3906585 flags=0x0000 ifindex=18  mac=D6:12:56:C2:53:71 nodemac=0A:13:93:9F:53:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:29.750Z",
  "value": "id=3560  sec_id=4     flags=0x0000 ifindex=10  mac=DA:A6:8F:38:E0:5B nodemac=72:84:BD:64:E6:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:29.750Z",
  "value": "id=1161  sec_id=3921194 flags=0x0000 ifindex=14  mac=76:7E:99:EA:87:99 nodemac=AE:10:0C:6B:B1:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:29.751Z",
  "value": "id=731   sec_id=3921194 flags=0x0000 ifindex=12  mac=A2:A4:EB:EF:E2:DD nodemac=32:22:59:E4:C0:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:30.750Z",
  "value": "id=1709  sec_id=3906585 flags=0x0000 ifindex=18  mac=D6:12:56:C2:53:71 nodemac=0A:13:93:9F:53:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:30.750Z",
  "value": "id=3560  sec_id=4     flags=0x0000 ifindex=10  mac=DA:A6:8F:38:E0:5B nodemac=72:84:BD:64:E6:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:30.750Z",
  "value": "id=1161  sec_id=3921194 flags=0x0000 ifindex=14  mac=76:7E:99:EA:87:99 nodemac=AE:10:0C:6B:B1:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.58.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:30.750Z",
  "value": "id=731   sec_id=3921194 flags=0x0000 ifindex=12  mac=A2:A4:EB:EF:E2:DD nodemac=32:22:59:E4:C0:0A"
}

