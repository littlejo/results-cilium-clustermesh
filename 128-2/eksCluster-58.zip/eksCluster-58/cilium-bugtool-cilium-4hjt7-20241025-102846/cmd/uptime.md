 10:28:48 up 14 min,  0 users,  load average: 0.00, 0.10, 0.13
