xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 575
ens6(5) clsact/ingress cil_from_netdev-ens6 id 586
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 571
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 562
cilium_host(7) clsact/egress cil_from_host-cilium_host id 559
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 549
lxc8207b4a427c9(12) clsact/ingress cil_from_container-lxc8207b4a427c9 id 510
lxceb3c08e95539(14) clsact/ingress cil_from_container-lxceb3c08e95539 id 526
lxc0a64ff509add(18) clsact/ingress cil_from_container-lxc0a64ff509add id 629

flow_dissector:

netfilter:

