1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:1b:61:f1:7b:9f brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.172.29/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2733sec preferred_lft 2733sec
    inet6 fe80::41b:61ff:fef1:7b9f/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:05:d8:75:cd:fd brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.146.26/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::405:d8ff:fe75:cdfd/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:59:90:bc:f2:86 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8059:90ff:febc:f286/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:b0:34:4e:ad:2c brd ff:ff:ff:ff:ff:ff
    inet 10.58.0.38/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::20b0:34ff:fe4e:ad2c/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether a2:18:56:48:c6:11 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a018:56ff:fe48:c611/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:84:bd:64:e6:0a brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::7084:bdff:fe64:e60a/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc8207b4a427c9@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:22:59:e4:c0:0a brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::3022:59ff:fee4:c00a/64 scope link 
       valid_lft forever preferred_lft forever
14: lxceb3c08e95539@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:10:0c:6b:b1:0b brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ac10:cff:fe6b:b10b/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc0a64ff509add@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:13:93:9f:53:70 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::813:93ff:fe9f:5370/64 scope link 
       valid_lft forever preferred_lft forever
