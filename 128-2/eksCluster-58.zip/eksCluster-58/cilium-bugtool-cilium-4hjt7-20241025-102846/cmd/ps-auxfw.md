USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         669  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         656  0.0  0.3 1240432 15508 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         689  0.0  0.0   6408  1648 ?        R    10:28   0:00  \_ ps auxfw
root         690  0.0  0.0   2068   240 ?        R    10:28   0:00  \_ hostname
root         650  0.0  0.0 1228744 3604 ?        Ssl  10:28   0:00 /bin/gops stats 1
root         644  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops stack 1
root         628  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  2.8  7.1 1472496 280280 ?      Ssl  10:15   0:23 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.1 1228848 5752 ?        Sl   10:15   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
