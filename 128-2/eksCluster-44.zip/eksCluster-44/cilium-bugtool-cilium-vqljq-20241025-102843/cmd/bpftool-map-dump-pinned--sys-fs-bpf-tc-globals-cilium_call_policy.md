key: b0 01 00 00  value: 46 02 00 00
key: cb 0a 00 00  value: 90 02 00 00
key: 68 0b 00 00  value: 1d 02 00 00
key: af 0e 00 00  value: 4e 02 00 00
Found 4 elements
