markdown output at /tmp/cilium-bugtool-20241025-102844.58+0000-UTC-3147725257/cmd/cilium-debuginfo-20241025-102915.258+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102844.58+0000-UTC-3147725257/cmd/cilium-debuginfo-20241025-102915.258+0000-UTC.json
