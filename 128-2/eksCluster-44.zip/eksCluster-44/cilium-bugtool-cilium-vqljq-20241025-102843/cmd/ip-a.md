1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:4e:df:9b:10:93 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.140.221/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2738sec preferred_lft 2738sec
    inet6 fe80::44e:dfff:fe9b:1093/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:1c:18:42:4f:df brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.143.251/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::41c:18ff:fe42:4fdf/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:3e:a5:f4:f3:a3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2c3e:a5ff:fef4:f3a3/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:66:7b:85:7a:a7 brd ff:ff:ff:ff:ff:ff
    inet 10.44.0.60/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::4066:7bff:fe85:7aa7/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether a2:c0:3c:0c:58:31 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a0c0:3cff:fe0c:5831/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:b6:5e:51:ee:d1 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::80b6:5eff:fe51:eed1/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc0d458d1c6363@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:b5:87:cd:0e:68 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c8b5:87ff:fecd:e68/64 scope link 
       valid_lft forever preferred_lft forever
14: lxca1755fc71dbb@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:46:25:9a:03:62 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::f046:25ff:fe9a:362/64 scope link 
       valid_lft forever preferred_lft forever
18: lxceacd725f28f8@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:7e:2b:65:e7:48 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c07e:2bff:fe65:e748/64 scope link 
       valid_lft forever preferred_lft forever
