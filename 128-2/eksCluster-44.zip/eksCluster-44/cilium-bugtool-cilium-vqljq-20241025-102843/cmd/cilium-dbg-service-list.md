ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.136.251:443 (active)    
                                        2 => 172.31.214.108:443 (active)    
2    10.100.64.237:443   ClusterIP      1 => 172.31.140.221:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.44.0.18:53 (active)         
                                        2 => 10.44.0.154:53 (active)        
4    10.100.0.10:9153    ClusterIP      1 => 10.44.0.18:9153 (active)       
                                        2 => 10.44.0.154:9153 (active)      
5    10.100.232.9:2379   ClusterIP      1 => 10.44.0.77:2379 (active)       
