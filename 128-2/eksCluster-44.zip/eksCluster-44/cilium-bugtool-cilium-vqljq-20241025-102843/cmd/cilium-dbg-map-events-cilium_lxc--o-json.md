{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:43.035Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.140.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:43.035Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.143.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:43.035Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:45.796Z",
  "value": "id=432   sec_id=4     flags=0x0000 ifindex=10  mac=0E:EB:2D:1D:51:6B nodemac=82:B6:5E:51:EE:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:48.873Z",
  "value": "id=2920  sec_id=2962584 flags=0x0000 ifindex=14  mac=4E:91:EE:35:63:E4 nodemac=F2:46:25:9A:03:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:48.883Z",
  "value": "id=3759  sec_id=2962584 flags=0x0000 ifindex=12  mac=6A:E0:30:02:04:69 nodemac=CA:B5:87:CD:0E:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:48.952Z",
  "value": "id=432   sec_id=4     flags=0x0000 ifindex=10  mac=0E:EB:2D:1D:51:6B nodemac=82:B6:5E:51:EE:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:48.977Z",
  "value": "id=3759  sec_id=2962584 flags=0x0000 ifindex=12  mac=6A:E0:30:02:04:69 nodemac=CA:B5:87:CD:0E:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:28.314Z",
  "value": "id=432   sec_id=4     flags=0x0000 ifindex=10  mac=0E:EB:2D:1D:51:6B nodemac=82:B6:5E:51:EE:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:28.314Z",
  "value": "id=3759  sec_id=2962584 flags=0x0000 ifindex=12  mac=6A:E0:30:02:04:69 nodemac=CA:B5:87:CD:0E:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:28.315Z",
  "value": "id=2920  sec_id=2962584 flags=0x0000 ifindex=14  mac=4E:91:EE:35:63:E4 nodemac=F2:46:25:9A:03:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:28.347Z",
  "value": "id=358   sec_id=3002561 flags=0x0000 ifindex=16  mac=FE:A8:D0:E9:A5:9E nodemac=66:F1:E3:AA:63:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:29.314Z",
  "value": "id=432   sec_id=4     flags=0x0000 ifindex=10  mac=0E:EB:2D:1D:51:6B nodemac=82:B6:5E:51:EE:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:29.314Z",
  "value": "id=358   sec_id=3002561 flags=0x0000 ifindex=16  mac=FE:A8:D0:E9:A5:9E nodemac=66:F1:E3:AA:63:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:29.314Z",
  "value": "id=2920  sec_id=2962584 flags=0x0000 ifindex=14  mac=4E:91:EE:35:63:E4 nodemac=F2:46:25:9A:03:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:29.314Z",
  "value": "id=3759  sec_id=2962584 flags=0x0000 ifindex=12  mac=6A:E0:30:02:04:69 nodemac=CA:B5:87:CD:0E:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:06.647Z",
  "value": "id=2763  sec_id=3002561 flags=0x0000 ifindex=18  mac=66:6B:68:6D:57:A3 nodemac=C2:7E:2B:65:E7:48"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.44.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:12.977Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:13.909Z",
  "value": "id=432   sec_id=4     flags=0x0000 ifindex=10  mac=0E:EB:2D:1D:51:6B nodemac=82:B6:5E:51:EE:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:13.909Z",
  "value": "id=3759  sec_id=2962584 flags=0x0000 ifindex=12  mac=6A:E0:30:02:04:69 nodemac=CA:B5:87:CD:0E:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:13.910Z",
  "value": "id=2920  sec_id=2962584 flags=0x0000 ifindex=14  mac=4E:91:EE:35:63:E4 nodemac=F2:46:25:9A:03:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:13.910Z",
  "value": "id=2763  sec_id=3002561 flags=0x0000 ifindex=18  mac=66:6B:68:6D:57:A3 nodemac=C2:7E:2B:65:E7:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:14.910Z",
  "value": "id=2763  sec_id=3002561 flags=0x0000 ifindex=18  mac=66:6B:68:6D:57:A3 nodemac=C2:7E:2B:65:E7:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:14.910Z",
  "value": "id=432   sec_id=4     flags=0x0000 ifindex=10  mac=0E:EB:2D:1D:51:6B nodemac=82:B6:5E:51:EE:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:14.910Z",
  "value": "id=3759  sec_id=2962584 flags=0x0000 ifindex=12  mac=6A:E0:30:02:04:69 nodemac=CA:B5:87:CD:0E:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:14.911Z",
  "value": "id=2920  sec_id=2962584 flags=0x0000 ifindex=14  mac=4E:91:EE:35:63:E4 nodemac=F2:46:25:9A:03:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:15.910Z",
  "value": "id=432   sec_id=4     flags=0x0000 ifindex=10  mac=0E:EB:2D:1D:51:6B nodemac=82:B6:5E:51:EE:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:15.910Z",
  "value": "id=3759  sec_id=2962584 flags=0x0000 ifindex=12  mac=6A:E0:30:02:04:69 nodemac=CA:B5:87:CD:0E:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:15.910Z",
  "value": "id=2763  sec_id=3002561 flags=0x0000 ifindex=18  mac=66:6B:68:6D:57:A3 nodemac=C2:7E:2B:65:E7:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.44.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:15.910Z",
  "value": "id=2920  sec_id=2962584 flags=0x0000 ifindex=14  mac=4E:91:EE:35:63:E4 nodemac=F2:46:25:9A:03:62"
}

