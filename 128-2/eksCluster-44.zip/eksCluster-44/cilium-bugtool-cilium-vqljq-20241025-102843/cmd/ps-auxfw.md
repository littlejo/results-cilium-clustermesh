USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         661  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops stats 1
root         655  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         648  0.0  0.4 1240432 16032 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         684  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         627  0.0  0.1 1228744 4040 ?        Ssl  10:28   0:00 /bin/gops stack 1
root         620  0.0  0.0 1228744 3656 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  2.8  6.8 1472240 270532 ?      Ssl  10:15   0:22 cilium-agent --config-dir=/tmp/cilium/config-map
root         391  0.0  0.1 1228848 5904 ?        Sl   10:15   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
