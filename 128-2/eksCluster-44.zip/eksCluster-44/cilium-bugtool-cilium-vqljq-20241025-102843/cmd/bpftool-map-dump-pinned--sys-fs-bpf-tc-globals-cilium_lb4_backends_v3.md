key: 06 00 00 00  value: 0a 2c 00 12 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 2c 00 12 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f d6 6c 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 2c 00 9a 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f 8c dd 10 94 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 2c 00 9a 00 35 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 2c 00 4d 09 4b 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 88 fb 01 bb 00 00  00 00 00 00
Found 8 elements
