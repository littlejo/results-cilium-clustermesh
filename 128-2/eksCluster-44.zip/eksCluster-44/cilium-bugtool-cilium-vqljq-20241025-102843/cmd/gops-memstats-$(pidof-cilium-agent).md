alloc: 80.17MB (84059312 bytes)
total-alloc: 1.32GB (1422354776 bytes)
sys: 214.70MB (225125716 bytes)
lookups: 0
mallocs: 47598206
frees: 47094336
heap-alloc: 80.17MB (84059312 bytes)
heap-sys: 171.64MB (179978240 bytes)
heap-idle: 46.55MB (48816128 bytes)
heap-in-use: 125.09MB (131162112 bytes)
heap-released: 2.71MB (2842624 bytes)
heap-objects: 503870
stack-in-use: 32.31MB (33882112 bytes)
stack-sys: 32.31MB (33882112 bytes)
stack-mspan-inuse: 1.93MB (2020000 bytes)
stack-mspan-sys: 2.61MB (2741760 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1009.67KB (1033905 bytes)
gc-sys: 5.23MB (5482656 bytes)
next-gc: when heap-alloc >= 146.84MB (153972088 bytes)
last-gc: 2024-10-25 10:29:12.747837471 +0000 UTC
gc-pause-total: 9.408217ms
gc-pause: 81182
gc-pause-end: 1729852152747837471
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.00031468609663207935
enable-gc: true
debug-gc: false
