Node 0, zone      DMA      3      2      2      2     10      9      5      3      1      3    165 
Node 0, zone   Normal    417     66     16      6      8      4      3      3      2      3      7 
