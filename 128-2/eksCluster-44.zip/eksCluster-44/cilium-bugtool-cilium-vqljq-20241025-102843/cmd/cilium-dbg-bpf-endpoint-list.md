IP ADDRESS         LOCAL ENDPOINT INFO
10.44.0.59:0       id=432   sec_id=4     flags=0x0000 ifindex=10  mac=0E:EB:2D:1D:51:6B nodemac=82:B6:5E:51:EE:D1     
172.31.140.221:0   (localhost)                                                                                        
10.44.0.18:0       id=3759  sec_id=2962584 flags=0x0000 ifindex=12  mac=6A:E0:30:02:04:69 nodemac=CA:B5:87:CD:0E:68   
172.31.143.251:0   (localhost)                                                                                        
10.44.0.154:0      id=2920  sec_id=2962584 flags=0x0000 ifindex=14  mac=4E:91:EE:35:63:E4 nodemac=F2:46:25:9A:03:62   
10.44.0.77:0       id=2763  sec_id=3002561 flags=0x0000 ifindex=18  mac=66:6B:68:6D:57:A3 nodemac=C2:7E:2B:65:E7:48   
10.44.0.60:0       (localhost)                                                                                        
