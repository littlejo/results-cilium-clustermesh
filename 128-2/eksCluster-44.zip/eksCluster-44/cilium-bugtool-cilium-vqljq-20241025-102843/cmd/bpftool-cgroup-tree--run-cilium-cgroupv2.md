CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4a986b30_87c9_4041_93cb_6f161179634d.slice/cri-containerd-10975aa1646e1984de6560dd5843f67a075fea31fbe71522fb7f42afb8dc7f15.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4a986b30_87c9_4041_93cb_6f161179634d.slice/cri-containerd-39d8bbd3fe3820dfbf633e88e1d13f6e5421a3ce474d05824653a3093701e419.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc8b01e7c_76d3_4624_adfd_9266e6497792.slice/cri-containerd-90ed1c54ea42fc69a6125a6447ec23a150cc9996886bdad2fd291d88bada22eb.scope
    606      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc8b01e7c_76d3_4624_adfd_9266e6497792.slice/cri-containerd-9affe2c151974a0eb1370fb35e481399f04203f1ea865131c659e69d542f94e1.scope
    610      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode54fbfce_1799_422d_a831_e153ba971b99.slice/cri-containerd-641a4b10db044e4ec926ef4031a924ffae7ec8ff8c8cca20c7b21579839d582c.scope
    614      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode54fbfce_1799_422d_a831_e153ba971b99.slice/cri-containerd-f95bab4af8a2073bed35cf905d722dba5267821b20564cb0fe89488141fe31ce.scope
    602      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc152dca8_adc6_4cb7_b698_6247d43a283f.slice/cri-containerd-677fc0e6f2cb112035d7dd2ddb7bd5e74a87a34ce4d6e7d98e2731471256d235.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc152dca8_adc6_4cb7_b698_6247d43a283f.slice/cri-containerd-202cae4104b08da44bd3f5d6466b153720a9566379ee9481e2d8a6b0fe067ddb.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda088a032_0e44_4d98_96c6_538bafc99eb5.slice/cri-containerd-edee82e251e943adc152793729557a544c6248930751df1d012cb2b64328a8dd.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda088a032_0e44_4d98_96c6_538bafc99eb5.slice/cri-containerd-f35e2125d84f0d0653c86e57247e8e423f6612e55e083dbf735fc5b039ddf77b.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb5027ae_44e2_4035_910b_710e489add3f.slice/cri-containerd-cca9b5ce9bda3f5c2395fdde240c2d6ad6509c910c43ea17cdfa7daf13a09757.scope
    668      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb5027ae_44e2_4035_910b_710e489add3f.slice/cri-containerd-39ee37a90d8fe8e1dec7ed11c740e4ae3524a30e5c23dfdb8cc54d28e26f2932.scope
    684      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb5027ae_44e2_4035_910b_710e489add3f.slice/cri-containerd-867072fe28649dca4ddca08ef3a9ad7e921a35cf927e2f365487f60d656112e7.scope
    692      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb5027ae_44e2_4035_910b_710e489add3f.slice/cri-containerd-b001b2f1c7662a1b9fb5b35495d635d1dc553aa657399ee5378ebdf3ffdb7f7e.scope
    688      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3bdddb6e_4842_4bcd_bf18_a65f077e4ba6.slice/cri-containerd-b3b983c7bbfc97eaefbc838026b9fe0631906a28d6257c4790057d0ffb28c12e.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3bdddb6e_4842_4bcd_bf18_a65f077e4ba6.slice/cri-containerd-d445dd0b3d11f55c8485592d6d8260b9afaf1e0ec6c31aadd34285d76ac1a6bb.scope
    109      cgroup_device   multi                                          
