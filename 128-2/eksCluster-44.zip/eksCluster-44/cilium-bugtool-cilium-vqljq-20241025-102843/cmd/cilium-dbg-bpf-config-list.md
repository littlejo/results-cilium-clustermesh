KEY             VALUE
AgentLiveness   902594004032
UTimeOffset     3378615728515625
