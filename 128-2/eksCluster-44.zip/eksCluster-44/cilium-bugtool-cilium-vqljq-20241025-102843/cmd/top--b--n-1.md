top - 10:28:44 up 14 min,  0 users,  load average: 0.04, 0.21, 0.19
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 10.0 us, 23.3 sy,  0.0 ni, 63.3 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   3836.2 total,    799.8 free,    894.7 used,   2141.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2772.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    648 root      20   0 1240432  16032  11292 S   6.7   0.4   0:00.03 cilium-+
      1 root      20   0 1472240 270532  77900 S   0.0   6.9   0:22.48 cilium-+
    391 root      20   0 1228848   5904   3056 S   0.0   0.2   0:00.27 cilium-+
    620 root      20   0 1228744   3656   2976 S   0.0   0.1   0:00.00 gops
    627 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    655 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    661 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    696 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    714 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
