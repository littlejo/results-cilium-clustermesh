35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:14:16+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:14:16+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:16+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:16+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:14:16+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:14:16+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
66: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
495: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:15:46+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,102
	btf_id 136
496: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:15:46+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 137
497: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:15:46+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 138
498: sched_cls  name tail_handle_ipv4  tag 3a2d3ad294540046  gpl
	loaded_at 2024-10-25T10:15:46+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,102
	btf_id 139
528: sched_cls  name tail_handle_ipv4_cont  tag 3f4c2119ebe819a6  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,115,41,112,82,83,39,76,74,77,116,40,37,38,81
	btf_id 175
529: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 177
530: sched_cls  name tail_ipv4_to_endpoint  tag 76680e856eacd3f7  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,112,39,116,40,37,38
	btf_id 178
531: sched_cls  name cil_from_container  tag 0ecd37270cb295b3  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 179
534: sched_cls  name tail_ipv4_ct_egress  tag 0f6027a0b759b1d5  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 180
536: sched_cls  name tail_handle_ipv4  tag 08e5d72f2b37ee76  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 183
537: sched_cls  name tail_handle_arp  tag 5338dbe9b41217fb  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 184
539: sched_cls  name tail_ipv4_ct_ingress  tag 8af9746bfc642326  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 186
541: sched_cls  name handle_policy  tag b75f25a961885836  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,112,39,84,75,40,37,38
	btf_id 188
542: sched_cls  name __send_drop_notify  tag 53cc5355b2f13e5e  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 190
545: sched_cls  name tail_handle_arp  tag 4f0d96a5a266d84d  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,117
	btf_id 194
550: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 195
551: sched_cls  name tail_ipv4_ct_ingress  tag 9a2202b650f227e4  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 199
552: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 201
554: sched_cls  name __send_drop_notify  tag 79851a34aabc73a7  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 203
556: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,120
	btf_id 206
557: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 207
558: sched_cls  name tail_ipv4_to_endpoint  tag d2e730339d2542ad  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,118,41,82,83,80,91,39,117,40,37,38
	btf_id 204
559: sched_cls  name tail_handle_ipv4_from_host  tag 7304cb4825c1d895  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 208
563: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 214
564: sched_cls  name tail_handle_ipv4_from_host  tag 7304cb4825c1d895  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 215
565: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 216
567: sched_cls  name __send_drop_notify  tag 79851a34aabc73a7  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 218
568: sched_cls  name tail_handle_ipv4_from_host  tag 7304cb4825c1d895  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 220
571: sched_cls  name __send_drop_notify  tag 79851a34aabc73a7  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 223
572: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 224
574: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 226
577: sched_cls  name __send_drop_notify  tag 79851a34aabc73a7  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 230
578: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,125,75
	btf_id 231
580: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,125
	btf_id 233
581: sched_cls  name tail_handle_ipv4_from_host  tag 7304cb4825c1d895  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,125
	btf_id 234
582: sched_cls  name handle_policy  tag 431e59fb9c94ebba  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,117,82,83,118,41,80,91,39,84,75,40,37,38
	btf_id 212
583: sched_cls  name tail_ipv4_ct_egress  tag 0f6027a0b759b1d5  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,127,82,83,128,84
	btf_id 236
585: sched_cls  name tail_handle_ipv4  tag aa671261f72b7a47  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,117
	btf_id 237
586: sched_cls  name tail_handle_ipv4_cont  tag e0a3dcc5b39f8cb8  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,118,41,91,82,83,39,76,74,77,117,40,37,38,81
	btf_id 240
587: sched_cls  name cil_from_container  tag 5d06bf3f3e02dd6b  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 117,76
	btf_id 241
588: sched_cls  name __send_drop_notify  tag aa59a015febbeca0  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 242
589: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,117
	btf_id 243
590: sched_cls  name handle_policy  tag 2169ec326f1a9620  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,127,82,83,128,41,80,103,39,84,75,40,37,38
	btf_id 239
591: sched_cls  name tail_handle_arp  tag b2d9d299273e0de7  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,127
	btf_id 244
592: sched_cls  name cil_from_container  tag 24fea8ab086553c8  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 127,76
	btf_id 245
593: sched_cls  name tail_handle_ipv4_cont  tag 685a2817991f4e33  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,128,41,103,82,83,39,76,74,77,127,40,37,38,81
	btf_id 246
594: sched_cls  name __send_drop_notify  tag ac934a9982eb2dae  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 247
595: sched_cls  name tail_ipv4_ct_ingress  tag 1186e64187c39edb  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,127,82,83,128,84
	btf_id 248
596: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,127
	btf_id 249
597: sched_cls  name tail_ipv4_to_endpoint  tag 9bec1d7d0d54774a  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,128,41,82,83,80,103,39,127,40,37,38
	btf_id 250
598: sched_cls  name tail_handle_ipv4  tag f17f3cc8804cae31  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,127
	btf_id 251
599: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
602: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
603: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
606: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
607: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
610: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
611: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
614: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
654: sched_cls  name tail_ipv4_ct_ingress  tag fe31c39c2df72beb  gpl
	loaded_at 2024-10-25T10:23:06+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,144,82,83,145,84
	btf_id 265
655: sched_cls  name cil_from_container  tag cbb04cc1d8cd417f  gpl
	loaded_at 2024-10-25T10:23:06+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 144,76
	btf_id 266
656: sched_cls  name handle_policy  tag 699d57dbbabd710b  gpl
	loaded_at 2024-10-25T10:23:06+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,144,82,83,145,41,80,143,39,84,75,40,37,38
	btf_id 267
657: sched_cls  name __send_drop_notify  tag 094d137b48e30bc4  gpl
	loaded_at 2024-10-25T10:23:06+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 268
658: sched_cls  name tail_ipv4_ct_egress  tag bca7bc4ab6888947  gpl
	loaded_at 2024-10-25T10:23:06+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,144,82,83,145,84
	btf_id 269
659: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:23:06+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,144
	btf_id 270
660: sched_cls  name tail_ipv4_to_endpoint  tag 4c470faca8b9ac26  gpl
	loaded_at 2024-10-25T10:23:06+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,145,41,82,83,80,143,39,144,40,37,38
	btf_id 271
662: sched_cls  name tail_handle_ipv4_cont  tag dfab9a03a29f4073  gpl
	loaded_at 2024-10-25T10:23:06+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,145,41,143,82,83,39,76,74,77,144,40,37,38,81
	btf_id 273
663: sched_cls  name tail_handle_arp  tag cf470f856098a7fb  gpl
	loaded_at 2024-10-25T10:23:06+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,144
	btf_id 274
664: sched_cls  name tail_handle_ipv4  tag 2dd9ed4d869a9b09  gpl
	loaded_at 2024-10-25T10:23:06+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,144
	btf_id 275
665: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
668: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
681: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
684: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
685: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
688: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
689: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
692: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
