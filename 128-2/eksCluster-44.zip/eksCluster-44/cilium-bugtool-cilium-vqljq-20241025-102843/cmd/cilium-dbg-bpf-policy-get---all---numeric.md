Endpoint ID: 432
Path: /sys/fs/bpf/tc/globals/cilium_policy_00432

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    437320   5591      0        
Allow    Ingress     1          ANY          NONE         disabled    12043    142       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 444
Path: /sys/fs/bpf/tc/globals/cilium_policy_00444

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2763
Path: /sys/fs/bpf/tc/globals/cilium_policy_02763

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3871832   35547     0        
Allow    Ingress     1          ANY          NONE         disabled    2944884   29676     0        
Allow    Egress      0          ANY          NONE         disabled    3627068   34078     0        


Endpoint ID: 2920
Path: /sys/fs/bpf/tc/globals/cilium_policy_02920

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    75402   863       0        
Allow    Egress      0          ANY          NONE         disabled    13907   144       0        


Endpoint ID: 3759
Path: /sys/fs/bpf/tc/globals/cilium_policy_03759

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    75377   865       0        
Allow    Egress      0          ANY          NONE         disabled    13238   137       0        


