[
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb5027ae_44e2_4035_910b_710e489add3f.slice/cri-containerd-b001b2f1c7662a1b9fb5b35495d635d1dc553aa657399ee5378ebdf3ffdb7f7e.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb5027ae_44e2_4035_910b_710e489add3f.slice/cri-containerd-39ee37a90d8fe8e1dec7ed11c740e4ae3524a30e5c23dfdb8cc54d28e26f2932.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb5027ae_44e2_4035_910b_710e489add3f.slice/cri-containerd-867072fe28649dca4ddca08ef3a9ad7e921a35cf927e2f365487f60d656112e7.scope"
      }
    ],
    "ips": [
      "10.44.0.77"
    ],
    "name": "clustermesh-apiserver-7bb9d9dcbc-7b6fn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc8b01e7c_76d3_4624_adfd_9266e6497792.slice/cri-containerd-9affe2c151974a0eb1370fb35e481399f04203f1ea865131c659e69d542f94e1.scope"
      }
    ],
    "ips": [
      "10.44.0.18"
    ],
    "name": "coredns-cc6ccd49c-z9txs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode54fbfce_1799_422d_a831_e153ba971b99.slice/cri-containerd-641a4b10db044e4ec926ef4031a924ffae7ec8ff8c8cca20c7b21579839d582c.scope"
      }
    ],
    "ips": [
      "10.44.0.154"
    ],
    "name": "coredns-cc6ccd49c-rbdtz",
    "namespace": "kube-system"
  }
]

