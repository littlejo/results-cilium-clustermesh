# Cilium debug information

#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.44.0.0/24, 
Allocated addresses:
  10.44.0.154 (kube-system/coredns-cc6ccd49c-rbdtz)
  10.44.0.18 (kube-system/coredns-cc6ccd49c-z9txs)
  10.44.0.59 (health)
  10.44.0.60 (router)
  10.44.0.77 (kube-system/clustermesh-apiserver-7bb9d9dcbc-7b6fn)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9deabc22cc74e5d8
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    28s ago        never        0       no error   
  ct-map-pressure                                                     2s ago         never        0       no error   
  daemon-validate-config                                              19s ago        never        0       no error   
  dns-garbage-collector-job                                           34s ago        never        0       no error   
  endpoint-2763-regeneration-recovery                                 never          never        0       no error   
  endpoint-2920-regeneration-recovery                                 never          never        0       no error   
  endpoint-3759-regeneration-recovery                                 never          never        0       no error   
  endpoint-432-regeneration-recovery                                  never          never        0       no error   
  endpoint-444-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         3m34s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                2s ago         never        0       no error   
  ipcache-inject-labels                                               32s ago        never        0       no error   
  k8s-heartbeat                                                       4s ago         never        0       no error   
  link-cache                                                          16s ago        never        0       no error   
  local-identity-checkpoint                                           13m32s ago     never        0       no error   
  node-neighbor-link-updater                                          1s ago         never        0       no error   
  remote-etcd-cmesh1                                                  6m1s ago       never        0       no error   
  remote-etcd-cmesh10                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh100                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh101                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh102                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh103                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh104                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh105                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh106                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh107                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh108                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh109                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh11                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh110                                                6m0s ago       never        0       no error   
  remote-etcd-cmesh111                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh112                                                6m0s ago       never        0       no error   
  remote-etcd-cmesh113                                                6m0s ago       never        0       no error   
  remote-etcd-cmesh114                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh115                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh116                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh117                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh118                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh119                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh12                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh120                                                6m0s ago       never        0       no error   
  remote-etcd-cmesh121                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh122                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh123                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh124                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh125                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh126                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh127                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh128                                                6m1s ago       never        0       no error   
  remote-etcd-cmesh13                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh14                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh15                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh16                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh17                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh18                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh19                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh2                                                  6m1s ago       never        0       no error   
  remote-etcd-cmesh20                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh21                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh22                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh23                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh24                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh25                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh26                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh27                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh28                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh29                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh3                                                  6m1s ago       never        0       no error   
  remote-etcd-cmesh30                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh31                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh32                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh33                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh34                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh35                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh36                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh37                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh38                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh39                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh4                                                  6m1s ago       never        0       no error   
  remote-etcd-cmesh40                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh41                                                 6m0s ago       never        0       no error   
  remote-etcd-cmesh42                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh43                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh44                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh46                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh47                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh48                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh49                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh5                                                  6m1s ago       never        0       no error   
  remote-etcd-cmesh50                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh51                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh52                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh53                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh54                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh55                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh56                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh57                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh58                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh59                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh6                                                  6m1s ago       never        0       no error   
  remote-etcd-cmesh60                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh61                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh62                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh63                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh64                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh65                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh66                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh67                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh68                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh69                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh7                                                  6m1s ago       never        0       no error   
  remote-etcd-cmesh70                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh71                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh72                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh73                                                 6m0s ago       never        0       no error   
  remote-etcd-cmesh74                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh75                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh76                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh77                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh78                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh79                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh8                                                  6m1s ago       never        0       no error   
  remote-etcd-cmesh80                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh81                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh82                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh83                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh84                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh85                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh86                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh87                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh88                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh89                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh9                                                  6m1s ago       never        0       no error   
  remote-etcd-cmesh90                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh91                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh92                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh93                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh94                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh95                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh96                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh97                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh98                                                 6m1s ago       never        0       no error   
  remote-etcd-cmesh99                                                 6m1s ago       never        0       no error   
  resolve-identity-2763                                               1m8s ago       never        0       no error   
  resolve-identity-2920                                               3m30s ago      never        0       no error   
  resolve-identity-3759                                               3m30s ago      never        0       no error   
  resolve-identity-432                                                3m32s ago      never        0       no error   
  resolve-identity-444                                                3m32s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-7bb9d9dcbc-7b6fn   6m8s ago       never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-rbdtz                  13m30s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-z9txs                  13m30s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      13m32s ago     never        0       no error   
  sync-policymap-2763                                                 6m8s ago       never        0       no error   
  sync-policymap-2920                                                 13m26s ago     never        0       no error   
  sync-policymap-3759                                                 13m26s ago     never        0       no error   
  sync-policymap-432                                                  13m29s ago     never        0       no error   
  sync-policymap-444                                                  13m30s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (2763)                                   8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2920)                                   10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (3759)                                   10s ago        never        0       no error   
  sync-utime                                                          32s ago        never        0       no error   
  write-cni-file                                                      13m34s ago     never        0       no error   
Proxy Status:            OK, ip 10.44.0.60, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 2949120, max 3014655
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 74.01   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium encryption



#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 33634648                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 33634648                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 33634648                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d400000 rw-p 00000000 00:00 0 
400d400000-4010000000 ---p 00000000 00:00 0 
ffff6d0a9000-ffff6d30f000 rw-p 00000000 00:00 0 
ffff6d317000-ffff6d438000 rw-p 00000000 00:00 0 
ffff6d438000-ffff6d479000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff6d479000-ffff6d4ba000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff6d4ba000-ffff6d4bc000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff6d4bc000-ffff6d4be000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff6d4be000-ffff6da75000 rw-p 00000000 00:00 0 
ffff6da75000-ffff6db75000 rw-p 00000000 00:00 0 
ffff6db75000-ffff6db86000 rw-p 00000000 00:00 0 
ffff6db86000-ffff6fb86000 rw-p 00000000 00:00 0 
ffff6fb86000-ffff6fc06000 ---p 00000000 00:00 0 
ffff6fc06000-ffff6fc07000 rw-p 00000000 00:00 0 
ffff6fc07000-ffff8fc06000 ---p 00000000 00:00 0 
ffff8fc06000-ffff8fc07000 rw-p 00000000 00:00 0 
ffff8fc07000-ffffafb96000 ---p 00000000 00:00 0 
ffffafb96000-ffffafb97000 rw-p 00000000 00:00 0 
ffffafb97000-ffffb3b88000 ---p 00000000 00:00 0 
ffffb3b88000-ffffb3b89000 rw-p 00000000 00:00 0 
ffffb3b89000-ffffb4386000 ---p 00000000 00:00 0 
ffffb4386000-ffffb4387000 rw-p 00000000 00:00 0 
ffffb4387000-ffffb4486000 ---p 00000000 00:00 0 
ffffb4486000-ffffb44e6000 rw-p 00000000 00:00 0 
ffffb44e6000-ffffb44e8000 r--p 00000000 00:00 0                          [vvar]
ffffb44e8000-ffffb44e9000 r-xp 00000000 00:00 0                          [vdso]
ffffc346c000-ffffc348d000 rw-p 00000000 00:00 0                          [stack]

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.44.0.77": (string) (len=50) "kube-system/clustermesh-apiserver-7bb9d9dcbc-7b6fn",
  (string) (len=10) "10.44.0.60": (string) (len=6) "router",
  (string) (len=10) "10.44.0.59": (string) (len=6) "health",
  (string) (len=10) "10.44.0.18": (string) (len=35) "kube-system/coredns-cc6ccd49c-z9txs",
  (string) (len=11) "10.44.0.154": (string) (len=35) "kube-system/coredns-cc6ccd49c-rbdtz"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.140.221": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001d4a630)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x40000bade0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x40000bade0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4002d820b0)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4002d82160)(frontends:[10.100.232.9]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4001f176b0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4001f17760)(frontends:[10.100.64.237]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4002657130)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4001201758)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4002290410)(172.31.136.251:443/TCP,172.31.214.108:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4001201760)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-9qwbh": (*k8s.Endpoints)(0x40010d00d0)(172.31.140.221:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4001201768)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-bg2mn": (*k8s.Endpoints)(0x400216fba0)(10.44.0.154:53/TCP[eu-west-3a],10.44.0.154:53/UDP[eu-west-3a],10.44.0.154:9153/TCP[eu-west-3a],10.44.0.18:53/TCP[eu-west-3a],10.44.0.18:53/UDP[eu-west-3a],10.44.0.18:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40012b7530)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-lvz68": (*k8s.Endpoints)(0x400244d2b0)(10.44.0.77:2379/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001bde000)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4002661bd0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x40041fc120
  },
  gcTrigger: (chan struct {}) (cap=1) 0x40026690e0,
  gcExited: (chan struct {}) 0x4002669140,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001be2b80)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000fc85e0)({
      MetricVec: (*prometheus.MetricVec)(0x4001efe810)({
       metricMap: (*prometheus.metricMap)(0x4001efe840)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40024261e0)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001be2c00)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000fc85e8)({
      MetricVec: (*prometheus.MetricVec)(0x4001efe8a0)({
       metricMap: (*prometheus.metricMap)(0x4001efe8d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002426240)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001be2c80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000fc85f0)({
      MetricVec: (*prometheus.MetricVec)(0x4001efe930)({
       metricMap: (*prometheus.metricMap)(0x4001efe960)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40024262a0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001be2d00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000fc85f8)({
      MetricVec: (*prometheus.MetricVec)(0x4001efe9c0)({
       metricMap: (*prometheus.metricMap)(0x4001efe9f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002426300)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001be2d80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000fc8600)({
      MetricVec: (*prometheus.MetricVec)(0x4001efea50)({
       metricMap: (*prometheus.metricMap)(0x4001efea80)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002426360)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001be2e00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000fc8608)({
      MetricVec: (*prometheus.MetricVec)(0x4001efeae0)({
       metricMap: (*prometheus.metricMap)(0x4001efeb10)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40024263c0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001be2e80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000fc8610)({
      MetricVec: (*prometheus.MetricVec)(0x4001efeb70)({
       metricMap: (*prometheus.metricMap)(0x4001efeba0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002426420)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001be2f00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000fc8618)({
      MetricVec: (*prometheus.MetricVec)(0x4001efec00)({
       metricMap: (*prometheus.metricMap)(0x4001efec30)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002426480)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001be2f80)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000fc8620)({
      MetricVec: (*prometheus.MetricVec)(0x4001efec90)({
       metricMap: (*prometheus.metricMap)(0x4001efecc0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40024264e0)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001bde000)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001bdf3b0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001357c20)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 386ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2
  }
 })
})

```


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium environment keys

```
hubble-listen-address::4244
enable-local-node-route:true
endpoint-queue-size:25
tofqdns-proxy-response-max-delay:100ms
hubble-redact-http-userinfo:true
enable-encryption-strict-mode:false
clustermesh-enable-mcs-api:false
wireguard-persistent-keepalive:0s
clustermesh-enable-endpoint-sync:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
prepend-iptables-chains:true
config:
enable-masquerade-to-route-source:false
enable-health-checking:true
vtep-mask:
debug-verbose:
enable-ipsec:false
envoy-base-id:0
enable-tcx:true
version:false
enable-high-scale-ipcache:false
k8s-kubeconfig-path:
disable-endpoint-crd:false
bpf-events-policy-verdict-enabled:true
clustermesh-config:/var/lib/cilium/clustermesh/
enable-envoy-config:false
k8s-namespace:kube-system
ipv6-node:auto
ip-masq-agent-config-path:/etc/config/ip-masq-agent
proxy-gid:1337
bpf-lb-affinity-map-max:0
tofqdns-max-deferred-connection-deletes:10000
operator-api-serve-addr:127.0.0.1:9234
kvstore-opt:
enable-hubble-recorder-api:true
fqdn-regex-compile-lru-size:1024
enable-hubble:true
http-max-grpc-timeout:0
bpf-lb-map-max:65536
enable-host-port:false
enable-gateway-api:false
enable-k8s-terminating-endpoint:true
enable-xt-socket-fallback:true
cni-log-file:/var/run/cilium/cilium-cni.log
conntrack-gc-interval:0s
ipv4-pod-subnets:
enable-l7-proxy:true
hubble-event-queue-size:0
cni-chaining-mode:none
label-prefix-file:
enable-ipv6-ndp:false
custom-cni-conf:false
tofqdns-pre-cache:
hubble-redact-enabled:false
bpf-lb-sock-hostns-only:false
mesh-auth-spire-admin-socket:
trace-payloadlen:128
exclude-node-label-patterns:
log-opt:
tofqdns-endpoint-max-ip-per-hostname:50
cni-exclusive:true
arping-refresh-period:30s
enable-ipv6-masquerade:true
cluster-health-port:4240
lib-dir:/var/lib/cilium
config-dir:/tmp/cilium/config-map
http-normalize-path:true
gops-port:9890
set-cilium-node-taints:true
identity-change-grace-period:5s
http-retry-count:3
identity-restore-grace-period:30s
enable-ipip-termination:false
enable-endpoint-routes:false
tofqdns-min-ttl:0
route-metric:0
kvstore-periodic-sync:5m0s
enable-node-port:false
config-sources:config-map:kube-system/cilium-config
exclude-local-address:
certificates-directory:/var/run/cilium/certs
enable-bpf-tproxy:false
ipv4-service-range:auto
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
enable-ip-masq-agent:false
k8s-heartbeat-timeout:30s
vlan-bpf-bypass:
hubble-redact-http-headers-deny:
hubble-drop-events-interval:2m0s
enable-k8s-networkpolicy:true
bpf-map-event-buffers:
synchronize-k8s-nodes:true
enable-icmp-rules:true
enable-nat46x64-gateway:false
enable-cilium-health-api-server-access:
enable-vtep:false
monitor-queue-size:0
cni-chaining-target:
hubble-export-file-path:
mke-cgroup-mount:
hubble-drop-events:false
vtep-mac:
bpf-lb-source-range-map-max:0
k8s-require-ipv6-pod-cidr:false
envoy-config-retry-interval:15s
endpoint-gc-interval:5m0s
hubble-redact-http-headers-allow:
log-driver:
node-port-range:
cilium-endpoint-gc-interval:5m0s
bpf-sock-rev-map-max:262144
nodeport-addresses:
kube-proxy-replacement-healthz-bind-address:
devices:
monitor-aggregation-flags:all
hubble-export-file-max-backups:5
max-internal-timer-delay:0s
enable-metrics:true
fixed-identity-mapping:
dnsproxy-concurrency-limit:0
enable-node-selector-labels:false
enable-policy:default
policy-accounting:true
enable-identity-mark:true
ipam:cluster-pool
node-port-acceleration:disabled
service-no-backend-response:reject
force-device-detection:false
policy-trigger-interval:1s
dnsproxy-insecure-skip-transparent-mode-check:false
allow-localhost:auto
hubble-recorder-storage-path:/var/run/cilium/pcaps
enable-pmtu-discovery:false
enable-sctp:false
enable-ipsec-key-watcher:true
mtu:0
encrypt-interface:
proxy-max-requests-per-connection:0
tofqdns-proxy-port:0
enable-l2-announcements:false
policy-cidr-match-mode:
bpf-ct-global-tcp-max:524288
enable-host-legacy-routing:false
ipv4-native-routing-cidr:
enable-wireguard:false
bpf-map-dynamic-size-ratio:0.0025
cluster-id:45
agent-liveness-update-interval:1s
tofqdns-enable-dns-compression:true
enable-well-known-identities:false
routing-mode:tunnel
k8s-api-server:
enable-k8s:true
bpf-ct-timeout-service-tcp-grace:1m0s
envoy-secrets-namespace:
enable-route-mtu-for-cni-chaining:false
kvstore-connectivity-timeout:2m0s
kvstore-lease-ttl:15m0s
iptables-random-fully:false
endpoint-bpf-prog-watchdog-interval:30s
encrypt-node:false
bpf-events-drop-enabled:true
ipam-default-ip-pool:default
enable-l2-pod-announcements:false
disable-external-ip-mitigation:false
dnsproxy-concurrency-processing-grace-period:0s
auto-direct-node-routes:false
bpf-ct-timeout-regular-any:1m0s
http-request-timeout:3600
pprof-address:localhost
bpf-ct-timeout-service-any:1m0s
enable-ipsec-xfrm-state-caching:true
metrics:
debug:false
local-router-ipv4:
enable-auto-protect-node-port-range:true
bpf-lb-sock:false
disable-iptables-feeder-rules:
enable-stale-cilium-endpoint-cleanup:true
enable-runtime-device-detection:true
bgp-config-path:/var/lib/cilium/bgp/config.yaml
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
http-idle-timeout:0
ipsec-key-file:
socket-path:/var/run/cilium/cilium.sock
mesh-auth-gc-interval:5m0s
kvstore:
bpf-lb-rev-nat-map-max:0
bypass-ip-availability-upon-restore:false
mesh-auth-rotated-identities-queue-size:1024
mesh-auth-signal-backoff-duration:1s
enable-service-topology:false
node-port-algorithm:random
operator-prometheus-serve-addr::9963
enable-ipsec-encrypted-overlay:false
srv6-encap-mode:reduced
egress-gateway-reconciliation-trigger-interval:1s
hubble-recorder-sink-queue-size:1024
enable-ipv4:true
bpf-lb-rss-ipv6-src-cidr:
enable-health-check-nodeport:true
crd-wait-timeout:5m0s
enable-active-connection-tracking:false
bpf-lb-acceleration:disabled
mesh-auth-enabled:true
enable-ipv6-big-tcp:false
enable-xdp-prefilter:false
ipsec-key-rotation-duration:5m0s
proxy-xff-num-trusted-hops-ingress:0
enable-bandwidth-manager:false
ipv6-pod-subnets:
dns-max-ips-per-restored-rule:1000
ipam-cilium-node-update-rate:15s
local-max-addr-scope:252
encryption-strict-mode-allow-remote-node-identities:false
enable-svc-source-range-check:true
enable-srv6:false
derive-masq-ip-addr-from-device:
proxy-max-connection-duration-seconds:0
kube-proxy-replacement:false
local-router-ipv6:
egress-multi-home-ip-rule-compat:false
hubble-export-file-max-size-mb:10
enable-wireguard-userspace-fallback:false
hubble-drop-events-reasons:auth_required,policy_denied
egress-gateway-policy-map-max:16384
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
tofqdns-idle-connection-grace-period:0s
l2-announcements-renew-deadline:5s
iptables-lock-timeout:5s
bpf-policy-map-full-reconciliation-interval:15m0s
proxy-admin-port:0
bpf-lb-dsr-dispatch:opt
node-labels:
kvstore-max-consecutive-quorum-errors:2
envoy-config-timeout:2m0s
k8s-client-qps:10
identity-gc-interval:15m0s
ipv4-node:auto
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
agent-labels:
hubble-event-buffer-capacity:4095
bpf-neigh-global-max:524288
bpf-lb-rss-ipv4-src-cidr:
enable-ipv4-egress-gateway:false
bpf-ct-timeout-service-tcp:2h13m20s
vtep-cidr:
bpf-lb-dsr-l4-xlate:frontend
pprof-port:6060
tunnel-protocol:vxlan
enable-monitor:true
ingress-secrets-namespace:
cni-external-routing:false
encryption-strict-mode-cidr:
ipv4-range:auto
hubble-export-denylist:
use-full-tls-context:false
policy-queue-size:100
identity-heartbeat-timeout:30m0s
read-cni-conf:
enable-host-firewall:false
tofqdns-dns-reject-response-code:refused
proxy-prometheus-port:0
bgp-announce-lb-ip:false
dnsproxy-enable-transparent-mode:true
bpf-lb-sock-terminate-pod-connections:false
prometheus-serve-addr:
k8s-client-connection-timeout:30s
bpf-root:/sys/fs/bpf
bpf-lb-mode:snat
enable-cilium-endpoint-slice:false
enable-cilium-api-server-access:
enable-l2-neigh-discovery:true
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
k8s-sync-timeout:3m0s
enable-session-affinity:false
dnsproxy-socket-linger-timeout:10
bpf-ct-timeout-regular-tcp-syn:1m0s
enable-endpoint-health-checking:true
annotate-k8s-node:false
restore:true
enable-recorder:false
monitor-aggregation:medium
l2-announcements-retry-period:2s
hubble-metrics-server:
envoy-log:
hubble-flowlogs-config-path:
api-rate-limit:
bpf-auth-map-max:524288
pprof:false
l2-pod-announcements-interface:
labels:
ipam-multi-pool-pre-allocation:
enable-k8s-api-discovery:false
bpf-lb-external-clusterip:false
enable-bpf-clock-probe:false
ipv6-cluster-alloc-cidr:f00d::/64
k8s-client-connection-keep-alive:30s
nodes-gc-interval:5m0s
hubble-monitor-events:
mesh-auth-mutual-listener-port:0
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
hubble-export-allowlist:
nat-map-stats-interval:30s
direct-routing-skip-unreachable:false
multicast-enabled:false
enable-health-check-loadbalancer-ip:false
cluster-name:cmesh45
enable-ipv4-big-tcp:false
enable-external-ips:false
bpf-ct-timeout-regular-tcp-fin:10s
policy-audit-mode:false
enable-ipv4-masquerade:true
ipv4-service-loopback-address:169.254.42.1
proxy-portrange-min:10000
set-cilium-is-up-condition:true
mesh-auth-queue-size:1024
proxy-xff-num-trusted-hops-egress:0
auto-create-cilium-node-resource:true
enable-ipv6:false
mesh-auth-mutual-connect-timeout:5s
container-ip-local-reserved-ports:auto
enable-custom-calls:false
hubble-export-file-compress:false
l2-announcements-lease-duration:15s
max-connected-clusters:255
bpf-lb-service-backend-map-max:0
enable-k8s-endpoint-slice:true
bpf-lb-service-map-max:0
enable-mke:false
bpf-node-map-max:16384
node-port-bind-protection:true
bpf-nat-global-max:524288
enable-local-redirect-policy:false
gateway-api-secrets-namespace:
bpf-ct-global-any-max:262144
agent-health-port:9879
datapath-mode:veth
enable-bgp-control-plane:false
enable-unreachable-routes:false
direct-routing-device:
install-no-conntrack-iptables-rules:false
hubble-redact-http-urlquery:false
hubble-skip-unknown-cgroup-ids:true
allow-icmp-frag-needed:true
enable-ingress-controller:false
controller-group-metrics:
unmanaged-pod-watcher-interval:15
ipv6-mcast-device:
allocator-list-timeout:3m0s
keep-config:false
monitor-aggregation-interval:5s
bpf-events-trace-enabled:true
proxy-portrange-max:20000
install-iptables-rules:true
ipv6-native-routing-cidr:
static-cnp-path:
ipv6-service-range:auto
node-port-mode:snat
bpf-lb-algorithm:random
nat-map-stats-entries:32
conntrack-gc-max-interval:0s
k8s-client-burst:20
clustermesh-ip-identities-sync-timeout:1m0s
proxy-connect-timeout:2
bpf-fragments-map-max:8192
enable-bpf-masquerade:false
remove-cilium-node-taints:true
k8s-service-proxy-name:
bpf-filter-priority:1
enable-tracing:false
egress-masquerade-interfaces:ens+
trace-sock:true
disable-envoy-version-check:false
procfs:/host/proc
k8s-require-ipv4-pod-cidr:false
cgroup-root:/run/cilium/cgroupv2
tunnel-port:0
bpf-lb-maglev-map-max:0
cflags:
hubble-metrics:
external-envoy-proxy:true
preallocate-bpf-maps:false
dns-policy-unload-on-shutdown:false
log-system-load:false
envoy-keep-cap-netbindservice:false
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
join-cluster:false
hubble-redact-kafka-apikey:false
enable-ipv4-fragment-tracking:true
enable-bbr:false
dnsproxy-lock-count:131
ipv6-range:auto
cluster-pool-ipv4-cidr:10.44.0.0/16
max-controller-interval:0
http-retry-timeout:0
dnsproxy-lock-timeout:500ms
bgp-announce-pod-cidr:false
hubble-socket-path:/var/run/cilium/hubble.sock
identity-allocation-mode:crd
use-cilium-internal-ip-for-ipsec:false
hubble-prefer-ipv6:false
state-dir:/var/run/cilium
cmdref:
hubble-disable-tls:false
clustermesh-sync-timeout:1m0s
mesh-auth-spiffe-trust-domain:spiffe.cilium
k8s-service-cache-size:128
hubble-export-fieldmask:
cluster-pool-ipv4-mask-size:24
bpf-policy-map-max:16384
bpf-ct-timeout-regular-tcp:2h13m20s
proxy-idle-timeout-seconds:60
bpf-lb-maglev-table-size:16381
vtep-endpoint:
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
432        Disabled           Disabled          4          reserved:health                                                                     10.44.0.59    ready   
444        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                
                                                           reserved:host                                                                                             
2763       Disabled           Disabled          3002561    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.44.0.77    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh45                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
2920       Disabled           Disabled          2962584    k8s:eks.amazonaws.com/component=coredns                                             10.44.0.154   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh45                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
3759       Disabled           Disabled          2962584    k8s:eks.amazonaws.com/component=coredns                                             10.44.0.18    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh45                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
```

#### BPF Policy Get 432

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    435907   5571      0        
Allow    Ingress     1          ANY          NONE         disabled    12043    142       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 432

```
Invalid argument: unknown type 432
```


#### Endpoint Get 432

```
[
  {
    "id": 432,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-432-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "0576530b-c3f4-47c2-8f9a-d27be0f0511c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-432",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:43.235Z",
            "success-count": 3
          },
          "uuid": "20092f5e-da83-4b5d-a2f0-6c74c37ea8ec"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-432",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:45.797Z",
            "success-count": 1
          },
          "uuid": "acdfdd92-873e-4c31-bb1c-5a8976aa1c2b"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:15Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.44.0.59",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "82:b6:5e:51:ee:d1",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "0e:eb:2d:1d:51:6b"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 432

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 432

```
Timestamp              Status   State                   Message
2024-10-25T10:23:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:15Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:45Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:15:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:43Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:43Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:43Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 444

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 444

```
Invalid argument: unknown type 444
```


#### Endpoint Get 444

```
[
  {
    "id": 444,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-444-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "4e187bc4-cde2-4ca9-b473-377f5229208d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-444",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:43.168Z",
            "success-count": 3
          },
          "uuid": "c1991f32-ca80-415b-ab7a-2396e4b6df96"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-444",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:44.673Z",
            "success-count": 1
          },
          "uuid": "3a172d5f-7ddf-48a3-a5d6-d5784596cc0c"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:15Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "42:66:7b:85:7a:a7",
        "interface-name": "cilium_host",
        "mac": "42:66:7b:85:7a:a7"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 444

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 444

```
Timestamp              Status   State                   Message
2024-10-25T10:23:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:15Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:47Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:43Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:43Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:43Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 2763

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3871470   35543     0        
Allow    Ingress     1          ANY          NONE         disabled    2943924   29665     0        
Allow    Egress      0          ANY          NONE         disabled    3620432   34003     0        

```


#### BPF CT List 2763

```
Invalid argument: unknown type 2763
```


#### Endpoint Get 2763

```
[
  {
    "id": 2763,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2763-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "76c87826-e145-4f52-af2d-f1d9ae571461"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2763",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:06.626Z",
            "success-count": 2
          },
          "uuid": "362b6449-1c64-4b2a-9d25-eaabec91a58c"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-7bb9d9dcbc-7b6fn",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:06.614Z",
            "success-count": 1
          },
          "uuid": "b8fd38a7-4f19-4243-a66a-0430921df448"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2763",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:06.647Z",
            "success-count": 1
          },
          "uuid": "4e13e649-57b9-4b7b-9d9d-766e2b954eeb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2763)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:06.674Z",
            "success-count": 38
          },
          "uuid": "d3d3685f-3daa-4555-997d-9384829bb8e8"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "cca9b5ce9bda3f5c2395fdde240c2d6ad6509c910c43ea17cdfa7daf13a09757:eth0",
        "container-id": "cca9b5ce9bda3f5c2395fdde240c2d6ad6509c910c43ea17cdfa7daf13a09757",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-7bb9d9dcbc-7b6fn",
        "pod-name": "kube-system/clustermesh-apiserver-7bb9d9dcbc-7b6fn"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3002561,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh45",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7bb9d9dcbc"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh45",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:15Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.44.0.77",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "c2:7e:2b:65:e7:48",
        "interface-index": 18,
        "interface-name": "lxceacd725f28f8",
        "mac": "66:6b:68:6d:57:a3"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3002561,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3002561,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2763

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2763

```
Timestamp              Status   State                   Message
2024-10-25T10:23:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:15Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:23:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:06Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:23:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:23:06Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:23:06Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3002561

```
ID        LABELS
3002561   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh45
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 2920

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    75402   863       0        
Allow    Egress      0          ANY          NONE         disabled    13907   144       0        

```


#### BPF CT List 2920

```
Invalid argument: unknown type 2920
```


#### Endpoint Get 2920

```
[
  {
    "id": 2920,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2920-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "8fb17f19-ae67-4ae1-b075-0014b74e8681"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2920",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:44.886Z",
            "success-count": 3
          },
          "uuid": "eed98e40-34f8-4aaf-a912-67503f26de98"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-rbdtz",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:44.885Z",
            "success-count": 1
          },
          "uuid": "dbb829b9-53c9-49ce-97d7-3d001b656e50"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2920",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:48.877Z",
            "success-count": 1
          },
          "uuid": "746c7eba-e0c2-4778-a8de-9df757da2752"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2920)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:14.957Z",
            "success-count": 83
          },
          "uuid": "e7344a38-3353-4c04-b924-6d5cd3bf1b2d"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "f95bab4af8a2073bed35cf905d722dba5267821b20564cb0fe89488141fe31ce:eth0",
        "container-id": "f95bab4af8a2073bed35cf905d722dba5267821b20564cb0fe89488141fe31ce",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-rbdtz",
        "pod-name": "kube-system/coredns-cc6ccd49c-rbdtz"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2962584,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh45",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh45",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:15Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.44.0.154",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "f2:46:25:9a:03:62",
        "interface-index": 14,
        "interface-name": "lxca1755fc71dbb",
        "mac": "4e:91:ee:35:63:e4"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2962584,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2962584,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2920

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2920

```
Timestamp              Status   State                   Message
2024-10-25T10:23:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:15Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:47Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:45Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:15:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:44Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:44Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2962584

```
ID        LABELS
2962584   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh45
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 3759

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    75377   865       0        
Allow    Egress      0          ANY          NONE         disabled    13238   137       0        

```


#### BPF CT List 3759

```
Invalid argument: unknown type 3759
```


#### Endpoint Get 3759

```
[
  {
    "id": 3759,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3759-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "9ef3cd5e-d79d-4d3c-adf6-0f49ad8745e8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3759",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:44.783Z",
            "success-count": 3
          },
          "uuid": "54dfe4b1-5511-4587-a405-84bcb63208d3"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-z9txs",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:44.782Z",
            "success-count": 1
          },
          "uuid": "f3118e5c-a928-42e8-a519-333a81b8e1d1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3759",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:48.884Z",
            "success-count": 1
          },
          "uuid": "db0d3027-be9e-45d9-8e01-d72dbc8e5fe9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3759)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:14.894Z",
            "success-count": 83
          },
          "uuid": "86ae5e98-b9bc-4fa1-89b7-c9264fc13bcc"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "90ed1c54ea42fc69a6125a6447ec23a150cc9996886bdad2fd291d88bada22eb:eth0",
        "container-id": "90ed1c54ea42fc69a6125a6447ec23a150cc9996886bdad2fd291d88bada22eb",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-z9txs",
        "pod-name": "kube-system/coredns-cc6ccd49c-z9txs"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2962584,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh45",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh45",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:15Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.44.0.18",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ca:b5:87:cd:0e:68",
        "interface-index": 12,
        "interface-name": "lxc0d458d1c6363",
        "mac": "6a:e0:30:02:04:69"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2962584,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2962584,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3759

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3759

```
Timestamp              Status    State                   Message
2024-10-25T10:23:15Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:15Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:15Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:23:15Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:14Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:14Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:14Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:14Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:13Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:13Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:13Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:13Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:29Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:29Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:29Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:29Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:28Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:28Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:28Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:28Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:48Z   OK        ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:15:48Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:48Z   OK        regenerating            Regenerating endpoint: devices changed
2024-10-25T10:15:48Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:46Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:15:45Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:45Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:15:44Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:44Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:15:44Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:44Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 2962584

```
ID        LABELS
2962584   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh45
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### Service list

```
ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.136.251:443 (active)    
                                        2 => 172.31.214.108:443 (active)    
2    10.100.64.237:443   ClusterIP      1 => 172.31.140.221:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.44.0.18:53 (active)         
                                        2 => 10.44.0.154:53 (active)        
4    10.100.0.10:9153    ClusterIP      1 => 10.44.0.18:9153 (active)       
                                        2 => 10.44.0.154:9153 (active)      
5    10.100.232.9:2379   ClusterIP      1 => 10.44.0.77:2379 (active)       
```

#### Policy get

```
:
 []
Revision: 1

```

