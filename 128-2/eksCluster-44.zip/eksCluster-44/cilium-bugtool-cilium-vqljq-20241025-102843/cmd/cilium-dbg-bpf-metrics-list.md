REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     211896    83474209   1132   bpf_host.c
Interface                 INGRESS     9500      741518     677    bpf_overlay.c
Success                   EGRESS      4447      339855     1694   bpf_host.c
Success                   EGRESS      87637     12008917   1308   bpf_lxc.c
Success                   EGRESS      9333      730015     53     encap.h
Success                   INGRESS     104742    12392520   235    trace.h
Success                   INGRESS     99167     11956349   86     l3.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
