key: 01 00 00 00  value: ac 1f e5 2a 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: 0a 1c 00 c5 00 35 00 00  00 00 00 00
key: 03 00 00 00  value: 0a 1c 00 bd 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 1c 00 fc 09 4b 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 1c 00 c5 23 c1 00 00  00 00 00 00
key: 04 00 00 00  value: 0a 1c 00 bd 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f 90 d8 10 94 00 00  00 00 00 00
key: 07 00 00 00  value: ac 1f 8d d3 01 bb 00 00  00 00 00 00
Found 8 elements
