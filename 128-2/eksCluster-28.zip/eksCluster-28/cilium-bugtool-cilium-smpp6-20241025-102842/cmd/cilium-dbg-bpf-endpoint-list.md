IP ADDRESS         LOCAL ENDPOINT INFO
10.28.0.252:0      id=27    sec_id=1957897 flags=0x0000 ifindex=15  mac=26:B3:6E:DD:56:14 nodemac=C6:97:16:A9:07:9F   
10.28.0.191:0      id=787   sec_id=4     flags=0x0000 ifindex=7   mac=CA:53:69:39:DF:57 nodemac=5A:4F:4C:79:FE:48     
10.28.0.197:0      id=2882  sec_id=1908893 flags=0x0000 ifindex=11  mac=42:C7:18:96:B7:E8 nodemac=0E:89:23:E7:A0:CB   
172.31.144.216:0   (localhost)                                                                                        
10.28.0.214:0      (localhost)                                                                                        
10.28.0.189:0      id=3650  sec_id=1908893 flags=0x0000 ifindex=9   mac=56:EB:4E:8F:41:98 nodemac=92:70:24:9C:63:44   
