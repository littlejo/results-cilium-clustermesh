32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:17+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:17+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:17+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:17+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:20+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:29+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
64: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
67: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
68: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
71: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
72: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
75: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
80: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
83: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
107: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
110: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
451: sched_cls  name tail_handle_ipv4  tag 190f9318cc5ba304  gpl
	loaded_at 2024-10-25T10:14:02+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 69,68,75,70,91
	btf_id 112
452: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:14:02+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 70,91
	btf_id 113
453: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:14:02+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 114
454: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:14:02+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 115
478: sched_cls  name handle_policy  tag c461b2ad95599d4f  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,102,76,77,103,35,74,99,33,78,69,34,31,32
	btf_id 143
482: sched_cls  name tail_handle_ipv4  tag b4e6c80b132d3a2c  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,102
	btf_id 146
487: sched_cls  name tail_ipv4_to_endpoint  tag c2d79eaf50469c35  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,103,35,76,77,74,99,33,102,34,31,32
	btf_id 150
488: sched_cls  name cil_from_container  tag c15003ba0a1a57a1  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 102,70
	btf_id 154
489: sched_cls  name tail_ipv4_ct_ingress  tag e5c5d13cb956127a  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,102,76,77,103,78
	btf_id 156
490: sched_cls  name __send_drop_notify  tag 17617f6815402028  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 157
491: sched_cls  name tail_handle_arp  tag 9b236a077470d7ec  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,102
	btf_id 158
492: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,102
	btf_id 159
493: sched_cls  name tail_handle_ipv4_cont  tag 8c314ba097ce24ea  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,103,35,99,76,77,33,70,68,71,102,34,31,32,75
	btf_id 160
496: sched_cls  name tail_ipv4_ct_egress  tag 8c9120d42219ccde  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,102,76,77,103,78
	btf_id 162
498: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 165
499: sched_cls  name tail_handle_ipv4_from_host  tag 08762b18e53e3142  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,105
	btf_id 166
501: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 70,69,105
	btf_id 170
503: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,105
	btf_id 172
504: sched_cls  name __send_drop_notify  tag 28bfa4e382dcdc8a  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 173
505: sched_cls  name tail_handle_ipv4_cont  tag bd71a5faf0773b94  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,107,35,104,76,77,33,70,68,71,108,34,31,32,75
	btf_id 169
506: sched_cls  name tail_handle_ipv4_from_host  tag 08762b18e53e3142  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,109
	btf_id 175
510: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,109
	btf_id 179
511: sched_cls  name __send_drop_notify  tag 28bfa4e382dcdc8a  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 180
512: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 181
514: sched_cls  name tail_handle_ipv4_from_host  tag 08762b18e53e3142  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,112
	btf_id 184
515: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 70,112,69
	btf_id 186
518: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,112
	btf_id 189
519: sched_cls  name __send_drop_notify  tag 28bfa4e382dcdc8a  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 190
520: sched_cls  name tail_handle_ipv4  tag 1fccdc28ebda2524  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,108
	btf_id 185
522: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,108
	btf_id 192
523: sched_cls  name tail_handle_arp  tag fddc490a81feb9a4  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,113
	btf_id 195
524: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,113
	btf_id 196
525: sched_cls  name __send_drop_notify  tag 2ae0b522d20c664c  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 197
526: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 70,113,76,77,114,78
	btf_id 198
527: sched_cls  name tail_handle_ipv4_cont  tag 8f6403f12d29590b  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 69,114,35,92,76,77,33,70,68,71,113,34,31,32,75
	btf_id 199
529: sched_cls  name tail_handle_ipv4  tag 6b1fe70edefffd8d  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,113
	btf_id 201
530: sched_cls  name handle_policy  tag 2ed909630d4bf8a8  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,108,76,77,107,35,74,104,33,78,69,34,31,32
	btf_id 193
531: sched_cls  name __send_drop_notify  tag 2ed838f726fdb4d7  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 203
532: sched_cls  name tail_ipv4_ct_ingress  tag 6cba7bcdb72c4fee  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,108,76,77,107,78
	btf_id 204
533: sched_cls  name tail_handle_arp  tag 10a6e5c2e62216e9  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,108
	btf_id 205
534: sched_cls  name handle_policy  tag c6a230122e2ba1a3  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 70,113,76,77,114,35,74,92,33,78,69,34,31,32
	btf_id 202
535: sched_cls  name tail_ipv4_to_endpoint  tag d82c6ab7334392a4  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,107,35,76,77,74,104,33,108,34,31,32
	btf_id 206
536: sched_cls  name tail_ipv4_ct_egress  tag 8c9120d42219ccde  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,108,76,77,107,78
	btf_id 208
537: sched_cls  name cil_from_container  tag f3f6740acd2e1d67  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 108,70
	btf_id 209
538: sched_cls  name tail_ipv4_to_endpoint  tag 07210b5cf8623388  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 69,70,114,35,76,77,74,92,33,113,34,31,32
	btf_id 207
539: sched_cls  name tail_ipv4_ct_ingress  tag 7190448d365d63fc  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 70,113,76,77,114,78
	btf_id 210
540: sched_cls  name cil_from_container  tag afe5fdc576c5ea42  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 113,70
	btf_id 211
541: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
544: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
545: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
548: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
549: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
552: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
553: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
556: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
596: sched_cls  name tail_ipv4_ct_ingress  tag 935b62d0b53536e0  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,131,76,77,130,78
	btf_id 227
597: sched_cls  name tail_handle_ipv4_cont  tag 4147e57c2de862bf  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,130,35,129,76,77,33,70,68,71,131,34,31,32,75
	btf_id 228
598: sched_cls  name tail_handle_arp  tag f970cf74c33421ee  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,131
	btf_id 229
599: sched_cls  name cil_from_container  tag 2f3d14118d04761b  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 131,70
	btf_id 230
601: sched_cls  name handle_policy  tag 94bb4c8bcbeb5a34  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,131,76,77,130,35,74,129,33,78,69,34,31,32
	btf_id 232
602: sched_cls  name tail_ipv4_to_endpoint  tag 79899cbc01e7b365  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,130,35,76,77,74,129,33,131,34,31,32
	btf_id 233
603: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,131
	btf_id 234
604: sched_cls  name tail_ipv4_ct_egress  tag 9ea14e0ffa24eeac  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,131,76,77,130,78
	btf_id 235
605: sched_cls  name __send_drop_notify  tag d703cef9f182f971  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 236
606: sched_cls  name tail_handle_ipv4  tag e7a61c2f8071e115  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,131
	btf_id 237
607: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
610: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
623: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
626: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
627: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
630: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
631: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
634: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
