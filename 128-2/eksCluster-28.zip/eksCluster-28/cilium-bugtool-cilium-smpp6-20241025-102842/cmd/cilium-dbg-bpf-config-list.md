KEY             VALUE
AgentLiveness   962082591614
UTimeOffset     3378615611328125
