Endpoint ID: 27
Path: /sys/fs/bpf/tc/globals/cilium_policy_00027

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3855552   35345     0        
Allow    Ingress     1          ANY          NONE         disabled    2674559   26524     0        
Allow    Egress      0          ANY          NONE         disabled    3636606   34091     0        


Endpoint ID: 648
Path: /sys/fs/bpf/tc/globals/cilium_policy_00648

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 787
Path: /sys/fs/bpf/tc/globals/cilium_policy_00787

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    438936   5605      0        
Allow    Ingress     1          ANY          NONE         disabled    13218    155       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2882
Path: /sys/fs/bpf/tc/globals/cilium_policy_02882

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    86002   988       0        
Allow    Egress      0          ANY          NONE         disabled    14202   148       0        


Endpoint ID: 3650
Path: /sys/fs/bpf/tc/globals/cilium_policy_03650

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    85408   979       0        
Allow    Egress      0          ANY          NONE         disabled    14033   146       0        


