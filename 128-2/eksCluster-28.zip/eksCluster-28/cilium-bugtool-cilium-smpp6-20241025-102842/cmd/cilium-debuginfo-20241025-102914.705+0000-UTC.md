# Cilium debug information

#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium environment keys

```
mesh-auth-gc-interval:5m0s
debug-verbose:
k8s-service-proxy-name:
ingress-secrets-namespace:
static-cnp-path:
ipv4-native-routing-cidr:
auto-direct-node-routes:false
keep-config:false
ipv4-range:auto
k8s-client-connection-timeout:30s
enable-cilium-api-server-access:
vtep-cidr:
enable-route-mtu-for-cni-chaining:false
cmdref:
nodes-gc-interval:5m0s
iptables-lock-timeout:5s
egress-gateway-policy-map-max:16384
gops-port:9890
enable-policy:default
cflags:
service-no-backend-response:reject
enable-unreachable-routes:false
bpf-ct-timeout-service-any:1m0s
use-cilium-internal-ip-for-ipsec:false
kube-proxy-replacement-healthz-bind-address:
enable-ingress-controller:false
nat-map-stats-interval:30s
multicast-enabled:false
hubble-export-file-path:
procfs:/host/proc
config-sources:config-map:kube-system/cilium-config
enable-node-port:false
bpf-ct-timeout-service-tcp:2h13m20s
routing-mode:tunnel
enable-custom-calls:false
http-normalize-path:true
dnsproxy-insecure-skip-transparent-mode-check:false
vtep-mask:
bpf-lb-rss-ipv6-src-cidr:
cilium-endpoint-gc-interval:5m0s
mesh-auth-spire-admin-socket:
ipv6-range:auto
disable-envoy-version-check:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
log-opt:
l2-pod-announcements-interface:
kvstore:
enable-mke:false
k8s-kubeconfig-path:
version:false
cluster-name:cmesh29
ipv4-node:auto
kube-proxy-replacement:false
tofqdns-proxy-port:0
local-router-ipv4:
enable-runtime-device-detection:true
enable-well-known-identities:false
hubble-disable-tls:false
pprof:false
policy-audit-mode:false
labels:
devices:
bpf-neigh-global-max:524288
direct-routing-skip-unreachable:false
enable-gateway-api:false
ipv6-native-routing-cidr:
join-cluster:false
bpf-lb-maglev-map-max:0
envoy-base-id:0
http-retry-count:3
annotate-k8s-node:false
egress-masquerade-interfaces:ens+
enable-service-topology:false
enable-hubble:true
clustermesh-enable-endpoint-sync:false
hubble-export-allowlist:
tofqdns-dns-reject-response-code:refused
bpf-lb-service-backend-map-max:0
dnsproxy-concurrency-limit:0
node-port-range:
bypass-ip-availability-upon-restore:false
http-retry-timeout:0
enable-vtep:false
envoy-config-timeout:2m0s
mesh-auth-rotated-identities-queue-size:1024
proxy-xff-num-trusted-hops-ingress:0
certificates-directory:/var/run/cilium/certs
bpf-map-dynamic-size-ratio:0.0025
bgp-config-path:/var/lib/cilium/bgp/config.yaml
egress-gateway-reconciliation-trigger-interval:1s
cluster-pool-ipv4-mask-size:24
bpf-ct-timeout-regular-tcp:2h13m20s
arping-refresh-period:30s
enable-active-connection-tracking:false
mtu:0
cni-chaining-mode:none
hubble-socket-path:/var/run/cilium/hubble.sock
enable-local-node-route:true
bpf-nat-global-max:524288
k8s-api-server:
cni-chaining-target:
enable-ipv4:true
enable-local-redirect-policy:false
allow-localhost:auto
hubble-export-fieldmask:
trace-payloadlen:128
envoy-log:
install-iptables-rules:true
tunnel-protocol:vxlan
mesh-auth-enabled:true
lib-dir:/var/lib/cilium
enable-ipv4-masquerade:true
enable-xt-socket-fallback:true
hubble-redact-http-urlquery:false
node-labels:
enable-bpf-tproxy:false
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
envoy-secrets-namespace:
kvstore-max-consecutive-quorum-errors:2
proxy-idle-timeout-seconds:60
enable-k8s-endpoint-slice:true
install-no-conntrack-iptables-rules:false
policy-queue-size:100
tofqdns-min-ttl:0
enable-k8s-networkpolicy:true
derive-masq-ip-addr-from-device:
hubble-skip-unknown-cgroup-ids:true
hubble-recorder-sink-queue-size:1024
ipv6-cluster-alloc-cidr:f00d::/64
bpf-sock-rev-map-max:262144
agent-health-port:9879
enable-masquerade-to-route-source:false
proxy-gid:1337
k8s-sync-timeout:3m0s
http-request-timeout:3600
cni-log-file:/var/run/cilium/cilium-cni.log
k8s-client-qps:10
enable-tcx:true
tofqdns-idle-connection-grace-period:0s
endpoint-queue-size:25
identity-restore-grace-period:30s
ipv6-node:auto
proxy-max-requests-per-connection:0
node-port-bind-protection:true
hubble-flowlogs-config-path:
route-metric:0
conntrack-gc-max-interval:0s
hubble-event-queue-size:0
mesh-auth-mutual-listener-port:0
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
hubble-export-file-max-size-mb:10
enable-ipsec-encrypted-overlay:false
kvstore-periodic-sync:5m0s
bpf-lb-rev-nat-map-max:0
enable-session-affinity:false
disable-iptables-feeder-rules:
enable-l2-pod-announcements:false
enable-monitor:true
prometheus-serve-addr:
enable-nat46x64-gateway:false
proxy-xff-num-trusted-hops-egress:0
enable-k8s-terminating-endpoint:true
hubble-metrics-server:
enable-auto-protect-node-port-range:true
enable-l2-neigh-discovery:true
proxy-admin-port:0
k8s-client-burst:20
trace-sock:true
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
bpf-events-drop-enabled:true
bpf-lb-algorithm:random
clustermesh-sync-timeout:1m0s
mesh-auth-mutual-connect-timeout:5s
max-connected-clusters:255
custom-cni-conf:false
proxy-prometheus-port:0
proxy-portrange-min:10000
mke-cgroup-mount:
exclude-local-address:
enable-ipv4-egress-gateway:false
metrics:
restore:true
bpf-ct-timeout-regular-any:1m0s
tofqdns-endpoint-max-ip-per-hostname:50
kvstore-opt:
k8s-namespace:kube-system
enable-host-legacy-routing:false
encrypt-node:false
monitor-aggregation:medium
bpf-events-trace-enabled:true
bpf-root:/sys/fs/bpf
dns-max-ips-per-restored-rule:1000
bpf-lb-mode:snat
bpf-lb-sock-terminate-pod-connections:false
disable-endpoint-crd:false
pprof-address:localhost
hubble-redact-http-userinfo:true
enable-host-firewall:false
conntrack-gc-interval:0s
max-controller-interval:0
enable-ipv6-ndp:false
set-cilium-node-taints:true
ipam-cilium-node-update-rate:15s
read-cni-conf:
enable-bandwidth-manager:false
pprof-port:6060
enable-health-checking:true
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
enable-wireguard-userspace-fallback:false
enable-bpf-clock-probe:false
bgp-announce-pod-cidr:false
enable-recorder:false
enable-srv6:false
k8s-require-ipv4-pod-cidr:false
proxy-max-connection-duration-seconds:0
enable-envoy-config:false
policy-cidr-match-mode:
identity-gc-interval:15m0s
hubble-drop-events-interval:2m0s
k8s-require-ipv6-pod-cidr:false
k8s-client-connection-keep-alive:30s
enable-ipsec-xfrm-state-caching:true
agent-labels:
enable-ipv6-big-tcp:false
enable-identity-mark:true
enable-endpoint-health-checking:true
proxy-connect-timeout:2
datapath-mode:veth
controller-group-metrics:
ipv6-service-range:auto
enable-ipsec:false
tofqdns-pre-cache:
egress-multi-home-ip-rule-compat:false
auto-create-cilium-node-resource:true
bgp-announce-lb-ip:false
enable-wireguard:false
ip-masq-agent-config-path:/etc/config/ip-masq-agent
bpf-ct-timeout-regular-tcp-syn:1m0s
enable-cilium-endpoint-slice:false
identity-heartbeat-timeout:30m0s
bpf-fragments-map-max:8192
bpf-lb-sock:false
enable-ipv6-masquerade:true
fixed-identity-mapping:
cluster-health-port:4240
bpf-ct-global-tcp-max:524288
iptables-random-fully:false
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
enable-endpoint-routes:false
log-system-load:false
hubble-metrics:
clustermesh-ip-identities-sync-timeout:1m0s
prepend-iptables-chains:true
crd-wait-timeout:5m0s
enable-xdp-prefilter:false
enable-node-selector-labels:false
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
bpf-lb-dsr-l4-xlate:frontend
hubble-export-denylist:
enable-metrics:true
monitor-queue-size:0
identity-allocation-mode:crd
nodeport-addresses:
allocator-list-timeout:3m0s
identity-change-grace-period:5s
mesh-auth-spiffe-trust-domain:spiffe.cilium
hubble-redact-http-headers-allow:
unmanaged-pod-watcher-interval:15
bpf-lb-dsr-dispatch:opt
enable-ip-masq-agent:false
vlan-bpf-bypass:
dns-policy-unload-on-shutdown:false
node-port-mode:snat
kvstore-lease-ttl:15m0s
enable-health-check-nodeport:true
http-idle-timeout:0
dnsproxy-concurrency-processing-grace-period:0s
envoy-keep-cap-netbindservice:false
hubble-monitor-events:
vtep-endpoint:
allow-icmp-frag-needed:true
local-max-addr-scope:252
enable-ipv6:false
enable-encryption-strict-mode:false
bpf-ct-timeout-service-tcp-grace:1m0s
operator-api-serve-addr:127.0.0.1:9234
bpf-ct-global-any-max:262144
cluster-pool-ipv4-cidr:10.28.0.0/16
tofqdns-enable-dns-compression:true
endpoint-bpf-prog-watchdog-interval:30s
monitor-aggregation-interval:5s
encrypt-interface:
nat-map-stats-entries:32
ipam-default-ip-pool:default
bpf-lb-acceleration:disabled
enable-ipv4-fragment-tracking:true
operator-prometheus-serve-addr::9963
bpf-policy-map-max:16384
http-max-grpc-timeout:0
config-dir:/tmp/cilium/config-map
bpf-lb-affinity-map-max:0
bpf-filter-priority:1
enable-bpf-masquerade:false
monitor-aggregation-flags:all
bpf-auth-map-max:524288
hubble-export-file-max-backups:5
ipsec-key-rotation-duration:5m0s
bpf-lb-sock-hostns-only:false
mesh-auth-signal-backoff-duration:1s
max-internal-timer-delay:0s
ipam-multi-pool-pre-allocation:
enable-external-ips:false
fqdn-regex-compile-lru-size:1024
enable-ipsec-key-watcher:true
clustermesh-enable-mcs-api:false
l2-announcements-renew-deadline:5s
enable-l2-announcements:false
dnsproxy-lock-timeout:500ms
srv6-encap-mode:reduced
external-envoy-proxy:true
k8s-heartbeat-timeout:30s
bpf-lb-maglev-table-size:16381
config:
enable-l7-proxy:true
l2-announcements-retry-period:2s
ipam:cluster-pool
state-dir:/var/run/cilium
vtep-mac:
envoy-config-retry-interval:15s
bpf-node-map-max:16384
disable-external-ip-mitigation:false
enable-tracing:false
hubble-prefer-ipv6:false
label-prefix-file:
enable-bbr:false
tunnel-port:0
endpoint-gc-interval:5m0s
ipv6-pod-subnets:
hubble-event-buffer-capacity:4095
remove-cilium-node-taints:true
enable-hubble-recorder-api:true
bpf-ct-timeout-regular-tcp-fin:10s
bpf-lb-map-max:65536
enable-cilium-health-api-server-access:
bpf-lb-source-range-map-max:0
wireguard-persistent-keepalive:0s
hubble-redact-enabled:false
force-device-detection:false
enable-stale-cilium-endpoint-cleanup:true
enable-k8s-api-discovery:false
ipv4-pod-subnets:
cluster-id:29
cni-exclusive:true
enable-icmp-rules:true
bpf-lb-external-clusterip:false
ipv4-service-loopback-address:169.254.42.1
tofqdns-max-deferred-connection-deletes:10000
container-ip-local-reserved-ports:auto
use-full-tls-context:false
hubble-drop-events:false
node-port-algorithm:random
api-rate-limit:
local-router-ipv6:
enable-pmtu-discovery:false
dnsproxy-lock-count:131
enable-high-scale-ipcache:false
ipv6-mcast-device:
enable-ipip-termination:false
ipsec-key-file:
bpf-events-policy-verdict-enabled:true
enable-k8s:true
exclude-node-label-patterns:
bpf-policy-map-full-reconciliation-interval:15m0s
hubble-recorder-storage-path:/var/run/cilium/pcaps
clustermesh-config:/var/lib/cilium/clustermesh/
node-port-acceleration:disabled
k8s-service-cache-size:128
bpf-map-event-buffers:
agent-liveness-update-interval:1s
dnsproxy-enable-transparent-mode:true
hubble-export-file-compress:false
synchronize-k8s-nodes:true
debug:false
enable-bgp-control-plane:false
hubble-drop-events-reasons:auth_required,policy_denied
hubble-redact-http-headers-deny:
policy-trigger-interval:1s
cni-external-routing:false
dnsproxy-socket-linger-timeout:10
encryption-strict-mode-cidr:
bpf-lb-rss-ipv4-src-cidr:
socket-path:/var/run/cilium/cilium.sock
encryption-strict-mode-allow-remote-node-identities:false
enable-health-check-loadbalancer-ip:false
hubble-redact-kafka-apikey:false
log-driver:
mesh-auth-queue-size:1024
enable-sctp:false
cgroup-root:/run/cilium/cgroupv2
policy-accounting:true
hubble-listen-address::4244
enable-host-port:false
proxy-portrange-max:20000
direct-routing-device:
enable-svc-source-range-check:true
kvstore-connectivity-timeout:2m0s
set-cilium-is-up-condition:true
preallocate-bpf-maps:false
ipv4-service-range:auto
bpf-lb-service-map-max:0
gateway-api-secrets-namespace:
tofqdns-proxy-response-max-delay:100ms
enable-ipv4-big-tcp:false
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
l2-announcements-lease-duration:15s
```


#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.229.42:443 (active)     
                                          2 => 172.31.141.211:443 (active)    
2    10.100.180.28:443     ClusterIP      1 => 172.31.144.216:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.28.0.189:53 (active)        
                                          2 => 10.28.0.197:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.28.0.189:9153 (active)      
                                          2 => 10.28.0.197:9153 (active)      
5    10.100.158.190:2379   ClusterIP      1 => 10.28.0.252:2379 (active)      
```

#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 16780340                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 16780340                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 16780340                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400cc00000 rw-p 00000000 00:00 0 
400cc00000-4010000000 ---p 00000000 00:00 0 
ffff6a67e000-ffff6a883000 rw-p 00000000 00:00 0 
ffff6a88a000-ffff6a96c000 rw-p 00000000 00:00 0 
ffff6a96c000-ffff6a9ad000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff6a9ad000-ffff6a9ee000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff6a9ee000-ffff6aa2e000 rw-p 00000000 00:00 0 
ffff6aa2e000-ffff6aa30000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff6aa30000-ffff6aa32000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff6aa32000-ffff6aff9000 rw-p 00000000 00:00 0 
ffff6aff9000-ffff6b0f9000 rw-p 00000000 00:00 0 
ffff6b0f9000-ffff6b10a000 rw-p 00000000 00:00 0 
ffff6b10a000-ffff6d10a000 rw-p 00000000 00:00 0 
ffff6d10a000-ffff6d18a000 ---p 00000000 00:00 0 
ffff6d18a000-ffff6d18b000 rw-p 00000000 00:00 0 
ffff6d18b000-ffff8d18a000 ---p 00000000 00:00 0 
ffff8d18a000-ffff8d18b000 rw-p 00000000 00:00 0 
ffff8d18b000-ffffad11a000 ---p 00000000 00:00 0 
ffffad11a000-ffffad11b000 rw-p 00000000 00:00 0 
ffffad11b000-ffffb110c000 ---p 00000000 00:00 0 
ffffb110c000-ffffb110d000 rw-p 00000000 00:00 0 
ffffb110d000-ffffb190a000 ---p 00000000 00:00 0 
ffffb190a000-ffffb190b000 rw-p 00000000 00:00 0 
ffffb190b000-ffffb1a0a000 ---p 00000000 00:00 0 
ffffb1a0a000-ffffb1a6a000 rw-p 00000000 00:00 0 
ffffb1a6a000-ffffb1a6c000 r--p 00000000 00:00 0                          [vvar]
ffffb1a6c000-ffffb1a6d000 r-xp 00000000 00:00 0                          [vdso]
fffffceb4000-fffffced5000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.28.0.0/24, 
Allocated addresses:
  10.28.0.189 (kube-system/coredns-cc6ccd49c-q4rpq)
  10.28.0.191 (health)
  10.28.0.197 (kube-system/coredns-cc6ccd49c-pv9ch)
  10.28.0.214 (router)
  10.28.0.252 (kube-system/clustermesh-apiserver-74469cd8d9-dslk9)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cf92ab1aa076bf5
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    12s ago        never        0       no error   
  ct-map-pressure                                                     13s ago        never        0       no error   
  daemon-validate-config                                              59s ago        never        0       no error   
  dns-garbage-collector-job                                           16s ago        never        0       no error   
  endpoint-27-regeneration-recovery                                   never          never        0       no error   
  endpoint-2882-regeneration-recovery                                 never          never        0       no error   
  endpoint-3650-regeneration-recovery                                 never          never        0       no error   
  endpoint-648-regeneration-recovery                                  never          never        0       no error   
  endpoint-787-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         16s ago        never        0       no error   
  ep-bpf-prog-watchdog                                                13s ago        never        0       no error   
  ipcache-inject-labels                                               14s ago        never        0       no error   
  k8s-heartbeat                                                       16s ago        never        0       no error   
  link-cache                                                          13s ago        never        0       no error   
  local-identity-checkpoint                                           15m4s ago      never        0       no error   
  node-neighbor-link-updater                                          3s ago         never        0       no error   
  remote-etcd-cmesh1                                                  5m20s ago      never        0       no error   
  remote-etcd-cmesh10                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh100                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh101                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh102                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh103                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh104                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh105                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh106                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh107                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh108                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh109                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh11                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh110                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh111                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh112                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh113                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh114                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh115                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh116                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh117                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh118                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh119                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh12                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh120                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh121                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh122                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh123                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh124                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh125                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh126                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh127                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh128                                                5m20s ago      never        0       no error   
  remote-etcd-cmesh13                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh14                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh15                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh16                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh17                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh18                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh19                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh2                                                  5m20s ago      never        0       no error   
  remote-etcd-cmesh20                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh21                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh22                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh23                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh24                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh25                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh26                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh27                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh28                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh3                                                  5m20s ago      never        0       no error   
  remote-etcd-cmesh30                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh31                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh32                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh33                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh34                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh35                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh36                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh37                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh38                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh39                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh4                                                  5m20s ago      never        0       no error   
  remote-etcd-cmesh40                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh41                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh42                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh43                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh44                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh45                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh46                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh47                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh48                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh49                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh5                                                  5m20s ago      never        0       no error   
  remote-etcd-cmesh50                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh51                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh52                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh53                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh54                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh55                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh56                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh57                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh58                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh59                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh6                                                  5m20s ago      never        0       no error   
  remote-etcd-cmesh60                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh61                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh62                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh63                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh64                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh65                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh66                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh67                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh68                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh69                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh7                                                  5m20s ago      never        0       no error   
  remote-etcd-cmesh70                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh71                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh72                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh73                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh74                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh75                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh76                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh77                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh78                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh79                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh8                                                  5m20s ago      never        0       no error   
  remote-etcd-cmesh80                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh81                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh82                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh83                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh84                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh85                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh86                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh87                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh88                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh89                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh9                                                  5m20s ago      never        0       no error   
  remote-etcd-cmesh90                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh91                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh92                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh93                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh94                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh95                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh96                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh97                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh98                                                 5m20s ago      never        0       no error   
  remote-etcd-cmesh99                                                 5m20s ago      never        0       no error   
  resolve-identity-27                                                 1m10s ago      never        0       no error   
  resolve-identity-2882                                               12s ago        never        0       no error   
  resolve-identity-3650                                               12s ago        never        0       no error   
  resolve-identity-648                                                14s ago        never        0       no error   
  resolve-identity-787                                                12s ago        never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-74469cd8d9-dslk9   6m10s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-pv9ch                  15m12s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-q4rpq                  15m12s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      15m14s ago     never        0       no error   
  sync-policymap-27                                                   6m10s ago      never        0       no error   
  sync-policymap-2882                                                 9s ago         never        0       no error   
  sync-policymap-3650                                                 9s ago         never        0       no error   
  sync-policymap-648                                                  12s ago        never        0       no error   
  sync-policymap-787                                                  9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (27)                                     10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2882)                                   12s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (3650)                                   12s ago        never        0       no error   
  sync-utime                                                          14s ago        never        0       no error   
  write-cni-file                                                      15m16s ago     never        0       no error   
Proxy Status:            OK, ip 10.28.0.214, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 1900544, max 1966079
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 64.82   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
27         Disabled           Disabled          1957897    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.28.0.252   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh29                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
648        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                
                                                           reserved:host                                                                                             
787        Disabled           Disabled          4          reserved:health                                                                     10.28.0.191   ready   
2882       Disabled           Disabled          1908893    k8s:eks.amazonaws.com/component=coredns                                             10.28.0.197   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh29                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
3650       Disabled           Disabled          1908893    k8s:eks.amazonaws.com/component=coredns                                             10.28.0.189   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh29                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
```

#### BPF Policy Get 27

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3855190   35341     0        
Allow    Ingress     1          ANY          NONE         disabled    2674559   26524     0        
Allow    Egress      0          ANY          NONE         disabled    3611326   33809     0        

```


#### BPF CT List 27

```
Invalid argument: unknown type 27
```


#### Endpoint Get 27

```
[
  {
    "id": 27,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-27-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "31f48eb2-d0be-4a7f-bfbd-d8c92db09901"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-27",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:04.349Z",
            "success-count": 2
          },
          "uuid": "108606a1-ad7e-4630-8b3f-aa84daceb825"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-74469cd8d9-dslk9",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:04.348Z",
            "success-count": 1
          },
          "uuid": "306327b9-42fa-4fb8-94e4-a966d6673dd9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-27",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:04.405Z",
            "success-count": 1
          },
          "uuid": "9dc52127-c7c8-470e-aa0e-27d7c8c13ca6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (27)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:14.395Z",
            "success-count": 39
          },
          "uuid": "e124e50d-2c23-4817-bfd6-993f470fa9a4"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "e69e9b9ae238619fd51cb0fff3077e9a0b2efc49d7b28c3b4891156535b020a3:eth0",
        "container-id": "e69e9b9ae238619fd51cb0fff3077e9a0b2efc49d7b28c3b4891156535b020a3",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-74469cd8d9-dslk9",
        "pod-name": "kube-system/clustermesh-apiserver-74469cd8d9-dslk9"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1957897,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh29",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=74469cd8d9"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh29",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:56Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.28.0.252",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "c6:97:16:a9:07:9f",
        "interface-index": 15,
        "interface-name": "lxc2722e703a37e",
        "mac": "26:b3:6e:dd:56:14"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1957897,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1957897,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 27

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 27

```
Timestamp              Status   State                   Message
2024-10-25T10:23:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:56Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:23:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:04Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:23:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:23:04Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:23:04Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1957897

```
ID        LABELS
1957897   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh29
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 648

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 648

```
Invalid argument: unknown type 648
```


#### Endpoint Get 648

```
[
  {
    "id": 648,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-648-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b9dcfd55-eb9b-4d48-b2d7-3278f2be314d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-648",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:00.693Z",
            "success-count": 4
          },
          "uuid": "8e43c3b5-e0b9-4f50-a6ce-6a8bc2a6b474"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-648",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:01.740Z",
            "success-count": 2
          },
          "uuid": "9198b0c5-11f1-49f6-bd85-32b346487b94"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:56Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "2e:c5:a0:eb:0f:df",
        "interface-name": "cilium_host",
        "mac": "2e:c5:a0:eb:0f:df"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 648

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 648

```
Timestamp              Status   State                   Message
2024-10-25T10:23:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:56Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:14:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:05Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:14:03Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:03Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:14:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:14:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:00Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:00Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:00Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 787

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    438614   5600      0        
Allow    Ingress     1          ANY          NONE         disabled    13218    155       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 787

```
Invalid argument: unknown type 787
```


#### Endpoint Get 787

```
[
  {
    "id": 787,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-787-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "01e475f8-2d89-4d14-8d65-c06d7b52cb6e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-787",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:01.747Z",
            "success-count": 4
          },
          "uuid": "1fd4ebfc-1933-45e3-bd15-0893dca854bc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-787",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:05.517Z",
            "success-count": 2
          },
          "uuid": "ef0349d3-4bea-434f-b486-039c517211f2"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:56Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.28.0.191",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "5a:4f:4c:79:fe:48",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "ca:53:69:39:df:57"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 787

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 787

```
Timestamp              Status   State                   Message
2024-10-25T10:23:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:56Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:05Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:05Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:03Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:14:02Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:01Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:01Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:00Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 2882

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    86002   988       0        
Allow    Egress      0          ANY          NONE         disabled    14202   148       0        

```


#### BPF CT List 2882

```
Invalid argument: unknown type 2882
```


#### Endpoint Get 2882

```
[
  {
    "id": 2882,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2882-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "cf154078-9f13-48d9-b7d4-3b6307b3af44"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2882",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:02.600Z",
            "success-count": 4
          },
          "uuid": "36c5ef69-7c9d-48cd-bd55-9f29f022bb2c"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-pv9ch",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:02.599Z",
            "success-count": 1
          },
          "uuid": "cb607552-7af1-4ae0-9e6d-5cd347f683f3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2882",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:05.585Z",
            "success-count": 2
          },
          "uuid": "2b6a5347-6ae3-477a-acda-ee6bcb56aaa9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2882)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:12.681Z",
            "success-count": 93
          },
          "uuid": "b5fc2b8a-4c88-46d2-b127-a3a29c18c75a"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "26a9f07e8c54c0fb998585e12fa9c1d37cbc399fa85ac6bedda07b2b7ba48489:eth0",
        "container-id": "26a9f07e8c54c0fb998585e12fa9c1d37cbc399fa85ac6bedda07b2b7ba48489",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-pv9ch",
        "pod-name": "kube-system/coredns-cc6ccd49c-pv9ch"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1908893,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh29",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh29",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:56Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.28.0.197",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "0e:89:23:e7:a0:cb",
        "interface-index": 11,
        "interface-name": "lxcaf1cd8325030",
        "mac": "42:c7:18:96:b7:e8"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1908893,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1908893,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2882

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2882

```
Timestamp              Status   State                   Message
2024-10-25T10:23:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:56Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:05Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:03Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:14:02Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:02Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:02Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1908893

```
ID        LABELS
1908893   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh29
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 3650

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    85408   979       0        
Allow    Egress      0          ANY          NONE         disabled    14033   146       0        

```


#### BPF CT List 3650

```
Invalid argument: unknown type 3650
```


#### Endpoint Get 3650

```
[
  {
    "id": 3650,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3650-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "6053b887-1d8a-4485-83bc-ddeff957c8d6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3650",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:02.542Z",
            "success-count": 4
          },
          "uuid": "6216d233-46e2-4970-b01d-e3185f3f6810"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-q4rpq",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:02.542Z",
            "success-count": 1
          },
          "uuid": "faf2f553-b3d7-4bd7-b74a-e80314867ee0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3650",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:05.516Z",
            "success-count": 2
          },
          "uuid": "2b9d465a-5ba2-4736-a330-d27919ef147c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3650)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:12.635Z",
            "success-count": 93
          },
          "uuid": "8ed29649-9548-4020-ac9a-0eb0230f9117"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "7039adb9caabee558c88d11fddbf3a3c87d20d9cf2683497c5037200aeebd5cf:eth0",
        "container-id": "7039adb9caabee558c88d11fddbf3a3c87d20d9cf2683497c5037200aeebd5cf",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-q4rpq",
        "pod-name": "kube-system/coredns-cc6ccd49c-q4rpq"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1908893,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh29",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh29",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:56Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.28.0.189",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "92:70:24:9c:63:44",
        "interface-index": 9,
        "interface-name": "lxc614ec2a882c0",
        "mac": "56:eb:4e:8f:41:98"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1908893,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1908893,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3650

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3650

```
Timestamp              Status    State                   Message
2024-10-25T10:23:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:56Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:23:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:54Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:32Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:32Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:32Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:32Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:31Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:31Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:31Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:31Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:05Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:05Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:03Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:03Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:14:02Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:02Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:14:02Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:02Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 1908893

```
ID        LABELS
1908893   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh29
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.28.0.189": (string) (len=35) "kube-system/coredns-cc6ccd49c-q4rpq",
  (string) (len=11) "10.28.0.197": (string) (len=35) "kube-system/coredns-cc6ccd49c-pv9ch",
  (string) (len=11) "10.28.0.252": (string) (len=50) "kube-system/clustermesh-apiserver-74469cd8d9-dslk9",
  (string) (len=11) "10.28.0.214": (string) (len=6) "router",
  (string) (len=11) "10.28.0.191": (string) (len=6) "health"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.144.216": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40018168f0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001bdeae0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001bdeae0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4002a4a0b0)(frontends:[10.100.158.190]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4001e1d8c0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4001e1d970)(frontends:[10.100.180.28]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4001e1da20)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4002af0160)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40019dd138)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-4p9z4": (*k8s.Endpoints)(0x4001fc04e0)(10.28.0.252:2379/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x400119c168)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4003202410)(172.31.141.211:443/TCP,172.31.229.42:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x400119c170)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-ln9gd": (*k8s.Endpoints)(0x4002d44dd0)(172.31.144.216:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x400119c178)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-m7dxv": (*k8s.Endpoints)(0x4001490b60)(10.28.0.189:53/TCP[eu-west-3a],10.28.0.189:53/UDP[eu-west-3a],10.28.0.189:9153/TCP[eu-west-3a],10.28.0.197:53/TCP[eu-west-3a],10.28.0.197:53/UDP[eu-west-3a],10.28.0.197:9153/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x400182a770)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x400075f810)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x40023418d8
  },
  gcTrigger: (chan struct {}) (cap=1) 0x400171a720,
  gcExited: (chan struct {}) 0x400171a780,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001a5a980)({
     ObserverVec: (*prometheus.HistogramVec)(0x400174d988)({
      MetricVec: (*prometheus.MetricVec)(0x4001b1a1b0)({
       metricMap: (*prometheus.metricMap)(0x4001b1a1e0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001908360)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001a5aa00)({
     ObserverVec: (*prometheus.HistogramVec)(0x400174d990)({
      MetricVec: (*prometheus.MetricVec)(0x4001b1a240)({
       metricMap: (*prometheus.metricMap)(0x4001b1a270)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019083c0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001a5aa80)({
     GaugeVec: (*prometheus.GaugeVec)(0x400174d998)({
      MetricVec: (*prometheus.MetricVec)(0x4001b1a2d0)({
       metricMap: (*prometheus.metricMap)(0x4001b1a300)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001908420)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001a5ab00)({
     GaugeVec: (*prometheus.GaugeVec)(0x400174d9a0)({
      MetricVec: (*prometheus.MetricVec)(0x4001b1a360)({
       metricMap: (*prometheus.metricMap)(0x4001b1a390)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001908480)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001a5ab80)({
     GaugeVec: (*prometheus.GaugeVec)(0x400174d9a8)({
      MetricVec: (*prometheus.MetricVec)(0x4001b1a3f0)({
       metricMap: (*prometheus.metricMap)(0x4001b1a420)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019084e0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001a5ac00)({
     GaugeVec: (*prometheus.GaugeVec)(0x400174d9b0)({
      MetricVec: (*prometheus.MetricVec)(0x4001b1a480)({
       metricMap: (*prometheus.metricMap)(0x4001b1a4b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001908540)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001a5ac80)({
     GaugeVec: (*prometheus.GaugeVec)(0x400174d9b8)({
      MetricVec: (*prometheus.MetricVec)(0x4001b1a510)({
       metricMap: (*prometheus.metricMap)(0x4001b1a540)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019085a0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001a5ad00)({
     GaugeVec: (*prometheus.GaugeVec)(0x400174d9c0)({
      MetricVec: (*prometheus.MetricVec)(0x4001b1a5a0)({
       metricMap: (*prometheus.metricMap)(0x4001b1a5d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001908600)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001a5ad80)({
     ObserverVec: (*prometheus.HistogramVec)(0x400174d9c8)({
      MetricVec: (*prometheus.MetricVec)(0x4001b1a630)({
       metricMap: (*prometheus.metricMap)(0x4001b1a660)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001908660)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x400182a770)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x400182b8f0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001bf67c8)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 402ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations

