ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.229.42:443 (active)     
                                          2 => 172.31.141.211:443 (active)    
2    10.100.180.28:443     ClusterIP      1 => 172.31.144.216:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.28.0.189:53 (active)        
                                          2 => 10.28.0.197:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.28.0.189:9153 (active)      
                                          2 => 10.28.0.197:9153 (active)      
5    10.100.158.190:2379   ClusterIP      1 => 10.28.0.252:2379 (active)      
