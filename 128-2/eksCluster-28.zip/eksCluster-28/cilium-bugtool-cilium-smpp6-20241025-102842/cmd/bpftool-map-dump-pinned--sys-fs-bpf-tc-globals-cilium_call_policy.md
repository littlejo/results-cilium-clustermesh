key: 1b 00 00 00  value: 59 02 00 00
key: 13 03 00 00  value: 16 02 00 00
key: 42 0b 00 00  value: 12 02 00 00
key: 42 0e 00 00  value: de 01 00 00
Found 4 elements
