REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     211500    99364618   1132   bpf_host.c
Interface                 INGRESS     9499      742167     677    bpf_overlay.c
Success                   EGRESS      4556      348097     1694   bpf_host.c
Success                   EGRESS      86377     11841333   1308   bpf_lxc.c
Success                   EGRESS      9258      725625     53     encap.h
Success                   INGRESS     102542    12225469   235    trace.h
Success                   INGRESS     96950     11787493   86     l3.h
Unsupported L3 protocol   EGRESS      37        2742       1492   bpf_lxc.c
