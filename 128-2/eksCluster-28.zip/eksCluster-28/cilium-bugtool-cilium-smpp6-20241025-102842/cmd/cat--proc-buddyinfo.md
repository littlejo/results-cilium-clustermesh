Node 0, zone      DMA     81     44     43     33     34     15      5      1      4      7    221 
Node 0, zone   Normal    178     78     63    230    149     49     18      2      2      1      9 
