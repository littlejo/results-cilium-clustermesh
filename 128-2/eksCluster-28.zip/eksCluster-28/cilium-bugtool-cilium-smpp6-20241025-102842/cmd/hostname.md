ip-172-31-144-216.eu-west-3.compute.internal
