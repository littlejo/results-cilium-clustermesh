alloc: 73.92MB (77507448 bytes)
total-alloc: 1.31GB (1405384968 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 47390373
frees: 46804748
heap-alloc: 73.92MB (77507448 bytes)
heap-sys: 165.48MB (173514752 bytes)
heap-idle: 53.15MB (55730176 bytes)
heap-in-use: 112.33MB (117784576 bytes)
heap-released: 10.46MB (10969088 bytes)
heap-objects: 585625
stack-in-use: 34.50MB (36175872 bytes)
stack-sys: 34.50MB (36175872 bytes)
stack-mspan-inuse: 1.89MB (1980640 bytes)
stack-mspan-sys: 2.43MB (2545920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 929.52KB (951825 bytes)
gc-sys: 5.16MB (5411192 bytes)
next-gc: when heap-alloc >= 147.90MB (155085608 bytes)
last-gc: 2024-10-25 10:29:04.851088104 +0000 UTC
gc-pause-total: 13.915484ms
gc-pause: 73535
gc-pause-end: 1729852144851088104
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00032778345588858714
enable-gc: true
debug-gc: false
