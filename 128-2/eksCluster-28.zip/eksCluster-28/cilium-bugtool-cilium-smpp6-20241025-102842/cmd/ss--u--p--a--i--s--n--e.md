Total: 551
TCP:   1080 (estab 306, closed 755, orphaned 0, timewait 292)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  325       313       12       
INET	  335       319       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.144.216%ens5:68         0.0.0.0:*    uid:192 ino:16405 sk:25e cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:22324 sk:25f cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15127 sk:260 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:33715      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:22154 sk:261 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:22323 sk:262 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15128 sk:263 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::40c:73ff:fe4d:18db]%ens5:546           [::]:*    uid:192 ino:16403 sk:264 cgroup:unreachable:c4e v6only:1 <->                   
