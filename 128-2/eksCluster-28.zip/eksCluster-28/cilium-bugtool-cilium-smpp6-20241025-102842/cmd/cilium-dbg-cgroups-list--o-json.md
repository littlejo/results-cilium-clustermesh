[
  {
    "containers": [
      {
        "cgroup-id": 8538,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95cf7590_df42_40eb_a125_49ce33b35f0d.slice/cri-containerd-ff1165a931288e6795b8f7fa2c59bf096c988219b29cc420bdb564986ef957bf.scope"
      },
      {
        "cgroup-id": 8454,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95cf7590_df42_40eb_a125_49ce33b35f0d.slice/cri-containerd-e20666908863c41ffefbaad6d594d97fdf078d64e082b1caae7a0ea0b2ba1c22.scope"
      },
      {
        "cgroup-id": 8622,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95cf7590_df42_40eb_a125_49ce33b35f0d.slice/cri-containerd-39a824377b1e9800cfb03a974e170c98e733d7f961d4728823b02d1912ba4aa0.scope"
      }
    ],
    "ips": [
      "10.28.0.252"
    ],
    "name": "clustermesh-apiserver-74469cd8d9-dslk9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7026,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7884341f_fc68_48b6_894d_4a4bc3080662.slice/cri-containerd-f514fe1fcc97dc4ef5232f512160b6edb461f5d8f09e039b868a757a5712f117.scope"
      }
    ],
    "ips": [
      "10.28.0.189"
    ],
    "name": "coredns-cc6ccd49c-q4rpq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7110,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3a0480fc_4920_486a_9488_ca9f706d49dc.slice/cri-containerd-d5f7627c6a7d3d8b51bb0c0dc12ed04e81a240d6b7815d91de9acf9b985d505d.scope"
      }
    ],
    "ips": [
      "10.28.0.197"
    ],
    "name": "coredns-cc6ccd49c-pv9ch",
    "namespace": "kube-system"
  }
]

