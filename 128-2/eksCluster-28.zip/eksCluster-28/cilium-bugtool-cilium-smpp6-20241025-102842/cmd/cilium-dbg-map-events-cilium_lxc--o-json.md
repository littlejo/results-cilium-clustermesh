{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:00.524Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.144.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:00.524Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:05.514Z",
  "value": "id=3650  sec_id=1908893 flags=0x0000 ifindex=9   mac=56:EB:4E:8F:41:98 nodemac=92:70:24:9C:63:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:05.515Z",
  "value": "id=787   sec_id=4     flags=0x0000 ifindex=7   mac=CA:53:69:39:DF:57 nodemac=5A:4F:4C:79:FE:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:05.584Z",
  "value": "id=2882  sec_id=1908893 flags=0x0000 ifindex=11  mac=42:C7:18:96:B7:E8 nodemac=0E:89:23:E7:A0:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:05.584Z",
  "value": "id=787   sec_id=4     flags=0x0000 ifindex=7   mac=CA:53:69:39:DF:57 nodemac=5A:4F:4C:79:FE:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:31.858Z",
  "value": "id=787   sec_id=4     flags=0x0000 ifindex=7   mac=CA:53:69:39:DF:57 nodemac=5A:4F:4C:79:FE:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:31.859Z",
  "value": "id=3650  sec_id=1908893 flags=0x0000 ifindex=9   mac=56:EB:4E:8F:41:98 nodemac=92:70:24:9C:63:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:31.860Z",
  "value": "id=2882  sec_id=1908893 flags=0x0000 ifindex=11  mac=42:C7:18:96:B7:E8 nodemac=0E:89:23:E7:A0:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:31.896Z",
  "value": "id=1371  sec_id=1957897 flags=0x0000 ifindex=13  mac=5A:6B:EE:94:DD:2A nodemac=0E:02:F1:3D:B3:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:32.858Z",
  "value": "id=2882  sec_id=1908893 flags=0x0000 ifindex=11  mac=42:C7:18:96:B7:E8 nodemac=0E:89:23:E7:A0:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:32.859Z",
  "value": "id=3650  sec_id=1908893 flags=0x0000 ifindex=9   mac=56:EB:4E:8F:41:98 nodemac=92:70:24:9C:63:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:32.859Z",
  "value": "id=787   sec_id=4     flags=0x0000 ifindex=7   mac=CA:53:69:39:DF:57 nodemac=5A:4F:4C:79:FE:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:32.859Z",
  "value": "id=1371  sec_id=1957897 flags=0x0000 ifindex=13  mac=5A:6B:EE:94:DD:2A nodemac=0E:02:F1:3D:B3:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:04.405Z",
  "value": "id=27    sec_id=1957897 flags=0x0000 ifindex=15  mac=26:B3:6E:DD:56:14 nodemac=C6:97:16:A9:07:9F"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.28.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:14.689Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:54.121Z",
  "value": "id=2882  sec_id=1908893 flags=0x0000 ifindex=11  mac=42:C7:18:96:B7:E8 nodemac=0E:89:23:E7:A0:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:54.123Z",
  "value": "id=27    sec_id=1957897 flags=0x0000 ifindex=15  mac=26:B3:6E:DD:56:14 nodemac=C6:97:16:A9:07:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:54.124Z",
  "value": "id=787   sec_id=4     flags=0x0000 ifindex=7   mac=CA:53:69:39:DF:57 nodemac=5A:4F:4C:79:FE:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:54.124Z",
  "value": "id=3650  sec_id=1908893 flags=0x0000 ifindex=9   mac=56:EB:4E:8F:41:98 nodemac=92:70:24:9C:63:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:55.090Z",
  "value": "id=2882  sec_id=1908893 flags=0x0000 ifindex=11  mac=42:C7:18:96:B7:E8 nodemac=0E:89:23:E7:A0:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:55.091Z",
  "value": "id=787   sec_id=4     flags=0x0000 ifindex=7   mac=CA:53:69:39:DF:57 nodemac=5A:4F:4C:79:FE:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:55.091Z",
  "value": "id=27    sec_id=1957897 flags=0x0000 ifindex=15  mac=26:B3:6E:DD:56:14 nodemac=C6:97:16:A9:07:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:55.091Z",
  "value": "id=3650  sec_id=1908893 flags=0x0000 ifindex=9   mac=56:EB:4E:8F:41:98 nodemac=92:70:24:9C:63:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:56.091Z",
  "value": "id=27    sec_id=1957897 flags=0x0000 ifindex=15  mac=26:B3:6E:DD:56:14 nodemac=C6:97:16:A9:07:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:56.091Z",
  "value": "id=787   sec_id=4     flags=0x0000 ifindex=7   mac=CA:53:69:39:DF:57 nodemac=5A:4F:4C:79:FE:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:56.091Z",
  "value": "id=3650  sec_id=1908893 flags=0x0000 ifindex=9   mac=56:EB:4E:8F:41:98 nodemac=92:70:24:9C:63:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.28.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:56.091Z",
  "value": "id=2882  sec_id=1908893 flags=0x0000 ifindex=11  mac=42:C7:18:96:B7:E8 nodemac=0E:89:23:E7:A0:CB"
}

