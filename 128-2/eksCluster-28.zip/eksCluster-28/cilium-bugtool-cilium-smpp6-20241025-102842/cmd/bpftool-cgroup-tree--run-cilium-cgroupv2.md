CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod15ad6ade_3895_4139_9d08_cfc66ce1124f.slice/cri-containerd-8b912ed6cbb8fb7a08b01b8d609b815c4ddb10f21fdde79c1888e8d1fd1be01a.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod15ad6ade_3895_4139_9d08_cfc66ce1124f.slice/cri-containerd-064aefb91e6121ad06cd52e0a87f42612a13f7c0bdd306609a916a2da01034e6.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7884341f_fc68_48b6_894d_4a4bc3080662.slice/cri-containerd-7039adb9caabee558c88d11fddbf3a3c87d20d9cf2683497c5037200aeebd5cf.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7884341f_fc68_48b6_894d_4a4bc3080662.slice/cri-containerd-f514fe1fcc97dc4ef5232f512160b6edb461f5d8f09e039b868a757a5712f117.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3a0480fc_4920_486a_9488_ca9f706d49dc.slice/cri-containerd-26a9f07e8c54c0fb998585e12fa9c1d37cbc399fa85ac6bedda07b2b7ba48489.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3a0480fc_4920_486a_9488_ca9f706d49dc.slice/cri-containerd-d5f7627c6a7d3d8b51bb0c0dc12ed04e81a240d6b7815d91de9acf9b985d505d.scope
    556      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod43720f33_6064_400b_91a8_98a38a11be59.slice/cri-containerd-a12ecaf5ebcf31b36a305dec90f737353006dc253942960b668cfc3eeb4841b5.scope
    110      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod43720f33_6064_400b_91a8_98a38a11be59.slice/cri-containerd-c782334fb428f9b04ef76bc729fd080c73cb9249c9225e6bd8f1ab3fbbdc8e9d.scope
    67       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd349545e_a9c3_4861_9c32_54561eae146a.slice/cri-containerd-76176b7b6e3de2083a3b0ba024644108874e774d7a6057b1ba649d59f0decad9.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd349545e_a9c3_4861_9c32_54561eae146a.slice/cri-containerd-cf9ffce07c124631730828650a1534c7bb7f4d7f7454f61739e79a8b695a84a6.scope
    83       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95cf7590_df42_40eb_a125_49ce33b35f0d.slice/cri-containerd-ff1165a931288e6795b8f7fa2c59bf096c988219b29cc420bdb564986ef957bf.scope
    630      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95cf7590_df42_40eb_a125_49ce33b35f0d.slice/cri-containerd-e69e9b9ae238619fd51cb0fff3077e9a0b2efc49d7b28c3b4891156535b020a3.scope
    610      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95cf7590_df42_40eb_a125_49ce33b35f0d.slice/cri-containerd-e20666908863c41ffefbaad6d594d97fdf078d64e082b1caae7a0ea0b2ba1c22.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95cf7590_df42_40eb_a125_49ce33b35f0d.slice/cri-containerd-39a824377b1e9800cfb03a974e170c98e733d7f961d4728823b02d1912ba4aa0.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod99e3b75c_d66c_496b_a126_0a8fb4525c92.slice/cri-containerd-41395076f0dfd5bc6bc4ae71d397a79d65fa24aeea2e97d94a6f57c519febd0a.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod99e3b75c_d66c_496b_a126_0a8fb4525c92.slice/cri-containerd-48058fc667b52dafcf40942eea1fb5e1746a311d628c3840ccaa606cf1f7a2e9.scope
    71       cgroup_device   multi                                          
