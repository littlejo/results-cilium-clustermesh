USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         613  0.0  0.3 1240176 15556 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         631  0.0  0.0   6408  1644 ?        R    10:28   0:00  \_ ps auxfw
root         633  0.0  0.0      4     4 ?        R    10:28   0:00  \_ [bash]
root           1  2.5  6.9 1537844 273828 ?      Ssl  10:13   0:22 cilium-agent --config-dir=/tmp/cilium/config-map
root         391  0.0  0.1 1228848 5784 ?        Sl   10:14   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
