USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         705  0.0  0.3 1240176 15560 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         721  0.0  0.0   6408  1648 ?        R    10:28   0:00  \_ ps auxfw
root         722  0.0  0.0   3852  1296 ?        R    10:28   0:00  \_ bash -c hostname
root         695  0.0  0.1 1228744 4036 ?        Ssl  10:28   0:00 /bin/gops stack 1
root         675  0.0  0.0 1228744 3596 ?        Ssl  10:28   0:00 /bin/gops memstats 1
root         669  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root         658  0.0  0.1 1228744 4036 ?        Ssl  10:28   0:00 /bin/gops stats 1
root           1  2.8  7.0 1472240 275856 ?      Ssl  10:15   0:22 cilium-agent --config-dir=/tmp/cilium/config-map
root         402  0.0  0.1 1228848 6732 ?        Sl   10:15   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
