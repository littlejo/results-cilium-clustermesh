[
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod66968444_00fb_4cb3_bbe6_8b2e78edaaae.slice/cri-containerd-04969908031df851403bc752ef32b6b45ccde9b72716f5c2fca46c0b0c444322.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod66968444_00fb_4cb3_bbe6_8b2e78edaaae.slice/cri-containerd-4dea35668a7a5ec9c5891680b6a8e6044464f1607c076415306d495df2579648.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod66968444_00fb_4cb3_bbe6_8b2e78edaaae.slice/cri-containerd-935e4dd107d473b2c721b83989621a2f24a7725c620484c41cc92634915a2be1.scope"
      }
    ],
    "ips": [
      "10.35.0.91"
    ],
    "name": "clustermesh-apiserver-588c8d87bd-wkvj2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7614,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0e98b195_5530_4320_a02e_ddaa9f2c9bf3.slice/cri-containerd-252ba965bab521e239cc3c8bd6647866dbd2504fe68de067bb65636dfc97dfba.scope"
      }
    ],
    "ips": [
      "10.35.0.165"
    ],
    "name": "coredns-cc6ccd49c-c7ksf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3dc97122_f8f2_4116_a7c6_a8f7ae37b91a.slice/cri-containerd-90165ef08537e19190efa1cd6d7ffa959cf3b1bc4b466e0b2b8c380e5f2107b9.scope"
      }
    ],
    "ips": [
      "10.35.0.71"
    ],
    "name": "coredns-cc6ccd49c-wtwz9",
    "namespace": "kube-system"
  }
]

