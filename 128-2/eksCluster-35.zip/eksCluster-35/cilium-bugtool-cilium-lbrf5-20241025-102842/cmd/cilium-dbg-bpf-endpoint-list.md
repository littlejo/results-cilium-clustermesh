IP ADDRESS         LOCAL ENDPOINT INFO
10.35.0.91:0       id=2453  sec_id=2375851 flags=0x0000 ifindex=18  mac=32:9B:4B:C5:60:13 nodemac=32:47:59:B1:5C:63   
10.35.0.180:0      (localhost)                                                                                        
10.35.0.90:0       id=1423  sec_id=4     flags=0x0000 ifindex=10  mac=22:8B:8E:D5:71:3E nodemac=82:8B:F7:57:8C:AB     
172.31.193.211:0   (localhost)                                                                                        
10.35.0.165:0      id=686   sec_id=2398546 flags=0x0000 ifindex=12  mac=92:2F:85:D5:40:C6 nodemac=BE:8B:51:22:9D:EB   
172.31.193.174:0   (localhost)                                                                                        
10.35.0.71:0       id=3596  sec_id=2398546 flags=0x0000 ifindex=14  mac=EA:0A:DB:31:12:3A nodemac=7A:A7:3B:C5:91:E4   
