key: ae 02 00 00  value: 16 02 00 00
key: 8f 05 00 00  value: 33 02 00 00
key: 95 09 00 00  value: 81 02 00 00
key: 0c 0e 00 00  value: 24 02 00 00
Found 4 elements
