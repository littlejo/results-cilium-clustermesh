Endpoint ID: 686
Path: /sys/fs/bpf/tc/globals/cilium_policy_00686

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    79120   914       0        
Allow    Egress      0          ANY          NONE         disabled    12246   126       0        


Endpoint ID: 1423
Path: /sys/fs/bpf/tc/globals/cilium_policy_01423

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    434888   5555      0        
Allow    Ingress     1          ANY          NONE         disabled    11084    129       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1850
Path: /sys/fs/bpf/tc/globals/cilium_policy_01850

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2453
Path: /sys/fs/bpf/tc/globals/cilium_policy_02453

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3898451   36326     0        
Allow    Ingress     1          ANY          NONE         disabled    2928406   29339     0        
Allow    Egress      0          ANY          NONE         disabled    4079138   38016     0        


Endpoint ID: 3596
Path: /sys/fs/bpf/tc/globals/cilium_policy_03596

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    77788   898       0        
Allow    Egress      0          ANY          NONE         disabled    13340   139       0        


