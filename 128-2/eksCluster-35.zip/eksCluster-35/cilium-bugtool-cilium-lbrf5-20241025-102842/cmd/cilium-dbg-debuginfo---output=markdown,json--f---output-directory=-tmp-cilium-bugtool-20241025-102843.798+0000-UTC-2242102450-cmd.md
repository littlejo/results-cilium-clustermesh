markdown output at /tmp/cilium-bugtool-20241025-102843.798+0000-UTC-2242102450/cmd/cilium-debuginfo-20241025-102914.238+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102843.798+0000-UTC-2242102450/cmd/cilium-debuginfo-20241025-102914.238+0000-UTC.json
