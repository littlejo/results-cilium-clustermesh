xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 585
ens6(5) clsact/ingress cil_from_netdev-ens6 id 591
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 580
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 576
cilium_host(7) clsact/egress cil_from_host-cilium_host id 573
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 505
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 506
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 561
lxc5b5b83bb8af8(12) clsact/ingress cil_from_container-lxc5b5b83bb8af8 id 538
lxcfdf641761af3(14) clsact/ingress cil_from_container-lxcfdf641761af3 id 554
lxcd01c6d90291d(18) clsact/ingress cil_from_container-lxcd01c6d90291d id 638

flow_dissector:

netfilter:

