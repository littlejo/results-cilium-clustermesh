{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:30.208Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.193.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:30.208Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.193.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:30.208Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:33.992Z",
  "value": "id=686   sec_id=2398546 flags=0x0000 ifindex=12  mac=92:2F:85:D5:40:C6 nodemac=BE:8B:51:22:9D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:37.447Z",
  "value": "id=3596  sec_id=2398546 flags=0x0000 ifindex=14  mac=EA:0A:DB:31:12:3A nodemac=7A:A7:3B:C5:91:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:37.460Z",
  "value": "id=1423  sec_id=4     flags=0x0000 ifindex=10  mac=22:8B:8E:D5:71:3E nodemac=82:8B:F7:57:8C:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:37.545Z",
  "value": "id=686   sec_id=2398546 flags=0x0000 ifindex=12  mac=92:2F:85:D5:40:C6 nodemac=BE:8B:51:22:9D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:37.640Z",
  "value": "id=3596  sec_id=2398546 flags=0x0000 ifindex=14  mac=EA:0A:DB:31:12:3A nodemac=7A:A7:3B:C5:91:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:37.737Z",
  "value": "id=1423  sec_id=4     flags=0x0000 ifindex=10  mac=22:8B:8E:D5:71:3E nodemac=82:8B:F7:57:8C:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:22.031Z",
  "value": "id=686   sec_id=2398546 flags=0x0000 ifindex=12  mac=92:2F:85:D5:40:C6 nodemac=BE:8B:51:22:9D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:22.031Z",
  "value": "id=3596  sec_id=2398546 flags=0x0000 ifindex=14  mac=EA:0A:DB:31:12:3A nodemac=7A:A7:3B:C5:91:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:22.031Z",
  "value": "id=1423  sec_id=4     flags=0x0000 ifindex=10  mac=22:8B:8E:D5:71:3E nodemac=82:8B:F7:57:8C:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:22.074Z",
  "value": "id=1309  sec_id=2375851 flags=0x0000 ifindex=16  mac=32:B2:F1:15:2F:48 nodemac=AE:C5:D8:77:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:23.031Z",
  "value": "id=1423  sec_id=4     flags=0x0000 ifindex=10  mac=22:8B:8E:D5:71:3E nodemac=82:8B:F7:57:8C:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:23.031Z",
  "value": "id=686   sec_id=2398546 flags=0x0000 ifindex=12  mac=92:2F:85:D5:40:C6 nodemac=BE:8B:51:22:9D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:23.031Z",
  "value": "id=1309  sec_id=2375851 flags=0x0000 ifindex=16  mac=32:B2:F1:15:2F:48 nodemac=AE:C5:D8:77:32:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:23.032Z",
  "value": "id=3596  sec_id=2398546 flags=0x0000 ifindex=14  mac=EA:0A:DB:31:12:3A nodemac=7A:A7:3B:C5:91:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:36.584Z",
  "value": "id=2453  sec_id=2375851 flags=0x0000 ifindex=18  mac=32:9B:4B:C5:60:13 nodemac=32:47:59:B1:5C:63"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.35.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:42.772Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:15.767Z",
  "value": "id=1423  sec_id=4     flags=0x0000 ifindex=10  mac=22:8B:8E:D5:71:3E nodemac=82:8B:F7:57:8C:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:15.767Z",
  "value": "id=2453  sec_id=2375851 flags=0x0000 ifindex=18  mac=32:9B:4B:C5:60:13 nodemac=32:47:59:B1:5C:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:15.768Z",
  "value": "id=686   sec_id=2398546 flags=0x0000 ifindex=12  mac=92:2F:85:D5:40:C6 nodemac=BE:8B:51:22:9D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:15.769Z",
  "value": "id=3596  sec_id=2398546 flags=0x0000 ifindex=14  mac=EA:0A:DB:31:12:3A nodemac=7A:A7:3B:C5:91:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:16.758Z",
  "value": "id=2453  sec_id=2375851 flags=0x0000 ifindex=18  mac=32:9B:4B:C5:60:13 nodemac=32:47:59:B1:5C:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:16.759Z",
  "value": "id=686   sec_id=2398546 flags=0x0000 ifindex=12  mac=92:2F:85:D5:40:C6 nodemac=BE:8B:51:22:9D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:16.759Z",
  "value": "id=3596  sec_id=2398546 flags=0x0000 ifindex=14  mac=EA:0A:DB:31:12:3A nodemac=7A:A7:3B:C5:91:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:16.760Z",
  "value": "id=1423  sec_id=4     flags=0x0000 ifindex=10  mac=22:8B:8E:D5:71:3E nodemac=82:8B:F7:57:8C:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.758Z",
  "value": "id=686   sec_id=2398546 flags=0x0000 ifindex=12  mac=92:2F:85:D5:40:C6 nodemac=BE:8B:51:22:9D:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.758Z",
  "value": "id=2453  sec_id=2375851 flags=0x0000 ifindex=18  mac=32:9B:4B:C5:60:13 nodemac=32:47:59:B1:5C:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.758Z",
  "value": "id=3596  sec_id=2398546 flags=0x0000 ifindex=14  mac=EA:0A:DB:31:12:3A nodemac=7A:A7:3B:C5:91:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.35.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.758Z",
  "value": "id=1423  sec_id=4     flags=0x0000 ifindex=10  mac=22:8B:8E:D5:71:3E nodemac=82:8B:F7:57:8C:AB"
}

