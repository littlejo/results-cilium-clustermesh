ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.186.60:443 (active)     
                                         2 => 172.31.240.67:443 (active)     
2    10.100.175.82:443    ClusterIP      1 => 172.31.193.211:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.35.0.165:53 (active)        
                                         2 => 10.35.0.71:53 (active)         
4    10.100.0.10:9153     ClusterIP      1 => 10.35.0.165:9153 (active)      
                                         2 => 10.35.0.71:9153 (active)       
5    10.100.32.116:2379   ClusterIP      1 => 10.35.0.91:2379 (active)       
