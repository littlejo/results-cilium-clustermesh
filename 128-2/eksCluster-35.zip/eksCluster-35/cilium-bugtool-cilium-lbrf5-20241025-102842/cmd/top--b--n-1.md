top - 10:28:44 up 14 min,  0 users,  load average: 0.48, 0.26, 0.17
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 41.4 us, 17.2 sy,  0.0 ni, 41.4 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    798.3 free,    895.8 used,   2142.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2771.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1472240 275856  79444 S   6.7   7.0   0:22.66 cilium-+
    402 root      20   0 1228848   6732   3904 S   0.0   0.2   0:00.27 cilium-+
    658 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    669 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    675 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    695 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    705 root      20   0 1240432  16396  11420 S   0.0   0.4   0:00.02 cilium-+
    733 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    757 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    763 root      20   0 1616264   8744   6236 S   0.0   0.2   0:00.00 runc:[2+
