alloc: 77.49MB (81257104 bytes)
total-alloc: 1.33GB (1424194856 bytes)
sys: 210.63MB (220865876 bytes)
lookups: 0
mallocs: 47661759
frees: 47131684
heap-alloc: 77.49MB (81257104 bytes)
heap-sys: 165.51MB (173547520 bytes)
heap-idle: 44.14MB (46284800 bytes)
heap-in-use: 121.37MB (127262720 bytes)
heap-released: 1.50MB (1572864 bytes)
heap-objects: 530075
stack-in-use: 34.47MB (36143104 bytes)
stack-sys: 34.47MB (36143104 bytes)
stack-mspan-inuse: 1.94MB (2034720 bytes)
stack-mspan-sys: 2.57MB (2692800 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.05MB (1099881 bytes)
gc-sys: 5.12MB (5367920 bytes)
next-gc: when heap-alloc >= 148.16MB (155352200 bytes)
last-gc: 2024-10-25 10:29:10.042653812 +0000 UTC
gc-pause-total: 8.714902ms
gc-pause: 59906
gc-pause-end: 1729852150042653812
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.000306021234445216
enable-gc: true
debug-gc: false
