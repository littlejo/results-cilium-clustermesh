key: 01 00 00 00  value: ac 1f ba 3c 01 bb 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f f0 43 01 bb 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 23 00 5b 09 4b 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 23 00 47 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f c1 d3 10 94 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 23 00 a5 23 c1 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 23 00 47 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 23 00 a5 00 35 00 00  00 00 00 00
Found 8 elements
