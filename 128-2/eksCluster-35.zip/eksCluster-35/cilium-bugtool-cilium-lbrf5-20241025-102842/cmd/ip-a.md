1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:ec:be:f7:20:ed brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.193.211/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2737sec preferred_lft 2737sec
    inet6 fe80::8ec:beff:fef7:20ed/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:40:5a:14:f8:bf brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.193.174/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::840:5aff:fe14:f8bf/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:d5:1b:56:70:10 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b8d5:1bff:fe56:7010/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:91:f6:45:3b:ae brd ff:ff:ff:ff:ff:ff
    inet 10.35.0.180/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::2091:f6ff:fe45:3bae/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 3a:0b:82:3f:b3:af brd ff:ff:ff:ff:ff:ff
    inet6 fe80::380b:82ff:fe3f:b3af/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:8b:f7:57:8c:ab brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::808b:f7ff:fe57:8cab/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc5b5b83bb8af8@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:8b:51:22:9d:eb brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::bc8b:51ff:fe22:9deb/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcfdf641761af3@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:a7:3b:c5:91:e4 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::78a7:3bff:fec5:91e4/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcd01c6d90291d@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:47:59:b1:5c:63 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::3047:59ff:feb1:5c63/64 scope link 
       valid_lft forever preferred_lft forever
