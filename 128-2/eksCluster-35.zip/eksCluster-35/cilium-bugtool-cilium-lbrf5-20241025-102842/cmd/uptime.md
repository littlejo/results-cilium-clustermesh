 10:28:43 up 14 min,  0 users,  load average: 0.48, 0.26, 0.17
