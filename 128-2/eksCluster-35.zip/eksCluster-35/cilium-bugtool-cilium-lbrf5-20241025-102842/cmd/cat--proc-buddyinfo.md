Node 0, zone      DMA      2     12      3      3      2      2      3      1      2      4    166 
Node 0, zone   Normal    184     52     23     17      6      2      1      2      2      2      8 
