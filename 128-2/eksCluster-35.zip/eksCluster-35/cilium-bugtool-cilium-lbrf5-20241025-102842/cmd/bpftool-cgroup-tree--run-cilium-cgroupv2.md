CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0e98b195_5530_4320_a02e_ddaa9f2c9bf3.slice/cri-containerd-252ba965bab521e239cc3c8bd6647866dbd2504fe68de067bb65636dfc97dfba.scope
    502      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0e98b195_5530_4320_a02e_ddaa9f2c9bf3.slice/cri-containerd-83ac82c21df684121ced802b608903adf5a67aaabe4f2b11d5e9704f357b98c1.scope
    498      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6dfd7d8e_f944_4167_a7b0_b3866e0b11e4.slice/cri-containerd-6572de3444f781f274826f6377fe3b02bac9f42175fe5abf4d5d7d73435fe2fb.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6dfd7d8e_f944_4167_a7b0_b3866e0b11e4.slice/cri-containerd-c0c038cec96f7e958209469a3477b662965a9623f178dd5a48de263837da7088.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3dc97122_f8f2_4116_a7c6_a8f7ae37b91a.slice/cri-containerd-90165ef08537e19190efa1cd6d7ffa959cf3b1bc4b466e0b2b8c380e5f2107b9.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3dc97122_f8f2_4116_a7c6_a8f7ae37b91a.slice/cri-containerd-b50c8c16a8c2b2077be7e710322f47f3ff98973505ca4337744824083e479b7e.scope
    547      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode6d53d6b_12b4_4ccc_ac55_95495eb03dca.slice/cri-containerd-ab8f2ba2c0dc7e2f49205c267bf389ab9c932f719289849f0dd98579e16a74c9.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode6d53d6b_12b4_4ccc_ac55_95495eb03dca.slice/cri-containerd-2c5fa848d15aaeb601a887dc8e673c5b8e283ce5e82055c96a3ff9bfa6ed429b.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod66968444_00fb_4cb3_bbe6_8b2e78edaaae.slice/cri-containerd-830c399750bee6a0c1ccc021308392a77d5d7c2d305ac145d2740734209d0dbd.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod66968444_00fb_4cb3_bbe6_8b2e78edaaae.slice/cri-containerd-4dea35668a7a5ec9c5891680b6a8e6044464f1607c076415306d495df2579648.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod66968444_00fb_4cb3_bbe6_8b2e78edaaae.slice/cri-containerd-935e4dd107d473b2c721b83989621a2f24a7725c620484c41cc92634915a2be1.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod66968444_00fb_4cb3_bbe6_8b2e78edaaae.slice/cri-containerd-04969908031df851403bc752ef32b6b45ccde9b72716f5c2fca46c0b0c444322.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcf815795_bf9c_4c71_aaca_341cf6c37ab7.slice/cri-containerd-859580b07fa19eb93d63f9aecb1b5dd84eacd25e1cf38b38d27e716a74ac28ba.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcf815795_bf9c_4c71_aaca_341cf6c37ab7.slice/cri-containerd-153d06c2cd0d7105a70a5865ae8574f57278f5acb5436fc30d1b439c92e0861f.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podefd4099a_5d3a_4e2e_ad45_49d40faee8f0.slice/cri-containerd-207e8d89c3543ca77c23613e83cfbdbfcde84e2747f97c9f5073cbb3d3f6aace.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podefd4099a_5d3a_4e2e_ad45_49d40faee8f0.slice/cri-containerd-53f9128ef88f9a0ac721d7cd7e4db516c945116fe4886fcd2fdf4a69d80129e0.scope
    97       cgroup_device   multi                                          
