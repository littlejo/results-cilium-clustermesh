KEY             VALUE
AgentLiveness   903765815350
UTimeOffset     3378615722656250
