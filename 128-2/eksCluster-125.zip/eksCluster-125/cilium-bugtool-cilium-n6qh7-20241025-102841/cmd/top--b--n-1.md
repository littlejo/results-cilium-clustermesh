top - 10:28:42 up 14 min,  0 users,  load average: 0.29, 0.22, 0.13
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 17.9 us, 28.6 sy,  0.0 ni, 53.6 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    787.1 free,    908.2 used,   2140.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2759.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 277008  78972 S   0.0   7.1   0:23.31 cilium-+
    417 root      20   0 1228848   5684   3056 S   0.0   0.1   0:00.26 cilium-+
    668 root      20   0 1229000   4048   3392 S   0.0   0.1   0:00.00 gops
    698 root      20   0 1240432  16484  11420 S   0.0   0.4   0:00.02 cilium-+
    731 root      20   0    6576   2416   2092 R   0.0   0.1   0:00.00 top
    750 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    755 root      20   0 1692104   8784   6256 S   0.0   0.2   0:00.00 runc:[2+
