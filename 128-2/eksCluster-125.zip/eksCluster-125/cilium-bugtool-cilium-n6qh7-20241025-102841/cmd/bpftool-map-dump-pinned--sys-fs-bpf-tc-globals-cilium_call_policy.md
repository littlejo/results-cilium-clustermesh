key: 09 01 00 00  value: 76 02 00 00
key: 8e 06 00 00  value: 06 02 00 00
key: d5 09 00 00  value: fd 01 00 00
key: 4c 0b 00 00  value: 1d 02 00 00
Found 4 elements
