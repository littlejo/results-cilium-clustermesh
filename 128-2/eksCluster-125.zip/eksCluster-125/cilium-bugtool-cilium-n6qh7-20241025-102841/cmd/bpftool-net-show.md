xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 571
ens6(5) clsact/ingress cil_from_netdev-ens6 id 574
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 563
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 557
cilium_host(7) clsact/egress cil_from_host-cilium_host id 555
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 478
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 515
lxca77b4f786c4c(12) clsact/ingress cil_from_container-lxca77b4f786c4c id 536
lxcb5581df50213(14) clsact/ingress cil_from_container-lxcb5581df50213 id 504
lxcba307b3394ee(18) clsact/ingress cil_from_container-lxcba307b3394ee id 627

flow_dissector:

netfilter:

