Node 0, zone      DMA      1      5      3      3     44     76     59     16      8      6    160 
Node 0, zone   Normal     47      1     12     19     17     16      8      2      1      1      8 
