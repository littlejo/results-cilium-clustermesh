CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb0a78353_aa6d_4d77_8e34_9384f7391470.slice/cri-containerd-8e9a2aa73a5dda8538934d517092e46e367316131f0435e85764fbd2905f1b54.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb0a78353_aa6d_4d77_8e34_9384f7391470.slice/cri-containerd-6617242d90d4855334f1e351fb7387b55b10674a9275444f43f00d8e0b5c3200.scope
    540      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod677986e9_e423_49e1_9965_df69c3efe587.slice/cri-containerd-70d10e6d9386d9b63cd8258c729d55e656c331e53da3db1e4e7b09ea1f247271.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod677986e9_e423_49e1_9965_df69c3efe587.slice/cri-containerd-11f1dd5a1174a222260f044d20f3883f287e22168d3ccd20e647b84e089da0f1.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda98676ed_e700_4d0a_8dcc_beea2d6fffef.slice/cri-containerd-3aa026e982094528fedf16bc09890ed6a98e921cc71c6d2ab5a7d26635deb5b7.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda98676ed_e700_4d0a_8dcc_beea2d6fffef.slice/cri-containerd-7a8c6ef83a61b703824b4d5c2568aa113b90769d2489b7c7565cc3a8b4c48083.scope
    529      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb4009a73_9c00_4c8c_b785_b55d1d8f534a.slice/cri-containerd-f9284ef3eb1f9616ebb9ab3c51d02ad2807b058f392f6ceeee554ac467c263aa.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb4009a73_9c00_4c8c_b785_b55d1d8f534a.slice/cri-containerd-b492cfc44870a9e63cce0c26296674296fb0d53c745a20395509f5249379e73d.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e4fb294_a39e_4241_97f9_d7585a6d9045.slice/cri-containerd-5a6c955a7ecd677cff5eb6da8af39d964f4aec89e0a0fc91376ab9344189f670.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e4fb294_a39e_4241_97f9_d7585a6d9045.slice/cri-containerd-5de9962278ddbeb4a2f79df8e0f2bd4ce768b7ca8772496d07dfc240044c8801.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5a7adf7_b0c7_4c13_a10e_a8db71917893.slice/cri-containerd-6a5c73e192f843c0deccf63afc5e0fe0397975a5b5c9a2bec6a0dce2cbb59f9d.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5a7adf7_b0c7_4c13_a10e_a8db71917893.slice/cri-containerd-8211fe55487101edc6f5af8242b8f2586c3dd3dc36d6cfc586aa57c898b2047c.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5a7adf7_b0c7_4c13_a10e_a8db71917893.slice/cri-containerd-b56e2834c73f9c69865f56a2db7fe980f718e609f79da9e0ff46c198c96355ee.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5a7adf7_b0c7_4c13_a10e_a8db71917893.slice/cri-containerd-dd0d53eb7590ace6e8e09de3e3cbaedfc14c5d819919c5aac2cf35a02df67dfb.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod09d10703_ca52_45a4_866f_de9d6e8179ee.slice/cri-containerd-2f61801759fe18440e5975e22f01839143652dce0ad13081cd773a8426ad582b.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod09d10703_ca52_45a4_866f_de9d6e8179ee.slice/cri-containerd-e957a1ee6eff5b2a3745d19c5087c90cade31bc7419e88d136f7894430070675.scope
    99       cgroup_device   multi                                          
