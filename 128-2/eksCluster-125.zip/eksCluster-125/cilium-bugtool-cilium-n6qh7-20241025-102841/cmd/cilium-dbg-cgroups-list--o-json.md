[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb0a78353_aa6d_4d77_8e34_9384f7391470.slice/cri-containerd-8e9a2aa73a5dda8538934d517092e46e367316131f0435e85764fbd2905f1b54.scope"
      }
    ],
    "ips": [
      "10.125.0.129"
    ],
    "name": "coredns-cc6ccd49c-phmh4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda98676ed_e700_4d0a_8dcc_beea2d6fffef.slice/cri-containerd-3aa026e982094528fedf16bc09890ed6a98e921cc71c6d2ab5a7d26635deb5b7.scope"
      }
    ],
    "ips": [
      "10.125.0.132"
    ],
    "name": "coredns-cc6ccd49c-k5bzn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5a7adf7_b0c7_4c13_a10e_a8db71917893.slice/cri-containerd-6a5c73e192f843c0deccf63afc5e0fe0397975a5b5c9a2bec6a0dce2cbb59f9d.scope"
      },
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5a7adf7_b0c7_4c13_a10e_a8db71917893.slice/cri-containerd-8211fe55487101edc6f5af8242b8f2586c3dd3dc36d6cfc586aa57c898b2047c.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5a7adf7_b0c7_4c13_a10e_a8db71917893.slice/cri-containerd-b56e2834c73f9c69865f56a2db7fe980f718e609f79da9e0ff46c198c96355ee.scope"
      }
    ],
    "ips": [
      "10.125.0.87"
    ],
    "name": "clustermesh-apiserver-648dc49d66-9zt94",
    "namespace": "kube-system"
  }
]

