markdown output at /tmp/cilium-bugtool-20241025-102842.644+0000-UTC-226724305/cmd/cilium-debuginfo-20241025-102913.058+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102842.644+0000-UTC-226724305/cmd/cilium-debuginfo-20241025-102913.058+0000-UTC.json
