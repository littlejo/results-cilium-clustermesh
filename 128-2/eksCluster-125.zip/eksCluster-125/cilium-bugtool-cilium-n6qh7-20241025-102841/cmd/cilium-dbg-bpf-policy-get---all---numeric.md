Endpoint ID: 265
Path: /sys/fs/bpf/tc/globals/cilium_policy_00265

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3879067   36078     0        
Allow    Ingress     1          ANY          NONE         disabled    3083927   31096     0        
Allow    Egress      0          ANY          NONE         disabled    4001575   37184     0        


Endpoint ID: 535
Path: /sys/fs/bpf/tc/globals/cilium_policy_00535

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1678
Path: /sys/fs/bpf/tc/globals/cilium_policy_01678

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    427127   5429      0        
Allow    Ingress     1          ANY          NONE         disabled    11540    135       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2517
Path: /sys/fs/bpf/tc/globals/cilium_policy_02517

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    73501   839       0        
Allow    Egress      0          ANY          NONE         disabled    13150   135       0        


Endpoint ID: 2892
Path: /sys/fs/bpf/tc/globals/cilium_policy_02892

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    74755   858       0        
Allow    Egress      0          ANY          NONE         disabled    12143   124       0        


