REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     214480    84085254   1132   bpf_host.c
Interface                 INGRESS     9969      782923     677    bpf_overlay.c
Success                   EGRESS      10168     797124     53     encap.h
Success                   EGRESS      5200      400507     1694   bpf_host.c
Success                   EGRESS      88895     12081713   1308   bpf_lxc.c
Success                   INGRESS     100977    12261044   86     l3.h
Success                   INGRESS     106395    12687366   235    trace.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
