KEY             VALUE
AgentLiveness   889965202377
UTimeOffset     3378615748046875
