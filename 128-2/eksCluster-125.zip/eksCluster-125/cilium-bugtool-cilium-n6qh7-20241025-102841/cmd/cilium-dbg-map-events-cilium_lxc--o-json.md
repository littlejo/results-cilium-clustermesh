{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:57.402Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.218.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:57.402Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.220.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:57.402Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:02.040Z",
  "value": "id=1678  sec_id=4     flags=0x0000 ifindex=10  mac=A6:98:8B:F7:E3:E7 nodemac=6E:5A:29:25:9C:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:02.044Z",
  "value": "id=2892  sec_id=8312322 flags=0x0000 ifindex=12  mac=BE:7A:73:53:D3:78 nodemac=6A:5E:EB:FF:27:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:02.111Z",
  "value": "id=2517  sec_id=8312322 flags=0x0000 ifindex=14  mac=4A:4A:70:09:96:99 nodemac=02:50:6D:46:86:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:02.196Z",
  "value": "id=1678  sec_id=4     flags=0x0000 ifindex=10  mac=A6:98:8B:F7:E3:E7 nodemac=6E:5A:29:25:9C:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:02.261Z",
  "value": "id=2892  sec_id=8312322 flags=0x0000 ifindex=12  mac=BE:7A:73:53:D3:78 nodemac=6A:5E:EB:FF:27:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:35.192Z",
  "value": "id=1678  sec_id=4     flags=0x0000 ifindex=10  mac=A6:98:8B:F7:E3:E7 nodemac=6E:5A:29:25:9C:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:35.193Z",
  "value": "id=2892  sec_id=8312322 flags=0x0000 ifindex=12  mac=BE:7A:73:53:D3:78 nodemac=6A:5E:EB:FF:27:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:35.193Z",
  "value": "id=2517  sec_id=8312322 flags=0x0000 ifindex=14  mac=4A:4A:70:09:96:99 nodemac=02:50:6D:46:86:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:35.221Z",
  "value": "id=1620  sec_id=8264628 flags=0x0000 ifindex=16  mac=C2:56:11:21:E4:21 nodemac=FA:F4:04:59:D3:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:35.222Z",
  "value": "id=1620  sec_id=8264628 flags=0x0000 ifindex=16  mac=C2:56:11:21:E4:21 nodemac=FA:F4:04:59:D3:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:36.192Z",
  "value": "id=1620  sec_id=8264628 flags=0x0000 ifindex=16  mac=C2:56:11:21:E4:21 nodemac=FA:F4:04:59:D3:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:36.192Z",
  "value": "id=1678  sec_id=4     flags=0x0000 ifindex=10  mac=A6:98:8B:F7:E3:E7 nodemac=6E:5A:29:25:9C:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:36.192Z",
  "value": "id=2892  sec_id=8312322 flags=0x0000 ifindex=12  mac=BE:7A:73:53:D3:78 nodemac=6A:5E:EB:FF:27:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:36.192Z",
  "value": "id=2517  sec_id=8312322 flags=0x0000 ifindex=14  mac=4A:4A:70:09:96:99 nodemac=02:50:6D:46:86:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:41.234Z",
  "value": "id=265   sec_id=8264628 flags=0x0000 ifindex=18  mac=36:D4:2E:5A:B0:A9 nodemac=02:97:E2:B4:0B:29"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.125.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:46.903Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:50.795Z",
  "value": "id=2892  sec_id=8312322 flags=0x0000 ifindex=12  mac=BE:7A:73:53:D3:78 nodemac=6A:5E:EB:FF:27:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:50.795Z",
  "value": "id=2517  sec_id=8312322 flags=0x0000 ifindex=14  mac=4A:4A:70:09:96:99 nodemac=02:50:6D:46:86:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:50.796Z",
  "value": "id=265   sec_id=8264628 flags=0x0000 ifindex=18  mac=36:D4:2E:5A:B0:A9 nodemac=02:97:E2:B4:0B:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:50.796Z",
  "value": "id=1678  sec_id=4     flags=0x0000 ifindex=10  mac=A6:98:8B:F7:E3:E7 nodemac=6E:5A:29:25:9C:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:51.794Z",
  "value": "id=1678  sec_id=4     flags=0x0000 ifindex=10  mac=A6:98:8B:F7:E3:E7 nodemac=6E:5A:29:25:9C:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:51.795Z",
  "value": "id=2892  sec_id=8312322 flags=0x0000 ifindex=12  mac=BE:7A:73:53:D3:78 nodemac=6A:5E:EB:FF:27:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:51.795Z",
  "value": "id=2517  sec_id=8312322 flags=0x0000 ifindex=14  mac=4A:4A:70:09:96:99 nodemac=02:50:6D:46:86:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:51.795Z",
  "value": "id=265   sec_id=8264628 flags=0x0000 ifindex=18  mac=36:D4:2E:5A:B0:A9 nodemac=02:97:E2:B4:0B:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.795Z",
  "value": "id=1678  sec_id=4     flags=0x0000 ifindex=10  mac=A6:98:8B:F7:E3:E7 nodemac=6E:5A:29:25:9C:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.795Z",
  "value": "id=265   sec_id=8264628 flags=0x0000 ifindex=18  mac=36:D4:2E:5A:B0:A9 nodemac=02:97:E2:B4:0B:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.795Z",
  "value": "id=2892  sec_id=8312322 flags=0x0000 ifindex=12  mac=BE:7A:73:53:D3:78 nodemac=6A:5E:EB:FF:27:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.125.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.795Z",
  "value": "id=2517  sec_id=8312322 flags=0x0000 ifindex=14  mac=4A:4A:70:09:96:99 nodemac=02:50:6D:46:86:56"
}

