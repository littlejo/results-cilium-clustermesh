alloc: 94.20MB (98775568 bytes)
total-alloc: 1.33GB (1433134712 bytes)
sys: 206.38MB (216409428 bytes)
lookups: 0
mallocs: 47796774
frees: 46884992
heap-alloc: 94.20MB (98775568 bytes)
heap-sys: 161.32MB (169156608 bytes)
heap-idle: 42.98MB (45064192 bytes)
heap-in-use: 118.34MB (124092416 bytes)
heap-released: 3.83MB (4014080 bytes)
heap-objects: 911782
stack-in-use: 34.66MB (36339712 bytes)
stack-sys: 34.66MB (36339712 bytes)
stack-mspan-inuse: 1.97MB (2064640 bytes)
stack-mspan-sys: 2.44MB (2562240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 908.36KB (930161 bytes)
gc-sys: 5.17MB (5423456 bytes)
next-gc: when heap-alloc >= 148.82MB (156053592 bytes)
last-gc: 2024-10-25 10:28:51.91782083 +0000 UTC
gc-pause-total: 6.788179ms
gc-pause: 68768
gc-pause-end: 1729852131917820830
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0003758942766047614
enable-gc: true
debug-gc: false
