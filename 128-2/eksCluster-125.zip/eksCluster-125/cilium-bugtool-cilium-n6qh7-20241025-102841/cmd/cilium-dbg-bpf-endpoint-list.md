IP ADDRESS         LOCAL ENDPOINT INFO
172.31.220.135:0   (localhost)                                                                                        
10.125.0.30:0      (localhost)                                                                                        
10.125.0.132:0     id=2892  sec_id=8312322 flags=0x0000 ifindex=12  mac=BE:7A:73:53:D3:78 nodemac=6A:5E:EB:FF:27:34   
10.125.0.108:0     id=1678  sec_id=4     flags=0x0000 ifindex=10  mac=A6:98:8B:F7:E3:E7 nodemac=6E:5A:29:25:9C:31     
172.31.218.191:0   (localhost)                                                                                        
10.125.0.129:0     id=2517  sec_id=8312322 flags=0x0000 ifindex=14  mac=4A:4A:70:09:96:99 nodemac=02:50:6D:46:86:56   
10.125.0.87:0      id=265   sec_id=8264628 flags=0x0000 ifindex=18  mac=36:D4:2E:5A:B0:A9 nodemac=02:97:E2:B4:0B:29   
