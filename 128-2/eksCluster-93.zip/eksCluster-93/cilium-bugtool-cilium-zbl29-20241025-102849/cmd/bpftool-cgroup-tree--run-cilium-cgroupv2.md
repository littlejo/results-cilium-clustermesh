CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5ad83968_7d8d_401e_a9ff_4975d89da3be.slice/cri-containerd-29e53e9298f5db911634b18e79e205601d90807618d84d91e81d985b0474a9b3.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5ad83968_7d8d_401e_a9ff_4975d89da3be.slice/cri-containerd-d1ddaa423db020f5972209053bce215ccc9f25a74e8f8f6fe6a92dfad8780fd9.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10451a92_ac42_4038_bba8_4a049194550a.slice/cri-containerd-46b37a92372470ec2f2c4299758886fb34e8bdd7e35ec06aa102c19774bd38de.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10451a92_ac42_4038_bba8_4a049194550a.slice/cri-containerd-b3e253159eef512a9d525c3b08604af8025c44d51d47f9c7eaecccfc9935b53a.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod748f8648_1987_4552_ad12_dd95319a93ee.slice/cri-containerd-c25ea15d898a4408012ffa09889d14be12a8b22ba85a58bb1f99c7b6300f44a3.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod748f8648_1987_4552_ad12_dd95319a93ee.slice/cri-containerd-ba363a37d595b4c3465e86fd81a047b200a9d10c20e756d181f8c0c2f00c9b49.scope
    540      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeed69586_ee29_434c_8f20_82a3ebea60a6.slice/cri-containerd-711fac037611157fe2c862334c519d27f1f0352d17fc9913673cfe85673316fd.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeed69586_ee29_434c_8f20_82a3ebea60a6.slice/cri-containerd-c2f00c97f8c912317138ca25e9d0d244b5dd8e63388b0031580562dafe7134f8.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb3a23ed9_9b16_4007_be6d_92bedc986d55.slice/cri-containerd-d3c8b1052fcb6e291715df8e57863955d02d4fd08b0a3896d8a5b37662899a82.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb3a23ed9_9b16_4007_be6d_92bedc986d55.slice/cri-containerd-9ffd40da0e7d02f7602c0fa49b3627d3c7cf311b62248d9934281b5f66eb5e22.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod377401ca_865d_4b0c_8c39_770eb4f292be.slice/cri-containerd-d9dd28199e0acd77e8ef6919ee1d656ff6cef40163f8c39fac201856f6612014.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod377401ca_865d_4b0c_8c39_770eb4f292be.slice/cri-containerd-2fbdd8f00fb401d0c9b9301428a555598643210c3385951cdc6a3b0b7a2d40f2.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7bba53f6_d471_421e_9fad_c205cbe12b46.slice/cri-containerd-8be728f25b1073c3ce511a260a03fc325794688e08abd076cd2725556f7f9017.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7bba53f6_d471_421e_9fad_c205cbe12b46.slice/cri-containerd-a65574427eb8c4a0c814f610fbffef36b195c01b40ae8d677614e86a5ea658b4.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7bba53f6_d471_421e_9fad_c205cbe12b46.slice/cri-containerd-840a589ced5005116aa1c840c66fd23e4a538043f8478a066a814f9ca2014756.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7bba53f6_d471_421e_9fad_c205cbe12b46.slice/cri-containerd-5a5c3507c82140a85ef6f8da21307befd35bb35d2fb4e118a5d35aaceca09dcf.scope
    664      cgroup_device   multi                                          
