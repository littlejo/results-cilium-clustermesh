xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 574
ens6(5) clsact/ingress cil_from_netdev-ens6 id 582
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 567
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 562
cilium_host(7) clsact/egress cil_from_host-cilium_host id 563
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 524
lxcf09a10eb6402(12) clsact/ingress cil_from_container-lxcf09a10eb6402 id 534
lxcceb272541274(14) clsact/ingress cil_from_container-lxcceb272541274 id 513
lxcc426a3b08cf2(18) clsact/ingress cil_from_container-lxcc426a3b08cf2 id 631

flow_dissector:

netfilter:

