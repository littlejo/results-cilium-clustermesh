1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:a4:3f:83:40:43 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.250.1/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2746sec preferred_lft 2746sec
    inet6 fe80::8a4:3fff:fe83:4043/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:ea:7f:ef:89:3d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.220.94/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8ea:7fff:feef:893d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:76:80:df:42:ac brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d076:80ff:fedf:42ac/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:95:1b:dc:8d:fc brd ff:ff:ff:ff:ff:ff
    inet 10.93.0.125/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::95:1bff:fedc:8dfc/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 8e:e8:ba:e4:db:c2 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8ce8:baff:fee4:dbc2/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:63:de:83:1a:78 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::8063:deff:fe83:1a78/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf09a10eb6402@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:18:a7:bb:fa:cf brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::e418:a7ff:febb:facf/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcceb272541274@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:62:f9:98:1c:e3 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::7062:f9ff:fe98:1ce3/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcc426a3b08cf2@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:cc:2e:c8:48:9a brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::28cc:2eff:fec8:489a/64 scope link 
       valid_lft forever preferred_lft forever
