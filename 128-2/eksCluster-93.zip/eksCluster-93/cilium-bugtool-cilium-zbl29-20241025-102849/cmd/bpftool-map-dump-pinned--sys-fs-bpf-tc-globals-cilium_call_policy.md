key: 71 05 00 00  value: fe 01 00 00
key: e8 08 00 00  value: 1d 02 00 00
key: 7a 0a 00 00  value: 0e 02 00 00
key: 6d 0e 00 00  value: 72 02 00 00
Found 4 elements
