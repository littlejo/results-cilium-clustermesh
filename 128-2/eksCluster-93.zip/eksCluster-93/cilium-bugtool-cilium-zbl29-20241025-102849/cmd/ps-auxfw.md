USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         652  0.0  0.1 1419400 3932 ?        Rsl  10:28   0:00 /usr/sbin/runc init
root         639  0.0  0.0      0     0 ?        Zs   10:28   0:00 [gops] <defunct>
root         632  0.0  0.0      0     0 ?        Zs   10:28   0:00 [gops] <defunct>
root         606  0.0  0.4 1240432 16520 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         650  0.0  0.0   3852  1288 ?        R    10:28   0:00  \_ bash -c cat /proc/net/xfrm_stat
root         651  0.0  0.0   6408  1648 ?        R    10:28   0:00  \_ ps auxfw
root           1  3.0  7.0 1538164 278376 ?      Ssl  10:15   0:23 cilium-agent --config-dir=/tmp/cilium/config-map
root         404  0.0  0.1 1228848 5788 ?        Sl   10:16   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
