ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.181.85:443 (active)    
                                          2 => 172.31.205.225:443 (active)   
2    10.100.204.59:443     ClusterIP      1 => 172.31.250.1:4244 (active)    
3    10.100.0.10:53        ClusterIP      1 => 10.93.0.49:53 (active)        
                                          2 => 10.93.0.99:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.93.0.49:9153 (active)      
                                          2 => 10.93.0.99:9153 (active)      
5    10.100.116.117:2379   ClusterIP      1 => 10.93.0.42:2379 (active)      
