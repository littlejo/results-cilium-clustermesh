Endpoint ID: 1393
Path: /sys/fs/bpf/tc/globals/cilium_policy_01393

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    286313   2577      0        
Allow    Ingress     1          ANY          NONE         disabled    73063    837       0        
Allow    Egress      0          ANY          NONE         disabled    64417    614       0        


Endpoint ID: 2249
Path: /sys/fs/bpf/tc/globals/cilium_policy_02249

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2280
Path: /sys/fs/bpf/tc/globals/cilium_policy_02280

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    278469   2513      0        
Allow    Ingress     1          ANY          NONE         disabled    73459    843       0        
Allow    Egress      0          ANY          NONE         disabled    62782    599       0        


Endpoint ID: 2682
Path: /sys/fs/bpf/tc/globals/cilium_policy_02682

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    442874   5667      0        
Allow    Ingress     1          ANY          NONE         disabled    10934    127       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3693
Path: /sys/fs/bpf/tc/globals/cilium_policy_03693

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3910628   36160     0        
Allow    Ingress     1          ANY          NONE         disabled    2912466   29324     0        
Allow    Egress      0          ANY          NONE         disabled    3877118   36427     0        


