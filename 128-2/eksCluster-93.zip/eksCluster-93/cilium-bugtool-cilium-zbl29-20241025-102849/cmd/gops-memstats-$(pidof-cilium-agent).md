alloc: 111.85MB (117282584 bytes)
total-alloc: 1.35GB (1445910824 bytes)
sys: 206.45MB (216474964 bytes)
lookups: 0
mallocs: 48251652
frees: 47014353
heap-alloc: 111.85MB (117282584 bytes)
heap-sys: 161.45MB (169287680 bytes)
heap-idle: 33.77MB (35405824 bytes)
heap-in-use: 127.68MB (133881856 bytes)
heap-released: 2.31MB (2424832 bytes)
heap-objects: 1237299
stack-in-use: 34.53MB (36208640 bytes)
stack-sys: 34.53MB (36208640 bytes)
stack-mspan-inuse: 2.13MB (2234080 bytes)
stack-mspan-sys: 2.40MB (2513280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 988.92KB (1012649 bytes)
gc-sys: 5.19MB (5443720 bytes)
next-gc: when heap-alloc >= 146.96MB (154103080 bytes)
last-gc: 2024-10-25 10:28:52.50594695 +0000 UTC
gc-pause-total: 13.723214ms
gc-pause: 83562
gc-pause-end: 1729852132505946950
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0004081666599747489
enable-gc: true
debug-gc: false
