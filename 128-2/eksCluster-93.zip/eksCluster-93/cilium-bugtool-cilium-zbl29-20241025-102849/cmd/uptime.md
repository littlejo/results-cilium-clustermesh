 10:28:51 up 14 min,  0 users,  load average: 0.14, 0.33, 0.26
