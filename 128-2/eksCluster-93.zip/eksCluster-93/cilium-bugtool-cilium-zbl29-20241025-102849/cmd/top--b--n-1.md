top - 10:28:51 up 14 min,  0 users,  load average: 0.14, 0.33, 0.26
Tasks:   7 total,   2 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s):  6.9 us, 34.5 sy,  0.0 ni, 58.6 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    799.8 free,    895.3 used,   2141.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2771.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    606 root      20   0 1240432  16520  11292 S   6.7   0.4   0:00.03 cilium-+
      1 root      20   0 1538164 278376  78012 S   0.0   7.1   0:23.48 cilium-+
    404 root      20   0 1228848   5788   2928 S   0.0   0.1   0:00.28 cilium-+
    667 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    678 root      20   0    6576   2424   2096 R   0.0   0.1   0:00.00 top
    696 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    701 root      20   0   13060   1228     60 R   0.0   0.0   0:00.00 runc:[1+
