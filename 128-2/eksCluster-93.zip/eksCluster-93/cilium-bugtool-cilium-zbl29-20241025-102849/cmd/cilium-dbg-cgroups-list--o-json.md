[
  {
    "containers": [
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7bba53f6_d471_421e_9fad_c205cbe12b46.slice/cri-containerd-5a5c3507c82140a85ef6f8da21307befd35bb35d2fb4e118a5d35aaceca09dcf.scope"
      },
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7bba53f6_d471_421e_9fad_c205cbe12b46.slice/cri-containerd-840a589ced5005116aa1c840c66fd23e4a538043f8478a066a814f9ca2014756.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7bba53f6_d471_421e_9fad_c205cbe12b46.slice/cri-containerd-8be728f25b1073c3ce511a260a03fc325794688e08abd076cd2725556f7f9017.scope"
      }
    ],
    "ips": [
      "10.93.0.42"
    ],
    "name": "clustermesh-apiserver-5d89f7744c-vwk9r",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5ad83968_7d8d_401e_a9ff_4975d89da3be.slice/cri-containerd-29e53e9298f5db911634b18e79e205601d90807618d84d91e81d985b0474a9b3.scope"
      }
    ],
    "ips": [
      "10.93.0.99"
    ],
    "name": "coredns-cc6ccd49c-sq7jc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod748f8648_1987_4552_ad12_dd95319a93ee.slice/cri-containerd-c25ea15d898a4408012ffa09889d14be12a8b22ba85a58bb1f99c7b6300f44a3.scope"
      }
    ],
    "ips": [
      "10.93.0.49"
    ],
    "name": "coredns-cc6ccd49c-gr9rn",
    "namespace": "kube-system"
  }
]

