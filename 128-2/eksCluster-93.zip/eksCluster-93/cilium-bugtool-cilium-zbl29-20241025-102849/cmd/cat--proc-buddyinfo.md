Node 0, zone      DMA     67     39     11      6      7      4      7      3      2      3    166 
Node 0, zone   Normal    892    198     55     27     26     14      3      4      3      5      4 
