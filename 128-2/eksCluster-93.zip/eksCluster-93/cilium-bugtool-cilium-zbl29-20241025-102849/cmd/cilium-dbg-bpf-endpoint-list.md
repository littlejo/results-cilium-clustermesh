IP ADDRESS        LOCAL ENDPOINT INFO
10.93.0.125:0     (localhost)                                                                                        
10.93.0.49:0      id=2280  sec_id=6215900 flags=0x0000 ifindex=12  mac=6E:B5:C7:CD:8C:D9 nodemac=E6:18:A7:BB:FA:CF   
172.31.220.94:0   (localhost)                                                                                        
10.93.0.99:0      id=1393  sec_id=6215900 flags=0x0000 ifindex=14  mac=86:E8:A2:59:C8:00 nodemac=72:62:F9:98:1C:E3   
10.93.0.42:0      id=3693  sec_id=6163463 flags=0x0000 ifindex=18  mac=DE:BF:75:76:3D:27 nodemac=2A:CC:2E:C8:48:9A   
10.93.0.4:0       id=2682  sec_id=4     flags=0x0000 ifindex=10  mac=6E:4C:70:CC:E1:4B nodemac=82:63:DE:83:1A:78     
172.31.250.1:0    (localhost)                                                                                        
