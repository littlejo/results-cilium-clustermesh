KEY             VALUE
AgentLiveness   894925909563
UTimeOffset     3378615755859375
