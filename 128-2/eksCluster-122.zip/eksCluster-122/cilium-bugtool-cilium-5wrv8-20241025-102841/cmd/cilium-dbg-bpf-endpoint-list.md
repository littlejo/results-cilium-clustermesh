IP ADDRESS         LOCAL ENDPOINT INFO
10.122.0.114:0     id=3068  sec_id=8075225 flags=0x0000 ifindex=14  mac=CE:5F:DB:94:53:5D nodemac=36:D7:B1:DF:27:B5   
10.122.0.103:0     (localhost)                                                                                        
172.31.144.245:0   (localhost)                                                                                        
10.122.0.83:0      id=587   sec_id=8080194 flags=0x0000 ifindex=18  mac=C2:CE:99:A8:D8:C1 nodemac=22:FF:07:F0:DD:07   
10.122.0.37:0      id=410   sec_id=4     flags=0x0000 ifindex=10  mac=F2:CE:8D:21:1E:05 nodemac=6E:C8:9F:CD:CB:A7     
10.122.0.232:0     id=239   sec_id=8075225 flags=0x0000 ifindex=12  mac=76:7C:4F:D5:03:BC nodemac=7E:01:DC:86:05:65   
172.31.172.198:0   (localhost)                                                                                        
