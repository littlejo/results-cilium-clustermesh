Node 0, zone      DMA    162     49      3      0      1      2      4      1      1      3    166 
Node 0, zone   Normal    159     35     31     38     15     10      3      1      2      3      7 
