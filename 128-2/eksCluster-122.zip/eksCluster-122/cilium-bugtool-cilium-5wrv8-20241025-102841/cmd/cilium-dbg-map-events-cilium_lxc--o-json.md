{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:50.328Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.144.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:50.328Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.172.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:50.328Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:56.218Z",
  "value": "id=3068  sec_id=8075225 flags=0x0000 ifindex=14  mac=CE:5F:DB:94:53:5D nodemac=36:D7:B1:DF:27:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:56.222Z",
  "value": "id=410   sec_id=4     flags=0x0000 ifindex=10  mac=F2:CE:8D:21:1E:05 nodemac=6E:C8:9F:CD:CB:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:56.304Z",
  "value": "id=239   sec_id=8075225 flags=0x0000 ifindex=12  mac=76:7C:4F:D5:03:BC nodemac=7E:01:DC:86:05:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:56.406Z",
  "value": "id=3068  sec_id=8075225 flags=0x0000 ifindex=14  mac=CE:5F:DB:94:53:5D nodemac=36:D7:B1:DF:27:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:56.496Z",
  "value": "id=410   sec_id=4     flags=0x0000 ifindex=10  mac=F2:CE:8D:21:1E:05 nodemac=6E:C8:9F:CD:CB:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:30.430Z",
  "value": "id=410   sec_id=4     flags=0x0000 ifindex=10  mac=F2:CE:8D:21:1E:05 nodemac=6E:C8:9F:CD:CB:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:30.430Z",
  "value": "id=3068  sec_id=8075225 flags=0x0000 ifindex=14  mac=CE:5F:DB:94:53:5D nodemac=36:D7:B1:DF:27:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:30.431Z",
  "value": "id=239   sec_id=8075225 flags=0x0000 ifindex=12  mac=76:7C:4F:D5:03:BC nodemac=7E:01:DC:86:05:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:30.461Z",
  "value": "id=396   sec_id=8080194 flags=0x0000 ifindex=16  mac=8E:4F:05:76:13:DB nodemac=FA:AB:99:54:2A:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:31.431Z",
  "value": "id=396   sec_id=8080194 flags=0x0000 ifindex=16  mac=8E:4F:05:76:13:DB nodemac=FA:AB:99:54:2A:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:31.431Z",
  "value": "id=410   sec_id=4     flags=0x0000 ifindex=10  mac=F2:CE:8D:21:1E:05 nodemac=6E:C8:9F:CD:CB:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:31.432Z",
  "value": "id=3068  sec_id=8075225 flags=0x0000 ifindex=14  mac=CE:5F:DB:94:53:5D nodemac=36:D7:B1:DF:27:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:31.432Z",
  "value": "id=239   sec_id=8075225 flags=0x0000 ifindex=12  mac=76:7C:4F:D5:03:BC nodemac=7E:01:DC:86:05:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.062Z",
  "value": "id=587   sec_id=8080194 flags=0x0000 ifindex=18  mac=C2:CE:99:A8:D8:C1 nodemac=22:FF:07:F0:DD:07"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.122.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:06.853Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:39.976Z",
  "value": "id=3068  sec_id=8075225 flags=0x0000 ifindex=14  mac=CE:5F:DB:94:53:5D nodemac=36:D7:B1:DF:27:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:39.977Z",
  "value": "id=239   sec_id=8075225 flags=0x0000 ifindex=12  mac=76:7C:4F:D5:03:BC nodemac=7E:01:DC:86:05:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:39.977Z",
  "value": "id=587   sec_id=8080194 flags=0x0000 ifindex=18  mac=C2:CE:99:A8:D8:C1 nodemac=22:FF:07:F0:DD:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:39.978Z",
  "value": "id=410   sec_id=4     flags=0x0000 ifindex=10  mac=F2:CE:8D:21:1E:05 nodemac=6E:C8:9F:CD:CB:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:40.976Z",
  "value": "id=3068  sec_id=8075225 flags=0x0000 ifindex=14  mac=CE:5F:DB:94:53:5D nodemac=36:D7:B1:DF:27:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:40.977Z",
  "value": "id=410   sec_id=4     flags=0x0000 ifindex=10  mac=F2:CE:8D:21:1E:05 nodemac=6E:C8:9F:CD:CB:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:40.977Z",
  "value": "id=239   sec_id=8075225 flags=0x0000 ifindex=12  mac=76:7C:4F:D5:03:BC nodemac=7E:01:DC:86:05:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:40.977Z",
  "value": "id=587   sec_id=8080194 flags=0x0000 ifindex=18  mac=C2:CE:99:A8:D8:C1 nodemac=22:FF:07:F0:DD:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:41.977Z",
  "value": "id=587   sec_id=8080194 flags=0x0000 ifindex=18  mac=C2:CE:99:A8:D8:C1 nodemac=22:FF:07:F0:DD:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:41.977Z",
  "value": "id=410   sec_id=4     flags=0x0000 ifindex=10  mac=F2:CE:8D:21:1E:05 nodemac=6E:C8:9F:CD:CB:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:41.977Z",
  "value": "id=3068  sec_id=8075225 flags=0x0000 ifindex=14  mac=CE:5F:DB:94:53:5D nodemac=36:D7:B1:DF:27:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.122.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:41.978Z",
  "value": "id=239   sec_id=8075225 flags=0x0000 ifindex=12  mac=76:7C:4F:D5:03:BC nodemac=7E:01:DC:86:05:65"
}

