REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10032     786514     677    bpf_overlay.c
Interface                 INGRESS     220407    85062665   1132   bpf_host.c
Success                   EGRESS      10224     800844     53     encap.h
Success                   EGRESS      5161      397900     1694   bpf_host.c
Success                   EGRESS      93083     12484742   1308   bpf_lxc.c
Success                   INGRESS     104002    12800424   86     l3.h
Success                   INGRESS     109521    13232874   235    trace.h
Unsupported L3 protocol   EGRESS      35        2586       1492   bpf_lxc.c
