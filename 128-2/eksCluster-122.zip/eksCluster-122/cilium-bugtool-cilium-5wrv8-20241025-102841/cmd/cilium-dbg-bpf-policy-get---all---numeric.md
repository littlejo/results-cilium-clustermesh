Endpoint ID: 239
Path: /sys/fs/bpf/tc/globals/cilium_policy_00239

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    75990   873       0        
Allow    Egress      0          ANY          NONE         disabled    12419   127       0        


Endpoint ID: 410
Path: /sys/fs/bpf/tc/globals/cilium_policy_00410

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    433446   5531      0        
Allow    Ingress     1          ANY          NONE         disabled    11588    136       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 587
Path: /sys/fs/bpf/tc/globals/cilium_policy_00587

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3910273   36837     0        
Allow    Ingress     1          ANY          NONE         disabled    3141821   31696     0        
Allow    Egress      0          ANY          NONE         disabled    4661504   43003     0        


Endpoint ID: 2703
Path: /sys/fs/bpf/tc/globals/cilium_policy_02703

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3068
Path: /sys/fs/bpf/tc/globals/cilium_policy_03068

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    76034   872       0        
Allow    Egress      0          ANY          NONE         disabled    13138   135       0        


