1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:78:f7:07:2d:7b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.144.245/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2741sec preferred_lft 2741sec
    inet6 fe80::478:f7ff:fe07:2d7b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ad:72:dc:34:75 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.172.198/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4ad:72ff:fedc:3475/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:53:3d:5e:0e:bb brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4853:3dff:fe5e:ebb/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:a1:34:fd:1a:60 brd ff:ff:ff:ff:ff:ff
    inet 10.122.0.103/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::2ca1:34ff:fefd:1a60/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 32:15:37:68:d0:11 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3015:37ff:fe68:d011/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:c8:9f:cd:cb:a7 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::6cc8:9fff:fecd:cba7/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc2db630fe0bc2@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:01:dc:86:05:65 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::7c01:dcff:fe86:565/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc1893b1e7328b@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:d7:b1:df:27:b5 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::34d7:b1ff:fedf:27b5/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcacecd1d62588@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:ff:07:f0:dd:07 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::20ff:7ff:fef0:dd07/64 scope link 
       valid_lft forever preferred_lft forever
