 10:28:42 up 14 min,  0 users,  load average: 0.04, 0.19, 0.18
