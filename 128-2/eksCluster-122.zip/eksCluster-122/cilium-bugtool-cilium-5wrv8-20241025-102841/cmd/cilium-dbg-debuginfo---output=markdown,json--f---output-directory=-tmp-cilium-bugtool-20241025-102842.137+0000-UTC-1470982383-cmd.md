markdown output at /tmp/cilium-bugtool-20241025-102842.137+0000-UTC-1470982383/cmd/cilium-debuginfo-20241025-102912.685+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102842.137+0000-UTC-1470982383/cmd/cilium-debuginfo-20241025-102912.685+0000-UTC.json
