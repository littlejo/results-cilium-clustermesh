[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf5c79e4d_d7ea_4369_99eb_134686b1ac9f.slice/cri-containerd-35deb4cec0b2226a808d46c4bbb257dc52538c01b83e4784d458174a3118f3e0.scope"
      }
    ],
    "ips": [
      "10.122.0.232"
    ],
    "name": "coredns-cc6ccd49c-pdbb8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod209e13a9_16c9_4bb1_9981_b137e41fc554.slice/cri-containerd-6e37cc1991abadb7f49e12d23d75a9ba0f2aa599b50067c5f2d2a0f431e5361b.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod209e13a9_16c9_4bb1_9981_b137e41fc554.slice/cri-containerd-6c3e7b5a4e7614922746aeac491f2bab3e06f3bd0ae46eb8d9bca01b4aad7341.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod209e13a9_16c9_4bb1_9981_b137e41fc554.slice/cri-containerd-b207f7828dec7df65e34d4b3824a7234b21c8a4654f399a06edebb7e5de1cac9.scope"
      }
    ],
    "ips": [
      "10.122.0.83"
    ],
    "name": "clustermesh-apiserver-679685866b-chrkh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda95a1607_87de_4ef1_bce4_9acaec3c8db5.slice/cri-containerd-9484d209e239760fbfc4335094dcdc1615091f5033986e2d52d8379a05c6f440.scope"
      }
    ],
    "ips": [
      "10.122.0.114"
    ],
    "name": "coredns-cc6ccd49c-68fdg",
    "namespace": "kube-system"
  }
]

