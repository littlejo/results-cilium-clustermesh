top - 10:28:42 up 14 min,  0 users,  load average: 0.04, 0.19, 0.18
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 10.0 us, 20.0 sy,  0.0 ni, 70.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    784.1 free,    909.7 used,   2142.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2757.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    680 root      20   0 1240432  15840  10832 S   6.7   0.4   0:00.03 cilium-+
      1 root      20   0 1538100 280248  78096 S   0.0   7.1   0:22.33 cilium-+
    396 root      20   0 1228848   5784   2872 S   0.0   0.1   0:00.26 cilium-+
    633 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    646 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
    653 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    674 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    710 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    728 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
