KEY             VALUE
AgentLiveness   899885466735
UTimeOffset     3378615728515625
