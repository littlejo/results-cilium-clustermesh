filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc2db630fe0bc2 direct-action not_in_hw id 504 tag 9dcb70ee9fa49191 jited 
