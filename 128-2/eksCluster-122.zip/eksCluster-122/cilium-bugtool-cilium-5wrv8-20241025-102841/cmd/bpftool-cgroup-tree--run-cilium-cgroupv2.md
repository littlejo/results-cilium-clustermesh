CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ba7c4fd_3e8c_40a5_a4f0_80c3755a17ce.slice/cri-containerd-0877a5a90189b2e1034d56585d5be954f8de3d2aaf23202b3420dc5a35681507.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ba7c4fd_3e8c_40a5_a4f0_80c3755a17ce.slice/cri-containerd-a152cda17f8fa90b26e7938fccbe9b65baeb01a33ee0a3f4a527903a92a46cf6.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda95a1607_87de_4ef1_bce4_9acaec3c8db5.slice/cri-containerd-6c1e9a3eeedd344c0c43673f29d994575c0b6dead4a3b046f6be7a6f7a291c60.scope
    522      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda95a1607_87de_4ef1_bce4_9acaec3c8db5.slice/cri-containerd-9484d209e239760fbfc4335094dcdc1615091f5033986e2d52d8379a05c6f440.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0c0c930b_5460_4a8d_b4f2_520bf2c0c8f3.slice/cri-containerd-bb00333d58064b4b2f6ddf777ccc652618c00935458e6842a9404afb04c3a930.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0c0c930b_5460_4a8d_b4f2_520bf2c0c8f3.slice/cri-containerd-0dee1786f78584ab42eea5b13a4b357c8f45204ffdf0f422fe26c1f0cbeb4787.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf5c79e4d_d7ea_4369_99eb_134686b1ac9f.slice/cri-containerd-35deb4cec0b2226a808d46c4bbb257dc52538c01b83e4784d458174a3118f3e0.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf5c79e4d_d7ea_4369_99eb_134686b1ac9f.slice/cri-containerd-c180781b2468bef2d198a50fa58bff6c0ca1ac38f5bb37acf38c7f1b9c0589d3.scope
    533      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod209e13a9_16c9_4bb1_9981_b137e41fc554.slice/cri-containerd-6c3e7b5a4e7614922746aeac491f2bab3e06f3bd0ae46eb8d9bca01b4aad7341.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod209e13a9_16c9_4bb1_9981_b137e41fc554.slice/cri-containerd-b207f7828dec7df65e34d4b3824a7234b21c8a4654f399a06edebb7e5de1cac9.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod209e13a9_16c9_4bb1_9981_b137e41fc554.slice/cri-containerd-b0d1dbec1c56064c19d44a3599b2b712bcba61cd355660e37725b337c8ad4cf2.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod209e13a9_16c9_4bb1_9981_b137e41fc554.slice/cri-containerd-6e37cc1991abadb7f49e12d23d75a9ba0f2aa599b50067c5f2d2a0f431e5361b.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29c67dc0_0697_450a_bb8d_39b2435406f6.slice/cri-containerd-1f95dd76109380158cf734e3b9c6d2e9436f66c17cd6353f075bd8ad3759a02f.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29c67dc0_0697_450a_bb8d_39b2435406f6.slice/cri-containerd-c5a1b2316d6d2bc6c6c4d470491af3da24a75151bec468f0f89a46354c420ea2.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40dce4c9_4488_4495_9e24_b76c2c87512d.slice/cri-containerd-68f7bfc3028c9c5f493fb13a8b170e312ee4a766109b81abf538fe1b36f3699f.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40dce4c9_4488_4495_9e24_b76c2c87512d.slice/cri-containerd-ecd012a68ab3cb4cdf683be657db93121e1d2c33542ece396aa3f1ce09c7258d.scope
    99       cgroup_device   multi                                          
