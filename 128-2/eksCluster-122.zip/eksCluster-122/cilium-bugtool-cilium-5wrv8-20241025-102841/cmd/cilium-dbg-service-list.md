ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.129.17:443 (active)     
                                          2 => 172.31.246.106:443 (active)    
2    10.100.225.118:443    ClusterIP      1 => 172.31.144.245:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.122.0.232:53 (active)       
                                          2 => 10.122.0.114:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.122.0.232:9153 (active)     
                                          2 => 10.122.0.114:9153 (active)     
5    10.100.150.222:2379   ClusterIP      1 => 10.122.0.83:2379 (active)      
