alloc: 121.89MB (127806784 bytes)
total-alloc: 1.34GB (1442830296 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 47982126
frees: 46742471
heap-alloc: 121.89MB (127806784 bytes)
heap-sys: 165.02MB (173031424 bytes)
heap-idle: 24.65MB (25845760 bytes)
heap-in-use: 140.37MB (147185664 bytes)
heap-released: 600.00KB (614400 bytes)
heap-objects: 1239655
stack-in-use: 34.66MB (36339712 bytes)
stack-sys: 34.66MB (36339712 bytes)
stack-mspan-inuse: 2.19MB (2296640 bytes)
stack-mspan-sys: 2.44MB (2562240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 921.76KB (943881 bytes)
gc-sys: 5.46MB (5726464 bytes)
next-gc: when heap-alloc >= 146.33MB (153438264 bytes)
last-gc: 2024-10-25 10:28:44.39793869 +0000 UTC
gc-pause-total: 20.502718ms
gc-pause: 2187348
gc-pause-end: 1729852124397938690
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0003858767363556935
enable-gc: true
debug-gc: false
