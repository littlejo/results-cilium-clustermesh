USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         680  0.0  0.4 1240432 15840 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         698  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         700  0.0  0.0      0     0 ?        R    10:28   0:00  \_ [hostname]
root         674  0.0  0.1 1229000 4052 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         653  0.0  0.1 1228744 4040 ?        Ssl  10:28   0:00 /bin/gops stack 1
root         646  0.0  0.1 1228744 4044 ?        Ssl  10:28   0:00 /bin/gops memstats 1
root         633  0.0  0.1 1228744 4036 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  2.8  7.1 1538100 280248 ?      Ssl  10:15   0:22 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.0  0.1 1228848 5784 ?        Sl   10:15   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
