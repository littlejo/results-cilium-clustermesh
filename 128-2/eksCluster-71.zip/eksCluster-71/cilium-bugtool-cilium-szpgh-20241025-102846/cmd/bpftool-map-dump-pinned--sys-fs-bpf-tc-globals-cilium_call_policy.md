key: cb 00 00 00  value: 70 02 00 00
key: a9 01 00 00  value: 0e 02 00 00
key: fc 08 00 00  value: 3b 02 00 00
key: e8 0c 00 00  value: 1a 02 00 00
Found 4 elements
