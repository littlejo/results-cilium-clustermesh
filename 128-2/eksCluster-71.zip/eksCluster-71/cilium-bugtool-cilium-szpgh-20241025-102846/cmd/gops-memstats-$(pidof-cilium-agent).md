alloc: 121.25MB (127136992 bytes)
total-alloc: 1.35GB (1447822880 bytes)
sys: 202.32MB (212146500 bytes)
lookups: 0
mallocs: 48082613
frees: 46799814
heap-alloc: 121.25MB (127136992 bytes)
heap-sys: 157.23MB (164872192 bytes)
heap-idle: 18.10MB (18980864 bytes)
heap-in-use: 139.13MB (145891328 bytes)
heap-released: 3.38MB (3538944 bytes)
heap-objects: 1282799
stack-in-use: 34.72MB (36405248 bytes)
stack-sys: 34.72MB (36405248 bytes)
stack-mspan-inuse: 2.26MB (2372320 bytes)
stack-mspan-sys: 2.41MB (2529600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 977.76KB (1001225 bytes)
gc-sys: 5.08MB (5321824 bytes)
next-gc: when heap-alloc >= 147.12MB (154265064 bytes)
last-gc: 2024-10-25 10:28:49.201750571 +0000 UTC
gc-pause-total: 11.117215ms
gc-pause: 203700
gc-pause-end: 1729852129201750571
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.00040039501717911995
enable-gc: true
debug-gc: false
