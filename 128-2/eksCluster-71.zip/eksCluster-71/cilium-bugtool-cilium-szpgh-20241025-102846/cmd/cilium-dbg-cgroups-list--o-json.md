[
  {
    "containers": [
      {
        "cgroup-id": 8118,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcdce7c42_2986_4a28_a816_1ebf2c68215c.slice/cri-containerd-c3c1ebed95968fc51584343bb02fe56c2a4bc91a34fa5d70bb216d915f9fbfe6.scope"
      }
    ],
    "ips": [
      "10.71.0.52"
    ],
    "name": "coredns-cc6ccd49c-wftlb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcce2abb7_9817_459e_912a_eaa27ef95df3.slice/cri-containerd-f49ff13940a6529b923935e3e50fb47973c07b9189bf34342524a62d2407795f.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcce2abb7_9817_459e_912a_eaa27ef95df3.slice/cri-containerd-7246bcc8a20101e1300a60cf0029dc599b0d47da92414c3a9bcf577cef8ff27d.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcce2abb7_9817_459e_912a_eaa27ef95df3.slice/cri-containerd-0280c50a89869c6ee49e1bd7381aa3e72d195186685a3e63fdd42035ea76ff05.scope"
      }
    ],
    "ips": [
      "10.71.0.197"
    ],
    "name": "clustermesh-apiserver-5c656676f9-hbck6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7530,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode24d4b79_0beb_4241_aa91_bba96d52e625.slice/cri-containerd-cd3b26aa27227515ae286b94fd9cc1a793fc1c9202c7cedba0c63017a41bc688.scope"
      }
    ],
    "ips": [
      "10.71.0.176"
    ],
    "name": "coredns-cc6ccd49c-sq98x",
    "namespace": "kube-system"
  }
]

