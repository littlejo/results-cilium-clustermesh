Node 0, zone      DMA      2      8      2     29     10      4     21      7      3      2    167 
Node 0, zone   Normal    154     34     16      1      4     13      6      7      4      1      7 
