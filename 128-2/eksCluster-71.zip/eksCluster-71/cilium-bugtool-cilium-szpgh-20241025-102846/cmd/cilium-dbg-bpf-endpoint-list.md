IP ADDRESS         LOCAL ENDPOINT INFO
172.31.207.233:0   (localhost)                                                                                        
10.71.0.214:0      (localhost)                                                                                        
10.71.0.197:0      id=203   sec_id=4719313 flags=0x0000 ifindex=18  mac=AE:77:FD:94:9B:A5 nodemac=E2:E6:1D:01:3D:18   
10.71.0.52:0       id=2300  sec_id=4750488 flags=0x0000 ifindex=14  mac=1A:96:E5:2B:AE:17 nodemac=6A:33:0B:4B:9A:EB   
10.71.0.183:0      id=3304  sec_id=4     flags=0x0000 ifindex=10  mac=AA:D0:5F:9A:41:6C nodemac=82:3F:09:F2:E2:BE     
10.71.0.176:0      id=425   sec_id=4750488 flags=0x0000 ifindex=12  mac=32:9E:99:CA:D9:AF nodemac=CA:90:9C:F7:38:52   
172.31.244.208:0   (localhost)                                                                                        
