Endpoint ID: 203
Path: /sys/fs/bpf/tc/globals/cilium_policy_00203

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3895090   36816     0        
Allow    Ingress     1          ANY          NONE         disabled    3281486   33357     0        
Allow    Egress      0          ANY          NONE         disabled    4775802   44183     0        


Endpoint ID: 425
Path: /sys/fs/bpf/tc/globals/cilium_policy_00425

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    67809   780       0        
Allow    Egress      0          ANY          NONE         disabled    12528   128       0        


Endpoint ID: 647
Path: /sys/fs/bpf/tc/globals/cilium_policy_00647

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2300
Path: /sys/fs/bpf/tc/globals/cilium_policy_02300

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    67092   773       0        
Allow    Egress      0          ANY          NONE         disabled    12747   130       0        


Endpoint ID: 3304
Path: /sys/fs/bpf/tc/globals/cilium_policy_03304

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    443046   5657      0        
Allow    Ingress     1          ANY          NONE         disabled    9734     111       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


