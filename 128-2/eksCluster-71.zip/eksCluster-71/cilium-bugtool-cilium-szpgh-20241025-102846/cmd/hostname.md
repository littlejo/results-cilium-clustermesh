ip-172-31-244-208.eu-west-3.compute.internal
