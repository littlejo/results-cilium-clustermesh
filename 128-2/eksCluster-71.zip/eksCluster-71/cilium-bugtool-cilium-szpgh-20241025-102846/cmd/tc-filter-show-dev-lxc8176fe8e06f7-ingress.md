filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc8176fe8e06f7 direct-action not_in_hw id 527 tag cc35eeb4e27a487e jited 
