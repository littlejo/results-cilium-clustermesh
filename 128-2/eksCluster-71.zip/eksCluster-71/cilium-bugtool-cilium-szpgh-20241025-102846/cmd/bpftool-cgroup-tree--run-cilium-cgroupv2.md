CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod336985eb_65c6_427e_8e86_650f561efa70.slice/cri-containerd-8d5306d1dfa966cb6f8ff5d15ecfa1f381680d3a7196f971ec1d8e2f404f58ef.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod336985eb_65c6_427e_8e86_650f561efa70.slice/cri-containerd-001d15c58d9e8e1efc248d6334d50d640551bb3908e0f1f7420ecb476296ec6d.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6f9fc148_7807_4a30_a059_80f026ac2478.slice/cri-containerd-2f354a6427b88b7537cbc6c8353c1df43d4276f03d8c5070f57dcbf9604baf1b.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6f9fc148_7807_4a30_a059_80f026ac2478.slice/cri-containerd-f64ab3d4d3727f6175da45fc2a67df4a79d751055315be0fd8b01d43a9e73b92.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode24d4b79_0beb_4241_aa91_bba96d52e625.slice/cri-containerd-cd3b26aa27227515ae286b94fd9cc1a793fc1c9202c7cedba0c63017a41bc688.scope
    556      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode24d4b79_0beb_4241_aa91_bba96d52e625.slice/cri-containerd-30a467c5199aa86ad21960872efa0490457e873c77079e4a80bc2193473bb00b.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcdce7c42_2986_4a28_a816_1ebf2c68215c.slice/cri-containerd-a288d70476185163f90dfa14a3cae2781af18de01e37d8829517b7805585ce26.scope
    579      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcdce7c42_2986_4a28_a816_1ebf2c68215c.slice/cri-containerd-c3c1ebed95968fc51584343bb02fe56c2a4bc91a34fa5d70bb216d915f9fbfe6.scope
    583      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod013a598f_c5d4_4243_912b_26558cce35c1.slice/cri-containerd-065975aed9d932095b46840b2ede9f9972baef1aec5c7cd0e4b242540122573c.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod013a598f_c5d4_4243_912b_26558cce35c1.slice/cri-containerd-daab5814540dd07aeffc8cfae185bab821a94084c374bad5edaac0b91de064f3.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcce2abb7_9817_459e_912a_eaa27ef95df3.slice/cri-containerd-f49ff13940a6529b923935e3e50fb47973c07b9189bf34342524a62d2407795f.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcce2abb7_9817_459e_912a_eaa27ef95df3.slice/cri-containerd-0280c50a89869c6ee49e1bd7381aa3e72d195186685a3e63fdd42035ea76ff05.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcce2abb7_9817_459e_912a_eaa27ef95df3.slice/cri-containerd-14fc17640615f8dd48395129521688c025d93fafb07269cb9add1ccdc3a641ea.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcce2abb7_9817_459e_912a_eaa27ef95df3.slice/cri-containerd-7246bcc8a20101e1300a60cf0029dc599b0d47da92414c3a9bcf577cef8ff27d.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab890c95_79a4_487b_a977_bbe62f37e90b.slice/cri-containerd-54c9ebc8581df477812f50cced23dd4f984a45be053cd7e9d007c0c7ac9f68ac.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab890c95_79a4_487b_a977_bbe62f37e90b.slice/cri-containerd-86868c95d8c46b6421ae875383ce20ae807744b999f99cde367296dc1f3733e2.scope
    105      cgroup_device   multi                                          
