top - 10:28:48 up 12 min,  0 users,  load average: 0.05, 0.15, 0.15
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s):  7.1 us, 14.3 sy,  0.0 ni, 75.0 id,  0.0 wa,  0.0 hi,  3.6 si,  0.0 st
MiB Mem :   3836.2 total,    792.6 free,    901.4 used,   2142.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2765.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1472496 273052  77632 S   0.0   7.0   0:19.74 cilium-+
    396 root      20   0 1228848   5780   2924 S   0.0   0.1   0:00.24 cilium-+
    642 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    648 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    653 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
    672 root      20   0 1240432  16028  11292 S   0.0   0.4   0:00.01 cilium-+
    698 root      20   0    6576   2432   2104 R   0.0   0.1   0:00.00 top
    716 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
