{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:08.526Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.207.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:08.526Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.244.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:08.526Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:12.713Z",
  "value": "id=425   sec_id=4750488 flags=0x0000 ifindex=12  mac=32:9E:99:CA:D9:AF nodemac=CA:90:9C:F7:38:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:12.714Z",
  "value": "id=425   sec_id=4750488 flags=0x0000 ifindex=12  mac=32:9E:99:CA:D9:AF nodemac=CA:90:9C:F7:38:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:12.746Z",
  "value": "id=3304  sec_id=4     flags=0x0000 ifindex=10  mac=AA:D0:5F:9A:41:6C nodemac=82:3F:09:F2:E2:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:12.793Z",
  "value": "id=3304  sec_id=4     flags=0x0000 ifindex=10  mac=AA:D0:5F:9A:41:6C nodemac=82:3F:09:F2:E2:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:23.178Z",
  "value": "id=2300  sec_id=4750488 flags=0x0000 ifindex=14  mac=1A:96:E5:2B:AE:17 nodemac=6A:33:0B:4B:9A:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:24.439Z",
  "value": "id=3304  sec_id=4     flags=0x0000 ifindex=10  mac=AA:D0:5F:9A:41:6C nodemac=82:3F:09:F2:E2:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:24.439Z",
  "value": "id=425   sec_id=4750488 flags=0x0000 ifindex=12  mac=32:9E:99:CA:D9:AF nodemac=CA:90:9C:F7:38:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:24.440Z",
  "value": "id=2300  sec_id=4750488 flags=0x0000 ifindex=14  mac=1A:96:E5:2B:AE:17 nodemac=6A:33:0B:4B:9A:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:24.471Z",
  "value": "id=517   sec_id=4719313 flags=0x0000 ifindex=16  mac=06:84:7A:36:E8:E8 nodemac=FA:3D:F9:44:73:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:25.440Z",
  "value": "id=425   sec_id=4750488 flags=0x0000 ifindex=12  mac=32:9E:99:CA:D9:AF nodemac=CA:90:9C:F7:38:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:25.440Z",
  "value": "id=2300  sec_id=4750488 flags=0x0000 ifindex=14  mac=1A:96:E5:2B:AE:17 nodemac=6A:33:0B:4B:9A:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:25.440Z",
  "value": "id=517   sec_id=4719313 flags=0x0000 ifindex=16  mac=06:84:7A:36:E8:E8 nodemac=FA:3D:F9:44:73:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:25.441Z",
  "value": "id=3304  sec_id=4     flags=0x0000 ifindex=10  mac=AA:D0:5F:9A:41:6C nodemac=82:3F:09:F2:E2:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:56.407Z",
  "value": "id=203   sec_id=4719313 flags=0x0000 ifindex=18  mac=AE:77:FD:94:9B:A5 nodemac=E2:E6:1D:01:3D:18"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.71.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.312Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:17.702Z",
  "value": "id=203   sec_id=4719313 flags=0x0000 ifindex=18  mac=AE:77:FD:94:9B:A5 nodemac=E2:E6:1D:01:3D:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:17.702Z",
  "value": "id=3304  sec_id=4     flags=0x0000 ifindex=10  mac=AA:D0:5F:9A:41:6C nodemac=82:3F:09:F2:E2:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:17.702Z",
  "value": "id=425   sec_id=4750488 flags=0x0000 ifindex=12  mac=32:9E:99:CA:D9:AF nodemac=CA:90:9C:F7:38:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:17.702Z",
  "value": "id=2300  sec_id=4750488 flags=0x0000 ifindex=14  mac=1A:96:E5:2B:AE:17 nodemac=6A:33:0B:4B:9A:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:18.703Z",
  "value": "id=203   sec_id=4719313 flags=0x0000 ifindex=18  mac=AE:77:FD:94:9B:A5 nodemac=E2:E6:1D:01:3D:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:18.703Z",
  "value": "id=2300  sec_id=4750488 flags=0x0000 ifindex=14  mac=1A:96:E5:2B:AE:17 nodemac=6A:33:0B:4B:9A:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:18.703Z",
  "value": "id=3304  sec_id=4     flags=0x0000 ifindex=10  mac=AA:D0:5F:9A:41:6C nodemac=82:3F:09:F2:E2:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:18.703Z",
  "value": "id=425   sec_id=4750488 flags=0x0000 ifindex=12  mac=32:9E:99:CA:D9:AF nodemac=CA:90:9C:F7:38:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:19.704Z",
  "value": "id=203   sec_id=4719313 flags=0x0000 ifindex=18  mac=AE:77:FD:94:9B:A5 nodemac=E2:E6:1D:01:3D:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:19.704Z",
  "value": "id=3304  sec_id=4     flags=0x0000 ifindex=10  mac=AA:D0:5F:9A:41:6C nodemac=82:3F:09:F2:E2:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:19.705Z",
  "value": "id=425   sec_id=4750488 flags=0x0000 ifindex=12  mac=32:9E:99:CA:D9:AF nodemac=CA:90:9C:F7:38:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:19.705Z",
  "value": "id=2300  sec_id=4750488 flags=0x0000 ifindex=14  mac=1A:96:E5:2B:AE:17 nodemac=6A:33:0B:4B:9A:EB"
}

