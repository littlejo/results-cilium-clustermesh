markdown output at /tmp/cilium-bugtool-20241025-102848.616+0000-UTC-1416231316/cmd/cilium-debuginfo-20241025-102918.92+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102848.616+0000-UTC-1416231316/cmd/cilium-debuginfo-20241025-102918.92+0000-UTC.json
