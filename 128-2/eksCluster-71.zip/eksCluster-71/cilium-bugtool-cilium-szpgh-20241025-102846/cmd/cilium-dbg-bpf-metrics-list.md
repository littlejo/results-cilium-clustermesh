REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10278     803822     677    bpf_overlay.c
Interface                 INGRESS     222989    85753009   1132   bpf_host.c
Success                   EGRESS      10480     818512     53     encap.h
Success                   EGRESS      5303      407244     1694   bpf_host.c
Success                   EGRESS      94227     12581548   1308   bpf_lxc.c
Success                   INGRESS     105341    12931747   86     l3.h
Success                   INGRESS     110965    13372231   235    trace.h
Unsupported L3 protocol   EGRESS      45        3438       1492   bpf_lxc.c
