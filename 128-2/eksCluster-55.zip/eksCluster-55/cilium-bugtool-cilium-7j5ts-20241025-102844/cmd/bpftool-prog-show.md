35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:14:09+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:14:20+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:15:19+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
485: sched_cls  name tail_handle_ipv4  tag 205639ea2f1b2ce3  gpl
	loaded_at 2024-10-25T10:15:19+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
486: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:15:19+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
487: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:15:19+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
510: sched_cls  name tail_handle_ipv4_cont  tag e42a89707a3c3b9b  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,107,41,101,82,83,39,76,74,77,106,40,37,38,81
	btf_id 153
511: sched_cls  name __send_drop_notify  tag df6ac366a9a0724f  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 154
512: sched_cls  name tail_handle_ipv4  tag 21dbedf5a35f2e80  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,106
	btf_id 155
513: sched_cls  name tail_handle_arp  tag b3667962c5080b16  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,106
	btf_id 156
514: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,106,82,83,107,84
	btf_id 157
516: sched_cls  name handle_policy  tag b58ed944783fc64b  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,106,82,83,107,41,80,101,39,84,75,40,37,38
	btf_id 159
517: sched_cls  name cil_from_container  tag 53c3d86b91880137  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 106,76
	btf_id 160
518: sched_cls  name tail_ipv4_ct_ingress  tag 183072729dc65637  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,106,82,83,107,84
	btf_id 161
519: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,106
	btf_id 162
520: sched_cls  name tail_ipv4_to_endpoint  tag 98bb9617ecdb0ba5  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,107,41,82,83,80,101,39,106,40,37,38
	btf_id 163
521: sched_cls  name tail_handle_ipv4  tag da1f1bc3c5179b5a  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,108
	btf_id 165
522: sched_cls  name tail_handle_ipv4_cont  tag cc989ad8095a0c87  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,109,41,100,82,83,39,76,74,77,108,40,37,38,81
	btf_id 166
523: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,108
	btf_id 167
524: sched_cls  name cil_from_container  tag 74dc716b5861dde4  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 108,76
	btf_id 168
525: sched_cls  name tail_ipv4_ct_ingress  tag 7d8a06290709a529  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,109,84
	btf_id 169
526: sched_cls  name __send_drop_notify  tag 3e0060a564eb92d8  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 170
527: sched_cls  name handle_policy  tag fec4e0355f66b787  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,108,82,83,109,41,80,100,39,84,75,40,37,38
	btf_id 171
528: sched_cls  name tail_ipv4_ct_egress  tag eeb06b2109173d6a  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,109,84
	btf_id 172
530: sched_cls  name tail_ipv4_to_endpoint  tag d0f2475829da1318  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,109,41,82,83,80,100,39,108,40,37,38
	btf_id 174
531: sched_cls  name tail_handle_arp  tag eed38ee817a08622  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,108
	btf_id 175
532: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
535: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
536: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
539: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
540: sched_cls  name __send_drop_notify  tag 084fd575228fbd40  gpl
	loaded_at 2024-10-25T10:15:22+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 177
542: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:15:22+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,113
	btf_id 179
544: sched_cls  name tail_handle_ipv4_from_host  tag da18f1a9e4089cc7  gpl
	loaded_at 2024-10-25T10:15:22+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,113
	btf_id 181
545: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:15:22+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 182
546: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:22+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,113
	btf_id 183
547: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:22+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,114
	btf_id 185
548: sched_cls  name __send_drop_notify  tag 084fd575228fbd40  gpl
	loaded_at 2024-10-25T10:15:22+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 186
552: sched_cls  name tail_handle_ipv4_from_host  tag da18f1a9e4089cc7  gpl
	loaded_at 2024-10-25T10:15:22+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,114
	btf_id 190
553: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:15:22+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 191
554: sched_cls  name __send_drop_notify  tag 084fd575228fbd40  gpl
	loaded_at 2024-10-25T10:15:22+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 193
555: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:15:22+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,117,75
	btf_id 194
558: sched_cls  name tail_handle_ipv4_from_host  tag da18f1a9e4089cc7  gpl
	loaded_at 2024-10-25T10:15:22+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 197
560: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:22+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 199
562: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:22+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 202
563: sched_cls  name __send_drop_notify  tag 084fd575228fbd40  gpl
	loaded_at 2024-10-25T10:15:22+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 203
564: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:15:22+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,118,75
	btf_id 204
567: sched_cls  name tail_handle_ipv4_from_host  tag da18f1a9e4089cc7  gpl
	loaded_at 2024-10-25T10:15:22+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 207
568: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,121
	btf_id 209
569: sched_cls  name tail_ipv4_to_endpoint  tag 0825656b36ab5de8  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,122,41,82,83,80,120,39,121,40,37,38
	btf_id 210
570: sched_cls  name __send_drop_notify  tag 7b80d7df8e3e02fb  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 211
571: sched_cls  name cil_from_container  tag 732d24d44b2370e9  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 121,76
	btf_id 212
572: sched_cls  name tail_ipv4_ct_ingress  tag 8e6a55c9e1d34f10  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,121,82,83,122,84
	btf_id 213
573: sched_cls  name handle_policy  tag 56a7323aede158c8  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,121,82,83,122,41,80,120,39,84,75,40,37,38
	btf_id 214
574: sched_cls  name tail_handle_arp  tag ecb1fa3b53ff9063  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,121
	btf_id 215
575: sched_cls  name tail_handle_ipv4_cont  tag 06bbc5ab0709b438  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,122,41,120,82,83,39,76,74,77,121,40,37,38,81
	btf_id 216
576: sched_cls  name tail_handle_ipv4  tag 310284cc3e8f22a7  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,121
	btf_id 217
577: sched_cls  name tail_ipv4_ct_egress  tag eeb06b2109173d6a  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,121,82,83,122,84
	btf_id 218
579: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
582: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
583: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
586: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
626: sched_cls  name cil_from_container  tag 3f30a43ab2ee9301  gpl
	loaded_at 2024-10-25T10:22:40+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 233
627: sched_cls  name handle_policy  tag 95b1d9e747c61d67  gpl
	loaded_at 2024-10-25T10:22:40+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 234
628: sched_cls  name tail_ipv4_ct_egress  tag 59a6b9ea80d80e8b  gpl
	loaded_at 2024-10-25T10:22:40+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 235
630: sched_cls  name tail_handle_ipv4  tag d7f0c9d496f72d4f  gpl
	loaded_at 2024-10-25T10:22:40+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 237
631: sched_cls  name __send_drop_notify  tag eaaa450ce855369f  gpl
	loaded_at 2024-10-25T10:22:40+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 238
632: sched_cls  name tail_handle_ipv4_cont  tag 341485c23f10a136  gpl
	loaded_at 2024-10-25T10:22:40+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 239
633: sched_cls  name tail_ipv4_ct_ingress  tag 3c837eee21264282  gpl
	loaded_at 2024-10-25T10:22:40+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 240
634: sched_cls  name tail_ipv4_to_endpoint  tag 838892760fd5317c  gpl
	loaded_at 2024-10-25T10:22:40+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 241
635: sched_cls  name tail_handle_arp  tag 4de1e14031402d8f  gpl
	loaded_at 2024-10-25T10:22:40+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 242
636: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:40+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 243
637: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
640: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
653: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
656: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
657: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
660: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
