ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.184.164:443 (active)    
                                         2 => 172.31.234.118:443 (active)    
2    10.100.25.138:443    ClusterIP      1 => 172.31.246.231:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.55.0.160:9153 (active)      
                                         2 => 10.55.0.27:9153 (active)       
4    10.100.0.10:53       ClusterIP      1 => 10.55.0.160:53 (active)        
                                         2 => 10.55.0.27:53 (active)         
5    10.100.15.248:2379   ClusterIP      1 => 10.55.0.48:2379 (active)       
