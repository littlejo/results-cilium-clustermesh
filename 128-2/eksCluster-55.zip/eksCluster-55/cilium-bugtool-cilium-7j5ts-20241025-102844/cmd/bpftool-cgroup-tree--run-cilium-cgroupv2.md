CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode9dd4c14_2edf_45f4_82ad_501d6087957e.slice/cri-containerd-a7980e7edc00b763a8b8c2be8ebb258d97e87817cb3703d2d2c33d582c6d6154.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode9dd4c14_2edf_45f4_82ad_501d6087957e.slice/cri-containerd-6e002c55329dc950c90a0df3b951372167d78ae4ce906f1a03a57dadb159a462.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ccdaa3c_95b9_45e8_92ef_fa17ca56e640.slice/cri-containerd-e5a2d3f6a4f12218d4182ec6d9beb3ade79aef548f949cee0fc541ef6290f680.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ccdaa3c_95b9_45e8_92ef_fa17ca56e640.slice/cri-containerd-d32cc5c8c7834ad9af7beddec47793eeb052b0244123e689499c3399fdd9e71b.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfb2a6dd0_7f93_49a1_b00e_50f04ca25591.slice/cri-containerd-ad9753fa8047fdc8331704a9704f57500039fec77591fe4923077db10ac24389.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfb2a6dd0_7f93_49a1_b00e_50f04ca25591.slice/cri-containerd-469ec262fc5cabed4395b587f84c730a1d9eca69be6826ca81330808addc5237.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4907b75e_b427_4714_ba99_2c930dcf1883.slice/cri-containerd-2bcafd0773a459b2badc378a438f4c2709ab9917feb1169651a8f31cdb213021.scope
    586      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4907b75e_b427_4714_ba99_2c930dcf1883.slice/cri-containerd-f7ee16e9e01c02af2ef880b868c176b36c899ce0757d0eebacf792707cf3a5ce.scope
    582      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ab3c960_7fbd_40e3_9396_944cba8b2ab3.slice/cri-containerd-cc2bc94bd3adf90596e5ed8ed618a67a170b595d6a3105ba3eb3a7b4eed87bee.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ab3c960_7fbd_40e3_9396_944cba8b2ab3.slice/cri-containerd-83df8d716c68994079c975698836a1b66d1207f1671b51d33b8f89268d7fed27.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod34b6ed19_afae_4aea_b615_c90f19753918.slice/cri-containerd-b65997f6aeda8586c3a8acaed7e9d2cb9cc419190e1a8341f25260a46314a5fb.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod34b6ed19_afae_4aea_b615_c90f19753918.slice/cri-containerd-9fb8957b91cd45c5a78c84ca7dea3979753d1c079583198d53ce5d92bc327e8c.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod34b6ed19_afae_4aea_b615_c90f19753918.slice/cri-containerd-146da9c2fd2a35be1d0ffceaa007067d89d8134c6122c2a4fef892e9799515b5.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod34b6ed19_afae_4aea_b615_c90f19753918.slice/cri-containerd-4b6c5f075fe036dff04dd624f26674c6b835db6186ed6d8287f45797a16901e0.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod90a4fcb6_a92a_4611_ab29_f274b21decc8.slice/cri-containerd-da36b8f3f51569420eea23cffe750d3a462017a3f2beb12c484ff2d8adee08b7.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod90a4fcb6_a92a_4611_ab29_f274b21decc8.slice/cri-containerd-67a520436808081c609e6dce5e5ed6753f1cc09a236996e57a71c7c73414f972.scope
    97       cgroup_device   multi                                          
