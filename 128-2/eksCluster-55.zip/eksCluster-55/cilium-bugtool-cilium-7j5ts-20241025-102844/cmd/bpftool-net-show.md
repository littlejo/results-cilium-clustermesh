xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 555
ens6(5) clsact/ingress cil_from_netdev-ens6 id 564
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 553
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 545
cilium_host(7) clsact/egress cil_from_host-cilium_host id 542
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 517
lxce53c9addc676(12) clsact/ingress cil_from_container-lxce53c9addc676 id 524
lxc09702e198079(14) clsact/ingress cil_from_container-lxc09702e198079 id 571
lxc4c1020c9c8fc(18) clsact/ingress cil_from_container-lxc4c1020c9c8fc id 626

flow_dissector:

netfilter:

