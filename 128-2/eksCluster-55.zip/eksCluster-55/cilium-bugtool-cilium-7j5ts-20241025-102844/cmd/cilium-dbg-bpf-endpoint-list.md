IP ADDRESS         LOCAL ENDPOINT INFO
10.55.0.200:0      (localhost)                                                                                        
172.31.246.231:0   (localhost)                                                                                        
10.55.0.27:0       id=191   sec_id=3698386 flags=0x0000 ifindex=14  mac=FE:72:4C:EB:B9:F1 nodemac=02:EC:E9:9F:24:41   
10.55.0.48:0       id=230   sec_id=3702661 flags=0x0000 ifindex=18  mac=B6:90:C6:63:E3:A0 nodemac=0E:07:0A:51:9A:46   
10.55.0.160:0      id=150   sec_id=3698386 flags=0x0000 ifindex=12  mac=CE:5E:DD:0A:FC:3C nodemac=1E:A0:48:82:2A:47   
172.31.253.14:0    (localhost)                                                                                        
10.55.0.64:0       id=550   sec_id=4     flags=0x0000 ifindex=10  mac=46:04:03:83:9C:6D nodemac=DE:AF:AF:7A:68:CC     
