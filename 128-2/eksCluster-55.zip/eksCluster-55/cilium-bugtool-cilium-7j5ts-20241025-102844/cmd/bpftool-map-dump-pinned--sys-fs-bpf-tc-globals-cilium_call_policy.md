key: 96 00 00 00  value: 0f 02 00 00
key: bf 00 00 00  value: 3d 02 00 00
key: e6 00 00 00  value: 73 02 00 00
key: 26 02 00 00  value: 04 02 00 00
Found 4 elements
