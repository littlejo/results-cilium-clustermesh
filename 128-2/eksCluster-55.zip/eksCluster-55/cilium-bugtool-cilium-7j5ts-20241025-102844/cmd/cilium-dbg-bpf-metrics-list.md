REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     213424    84450145   1132   bpf_host.c
Interface                 INGRESS     9605      748954     677    bpf_overlay.c
Success                   EGRESS      4977      378211     1694   bpf_host.c
Success                   EGRESS      89680     12117145   1308   bpf_lxc.c
Success                   EGRESS      9506      741471     53     encap.h
Success                   INGRESS     100979    12282966   86     l3.h
Success                   INGRESS     106510    12716411   235    trace.h
Unsupported L3 protocol   EGRESS      41        3098       1492   bpf_lxc.c
