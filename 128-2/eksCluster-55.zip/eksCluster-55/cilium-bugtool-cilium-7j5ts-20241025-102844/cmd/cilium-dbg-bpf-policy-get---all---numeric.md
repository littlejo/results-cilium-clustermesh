Endpoint ID: 150
Path: /sys/fs/bpf/tc/globals/cilium_policy_00150

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    78182   898       0        
Allow    Egress      0          ANY          NONE         disabled    13573   141       0        


Endpoint ID: 191
Path: /sys/fs/bpf/tc/globals/cilium_policy_00191

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    77656   896       0        
Allow    Egress      0          ANY          NONE         disabled    13355   139       0        


Endpoint ID: 230
Path: /sys/fs/bpf/tc/globals/cilium_policy_00230

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3911778   36377     0        
Allow    Ingress     1          ANY          NONE         disabled    3058230   30749     0        
Allow    Egress      0          ANY          NONE         disabled    4039989   37589     0        


Endpoint ID: 550
Path: /sys/fs/bpf/tc/globals/cilium_policy_00550

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    433841   5537      0        
Allow    Ingress     1          ANY          NONE         disabled    11449    133       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 878
Path: /sys/fs/bpf/tc/globals/cilium_policy_00878

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


