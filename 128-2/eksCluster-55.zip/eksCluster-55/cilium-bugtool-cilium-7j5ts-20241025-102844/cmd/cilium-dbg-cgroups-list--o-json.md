[
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod34b6ed19_afae_4aea_b615_c90f19753918.slice/cri-containerd-4b6c5f075fe036dff04dd624f26674c6b835db6186ed6d8287f45797a16901e0.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod34b6ed19_afae_4aea_b615_c90f19753918.slice/cri-containerd-b65997f6aeda8586c3a8acaed7e9d2cb9cc419190e1a8341f25260a46314a5fb.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod34b6ed19_afae_4aea_b615_c90f19753918.slice/cri-containerd-146da9c2fd2a35be1d0ffceaa007067d89d8134c6122c2a4fef892e9799515b5.scope"
      }
    ],
    "ips": [
      "10.55.0.48"
    ],
    "name": "clustermesh-apiserver-568b9994d7-dc46s",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7535,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode9dd4c14_2edf_45f4_82ad_501d6087957e.slice/cri-containerd-6e002c55329dc950c90a0df3b951372167d78ae4ce906f1a03a57dadb159a462.scope"
      }
    ],
    "ips": [
      "10.55.0.160"
    ],
    "name": "coredns-cc6ccd49c-jn58w",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4907b75e_b427_4714_ba99_2c930dcf1883.slice/cri-containerd-2bcafd0773a459b2badc378a438f4c2709ab9917feb1169651a8f31cdb213021.scope"
      }
    ],
    "ips": [
      "10.55.0.27"
    ],
    "name": "coredns-cc6ccd49c-frwh6",
    "namespace": "kube-system"
  }
]

