{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:16.716Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.246.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:16.716Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.253.14:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:16.716Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:21.302Z",
  "value": "id=550   sec_id=4     flags=0x0000 ifindex=10  mac=46:04:03:83:9C:6D nodemac=DE:AF:AF:7A:68:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:21.312Z",
  "value": "id=150   sec_id=3698386 flags=0x0000 ifindex=12  mac=CE:5E:DD:0A:FC:3C nodemac=1E:A0:48:82:2A:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:21.355Z",
  "value": "id=550   sec_id=4     flags=0x0000 ifindex=10  mac=46:04:03:83:9C:6D nodemac=DE:AF:AF:7A:68:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:21.424Z",
  "value": "id=150   sec_id=3698386 flags=0x0000 ifindex=12  mac=CE:5E:DD:0A:FC:3C nodemac=1E:A0:48:82:2A:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:30.883Z",
  "value": "id=191   sec_id=3698386 flags=0x0000 ifindex=14  mac=FE:72:4C:EB:B9:F1 nodemac=02:EC:E9:9F:24:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:06.417Z",
  "value": "id=550   sec_id=4     flags=0x0000 ifindex=10  mac=46:04:03:83:9C:6D nodemac=DE:AF:AF:7A:68:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:06.417Z",
  "value": "id=150   sec_id=3698386 flags=0x0000 ifindex=12  mac=CE:5E:DD:0A:FC:3C nodemac=1E:A0:48:82:2A:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:06.418Z",
  "value": "id=191   sec_id=3698386 flags=0x0000 ifindex=14  mac=FE:72:4C:EB:B9:F1 nodemac=02:EC:E9:9F:24:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:06.447Z",
  "value": "id=2555  sec_id=3702661 flags=0x0000 ifindex=16  mac=E6:7C:C0:28:95:11 nodemac=2A:5C:EF:98:1C:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:07.417Z",
  "value": "id=550   sec_id=4     flags=0x0000 ifindex=10  mac=46:04:03:83:9C:6D nodemac=DE:AF:AF:7A:68:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:07.417Z",
  "value": "id=2555  sec_id=3702661 flags=0x0000 ifindex=16  mac=E6:7C:C0:28:95:11 nodemac=2A:5C:EF:98:1C:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:07.418Z",
  "value": "id=150   sec_id=3698386 flags=0x0000 ifindex=12  mac=CE:5E:DD:0A:FC:3C nodemac=1E:A0:48:82:2A:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:07.418Z",
  "value": "id=191   sec_id=3698386 flags=0x0000 ifindex=14  mac=FE:72:4C:EB:B9:F1 nodemac=02:EC:E9:9F:24:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:40.414Z",
  "value": "id=230   sec_id=3702661 flags=0x0000 ifindex=18  mac=B6:90:C6:63:E3:A0 nodemac=0E:07:0A:51:9A:46"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.55.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:46.276Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.229Z",
  "value": "id=191   sec_id=3698386 flags=0x0000 ifindex=14  mac=FE:72:4C:EB:B9:F1 nodemac=02:EC:E9:9F:24:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.229Z",
  "value": "id=230   sec_id=3702661 flags=0x0000 ifindex=18  mac=B6:90:C6:63:E3:A0 nodemac=0E:07:0A:51:9A:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.233Z",
  "value": "id=550   sec_id=4     flags=0x0000 ifindex=10  mac=46:04:03:83:9C:6D nodemac=DE:AF:AF:7A:68:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.234Z",
  "value": "id=150   sec_id=3698386 flags=0x0000 ifindex=12  mac=CE:5E:DD:0A:FC:3C nodemac=1E:A0:48:82:2A:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.228Z",
  "value": "id=191   sec_id=3698386 flags=0x0000 ifindex=14  mac=FE:72:4C:EB:B9:F1 nodemac=02:EC:E9:9F:24:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.229Z",
  "value": "id=150   sec_id=3698386 flags=0x0000 ifindex=12  mac=CE:5E:DD:0A:FC:3C nodemac=1E:A0:48:82:2A:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.229Z",
  "value": "id=550   sec_id=4     flags=0x0000 ifindex=10  mac=46:04:03:83:9C:6D nodemac=DE:AF:AF:7A:68:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.229Z",
  "value": "id=230   sec_id=3702661 flags=0x0000 ifindex=18  mac=B6:90:C6:63:E3:A0 nodemac=0E:07:0A:51:9A:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.229Z",
  "value": "id=191   sec_id=3698386 flags=0x0000 ifindex=14  mac=FE:72:4C:EB:B9:F1 nodemac=02:EC:E9:9F:24:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.229Z",
  "value": "id=550   sec_id=4     flags=0x0000 ifindex=10  mac=46:04:03:83:9C:6D nodemac=DE:AF:AF:7A:68:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.229Z",
  "value": "id=230   sec_id=3702661 flags=0x0000 ifindex=18  mac=B6:90:C6:63:E3:A0 nodemac=0E:07:0A:51:9A:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.55.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.229Z",
  "value": "id=150   sec_id=3698386 flags=0x0000 ifindex=12  mac=CE:5E:DD:0A:FC:3C nodemac=1E:A0:48:82:2A:47"
}

