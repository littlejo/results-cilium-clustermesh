1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:e6:cb:76:5e:13 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.246.231/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2726sec preferred_lft 2726sec
    inet6 fe80::8e6:cbff:fe76:5e13/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:c6:8f:3b:ec:59 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.253.14/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8c6:8fff:fe3b:ec59/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:2f:2b:c2:39:cd brd ff:ff:ff:ff:ff:ff
    inet6 fe80::642f:2bff:fec2:39cd/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:71:42:bd:3a:e7 brd ff:ff:ff:ff:ff:ff
    inet 10.55.0.200/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::c471:42ff:febd:3ae7/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 2e:33:e1:6c:2a:7a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2c33:e1ff:fe6c:2a7a/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:af:af:7a:68:cc brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::dcaf:afff:fe7a:68cc/64 scope link 
       valid_lft forever preferred_lft forever
12: lxce53c9addc676@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:a0:48:82:2a:47 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::1ca0:48ff:fe82:2a47/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc09702e198079@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:ec:e9:9f:24:41 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::ec:e9ff:fe9f:2441/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc4c1020c9c8fc@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:07:0a:51:9a:46 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c07:aff:fe51:9a46/64 scope link 
       valid_lft forever preferred_lft forever
