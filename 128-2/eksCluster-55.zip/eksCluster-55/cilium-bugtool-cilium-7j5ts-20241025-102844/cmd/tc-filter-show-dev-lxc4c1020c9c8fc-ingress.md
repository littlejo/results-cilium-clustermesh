filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc4c1020c9c8fc direct-action not_in_hw id 626 tag 3f30a43ab2ee9301 jited 
