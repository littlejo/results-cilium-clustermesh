top - 10:28:46 up 14 min,  0 users,  load average: 0.11, 0.13, 0.13
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 17.9 us, 14.3 sy,  0.0 ni, 67.9 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    800.7 free,    893.1 used,   2142.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2774.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1472624 277332  77500 S  13.3   7.1   0:24.40 cilium-+
    619 root      20   0 1240432  16016  11292 S  13.3   0.4   0:00.03 cilium-+
    396 root      20   0 1228848   5800   2924 S   0.0   0.1   0:00.28 cilium-+
    643 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
    654 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    692 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    710 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
