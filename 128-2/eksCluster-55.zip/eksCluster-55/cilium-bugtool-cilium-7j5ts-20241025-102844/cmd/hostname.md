ip-172-31-246-231.eu-west-3.compute.internal
