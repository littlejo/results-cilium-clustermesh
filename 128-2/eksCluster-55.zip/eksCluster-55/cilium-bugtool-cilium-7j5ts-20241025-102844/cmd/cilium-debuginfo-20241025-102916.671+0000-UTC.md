# Cilium debug information

#### Service list

```
ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.184.164:443 (active)    
                                         2 => 172.31.234.118:443 (active)    
2    10.100.25.138:443    ClusterIP      1 => 172.31.246.231:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.55.0.160:9153 (active)      
                                         2 => 10.55.0.27:9153 (active)       
4    10.100.0.10:53       ClusterIP      1 => 10.55.0.160:53 (active)        
                                         2 => 10.55.0.27:53 (active)         
5    10.100.15.248:2379   ClusterIP      1 => 10.55.0.48:2379 (active)       
```

#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.55.0.0/24, 
Allocated addresses:
  10.55.0.160 (kube-system/coredns-cc6ccd49c-jn58w)
  10.55.0.200 (router)
  10.55.0.27 (kube-system/coredns-cc6ccd49c-frwh6)
  10.55.0.48 (kube-system/clustermesh-apiserver-568b9994d7-dc46s)
  10.55.0.64 (health)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 70901494a320bdf2
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    58s ago        never        0       no error   
  ct-map-pressure                                                     29s ago        never        0       no error   
  daemon-validate-config                                              46s ago        never        0       no error   
  dns-garbage-collector-job                                           1m2s ago       never        0       no error   
  endpoint-150-regeneration-recovery                                  never          never        0       no error   
  endpoint-191-regeneration-recovery                                  never          never        0       no error   
  endpoint-230-regeneration-recovery                                  never          never        0       no error   
  endpoint-550-regeneration-recovery                                  never          never        0       no error   
  endpoint-878-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         4m2s ago       never        0       no error   
  ep-bpf-prog-watchdog                                                29s ago        never        0       no error   
  ipcache-inject-labels                                               59s ago        never        0       no error   
  k8s-heartbeat                                                       32s ago        never        0       no error   
  link-cache                                                          14s ago        never        0       no error   
  local-identity-checkpoint                                           13m59s ago     never        0       no error   
  node-neighbor-link-updater                                          9s ago         never        0       no error   
  remote-etcd-cmesh1                                                  6m24s ago      never        0       no error   
  remote-etcd-cmesh10                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh100                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh101                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh102                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh103                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh104                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh105                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh106                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh107                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh108                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh109                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh11                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh110                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh111                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh112                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh113                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh114                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh115                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh116                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh117                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh118                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh119                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh12                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh120                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh121                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh122                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh123                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh124                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh125                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh126                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh127                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh128                                                6m24s ago      never        0       no error   
  remote-etcd-cmesh13                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh14                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh15                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh16                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh17                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh18                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh19                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh2                                                  6m24s ago      never        0       no error   
  remote-etcd-cmesh20                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh21                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh22                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh23                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh24                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh25                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh26                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh27                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh28                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh29                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh3                                                  6m24s ago      never        0       no error   
  remote-etcd-cmesh30                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh31                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh32                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh33                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh34                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh35                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh36                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh37                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh38                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh39                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh4                                                  6m24s ago      never        0       no error   
  remote-etcd-cmesh40                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh41                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh42                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh43                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh44                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh45                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh46                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh47                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh48                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh49                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh5                                                  6m24s ago      never        0       no error   
  remote-etcd-cmesh50                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh51                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh52                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh53                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh54                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh55                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh57                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh58                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh59                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh6                                                  6m24s ago      never        0       no error   
  remote-etcd-cmesh60                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh61                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh62                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh63                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh64                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh65                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh66                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh67                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh68                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh69                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh7                                                  6m24s ago      never        0       no error   
  remote-etcd-cmesh70                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh71                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh72                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh73                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh74                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh75                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh76                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh77                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh78                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh79                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh8                                                  6m24s ago      never        0       no error   
  remote-etcd-cmesh80                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh81                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh82                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh83                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh84                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh85                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh86                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh87                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh88                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh89                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh9                                                  6m24s ago      never        0       no error   
  remote-etcd-cmesh90                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh91                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh92                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh93                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh94                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh95                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh96                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh97                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh98                                                 6m24s ago      never        0       no error   
  remote-etcd-cmesh99                                                 6m24s ago      never        0       no error   
  resolve-identity-150                                                3m57s ago      never        0       no error   
  resolve-identity-191                                                3m45s ago      never        0       no error   
  resolve-identity-230                                                1m36s ago      never        0       no error   
  resolve-identity-550                                                3m58s ago      never        0       no error   
  resolve-identity-878                                                3m59s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-568b9994d7-dc46s   6m36s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-frwh6                  13m45s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-jn58w                  13m57s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      13m59s ago     never        0       no error   
  sync-policymap-150                                                  13m55s ago     never        0       no error   
  sync-policymap-191                                                  13m45s ago     never        0       no error   
  sync-policymap-230                                                  6m36s ago      never        0       no error   
  sync-policymap-550                                                  13m55s ago     never        0       no error   
  sync-policymap-878                                                  13m58s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (150)                                    7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (191)                                    5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (230)                                    6s ago         never        0       no error   
  sync-utime                                                          59s ago        never        0       no error   
  write-cni-file                                                      14m2s ago      never        0       no error   
Proxy Status:            OK, ip 10.55.0.200, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 3670016, max 3735551
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 73.53   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
egress-gateway-policy-map-max:16384
certificates-directory:/var/run/cilium/certs
ipam-cilium-node-update-rate:15s
http-idle-timeout:0
bpf-nat-global-max:524288
bpf-lb-rev-nat-map-max:0
envoy-secrets-namespace:
dnsproxy-socket-linger-timeout:10
enable-monitor:true
enable-endpoint-routes:false
bpf-auth-map-max:524288
cluster-pool-ipv4-cidr:10.55.0.0/16
lib-dir:/var/lib/cilium
hubble-skip-unknown-cgroup-ids:true
enable-gateway-api:false
l2-pod-announcements-interface:
custom-cni-conf:false
ipv4-native-routing-cidr:
bpf-events-policy-verdict-enabled:true
http-max-grpc-timeout:0
monitor-aggregation-flags:all
agent-labels:
local-max-addr-scope:252
kvstore-max-consecutive-quorum-errors:2
cni-exclusive:true
cni-external-routing:false
ipv6-cluster-alloc-cidr:f00d::/64
cluster-pool-ipv4-mask-size:24
endpoint-gc-interval:5m0s
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
bpf-lb-service-map-max:0
trace-sock:true
enable-runtime-device-detection:true
l2-announcements-lease-duration:15s
enable-bbr:false
nat-map-stats-interval:30s
clustermesh-config:/var/lib/cilium/clustermesh/
hubble-recorder-sink-queue-size:1024
procfs:/host/proc
max-controller-interval:0
identity-restore-grace-period:30s
use-cilium-internal-ip-for-ipsec:false
enable-ipv4:true
enable-k8s-endpoint-slice:true
debug-verbose:
hubble-export-file-compress:false
hubble-export-allowlist:
mtu:0
enable-recorder:false
operator-prometheus-serve-addr::9963
mesh-auth-spire-admin-socket:
set-cilium-node-taints:true
bpf-events-trace-enabled:true
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
envoy-keep-cap-netbindservice:false
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
hubble-export-file-path:
http-normalize-path:true
ipv6-native-routing-cidr:
envoy-base-id:0
cni-chaining-target:
node-port-bind-protection:true
enable-node-selector-labels:false
proxy-prometheus-port:0
use-full-tls-context:false
enable-bandwidth-manager:false
k8s-require-ipv6-pod-cidr:false
bpf-events-drop-enabled:true
bpf-sock-rev-map-max:262144
cni-chaining-mode:none
proxy-idle-timeout-seconds:60
metrics:
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
bpf-lb-rss-ipv4-src-cidr:
disable-envoy-version-check:false
local-router-ipv6:
enable-tracing:false
cmdref:
mesh-auth-mutual-listener-port:0
force-device-detection:false
kvstore-lease-ttl:15m0s
allow-icmp-frag-needed:true
clustermesh-ip-identities-sync-timeout:1m0s
bpf-policy-map-full-reconciliation-interval:15m0s
allow-localhost:auto
ipv4-node:auto
proxy-portrange-min:10000
proxy-max-connection-duration-seconds:0
hubble-export-file-max-size-mb:10
bpf-map-event-buffers:
hubble-event-queue-size:0
k8s-namespace:kube-system
node-port-range:
clustermesh-enable-endpoint-sync:false
hubble-drop-events-reasons:auth_required,policy_denied
remove-cilium-node-taints:true
tofqdns-dns-reject-response-code:refused
local-router-ipv4:
unmanaged-pod-watcher-interval:15
kvstore-connectivity-timeout:2m0s
hubble-redact-http-headers-allow:
k8s-heartbeat-timeout:30s
dnsproxy-enable-transparent-mode:true
enable-nat46x64-gateway:false
bpf-lb-affinity-map-max:0
bypass-ip-availability-upon-restore:false
enable-ipv4-big-tcp:false
clustermesh-sync-timeout:1m0s
identity-allocation-mode:crd
pprof-address:localhost
max-connected-clusters:255
bpf-node-map-max:16384
dnsproxy-lock-timeout:500ms
derive-masq-ip-addr-from-device:
enable-srv6:false
bpf-ct-global-any-max:262144
vtep-mask:
hubble-drop-events-interval:2m0s
bpf-lb-source-range-map-max:0
l2-announcements-renew-deadline:5s
ip-masq-agent-config-path:/etc/config/ip-masq-agent
bpf-ct-timeout-regular-tcp-fin:10s
bpf-lb-acceleration:disabled
ipam-default-ip-pool:default
ipam-multi-pool-pre-allocation:
identity-gc-interval:15m0s
version:false
vtep-mac:
enable-tcx:true
bpf-lb-algorithm:random
state-dir:/var/run/cilium
tunnel-port:0
policy-accounting:true
bpf-map-dynamic-size-ratio:0.0025
bpf-policy-map-max:16384
enable-ipsec-xfrm-state-caching:true
encryption-strict-mode-allow-remote-node-identities:false
enable-k8s-networkpolicy:true
enable-vtep:false
gops-port:9890
disable-iptables-feeder-rules:
policy-cidr-match-mode:
clustermesh-enable-mcs-api:false
kvstore-periodic-sync:5m0s
enable-health-check-nodeport:true
enable-svc-source-range-check:true
enable-metrics:true
enable-cilium-endpoint-slice:false
enable-k8s:true
enable-identity-mark:true
mesh-auth-queue-size:1024
enable-xdp-prefilter:false
enable-k8s-terminating-endpoint:true
bpf-filter-priority:1
enable-l2-neigh-discovery:true
proxy-max-requests-per-connection:0
mesh-auth-mutual-connect-timeout:5s
bpf-lb-sock:false
operator-api-serve-addr:127.0.0.1:9234
crd-wait-timeout:5m0s
k8s-client-connection-keep-alive:30s
enable-encryption-strict-mode:false
hubble-listen-address::4244
label-prefix-file:
ipv4-pod-subnets:
iptables-random-fully:false
srv6-encap-mode:reduced
bpf-fragments-map-max:8192
ipv6-range:auto
cni-log-file:/var/run/cilium/cilium-cni.log
bpf-lb-dsr-l4-xlate:frontend
hubble-event-buffer-capacity:4095
disable-endpoint-crd:false
enable-unreachable-routes:false
enable-node-port:false
disable-external-ip-mitigation:false
log-system-load:false
enable-ipsec-key-watcher:true
cluster-health-port:4240
log-driver:
config:
route-metric:0
bpf-root:/sys/fs/bpf
mesh-auth-spiffe-trust-domain:spiffe.cilium
enable-host-port:false
bpf-lb-sock-hostns-only:false
tofqdns-enable-dns-compression:true
prepend-iptables-chains:true
hubble-export-fieldmask:
enable-bpf-masquerade:false
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
bpf-ct-timeout-service-tcp:2h13m20s
envoy-config-timeout:2m0s
datapath-mode:veth
preallocate-bpf-maps:false
bgp-announce-lb-ip:false
enable-hubble:true
ipv6-pod-subnets:
cluster-name:cmesh56
encrypt-interface:
hubble-metrics-server:
socket-path:/var/run/cilium/cilium.sock
conntrack-gc-max-interval:0s
enable-cilium-health-api-server-access:
enable-high-scale-ipcache:false
enable-host-firewall:false
encrypt-node:false
endpoint-bpf-prog-watchdog-interval:30s
hubble-monitor-events:
enable-host-legacy-routing:false
k8s-sync-timeout:3m0s
enable-bpf-tproxy:false
hubble-recorder-storage-path:/var/run/cilium/pcaps
trace-payloadlen:128
identity-heartbeat-timeout:30m0s
hubble-socket-path:/var/run/cilium/hubble.sock
enable-ipv4-masquerade:true
join-cluster:false
proxy-xff-num-trusted-hops-ingress:0
bpf-ct-timeout-service-any:1m0s
gateway-api-secrets-namespace:
bgp-config-path:/var/lib/cilium/bgp/config.yaml
controller-group-metrics:
k8s-kubeconfig-path:
ipam:cluster-pool
direct-routing-skip-unreachable:false
proxy-gid:1337
hubble-drop-events:false
enable-mke:false
http-retry-count:3
auto-create-cilium-node-resource:true
max-internal-timer-delay:0s
enable-sctp:false
enable-wireguard-userspace-fallback:false
enable-route-mtu-for-cni-chaining:false
ipv6-mcast-device:
auto-direct-node-routes:false
encryption-strict-mode-cidr:
enable-icmp-rules:true
http-retry-timeout:0
direct-routing-device:
bpf-lb-dsr-dispatch:opt
node-port-mode:snat
bpf-neigh-global-max:524288
conntrack-gc-interval:0s
ipv4-service-range:auto
kvstore:
hubble-redact-http-userinfo:true
mesh-auth-enabled:true
k8s-client-qps:10
endpoint-queue-size:25
kube-proxy-replacement:false
identity-change-grace-period:5s
proxy-connect-timeout:2
exclude-local-address:
enable-masquerade-to-route-source:false
enable-policy:default
monitor-aggregation-interval:5s
monitor-queue-size:0
envoy-config-retry-interval:15s
hubble-metrics:
enable-service-topology:false
exclude-node-label-patterns:
hubble-export-file-max-backups:5
k8s-api-server:
enable-active-connection-tracking:false
enable-l2-pod-announcements:false
enable-pmtu-discovery:false
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
api-rate-limit:
bpf-ct-timeout-regular-any:1m0s
enable-ingress-controller:false
k8s-service-proxy-name:
bpf-lb-external-clusterip:false
bpf-lb-maglev-map-max:0
mesh-auth-rotated-identities-queue-size:1024
enable-ipip-termination:false
ipv6-node:auto
mesh-auth-gc-interval:5m0s
dns-policy-unload-on-shutdown:false
k8s-client-burst:20
enable-cilium-api-server-access:
enable-session-affinity:false
hubble-flowlogs-config-path:
tofqdns-proxy-port:0
policy-queue-size:100
vlan-bpf-bypass:
bpf-lb-service-backend-map-max:0
ipv4-service-loopback-address:169.254.42.1
hubble-redact-enabled:false
annotate-k8s-node:false
read-cni-conf:
enable-l7-proxy:true
service-no-backend-response:reject
agent-health-port:9879
tunnel-protocol:vxlan
hubble-prefer-ipv6:false
enable-auto-protect-node-port-range:true
k8s-client-connection-timeout:30s
bpf-ct-timeout-regular-tcp-syn:1m0s
cluster-id:56
config-sources:config-map:kube-system/cilium-config
ingress-secrets-namespace:
keep-config:false
nodes-gc-interval:5m0s
tofqdns-max-deferred-connection-deletes:10000
bpf-ct-timeout-regular-tcp:2h13m20s
enable-local-node-route:true
install-no-conntrack-iptables-rules:false
tofqdns-proxy-response-max-delay:100ms
node-port-acceleration:disabled
dnsproxy-lock-count:131
proxy-xff-num-trusted-hops-egress:0
fixed-identity-mapping:
kube-proxy-replacement-healthz-bind-address:
enable-external-ips:false
static-cnp-path:
cilium-endpoint-gc-interval:5m0s
envoy-log:
bpf-lb-maglev-table-size:16381
enable-health-check-loadbalancer-ip:false
set-cilium-is-up-condition:true
hubble-redact-http-headers-deny:
bpf-lb-rss-ipv6-src-cidr:
dnsproxy-concurrency-limit:0
node-port-algorithm:random
ipsec-key-file:
k8s-service-cache-size:128
arping-refresh-period:30s
policy-trigger-interval:1s
enable-wireguard:false
container-ip-local-reserved-ports:auto
egress-gateway-reconciliation-trigger-interval:1s
dnsproxy-insecure-skip-transparent-mode-check:false
enable-ipv6-big-tcp:false
enable-ipv6-ndp:false
enable-xt-socket-fallback:true
tofqdns-pre-cache:
enable-local-redirect-policy:false
l2-announcements-retry-period:2s
labels:
enable-l2-announcements:false
tofqdns-min-ttl:0
fqdn-regex-compile-lru-size:1024
enable-ip-masq-agent:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
config-dir:/tmp/cilium/config-map
enable-k8s-api-discovery:false
routing-mode:tunnel
enable-hubble-recorder-api:true
tofqdns-endpoint-max-ip-per-hostname:50
bpf-lb-map-max:65536
dnsproxy-concurrency-processing-grace-period:0s
bgp-announce-pod-cidr:false
devices:
bpf-lb-sock-terminate-pod-connections:false
pprof-port:6060
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
enable-ipsec:false
vtep-endpoint:
proxy-admin-port:0
mke-cgroup-mount:
enable-endpoint-health-checking:true
mesh-auth-signal-backoff-duration:1s
bpf-ct-global-tcp-max:524288
prometheus-serve-addr:
bpf-lb-mode:snat
enable-ipv4-egress-gateway:false
dns-max-ips-per-restored-rule:1000
nat-map-stats-entries:32
install-iptables-rules:true
synchronize-k8s-nodes:true
enable-ipv6-masquerade:true
enable-ipv6:false
enable-bpf-clock-probe:false
vtep-cidr:
hubble-redact-kafka-apikey:false
wireguard-persistent-keepalive:0s
iptables-lock-timeout:5s
http-request-timeout:3600
kvstore-opt:
enable-ipv4-fragment-tracking:true
ipv6-service-range:auto
enable-stale-cilium-endpoint-cleanup:true
bpf-ct-timeout-service-tcp-grace:1m0s
nodeport-addresses:
cgroup-root:/run/cilium/cgroupv2
tofqdns-idle-connection-grace-period:0s
external-envoy-proxy:true
enable-bgp-control-plane:false
monitor-aggregation:medium
egress-multi-home-ip-rule-compat:false
node-labels:
allocator-list-timeout:3m0s
pprof:false
enable-well-known-identities:false
restore:true
hubble-export-denylist:
enable-custom-calls:false
agent-liveness-update-interval:1s
hubble-disable-tls:false
proxy-portrange-max:20000
k8s-require-ipv4-pod-cidr:false
hubble-redact-http-urlquery:false
enable-health-checking:true
multicast-enabled:false
debug:false
enable-ipsec-encrypted-overlay:false
cflags:
ipsec-key-rotation-duration:5m0s
policy-audit-mode:false
enable-envoy-config:false
ipv4-range:auto
egress-masquerade-interfaces:ens+
log-opt:
```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 33632098                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 33632098                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 33632098                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400cc00000 rw-p 00000000 00:00 0 
400cc00000-4010000000 ---p 00000000 00:00 0 
ffff63dad000-ffff63fa3000 rw-p 00000000 00:00 0 
ffff63fab000-ffff640cc000 rw-p 00000000 00:00 0 
ffff640cc000-ffff6410d000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff6410d000-ffff6414e000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff6414e000-ffff641ce000 rw-p 00000000 00:00 0 
ffff641ce000-ffff641d0000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff641d0000-ffff641d2000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff641d2000-ffff64749000 rw-p 00000000 00:00 0 
ffff64749000-ffff64849000 rw-p 00000000 00:00 0 
ffff64849000-ffff6485a000 rw-p 00000000 00:00 0 
ffff6485a000-ffff6685a000 rw-p 00000000 00:00 0 
ffff6685a000-ffff668da000 ---p 00000000 00:00 0 
ffff668da000-ffff668db000 rw-p 00000000 00:00 0 
ffff668db000-ffff868da000 ---p 00000000 00:00 0 
ffff868da000-ffff868db000 rw-p 00000000 00:00 0 
ffff868db000-ffffa686a000 ---p 00000000 00:00 0 
ffffa686a000-ffffa686b000 rw-p 00000000 00:00 0 
ffffa686b000-ffffaa85c000 ---p 00000000 00:00 0 
ffffaa85c000-ffffaa85d000 rw-p 00000000 00:00 0 
ffffaa85d000-ffffab05a000 ---p 00000000 00:00 0 
ffffab05a000-ffffab05b000 rw-p 00000000 00:00 0 
ffffab05b000-ffffab15a000 ---p 00000000 00:00 0 
ffffab15a000-ffffab1ba000 rw-p 00000000 00:00 0 
ffffab1ba000-ffffab1bc000 r--p 00000000 00:00 0                          [vvar]
ffffab1bc000-ffffab1bd000 r-xp 00000000 00:00 0                          [vdso]
fffff63d3000-fffff63f4000 rw-p 00000000 00:00 0                          [stack]

```


#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.55.0.27": (string) (len=35) "kube-system/coredns-cc6ccd49c-frwh6",
  (string) (len=10) "10.55.0.48": (string) (len=50) "kube-system/clustermesh-apiserver-568b9994d7-dc46s",
  (string) (len=11) "10.55.0.200": (string) (len=6) "router",
  (string) (len=10) "10.55.0.64": (string) (len=6) "health",
  (string) (len=11) "10.55.0.160": (string) (len=35) "kube-system/coredns-cc6ccd49c-jn58w"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.246.231": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001e522c0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x400255d8c0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x400255d8c0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4002679080)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4001a73970)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40022e1550)(frontends:[10.100.15.248]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4002678f20)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4002678fd0)(frontends:[10.100.25.138]/ports=[peer-service]/selector=map[k8s-app:cilium])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4000d637d0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x400223c680)(172.31.184.164:443/TCP,172.31.234.118:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4000d637d8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-9d7f4": (*k8s.Endpoints)(0x4001f65790)(172.31.246.231:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4000d637e0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-t4fhs": (*k8s.Endpoints)(0x4002cfef70)(10.55.0.160:53/TCP[eu-west-3b],10.55.0.160:53/UDP[eu-west-3b],10.55.0.160:9153/TCP[eu-west-3b],10.55.0.27:53/TCP[eu-west-3b],10.55.0.27:53/UDP[eu-west-3b],10.55.0.27:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4000721110)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-v5rmr": (*k8s.Endpoints)(0x40030ce4e0)(10.55.0.48:2379/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001c04a10)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x400233afa0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400a78f950
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4002346780,
  gcExited: (chan struct {}) 0x40023467e0,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001c91100)({
     ObserverVec: (*prometheus.HistogramVec)(0x400174b7b8)({
      MetricVec: (*prometheus.MetricVec)(0x400253b1a0)({
       metricMap: (*prometheus.metricMap)(0x400253b1d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c2d140)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001c91180)({
     ObserverVec: (*prometheus.HistogramVec)(0x400174b7c0)({
      MetricVec: (*prometheus.MetricVec)(0x400253b230)({
       metricMap: (*prometheus.metricMap)(0x400253b260)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c2d1a0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001c91200)({
     GaugeVec: (*prometheus.GaugeVec)(0x400174b7c8)({
      MetricVec: (*prometheus.MetricVec)(0x400253b2c0)({
       metricMap: (*prometheus.metricMap)(0x400253b2f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c2d200)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001c91280)({
     GaugeVec: (*prometheus.GaugeVec)(0x400174b7d0)({
      MetricVec: (*prometheus.MetricVec)(0x400253b350)({
       metricMap: (*prometheus.metricMap)(0x400253b380)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c2d260)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001c91300)({
     GaugeVec: (*prometheus.GaugeVec)(0x400174b7d8)({
      MetricVec: (*prometheus.MetricVec)(0x400253b3e0)({
       metricMap: (*prometheus.metricMap)(0x400253b410)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c2d2c0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001c91380)({
     GaugeVec: (*prometheus.GaugeVec)(0x400174b7e0)({
      MetricVec: (*prometheus.MetricVec)(0x400253b470)({
       metricMap: (*prometheus.metricMap)(0x400253b4a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c2d320)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001c91400)({
     GaugeVec: (*prometheus.GaugeVec)(0x400174b7e8)({
      MetricVec: (*prometheus.MetricVec)(0x400253b500)({
       metricMap: (*prometheus.metricMap)(0x400253b530)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c2d380)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001c91480)({
     GaugeVec: (*prometheus.GaugeVec)(0x400174b7f0)({
      MetricVec: (*prometheus.MetricVec)(0x400253b590)({
       metricMap: (*prometheus.metricMap)(0x400253b5c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c2d3e0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001c91500)({
     ObserverVec: (*prometheus.HistogramVec)(0x400174b7f8)({
      MetricVec: (*prometheus.MetricVec)(0x400253b620)({
       metricMap: (*prometheus.metricMap)(0x400253b650)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001c2d440)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001c04a10)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001c048c0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001e64d08)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 344ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   },
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
150        Disabled           Disabled          3698386    k8s:eks.amazonaws.com/component=coredns                                             10.55.0.160   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh56                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
191        Disabled           Disabled          3698386    k8s:eks.amazonaws.com/component=coredns                                             10.55.0.27    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh56                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
230        Disabled           Disabled          3702661    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.55.0.48    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh56                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
550        Disabled           Disabled          4          reserved:health                                                                     10.55.0.64    ready   
878        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                
                                                           reserved:host                                                                                             
```

#### BPF Policy Get 150

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    78182   898       0        
Allow    Egress      0          ANY          NONE         disabled    13573   141       0        

```


#### BPF CT List 150

```
Invalid argument: unknown type 150
```


#### Endpoint Get 150

```
[
  {
    "id": 150,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-150-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "83b83e63-bddc-4541-8092-fe95727a5092"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-150",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:18.772Z",
            "success-count": 3
          },
          "uuid": "e33cd92a-ff56-4935-9900-4cbbc231cd6a"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-jn58w",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:18.771Z",
            "success-count": 1
          },
          "uuid": "f1d87bc5-443c-4b64-80a6-d307ee48e1df"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-150",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:21.314Z",
            "success-count": 1
          },
          "uuid": "095483b5-235f-435d-92a8-30311c7d3174"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (150)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:08.849Z",
            "success-count": 85
          },
          "uuid": "6196a5e6-3954-4617-a11e-a5c900454131"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "a7980e7edc00b763a8b8c2be8ebb258d97e87817cb3703d2d2c33d582c6d6154:eth0",
        "container-id": "a7980e7edc00b763a8b8c2be8ebb258d97e87817cb3703d2d2c33d582c6d6154",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-jn58w",
        "pod-name": "kube-system/coredns-cc6ccd49c-jn58w"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3698386,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh56",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh56",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:54Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.55.0.160",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "1e:a0:48:82:2a:47",
        "interface-index": 12,
        "interface-name": "lxce53c9addc676",
        "mac": "ce:5e:dd:0a:fc:3c"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3698386,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3698386,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 150

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 150

```
Timestamp              Status   State                   Message
2024-10-25T10:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:54Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:07Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:15:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:21Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:15:21Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:15:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:15:18Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:18Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:15:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:18Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:18Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3698386

```
ID        LABELS
3698386   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh56
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 191

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    77656   896       0        
Allow    Egress      0          ANY          NONE         disabled    13355   139       0        

```


#### BPF CT List 191

```
Invalid argument: unknown type 191
```


#### Endpoint Get 191

```
[
  {
    "id": 191,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-191-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "393c8a04-0d95-4d9d-a9ee-279d074c5336"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-191",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:30.853Z",
            "success-count": 3
          },
          "uuid": "c3805d86-8fff-4804-819a-bc67a835933e"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-frwh6",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:30.852Z",
            "success-count": 1
          },
          "uuid": "7aa39cbb-feb6-442c-abe0-e2bf9a0c257b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-191",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:30.884Z",
            "success-count": 1
          },
          "uuid": "3082c13a-1600-4aaa-bc11-78efe1a171fa"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (191)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:10.917Z",
            "success-count": 84
          },
          "uuid": "f653d10c-396f-40a2-a171-1956f13402dc"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "f7ee16e9e01c02af2ef880b868c176b36c899ce0757d0eebacf792707cf3a5ce:eth0",
        "container-id": "f7ee16e9e01c02af2ef880b868c176b36c899ce0757d0eebacf792707cf3a5ce",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-frwh6",
        "pod-name": "kube-system/coredns-cc6ccd49c-frwh6"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3698386,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh56",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh56",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:54Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.55.0.27",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "02:ec:e9:9f:24:41",
        "interface-index": 14,
        "interface-name": "lxc09702e198079",
        "mac": "fe:72:4c:eb:b9:f1"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3698386,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3698386,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 191

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 191

```
Timestamp              Status   State                   Message
2024-10-25T10:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:54Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:07Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:30Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:30Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:30Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3698386

```
ID        LABELS
3698386   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh56
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 230

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3879982   36028     0        
Allow    Ingress     1          ANY          NONE         disabled    3058230   30749     0        
Allow    Egress      0          ANY          NONE         disabled    4039311   37581     0        

```


#### BPF CT List 230

```
Invalid argument: unknown type 230
```


#### Endpoint Get 230

```
[
  {
    "id": 230,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-230-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7619c68e-0836-4348-9ca9-093415be865e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-230",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:40.377Z",
            "success-count": 2
          },
          "uuid": "3ac2bdd2-66e3-4e08-8df0-b7ea3d1afd37"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-568b9994d7-dc46s",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:40.375Z",
            "success-count": 1
          },
          "uuid": "8d345c93-90be-4c81-8913-c78c68b3889e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-230",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:40.415Z",
            "success-count": 1
          },
          "uuid": "7e3d5c41-a168-4711-a7b2-2ec432528cf5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (230)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:10.432Z",
            "success-count": 41
          },
          "uuid": "08d1f473-5a07-4029-a6b2-60b6949c6f1d"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "9fb8957b91cd45c5a78c84ca7dea3979753d1c079583198d53ce5d92bc327e8c:eth0",
        "container-id": "9fb8957b91cd45c5a78c84ca7dea3979753d1c079583198d53ce5d92bc327e8c",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-568b9994d7-dc46s",
        "pod-name": "kube-system/clustermesh-apiserver-568b9994d7-dc46s"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3702661,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh56",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=568b9994d7"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh56",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:54Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.55.0.48",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "0e:07:0a:51:9a:46",
        "interface-index": 18,
        "interface-name": "lxc4c1020c9c8fc",
        "mac": "b6:90:c6:63:e3:a0"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3702661,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3702661,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 230

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 230

```
Timestamp              Status   State                   Message
2024-10-25T10:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:54Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:40Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:22:40Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:22:40Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3702661

```
ID        LABELS
3702661   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh56
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 550

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    433709   5535      0        
Allow    Ingress     1          ANY          NONE         disabled    11076    129       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 550

```
Invalid argument: unknown type 550
```


#### Endpoint Get 550

```
[
  {
    "id": 550,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-550-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "125952a8-d1f2-42df-b918-7867d838a33f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-550",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:18.012Z",
            "success-count": 3
          },
          "uuid": "5805c11c-f5fa-42b7-849d-52fa85e413c3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-550",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:21.302Z",
            "success-count": 1
          },
          "uuid": "568c67f4-88f2-48e3-9c2c-438a606395d2"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:54Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.55.0.64",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "de:af:af:7a:68:cc",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "46:04:03:83:9c:6d"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 550

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 550

```
Timestamp              Status   State                   Message
2024-10-25T10:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:54Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:07Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:21Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:15:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:18Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:18Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:16Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 878

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 878

```
Invalid argument: unknown type 878
```


#### Endpoint Get 878

```
[
  {
    "id": 878,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-878-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "2781591d-90db-4fd8-ab13-f118493e5e35"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-878",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:16.942Z",
            "success-count": 3
          },
          "uuid": "1f15da33-2f6e-41dc-8ae7-a96146a1854f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-878",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:18.026Z",
            "success-count": 1
          },
          "uuid": "1190bc25-f0cf-46f4-b1bf-e5262773e8db"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:54Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "c6:71:42:bd:3a:e7",
        "interface-name": "cilium_host",
        "mac": "c6:71:42:bd:3a:e7"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 878

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 878

```
Timestamp              Status   State                   Message
2024-10-25T10:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:54Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:07Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:15:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:16Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:16Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:16Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### Policy get

```
:
 []
Revision: 1

```

