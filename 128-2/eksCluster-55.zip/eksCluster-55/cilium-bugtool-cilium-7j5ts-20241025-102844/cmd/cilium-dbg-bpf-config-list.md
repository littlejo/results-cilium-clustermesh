KEY             VALUE
AgentLiveness   915274631885
UTimeOffset     3378615705078125
