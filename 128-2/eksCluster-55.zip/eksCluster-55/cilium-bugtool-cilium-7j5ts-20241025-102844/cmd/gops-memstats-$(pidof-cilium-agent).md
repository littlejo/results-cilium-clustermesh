alloc: 140.24MB (147047104 bytes)
total-alloc: 1.34GB (1433543360 bytes)
sys: 210.51MB (220734804 bytes)
lookups: 0
mallocs: 47809571
frees: 46311143
heap-alloc: 140.24MB (147047104 bytes)
heap-sys: 163.36MB (171294720 bytes)
heap-idle: 5.84MB (6119424 bytes)
heap-in-use: 157.52MB (165175296 bytes)
heap-released: 3.99MB (4186112 bytes)
heap-objects: 1498428
stack-in-use: 36.34MB (38109184 bytes)
stack-sys: 36.34MB (38109184 bytes)
stack-mspan-inuse: 2.46MB (2583200 bytes)
stack-mspan-sys: 2.54MB (2660160 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 857.84KB (878425 bytes)
gc-sys: 5.51MB (5781544 bytes)
next-gc: when heap-alloc >= 144.22MB (151221096 bytes)
last-gc: 2024-10-25 10:28:21.054620229 +0000 UTC
gc-pause-total: 7.531323ms
gc-pause: 212424
gc-pause-end: 1729852101054620229
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.0003199775293742999
enable-gc: true
debug-gc: false
