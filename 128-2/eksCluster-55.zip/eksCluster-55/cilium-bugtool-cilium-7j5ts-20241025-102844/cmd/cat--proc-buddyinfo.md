Node 0, zone      DMA    150     22      4     33     17      6      3      1      3      4    165 
Node 0, zone   Normal     91     33      2     19     14      6      2      1      2      2      8 
