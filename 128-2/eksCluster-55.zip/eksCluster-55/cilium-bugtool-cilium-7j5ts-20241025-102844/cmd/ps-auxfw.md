USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         672  0.0  0.0   2340   788 ?        Rs   10:28   0:00 /usr/bin/cat /etc/cni/net.d/05-cilium-cni.conf
root         654  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops stack 1
root         643  0.0  0.0 1228744 3776 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root         619  0.0  0.4 1240176 16016 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         679  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         683  0.0  0.0   3728   488 ?        R    10:28   0:00  \_ bash -c ip a
root           1  2.9  7.0 1472624 277332 ?      Ssl  10:15   0:24 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.0  0.1 1228848 5800 ?        Sl   10:15   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
