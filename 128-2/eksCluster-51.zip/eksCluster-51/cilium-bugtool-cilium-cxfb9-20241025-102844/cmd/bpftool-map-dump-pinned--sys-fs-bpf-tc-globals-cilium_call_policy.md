key: 1b 00 00 00  value: f2 01 00 00
key: a0 01 00 00  value: 3b 02 00 00
key: 51 03 00 00  value: fd 01 00 00
key: 2c 09 00 00  value: e5 01 00 00
Found 4 elements
