[
  {
    "containers": [
      {
        "cgroup-id": 8286,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6451ef07_a148_4d52_aa83_df838ed65f44.slice/cri-containerd-aa43be87fe7d1f925117c01ac249ce25a84ae2796bdd67a16f050a3e87f4fa01.scope"
      },
      {
        "cgroup-id": 8202,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6451ef07_a148_4d52_aa83_df838ed65f44.slice/cri-containerd-0affe4125f1d545f68e7eda71c6663aea137770b9a2ead29647d56608fe8a851.scope"
      },
      {
        "cgroup-id": 8370,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6451ef07_a148_4d52_aa83_df838ed65f44.slice/cri-containerd-a0835639bec3840e1ab9de7fe5efa231bc27b37bd8bb0dfaa079e57149b62c61.scope"
      }
    ],
    "ips": [
      "10.51.0.19"
    ],
    "name": "clustermesh-apiserver-7769dd85f8-ln6cv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6858,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7f2b12a6_49f1_4f44_92f8_2b0b273e9ef3.slice/cri-containerd-06ab3ea05909bd1228d285bec989a7d63cd06681e1159051a5136274cdf469d7.scope"
      }
    ],
    "ips": [
      "10.51.0.169"
    ],
    "name": "coredns-cc6ccd49c-57kww",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6774,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6d9293ae_3730_4be3_ad32_bd1304ecc3f0.slice/cri-containerd-74cab1e5ba55d0ffb2e108735a5af36ae59aa32bd04ac250cccbf9f8025be314.scope"
      }
    ],
    "ips": [
      "10.51.0.132"
    ],
    "name": "coredns-cc6ccd49c-djs4m",
    "namespace": "kube-system"
  }
]

