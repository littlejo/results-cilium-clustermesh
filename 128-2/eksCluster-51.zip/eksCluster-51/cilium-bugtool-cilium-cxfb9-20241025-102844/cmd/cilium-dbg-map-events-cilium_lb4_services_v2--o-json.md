{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:55.361Z",
  "value": "1 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:55.361Z",
  "value": "0 1 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.28.187:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:55.362Z",
  "value": "0 0 (2) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:55.362Z",
  "value": "0 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:55.362Z",
  "value": "0 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.28.187:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:59.825Z",
  "value": "2 0 (2) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.28.187:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:59.825Z",
  "value": "0 1 (2) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:04.627Z",
  "value": "0 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:04.627Z",
  "value": "0 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:04.648Z",
  "value": "3 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:04.648Z",
  "value": "0 1 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:04.648Z",
  "value": "4 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:04.648Z",
  "value": "0 1 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:04.672Z",
  "value": "4 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:04.672Z",
  "value": "5 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:04.672Z",
  "value": "0 2 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:04.672Z",
  "value": "3 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:04.672Z",
  "value": "6 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:04.672Z",
  "value": "0 2 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.90.213:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:08.152Z",
  "value": "0 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:09.209Z",
  "value": "1 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:09.209Z",
  "value": "7 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:09.209Z",
  "value": "0 2 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.90.213:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:18.664Z",
  "value": "0 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.90.213:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:24.682Z",
  "value": "8 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.90.213:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:24.682Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.90.213:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:28.923Z",
  "value": "8 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.90.213:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:28.923Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.90.213:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:38.469Z",
  "value": "8 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.90.213:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:38.469Z",
  "value": "9 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.90.213:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:38.469Z",
  "value": "0 2 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.90.213:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:38.601Z",
  "value": "9 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.90.213:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:38.601Z",
  "value": "8 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.90.213:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:38.601Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.90.213:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:39.140Z",
  "value": "9 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.90.213:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:39.140Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.90.213:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:39.140Z",
  "value": "\u003cnil\u003e"
}

