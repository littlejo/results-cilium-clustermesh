{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:57.636Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.245.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:57.636Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:02.634Z",
  "value": "id=849   sec_id=4     flags=0x0000 ifindex=7   mac=1E:06:6F:FC:20:0D nodemac=D6:7C:66:8C:7D:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:02.648Z",
  "value": "id=2348  sec_id=3459824 flags=0x0000 ifindex=9   mac=12:12:61:76:A2:08 nodemac=5A:E3:FB:92:51:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:02.714Z",
  "value": "id=27    sec_id=3459824 flags=0x0000 ifindex=11  mac=CA:E9:AC:55:5F:5B nodemac=16:1C:DC:C6:0B:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:02.715Z",
  "value": "id=2348  sec_id=3459824 flags=0x0000 ifindex=9   mac=12:12:61:76:A2:08 nodemac=5A:E3:FB:92:51:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:02.726Z",
  "value": "id=849   sec_id=4     flags=0x0000 ifindex=7   mac=1E:06:6F:FC:20:0D nodemac=D6:7C:66:8C:7D:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:13.361Z",
  "value": "id=2348  sec_id=3459824 flags=0x0000 ifindex=9   mac=12:12:61:76:A2:08 nodemac=5A:E3:FB:92:51:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:13.361Z",
  "value": "id=849   sec_id=4     flags=0x0000 ifindex=7   mac=1E:06:6F:FC:20:0D nodemac=D6:7C:66:8C:7D:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:13.361Z",
  "value": "id=27    sec_id=3459824 flags=0x0000 ifindex=11  mac=CA:E9:AC:55:5F:5B nodemac=16:1C:DC:C6:0B:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:13.388Z",
  "value": "id=808   sec_id=3440100 flags=0x0000 ifindex=13  mac=42:E8:5A:3D:DE:EE nodemac=0E:48:62:67:0E:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:14.353Z",
  "value": "id=808   sec_id=3440100 flags=0x0000 ifindex=13  mac=42:E8:5A:3D:DE:EE nodemac=0E:48:62:67:0E:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:14.353Z",
  "value": "id=27    sec_id=3459824 flags=0x0000 ifindex=11  mac=CA:E9:AC:55:5F:5B nodemac=16:1C:DC:C6:0B:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:14.353Z",
  "value": "id=849   sec_id=4     flags=0x0000 ifindex=7   mac=1E:06:6F:FC:20:0D nodemac=D6:7C:66:8C:7D:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:14.353Z",
  "value": "id=2348  sec_id=3459824 flags=0x0000 ifindex=9   mac=12:12:61:76:A2:08 nodemac=5A:E3:FB:92:51:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:28.603Z",
  "value": "id=416   sec_id=3440100 flags=0x0000 ifindex=15  mac=6E:9E:F1:3F:2F:92 nodemac=4E:74:A1:CE:39:46"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.51.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:39.029Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:29.143Z",
  "value": "id=416   sec_id=3440100 flags=0x0000 ifindex=15  mac=6E:9E:F1:3F:2F:92 nodemac=4E:74:A1:CE:39:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:29.145Z",
  "value": "id=849   sec_id=4     flags=0x0000 ifindex=7   mac=1E:06:6F:FC:20:0D nodemac=D6:7C:66:8C:7D:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:29.146Z",
  "value": "id=2348  sec_id=3459824 flags=0x0000 ifindex=9   mac=12:12:61:76:A2:08 nodemac=5A:E3:FB:92:51:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:29.146Z",
  "value": "id=27    sec_id=3459824 flags=0x0000 ifindex=11  mac=CA:E9:AC:55:5F:5B nodemac=16:1C:DC:C6:0B:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:30.135Z",
  "value": "id=27    sec_id=3459824 flags=0x0000 ifindex=11  mac=CA:E9:AC:55:5F:5B nodemac=16:1C:DC:C6:0B:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:30.135Z",
  "value": "id=849   sec_id=4     flags=0x0000 ifindex=7   mac=1E:06:6F:FC:20:0D nodemac=D6:7C:66:8C:7D:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:30.135Z",
  "value": "id=2348  sec_id=3459824 flags=0x0000 ifindex=9   mac=12:12:61:76:A2:08 nodemac=5A:E3:FB:92:51:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:30.135Z",
  "value": "id=416   sec_id=3440100 flags=0x0000 ifindex=15  mac=6E:9E:F1:3F:2F:92 nodemac=4E:74:A1:CE:39:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:31.135Z",
  "value": "id=849   sec_id=4     flags=0x0000 ifindex=7   mac=1E:06:6F:FC:20:0D nodemac=D6:7C:66:8C:7D:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:31.135Z",
  "value": "id=2348  sec_id=3459824 flags=0x0000 ifindex=9   mac=12:12:61:76:A2:08 nodemac=5A:E3:FB:92:51:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:31.136Z",
  "value": "id=27    sec_id=3459824 flags=0x0000 ifindex=11  mac=CA:E9:AC:55:5F:5B nodemac=16:1C:DC:C6:0B:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:31.136Z",
  "value": "id=416   sec_id=3440100 flags=0x0000 ifindex=15  mac=6E:9E:F1:3F:2F:92 nodemac=4E:74:A1:CE:39:46"
}

