USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         643  0.0  0.4 1240432 15880 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         658  0.0  0.0   6408  1640 ?        R    10:28   0:00  \_ ps auxfw
root           1  4.0  6.9 1472496 273784 ?      Ssl  10:18   0:24 cilium-agent --config-dir=/tmp/cilium/config-map
root         404  0.0  0.1 1228848 6656 ?        Sl   10:18   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
