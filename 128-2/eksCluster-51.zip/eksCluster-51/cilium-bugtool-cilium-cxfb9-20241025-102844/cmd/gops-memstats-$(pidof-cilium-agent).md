alloc: 123.53MB (129529920 bytes)
total-alloc: 1.27GB (1359029688 bytes)
sys: 198.32MB (207952196 bytes)
lookups: 0
mallocs: 46995128
frees: 45559972
heap-alloc: 123.53MB (129529920 bytes)
heap-sys: 153.34MB (160792576 bytes)
heap-idle: 13.80MB (14475264 bytes)
heap-in-use: 139.54MB (146317312 bytes)
heap-released: 1.44MB (1507328 bytes)
heap-objects: 1435156
stack-in-use: 34.66MB (36339712 bytes)
stack-sys: 34.66MB (36339712 bytes)
stack-mspan-inuse: 2.34MB (2458080 bytes)
stack-mspan-sys: 2.51MB (2627520 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 887.11KB (908401 bytes)
gc-sys: 5.04MB (5289176 bytes)
next-gc: when heap-alloc >= 142.33MB (149242200 bytes)
last-gc: 2024-10-25 10:27:36.419091972 +0000 UTC
gc-pause-total: 6.79369ms
gc-pause: 64707
gc-pause-end: 1729852056419091972
num-gc: 70
num-forced-gc: 0
gc-cpu-fraction: 0.0005328086389532401
enable-gc: true
debug-gc: false
