Endpoint ID: 27
Path: /sys/fs/bpf/tc/globals/cilium_policy_00027

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    53563   614       0        
Allow    Egress      0          ANY          NONE         disabled    11685   116       0        


Endpoint ID: 416
Path: /sys/fs/bpf/tc/globals/cilium_policy_00416

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3197386   31748     0        
Allow    Ingress     1          ANY          NONE         disabled    3081273   31130     0        
Allow    Egress      0          ANY          NONE         disabled    4437692   42257     0        


Endpoint ID: 849
Path: /sys/fs/bpf/tc/globals/cilium_policy_00849

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    395418   5044      0        
Allow    Ingress     1          ANY          NONE         disabled    8156     96        0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2003
Path: /sys/fs/bpf/tc/globals/cilium_policy_02003

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2348
Path: /sys/fs/bpf/tc/globals/cilium_policy_02348

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    53365   611       0        
Allow    Egress      0          ANY          NONE         disabled    11371   113       0        


