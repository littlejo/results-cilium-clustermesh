KEY             VALUE
AgentLiveness   645199279504
UTimeOffset     3378616177734375
