 10:28:45 up 10 min,  0 users,  load average: 0.23, 0.43, 0.33
