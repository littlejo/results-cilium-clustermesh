CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6d9293ae_3730_4be3_ad32_bd1304ecc3f0.slice/cri-containerd-79a36952de0739014213fea9a8ca6eecb8e7dc6840464f2f0038565acea02e42.scope
    513      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6d9293ae_3730_4be3_ad32_bd1304ecc3f0.slice/cri-containerd-74cab1e5ba55d0ffb2e108735a5af36ae59aa32bd04ac250cccbf9f8025be314.scope
    521      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcec6a1c1_a2df_46a4_b45c_d7980b9c174a.slice/cri-containerd-58959c399b31e341a2088531c4372c38e31a34bd7219c8b746374d5cf6829b2b.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcec6a1c1_a2df_46a4_b45c_d7980b9c174a.slice/cri-containerd-6d77535a7cb57730719f74a0be0fe8bba631fa7918480897aaa9fb3aad475086.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7f2b12a6_49f1_4f44_92f8_2b0b273e9ef3.slice/cri-containerd-06ab3ea05909bd1228d285bec989a7d63cd06681e1159051a5136274cdf469d7.scope
    525      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7f2b12a6_49f1_4f44_92f8_2b0b273e9ef3.slice/cri-containerd-5c861ce9b85e0498b09be2ee84933c48df97dac9396a76704f3a10e9192ae264.scope
    517      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4c876593_a75b_4723_852d_9a60f68b80c7.slice/cri-containerd-d0054e3904a60314ee3b68e60990102d8da289743e0c3b55effa9f3742ca39d7.scope
    100      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4c876593_a75b_4723_852d_9a60f68b80c7.slice/cri-containerd-15f1bc076a9f8e31874cbce5ee081fa1cd9862caa1004fa18a53b5eb1db5369d.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6451ef07_a148_4d52_aa83_df838ed65f44.slice/cri-containerd-0affe4125f1d545f68e7eda71c6663aea137770b9a2ead29647d56608fe8a851.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6451ef07_a148_4d52_aa83_df838ed65f44.slice/cri-containerd-3ca85947f52098476763d9a75c8edcd0f5bf2a9e459f471aef95dd31f74d64a4.scope
    579      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6451ef07_a148_4d52_aa83_df838ed65f44.slice/cri-containerd-aa43be87fe7d1f925117c01ac249ce25a84ae2796bdd67a16f050a3e87f4fa01.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6451ef07_a148_4d52_aa83_df838ed65f44.slice/cri-containerd-a0835639bec3840e1ab9de7fe5efa231bc27b37bd8bb0dfaa079e57149b62c61.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod641042d8_3668_4fa8_ad20_0ac6dd6a64b5.slice/cri-containerd-c0e5ee0d34e6d5e496ddf2726ee3203eaa48bf90952c9abe5950ee221cc035e0.scope
    62       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod641042d8_3668_4fa8_ad20_0ac6dd6a64b5.slice/cri-containerd-158831620d33b8a710a67f89ebd7f135e9d62b12c49bf0ed95d6ae594f7fa116.scope
    73       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38466edd_34d1_4514_837e_40b17e11c457.slice/cri-containerd-5ab0ebc26e6abf9fcde9f96c6e23f07a16ff1152bf4c967f9c77358ab4597dce.scope
    58       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38466edd_34d1_4514_837e_40b17e11c457.slice/cri-containerd-36be82648359caec6736013c713e7adf39f751703d6f09311977001f2a368896.scope
    69       cgroup_device   multi                                          
