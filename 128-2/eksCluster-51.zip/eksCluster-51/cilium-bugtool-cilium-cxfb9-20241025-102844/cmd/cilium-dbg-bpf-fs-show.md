MountID:          988
ParentID:         952
Mounted State:    true
MountPoint:       /sys/fs/bpf
MountOptions:     rw,nosuid,nodev,noexec,relatime
OptionFields:     [master:7]
FilesystemType:   bpf
MountSource:      bpf
SuperOptions:     rw,mode=700
