1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:4f:f8:a0:20:f9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.245.66/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2969sec preferred_lft 2969sec
    inet6 fe80::84f:f8ff:fea0:20f9/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:0a:e4:0a:a1:97 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3c0a:e4ff:fe0a:a197/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:04:55:15:ae:37 brd ff:ff:ff:ff:ff:ff
    inet 10.51.0.216/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::7004:55ff:fe15:ae37/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 06:2b:73:ce:03:01 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::42b:73ff:fece:301/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:7c:66:8c:7d:ea brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d47c:66ff:fe8c:7dea/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc171acd07ba98@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:e3:fb:92:51:de brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::58e3:fbff:fe92:51de/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc81da71635c95@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:1c:dc:c6:0b:d8 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::141c:dcff:fec6:bd8/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc565b022e6a86@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:74:a1:ce:39:46 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::4c74:a1ff:fece:3946/64 scope link 
       valid_lft forever preferred_lft forever
