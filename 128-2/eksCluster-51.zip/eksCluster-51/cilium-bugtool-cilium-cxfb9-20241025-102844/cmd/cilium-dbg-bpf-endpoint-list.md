IP ADDRESS        LOCAL ENDPOINT INFO
172.31.245.66:0   (localhost)                                                                                        
10.51.0.132:0     id=2348  sec_id=3459824 flags=0x0000 ifindex=9   mac=12:12:61:76:A2:08 nodemac=5A:E3:FB:92:51:DE   
10.51.0.169:0     id=27    sec_id=3459824 flags=0x0000 ifindex=11  mac=CA:E9:AC:55:5F:5B nodemac=16:1C:DC:C6:0B:D8   
10.51.0.216:0     (localhost)                                                                                        
10.51.0.19:0      id=416   sec_id=3440100 flags=0x0000 ifindex=15  mac=6E:9E:F1:3F:2F:92 nodemac=4E:74:A1:CE:39:46   
10.51.0.173:0     id=849   sec_id=4     flags=0x0000 ifindex=7   mac=1E:06:6F:FC:20:0D nodemac=D6:7C:66:8C:7D:EA     
