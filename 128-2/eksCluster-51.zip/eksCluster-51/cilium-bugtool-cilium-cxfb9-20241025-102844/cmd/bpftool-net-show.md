xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 459
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 458
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 448
cilium_host(4) clsact/egress cil_from_host-cilium_host id 447
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 442
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 443
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 489
lxc171acd07ba98(9) clsact/ingress cil_from_container-lxc171acd07ba98 id 468
lxc81da71635c95(11) clsact/ingress cil_from_container-lxc81da71635c95 id 501
lxc565b022e6a86(15) clsact/ingress cil_from_container-lxc565b022e6a86 id 573

flow_dissector:

netfilter:

