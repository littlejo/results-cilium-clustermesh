key: 03 00 00 00  value: 0a 33 00 a9 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f f5 42 10 94 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f cd 47 01 bb 00 00  00 00 00 00
key: 07 00 00 00  value: ac 1f a2 cf 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 33 00 13 09 4b 00 00  00 00 00 00
key: 05 00 00 00  value: 0a 33 00 84 00 35 00 00  00 00 00 00
key: 04 00 00 00  value: 0a 33 00 a9 00 35 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 33 00 84 23 c1 00 00  00 00 00 00
Found 8 elements
