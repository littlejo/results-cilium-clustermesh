ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.205.71:443 (active)    
                                         2 => 172.31.162.207:443 (active)   
2    10.100.28.187:443    ClusterIP      1 => 172.31.245.66:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.51.0.169:53 (active)       
                                         2 => 10.51.0.132:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.51.0.169:9153 (active)     
                                         2 => 10.51.0.132:9153 (active)     
5    10.100.90.213:2379   ClusterIP      1 => 10.51.0.19:2379 (active)      
