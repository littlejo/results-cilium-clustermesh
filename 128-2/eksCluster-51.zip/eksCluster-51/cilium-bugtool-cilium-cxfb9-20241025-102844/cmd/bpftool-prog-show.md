29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:18:06+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:18:07+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:18:08+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:18:08+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:18:08+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:18:08+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:18:12+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
55: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
58: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
59: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
62: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:18:28+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
66: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
69: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
70: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
73: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
97: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
100: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
441: sched_cls  name tail_handle_ipv4  tag 0984155edc1ab9a3  gpl
	loaded_at 2024-10-25T10:18:59+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 112
442: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:18:59+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 113
443: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:18:59+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 114
444: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:18:59+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 115
445: sched_cls  name tail_handle_ipv4_from_host  tag ac6632117b86fba1  gpl
	loaded_at 2024-10-25T10:19:01+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,92
	btf_id 117
446: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:19:01+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,92
	btf_id 118
447: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:19:01+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,92
	btf_id 119
448: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:19:01+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 120
449: sched_cls  name __send_drop_notify  tag c17d87411f25f53c  gpl
	loaded_at 2024-10-25T10:19:01+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 121
452: sched_cls  name __send_drop_notify  tag c17d87411f25f53c  gpl
	loaded_at 2024-10-25T10:19:01+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 125
455: sched_cls  name tail_handle_ipv4_from_host  tag ac6632117b86fba1  gpl
	loaded_at 2024-10-25T10:19:01+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,94
	btf_id 128
456: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:19:01+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,94
	btf_id 129
458: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:19:01+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 131
459: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:19:01+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,96,67
	btf_id 133
461: sched_cls  name tail_handle_ipv4_from_host  tag ac6632117b86fba1  gpl
	loaded_at 2024-10-25T10:19:01+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,96
	btf_id 135
462: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:19:01+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,96
	btf_id 136
465: sched_cls  name __send_drop_notify  tag c17d87411f25f53c  gpl
	loaded_at 2024-10-25T10:19:01+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 139
467: sched_cls  name tail_ipv4_ct_egress  tag 31191955b5d9a468  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,101,74,75,100,76
	btf_id 144
468: sched_cls  name cil_from_container  tag 731bd99206e9883a  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 101,68
	btf_id 145
471: sched_cls  name tail_handle_ipv4_cont  tag 472c2d25d426d6ea  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,100,33,97,74,75,31,68,66,69,101,32,29,30,73
	btf_id 147
474: sched_cls  name tail_handle_ipv4  tag a9f4f5debf12491c  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,101
	btf_id 150
477: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,101
	btf_id 152
481: sched_cls  name tail_ipv4_to_endpoint  tag 4b705c24b6b82a6f  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,100,33,74,75,72,97,31,101,32,29,30
	btf_id 155
482: sched_cls  name __send_drop_notify  tag 9103a922c8591503  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 159
485: sched_cls  name handle_policy  tag da29b8cac732a235  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,101,74,75,100,33,72,97,31,76,67,32,29,30
	btf_id 160
486: sched_cls  name tail_ipv4_ct_ingress  tag 6828a5699c6ecd72  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,101,74,75,100,76
	btf_id 164
487: sched_cls  name tail_handle_arp  tag a1de8ccd77a68d40  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,101
	btf_id 165
488: sched_cls  name tail_ipv4_to_endpoint  tag 1164bb8970ee1e5e  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,103,33,74,75,72,102,31,104,32,29,30
	btf_id 163
489: sched_cls  name cil_from_container  tag 92411bab5f86c5cb  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 106,68
	btf_id 167
490: sched_cls  name tail_ipv4_to_endpoint  tag e0085f7b28d757af  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,105,33,74,75,72,90,31,106,32,29,30
	btf_id 168
491: sched_cls  name tail_handle_arp  tag 8fa896cdee5ccb87  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,104
	btf_id 169
492: sched_cls  name tail_handle_ipv4_cont  tag 7acd98dcda880510  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,103,33,102,74,75,31,68,66,69,104,32,29,30,73
	btf_id 171
493: sched_cls  name tail_ipv4_ct_ingress  tag b2195d1e6c6e5157  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,106,74,75,105,76
	btf_id 170
494: sched_cls  name tail_handle_ipv4  tag f479e1f64ec7907a  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,106
	btf_id 172
495: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,106,74,75,105,76
	btf_id 174
496: sched_cls  name tail_handle_arp  tag ff8948a652193b75  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,106
	btf_id 175
497: sched_cls  name __send_drop_notify  tag 06488c603adf19d3  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 176
498: sched_cls  name handle_policy  tag 470e84e0f1992693  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,104,74,75,103,33,72,102,31,76,67,32,29,30
	btf_id 173
499: sched_cls  name __send_drop_notify  tag d703cef9f182f971  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 177
501: sched_cls  name cil_from_container  tag 31247c9929634148  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 104,68
	btf_id 179
502: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,104
	btf_id 181
503: sched_cls  name tail_ipv4_ct_ingress  tag 281602cd0d6e320e  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 182
504: sched_cls  name tail_handle_ipv4_cont  tag 0583ce4e61e0c4b5  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,105,33,90,74,75,31,68,66,69,106,32,29,30,73
	btf_id 180
506: sched_cls  name tail_ipv4_ct_egress  tag 31191955b5d9a468  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 184
507: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,106
	btf_id 185
508: sched_cls  name tail_handle_ipv4  tag 4053d549d681f2f1  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,104
	btf_id 186
509: sched_cls  name handle_policy  tag e2250f41bc677184  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,106,74,75,105,33,72,90,31,76,67,32,29,30
	btf_id 187
510: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
513: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
514: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
517: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
518: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
521: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
522: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:19:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
525: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:19:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
565: sched_cls  name __send_drop_notify  tag e29a7ae1e6a9eb44  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 203
566: sched_cls  name tail_handle_ipv4_cont  tag 6f755bfec085c3ef  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,123,33,121,74,75,31,68,66,69,122,32,29,30,73
	btf_id 204
567: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,122
	btf_id 205
568: sched_cls  name tail_ipv4_ct_egress  tag 03214eea100825c6  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,122,74,75,123,76
	btf_id 206
569: sched_cls  name tail_ipv4_ct_ingress  tag 70b0cd6639143c7f  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,122,74,75,123,76
	btf_id 207
570: sched_cls  name tail_handle_arp  tag 228fe812014191c2  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,122
	btf_id 208
571: sched_cls  name handle_policy  tag 35392f10e7a362e7  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,122,74,75,123,33,72,121,31,76,67,32,29,30
	btf_id 209
572: sched_cls  name tail_ipv4_to_endpoint  tag bc655df09c6663a2  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,123,33,74,75,72,121,31,122,32,29,30
	btf_id 210
573: sched_cls  name cil_from_container  tag f91c0c116ed68241  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 122,68
	btf_id 211
574: sched_cls  name tail_handle_ipv4  tag 46855b0f69d1fbde  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,122
	btf_id 212
576: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
579: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
592: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
595: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
596: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
599: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
600: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
603: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
