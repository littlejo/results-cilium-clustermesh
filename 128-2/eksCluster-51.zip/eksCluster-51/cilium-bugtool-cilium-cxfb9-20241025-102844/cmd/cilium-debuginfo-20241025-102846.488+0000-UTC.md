# Cilium debug information

#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.51.0.0/24, 
Allocated addresses:
  10.51.0.132 (kube-system/coredns-cc6ccd49c-djs4m)
  10.51.0.169 (kube-system/coredns-cc6ccd49c-57kww)
  10.51.0.173 (health)
  10.51.0.19 (kube-system/clustermesh-apiserver-7769dd85f8-ln6cv)
  10.51.0.216 (router)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 29b0808b181df9c0
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    46s ago        never        0       no error   
  ct-map-pressure                                                     18s ago        never        0       no error   
  daemon-validate-config                                              39s ago        never        0       no error   
  dns-garbage-collector-job                                           51s ago        never        0       no error   
  endpoint-2003-regeneration-recovery                                 never          never        0       no error   
  endpoint-2348-regeneration-recovery                                 never          never        0       no error   
  endpoint-27-regeneration-recovery                                   never          never        0       no error   
  endpoint-416-regeneration-recovery                                  never          never        0       no error   
  endpoint-849-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         4m51s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                18s ago        never        0       no error   
  ipcache-inject-labels                                               48s ago        never        0       no error   
  k8s-heartbeat                                                       21s ago        never        0       no error   
  link-cache                                                          3s ago         never        0       no error   
  local-identity-checkpoint                                           9m37s ago      never        0       no error   
  node-neighbor-link-updater                                          8s ago         never        0       no error   
  remote-etcd-cmesh1                                                  6m17s ago      never        0       no error   
  remote-etcd-cmesh10                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh100                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh101                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh102                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh103                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh104                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh105                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh106                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh107                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh108                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh109                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh11                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh110                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh111                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh112                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh113                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh114                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh115                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh116                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh117                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh118                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh119                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh12                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh120                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh121                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh122                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh123                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh124                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh125                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh126                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh127                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh128                                                6m17s ago      never        0       no error   
  remote-etcd-cmesh13                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh14                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh15                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh16                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh17                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh18                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh19                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh2                                                  6m17s ago      never        0       no error   
  remote-etcd-cmesh20                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh21                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh22                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh23                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh24                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh25                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh26                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh27                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh28                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh29                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh3                                                  6m17s ago      never        0       no error   
  remote-etcd-cmesh30                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh31                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh32                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh33                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh34                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh35                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh36                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh37                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh38                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh39                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh4                                                  6m17s ago      never        0       no error   
  remote-etcd-cmesh40                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh41                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh42                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh43                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh44                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh45                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh46                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh47                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh48                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh49                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh5                                                  6m17s ago      never        0       no error   
  remote-etcd-cmesh50                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh51                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh53                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh54                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh55                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh56                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh57                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh58                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh59                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh6                                                  6m17s ago      never        0       no error   
  remote-etcd-cmesh60                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh61                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh62                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh63                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh64                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh65                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh66                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh67                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh68                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh69                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh7                                                  6m17s ago      never        0       no error   
  remote-etcd-cmesh70                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh71                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh72                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh73                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh74                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh75                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh76                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh77                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh78                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh79                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh8                                                  6m17s ago      never        0       no error   
  remote-etcd-cmesh80                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh81                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh82                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh83                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh84                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh85                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh86                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh87                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh88                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh89                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh9                                                  6m17s ago      never        0       no error   
  remote-etcd-cmesh90                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh91                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh92                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh93                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh94                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh95                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh96                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh97                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh98                                                 6m17s ago      never        0       no error   
  remote-etcd-cmesh99                                                 6m17s ago      never        0       no error   
  resolve-identity-2003                                               4m48s ago      never        0       no error   
  resolve-identity-2348                                               4m46s ago      never        0       no error   
  resolve-identity-27                                                 4m46s ago      never        0       no error   
  resolve-identity-416                                                2m17s ago      never        0       no error   
  resolve-identity-849                                                4m47s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-7769dd85f8-ln6cv   7m17s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-57kww                  9m46s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-djs4m                  9m46s ago      never        0       no error   
  sync-lb-maps-with-k8s-services                                      9m48s ago      never        0       no error   
  sync-policymap-2003                                                 9m47s ago      never        0       no error   
  sync-policymap-2348                                                 9m43s ago      never        0       no error   
  sync-policymap-27                                                   9m43s ago      never        0       no error   
  sync-policymap-416                                                  7m17s ago      never        0       no error   
  sync-policymap-849                                                  9m43s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (2348)                                   6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (27)                                     5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (416)                                    7s ago         never        0       no error   
  sync-utime                                                          48s ago        never        0       no error   
  write-cni-file                                                      9m51s ago      never        0       no error   
Proxy Status:            OK, ip 10.51.0.216, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 3407872, max 3473407
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 93.56   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
kvstore:
enable-ipv4-fragment-tracking:true
monitor-queue-size:0
exclude-node-label-patterns:
bpf-ct-timeout-regular-any:1m0s
max-connected-clusters:255
bpf-lb-rev-nat-map-max:0
bpf-node-map-max:16384
enable-mke:false
enable-local-redirect-policy:false
enable-xdp-prefilter:false
enable-metrics:true
crd-wait-timeout:5m0s
local-router-ipv6:
hubble-export-file-max-backups:5
http-max-grpc-timeout:0
read-cni-conf:
k8s-service-proxy-name:
proxy-portrange-max:20000
enable-sctp:false
dns-max-ips-per-restored-rule:1000
identity-restore-grace-period:30s
iptables-random-fully:false
use-full-tls-context:false
allow-localhost:auto
enable-health-check-loadbalancer-ip:false
certificates-directory:/var/run/cilium/certs
cni-exclusive:true
bpf-ct-global-tcp-max:524288
enable-ipv6-big-tcp:false
node-port-mode:snat
mesh-auth-rotated-identities-queue-size:1024
k8s-require-ipv4-pod-cidr:false
mesh-auth-spire-admin-socket:
enable-host-legacy-routing:false
enable-ip-masq-agent:false
hubble-redact-http-headers-deny:
enable-external-ips:false
bpf-lb-map-max:65536
ipv6-service-range:auto
tofqdns-max-deferred-connection-deletes:10000
enable-l2-neigh-discovery:true
operator-api-serve-addr:127.0.0.1:9234
bpf-events-drop-enabled:true
ipv4-pod-subnets:
cgroup-root:/run/cilium/cgroupv2
debug-verbose:
prometheus-serve-addr:
hubble-redact-kafka-apikey:false
tofqdns-endpoint-max-ip-per-hostname:50
ipv4-service-loopback-address:169.254.42.1
config:
enable-ipv6:false
install-no-conntrack-iptables-rules:false
version:false
k8s-client-connection-keep-alive:30s
kvstore-max-consecutive-quorum-errors:2
conntrack-gc-interval:0s
preallocate-bpf-maps:false
enable-bandwidth-manager:false
kube-proxy-replacement-healthz-bind-address:
install-iptables-rules:true
keep-config:false
enable-host-port:false
hubble-drop-events-interval:2m0s
disable-iptables-feeder-rules:
mtu:0
enable-route-mtu-for-cni-chaining:false
ipv4-service-range:auto
bpf-ct-timeout-regular-tcp-syn:1m0s
enable-icmp-rules:true
hubble-recorder-sink-queue-size:1024
ipv6-cluster-alloc-cidr:f00d::/64
k8s-heartbeat-timeout:30s
mesh-auth-signal-backoff-duration:1s
bpf-root:/sys/fs/bpf
auto-direct-node-routes:false
arping-refresh-period:30s
disable-external-ip-mitigation:false
ipv6-node:auto
enable-masquerade-to-route-source:false
api-rate-limit:
allocator-list-timeout:3m0s
identity-allocation-mode:crd
bpf-filter-priority:1
k8s-require-ipv6-pod-cidr:false
mesh-auth-queue-size:1024
proxy-prometheus-port:0
tofqdns-pre-cache:
bpf-lb-maglev-map-max:0
hubble-flowlogs-config-path:
tofqdns-proxy-port:0
bpf-ct-timeout-service-tcp:2h13m20s
bpf-lb-acceleration:disabled
hubble-monitor-events:
enable-l7-proxy:true
mesh-auth-enabled:true
bpf-lb-mode:snat
enable-unreachable-routes:false
ipsec-key-rotation-duration:5m0s
policy-accounting:true
ipv4-native-routing-cidr:
bpf-ct-timeout-regular-tcp:2h13m20s
enable-recorder:false
monitor-aggregation:medium
direct-routing-skip-unreachable:false
http-normalize-path:true
enable-srv6:false
cflags:
bpf-events-trace-enabled:true
vtep-endpoint:
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
envoy-config-timeout:2m0s
enable-cilium-endpoint-slice:false
envoy-config-retry-interval:15s
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
bpf-auth-map-max:524288
routing-mode:tunnel
enable-k8s-networkpolicy:true
dnsproxy-enable-transparent-mode:true
hubble-recorder-storage-path:/var/run/cilium/pcaps
enable-identity-mark:true
bpf-ct-timeout-regular-tcp-fin:10s
ipv6-pod-subnets:
ipam-cilium-node-update-rate:15s
enable-tracing:false
label-prefix-file:
enable-bpf-tproxy:false
fqdn-regex-compile-lru-size:1024
bpf-lb-affinity-map-max:0
enable-tcx:true
log-opt:
k8s-client-burst:20
tofqdns-proxy-response-max-delay:100ms
egress-multi-home-ip-rule-compat:false
envoy-secrets-namespace:
tofqdns-idle-connection-grace-period:0s
cluster-health-port:4240
proxy-idle-timeout-seconds:60
cluster-name:cmesh52
hubble-redact-enabled:false
agent-liveness-update-interval:1s
enable-bpf-masquerade:false
bpf-lb-dsr-dispatch:opt
cni-external-routing:false
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
monitor-aggregation-flags:all
bpf-nat-global-max:524288
bgp-announce-lb-ip:false
ipam-default-ip-pool:default
dnsproxy-socket-linger-timeout:10
identity-gc-interval:15m0s
enable-ipsec-xfrm-state-caching:true
egress-gateway-reconciliation-trigger-interval:1s
hubble-event-queue-size:0
ipv6-range:auto
enable-active-connection-tracking:false
enable-cilium-health-api-server-access:
hubble-export-fieldmask:
enable-health-checking:true
max-controller-interval:0
k8s-sync-timeout:3m0s
pprof-address:localhost
http-retry-timeout:0
static-cnp-path:
config-sources:config-map:kube-system/cilium-config
proxy-gid:1337
hubble-listen-address::4244
unmanaged-pod-watcher-interval:15
procfs:/host/proc
enable-well-known-identities:false
enable-monitor:true
enable-k8s-api-discovery:false
enable-session-affinity:false
remove-cilium-node-taints:true
bpf-lb-maglev-table-size:16381
enable-hubble:true
enable-cilium-api-server-access:
hubble-prefer-ipv6:false
controller-group-metrics:
l2-announcements-renew-deadline:5s
enable-high-scale-ipcache:false
enable-k8s-endpoint-slice:true
log-system-load:false
bpf-lb-service-map-max:0
ingress-secrets-namespace:
config-dir:/tmp/cilium/config-map
derive-masq-ip-addr-from-device:
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
trace-payloadlen:128
enable-gateway-api:false
enable-node-selector-labels:false
proxy-xff-num-trusted-hops-ingress:0
envoy-keep-cap-netbindservice:false
set-cilium-node-taints:true
route-metric:0
nat-map-stats-interval:30s
ip-masq-agent-config-path:/etc/config/ip-masq-agent
nodes-gc-interval:5m0s
enable-ipip-termination:false
http-idle-timeout:0
bpf-fragments-map-max:8192
prepend-iptables-chains:true
policy-cidr-match-mode:
cluster-pool-ipv4-cidr:10.51.0.0/16
max-internal-timer-delay:0s
mesh-auth-mutual-listener-port:0
tofqdns-min-ttl:0
tofqdns-dns-reject-response-code:refused
lib-dir:/var/lib/cilium
datapath-mode:veth
ipv4-node:auto
enable-bgp-control-plane:false
enable-xt-socket-fallback:true
proxy-admin-port:0
enable-endpoint-health-checking:true
cilium-endpoint-gc-interval:5m0s
ipv4-range:auto
tunnel-port:0
tofqdns-enable-dns-compression:true
hubble-redact-http-headers-allow:
hubble-event-buffer-capacity:4095
bpf-lb-dsr-l4-xlate:frontend
egress-gateway-policy-map-max:16384
multicast-enabled:false
k8s-kubeconfig-path:
hubble-redact-http-urlquery:false
enable-wireguard:false
enable-ipv4-egress-gateway:false
enable-k8s-terminating-endpoint:true
egress-masquerade-interfaces:ens+
nodeport-addresses:
identity-heartbeat-timeout:30m0s
cmdref:
set-cilium-is-up-condition:true
k8s-api-server:
enable-bbr:false
bpf-lb-algorithm:random
clustermesh-sync-timeout:1m0s
bpf-ct-timeout-service-any:1m0s
metrics:
monitor-aggregation-interval:5s
kvstore-lease-ttl:15m0s
mesh-auth-gc-interval:5m0s
container-ip-local-reserved-ports:auto
mesh-auth-mutual-connect-timeout:5s
enable-bpf-clock-probe:false
agent-labels:
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
k8s-client-connection-timeout:30s
node-port-range:
clustermesh-ip-identities-sync-timeout:1m0s
local-router-ipv4:
enable-local-node-route:true
use-cilium-internal-ip-for-ipsec:false
encrypt-interface:
kube-proxy-replacement:false
clustermesh-enable-mcs-api:false
clustermesh-config:/var/lib/cilium/clustermesh/
enable-ipsec:false
tunnel-protocol:vxlan
bpf-sock-rev-map-max:262144
pprof-port:6060
vtep-mac:
state-dir:/var/run/cilium
k8s-namespace:kube-system
enable-auto-protect-node-port-range:true
hubble-disable-tls:false
enable-ipv4-big-tcp:false
agent-health-port:9879
dnsproxy-concurrency-processing-grace-period:0s
node-labels:
enable-svc-source-range-check:true
vtep-cidr:
disable-endpoint-crd:false
policy-trigger-interval:1s
external-envoy-proxy:true
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
enable-ipv6-masquerade:true
bpf-events-policy-verdict-enabled:true
http-retry-count:3
devices:
restore:true
node-port-acceleration:disabled
hubble-export-file-path:
enable-encryption-strict-mode:false
enable-policy:default
enable-nat46x64-gateway:false
endpoint-bpf-prog-watchdog-interval:30s
mke-cgroup-mount:
dnsproxy-concurrency-limit:0
gops-port:9890
node-port-bind-protection:true
hubble-export-file-compress:false
ipsec-key-file:
enable-vtep:false
identity-change-grace-period:5s
bpf-lb-source-range-map-max:0
hubble-drop-events-reasons:auth_required,policy_denied
kvstore-periodic-sync:5m0s
hubble-metrics:
ipv6-native-routing-cidr:
force-device-detection:false
allow-icmp-frag-needed:true
clustermesh-enable-endpoint-sync:false
ipv6-mcast-device:
auto-create-cilium-node-resource:true
enable-endpoint-routes:false
dnsproxy-lock-count:131
labels:
synchronize-k8s-nodes:true
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
envoy-log:
kvstore-connectivity-timeout:2m0s
bpf-map-event-buffers:
bypass-ip-availability-upon-restore:false
hubble-socket-path:/var/run/cilium/hubble.sock
nat-map-stats-entries:32
endpoint-gc-interval:5m0s
hubble-drop-events:false
bgp-announce-pod-cidr:false
socket-path:/var/run/cilium/cilium.sock
cni-chaining-mode:none
k8s-client-qps:10
l2-pod-announcements-interface:
bpf-lb-sock-terminate-pod-connections:false
enable-ipv4-masquerade:true
cluster-id:52
gateway-api-secrets-namespace:
srv6-encap-mode:reduced
bpf-lb-external-clusterip:false
enable-k8s:true
bpf-lb-sock-hostns-only:false
ipam:cluster-pool
enable-ipv4:true
proxy-max-requests-per-connection:0
local-max-addr-scope:252
hubble-export-allowlist:
debug:false
enable-ipv6-ndp:false
ipam-multi-pool-pre-allocation:
enable-ingress-controller:false
enable-runtime-device-detection:true
enable-l2-announcements:false
encrypt-node:false
kvstore-opt:
bpf-ct-timeout-service-tcp-grace:1m0s
cni-log-file:/var/run/cilium/cilium-cni.log
custom-cni-conf:false
wireguard-persistent-keepalive:0s
trace-sock:true
enable-l2-pod-announcements:false
enable-envoy-config:false
enable-node-port:false
proxy-connect-timeout:2
annotate-k8s-node:false
conntrack-gc-max-interval:0s
hubble-export-file-max-size-mb:10
l2-announcements-lease-duration:15s
bpf-policy-map-full-reconciliation-interval:15m0s
direct-routing-device:
envoy-base-id:0
k8s-service-cache-size:128
hubble-redact-http-userinfo:true
hubble-skip-unknown-cgroup-ids:true
vtep-mask:
enable-hubble-recorder-api:true
exclude-local-address:
policy-audit-mode:false
bpf-map-dynamic-size-ratio:0.0025
enable-stale-cilium-endpoint-cleanup:true
proxy-max-connection-duration-seconds:0
join-cluster:false
bpf-lb-service-backend-map-max:0
encryption-strict-mode-cidr:
hubble-export-denylist:
dns-policy-unload-on-shutdown:false
enable-ipsec-encrypted-overlay:false
enable-pmtu-discovery:false
http-request-timeout:3600
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
hubble-metrics-server:
bpf-lb-rss-ipv6-src-cidr:
service-no-backend-response:reject
pprof:false
cluster-pool-ipv4-mask-size:24
policy-queue-size:100
dnsproxy-insecure-skip-transparent-mode-check:false
iptables-lock-timeout:5s
fixed-identity-mapping:
disable-envoy-version-check:false
enable-host-firewall:false
enable-wireguard-userspace-fallback:false
proxy-xff-num-trusted-hops-egress:0
mesh-auth-spiffe-trust-domain:spiffe.cilium
bpf-lb-rss-ipv4-src-cidr:
bgp-config-path:/var/lib/cilium/bgp/config.yaml
enable-ipsec-key-watcher:true
endpoint-queue-size:25
proxy-portrange-min:10000
cni-chaining-target:
encryption-strict-mode-allow-remote-node-identities:false
bpf-lb-sock:false
vlan-bpf-bypass:
node-port-algorithm:random
enable-custom-calls:false
enable-health-check-nodeport:true
bpf-ct-global-any-max:262144
dnsproxy-lock-timeout:500ms
operator-prometheus-serve-addr::9963
log-driver:
bpf-neigh-global-max:524288
l2-announcements-retry-period:2s
bpf-policy-map-max:16384
enable-service-topology:false
```


#### Policy get

```
:
 []
Revision: 1

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.51.0.19": (string) (len=50) "kube-system/clustermesh-apiserver-7769dd85f8-ln6cv",
  (string) (len=11) "10.51.0.216": (string) (len=6) "router",
  (string) (len=11) "10.51.0.173": (string) (len=6) "health",
  (string) (len=11) "10.51.0.132": (string) (len=35) "kube-system/coredns-cc6ccd49c-djs4m",
  (string) (len=11) "10.51.0.169": (string) (len=35) "kube-system/coredns-cc6ccd49c-57kww"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.245.66": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40025828f0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x400238b560,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x400238b560,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x40025e2dc0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x40025e2f20)(frontends:[10.100.28.187]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x40025e2fd0)(frontends:[10.100.0.10]/ports=[metrics dns dns-tcp]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x400302d550)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x400302d6b0)(frontends:[10.100.90.213]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4001652100)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40026f0680)(172.31.162.207:443/TCP,172.31.205.71:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4001652108)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-mkxsv": (*k8s.Endpoints)(0x4002d175f0)(172.31.245.66:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4001652110)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-2vsvk": (*k8s.Endpoints)(0x4003787930)(10.51.0.132:53/TCP[eu-west-3b],10.51.0.132:53/UDP[eu-west-3b],10.51.0.132:9153/TCP[eu-west-3b],10.51.0.169:53/TCP[eu-west-3b],10.51.0.169:53/UDP[eu-west-3b],10.51.0.169:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x400113e958)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-29w78": (*k8s.Endpoints)(0x40026f00d0)(10.51.0.19:2379/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001cd3c70)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x400207f5e0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400b061bd8
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4001fcfe00,
  gcExited: (chan struct {}) 0x4001fcfe60,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4002447c80)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001653190)({
      MetricVec: (*prometheus.MetricVec)(0x4000c66690)({
       metricMap: (*prometheus.metricMap)(0x4000c66720)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025b0720)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4002447d00)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001653198)({
      MetricVec: (*prometheus.MetricVec)(0x4000c667e0)({
       metricMap: (*prometheus.metricMap)(0x4000c66810)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025b0780)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4002447d80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40016531a0)({
      MetricVec: (*prometheus.MetricVec)(0x4000c66870)({
       metricMap: (*prometheus.metricMap)(0x4000c668d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025b07e0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4002447e00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40016531a8)({
      MetricVec: (*prometheus.MetricVec)(0x4000c66930)({
       metricMap: (*prometheus.metricMap)(0x4000c66960)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025b0840)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4002447e80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40016531b0)({
      MetricVec: (*prometheus.MetricVec)(0x4000c669f0)({
       metricMap: (*prometheus.metricMap)(0x4000c66ab0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025b08a0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4002447f00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40016531b8)({
      MetricVec: (*prometheus.MetricVec)(0x4000c66b10)({
       metricMap: (*prometheus.metricMap)(0x4000c66b40)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025b0900)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x40014b8000)({
     GaugeVec: (*prometheus.GaugeVec)(0x40016531c0)({
      MetricVec: (*prometheus.MetricVec)(0x4000c66c00)({
       metricMap: (*prometheus.metricMap)(0x4000c66c60)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025b0960)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x40014b8080)({
     GaugeVec: (*prometheus.GaugeVec)(0x40016531c8)({
      MetricVec: (*prometheus.MetricVec)(0x4000c66d20)({
       metricMap: (*prometheus.metricMap)(0x4000c66d50)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025b09c0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x40014b8100)({
     ObserverVec: (*prometheus.HistogramVec)(0x40016531d0)({
      MetricVec: (*prometheus.MetricVec)(0x4000c66db0)({
       metricMap: (*prometheus.metricMap)(0x4000c66e10)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025b0a20)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001cd3c70)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40024799d0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001b8fe48)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 353ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
27         Disabled           Disabled          3459824    k8s:eks.amazonaws.com/component=coredns                                             10.51.0.169   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh52                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
416        Disabled           Disabled          3440100    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.51.0.19    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh52                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
849        Disabled           Disabled          4          reserved:health                                                                     10.51.0.173   ready   
2003       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                
                                                           reserved:host                                                                                             
2348       Disabled           Disabled          3459824    k8s:eks.amazonaws.com/component=coredns                                             10.51.0.132   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh52                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
```

#### BPF Policy Get 27

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    53563   614       0        
Allow    Egress      0          ANY          NONE         disabled    11685   116       0        

```


#### BPF CT List 27

```
Invalid argument: unknown type 27
```


#### Endpoint Get 27

```
[
  {
    "id": 27,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-27-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c75437b5-a5c9-4eff-aee9-8f0b0acded3c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-27",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:00.464Z",
            "success-count": 2
          },
          "uuid": "d4f14186-51b6-4946-a979-b43ba208a3e8"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-57kww",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:19:00.463Z",
            "success-count": 1
          },
          "uuid": "4708ef56-4154-4fa1-a338-102cb796b5db"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-27",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:19:02.715Z",
            "success-count": 1
          },
          "uuid": "bf8f3623-b5a8-4f5f-932f-0a28e0a57e95"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (27)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:40.525Z",
            "success-count": 60
          },
          "uuid": "1e4c1dbb-a302-4e94-abf0-e70825cc8ed9"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "5c861ce9b85e0498b09be2ee84933c48df97dac9396a76704f3a10e9192ae264:eth0",
        "container-id": "5c861ce9b85e0498b09be2ee84933c48df97dac9396a76704f3a10e9192ae264",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-57kww",
        "pod-name": "kube-system/coredns-cc6ccd49c-57kww"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3459824,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh52",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh52",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:31Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.51.0.169",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "16:1c:dc:c6:0b:d8",
        "interface-index": 11,
        "interface-name": "lxc81da71635c95",
        "mac": "ca:e9:ac:55:5f:5b"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3459824,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3459824,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 27

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 27

```
Timestamp              Status   State                   Message
2024-10-25T10:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:31Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:19:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:02Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:19:01Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:19:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:19:00Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:19:00Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3459824

```
ID        LABELS
3459824   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh52
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 416

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3104271   31163     0        
Allow    Ingress     1          ANY          NONE         disabled    3080247   31118     0        
Allow    Egress      0          ANY          NONE         disabled    4423536   42096     0        

```


#### BPF CT List 416

```
Invalid argument: unknown type 416
```


#### Endpoint Get 416

```
[
  {
    "id": 416,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-416-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "079d3174-ae58-4532-a159-1673d50b30f4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-416",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:28.564Z",
            "success-count": 2
          },
          "uuid": "403cd4ac-18bf-4e4c-bdf6-5129af81ed50"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-7769dd85f8-ln6cv",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:28.563Z",
            "success-count": 1
          },
          "uuid": "251c929d-f8fc-4b42-9b8f-7e04b7086a05"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-416",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:28.603Z",
            "success-count": 1
          },
          "uuid": "d853dc28-1549-4d85-ae9c-a72dd28f8a96"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (416)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:38.615Z",
            "success-count": 45
          },
          "uuid": "cdfeb08e-7ed7-4f12-b099-6e58bbf6bac5"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "3ca85947f52098476763d9a75c8edcd0f5bf2a9e459f471aef95dd31f74d64a4:eth0",
        "container-id": "3ca85947f52098476763d9a75c8edcd0f5bf2a9e459f471aef95dd31f74d64a4",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-7769dd85f8-ln6cv",
        "pod-name": "kube-system/clustermesh-apiserver-7769dd85f8-ln6cv"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3440100,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh52",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7769dd85f8"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh52",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:31Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.51.0.19",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "4e:74:a1:ce:39:46",
        "interface-index": 15,
        "interface-name": "lxc565b022e6a86",
        "mac": "6e:9e:f1:3f:2f:92"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3440100,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3440100,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 416

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 416

```
Timestamp              Status   State                   Message
2024-10-25T10:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:31Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:28Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:28Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:28Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3440100

```
ID        LABELS
3440100   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh52
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 849

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    392350   5005      0        
Allow    Ingress     1          ANY          NONE         disabled    8156     96        0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 849

```
Invalid argument: unknown type 849
```


#### Endpoint Get 849

```
[
  {
    "id": 849,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-849-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "314c7509-7d93-40aa-8704-0b2493e4545c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-849",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:58.830Z",
            "success-count": 2
          },
          "uuid": "68b621d5-04bd-4543-9e3f-0e112f006a4b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-849",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:19:02.635Z",
            "success-count": 1
          },
          "uuid": "e3a4be1a-7d2f-46ba-b61a-e9ebf23ad9c9"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:31Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.51.0.173",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "d6:7c:66:8c:7d:ea",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "1e:06:6f:fc:20:0d"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 849

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 849

```
Timestamp              Status   State                   Message
2024-10-25T10:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:31Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:19:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:02Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:19:02Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:19:01Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:19:00Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:18:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:18:58Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:18:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:18:58Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:18:57Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 2003

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2003

```
Invalid argument: unknown type 2003
```


#### Endpoint Get 2003

```
[
  {
    "id": 2003,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2003-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "001a587b-dfc7-495e-9b34-785f485468dd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2003",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:57.752Z",
            "success-count": 2
          },
          "uuid": "208f3bac-9e96-4161-a115-9677c8cd79ec"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2003",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:18:58.934Z",
            "success-count": 1
          },
          "uuid": "53d146f7-67f6-4b3f-8afa-eb0018555bac"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:31Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "72:04:55:15:ae:37",
        "interface-name": "cilium_host",
        "mac": "72:04:55:15:ae:37"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2003

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2003

```
Timestamp              Status   State                   Message
2024-10-25T10:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:31Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:01Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:19:01Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:19:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:59Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:18:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:18:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:18:57Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:18:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:18:57Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:18:57Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 2348

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    53365   611       0        
Allow    Egress      0          ANY          NONE         disabled    11305   112       0        

```


#### BPF CT List 2348

```
Invalid argument: unknown type 2348
```


#### Endpoint Get 2348

```
[
  {
    "id": 2348,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2348-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "3ce6aa9e-a170-45a8-8ca0-1cbb9f250056"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2348",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:00.368Z",
            "success-count": 2
          },
          "uuid": "4a1ba33a-70ae-467a-b5e8-17957c3f34ed"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-djs4m",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:19:00.364Z",
            "success-count": 1
          },
          "uuid": "34343dd7-2b3b-4d6e-8903-13a1ed53335e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2348",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:19:02.658Z",
            "success-count": 1
          },
          "uuid": "aa22bdc7-e76d-490d-bf86-c557684cb340"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2348)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:40.437Z",
            "success-count": 60
          },
          "uuid": "6a00342d-72da-42b4-9c46-eabd7187917d"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "79a36952de0739014213fea9a8ca6eecb8e7dc6840464f2f0038565acea02e42:eth0",
        "container-id": "79a36952de0739014213fea9a8ca6eecb8e7dc6840464f2f0038565acea02e42",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-djs4m",
        "pod-name": "kube-system/coredns-cc6ccd49c-djs4m"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3459824,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh52",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh52",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:31Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.51.0.132",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "5a:e3:fb:92:51:de",
        "interface-index": 9,
        "interface-name": "lxc171acd07ba98",
        "mac": "12:12:61:76:a2:08"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3459824,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3459824,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2348

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2348

```
Timestamp              Status    State                   Message
2024-10-25T10:22:31Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:31Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:31Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:22:31Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:30Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:30Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:30Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:30Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:29Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:29Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:29Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:29Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:14Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:14Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:14Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:14Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:13Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:13Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:13Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:13Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:02Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:02Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:19:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:01Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:19:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:19:00Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:19:00Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:00Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 3459824

```
ID        LABELS
3459824   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh52
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### Service list

```
ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.205.71:443 (active)    
                                         2 => 172.31.162.207:443 (active)   
2    10.100.28.187:443    ClusterIP      1 => 172.31.245.66:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.51.0.169:53 (active)       
                                         2 => 10.51.0.132:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.51.0.169:9153 (active)     
                                         2 => 10.51.0.132:9153 (active)     
5    10.100.90.213:2379   ClusterIP      1 => 10.51.0.19:2379 (active)      
```

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 12641089                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 12641089                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 12641089                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400c400000 rw-p 00000000 00:00 0 
400c400000-4010000000 ---p 00000000 00:00 0 
ffff463bf000-ffff465f5000 rw-p 00000000 00:00 0 
ffff465fd000-ffff466de000 rw-p 00000000 00:00 0 
ffff466de000-ffff4671f000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff4671f000-ffff46760000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff46760000-ffff467a0000 rw-p 00000000 00:00 0 
ffff467a0000-ffff467a2000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff467a2000-ffff467a4000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff467a4000-ffff46d3b000 rw-p 00000000 00:00 0 
ffff46d3b000-ffff46e3b000 rw-p 00000000 00:00 0 
ffff46e3b000-ffff46e4c000 rw-p 00000000 00:00 0 
ffff46e4c000-ffff48e4c000 rw-p 00000000 00:00 0 
ffff48e4c000-ffff48ecc000 ---p 00000000 00:00 0 
ffff48ecc000-ffff48ecd000 rw-p 00000000 00:00 0 
ffff48ecd000-ffff68ecc000 ---p 00000000 00:00 0 
ffff68ecc000-ffff68ecd000 rw-p 00000000 00:00 0 
ffff68ecd000-ffff88e5c000 ---p 00000000 00:00 0 
ffff88e5c000-ffff88e5d000 rw-p 00000000 00:00 0 
ffff88e5d000-ffff8ce4e000 ---p 00000000 00:00 0 
ffff8ce4e000-ffff8ce4f000 rw-p 00000000 00:00 0 
ffff8ce4f000-ffff8d64c000 ---p 00000000 00:00 0 
ffff8d64c000-ffff8d64d000 rw-p 00000000 00:00 0 
ffff8d64d000-ffff8d74c000 ---p 00000000 00:00 0 
ffff8d74c000-ffff8d7ac000 rw-p 00000000 00:00 0 
ffff8d7ac000-ffff8d7ae000 r--p 00000000 00:00 0                          [vvar]
ffff8d7ae000-ffff8d7af000 r-xp 00000000 00:00 0                          [vdso]
ffffcd21b000-ffffcd23c000 rw-p 00000000 00:00 0                          [stack]

```

