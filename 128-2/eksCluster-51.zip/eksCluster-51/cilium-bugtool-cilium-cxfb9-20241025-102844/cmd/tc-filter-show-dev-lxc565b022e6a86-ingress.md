filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc565b022e6a86 direct-action not_in_hw id 573 tag f91c0c116ed68241 jited 
