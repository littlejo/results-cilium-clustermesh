markdown output at /tmp/cilium-bugtool-20241025-102845.872+0000-UTC-1445513837/cmd/cilium-debuginfo-20241025-102846.488+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102845.872+0000-UTC-1445513837/cmd/cilium-debuginfo-20241025-102846.488+0000-UTC.json
