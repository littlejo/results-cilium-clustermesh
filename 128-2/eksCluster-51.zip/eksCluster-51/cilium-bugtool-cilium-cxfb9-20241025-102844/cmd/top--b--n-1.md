top - 10:28:46 up 10 min,  0 users,  load average: 0.23, 0.43, 0.33
Tasks:   5 total,   1 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 24.1 us, 31.0 sy,  0.0 ni, 44.8 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1200.5 free,    879.4 used,   1756.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2788.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1472496 275648  77564 S  46.7   7.0   0:24.42 cilium-+
    404 root      20   0 1228848   6656   3840 S   0.0   0.2   0:00.28 cilium-+
    643 root      20   0 1240432  16196  11164 S   0.0   0.4   0:00.02 cilium-+
    669 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    693 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
