ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.253.206:443 (active)    
                                         2 => 172.31.147.177:443 (active)    
2    10.100.177.252:443   ClusterIP      1 => 172.31.186.243:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.94.0.192:53 (active)        
                                         2 => 10.94.0.161:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.94.0.192:9153 (active)      
                                         2 => 10.94.0.161:9153 (active)      
5    10.100.113.66:2379   ClusterIP      1 => 10.94.0.121:2379 (active)      
