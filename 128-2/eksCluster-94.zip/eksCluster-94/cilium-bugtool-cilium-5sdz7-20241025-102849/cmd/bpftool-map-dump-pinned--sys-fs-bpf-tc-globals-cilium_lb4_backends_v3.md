key: 02 00 00 00  value: ac 1f ba f3 10 94 00 00  00 00 00 00
key: 05 00 00 00  value: 0a 5e 00 a1 00 35 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 5e 00 a1 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 5e 00 79 09 4b 00 00  00 00 00 00
key: 03 00 00 00  value: 0a 5e 00 c0 23 c1 00 00  00 00 00 00
key: 07 00 00 00  value: ac 1f 93 b1 01 bb 00 00  00 00 00 00
key: 04 00 00 00  value: 0a 5e 00 c0 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f fd ce 01 bb 00 00  00 00 00 00
Found 8 elements
