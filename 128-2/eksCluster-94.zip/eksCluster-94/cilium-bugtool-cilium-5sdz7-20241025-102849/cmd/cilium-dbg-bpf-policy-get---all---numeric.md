Endpoint ID: 254
Path: /sys/fs/bpf/tc/globals/cilium_policy_00254

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    59292   683       0        
Allow    Egress      0          ANY          NONE         disabled    12054   121       0        


Endpoint ID: 728
Path: /sys/fs/bpf/tc/globals/cilium_policy_00728

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    441686   5640      0        
Allow    Ingress     1          ANY          NONE         disabled    8184     94        0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1808
Path: /sys/fs/bpf/tc/globals/cilium_policy_01808

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3914983   36303     0        
Allow    Ingress     1          ANY          NONE         disabled    3023808   30398     0        
Allow    Egress      0          ANY          NONE         disabled    3930598   36537     0        


Endpoint ID: 2265
Path: /sys/fs/bpf/tc/globals/cilium_policy_02265

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    58896   677       0        
Allow    Egress      0          ANY          NONE         disabled    11818   118       0        


Endpoint ID: 3668
Path: /sys/fs/bpf/tc/globals/cilium_policy_03668

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


