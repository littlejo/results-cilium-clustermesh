 10:28:50 up 10 min,  0 users,  load average: 0.25, 0.23, 0.18
