35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:18:08+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:18:08+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:18:09+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:18:09+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:09+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:18:09+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:18:09+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:18:09+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:18:13+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
61: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
64: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
71: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:18:26+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
72: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
75: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
447: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 112
448: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 113
449: sched_cls  name tail_handle_ipv4  tag 6e890104e3f79565  gpl
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 114
450: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:18:52+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 115
451: sched_cls  name __send_drop_notify  tag 84cbbb0a5166c06e  gpl
	loaded_at 2024-10-25T10:18:53+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 117
452: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:18:53+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,92
	btf_id 118
454: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:18:53+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 120
455: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:18:53+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,92
	btf_id 121
457: sched_cls  name tail_handle_ipv4_from_host  tag 8270061f91daaea5  gpl
	loaded_at 2024-10-25T10:18:53+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,92
	btf_id 123
458: sched_cls  name tail_handle_ipv4_from_host  tag 8270061f91daaea5  gpl
	loaded_at 2024-10-25T10:18:53+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,94
	btf_id 125
459: sched_cls  name __send_drop_notify  tag 84cbbb0a5166c06e  gpl
	loaded_at 2024-10-25T10:18:53+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 126
460: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:18:53+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,94
	btf_id 127
462: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:18:53+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 129
466: sched_cls  name tail_handle_ipv4_from_host  tag 8270061f91daaea5  gpl
	loaded_at 2024-10-25T10:18:53+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,95
	btf_id 134
467: sched_cls  name __send_drop_notify  tag 84cbbb0a5166c06e  gpl
	loaded_at 2024-10-25T10:18:53+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 135
468: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:18:53+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,95
	btf_id 136
469: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:18:53+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,95,67
	btf_id 137
474: sched_cls  name tail_handle_ipv4  tag a9229c262ab1107e  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,100
	btf_id 144
478: sched_cls  name tail_ipv4_ct_ingress  tag feeacbb6de2db024  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,100,74,75,101,76
	btf_id 146
479: sched_cls  name tail_handle_arp  tag 09760f3d364687a2  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,100
	btf_id 150
484: sched_cls  name handle_policy  tag e3083481a5c8b33d  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,100,74,75,101,33,72,97,31,76,67,32,29,30
	btf_id 151
488: sched_cls  name tail_ipv4_ct_egress  tag 153dfaacbd7c52f2  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,100,74,75,101,76
	btf_id 156
489: sched_cls  name __send_drop_notify  tag 17993f526c4dc5be  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 159
490: sched_cls  name tail_handle_ipv4_cont  tag 67eac26cbc0dd16f  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,101,33,97,74,75,31,68,66,69,100,32,29,30,73
	btf_id 160
491: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,104
	btf_id 162
492: sched_cls  name cil_from_container  tag f760fcbfbd0bcb40  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 104,68
	btf_id 163
493: sched_cls  name tail_ipv4_to_endpoint  tag 056cba1ef3fd23b7  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,103,33,74,75,72,102,31,104,32,29,30
	btf_id 164
494: sched_cls  name __send_drop_notify  tag 9d61a90147174701  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 166
496: sched_cls  name tail_ipv4_to_endpoint  tag c6a0e9b9f0020b58  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,101,33,74,75,72,97,31,100,32,29,30
	btf_id 165
497: sched_cls  name cil_from_container  tag 77d1b9685d26fbd3  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 100,68
	btf_id 169
498: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,100
	btf_id 170
499: sched_cls  name handle_policy  tag e64d0344c53f2763  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,104,74,75,103,33,72,102,31,76,67,32,29,30
	btf_id 168
500: sched_cls  name tail_ipv4_ct_ingress  tag ad75575a50bf42dd  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 173
501: sched_cls  name tail_handle_ipv4_cont  tag 72493c8ed314dc52  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,106,33,90,74,75,31,68,66,69,105,32,29,30,73
	btf_id 172
502: sched_cls  name tail_handle_ipv4_cont  tag 55095c6912fe5c9f  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,103,33,102,74,75,31,68,66,69,104,32,29,30,73
	btf_id 174
503: sched_cls  name tail_handle_ipv4  tag f1583e09438f634a  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,105
	btf_id 175
504: sched_cls  name tail_handle_ipv4  tag 877e650533197d42  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,104
	btf_id 176
505: sched_cls  name tail_ipv4_ct_ingress  tag 53126b6dd99396eb  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,105,74,75,106,76
	btf_id 177
506: sched_cls  name tail_handle_arp  tag 52d505b5dad19fc2  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,104
	btf_id 178
507: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,105
	btf_id 179
508: sched_cls  name tail_ipv4_ct_egress  tag 153dfaacbd7c52f2  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 180
509: sched_cls  name handle_policy  tag 260f9356f3af9f02  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,105,74,75,106,33,72,90,31,76,67,32,29,30
	btf_id 181
510: sched_cls  name tail_handle_arp  tag 145a3bbff00713d6  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,105
	btf_id 182
511: sched_cls  name tail_ipv4_to_endpoint  tag f35f29cc864e655f  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,106,33,74,75,72,90,31,105,32,29,30
	btf_id 183
512: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,105,74,75,106,76
	btf_id 184
513: sched_cls  name __send_drop_notify  tag ca831355bce09fd1  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 185
514: sched_cls  name cil_from_container  tag a2430a9826ee77c5  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 105,68
	btf_id 186
516: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
519: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
520: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
523: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
524: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
527: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
528: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:18:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
531: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:18:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
571: sched_cls  name tail_handle_ipv4  tag 4a7142a899168e61  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,123
	btf_id 203
572: sched_cls  name tail_ipv4_ct_ingress  tag d56530efce9551c5  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,123,74,75,122,76
	btf_id 204
573: sched_cls  name __send_drop_notify  tag 3b1d198471137107  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 205
575: sched_cls  name tail_handle_arp  tag d786e8c902d1db4e  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,123
	btf_id 207
576: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,123
	btf_id 208
577: sched_cls  name cil_from_container  tag c5a7694ff5c731b3  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 123,68
	btf_id 209
578: sched_cls  name tail_ipv4_ct_egress  tag 3dfd22891aa56666  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,123,74,75,122,76
	btf_id 210
579: sched_cls  name tail_ipv4_to_endpoint  tag 068058965b2667c2  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,122,33,74,75,72,121,31,123,32,29,30
	btf_id 211
580: sched_cls  name handle_policy  tag 8490856d9993c172  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,123,74,75,122,33,72,121,31,76,67,32,29,30
	btf_id 212
581: sched_cls  name tail_handle_ipv4_cont  tag 28b5181c040136db  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,122,33,121,74,75,31,68,66,69,123,32,29,30,73
	btf_id 213
582: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
585: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
598: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
601: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
602: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
605: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
606: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
609: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
