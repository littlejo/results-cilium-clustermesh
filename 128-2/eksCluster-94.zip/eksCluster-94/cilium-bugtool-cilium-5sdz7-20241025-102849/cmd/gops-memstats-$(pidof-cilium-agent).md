alloc: 69.33MB (72695768 bytes)
total-alloc: 1.31GB (1405014144 bytes)
sys: 206.38MB (216409428 bytes)
lookups: 0
mallocs: 47473583
frees: 46969009
heap-alloc: 69.33MB (72695768 bytes)
heap-sys: 163.54MB (171483136 bytes)
heap-idle: 55.16MB (57835520 bytes)
heap-in-use: 108.38MB (113647616 bytes)
heap-released: 2.84MB (2973696 bytes)
heap-objects: 504574
stack-in-use: 32.44MB (34013184 bytes)
stack-sys: 32.44MB (34013184 bytes)
stack-mspan-inuse: 1.82MB (1909280 bytes)
stack-mspan-sys: 2.43MB (2545920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 980.68KB (1004217 bytes)
gc-sys: 5.11MB (5357632 bytes)
next-gc: when heap-alloc >= 147.19MB (154335336 bytes)
last-gc: 2024-10-25 10:29:19.203743118 +0000 UTC
gc-pause-total: 8.958536ms
gc-pause: 68226
gc-pause-end: 1729852159203743118
num-gc: 71
num-forced-gc: 0
gc-cpu-fraction: 0.000360840015914899
enable-gc: true
debug-gc: false
