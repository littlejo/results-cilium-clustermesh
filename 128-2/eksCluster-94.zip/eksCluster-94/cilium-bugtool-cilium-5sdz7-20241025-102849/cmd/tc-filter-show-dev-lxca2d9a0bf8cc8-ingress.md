filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxca2d9a0bf8cc8 direct-action not_in_hw id 492 tag f760fcbfbd0bcb40 jited 
