fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxcae150a15d24c proto kernel metric 256 pref medium
fe80::/64 dev lxca2d9a0bf8cc8 proto kernel metric 256 pref medium
fe80::/64 dev lxc7053e67ac577 proto kernel metric 256 pref medium
