REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     212343    98953908   1132   bpf_host.c
Interface                 INGRESS     9564      746858     677    bpf_overlay.c
Success                   EGRESS      4587      350103     1694   bpf_host.c
Success                   EGRESS      88293     12091147   1308   bpf_lxc.c
Success                   EGRESS      9385      734195     53     encap.h
Success                   INGRESS     100457    12217304   86     l3.h
Success                   INGRESS     106083    12657965   235    trace.h
Unsupported L3 protocol   EGRESS      36        2692       1492   bpf_lxc.c
