IP ADDRESS         LOCAL ENDPOINT INFO
10.94.0.192:0      id=2265  sec_id=6232298 flags=0x0000 ifindex=9   mac=6A:96:39:BB:DC:52 nodemac=FA:CC:1F:58:08:19   
10.94.0.119:0      (localhost)                                                                                        
10.94.0.74:0       id=728   sec_id=4     flags=0x0000 ifindex=7   mac=86:1B:8C:13:2A:6F nodemac=B2:F0:8D:C6:EA:AC     
10.94.0.121:0      id=1808  sec_id=6246044 flags=0x0000 ifindex=15  mac=8A:D4:F4:A7:0C:96 nodemac=82:65:D2:2F:C3:7D   
10.94.0.161:0      id=254   sec_id=6232298 flags=0x0000 ifindex=11  mac=DE:63:EF:7D:9D:10 nodemac=1E:1D:B4:4C:7B:2B   
172.31.186.243:0   (localhost)                                                                                        
