xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 469
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 462
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 454
cilium_host(4) clsact/egress cil_from_host-cilium_host id 455
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 450
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 447
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 514
lxcae150a15d24c(9) clsact/ingress cil_from_container-lxcae150a15d24c id 497
lxca2d9a0bf8cc8(11) clsact/ingress cil_from_container-lxca2d9a0bf8cc8 id 492
lxc7053e67ac577(15) clsact/ingress cil_from_container-lxc7053e67ac577 id 577

flow_dissector:

netfilter:

