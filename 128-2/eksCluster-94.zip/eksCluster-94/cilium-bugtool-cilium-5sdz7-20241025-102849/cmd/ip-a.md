1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:f3:aa:0e:63:6d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.186.243/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2965sec preferred_lft 2965sec
    inet6 fe80::4f3:aaff:fe0e:636d/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:99:5a:3d:e6:87 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::bc99:5aff:fe3d:e687/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:34:2a:97:45:01 brd ff:ff:ff:ff:ff:ff
    inet 10.94.0.119/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::e834:2aff:fe97:4501/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether d6:c4:f9:0c:5f:6b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d4c4:f9ff:fe0c:5f6b/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:f0:8d:c6:ea:ac brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::b0f0:8dff:fec6:eaac/64 scope link 
       valid_lft forever preferred_lft forever
9: lxcae150a15d24c@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:cc:1f:58:08:19 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::f8cc:1fff:fe58:819/64 scope link 
       valid_lft forever preferred_lft forever
11: lxca2d9a0bf8cc8@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:1d:b4:4c:7b:2b brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::1c1d:b4ff:fe4c:7b2b/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc7053e67ac577@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:65:d2:2f:c3:7d brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::8065:d2ff:fe2f:c37d/64 scope link 
       valid_lft forever preferred_lft forever
