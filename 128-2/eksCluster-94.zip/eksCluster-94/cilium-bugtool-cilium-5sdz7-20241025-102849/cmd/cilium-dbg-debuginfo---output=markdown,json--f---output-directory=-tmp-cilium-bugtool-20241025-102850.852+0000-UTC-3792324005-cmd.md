markdown output at /tmp/cilium-bugtool-20241025-102850.852+0000-UTC-3792324005/cmd/cilium-debuginfo-20241025-102921.317+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102850.852+0000-UTC-3792324005/cmd/cilium-debuginfo-20241025-102921.317+0000-UTC.json
