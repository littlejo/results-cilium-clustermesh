top - 10:28:51 up 10 min,  0 users,  load average: 0.25, 0.23, 0.18
Tasks:   7 total,   2 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 13.3 us, 23.3 sy,  0.0 ni, 60.0 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   3836.2 total,   1194.5 free,    886.4 used,   1755.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2781.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 275960  78276 S   6.7   7.0   0:16.01 cilium-+
    392 root      20   0 1228848   6892   3836 S   0.0   0.2   0:00.22 cilium-+
    650 root      20   0 1240432  16792  11484 S   0.0   0.4   0:00.02 cilium-+
    670 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    697 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    715 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
    720 root      20   0   13060   1228     60 R   0.0   0.0   0:00.00 runc:[2+
