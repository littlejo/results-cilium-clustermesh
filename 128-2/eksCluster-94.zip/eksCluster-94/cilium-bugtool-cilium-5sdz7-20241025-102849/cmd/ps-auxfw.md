USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         670  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root         650  0.0  0.4 1240432 16476 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         686  0.0  0.0   6408  1640 ?        R    10:28   0:00  \_ ps auxfw
root         687  0.0  0.0   3852  1288 ?        R    10:28   0:00  \_ bash -c hostname
root           1  2.6  7.0 1538100 275960 ?      Ssl  10:18   0:16 cilium-agent --config-dir=/tmp/cilium/config-map
root         392  0.0  0.1 1228848 6892 ?        Sl   10:18   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
