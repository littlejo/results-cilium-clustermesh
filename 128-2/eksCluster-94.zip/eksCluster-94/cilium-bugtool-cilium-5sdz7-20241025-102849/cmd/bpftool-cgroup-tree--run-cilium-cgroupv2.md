CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd133fd0c_1a29_469a_a842_6ac6aed0b38e.slice/cri-containerd-b9aef41c869786c0f64d7b06416cd849be3093757aa3d9b8b501f1444342a21f.scope
    71       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd133fd0c_1a29_469a_a842_6ac6aed0b38e.slice/cri-containerd-42d3753f2fb26afd92e4c1d68785833e18c10c5a45293dd29d715e8451cf97da.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2c388e37_bc96_489f_b7ba_17e20be5a858.slice/cri-containerd-6c2f195e63d62717d36f180dd947fc3c72488c6b579ec9afde6da7c7a8191405.scope
    531      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2c388e37_bc96_489f_b7ba_17e20be5a858.slice/cri-containerd-7fc92696fc63f1999f6e2bdae3b037fbf8e5db43f2c489c9056df07038147417.scope
    523      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod60cd6898_8391_4b95_8bc7_bfcaffa7250f.slice/cri-containerd-74d2f2bbd413e75be6bbfd53b44da29bf8a86779ded4dc0244f010d5bfd435d3.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod60cd6898_8391_4b95_8bc7_bfcaffa7250f.slice/cri-containerd-ed56951c9b36e578a4d86e34c5ca4a05c6d3638960804d817f5d190b70291bb8.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a7ba732_6cfd_4764_be26_52a8c68a35bb.slice/cri-containerd-32da332187bad58241f2386df80128fd26805957ee1d1fdd57d12189e3ff5bee.scope
    527      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a7ba732_6cfd_4764_be26_52a8c68a35bb.slice/cri-containerd-64d7134418bcd154089ff4e80083b516ef31e857c0b68864a91704f5cadcacca.scope
    519      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod59af6b05_6b72_454a_8b6e_54a6010b20dd.slice/cri-containerd-c16669b004bd3c9b4de4f548a7bc85e056413e12111afd263f659441fc1b793a.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod59af6b05_6b72_454a_8b6e_54a6010b20dd.slice/cri-containerd-ba91d93a408a846162ef71073d08d64f1b1b2485fb4b97cab767a72e0cac571b.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa4bcfba_30bf_4d36_ad71_318ea984eed4.slice/cri-containerd-83d59947c634b8109b527c709265466f86b2c6ca2acd21148c217f71d83282d6.scope
    609      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa4bcfba_30bf_4d36_ad71_318ea984eed4.slice/cri-containerd-8f025e0377c1bf01238e3fbce26f1ed290abe2823c419d680566350373a6a012.scope
    605      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa4bcfba_30bf_4d36_ad71_318ea984eed4.slice/cri-containerd-81d892a2f85444111137a26f70e95c82cb83246d47bda7ac4a73ae975b6a5445.scope
    601      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa4bcfba_30bf_4d36_ad71_318ea984eed4.slice/cri-containerd-01da898df2b6300a9556e9f71c9c6551ed4b7c13070a8cc8b8a4b6acf51f0122.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9309bbd5_87c8_426b_bfdb_a21188b10bd1.slice/cri-containerd-654580aa9b6120c134c9cd2fb3999d3217090ecee45c97778a10866a88a60cd6.scope
    64       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9309bbd5_87c8_426b_bfdb_a21188b10bd1.slice/cri-containerd-60ef38fe0474a93b05c790388c7061dfe1427f716c24decbcde36b66d3d8ce08.scope
    79       cgroup_device   multi                                          
