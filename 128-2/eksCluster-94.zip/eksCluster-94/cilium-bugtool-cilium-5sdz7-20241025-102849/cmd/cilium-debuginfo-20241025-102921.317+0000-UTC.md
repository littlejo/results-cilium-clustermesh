# Cilium debug information

#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.94.0.192": (string) (len=35) "kube-system/coredns-cc6ccd49c-5jrpl",
  (string) (len=11) "10.94.0.161": (string) (len=35) "kube-system/coredns-cc6ccd49c-hw98h",
  (string) (len=11) "10.94.0.121": (string) (len=50) "kube-system/clustermesh-apiserver-795cf847cd-b89h6",
  (string) (len=11) "10.94.0.119": (string) (len=6) "router",
  (string) (len=10) "10.94.0.74": (string) (len=6) "health"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.186.243": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001e3c160)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001e38060,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001e38060,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4001f3d8c0)(frontends:[]/ports=[kvmesh-metrics etcd-metrics apiserv-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4001f3d970)(frontends:[10.100.113.66]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4001e3c9a0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4001e3ca50)(frontends:[10.100.177.252]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4001e3cb00)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4000c70438)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-6xnrm": (*k8s.Endpoints)(0x4001b70750)(10.94.0.161:53/TCP[eu-west-3a],10.94.0.161:53/UDP[eu-west-3a],10.94.0.161:9153/TCP[eu-west-3a],10.94.0.192:53/TCP[eu-west-3a],10.94.0.192:53/UDP[eu-west-3a],10.94.0.192:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001486c10)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-tx44p": (*k8s.Endpoints)(0x40001db2b0)(10.94.0.121:2379/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4000c70428)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40031de750)(172.31.147.177:443/TCP,172.31.253.206:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4000c70430)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-pwxvv": (*k8s.Endpoints)(0x4003416ea0)(172.31.186.243:4244/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x400199acb0)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x400200e690)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x40033d0528
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4001997080,
  gcExited: (chan struct {}) 0x40019970e0,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x40019a9300)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001633df8)({
      MetricVec: (*prometheus.MetricVec)(0x4001ccbb00)({
       metricMap: (*prometheus.metricMap)(0x4001ccbb30)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019e5f20)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x40019a9380)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001633e00)({
      MetricVec: (*prometheus.MetricVec)(0x4001ccbb90)({
       metricMap: (*prometheus.metricMap)(0x4001ccbbc0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001cd6000)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x40019a9400)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001633e08)({
      MetricVec: (*prometheus.MetricVec)(0x4001ccbc20)({
       metricMap: (*prometheus.metricMap)(0x4001ccbc50)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001cd6060)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x40019a9480)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001633e10)({
      MetricVec: (*prometheus.MetricVec)(0x4001ccbcb0)({
       metricMap: (*prometheus.metricMap)(0x4001ccbce0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001cd60c0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x40019a9500)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001633e18)({
      MetricVec: (*prometheus.MetricVec)(0x4001ccbd40)({
       metricMap: (*prometheus.metricMap)(0x4001ccbd70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001cd6120)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x40019a9580)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001633e20)({
      MetricVec: (*prometheus.MetricVec)(0x4001ccbdd0)({
       metricMap: (*prometheus.metricMap)(0x4001ccbe00)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001cd6180)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x40019a9600)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001633e28)({
      MetricVec: (*prometheus.MetricVec)(0x4001ccbe60)({
       metricMap: (*prometheus.metricMap)(0x4001ccbe90)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001cd61e0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x40019a9680)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001633e30)({
      MetricVec: (*prometheus.MetricVec)(0x4001ccbef0)({
       metricMap: (*prometheus.metricMap)(0x4001ccbf20)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001cd6240)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x40019a9700)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001633e38)({
      MetricVec: (*prometheus.MetricVec)(0x4001cd8000)({
       metricMap: (*prometheus.metricMap)(0x4001cd8030)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001cd62a0)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x400199acb0)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4000313d50)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001e20348)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 287ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium environment keys

```
dns-policy-unload-on-shutdown:false
max-controller-interval:0
cni-chaining-target:
nodeport-addresses:
bpf-policy-map-full-reconciliation-interval:15m0s
read-cni-conf:
ipv6-native-routing-cidr:
enable-bbr:false
nat-map-stats-entries:32
node-port-mode:snat
enable-l2-announcements:false
bypass-ip-availability-upon-restore:false
bpf-auth-map-max:524288
clustermesh-config:/var/lib/cilium/clustermesh/
enable-hubble:true
enable-health-checking:true
ipam-default-ip-pool:default
certificates-directory:/var/run/cilium/certs
enable-ipv4-egress-gateway:false
kvstore-lease-ttl:15m0s
log-system-load:false
egress-masquerade-interfaces:ens+
cni-exclusive:true
bpf-sock-rev-map-max:262144
restore:true
bpf-lb-affinity-map-max:0
enable-ip-masq-agent:false
tofqdns-pre-cache:
dnsproxy-insecure-skip-transparent-mode-check:false
enable-policy:default
hubble-export-file-compress:false
auto-direct-node-routes:false
install-iptables-rules:true
l2-announcements-retry-period:2s
unmanaged-pod-watcher-interval:15
label-prefix-file:
pprof-port:6060
controller-group-metrics:
egress-gateway-reconciliation-trigger-interval:1s
debug-verbose:
exclude-node-label-patterns:
ingress-secrets-namespace:
k8s-heartbeat-timeout:30s
enable-external-ips:false
k8s-kubeconfig-path:
policy-cidr-match-mode:
exclude-local-address:
hubble-redact-http-userinfo:true
cluster-pool-ipv4-mask-size:24
bpf-node-map-max:16384
kvstore-connectivity-timeout:2m0s
enable-ipv6-masquerade:true
http-request-timeout:3600
enable-host-firewall:false
enable-masquerade-to-route-source:false
pprof-address:localhost
enable-ipsec-xfrm-state-caching:true
vtep-endpoint:
enable-unreachable-routes:false
enable-ipv6-big-tcp:false
bpf-lb-map-max:65536
preallocate-bpf-maps:false
hubble-event-queue-size:0
vtep-mac:
node-port-algorithm:random
enable-pmtu-discovery:false
tofqdns-max-deferred-connection-deletes:10000
hubble-metrics-server:
k8s-namespace:kube-system
tofqdns-idle-connection-grace-period:0s
bpf-nat-global-max:524288
tofqdns-proxy-response-max-delay:100ms
cni-external-routing:false
encryption-strict-mode-allow-remote-node-identities:false
nodes-gc-interval:5m0s
agent-health-port:9879
enable-recorder:false
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
custom-cni-conf:false
k8s-sync-timeout:3m0s
synchronize-k8s-nodes:true
bpf-ct-timeout-regular-tcp-syn:1m0s
bpf-lb-rev-nat-map-max:0
enable-active-connection-tracking:false
cluster-pool-ipv4-cidr:10.94.0.0/16
clustermesh-enable-mcs-api:false
hubble-flowlogs-config-path:
envoy-keep-cap-netbindservice:false
k8s-service-proxy-name:
hubble-redact-http-urlquery:false
enable-local-redirect-policy:false
enable-encryption-strict-mode:false
enable-auto-protect-node-port-range:true
local-max-addr-scope:252
nat-map-stats-interval:30s
gateway-api-secrets-namespace:
container-ip-local-reserved-ports:auto
static-cnp-path:
labels:
ipv4-range:auto
bpf-ct-timeout-service-tcp:2h13m20s
ipv4-service-range:auto
enable-tracing:false
enable-wireguard-userspace-fallback:false
bpf-lb-maglev-map-max:0
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
devices:
monitor-aggregation:medium
pprof:false
identity-change-grace-period:5s
kvstore:
monitor-queue-size:0
policy-audit-mode:false
endpoint-bpf-prog-watchdog-interval:30s
proxy-prometheus-port:0
dns-max-ips-per-restored-rule:1000
egress-multi-home-ip-rule-compat:false
bpf-lb-sock:false
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
enable-identity-mark:true
enable-l2-neigh-discovery:true
tofqdns-enable-dns-compression:true
dnsproxy-enable-transparent-mode:true
vlan-bpf-bypass:
dnsproxy-concurrency-processing-grace-period:0s
l2-announcements-lease-duration:15s
monitor-aggregation-interval:5s
derive-masq-ip-addr-from-device:
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
http-normalize-path:true
cluster-id:95
enable-xdp-prefilter:false
use-cilium-internal-ip-for-ipsec:false
enable-node-selector-labels:false
ipv6-node:auto
routing-mode:tunnel
enable-ipip-termination:false
bpf-root:/sys/fs/bpf
identity-allocation-mode:crd
enable-bpf-tproxy:false
install-no-conntrack-iptables-rules:false
enable-high-scale-ipcache:false
node-labels:
mesh-auth-signal-backoff-duration:1s
cni-log-file:/var/run/cilium/cilium-cni.log
bpf-lb-sock-hostns-only:false
enable-hubble-recorder-api:true
iptables-random-fully:false
mesh-auth-spiffe-trust-domain:spiffe.cilium
multicast-enabled:false
mesh-auth-spire-admin-socket:
local-router-ipv6:
allow-localhost:auto
bpf-lb-dsr-l4-xlate:frontend
enable-service-topology:false
kube-proxy-replacement-healthz-bind-address:
l2-announcements-renew-deadline:5s
state-dir:/var/run/cilium
node-port-bind-protection:true
ipv4-service-loopback-address:169.254.42.1
cni-chaining-mode:none
enable-bgp-control-plane:false
ip-masq-agent-config-path:/etc/config/ip-masq-agent
allocator-list-timeout:3m0s
bgp-announce-lb-ip:false
bpf-lb-algorithm:random
enable-health-check-nodeport:true
hubble-drop-events-reasons:auth_required,policy_denied
proxy-portrange-max:20000
enable-sctp:false
bpf-events-policy-verdict-enabled:true
enable-ipv6:false
bpf-ct-timeout-regular-tcp:2h13m20s
bpf-lb-service-map-max:0
version:false
enable-svc-source-range-check:true
mesh-auth-mutual-listener-port:0
hubble-drop-events:false
api-rate-limit:
arping-refresh-period:30s
external-envoy-proxy:true
enable-ipsec-encrypted-overlay:false
max-connected-clusters:255
dnsproxy-lock-count:131
node-port-range:
ipv6-service-range:auto
ipsec-key-file:
srv6-encap-mode:reduced
enable-bpf-masquerade:false
enable-tcx:true
enable-nat46x64-gateway:false
keep-config:false
hubble-redact-kafka-apikey:false
enable-endpoint-health-checking:true
cgroup-root:/run/cilium/cgroupv2
bpf-ct-timeout-service-tcp-grace:1m0s
envoy-log:
enable-bandwidth-manager:false
mesh-auth-rotated-identities-queue-size:1024
cmdref:
enable-gateway-api:false
hubble-export-denylist:
endpoint-gc-interval:5m0s
mtu:0
ipv4-node:auto
hubble-socket-path:/var/run/cilium/hubble.sock
kvstore-opt:
enable-l2-pod-announcements:false
enable-route-mtu-for-cni-chaining:false
k8s-api-server:
ipv4-native-routing-cidr:
enable-k8s-api-discovery:false
policy-accounting:true
tofqdns-endpoint-max-ip-per-hostname:50
hubble-skip-unknown-cgroup-ids:true
enable-ipsec:false
enable-mke:false
http-max-grpc-timeout:0
bpf-events-trace-enabled:true
proxy-max-requests-per-connection:0
enable-cilium-api-server-access:
bpf-lb-source-range-map-max:0
enable-ipv4-masquerade:true
force-device-detection:false
cilium-endpoint-gc-interval:5m0s
ipsec-key-rotation-duration:5m0s
enable-stale-cilium-endpoint-cleanup:true
hubble-disable-tls:false
identity-heartbeat-timeout:30m0s
proxy-portrange-min:10000
kube-proxy-replacement:false
hubble-prefer-ipv6:false
enable-host-legacy-routing:false
join-cluster:false
bpf-lb-maglev-table-size:16381
enable-runtime-device-detection:true
proxy-max-connection-duration-seconds:0
egress-gateway-policy-map-max:16384
bpf-lb-dsr-dispatch:opt
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
bgp-config-path:/var/lib/cilium/bgp/config.yaml
k8s-require-ipv6-pod-cidr:false
k8s-client-connection-timeout:30s
envoy-base-id:0
dnsproxy-lock-timeout:500ms
mke-cgroup-mount:
agent-liveness-update-interval:1s
proxy-gid:1337
identity-restore-grace-period:30s
proxy-xff-num-trusted-hops-ingress:0
endpoint-queue-size:25
local-router-ipv4:
enable-ingress-controller:false
debug:false
vtep-mask:
envoy-config-retry-interval:15s
proxy-connect-timeout:2
hubble-metrics:
hubble-recorder-sink-queue-size:1024
kvstore-max-consecutive-quorum-errors:2
allow-icmp-frag-needed:true
bpf-ct-global-any-max:262144
enable-health-check-loadbalancer-ip:false
bpf-lb-rss-ipv6-src-cidr:
enable-host-port:false
ipv4-pod-subnets:
enable-metrics:true
enable-vtep:false
clustermesh-sync-timeout:1m0s
socket-path:/var/run/cilium/cilium.sock
clustermesh-ip-identities-sync-timeout:1m0s
clustermesh-enable-endpoint-sync:false
bpf-neigh-global-max:524288
mesh-auth-queue-size:1024
bpf-lb-mode:snat
enable-ipv6-ndp:false
conntrack-gc-interval:0s
route-metric:0
conntrack-gc-max-interval:0s
ipam-multi-pool-pre-allocation:
l2-pod-announcements-interface:
agent-labels:
hubble-monitor-events:
dnsproxy-socket-linger-timeout:10
bpf-map-event-buffers:
encrypt-interface:
http-retry-count:3
mesh-auth-mutual-connect-timeout:5s
vtep-cidr:
enable-ipv4:true
disable-external-ip-mitigation:false
hubble-redact-http-headers-allow:
encrypt-node:false
service-no-backend-response:reject
hubble-recorder-storage-path:/var/run/cilium/pcaps
wireguard-persistent-keepalive:0s
lib-dir:/var/lib/cilium
operator-prometheus-serve-addr::9963
ipv6-pod-subnets:
enable-wireguard:false
bpf-ct-timeout-service-any:1m0s
config:
enable-k8s-terminating-endpoint:true
enable-k8s-networkpolicy:true
crd-wait-timeout:5m0s
k8s-require-ipv4-pod-cidr:false
bpf-lb-sock-terminate-pod-connections:false
hubble-export-fieldmask:
fqdn-regex-compile-lru-size:1024
encryption-strict-mode-cidr:
iptables-lock-timeout:5s
enable-ipv4-fragment-tracking:true
bpf-filter-priority:1
config-sources:config-map:kube-system/cilium-config
tofqdns-min-ttl:0
tunnel-port:0
set-cilium-is-up-condition:true
hubble-drop-events-interval:2m0s
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
enable-local-node-route:true
enable-session-affinity:false
log-driver:
enable-well-known-identities:false
prepend-iptables-chains:true
hubble-event-buffer-capacity:4095
ipam:cluster-pool
hubble-export-file-path:
bpf-lb-rss-ipv4-src-cidr:
proxy-xff-num-trusted-hops-egress:0
annotate-k8s-node:false
bpf-policy-map-max:16384
auto-create-cilium-node-resource:true
tunnel-protocol:vxlan
ipv6-cluster-alloc-cidr:f00d::/64
hubble-export-file-max-backups:5
datapath-mode:veth
cflags:
set-cilium-node-taints:true
fixed-identity-mapping:
max-internal-timer-delay:0s
enable-k8s:true
enable-node-port:false
direct-routing-device:
bpf-lb-service-backend-map-max:0
remove-cilium-node-taints:true
enable-ipsec-key-watcher:true
node-port-acceleration:disabled
enable-envoy-config:false
proxy-admin-port:0
direct-routing-skip-unreachable:false
enable-l7-proxy:true
use-full-tls-context:false
bpf-ct-timeout-regular-any:1m0s
enable-custom-calls:false
enable-cilium-endpoint-slice:false
dnsproxy-concurrency-limit:0
cluster-health-port:4240
http-retry-timeout:0
hubble-export-file-max-size-mb:10
bgp-announce-pod-cidr:false
procfs:/host/proc
hubble-redact-enabled:false
ipv6-mcast-device:
enable-cilium-health-api-server-access:
enable-bpf-clock-probe:false
gops-port:9890
bpf-map-dynamic-size-ratio:0.0025
bpf-fragments-map-max:8192
enable-icmp-rules:true
k8s-client-connection-keep-alive:30s
disable-endpoint-crd:false
log-opt:
envoy-config-timeout:2m0s
k8s-client-burst:20
disable-envoy-version-check:false
trace-sock:true
bpf-lb-external-clusterip:false
bpf-lb-acceleration:disabled
enable-monitor:true
enable-xt-socket-fallback:true
mesh-auth-gc-interval:5m0s
k8s-service-cache-size:128
enable-srv6:false
policy-trigger-interval:1s
disable-iptables-feeder-rules:
tofqdns-proxy-port:0
hubble-listen-address::4244
bpf-events-drop-enabled:true
monitor-aggregation-flags:all
k8s-client-qps:10
config-dir:/tmp/cilium/config-map
hubble-export-allowlist:
enable-k8s-endpoint-slice:true
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
cluster-name:cmesh95
envoy-secrets-namespace:
enable-endpoint-routes:false
http-idle-timeout:0
mesh-auth-enabled:true
ipam-cilium-node-update-rate:15s
bpf-ct-timeout-regular-tcp-fin:10s
prometheus-serve-addr:
operator-api-serve-addr:127.0.0.1:9234
proxy-idle-timeout-seconds:60
hubble-redact-http-headers-deny:
policy-queue-size:100
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
kvstore-periodic-sync:5m0s
metrics:
enable-ipv4-big-tcp:false
ipv6-range:auto
tofqdns-dns-reject-response-code:refused
trace-payloadlen:128
bpf-ct-global-tcp-max:524288
identity-gc-interval:15m0s
```


#### Service list

```
ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.253.206:443 (active)    
                                         2 => 172.31.147.177:443 (active)    
2    10.100.177.252:443   ClusterIP      1 => 172.31.186.243:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.94.0.192:53 (active)        
                                         2 => 10.94.0.161:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.94.0.192:9153 (active)      
                                         2 => 10.94.0.161:9153 (active)      
5    10.100.113.66:2379   ClusterIP      1 => 10.94.0.121:2379 (active)      
```

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 37771566                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 37771566                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 37771566                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400c400000 rw-p 00000000 00:00 0 
400c400000-4010000000 ---p 00000000 00:00 0 
ffff3a723000-ffff3a939000 rw-p 00000000 00:00 0 
ffff3a941000-ffff3aa62000 rw-p 00000000 00:00 0 
ffff3aa62000-ffff3aaa3000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff3aaa3000-ffff3aae4000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff3aae4000-ffff3aae6000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff3aae6000-ffff3aae8000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff3aae8000-ffff3b09f000 rw-p 00000000 00:00 0 
ffff3b09f000-ffff3b19f000 rw-p 00000000 00:00 0 
ffff3b19f000-ffff3b1b0000 rw-p 00000000 00:00 0 
ffff3b1b0000-ffff3d1b0000 rw-p 00000000 00:00 0 
ffff3d1b0000-ffff3d230000 ---p 00000000 00:00 0 
ffff3d230000-ffff3d231000 rw-p 00000000 00:00 0 
ffff3d231000-ffff5d230000 ---p 00000000 00:00 0 
ffff5d230000-ffff5d231000 rw-p 00000000 00:00 0 
ffff5d231000-ffff7d1c0000 ---p 00000000 00:00 0 
ffff7d1c0000-ffff7d1c1000 rw-p 00000000 00:00 0 
ffff7d1c1000-ffff811b2000 ---p 00000000 00:00 0 
ffff811b2000-ffff811b3000 rw-p 00000000 00:00 0 
ffff811b3000-ffff819b0000 ---p 00000000 00:00 0 
ffff819b0000-ffff819b1000 rw-p 00000000 00:00 0 
ffff819b1000-ffff81ab0000 ---p 00000000 00:00 0 
ffff81ab0000-ffff81b10000 rw-p 00000000 00:00 0 
ffff81b10000-ffff81b12000 r--p 00000000 00:00 0                          [vvar]
ffff81b12000-ffff81b13000 r-xp 00000000 00:00 0                          [vdso]
ffffe91f3000-ffffe9214000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.94.0.0/24, 
Allocated addresses:
  10.94.0.119 (router)
  10.94.0.121 (kube-system/clustermesh-apiserver-795cf847cd-b89h6)
  10.94.0.161 (kube-system/coredns-cc6ccd49c-hw98h)
  10.94.0.192 (kube-system/coredns-cc6ccd49c-5jrpl)
  10.94.0.74 (health)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: f7971674d1565ad4
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    29s ago        never        0       no error   
  ct-map-pressure                                                     1s ago         never        0       no error   
  daemon-validate-config                                              21s ago        never        0       no error   
  dns-garbage-collector-job                                           33s ago        never        0       no error   
  endpoint-1808-regeneration-recovery                                 never          never        0       no error   
  endpoint-2265-regeneration-recovery                                 never          never        0       no error   
  endpoint-254-regeneration-recovery                                  never          never        0       no error   
  endpoint-3668-regeneration-recovery                                 never          never        0       no error   
  endpoint-728-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         33s ago        never        0       no error   
  ep-bpf-prog-watchdog                                                1s ago         never        0       no error   
  ipcache-inject-labels                                               31s ago        never        0       no error   
  k8s-heartbeat                                                       3s ago         never        0       no error   
  link-cache                                                          0s ago         never        0       no error   
  local-identity-checkpoint                                           10m9s ago      never        0       no error   
  node-neighbor-link-updater                                          0s ago         never        0       no error   
  remote-etcd-cmesh1                                                  6m20s ago      never        0       no error   
  remote-etcd-cmesh10                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh100                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh101                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh102                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh103                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh104                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh105                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh106                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh107                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh108                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh109                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh11                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh110                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh111                                                6m21s ago      never        0       no error   
  remote-etcd-cmesh112                                                6m21s ago      never        0       no error   
  remote-etcd-cmesh113                                                6m21s ago      never        0       no error   
  remote-etcd-cmesh114                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh115                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh116                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh117                                                6m21s ago      never        0       no error   
  remote-etcd-cmesh118                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh119                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh12                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh120                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh121                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh122                                                6m21s ago      never        0       no error   
  remote-etcd-cmesh123                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh124                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh125                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh126                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh127                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh128                                                6m20s ago      never        0       no error   
  remote-etcd-cmesh13                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh14                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh15                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh16                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh17                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh18                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh19                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh2                                                  6m20s ago      never        0       no error   
  remote-etcd-cmesh20                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh21                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh22                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh23                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh24                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh25                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh26                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh27                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh28                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh29                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh3                                                  6m21s ago      never        0       no error   
  remote-etcd-cmesh30                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh31                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh32                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh33                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh34                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh35                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh36                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh37                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh38                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh39                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh4                                                  6m20s ago      never        0       no error   
  remote-etcd-cmesh40                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh41                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh42                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh43                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh44                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh45                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh46                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh47                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh48                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh49                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh5                                                  6m20s ago      never        0       no error   
  remote-etcd-cmesh50                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh51                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh52                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh53                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh54                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh55                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh56                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh57                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh58                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh59                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh6                                                  6m21s ago      never        0       no error   
  remote-etcd-cmesh60                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh61                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh62                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh63                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh64                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh65                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh66                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh67                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh68                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh69                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh7                                                  6m20s ago      never        0       no error   
  remote-etcd-cmesh70                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh71                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh72                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh73                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh74                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh75                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh76                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh77                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh78                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh79                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh8                                                  6m20s ago      never        0       no error   
  remote-etcd-cmesh80                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh81                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh82                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh83                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh84                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh85                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh86                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh87                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh88                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh89                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh9                                                  6m21s ago      never        0       no error   
  remote-etcd-cmesh90                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh91                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh92                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh93                                                 6m21s ago      never        0       no error   
  remote-etcd-cmesh94                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh96                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh97                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh98                                                 6m20s ago      never        0       no error   
  remote-etcd-cmesh99                                                 6m21s ago      never        0       no error   
  resolve-identity-1808                                               1m34s ago      never        0       no error   
  resolve-identity-2265                                               28s ago        never        0       no error   
  resolve-identity-254                                                28s ago        never        0       no error   
  resolve-identity-3668                                               31s ago        never        0       no error   
  resolve-identity-728                                                29s ago        never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-795cf847cd-b89h6   6m34s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-5jrpl                  10m28s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-hw98h                  10m28s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      10m31s ago     never        0       no error   
  sync-policymap-1808                                                 6m33s ago      never        0       no error   
  sync-policymap-2265                                                 10m27s ago     never        0       no error   
  sync-policymap-254                                                  10m26s ago     never        0       no error   
  sync-policymap-3668                                                 10m30s ago     never        0       no error   
  sync-policymap-728                                                  10m27s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (1808)                                   3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2265)                                   8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (254)                                    8s ago         never        0       no error   
  sync-utime                                                          31s ago        never        0       no error   
  write-cni-file                                                      10m33s ago     never        0       no error   
Proxy Status:            OK, ip 10.94.0.119, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 6225920, max 6291455
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 96.47   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
254        Disabled           Disabled          6232298    k8s:eks.amazonaws.com/component=coredns                                             10.94.0.161   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh95                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
728        Disabled           Disabled          4          reserved:health                                                                     10.94.0.74    ready   
1808       Disabled           Disabled          6246044    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.94.0.121   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh95                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
2265       Disabled           Disabled          6232298    k8s:eks.amazonaws.com/component=coredns                                             10.94.0.192   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh95                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
3668       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                
                                                           reserved:host                                                                                             
```

#### BPF Policy Get 254

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    58265   671       0        
Allow    Egress      0          ANY          NONE         disabled    12054   121       0        

```


#### BPF CT List 254

```
Invalid argument: unknown type 254
```


#### Endpoint Get 254

```
[
  {
    "id": 254,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-254-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "df67cd16-e667-404b-bb81-bb4019520cc7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-254",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:52.559Z",
            "success-count": 3
          },
          "uuid": "9b641e67-c942-4032-b67a-39e54caa86d4"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-hw98h",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:18:52.558Z",
            "success-count": 1
          },
          "uuid": "9987ceec-b377-4e55-b08f-877e83dd6739"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-254",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:18:54.340Z",
            "success-count": 1
          },
          "uuid": "b9fadd62-5186-4bec-815b-32c18d681a4f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (254)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:12.604Z",
            "success-count": 64
          },
          "uuid": "e73fa479-6c55-4214-8438-9de0ad5a296a"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "7fc92696fc63f1999f6e2bdae3b037fbf8e5db43f2c489c9056df07038147417:eth0",
        "container-id": "7fc92696fc63f1999f6e2bdae3b037fbf8e5db43f2c489c9056df07038147417",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-hw98h",
        "pod-name": "kube-system/coredns-cc6ccd49c-hw98h"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6232298,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh95",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh95",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:02Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.94.0.161",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "1e:1d:b4:4c:7b:2b",
        "interface-index": 11,
        "interface-name": "lxca2d9a0bf8cc8",
        "mac": "de:63:ef:7d:9d:10"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6232298,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6232298,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 254

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 254

```
Timestamp              Status   State                   Message
2024-10-25T10:23:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:02Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:18:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:18:54Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:18:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:18:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:18:52Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:18:52Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 6232298

```
ID        LABELS
6232298   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh95
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 728

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    440661   5626      0        
Allow    Ingress     1          ANY          NONE         disabled    8184     94        0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 728

```
Invalid argument: unknown type 728
```


#### Endpoint Get 728

```
[
  {
    "id": 728,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-728-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "9a3534db-ff30-461b-a33c-9b9935c1de4e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-728",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:51.325Z",
            "success-count": 3
          },
          "uuid": "bdd84746-c533-4b4f-88b9-4ff4abb02cd2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-728",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:18:54.296Z",
            "success-count": 1
          },
          "uuid": "91329ba8-810e-4240-919f-c4b3b665dee6"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.94.0.74",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "b2:f0:8d:c6:ea:ac",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "86:1b:8c:13:2a:6f"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 728

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 728

```
Timestamp              Status   State                   Message
2024-10-25T10:23:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:02Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:18:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:18:54Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:18:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:18:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:18:52Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:18:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:18:51Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:18:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:18:51Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:18:50Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 1808

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3914259   36295     0        
Allow    Ingress     1          ANY          NONE         disabled    3023808   30398     0        
Allow    Egress      0          ANY          NONE         disabled    3925892   36485     0        

```


#### BPF CT List 1808

```
Invalid argument: unknown type 1808
```


#### Endpoint Get 1808

```
[
  {
    "id": 1808,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1808-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5a0737e2-44f4-4f86-bdea-139e905b9ee4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1808",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:47.308Z",
            "success-count": 2
          },
          "uuid": "f771f5c2-40e2-474a-9e6a-8614c9750e7f"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-795cf847cd-b89h6",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:47.307Z",
            "success-count": 1
          },
          "uuid": "80ca2572-372c-4202-b51c-04ebd1317fe2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1808",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:47.342Z",
            "success-count": 1
          },
          "uuid": "a3f7c28d-ec61-44e4-a45a-7274e58642e7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1808)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:17.358Z",
            "success-count": 41
          },
          "uuid": "376e3d22-8527-44b5-b807-5452ca1ca6a0"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "01da898df2b6300a9556e9f71c9c6551ed4b7c13070a8cc8b8a4b6acf51f0122:eth0",
        "container-id": "01da898df2b6300a9556e9f71c9c6551ed4b7c13070a8cc8b8a4b6acf51f0122",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-795cf847cd-b89h6",
        "pod-name": "kube-system/clustermesh-apiserver-795cf847cd-b89h6"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6246044,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh95",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=795cf847cd"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh95",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:02Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.94.0.121",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "82:65:d2:2f:c3:7d",
        "interface-index": 15,
        "interface-name": "lxc7053e67ac577",
        "mac": "8a:d4:f4:a7:0c:96"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6246044,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6246044,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1808

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1808

```
Timestamp              Status   State                   Message
2024-10-25T10:23:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:02Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:22:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:47Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:22:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:22:47Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:22:47Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 6246044

```
ID        LABELS
6246044   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh95
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 2265

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    57869   665       0        
Allow    Egress      0          ANY          NONE         disabled    11818   118       0        

```


#### BPF CT List 2265

```
Invalid argument: unknown type 2265
```


#### Endpoint Get 2265

```
[
  {
    "id": 2265,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2265-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d30240a5-77b3-416e-ac90-789201683f0f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2265",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:52.471Z",
            "success-count": 3
          },
          "uuid": "f4e912d7-2ce6-4ea8-a481-9c7cfebc23ac"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-5jrpl",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:18:52.471Z",
            "success-count": 1
          },
          "uuid": "c71b64ed-94ff-4ef4-a860-4a2f0dff7bf3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2265",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:18:54.316Z",
            "success-count": 1
          },
          "uuid": "af0da236-b80a-4712-bd35-8ac0c629f9e5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2265)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:12.527Z",
            "success-count": 64
          },
          "uuid": "2517ce8e-2308-4d45-a88c-1840e36d73a1"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "64d7134418bcd154089ff4e80083b516ef31e857c0b68864a91704f5cadcacca:eth0",
        "container-id": "64d7134418bcd154089ff4e80083b516ef31e857c0b68864a91704f5cadcacca",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-5jrpl",
        "pod-name": "kube-system/coredns-cc6ccd49c-5jrpl"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6232298,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh95",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh95",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:02Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.94.0.192",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "fa:cc:1f:58:08:19",
        "interface-index": 9,
        "interface-name": "lxcae150a15d24c",
        "mac": "6a:96:39:bb:dc:52"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6232298,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6232298,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2265

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2265

```
Timestamp              Status    State                   Message
2024-10-25T10:23:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:02Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:23:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:08Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:08Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:08Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:08Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:18:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:18:54Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:18:54Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:18:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:53Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:18:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:18:52Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:18:52Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:52Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 6232298

```
ID        LABELS
6232298   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh95
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 3668

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 3668

```
Invalid argument: unknown type 3668
```


#### Endpoint Get 3668

```
[
  {
    "id": 3668,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3668-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "05b3c3ee-f1c9-4a52-bd25-5fef39719486"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3668",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:50.276Z",
            "success-count": 3
          },
          "uuid": "dff4511d-90a8-4b67-a011-8fda9e6b630b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3668",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:18:51.263Z",
            "success-count": 1
          },
          "uuid": "3b13436f-57a3-4fb7-9c84-925f49ec2758"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "ea:34:2a:97:45:01",
        "interface-name": "cilium_host",
        "mac": "ea:34:2a:97:45:01"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3668

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3668

```
Timestamp              Status   State                   Message
2024-10-25T10:23:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:02Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:19:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:19:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:19:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:19:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:18:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:18:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:18:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:18:53Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:18:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:18:52Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:18:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:18:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:18:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:18:50Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:18:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:18:50Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:18:50Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### Policy get

```
:
 []
Revision: 1

```

