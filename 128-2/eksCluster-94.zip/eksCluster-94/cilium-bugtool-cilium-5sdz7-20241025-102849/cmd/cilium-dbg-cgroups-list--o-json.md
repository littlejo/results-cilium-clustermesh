[
  {
    "containers": [
      {
        "cgroup-id": 6868,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2c388e37_bc96_489f_b7ba_17e20be5a858.slice/cri-containerd-6c2f195e63d62717d36f180dd947fc3c72488c6b579ec9afde6da7c7a8191405.scope"
      }
    ],
    "ips": [
      "10.94.0.161"
    ],
    "name": "coredns-cc6ccd49c-hw98h",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8296,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa4bcfba_30bf_4d36_ad71_318ea984eed4.slice/cri-containerd-8f025e0377c1bf01238e3fbce26f1ed290abe2823c419d680566350373a6a012.scope"
      },
      {
        "cgroup-id": 8212,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa4bcfba_30bf_4d36_ad71_318ea984eed4.slice/cri-containerd-81d892a2f85444111137a26f70e95c82cb83246d47bda7ac4a73ae975b6a5445.scope"
      },
      {
        "cgroup-id": 8380,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa4bcfba_30bf_4d36_ad71_318ea984eed4.slice/cri-containerd-83d59947c634b8109b527c709265466f86b2c6ca2acd21148c217f71d83282d6.scope"
      }
    ],
    "ips": [
      "10.94.0.121"
    ],
    "name": "clustermesh-apiserver-795cf847cd-b89h6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6784,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a7ba732_6cfd_4764_be26_52a8c68a35bb.slice/cri-containerd-32da332187bad58241f2386df80128fd26805957ee1d1fdd57d12189e3ff5bee.scope"
      }
    ],
    "ips": [
      "10.94.0.192"
    ],
    "name": "coredns-cc6ccd49c-5jrpl",
    "namespace": "kube-system"
  }
]

