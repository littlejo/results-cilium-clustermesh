key: fe 00 00 00  value: f3 01 00 00
key: d8 02 00 00  value: fd 01 00 00
key: 10 07 00 00  value: 44 02 00 00
key: d9 08 00 00  value: e4 01 00 00
Found 4 elements
