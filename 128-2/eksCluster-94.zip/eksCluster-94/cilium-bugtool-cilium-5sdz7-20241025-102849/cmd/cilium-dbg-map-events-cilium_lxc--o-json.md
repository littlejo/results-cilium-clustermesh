{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:50.123Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.186.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:50.123Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:54.295Z",
  "value": "id=728   sec_id=4     flags=0x0000 ifindex=7   mac=86:1B:8C:13:2A:6F nodemac=B2:F0:8D:C6:EA:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:54.314Z",
  "value": "id=2265  sec_id=6232298 flags=0x0000 ifindex=9   mac=6A:96:39:BB:DC:52 nodemac=FA:CC:1F:58:08:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:54.338Z",
  "value": "id=254   sec_id=6232298 flags=0x0000 ifindex=11  mac=DE:63:EF:7D:9D:10 nodemac=1E:1D:B4:4C:7B:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:54.339Z",
  "value": "id=2265  sec_id=6232298 flags=0x0000 ifindex=9   mac=6A:96:39:BB:DC:52 nodemac=FA:CC:1F:58:08:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:18:54.357Z",
  "value": "id=728   sec_id=4     flags=0x0000 ifindex=7   mac=86:1B:8C:13:2A:6F nodemac=B2:F0:8D:C6:EA:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:08.899Z",
  "value": "id=728   sec_id=4     flags=0x0000 ifindex=7   mac=86:1B:8C:13:2A:6F nodemac=B2:F0:8D:C6:EA:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:08.899Z",
  "value": "id=2265  sec_id=6232298 flags=0x0000 ifindex=9   mac=6A:96:39:BB:DC:52 nodemac=FA:CC:1F:58:08:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:08.900Z",
  "value": "id=254   sec_id=6232298 flags=0x0000 ifindex=11  mac=DE:63:EF:7D:9D:10 nodemac=1E:1D:B4:4C:7B:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:08.927Z",
  "value": "id=379   sec_id=6246044 flags=0x0000 ifindex=13  mac=4A:B9:4B:1B:75:24 nodemac=3A:36:74:D6:E0:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:09.900Z",
  "value": "id=728   sec_id=4     flags=0x0000 ifindex=7   mac=86:1B:8C:13:2A:6F nodemac=B2:F0:8D:C6:EA:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:09.900Z",
  "value": "id=379   sec_id=6246044 flags=0x0000 ifindex=13  mac=4A:B9:4B:1B:75:24 nodemac=3A:36:74:D6:E0:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:09.900Z",
  "value": "id=2265  sec_id=6232298 flags=0x0000 ifindex=9   mac=6A:96:39:BB:DC:52 nodemac=FA:CC:1F:58:08:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:19:09.900Z",
  "value": "id=254   sec_id=6232298 flags=0x0000 ifindex=11  mac=DE:63:EF:7D:9D:10 nodemac=1E:1D:B4:4C:7B:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:47.342Z",
  "value": "id=1808  sec_id=6246044 flags=0x0000 ifindex=15  mac=8A:D4:F4:A7:0C:96 nodemac=82:65:D2:2F:C3:7D"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.94.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.766Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:00.293Z",
  "value": "id=1808  sec_id=6246044 flags=0x0000 ifindex=15  mac=8A:D4:F4:A7:0C:96 nodemac=82:65:D2:2F:C3:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:00.294Z",
  "value": "id=2265  sec_id=6232298 flags=0x0000 ifindex=9   mac=6A:96:39:BB:DC:52 nodemac=FA:CC:1F:58:08:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:00.294Z",
  "value": "id=728   sec_id=4     flags=0x0000 ifindex=7   mac=86:1B:8C:13:2A:6F nodemac=B2:F0:8D:C6:EA:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:00.295Z",
  "value": "id=254   sec_id=6232298 flags=0x0000 ifindex=11  mac=DE:63:EF:7D:9D:10 nodemac=1E:1D:B4:4C:7B:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:01.292Z",
  "value": "id=728   sec_id=4     flags=0x0000 ifindex=7   mac=86:1B:8C:13:2A:6F nodemac=B2:F0:8D:C6:EA:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:01.292Z",
  "value": "id=2265  sec_id=6232298 flags=0x0000 ifindex=9   mac=6A:96:39:BB:DC:52 nodemac=FA:CC:1F:58:08:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:01.293Z",
  "value": "id=254   sec_id=6232298 flags=0x0000 ifindex=11  mac=DE:63:EF:7D:9D:10 nodemac=1E:1D:B4:4C:7B:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:01.293Z",
  "value": "id=1808  sec_id=6246044 flags=0x0000 ifindex=15  mac=8A:D4:F4:A7:0C:96 nodemac=82:65:D2:2F:C3:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:02.293Z",
  "value": "id=728   sec_id=4     flags=0x0000 ifindex=7   mac=86:1B:8C:13:2A:6F nodemac=B2:F0:8D:C6:EA:AC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:02.293Z",
  "value": "id=2265  sec_id=6232298 flags=0x0000 ifindex=9   mac=6A:96:39:BB:DC:52 nodemac=FA:CC:1F:58:08:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:02.293Z",
  "value": "id=1808  sec_id=6246044 flags=0x0000 ifindex=15  mac=8A:D4:F4:A7:0C:96 nodemac=82:65:D2:2F:C3:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:02.294Z",
  "value": "id=254   sec_id=6232298 flags=0x0000 ifindex=11  mac=DE:63:EF:7D:9D:10 nodemac=1E:1D:B4:4C:7B:2B"
}

