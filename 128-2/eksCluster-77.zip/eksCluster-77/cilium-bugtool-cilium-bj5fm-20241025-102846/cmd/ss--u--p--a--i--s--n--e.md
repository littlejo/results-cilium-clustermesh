Total: 569
TCP:   1091 (estab 318, closed 754, orphaned 0, timewait 289)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  337       325       12       
INET	  347       331       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.236.177%ens5:68         0.0.0.0:*    uid:192 ino:16432 sk:267 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:24881 sk:268 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15456 sk:269 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:33319      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:24698 sk:26a fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:24880 sk:26b cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15457 sk:26c cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::895:c0ff:fe2b:b695]%ens5:546           [::]:*    uid:192 ino:16424 sk:26d cgroup:unreachable:c4e v6only:1 <->                   
