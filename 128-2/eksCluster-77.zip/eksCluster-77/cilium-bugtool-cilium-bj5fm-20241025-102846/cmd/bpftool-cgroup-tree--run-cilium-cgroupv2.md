CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod38909029_2b28_476b_8ab6_5ccf50bb6e24.slice/cri-containerd-2bc05e900cdd04a3c2f8f3aa577eacd618d87f1148d9925cb6d461037a1a9afa.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod38909029_2b28_476b_8ab6_5ccf50bb6e24.slice/cri-containerd-ed51b4b873a2cb3708b8d5a56cd46ed0e68be9a74926ae6894722a249e668d19.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod30588b48_035b_4cab_9af4_0e8b26f14f04.slice/cri-containerd-b47d31ff19ec81fb0afa2a380519c614e10d07f696d32e2ff4ab93e616b56485.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod30588b48_035b_4cab_9af4_0e8b26f14f04.slice/cri-containerd-e10735f4e2a68ddc0ce1b675b013f64c64555397e5f5bf0faa0ea7904ebb66aa.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod12f5d017_f4af_4de3_ac46_101a6380b40d.slice/cri-containerd-ef409666df5b3f366e9c8165e4fec966b645ae85cdc6b39bb7783348f04c056d.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod12f5d017_f4af_4de3_ac46_101a6380b40d.slice/cri-containerd-3ea2e122f04ff45d9cc722d3ad6c90f208a4490c52f64d8767057c736f571f65.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda4fe485a_eb80_48d5_af1e_ede5fafee68d.slice/cri-containerd-132611a610e456dd6d0a1a54ed876bc73213e0a08aaf654c9ed0fffbd226b1f3.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda4fe485a_eb80_48d5_af1e_ede5fafee68d.slice/cri-containerd-7e67e509645ec397066d704996529818e19b8a0bb571636c3ffbebc20224732a.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3acfd8c5_8c63_4e67_b24b_6b9a60725e55.slice/cri-containerd-4b9b527c74241353790ca85cb5807f304950a73e3096dae43697b5678578fb2b.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3acfd8c5_8c63_4e67_b24b_6b9a60725e55.slice/cri-containerd-4f022cd7804b52f8d4d8bb2a19effa0026b639a2f2ac82d0dd839670842710e5.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6186974b_301a_4c1e_a853_29fa3f3e261c.slice/cri-containerd-30039549814beccf54877dd5c1ec63fb09ea6826faf441b7bb3f1129617aad79.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6186974b_301a_4c1e_a853_29fa3f3e261c.slice/cri-containerd-277039674e2830a0ae81af8e8ff74d02c083e9b6e912ee2f0034c95848a5eaa0.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podde414d6d_86e5_4830_ba6e_6ee2e5cb5fb1.slice/cri-containerd-9805da8cb29a0ce90148fbd3b6a055dcf94261717832c1baf179f457d671fb2f.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podde414d6d_86e5_4830_ba6e_6ee2e5cb5fb1.slice/cri-containerd-69a6555015a3b174620278eafee86a16e2ab9884de174d5af6dc933ea06261a2.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podde414d6d_86e5_4830_ba6e_6ee2e5cb5fb1.slice/cri-containerd-c6b4f3556aa06bcf406d24173fe88447328fece410215939c167d005a02ca35f.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podde414d6d_86e5_4830_ba6e_6ee2e5cb5fb1.slice/cri-containerd-7988f0114ce55899c6e31fb751b0e01d9c97c3c5cea8dd11b2521b94ba855f87.scope
    643      cgroup_device   multi                                          
