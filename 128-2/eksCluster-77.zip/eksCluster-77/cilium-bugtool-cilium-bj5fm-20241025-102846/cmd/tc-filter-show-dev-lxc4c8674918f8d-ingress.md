filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc4c8674918f8d direct-action not_in_hw id 616 tag 1e203621b9d9b5f2 jited 
