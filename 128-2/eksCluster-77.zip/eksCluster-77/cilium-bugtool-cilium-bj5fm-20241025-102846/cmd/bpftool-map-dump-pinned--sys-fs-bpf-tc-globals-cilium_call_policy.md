key: e4 00 00 00  value: 13 02 00 00
key: dc 05 00 00  value: 1a 02 00 00
key: 01 09 00 00  value: 06 02 00 00
key: 67 0a 00 00  value: 63 02 00 00
Found 4 elements
