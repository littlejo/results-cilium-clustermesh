IP ADDRESS         LOCAL ENDPOINT INFO
10.77.0.203:0      id=2305  sec_id=5164343 flags=0x0000 ifindex=12  mac=C2:0E:96:A9:63:F0 nodemac=FE:81:49:FC:F5:E9   
10.77.0.249:0      id=2663  sec_id=5140967 flags=0x0000 ifindex=18  mac=FE:C8:F9:52:7A:E4 nodemac=AE:14:F9:CB:01:85   
172.31.236.177:0   (localhost)                                                                                        
10.77.0.192:0      (localhost)                                                                                        
10.77.0.180:0      id=228   sec_id=5164343 flags=0x0000 ifindex=14  mac=36:5A:DD:CF:0F:C6 nodemac=72:6F:9E:26:6C:0F   
172.31.249.219:0   (localhost)                                                                                        
10.77.0.185:0      id=1500  sec_id=4     flags=0x0000 ifindex=10  mac=A2:AA:4B:2C:61:8B nodemac=A6:D8:16:6D:5D:B1     
