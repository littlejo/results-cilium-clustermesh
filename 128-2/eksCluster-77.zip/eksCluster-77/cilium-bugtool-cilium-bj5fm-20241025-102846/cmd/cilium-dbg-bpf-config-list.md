KEY             VALUE
AgentLiveness   808705434459
UTimeOffset     3378615919921875
