{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:07.147Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.236.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:07.147Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.249.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:07.147Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:11.457Z",
  "value": "id=1500  sec_id=4     flags=0x0000 ifindex=10  mac=A2:AA:4B:2C:61:8B nodemac=A6:D8:16:6D:5D:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:11.470Z",
  "value": "id=2305  sec_id=5164343 flags=0x0000 ifindex=12  mac=C2:0E:96:A9:63:F0 nodemac=FE:81:49:FC:F5:E9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:11.509Z",
  "value": "id=228   sec_id=5164343 flags=0x0000 ifindex=14  mac=36:5A:DD:CF:0F:C6 nodemac=72:6F:9E:26:6C:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:11.516Z",
  "value": "id=1500  sec_id=4     flags=0x0000 ifindex=10  mac=A2:AA:4B:2C:61:8B nodemac=A6:D8:16:6D:5D:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:25.130Z",
  "value": "id=1500  sec_id=4     flags=0x0000 ifindex=10  mac=A2:AA:4B:2C:61:8B nodemac=A6:D8:16:6D:5D:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:25.131Z",
  "value": "id=2305  sec_id=5164343 flags=0x0000 ifindex=12  mac=C2:0E:96:A9:63:F0 nodemac=FE:81:49:FC:F5:E9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:25.131Z",
  "value": "id=228   sec_id=5164343 flags=0x0000 ifindex=14  mac=36:5A:DD:CF:0F:C6 nodemac=72:6F:9E:26:6C:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:25.158Z",
  "value": "id=3184  sec_id=5140967 flags=0x0000 ifindex=16  mac=42:C0:05:70:82:BC nodemac=56:2E:BF:66:F3:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:26.130Z",
  "value": "id=2305  sec_id=5164343 flags=0x0000 ifindex=12  mac=C2:0E:96:A9:63:F0 nodemac=FE:81:49:FC:F5:E9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:26.130Z",
  "value": "id=3184  sec_id=5140967 flags=0x0000 ifindex=16  mac=42:C0:05:70:82:BC nodemac=56:2E:BF:66:F3:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:26.130Z",
  "value": "id=228   sec_id=5164343 flags=0x0000 ifindex=14  mac=36:5A:DD:CF:0F:C6 nodemac=72:6F:9E:26:6C:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:26.131Z",
  "value": "id=1500  sec_id=4     flags=0x0000 ifindex=10  mac=A2:AA:4B:2C:61:8B nodemac=A6:D8:16:6D:5D:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:46.867Z",
  "value": "id=2663  sec_id=5140967 flags=0x0000 ifindex=18  mac=FE:C8:F9:52:7A:E4 nodemac=AE:14:F9:CB:01:85"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.77.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:51.724Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:34.095Z",
  "value": "id=1500  sec_id=4     flags=0x0000 ifindex=10  mac=A2:AA:4B:2C:61:8B nodemac=A6:D8:16:6D:5D:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:34.096Z",
  "value": "id=2305  sec_id=5164343 flags=0x0000 ifindex=12  mac=C2:0E:96:A9:63:F0 nodemac=FE:81:49:FC:F5:E9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:34.096Z",
  "value": "id=228   sec_id=5164343 flags=0x0000 ifindex=14  mac=36:5A:DD:CF:0F:C6 nodemac=72:6F:9E:26:6C:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:34.096Z",
  "value": "id=2663  sec_id=5140967 flags=0x0000 ifindex=18  mac=FE:C8:F9:52:7A:E4 nodemac=AE:14:F9:CB:01:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:35.094Z",
  "value": "id=228   sec_id=5164343 flags=0x0000 ifindex=14  mac=36:5A:DD:CF:0F:C6 nodemac=72:6F:9E:26:6C:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:35.095Z",
  "value": "id=2663  sec_id=5140967 flags=0x0000 ifindex=18  mac=FE:C8:F9:52:7A:E4 nodemac=AE:14:F9:CB:01:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:35.096Z",
  "value": "id=1500  sec_id=4     flags=0x0000 ifindex=10  mac=A2:AA:4B:2C:61:8B nodemac=A6:D8:16:6D:5D:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:35.096Z",
  "value": "id=2305  sec_id=5164343 flags=0x0000 ifindex=12  mac=C2:0E:96:A9:63:F0 nodemac=FE:81:49:FC:F5:E9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.249:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:36.095Z",
  "value": "id=2663  sec_id=5140967 flags=0x0000 ifindex=18  mac=FE:C8:F9:52:7A:E4 nodemac=AE:14:F9:CB:01:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:36.095Z",
  "value": "id=1500  sec_id=4     flags=0x0000 ifindex=10  mac=A2:AA:4B:2C:61:8B nodemac=A6:D8:16:6D:5D:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:36.095Z",
  "value": "id=228   sec_id=5164343 flags=0x0000 ifindex=14  mac=36:5A:DD:CF:0F:C6 nodemac=72:6F:9E:26:6C:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:36.095Z",
  "value": "id=2305  sec_id=5164343 flags=0x0000 ifindex=12  mac=C2:0E:96:A9:63:F0 nodemac=FE:81:49:FC:F5:E9"
}

