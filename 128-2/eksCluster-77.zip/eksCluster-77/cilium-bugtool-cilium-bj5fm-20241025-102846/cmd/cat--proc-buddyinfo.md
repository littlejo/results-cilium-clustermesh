Node 0, zone      DMA     14     36      2     12     20      9      8      1      2      3    162 
Node 0, zone   Normal    309     82     34     28     18     10      5      4      3      3      6 
