[
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podde414d6d_86e5_4830_ba6e_6ee2e5cb5fb1.slice/cri-containerd-7988f0114ce55899c6e31fb751b0e01d9c97c3c5cea8dd11b2521b94ba855f87.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podde414d6d_86e5_4830_ba6e_6ee2e5cb5fb1.slice/cri-containerd-c6b4f3556aa06bcf406d24173fe88447328fece410215939c167d005a02ca35f.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podde414d6d_86e5_4830_ba6e_6ee2e5cb5fb1.slice/cri-containerd-69a6555015a3b174620278eafee86a16e2ab9884de174d5af6dc933ea06261a2.scope"
      }
    ],
    "ips": [
      "10.77.0.249"
    ],
    "name": "clustermesh-apiserver-5c5f75ff5-r76fv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod38909029_2b28_476b_8ab6_5ccf50bb6e24.slice/cri-containerd-2bc05e900cdd04a3c2f8f3aa577eacd618d87f1148d9925cb6d461037a1a9afa.scope"
      }
    ],
    "ips": [
      "10.77.0.180"
    ],
    "name": "coredns-cc6ccd49c-xpj4g",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod12f5d017_f4af_4de3_ac46_101a6380b40d.slice/cri-containerd-ef409666df5b3f366e9c8165e4fec966b645ae85cdc6b39bb7783348f04c056d.scope"
      }
    ],
    "ips": [
      "10.77.0.203"
    ],
    "name": "coredns-cc6ccd49c-jjxdr",
    "namespace": "kube-system"
  }
]

