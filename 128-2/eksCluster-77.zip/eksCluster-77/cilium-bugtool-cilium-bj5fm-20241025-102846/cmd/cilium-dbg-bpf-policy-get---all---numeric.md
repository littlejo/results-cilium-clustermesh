Endpoint ID: 228
Path: /sys/fs/bpf/tc/globals/cilium_policy_00228

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    68242   783       0        
Allow    Egress      0          ANY          NONE         disabled    11872   120       0        


Endpoint ID: 527
Path: /sys/fs/bpf/tc/globals/cilium_policy_00527

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1500
Path: /sys/fs/bpf/tc/globals/cilium_policy_01500

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    445512   5689      0        
Allow    Ingress     1          ANY          NONE         disabled    10328    120       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2305
Path: /sys/fs/bpf/tc/globals/cilium_policy_02305

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    68770   791       0        
Allow    Egress      0          ANY          NONE         disabled    13128   135       0        


Endpoint ID: 2663
Path: /sys/fs/bpf/tc/globals/cilium_policy_02663

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3901083   36138     0        
Allow    Ingress     1          ANY          NONE         disabled    2827499   28272     0        
Allow    Egress      0          ANY          NONE         disabled    3963952   36903     0        


