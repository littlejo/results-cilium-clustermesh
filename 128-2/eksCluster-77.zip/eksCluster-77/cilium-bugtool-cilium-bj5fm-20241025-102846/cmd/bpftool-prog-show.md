29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:15:54+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:54+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:54+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:54+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:54+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:15:54+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:15:55+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:15:55+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:55+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:55+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:15:55+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:15:55+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:15:59+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:16:11+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
479: sched_cls  name tail_handle_ipv4  tag 1a0a75b8b5f4e99b  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
480: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
481: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
483: sched_cls  name __send_drop_notify  tag 86b08defe167161e  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 130
484: sched_cls  name tail_handle_ipv4_from_host  tag 00517d8f13cdde62  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,102
	btf_id 131
486: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,102
	btf_id 133
487: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,102
	btf_id 134
488: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 135
489: sched_cls  name tail_handle_ipv4_from_host  tag 00517d8f13cdde62  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,104
	btf_id 137
491: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,104
	btf_id 139
493: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 141
495: sched_cls  name __send_drop_notify  tag 86b08defe167161e  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 143
496: sched_cls  name tail_handle_ipv4_from_host  tag 00517d8f13cdde62  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,105
	btf_id 145
498: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,105
	btf_id 147
501: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,105,75
	btf_id 150
502: sched_cls  name __send_drop_notify  tag 86b08defe167161e  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 151
503: sched_cls  name __send_drop_notify  tag 86b08defe167161e  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 153
504: sched_cls  name tail_handle_ipv4_from_host  tag 00517d8f13cdde62  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,107
	btf_id 154
506: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,107
	btf_id 156
509: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,107,75
	btf_id 159
514: sched_cls  name tail_ipv4_to_endpoint  tag d768a1fd162f1344  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 164
516: sched_cls  name __send_drop_notify  tag 993486759ad5c48e  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 168
518: sched_cls  name handle_policy  tag 7b78b8e82b32077f  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 170
522: sched_cls  name tail_handle_ipv4  tag 78b9696a34d6155a  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 172
523: sched_cls  name tail_handle_arp  tag a45c5463276b0941  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 175
524: sched_cls  name tail_ipv4_ct_ingress  tag 4dad3265b3855b9e  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 177
527: sched_cls  name tail_handle_ipv4_cont  tag 29bd309c3a714abe  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 178
528: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 182
530: sched_cls  name cil_from_container  tag 6c012552262051a1  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 184
531: sched_cls  name handle_policy  tag c6096597aef3e826  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 181
532: sched_cls  name tail_ipv4_ct_egress  tag a7ed4a6df42af84c  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 185
533: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 188
534: sched_cls  name tail_handle_ipv4  tag 4d36d96aee8923df  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 186
535: sched_cls  name tail_handle_ipv4  tag e74dfb7805f1503c  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,117
	btf_id 189
536: sched_cls  name tail_handle_ipv4_cont  tag 9fff2741d985c6d0  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 190
537: sched_cls  name cil_from_container  tag b99a7ff52e709c3f  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 192
538: sched_cls  name handle_policy  tag d7b66a9986c66543  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,117,82,83,118,41,80,100,39,84,75,40,37,38
	btf_id 191
539: sched_cls  name tail_handle_ipv4_cont  tag b602b75710337035  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,118,41,100,82,83,39,76,74,77,117,40,37,38,81
	btf_id 194
540: sched_cls  name tail_ipv4_ct_ingress  tag 43ee07df71403847  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 193
541: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,117
	btf_id 195
542: sched_cls  name cil_from_container  tag 142061466189d98d  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 117,76
	btf_id 196
545: sched_cls  name tail_ipv4_to_endpoint  tag 922bd30317763780  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,118,41,82,83,80,100,39,117,40,37,38
	btf_id 198
546: sched_cls  name tail_ipv4_to_endpoint  tag 6afd6bd7bd2c0493  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 200
547: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 201
548: sched_cls  name tail_ipv4_ct_egress  tag a7ed4a6df42af84c  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 202
549: sched_cls  name tail_handle_arp  tag 0adc3c321461ffe9  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 203
550: sched_cls  name __send_drop_notify  tag fc829f21d6569c1c  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 205
551: sched_cls  name tail_handle_arp  tag c1e9d688774b8edc  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,117
	btf_id 204
552: sched_cls  name __send_drop_notify  tag 44671162446fcdd6  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 206
553: sched_cls  name tail_ipv4_ct_ingress  tag a90db5661f735312  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 207
554: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
557: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
558: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
561: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
562: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
565: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
566: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
569: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
609: sched_cls  name tail_ipv4_ct_egress  tag cc57486fbd4855fa  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 221
610: sched_cls  name tail_handle_arp  tag de8693bc8b467d21  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,134
	btf_id 222
611: sched_cls  name handle_policy  tag 62499a7b49956847  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,134,82,83,135,41,80,133,39,84,75,40,37,38
	btf_id 223
612: sched_cls  name tail_ipv4_ct_ingress  tag 257c02dcdfaadbd6  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 224
613: sched_cls  name tail_handle_ipv4  tag 55a369d7172b5e23  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,134
	btf_id 225
614: sched_cls  name tail_handle_ipv4_cont  tag 03caa750f95e4e53  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,135,41,133,82,83,39,76,74,77,134,40,37,38,81
	btf_id 226
615: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,134
	btf_id 227
616: sched_cls  name cil_from_container  tag 1e203621b9d9b5f2  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 134,76
	btf_id 228
617: sched_cls  name tail_ipv4_to_endpoint  tag f9a02e5f46106e08  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,135,41,82,83,80,133,39,134,40,37,38
	btf_id 229
619: sched_cls  name __send_drop_notify  tag c61f867652416fd4  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 231
620: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
623: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
636: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
639: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
643: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
644: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
647: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
