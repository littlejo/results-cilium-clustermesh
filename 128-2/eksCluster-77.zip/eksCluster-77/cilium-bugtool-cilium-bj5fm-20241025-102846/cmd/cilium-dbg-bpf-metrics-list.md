REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     208259    83790123   1132   bpf_host.c
Interface                 INGRESS     9583      748351     677    bpf_overlay.c
Success                   EGRESS      4580      349713     1694   bpf_host.c
Success                   EGRESS      87613     11945883   1308   bpf_lxc.c
Success                   EGRESS      9400      735141     53     encap.h
Success                   INGRESS     104249    12494893   235    trace.h
Success                   INGRESS     98597     12052349   86     l3.h
Unsupported L3 protocol   EGRESS      36        2676       1492   bpf_lxc.c
