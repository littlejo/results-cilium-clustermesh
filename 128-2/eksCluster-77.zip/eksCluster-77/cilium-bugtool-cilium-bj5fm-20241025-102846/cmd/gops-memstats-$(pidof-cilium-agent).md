alloc: 81.13MB (85073008 bytes)
total-alloc: 1.31GB (1402910096 bytes)
sys: 222.38MB (233186644 bytes)
lookups: 0
mallocs: 47390270
frees: 46861790
heap-alloc: 81.13MB (85073008 bytes)
heap-sys: 178.80MB (187482112 bytes)
heap-idle: 56.09MB (58818560 bytes)
heap-in-use: 122.70MB (128663552 bytes)
heap-released: 12.62MB (13230080 bytes)
heap-objects: 528480
stack-in-use: 33.16MB (34766848 bytes)
stack-sys: 33.16MB (34766848 bytes)
stack-mspan-inuse: 1.91MB (1999040 bytes)
stack-mspan-sys: 2.44MB (2562240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 930.47KB (952801 bytes)
gc-sys: 5.17MB (5423408 bytes)
next-gc: when heap-alloc >= 145.55MB (152619832 bytes)
last-gc: 2024-10-25 10:29:14.780518597 +0000 UTC
gc-pause-total: 16.323039ms
gc-pause: 71303
gc-pause-end: 1729852154780518597
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.0003902280816987386
enable-gc: true
debug-gc: false
