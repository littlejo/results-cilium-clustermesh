 10:28:48 up 12 min,  0 users,  load average: 0.07, 0.12, 0.13
