1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d6:0b:d9:3c:cb brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.137.105/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2730sec preferred_lft 2730sec
    inet6 fe80::4d6:bff:fed9:3ccb/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d8:a6:c0:85:41 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.177.110/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4d8:a6ff:fec0:8541/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:38:ab:39:bf:7c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e438:abff:fe39:bf7c/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:2a:69:4e:a0:1b brd ff:ff:ff:ff:ff:ff
    inet 10.68.0.19/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::642a:69ff:fe4e:a01b/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 4a:6b:0e:ee:e9:f5 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::486b:eff:feee:e9f5/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:9a:92:1d:ae:0c brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::49a:92ff:fe1d:ae0c/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc6524a0eddf54@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:4c:67:aa:cc:be brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::b04c:67ff:feaa:ccbe/64 scope link 
       valid_lft forever preferred_lft forever
14: lxca94717be4d2c@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:f5:cf:79:4d:fb brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::f8f5:cfff:fe79:4dfb/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcbdbb169746fd@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:89:03:f6:18:75 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::8089:3ff:fef6:1875/64 scope link 
       valid_lft forever preferred_lft forever
