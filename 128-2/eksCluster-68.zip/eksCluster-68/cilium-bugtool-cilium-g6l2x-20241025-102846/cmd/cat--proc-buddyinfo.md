Node 0, zone      DMA      2      9     15      6      6     43     13     15     10      4    162 
Node 0, zone   Normal    946    223     90     19     26      7      4      4      1      2      6 
