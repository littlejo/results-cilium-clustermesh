Total: 560
TCP:   1099 (estab 317, closed 763, orphaned 0, timewait 299)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  336       324       12       
INET	  346       330       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                  Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                           127.0.0.1:41861      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:23958 sk:27c fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                 172.31.137.105%ens5:68         0.0.0.0:*    uid:192 ino:15563 sk:27d cgroup:unreachable:c4e <->                            
UNCONN 0      0                             0.0.0.0:8472       0.0.0.0:*    ino:25294 sk:27e cgroup:/ <->                                                  
UNCONN 0      0                           127.0.0.1:323        0.0.0.0:*    ino:15356 sk:27f cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                [::]:8472          [::]:*    ino:25293 sk:280 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                               [::1]:323           [::]:*    ino:15357 sk:281 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::4d6:bff:fed9:3ccb]%ens5:546           [::]:*    uid:192 ino:15554 sk:282 cgroup:unreachable:c4e v6only:1 <->                   
