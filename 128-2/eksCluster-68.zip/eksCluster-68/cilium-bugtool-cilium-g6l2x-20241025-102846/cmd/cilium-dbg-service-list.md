ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.178.125:443 (active)    
                                         2 => 172.31.250.226:443 (active)    
2    10.100.138.10:443    ClusterIP      1 => 172.31.137.105:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.68.0.2:53 (active)          
                                         2 => 10.68.0.116:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.68.0.2:9153 (active)        
                                         2 => 10.68.0.116:9153 (active)      
5    10.100.86.106:2379   ClusterIP      1 => 10.68.0.32:2379 (active)       
