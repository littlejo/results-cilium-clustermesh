 10:28:47 up 14 min,  0 users,  load average: 0.75, 0.26, 0.15
