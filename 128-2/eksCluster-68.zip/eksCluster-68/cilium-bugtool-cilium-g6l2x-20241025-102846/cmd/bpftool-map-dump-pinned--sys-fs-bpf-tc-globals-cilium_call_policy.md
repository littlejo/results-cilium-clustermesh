key: c1 02 00 00  value: 0a 02 00 00
key: 28 03 00 00  value: 74 02 00 00
key: 15 05 00 00  value: 19 02 00 00
key: a5 06 00 00  value: fe 01 00 00
Found 4 elements
