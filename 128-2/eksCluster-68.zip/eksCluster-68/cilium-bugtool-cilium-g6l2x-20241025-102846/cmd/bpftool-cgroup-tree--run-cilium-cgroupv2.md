CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0f0764f4_2662_4cf5_b48c_b8f54ce25c3a.slice/cri-containerd-41ea69c5ca00947ec42ef59cdc4ced0c92a220354350900eea5318d61b277941.scope
    521      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0f0764f4_2662_4cf5_b48c_b8f54ce25c3a.slice/cri-containerd-f79407cd68ae3f9d9efa8edcc810ac94605689f8c54525b4e26159e67fefd933.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7d12865a_f839_4740_a439_c54ef561a06a.slice/cri-containerd-7c53df7e823478bda16b3e2135e7b005b3c8e1d0b63561bd60f2e6481bc9d738.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7d12865a_f839_4740_a439_c54ef561a06a.slice/cri-containerd-fcf2ee5b1d15cee70749c1bb3831f2e243ab78e08bb4f79d2ba5ac7142527065.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd858c600_36d2_40ad_bb90_ad5516dcbb2b.slice/cri-containerd-bcf94ce907f1011db7377b179e1176d3725d54e023192b32c9375e6bc07c23be.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd858c600_36d2_40ad_bb90_ad5516dcbb2b.slice/cri-containerd-4efe80b56f6448027602e06092392e8664965a19a4af14a9a9b5bfb651ecb368.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd39532dc_2dfa_4ea1_9deb_423d170d950f.slice/cri-containerd-23ea22ca177b51e02f962c0dc31e22ab9c8e5d14f27bad52a0be7a69a2bdb5f4.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd39532dc_2dfa_4ea1_9deb_423d170d950f.slice/cri-containerd-e5b5ba56103b9f3570f49c1e19015cf38e4e15acb92c404d024671d9d81ef696.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc222c1fc_08a0_4a9c_9fc8_dc6905764f56.slice/cri-containerd-2aec4ae9b9b21680aa2a4f965e6e04bb0dc37f51879e9af63c07bf67bed1fc7e.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc222c1fc_08a0_4a9c_9fc8_dc6905764f56.slice/cri-containerd-0eef854df10376d621361550271455ff3f86ef3577c970ac0e3eec5bf9ee6ed5.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc222c1fc_08a0_4a9c_9fc8_dc6905764f56.slice/cri-containerd-e9334518512af1d930c1850608a181a21ea910c3798b98cdddb17d032a746da3.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc222c1fc_08a0_4a9c_9fc8_dc6905764f56.slice/cri-containerd-b01632642e2c37723d45d37cb0c5db1c53e74e7f9136967578fa07faa27c55a7.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod169704fa_4774_41bb_8ae8_9ef3a51f6c91.slice/cri-containerd-a1e333f0e54f3d96a3d897021e20811c566ca0dc3dff73cd2476cecc055c1d73.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod169704fa_4774_41bb_8ae8_9ef3a51f6c91.slice/cri-containerd-ed836b155030b08a6a28310d500c8242670beb964ef5d912c280453def74441a.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode4f97c30_6c0e_41ee_9133_e357cb16378e.slice/cri-containerd-3294d5029ba3b96cc0349b0f6c32e612e14d62594ae90026bacbde0a4aa9982d.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode4f97c30_6c0e_41ee_9133_e357cb16378e.slice/cri-containerd-8bd9365b5ac8f4289f68fe75a4b2d8d170b2521cc52edde746b5d18e0f31e32f.scope
    99       cgroup_device   multi                                          
