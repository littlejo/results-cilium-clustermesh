KEY             VALUE
AgentLiveness   910373352938
UTimeOffset     3378615718750000
