Endpoint ID: 705
Path: /sys/fs/bpf/tc/globals/cilium_policy_00705

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    441622   5634      0        
Allow    Ingress     1          ANY          NONE         disabled    10574    121       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 808
Path: /sys/fs/bpf/tc/globals/cilium_policy_00808

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3894109   35855     0        
Allow    Ingress     1          ANY          NONE         disabled    2911713   29208     0        
Allow    Egress      0          ANY          NONE         disabled    3712307   34729     0        


Endpoint ID: 1301
Path: /sys/fs/bpf/tc/globals/cilium_policy_01301

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    76957   883       0        
Allow    Egress      0          ANY          NONE         disabled    13164   137       0        


Endpoint ID: 1701
Path: /sys/fs/bpf/tc/globals/cilium_policy_01701

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    76441   880       0        
Allow    Egress      0          ANY          NONE         disabled    13936   145       0        


Endpoint ID: 3696
Path: /sys/fs/bpf/tc/globals/cilium_policy_03696

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


