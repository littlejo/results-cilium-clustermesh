top - 10:28:47 up 14 min,  0 users,  load average: 0.75, 0.26, 0.15
Tasks:   6 total,   2 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 71.0 us, 29.0 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    794.3 free,    900.0 used,   2141.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2767.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 282916  79680 S  81.2   7.2   0:20.96 cilium-+
    644 root      20   0 1240432  16004  10768 S  12.5   0.4   0:00.04 cilium-+
    396 root      20   0 1228848   7336   4028 S   0.0   0.2   0:00.27 cilium-+
    650 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    696 root      20   0    6576   2412   2088 R   0.0   0.1   0:00.00 top
    714 root      20   0    3852   1280   1124 R   0.0   0.0   0:00.00 bash
