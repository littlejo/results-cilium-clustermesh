IP ADDRESS         LOCAL ENDPOINT INFO
172.31.137.105:0   (localhost)                                                                                        
10.68.0.164:0      id=705   sec_id=4     flags=0x0000 ifindex=10  mac=E6:3E:67:D5:8C:EC nodemac=06:9A:92:1D:AE:0C     
10.68.0.2:0        id=1701  sec_id=4586135 flags=0x0000 ifindex=14  mac=92:B9:3F:2E:9F:CA nodemac=FA:F5:CF:79:4D:FB   
10.68.0.32:0       id=808   sec_id=4557083 flags=0x0000 ifindex=18  mac=76:E9:95:94:D9:2A nodemac=82:89:03:F6:18:75   
10.68.0.116:0      id=1301  sec_id=4586135 flags=0x0000 ifindex=12  mac=F2:93:30:A9:A3:E4 nodemac=B2:4C:67:AA:CC:BE   
172.31.177.110:0   (localhost)                                                                                        
10.68.0.19:0       (localhost)                                                                                        
