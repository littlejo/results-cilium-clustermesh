alloc: 121.23MB (127123576 bytes)
total-alloc: 1.32GB (1420516480 bytes)
sys: 206.38MB (216409428 bytes)
lookups: 0
mallocs: 47609255
frees: 46411223
heap-alloc: 121.23MB (127123576 bytes)
heap-sys: 161.30MB (169132032 bytes)
heap-idle: 20.77MB (21774336 bytes)
heap-in-use: 140.53MB (147357696 bytes)
heap-released: 616.00KB (630784 bytes)
heap-objects: 1198032
stack-in-use: 34.66MB (36339712 bytes)
stack-sys: 34.66MB (36339712 bytes)
stack-mspan-inuse: 2.19MB (2294240 bytes)
stack-mspan-sys: 2.49MB (2611200 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 900.75KB (922369 bytes)
gc-sys: 5.14MB (5394568 bytes)
next-gc: when heap-alloc >= 161.32MB (169153256 bytes)
last-gc: 2024-10-25 10:28:47.935231971 +0000 UTC
gc-pause-total: 10.009444ms
gc-pause: 987227
gc-pause-end: 1729852127935231971
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.0003796438563503355
enable-gc: true
debug-gc: false
