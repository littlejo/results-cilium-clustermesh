{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:32.815Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.137.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:32.815Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.177.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:32.815Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:37.332Z",
  "value": "id=705   sec_id=4     flags=0x0000 ifindex=10  mac=E6:3E:67:D5:8C:EC nodemac=06:9A:92:1D:AE:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:37.336Z",
  "value": "id=1301  sec_id=4586135 flags=0x0000 ifindex=12  mac=F2:93:30:A9:A3:E4 nodemac=B2:4C:67:AA:CC:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:37.401Z",
  "value": "id=1701  sec_id=4586135 flags=0x0000 ifindex=14  mac=92:B9:3F:2E:9F:CA nodemac=FA:F5:CF:79:4D:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:37.466Z",
  "value": "id=705   sec_id=4     flags=0x0000 ifindex=10  mac=E6:3E:67:D5:8C:EC nodemac=06:9A:92:1D:AE:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:37.508Z",
  "value": "id=1301  sec_id=4586135 flags=0x0000 ifindex=12  mac=F2:93:30:A9:A3:E4 nodemac=B2:4C:67:AA:CC:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:19.967Z",
  "value": "id=705   sec_id=4     flags=0x0000 ifindex=10  mac=E6:3E:67:D5:8C:EC nodemac=06:9A:92:1D:AE:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:19.967Z",
  "value": "id=1301  sec_id=4586135 flags=0x0000 ifindex=12  mac=F2:93:30:A9:A3:E4 nodemac=B2:4C:67:AA:CC:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:19.968Z",
  "value": "id=1701  sec_id=4586135 flags=0x0000 ifindex=14  mac=92:B9:3F:2E:9F:CA nodemac=FA:F5:CF:79:4D:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:19.999Z",
  "value": "id=173   sec_id=4557083 flags=0x0000 ifindex=16  mac=42:80:9C:B7:6B:F1 nodemac=0E:8C:AB:58:3C:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:20.000Z",
  "value": "id=173   sec_id=4557083 flags=0x0000 ifindex=16  mac=42:80:9C:B7:6B:F1 nodemac=0E:8C:AB:58:3C:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:02.263Z",
  "value": "id=808   sec_id=4557083 flags=0x0000 ifindex=18  mac=76:E9:95:94:D9:2A nodemac=82:89:03:F6:18:75"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.68.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:07.551Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.383Z",
  "value": "id=1301  sec_id=4586135 flags=0x0000 ifindex=12  mac=F2:93:30:A9:A3:E4 nodemac=B2:4C:67:AA:CC:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.384Z",
  "value": "id=1701  sec_id=4586135 flags=0x0000 ifindex=14  mac=92:B9:3F:2E:9F:CA nodemac=FA:F5:CF:79:4D:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.384Z",
  "value": "id=808   sec_id=4557083 flags=0x0000 ifindex=18  mac=76:E9:95:94:D9:2A nodemac=82:89:03:F6:18:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.385Z",
  "value": "id=705   sec_id=4     flags=0x0000 ifindex=10  mac=E6:3E:67:D5:8C:EC nodemac=06:9A:92:1D:AE:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.384Z",
  "value": "id=705   sec_id=4     flags=0x0000 ifindex=10  mac=E6:3E:67:D5:8C:EC nodemac=06:9A:92:1D:AE:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.384Z",
  "value": "id=808   sec_id=4557083 flags=0x0000 ifindex=18  mac=76:E9:95:94:D9:2A nodemac=82:89:03:F6:18:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.384Z",
  "value": "id=1301  sec_id=4586135 flags=0x0000 ifindex=12  mac=F2:93:30:A9:A3:E4 nodemac=B2:4C:67:AA:CC:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.385Z",
  "value": "id=1701  sec_id=4586135 flags=0x0000 ifindex=14  mac=92:B9:3F:2E:9F:CA nodemac=FA:F5:CF:79:4D:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:19.384Z",
  "value": "id=808   sec_id=4557083 flags=0x0000 ifindex=18  mac=76:E9:95:94:D9:2A nodemac=82:89:03:F6:18:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:19.384Z",
  "value": "id=1701  sec_id=4586135 flags=0x0000 ifindex=14  mac=92:B9:3F:2E:9F:CA nodemac=FA:F5:CF:79:4D:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:19.384Z",
  "value": "id=1301  sec_id=4586135 flags=0x0000 ifindex=12  mac=F2:93:30:A9:A3:E4 nodemac=B2:4C:67:AA:CC:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.68.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:19.385Z",
  "value": "id=705   sec_id=4     flags=0x0000 ifindex=10  mac=E6:3E:67:D5:8C:EC nodemac=06:9A:92:1D:AE:0C"
}

