[
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc222c1fc_08a0_4a9c_9fc8_dc6905764f56.slice/cri-containerd-2aec4ae9b9b21680aa2a4f965e6e04bb0dc37f51879e9af63c07bf67bed1fc7e.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc222c1fc_08a0_4a9c_9fc8_dc6905764f56.slice/cri-containerd-b01632642e2c37723d45d37cb0c5db1c53e74e7f9136967578fa07faa27c55a7.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc222c1fc_08a0_4a9c_9fc8_dc6905764f56.slice/cri-containerd-0eef854df10376d621361550271455ff3f86ef3577c970ac0e3eec5bf9ee6ed5.scope"
      }
    ],
    "ips": [
      "10.68.0.32"
    ],
    "name": "clustermesh-apiserver-77cb5b8554-9gr6v",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7d12865a_f839_4740_a439_c54ef561a06a.slice/cri-containerd-fcf2ee5b1d15cee70749c1bb3831f2e243ab78e08bb4f79d2ba5ac7142527065.scope"
      }
    ],
    "ips": [
      "10.68.0.2"
    ],
    "name": "coredns-cc6ccd49c-bp5d7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0f0764f4_2662_4cf5_b48c_b8f54ce25c3a.slice/cri-containerd-f79407cd68ae3f9d9efa8edcc810ac94605689f8c54525b4e26159e67fefd933.scope"
      }
    ],
    "ips": [
      "10.68.0.116"
    ],
    "name": "coredns-cc6ccd49c-n6dnq",
    "namespace": "kube-system"
  }
]

