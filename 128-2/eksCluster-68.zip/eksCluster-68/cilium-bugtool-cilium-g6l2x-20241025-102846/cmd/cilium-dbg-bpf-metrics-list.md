REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     212465    84080838   1132   bpf_host.c
Interface                 INGRESS     9610      749827     677    bpf_overlay.c
Success                   EGRESS      4674      355949     1694   bpf_host.c
Success                   EGRESS      87792     11999290   1308   bpf_lxc.c
Success                   EGRESS      9461      738662     53     encap.h
Success                   INGRESS     104765    12465486   235    trace.h
Success                   INGRESS     99180     12027702   86     l3.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
