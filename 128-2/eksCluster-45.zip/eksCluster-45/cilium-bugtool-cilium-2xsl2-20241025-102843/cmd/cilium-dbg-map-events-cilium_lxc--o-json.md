{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:12.016Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.210.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:12.016Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.211.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:12.016Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:14.486Z",
  "value": "id=1080  sec_id=4     flags=0x0000 ifindex=10  mac=56:32:23:23:9E:7C nodemac=B2:1A:31:BE:9C:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:17.761Z",
  "value": "id=1253  sec_id=3023022 flags=0x0000 ifindex=12  mac=DE:71:F4:4F:9E:41 nodemac=96:86:25:B6:FC:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:17.761Z",
  "value": "id=1080  sec_id=4     flags=0x0000 ifindex=10  mac=56:32:23:23:9E:7C nodemac=B2:1A:31:BE:9C:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:17.837Z",
  "value": "id=64    sec_id=3023022 flags=0x0000 ifindex=14  mac=AE:AE:19:44:A0:82 nodemac=C2:70:07:B6:45:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:17.873Z",
  "value": "id=1080  sec_id=4     flags=0x0000 ifindex=10  mac=56:32:23:23:9E:7C nodemac=B2:1A:31:BE:9C:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:26.976Z",
  "value": "id=1080  sec_id=4     flags=0x0000 ifindex=10  mac=56:32:23:23:9E:7C nodemac=B2:1A:31:BE:9C:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:26.977Z",
  "value": "id=1253  sec_id=3023022 flags=0x0000 ifindex=12  mac=DE:71:F4:4F:9E:41 nodemac=96:86:25:B6:FC:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:26.977Z",
  "value": "id=64    sec_id=3023022 flags=0x0000 ifindex=14  mac=AE:AE:19:44:A0:82 nodemac=C2:70:07:B6:45:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:27.008Z",
  "value": "id=671   sec_id=3068569 flags=0x0000 ifindex=16  mac=DA:B5:D8:0D:FC:02 nodemac=32:D6:BC:8E:F8:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:27.976Z",
  "value": "id=1080  sec_id=4     flags=0x0000 ifindex=10  mac=56:32:23:23:9E:7C nodemac=B2:1A:31:BE:9C:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:27.976Z",
  "value": "id=671   sec_id=3068569 flags=0x0000 ifindex=16  mac=DA:B5:D8:0D:FC:02 nodemac=32:D6:BC:8E:F8:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:27.977Z",
  "value": "id=1253  sec_id=3023022 flags=0x0000 ifindex=12  mac=DE:71:F4:4F:9E:41 nodemac=96:86:25:B6:FC:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:27.977Z",
  "value": "id=64    sec_id=3023022 flags=0x0000 ifindex=14  mac=AE:AE:19:44:A0:82 nodemac=C2:70:07:B6:45:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:27.624Z",
  "value": "id=2484  sec_id=3068569 flags=0x0000 ifindex=18  mac=AE:5D:2E:34:32:B6 nodemac=12:BA:0A:7E:30:03"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.45.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:37.984Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:37.720Z",
  "value": "id=2484  sec_id=3068569 flags=0x0000 ifindex=18  mac=AE:5D:2E:34:32:B6 nodemac=12:BA:0A:7E:30:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:37.720Z",
  "value": "id=1080  sec_id=4     flags=0x0000 ifindex=10  mac=56:32:23:23:9E:7C nodemac=B2:1A:31:BE:9C:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:37.721Z",
  "value": "id=1253  sec_id=3023022 flags=0x0000 ifindex=12  mac=DE:71:F4:4F:9E:41 nodemac=96:86:25:B6:FC:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:37.721Z",
  "value": "id=64    sec_id=3023022 flags=0x0000 ifindex=14  mac=AE:AE:19:44:A0:82 nodemac=C2:70:07:B6:45:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:38.720Z",
  "value": "id=1253  sec_id=3023022 flags=0x0000 ifindex=12  mac=DE:71:F4:4F:9E:41 nodemac=96:86:25:B6:FC:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:38.720Z",
  "value": "id=2484  sec_id=3068569 flags=0x0000 ifindex=18  mac=AE:5D:2E:34:32:B6 nodemac=12:BA:0A:7E:30:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:38.721Z",
  "value": "id=64    sec_id=3023022 flags=0x0000 ifindex=14  mac=AE:AE:19:44:A0:82 nodemac=C2:70:07:B6:45:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:38.721Z",
  "value": "id=1080  sec_id=4     flags=0x0000 ifindex=10  mac=56:32:23:23:9E:7C nodemac=B2:1A:31:BE:9C:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:39.721Z",
  "value": "id=1080  sec_id=4     flags=0x0000 ifindex=10  mac=56:32:23:23:9E:7C nodemac=B2:1A:31:BE:9C:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:39.721Z",
  "value": "id=2484  sec_id=3068569 flags=0x0000 ifindex=18  mac=AE:5D:2E:34:32:B6 nodemac=12:BA:0A:7E:30:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:39.721Z",
  "value": "id=1253  sec_id=3023022 flags=0x0000 ifindex=12  mac=DE:71:F4:4F:9E:41 nodemac=96:86:25:B6:FC:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:39.721Z",
  "value": "id=64    sec_id=3023022 flags=0x0000 ifindex=14  mac=AE:AE:19:44:A0:82 nodemac=C2:70:07:B6:45:2D"
}

