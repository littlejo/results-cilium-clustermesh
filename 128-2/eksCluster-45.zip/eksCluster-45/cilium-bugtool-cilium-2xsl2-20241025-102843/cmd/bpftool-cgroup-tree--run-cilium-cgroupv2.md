CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3da76841_892f_4e57_8954_8aa5a186d427.slice/cri-containerd-7706480b0b23708ba96203286a9e8692963e6e80b8cf39b17bceb35038df512d.scope
    608      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3da76841_892f_4e57_8954_8aa5a186d427.slice/cri-containerd-8aaab0284b982a528feeba99b06059973f32af126d4a213b42db843d4060b2ee.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode709aa45_56c6_4d43_a8d1_611ceb8c11bb.slice/cri-containerd-9baf6b8c6a7de8100f2b619cb7adac506397eefd98f518de638048f0e4562364.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode709aa45_56c6_4d43_a8d1_611ceb8c11bb.slice/cri-containerd-fc92b81a807c1aaf86e7d6a88026a5d4dd6077e505df42bcb363d30fc6ba73d2.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5c7a4ea4_e39b_4441_8075_ee4a318c247f.slice/cri-containerd-adb549f2d2e049c1eacd9638e66b583b1d8e161faf3ddba67316d499e0faf960.scope
    604      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5c7a4ea4_e39b_4441_8075_ee4a318c247f.slice/cri-containerd-c3d9e8f3fa4df33a86c60b99b7d32b304b943c44e6138a78a29679cfcaa0d762.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod05ab306e_4bc1_47dc_9176_f032f0223ca9.slice/cri-containerd-ecbde49fd01609d445d0758deb9166f29dba2af5650dff65fd32de123aa3e7ec.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod05ab306e_4bc1_47dc_9176_f032f0223ca9.slice/cri-containerd-01d56b779d4c82f3804f4c2a851ba515006a340266addf598a07561c9baf3f2f.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ed80e08_c81b_422c_ae1e_efd7112b1399.slice/cri-containerd-530f1fd964aa621b6eba9e6f45e6724aa2797c4cb1f892563fb6334b277001c0.scope
    686      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ed80e08_c81b_422c_ae1e_efd7112b1399.slice/cri-containerd-c6e2422d830879a7bb14f42d95d15a7949583b4adc7dbf88eb789a3186beecf4.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ed80e08_c81b_422c_ae1e_efd7112b1399.slice/cri-containerd-07463a3b057f1acc71b91446b81f0542ee5ef824aecf3acd6b6a3b828a2f0243.scope
    682      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ed80e08_c81b_422c_ae1e_efd7112b1399.slice/cri-containerd-b39ebec74fc05729390805b7fe4ccf8023c55978bb1d2cd45ef2a6157da3fd61.scope
    662      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04cc2019_7ab4_438f_b9c9_2f67252897dc.slice/cri-containerd-fa1696bad2b12631221270bd4d3f989346e8b9736111e3c0433a9aac9d737bd2.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04cc2019_7ab4_438f_b9c9_2f67252897dc.slice/cri-containerd-22464a863185de8752b4ac87ea424df0c8e6019fa3ddfb4e3756855c620ad115.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6cfc3ba_097b_48c5_8918_a8508a0ddc0e.slice/cri-containerd-780469460b1fe1749c8c6abeda8c6170bd9df3464d07cab1d6ee615519d78995.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6cfc3ba_097b_48c5_8918_a8508a0ddc0e.slice/cri-containerd-268d276501c716ee4803a30e08066b5146445834c6b210e8b6cbf486255c9cc0.scope
    91       cgroup_device   multi                                          
