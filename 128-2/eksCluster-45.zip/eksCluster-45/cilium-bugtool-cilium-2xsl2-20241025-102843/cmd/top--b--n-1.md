top - 10:28:44 up 12 min,  0 users,  load average: 0.00, 0.14, 0.15
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 41.9 us, 29.0 sy,  0.0 ni, 29.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    793.6 free,    900.6 used,   2141.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2766.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 281276  79748 S  37.5   7.2   0:18.07 cilium-+
    670 root      20   0 1240432  16272  11292 S   6.2   0.4   0:00.03 cilium-+
    396 root      20   0 1228848   7088   3840 S   0.0   0.2   0:00.25 cilium-+
    697 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    720 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
    725 root      20   0 1616264   8756   6248 S   0.0   0.2   0:00.00 runc:[2+
