xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 563
ens6(5) clsact/ingress cil_from_netdev-ens6 id 571
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 556
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 549
cilium_host(7) clsact/egress cil_from_host-cilium_host id 547
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 491
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 492
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 585
lxc3edfa8bf9322(12) clsact/ingress cil_from_container-lxc3edfa8bf9322 id 522
lxc4e199bdc673b(14) clsact/ingress cil_from_container-lxc4e199bdc673b id 573
lxc6fc2791ca447(18) clsact/ingress cil_from_container-lxc6fc2791ca447 id 656

flow_dissector:

netfilter:

