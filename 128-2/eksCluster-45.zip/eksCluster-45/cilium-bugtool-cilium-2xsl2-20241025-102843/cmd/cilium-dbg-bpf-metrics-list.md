REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     189639    81012572   1132   bpf_host.c
Interface                 INGRESS     8369      651538     677    bpf_overlay.c
Success                   EGRESS      3913      296214     1694   bpf_host.c
Success                   EGRESS      80026     10645463   1308   bpf_lxc.c
Success                   EGRESS      8051      628018     53     encap.h
Success                   INGRESS     88973     10756300   86     l3.h
Success                   INGRESS     94078     11155530   235    trace.h
Unsupported L3 protocol   EGRESS      38        2852       1492   bpf_lxc.c
