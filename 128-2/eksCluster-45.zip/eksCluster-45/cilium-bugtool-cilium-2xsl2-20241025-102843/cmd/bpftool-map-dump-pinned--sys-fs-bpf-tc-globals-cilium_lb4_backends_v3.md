key: 06 00 00 00  value: 0a 2d 00 49 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f d4 93 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 2d 00 5d 23 c1 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 2d 00 49 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f ba d5 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f d2 61 10 94 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 2d 00 4b 09 4b 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 2d 00 5d 00 35 00 00  00 00 00 00
Found 8 elements
