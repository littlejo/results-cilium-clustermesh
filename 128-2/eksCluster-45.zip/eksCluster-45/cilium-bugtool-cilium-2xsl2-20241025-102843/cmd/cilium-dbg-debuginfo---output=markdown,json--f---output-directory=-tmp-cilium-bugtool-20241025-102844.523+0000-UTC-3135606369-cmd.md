markdown output at /tmp/cilium-bugtool-20241025-102844.523+0000-UTC-3135606369/cmd/cilium-debuginfo-20241025-102846.222+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102844.523+0000-UTC-3135606369/cmd/cilium-debuginfo-20241025-102846.222+0000-UTC.json
