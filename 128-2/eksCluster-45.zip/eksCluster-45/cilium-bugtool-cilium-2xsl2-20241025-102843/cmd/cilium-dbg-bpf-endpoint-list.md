IP ADDRESS        LOCAL ENDPOINT INFO
172.31.210.97:0   (localhost)                                                                                        
10.45.0.93:0      id=64    sec_id=3023022 flags=0x0000 ifindex=14  mac=AE:AE:19:44:A0:82 nodemac=C2:70:07:B6:45:2D   
10.45.0.89:0      (localhost)                                                                                        
172.31.211.95:0   (localhost)                                                                                        
10.45.0.75:0      id=2484  sec_id=3068569 flags=0x0000 ifindex=18  mac=AE:5D:2E:34:32:B6 nodemac=12:BA:0A:7E:30:03   
10.45.0.73:0      id=1253  sec_id=3023022 flags=0x0000 ifindex=12  mac=DE:71:F4:4F:9E:41 nodemac=96:86:25:B6:FC:D2   
10.45.0.161:0     id=1080  sec_id=4     flags=0x0000 ifindex=10  mac=56:32:23:23:9E:7C nodemac=B2:1A:31:BE:9C:F7     
