Node 0, zone      DMA     18    282    108     24     18     10     31     33     25      6    164 
Node 0, zone   Normal    692    178     52      7     37     13      5      1      3      0      7 
