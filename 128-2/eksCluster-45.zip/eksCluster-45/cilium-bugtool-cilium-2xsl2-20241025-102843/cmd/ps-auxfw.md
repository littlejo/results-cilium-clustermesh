USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         670  0.0  0.4 1240432 16272 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         685  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         687  0.0  0.0      4     4 ?        R    10:28   0:00  \_ [bash]
root           1  2.5  7.0 1538100 278624 ?      Ssl  10:17   0:18 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.0  0.1 1228848 7088 ?        Sl   10:17   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
