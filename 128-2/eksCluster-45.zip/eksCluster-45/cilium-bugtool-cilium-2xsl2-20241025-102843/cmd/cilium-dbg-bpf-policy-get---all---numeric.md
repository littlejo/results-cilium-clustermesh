Endpoint ID: 64
Path: /sys/fs/bpf/tc/globals/cilium_policy_00064

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    64331   740       0        
Allow    Egress      0          ANY          NONE         disabled    12594   128       0        


Endpoint ID: 1080
Path: /sys/fs/bpf/tc/globals/cilium_policy_01080

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    402562   5148      0        
Allow    Ingress     1          ANY          NONE         disabled    9514     111       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1253
Path: /sys/fs/bpf/tc/globals/cilium_policy_01253

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    64991   750       0        
Allow    Egress      0          ANY          NONE         disabled    12423   126       0        


Endpoint ID: 1315
Path: /sys/fs/bpf/tc/globals/cilium_policy_01315

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2484
Path: /sys/fs/bpf/tc/globals/cilium_policy_02484

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3505385   33113     0        
Allow    Ingress     1          ANY          NONE         disabled    2594163   25707     0        
Allow    Egress      0          ANY          NONE         disabled    3837109   36098     0        


