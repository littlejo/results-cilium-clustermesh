ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.186.213:443 (active)   
                                         2 => 172.31.212.147:443 (active)   
2    10.100.208.65:443    ClusterIP      1 => 172.31.210.97:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.45.0.73:53 (active)        
                                         2 => 10.45.0.93:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.45.0.73:9153 (active)      
                                         2 => 10.45.0.93:9153 (active)      
5    10.100.246.12:2379   ClusterIP      1 => 10.45.0.75:2379 (active)      
