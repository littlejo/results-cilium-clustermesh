[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3da76841_892f_4e57_8954_8aa5a186d427.slice/cri-containerd-7706480b0b23708ba96203286a9e8692963e6e80b8cf39b17bceb35038df512d.scope"
      }
    ],
    "ips": [
      "10.45.0.93"
    ],
    "name": "coredns-cc6ccd49c-gzzxt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5c7a4ea4_e39b_4441_8075_ee4a318c247f.slice/cri-containerd-adb549f2d2e049c1eacd9638e66b583b1d8e161faf3ddba67316d499e0faf960.scope"
      }
    ],
    "ips": [
      "10.45.0.73"
    ],
    "name": "coredns-cc6ccd49c-b72qz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ed80e08_c81b_422c_ae1e_efd7112b1399.slice/cri-containerd-07463a3b057f1acc71b91446b81f0542ee5ef824aecf3acd6b6a3b828a2f0243.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ed80e08_c81b_422c_ae1e_efd7112b1399.slice/cri-containerd-c6e2422d830879a7bb14f42d95d15a7949583b4adc7dbf88eb789a3186beecf4.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ed80e08_c81b_422c_ae1e_efd7112b1399.slice/cri-containerd-530f1fd964aa621b6eba9e6f45e6724aa2797c4cb1f892563fb6334b277001c0.scope"
      }
    ],
    "ips": [
      "10.45.0.75"
    ],
    "name": "clustermesh-apiserver-85bb6bcd77-g9hv6",
    "namespace": "kube-system"
  }
]

