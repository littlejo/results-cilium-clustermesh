alloc: 95.67MB (100312432 bytes)
total-alloc: 1.26GB (1349559856 bytes)
sys: 214.38MB (224798036 bytes)
lookups: 0
mallocs: 46557736
frees: 45748477
heap-alloc: 95.67MB (100312432 bytes)
heap-sys: 169.66MB (177905664 bytes)
heap-idle: 43.10MB (45195264 bytes)
heap-in-use: 126.56MB (132710400 bytes)
heap-released: 13.45MB (14106624 bytes)
heap-objects: 809259
stack-in-use: 34.31MB (35979264 bytes)
stack-sys: 34.31MB (35979264 bytes)
stack-mspan-inuse: 1.98MB (2078880 bytes)
stack-mspan-sys: 2.41MB (2529600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 988.47KB (1012193 bytes)
gc-sys: 5.13MB (5382352 bytes)
next-gc: when heap-alloc >= 142.90MB (149841704 bytes)
last-gc: 2024-10-25 10:28:18.726694281 +0000 UTC
gc-pause-total: 13.478837ms
gc-pause: 229663
gc-pause-end: 1729852098726694281
num-gc: 70
num-forced-gc: 0
gc-cpu-fraction: 0.0003755491328587655
enable-gc: true
debug-gc: false
