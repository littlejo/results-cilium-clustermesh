 10:28:44 up 12 min,  0 users,  load average: 0.00, 0.14, 0.15
