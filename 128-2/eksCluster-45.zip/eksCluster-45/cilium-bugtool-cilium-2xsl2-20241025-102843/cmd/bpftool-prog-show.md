29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:15:49+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:15:49+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:15:50+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:15:50+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:50+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:50+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:15:50+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:15:50+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:15:55+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:16:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
489: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:17:15+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 136
490: sched_cls  name tail_handle_ipv4  tag 3af32e61cd0cef64  gpl
	loaded_at 2024-10-25T10:17:15+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,102
	btf_id 137
491: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:17:15+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,102
	btf_id 138
492: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:17:15+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 139
522: sched_cls  name cil_from_container  tag bbadd6f5c15e2949  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 175
524: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 177
526: sched_cls  name tail_handle_ipv4  tag c2ef2cd7844162b4  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 179
529: sched_cls  name tail_handle_ipv4_cont  tag a5aad908cb6e7a8b  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,114,41,111,82,83,39,76,74,77,115,40,37,38,81
	btf_id 182
531: sched_cls  name tail_ipv4_to_endpoint  tag 409a6b378dc4c9ab  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,114,41,82,83,80,111,39,115,40,37,38
	btf_id 184
536: sched_cls  name handle_policy  tag 35685802fdee7c7f  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,114,41,80,111,39,84,75,40,37,38
	btf_id 186
537: sched_cls  name tail_ipv4_ct_ingress  tag e6437c3e8bdedb13  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,114,84
	btf_id 191
538: sched_cls  name tail_handle_arp  tag 69711a420fe0844b  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 192
539: sched_cls  name tail_ipv4_ct_egress  tag 7c702917970b9bdb  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,114,84
	btf_id 193
541: sched_cls  name __send_drop_notify  tag 8d7c0edd063b846e  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 194
544: sched_cls  name tail_handle_ipv4_from_host  tag d09aad39fb4e5fe1  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 198
545: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 199
547: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,118
	btf_id 201
548: sched_cls  name __send_drop_notify  tag 7af65e446b227cbc  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 202
549: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 203
551: sched_cls  name tail_handle_ipv4_from_host  tag d09aad39fb4e5fe1  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 206
552: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 207
555: sched_cls  name __send_drop_notify  tag 7af65e446b227cbc  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 210
556: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 211
557: sched_cls  name __send_drop_notify  tag 7af65e446b227cbc  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 215
560: sched_cls  name tail_handle_ipv4_from_host  tag d09aad39fb4e5fe1  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 218
561: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 219
562: sched_cls  name handle_policy  tag 7e64b233e29f7c52  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,122,82,83,121,41,80,116,39,84,75,40,37,38
	btf_id 213
563: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 220
566: sched_cls  name __send_drop_notify  tag 7af65e446b227cbc  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 224
569: sched_cls  name tail_handle_ipv4_from_host  tag d09aad39fb4e5fe1  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,125
	btf_id 228
570: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,125
	btf_id 229
571: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,125,75
	btf_id 230
572: sched_cls  name tail_ipv4_ct_egress  tag 7c702917970b9bdb  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,122,82,83,121,84
	btf_id 226
573: sched_cls  name cil_from_container  tag 65a260b36c1f341c  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 122,76
	btf_id 231
574: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,122
	btf_id 232
575: sched_cls  name tail_handle_ipv4  tag 58ca5f1a9d28c9f7  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,122
	btf_id 233
576: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,128,82,83,127,84
	btf_id 235
577: sched_cls  name __send_drop_notify  tag 1a0dde4320a7cdb1  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 237
578: sched_cls  name tail_handle_ipv4_cont  tag 6f76c5c925bf446c  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,121,41,116,82,83,39,76,74,77,122,40,37,38,81
	btf_id 236
579: sched_cls  name tail_ipv4_ct_ingress  tag 1fc4dac8acff3856  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,122,82,83,121,84
	btf_id 239
580: sched_cls  name tail_handle_arp  tag dc8d64608bef39f3  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,122
	btf_id 240
581: sched_cls  name __send_drop_notify  tag 8e32393efbf3d97d  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 241
583: sched_cls  name tail_handle_ipv4  tag 55901b4870a58705  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,128
	btf_id 238
584: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,128
	btf_id 244
585: sched_cls  name cil_from_container  tag 8dea827e716f1de7  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 128,76
	btf_id 245
586: sched_cls  name tail_ipv4_to_endpoint  tag d9e808de941d8815  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,121,41,82,83,80,116,39,122,40,37,38
	btf_id 243
587: sched_cls  name tail_ipv4_to_endpoint  tag 9259d674fc42b23a  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,127,41,82,83,80,91,39,128,40,37,38
	btf_id 246
588: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
591: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
592: sched_cls  name handle_policy  tag 9793b77052f573e2  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,128,82,83,127,41,80,91,39,84,75,40,37,38
	btf_id 247
593: sched_cls  name tail_ipv4_ct_ingress  tag 4c6c4a30a87b8c86  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,128,82,83,127,84
	btf_id 248
594: sched_cls  name tail_handle_arp  tag c728fb1c589f5e53  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,128
	btf_id 249
596: sched_cls  name tail_handle_ipv4_cont  tag a0552daa946f65ca  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,127,41,91,82,83,39,76,74,77,128,40,37,38,81
	btf_id 251
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
601: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
604: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
605: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
608: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
648: sched_cls  name handle_policy  tag 7a9a5ff5b8a0cb17  gpl
	loaded_at 2024-10-25T10:22:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,145,82,83,144,41,80,143,39,84,75,40,37,38
	btf_id 265
649: sched_cls  name tail_ipv4_to_endpoint  tag f3781b57708a7400  gpl
	loaded_at 2024-10-25T10:22:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,144,41,82,83,80,143,39,145,40,37,38
	btf_id 266
650: sched_cls  name tail_handle_ipv4_cont  tag 37c3cd2d00a3f9cf  gpl
	loaded_at 2024-10-25T10:22:27+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,144,41,143,82,83,39,76,74,77,145,40,37,38,81
	btf_id 267
652: sched_cls  name tail_ipv4_ct_ingress  tag 1bc27112608a8025  gpl
	loaded_at 2024-10-25T10:22:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,145,82,83,144,84
	btf_id 269
653: sched_cls  name __send_drop_notify  tag 19abef89e1456762  gpl
	loaded_at 2024-10-25T10:22:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 270
654: sched_cls  name tail_ipv4_ct_egress  tag b4d1a1c546fa1c8b  gpl
	loaded_at 2024-10-25T10:22:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,145,82,83,144,84
	btf_id 271
655: sched_cls  name tail_handle_ipv4  tag f31dfd30b0f230fc  gpl
	loaded_at 2024-10-25T10:22:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,145
	btf_id 272
656: sched_cls  name cil_from_container  tag 923288f095178329  gpl
	loaded_at 2024-10-25T10:22:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 145,76
	btf_id 273
657: sched_cls  name tail_handle_arp  tag 6650bc4f0362db34  gpl
	loaded_at 2024-10-25T10:22:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,145
	btf_id 274
658: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,145
	btf_id 275
659: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
662: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
675: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
678: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
679: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
682: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
683: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
686: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
