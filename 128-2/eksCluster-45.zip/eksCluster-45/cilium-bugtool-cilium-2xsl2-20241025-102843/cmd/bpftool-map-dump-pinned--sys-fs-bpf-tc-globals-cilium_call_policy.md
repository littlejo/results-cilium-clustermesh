key: 40 00 00 00  value: 32 02 00 00
key: 38 04 00 00  value: 50 02 00 00
key: e5 04 00 00  value: 18 02 00 00
key: b4 09 00 00  value: 88 02 00 00
Found 4 elements
