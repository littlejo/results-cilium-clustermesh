KEY             VALUE
AgentLiveness   782574453107
UTimeOffset     3378615910156250
