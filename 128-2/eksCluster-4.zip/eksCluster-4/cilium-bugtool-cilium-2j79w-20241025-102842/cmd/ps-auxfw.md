USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         671  0.0  0.4 1240432 15848 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         685  0.0  0.0      0     0 ?        Z    10:28   0:00  \_ [cat] <defunct>
root         686  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         662  0.0  0.0 1228744 3716 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         643  0.0  0.1 1228744 4032 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  2.3  7.0 1537844 276228 ?      Ssl  10:13   0:22 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.0  0.1 1228848 5520 ?        Sl   10:13   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
