fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxc461f795bfacb proto kernel metric 256 pref medium
fe80::/64 dev lxca9aeb1b533aa proto kernel metric 256 pref medium
fe80::/64 dev lxc728f7bcb022e proto kernel metric 256 pref medium
