[
  {
    "containers": [
      {
        "cgroup-id": 6868,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0b853d1b_5e91_4730_8d8a_37de34e66fe5.slice/cri-containerd-1c677c22810e0ba7d8a928df67a3390082c5b34bee4d6bcb51e1aafea60a3095.scope"
      }
    ],
    "ips": [
      "10.4.0.231"
    ],
    "name": "coredns-cc6ccd49c-n4vz4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6784,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd8d86cb2_8a01_4a83_84d7_369caed746ab.slice/cri-containerd-7b652fa31d9dae75398518b9c588a5dbe6b19321980b1a515a4f5d4d312f6faf.scope"
      }
    ],
    "ips": [
      "10.4.0.51"
    ],
    "name": "coredns-cc6ccd49c-85l2r",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8296,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95325341_7bb3_4fa0_bbc9_99eeec1a6baf.slice/cri-containerd-60cee638941a26a3eb83fa420ce53e2f123107772f1277c2b8dfb9095792a3c9.scope"
      },
      {
        "cgroup-id": 8212,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95325341_7bb3_4fa0_bbc9_99eeec1a6baf.slice/cri-containerd-bcc76faff0d09726245f6eb7d7c0f8f2100df0f544e836ccd42c7d993cb621ee.scope"
      },
      {
        "cgroup-id": 8380,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95325341_7bb3_4fa0_bbc9_99eeec1a6baf.slice/cri-containerd-321edfdc537257e63f8a72a65f6daef938edcdd67496dc025d1200d659141ca1.scope"
      }
    ],
    "ips": [
      "10.4.0.158"
    ],
    "name": "clustermesh-apiserver-b54d45b4b-z5pgz",
    "namespace": "kube-system"
  }
]

