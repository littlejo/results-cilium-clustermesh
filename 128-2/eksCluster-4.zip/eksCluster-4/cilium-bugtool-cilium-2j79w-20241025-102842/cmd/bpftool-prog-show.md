32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:35+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:35+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:35+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:35+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:35+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:12:35+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:12:36+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:12:36+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:36+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:36+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:12:36+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:36+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:12:40+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
58: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
61: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
62: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
65: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
68: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
69: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
72: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
73: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
76: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
444: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 112
445: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 113
446: sched_cls  name tail_handle_ipv4  tag 3063f873e5ae6029  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 114
447: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 115
469: sched_cls  name __send_drop_notify  tag db1da3e457546fc2  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 143
474: sched_cls  name tail_ipv4_ct_egress  tag 6ea313ca4745bd72  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,100,74,75,101,76
	btf_id 145
477: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,100
	btf_id 149
478: sched_cls  name tail_handle_arp  tag 47adaaf0abc77f2a  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,100
	btf_id 152
480: sched_cls  name tail_handle_ipv4_cont  tag 3d33f087784c9c06  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,101,33,97,74,75,31,68,66,69,100,32,29,30,73
	btf_id 153
483: sched_cls  name tail_ipv4_to_endpoint  tag 71727925e2ce988c  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,101,33,74,75,72,97,31,100,32,29,30
	btf_id 156
486: sched_cls  name tail_ipv4_ct_ingress  tag 2d3282ba733c5635  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,100,74,75,101,76
	btf_id 159
487: sched_cls  name tail_handle_ipv4  tag 9c48c0db2a9ff179  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,100
	btf_id 161
489: sched_cls  name cil_from_container  tag a3b7d9d361f5945d  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 100,68
	btf_id 162
490: sched_cls  name __send_drop_notify  tag 1646dddd1fbce38c  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 165
491: sched_cls  name tail_ipv4_to_endpoint  tag e552384fe0bbc84b  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,104,33,74,75,72,102,31,103,32,29,30
	btf_id 166
492: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,103
	btf_id 167
493: sched_cls  name handle_policy  tag f974ff9ee130ed98  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,100,74,75,101,33,72,97,31,76,67,32,29,30
	btf_id 163
494: sched_cls  name handle_policy  tag 8083908601d20598  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,103,74,75,104,33,72,102,31,76,67,32,29,30
	btf_id 168
495: sched_cls  name tail_ipv4_ct_egress  tag 6ea313ca4745bd72  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,103,74,75,104,76
	btf_id 169
496: sched_cls  name tail_handle_arp  tag 7bd6b116fa90f8af  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,103
	btf_id 170
497: sched_cls  name tail_handle_ipv4_cont  tag 6f5c1849e6a2e968  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,104,33,102,74,75,31,68,66,69,103,32,29,30,73
	btf_id 171
498: sched_cls  name cil_from_container  tag 44cd53cdf957b025  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 103,68
	btf_id 173
499: sched_cls  name tail_handle_ipv4  tag 6592341af7356fa9  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,103
	btf_id 174
500: sched_cls  name tail_ipv4_ct_ingress  tag b7a82cb05611b15f  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,103,74,75,104,76
	btf_id 175
502: sched_cls  name tail_handle_ipv4_from_host  tag f056984fcd06edf4  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,105
	btf_id 176
503: sched_cls  name __send_drop_notify  tag 4174e8f2683cc1ed  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 180
505: sched_cls  name tail_handle_ipv4  tag 78db1e1595ece4bd  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,108
	btf_id 182
506: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,105
	btf_id 178
507: sched_cls  name tail_handle_arp  tag 8e3cbc62b527ae40  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,108
	btf_id 183
508: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,105
	btf_id 184
509: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 186
510: sched_cls  name __send_drop_notify  tag 74e402422d3a2c0f  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 187
515: sched_cls  name tail_handle_ipv4_from_host  tag f056984fcd06edf4  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,109
	btf_id 193
516: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,109
	btf_id 194
518: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 196
519: sched_cls  name __send_drop_notify  tag 74e402422d3a2c0f  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 197
520: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,112,67
	btf_id 199
522: sched_cls  name tail_handle_ipv4_from_host  tag f056984fcd06edf4  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,112
	btf_id 201
523: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,112
	btf_id 202
525: sched_cls  name handle_policy  tag 980562e29367cb20  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,108,74,75,107,33,72,90,31,76,67,32,29,30
	btf_id 185
527: sched_cls  name __send_drop_notify  tag 74e402422d3a2c0f  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 206
528: sched_cls  name tail_handle_ipv4_cont  tag 601e80ff38c210ea  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,107,33,90,74,75,31,68,66,69,108,32,29,30,73
	btf_id 205
529: sched_cls  name tail_ipv4_to_endpoint  tag ec5dbffef7bab53b  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,107,33,74,75,72,90,31,108,32,29,30
	btf_id 207
530: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,108
	btf_id 208
531: sched_cls  name cil_from_container  tag 609c102bcd90a0cf  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 108,68
	btf_id 209
532: sched_cls  name tail_ipv4_ct_ingress  tag 49d41e88544ba5c4  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,108,74,75,107,76
	btf_id 210
533: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,108,74,75,107,76
	btf_id 211
534: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
537: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
538: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
541: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
542: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
545: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
546: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
549: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
590: sched_cls  name tail_ipv4_ct_ingress  tag c31d1843ede50fae  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,129,74,75,128,76
	btf_id 228
591: sched_cls  name tail_ipv4_ct_egress  tag de36a25a201ca0c3  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,129,74,75,128,76
	btf_id 229
592: sched_cls  name tail_handle_ipv4  tag 9d4c758cbac45715  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,129
	btf_id 230
593: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,129
	btf_id 231
594: sched_cls  name tail_handle_ipv4_cont  tag b4b7a18c905ecc59  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,128,33,127,74,75,31,68,66,69,129,32,29,30,73
	btf_id 232
595: sched_cls  name __send_drop_notify  tag 8fde8b568e7c8a59  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 233
596: sched_cls  name handle_policy  tag 1a73137f34e35763  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,129,74,75,128,33,72,127,31,76,67,32,29,30
	btf_id 234
597: sched_cls  name tail_handle_arp  tag 035c0164d271e0a4  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,129
	btf_id 235
598: sched_cls  name tail_ipv4_to_endpoint  tag 9633678adb06b975  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,128,33,74,75,72,127,31,129,32,29,30
	btf_id 236
599: sched_cls  name cil_from_container  tag e3b2d0e8a9fbb630  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 129,68
	btf_id 237
600: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
603: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
616: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
619: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
620: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
623: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
624: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
627: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
