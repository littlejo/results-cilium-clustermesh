REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     206939    98689447   1132   bpf_host.c
Interface                 INGRESS     8930      694711     677    bpf_overlay.c
Success                   EGRESS      3955      298942     1694   bpf_host.c
Success                   EGRESS      8461      660187     53     encap.h
Success                   EGRESS      85827     11830917   1308   bpf_lxc.c
Success                   INGRESS     102698    12192133   235    trace.h
Success                   INGRESS     97073     11752388   86     l3.h
Unsupported L3 protocol   EGRESS      37        2742       1492   bpf_lxc.c
