key: 00 04  value: 0a 64 00 0a 23 c1
key: 00 05  value: 0a 64 5d 69 09 4b
key: 00 01  value: 0a 64 00 01 01 bb
key: 00 02  value: 0a 64 12 5e 01 bb
key: 00 03  value: 0a 64 00 0a 00 35
Found 5 elements
