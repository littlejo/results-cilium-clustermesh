alloc: 76.02MB (79710304 bytes)
total-alloc: 1.32GB (1412946600 bytes)
sys: 214.13MB (224535892 bytes)
lookups: 0
mallocs: 47459830
frees: 46904477
heap-alloc: 76.02MB (79710304 bytes)
heap-sys: 169.70MB (177946624 bytes)
heap-idle: 52.62MB (55181312 bytes)
heap-in-use: 117.08MB (122765312 bytes)
heap-released: 13.38MB (14024704 bytes)
heap-objects: 555353
stack-in-use: 34.25MB (35913728 bytes)
stack-sys: 34.25MB (35913728 bytes)
stack-mspan-inuse: 1.93MB (2025920 bytes)
stack-mspan-sys: 2.40MB (2513280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 729.92KB (747433 bytes)
gc-sys: 5.18MB (5427480 bytes)
next-gc: when heap-alloc >= 146.73MB (153853688 bytes)
last-gc: 2024-10-25 10:29:09.257699398 +0000 UTC
gc-pause-total: 10.13157ms
gc-pause: 78407
gc-pause-end: 1729852149257699398
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00033816202646682367
enable-gc: true
debug-gc: false
