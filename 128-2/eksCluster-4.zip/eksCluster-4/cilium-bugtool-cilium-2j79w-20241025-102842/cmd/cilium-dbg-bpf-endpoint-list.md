IP ADDRESS         LOCAL ENDPOINT INFO
10.4.0.158:0       id=383   sec_id=337601 flags=0x0000 ifindex=15  mac=AA:B6:88:DB:A0:75 nodemac=EA:76:07:AB:08:53   
10.4.0.207:0       id=3849  sec_id=4     flags=0x0000 ifindex=7   mac=DA:75:E3:53:22:AA nodemac=4A:24:76:B8:A3:AE    
10.4.0.4:0         (localhost)                                                                                       
10.4.0.51:0        id=3313  sec_id=379782 flags=0x0000 ifindex=9   mac=FE:64:F9:21:1F:CA nodemac=EA:7E:6A:3E:55:FB   
172.31.172.128:0   (localhost)                                                                                       
10.4.0.231:0       id=3728  sec_id=379782 flags=0x0000 ifindex=11  mac=6A:95:67:94:22:74 nodemac=62:0E:92:3C:F2:67   
