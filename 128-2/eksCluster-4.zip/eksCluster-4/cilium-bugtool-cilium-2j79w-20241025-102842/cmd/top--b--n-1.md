top - 10:28:44 up 16 min,  0 users,  load average: 0.35, 0.16, 0.11
Tasks:   9 total,   2 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 50.0 us, 33.3 sy,  0.0 ni, 10.0 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   3836.2 total,   1193.0 free,    887.6 used,   1755.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2780.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    708 root      20   0 1244340  21872  13636 S  46.7   0.6   0:00.07 hubble
      1 root      20   0 1537844 276228  77696 S  13.3   7.0   0:22.20 cilium-+
    671 root      20   0 1240432  15848  10832 S   6.7   0.4   0:00.03 cilium-+
    394 root      20   0 1228848   5756   2868 S   0.0   0.1   0:00.27 cilium-+
    643 root      20   0 1228744   4032   3392 S   0.0   0.1   0:00.00 gops
    662 root      20   0 1228744   3716   3040 S   0.0   0.1   0:00.00 gops
    697 root      20   0    2208    792    716 S   0.0   0.0   0:00.00 timeout
    704 root      20   0    6576   2420   2096 R   0.0   0.1   0:00.00 top
    728 root      20   0    2424    488    428 R   0.0   0.0   0:00.00 ipset
