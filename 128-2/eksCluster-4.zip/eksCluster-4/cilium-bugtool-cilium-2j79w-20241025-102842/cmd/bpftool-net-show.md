xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 520
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 518
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 509
cilium_host(4) clsact/egress cil_from_host-cilium_host id 508
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 447
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 444
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 531
lxc461f795bfacb(9) clsact/ingress cil_from_container-lxc461f795bfacb id 489
lxca9aeb1b533aa(11) clsact/ingress cil_from_container-lxca9aeb1b533aa id 498
lxc728f7bcb022e(15) clsact/ingress cil_from_container-lxc728f7bcb022e id 599

flow_dissector:

netfilter:

