Total: 548
TCP:   1075 (estab 300, closed 756, orphaned 0, timewait 297)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  319       309       10       
INET	  329       315       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:21735 sk:1001 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15450 sk:1002 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:34615      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=40)) ino:21226 sk:1003 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.172.128%ens5:68         0.0.0.0:*    uid:192 ino:16451 sk:1004 cgroup:unreachable:c4e <->                            
UNCONN 0      0                                 [::]:8472          [::]:*    ino:21734 sk:1005 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15451 sk:1006 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::4f5:e1ff:fef8:450f]%ens5:546           [::]:*    uid:192 ino:16447 sk:1007 cgroup:unreachable:c4e v6only:1 <->                   
