# Cilium debug information

#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4         STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                   
383        Disabled           Disabled          337601     k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.4.0.158   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh5                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                              
                                                           k8s:k8s-app=clustermesh-apiserver                                                                        
3313       Disabled           Disabled          379782     k8s:eks.amazonaws.com/component=coredns                                             10.4.0.51    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh5                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                          
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                              
                                                           k8s:k8s-app=kube-dns                                                                                     
3645       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                  ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                    
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                              
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                               
                                                           reserved:host                                                                                            
3728       Disabled           Disabled          379782     k8s:eks.amazonaws.com/component=coredns                                             10.4.0.231   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh5                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                          
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                              
                                                           k8s:k8s-app=kube-dns                                                                                     
3849       Disabled           Disabled          4          reserved:health                                                                     10.4.0.207   ready   
```

#### BPF Policy Get 383

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3829254   34918     0        
Allow    Ingress     1          ANY          NONE         disabled    2748690   27417     0        
Allow    Egress      0          ANY          NONE         disabled    3451576   32360     0        

```


#### BPF CT List 383

```
Invalid argument: unknown type 383
```


#### Endpoint Get 383

```
[
  {
    "id": 383,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-383-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "99546051-6425-4350-bf03-66a0451f1f82"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-383",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:16.127Z",
            "success-count": 2
          },
          "uuid": "85cf5d54-fcda-49ba-8c6d-fb1ec744487e"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-b54d45b4b-z5pgz",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:16.126Z",
            "success-count": 1
          },
          "uuid": "05673afa-ef1f-4efa-b904-43d65bd8ad6d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-383",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:16.170Z",
            "success-count": 1
          },
          "uuid": "fc7c57cc-42af-4b02-9f42-7dc447359924"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (383)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:06.187Z",
            "success-count": 37
          },
          "uuid": "44fadeff-6c44-4817-a4b4-d24b706e72c1"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "d7a71f7d1a42f19e4a3bac1345e3931659e117aa55ee9c7115308bf87912569a:eth0",
        "container-id": "d7a71f7d1a42f19e4a3bac1345e3931659e117aa55ee9c7115308bf87912569a",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-b54d45b4b-z5pgz",
        "pod-name": "kube-system/clustermesh-apiserver-b54d45b4b-z5pgz"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 337601,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh5",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=b54d45b4b"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh5",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:43Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.4.0.158",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ea:76:07:ab:08:53",
        "interface-index": 15,
        "interface-name": "lxc728f7bcb022e",
        "mac": "aa:b6:88:db:a0:75"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 337601,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 337601,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 383

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 383

```
Timestamp              Status   State                   Message
2024-10-25T10:23:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:43Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:23:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:16Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:23:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:23:16Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:23:16Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 337601

```
ID       LABELS
337601   k8s:app.kubernetes.io/name=clustermesh-apiserver
         k8s:app.kubernetes.io/part-of=cilium
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh5
         k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 3313

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    89608   1034      0        
Allow    Egress      0          ANY          NONE         disabled    14546   152       0        

```


#### BPF CT List 3313

```
Invalid argument: unknown type 3313
```


#### Endpoint Get 3313

```
[
  {
    "id": 3313,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3313-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "1ed7b77c-f9cb-42b9-8d2f-038c3c9b7623"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3313",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:20.932Z",
            "success-count": 4
          },
          "uuid": "986ca494-d4cf-47e1-9f9c-fdabeca9676d"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-85l2r",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:13:20.930Z",
            "success-count": 1
          },
          "uuid": "74ed4937-86f1-4111-b8d1-110b955cc9fc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3313",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:24.246Z",
            "success-count": 2
          },
          "uuid": "fb0c9fcd-a20c-42b3-a760-75b280cfbf7a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3313)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:11.016Z",
            "success-count": 97
          },
          "uuid": "b6e1228f-36fd-400b-a383-6f9aac351d9c"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "096d5fa6b7b4bb9f06cb49451de465dbe475dbba9f3939203784455271ba8138:eth0",
        "container-id": "096d5fa6b7b4bb9f06cb49451de465dbe475dbba9f3939203784455271ba8138",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-85l2r",
        "pod-name": "kube-system/coredns-cc6ccd49c-85l2r"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 379782,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh5",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh5",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:43Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.4.0.51",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ea:7e:6a:3e:55:fb",
        "interface-index": 9,
        "interface-name": "lxc461f795bfacb",
        "mac": "fe:64:f9:21:1f:ca"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 379782,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 379782,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3313

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3313

```
Timestamp              Status    State                   Message
2024-10-25T10:23:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:43Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:23:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:42Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:42Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:42Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:42Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:41Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:41Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:41Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:41Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:39Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:39Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:39Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:38Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:38Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:38Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:38Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:37Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:24Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:24Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:22Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:21Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:13:21Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:13:20Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:20Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:13:20Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:20Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 379782

```
ID       LABELS
379782   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh5
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 3645

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 3645

```
Invalid argument: unknown type 3645
```


#### Endpoint Get 3645

```
[
  {
    "id": 3645,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3645-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7faa25a6-3cd0-4a37-8dc0-028550c71cff"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3645",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:19.581Z",
            "success-count": 4
          },
          "uuid": "0c0f401c-e367-4792-b392-7988603d17f4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3645",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:20.701Z",
            "success-count": 2
          },
          "uuid": "e5438899-4bf8-4cfc-ac3a-445ad2722439"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:43Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "02:c0:d3:41:83:aa",
        "interface-name": "cilium_host",
        "mac": "02:c0:d3:41:83:aa"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3645

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3645

```
Timestamp              Status   State                   Message
2024-10-25T10:23:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:43Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:37Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:13:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:24Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:13:22Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:13:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:13:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:19Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:19Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:19Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 3728

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    89793   1034      0        
Allow    Egress      0          ANY          NONE         disabled    13797   145       0        

```


#### BPF CT List 3728

```
Invalid argument: unknown type 3728
```


#### Endpoint Get 3728

```
[
  {
    "id": 3728,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3728-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f8243030-6c6b-4df8-9fa0-eb5cd8990ada"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3728",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:21.001Z",
            "success-count": 4
          },
          "uuid": "3b55b94a-baf3-4e2e-bb1d-8747a295eec1"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-n4vz4",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:13:20.998Z",
            "success-count": 1
          },
          "uuid": "33c1fc65-63ad-49c3-a370-edcb093e631b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3728",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:24.267Z",
            "success-count": 2
          },
          "uuid": "8f541b90-76b0-46ee-be7a-841c59e0b357"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3728)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:11.082Z",
            "success-count": 97
          },
          "uuid": "b7bd97f9-9e07-4643-bd8a-44d4a803bded"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "dff4210bee75a321d1f606ad778ba340f43020286cca441f549de74422675ec5:eth0",
        "container-id": "dff4210bee75a321d1f606ad778ba340f43020286cca441f549de74422675ec5",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-n4vz4",
        "pod-name": "kube-system/coredns-cc6ccd49c-n4vz4"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 379782,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh5",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh5",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:43Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.4.0.231",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "62:0e:92:3c:f2:67",
        "interface-index": 11,
        "interface-name": "lxca9aeb1b533aa",
        "mac": "6a:95:67:94:22:74"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 379782,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 379782,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3728

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3728

```
Timestamp              Status   State                   Message
2024-10-25T10:23:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:43Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:37Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:24Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:13:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:13:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:20Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:20Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 379782

```
ID       LABELS
379782   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh5
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 3849

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    439877   5627      0        
Allow    Ingress     1          ANY          NONE         disabled    13056    153       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 3849

```
Invalid argument: unknown type 3849
```


#### Endpoint Get 3849

```
[
  {
    "id": 3849,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3849-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f13202a7-56d2-4c2e-af29-f223b424fa10"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3849",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:20.653Z",
            "success-count": 4
          },
          "uuid": "eb1aac96-e075-4bc2-8207-7e29d3448bab"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3849",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:24.217Z",
            "success-count": 2
          },
          "uuid": "622f271d-7f56-4939-8acb-fa1ef9e5a618"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:43Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.4.0.207",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "4a:24:76:b8:a3:ae",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "da:75:e3:53:22:aa"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3849

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3849

```
Timestamp              Status   State                   Message
2024-10-25T10:23:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:43Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:24Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:13:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:13:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:20Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:20Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:19Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Service list

```
ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.167.244:443 (active)    
                                         2 => 172.31.195.197:443 (active)    
2    10.100.18.94:443     ClusterIP      1 => 172.31.172.128:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.4.0.51:53 (active)          
                                         2 => 10.4.0.231:53 (active)         
4    10.100.0.10:9153     ClusterIP      1 => 10.4.0.51:9153 (active)        
                                         2 => 10.4.0.231:9153 (active)       
5    10.100.93.105:2379   ClusterIP      1 => 10.4.0.158:2379 (active)       
```

#### Cilium encryption



#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.4.0.0/24, 
Allocated addresses:
  10.4.0.158 (kube-system/clustermesh-apiserver-b54d45b4b-z5pgz)
  10.4.0.207 (health)
  10.4.0.231 (kube-system/coredns-cc6ccd49c-n4vz4)
  10.4.0.4 (router)
  10.4.0.51 (kube-system/coredns-cc6ccd49c-85l2r)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 531c889888ab59e2
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                               Last success   Last error   Count   Message
  cilium-health-ep                                                   54s ago        never        0       no error   
  ct-map-pressure                                                    26s ago        never        0       no error   
  daemon-validate-config                                             41s ago        never        0       no error   
  dns-garbage-collector-job                                          59s ago        never        0       no error   
  endpoint-3313-regeneration-recovery                                never          never        0       no error   
  endpoint-3645-regeneration-recovery                                never          never        0       no error   
  endpoint-3728-regeneration-recovery                                never          never        0       no error   
  endpoint-383-regeneration-recovery                                 never          never        0       no error   
  endpoint-3849-regeneration-recovery                                never          never        0       no error   
  endpoint-gc                                                        59s ago        never        0       no error   
  ep-bpf-prog-watchdog                                               26s ago        never        0       no error   
  ipcache-inject-labels                                              57s ago        never        0       no error   
  k8s-heartbeat                                                      29s ago        never        0       no error   
  link-cache                                                         11s ago        never        0       no error   
  local-identity-checkpoint                                          15m46s ago     never        0       no error   
  node-neighbor-link-updater                                         6s ago         never        0       no error   
  remote-etcd-cmesh1                                                 5m34s ago      never        0       no error   
  remote-etcd-cmesh10                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh100                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh101                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh102                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh103                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh104                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh105                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh106                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh107                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh108                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh109                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh11                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh110                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh111                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh112                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh113                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh114                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh115                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh116                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh117                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh118                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh119                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh12                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh120                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh121                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh122                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh123                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh124                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh125                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh126                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh127                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh128                                               5m34s ago      never        0       no error   
  remote-etcd-cmesh13                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh14                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh15                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh16                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh17                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh18                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh19                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh2                                                 5m34s ago      never        0       no error   
  remote-etcd-cmesh20                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh21                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh22                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh23                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh24                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh25                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh26                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh27                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh28                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh29                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh3                                                 5m34s ago      never        0       no error   
  remote-etcd-cmesh30                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh31                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh32                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh33                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh34                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh35                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh36                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh37                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh38                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh39                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh4                                                 5m34s ago      never        0       no error   
  remote-etcd-cmesh40                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh41                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh42                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh43                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh44                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh45                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh46                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh47                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh48                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh49                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh50                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh51                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh52                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh53                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh54                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh55                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh56                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh57                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh58                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh59                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh6                                                 5m34s ago      never        0       no error   
  remote-etcd-cmesh60                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh61                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh62                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh63                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh64                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh65                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh66                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh67                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh68                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh69                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh7                                                 5m34s ago      never        0       no error   
  remote-etcd-cmesh70                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh71                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh72                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh73                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh74                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh75                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh76                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh77                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh78                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh79                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh8                                                 5m34s ago      never        0       no error   
  remote-etcd-cmesh80                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh81                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh82                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh83                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh84                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh85                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh86                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh87                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh88                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh89                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh9                                                 5m34s ago      never        0       no error   
  remote-etcd-cmesh90                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh91                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh92                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh93                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh94                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh95                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh96                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh97                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh98                                                5m34s ago      never        0       no error   
  remote-etcd-cmesh99                                                5m34s ago      never        0       no error   
  resolve-identity-3313                                              55s ago        never        0       no error   
  resolve-identity-3645                                              56s ago        never        0       no error   
  resolve-identity-3728                                              55s ago        never        0       no error   
  resolve-identity-383                                               1m0s ago       never        0       no error   
  resolve-identity-3849                                              55s ago        never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-b54d45b4b-z5pgz   6m0s ago       never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-85l2r                 15m55s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-n4vz4                 15m55s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                     15m56s ago     never        0       no error   
  sync-policymap-3313                                                52s ago        never        0       no error   
  sync-policymap-3645                                                55s ago        never        0       no error   
  sync-policymap-3728                                                52s ago        never        0       no error   
  sync-policymap-383                                                 6m0s ago       never        0       no error   
  sync-policymap-3849                                                52s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (3313)                                  5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3728)                                  5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (383)                                   10s ago        never        0       no error   
  sync-utime                                                         57s ago        never        0       no error   
  write-cni-file                                                     15m59s ago     never        0       no error   
Proxy Status:            OK, ip 10.4.0.4, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 327680, max 393215
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 61.97   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
direct-routing-skip-unreachable:false
enable-bpf-tproxy:false
kvstore:
restore:true
hubble-drop-events-interval:2m0s
endpoint-bpf-prog-watchdog-interval:30s
enable-bgp-control-plane:false
kvstore-max-consecutive-quorum-errors:2
bpf-ct-timeout-service-tcp-grace:1m0s
vtep-endpoint:
bgp-announce-lb-ip:false
monitor-queue-size:0
enable-bbr:false
proxy-gid:1337
kube-proxy-replacement-healthz-bind-address:
mesh-auth-spire-admin-socket:
state-dir:/var/run/cilium
k8s-client-burst:20
envoy-config-retry-interval:15s
ip-masq-agent-config-path:/etc/config/ip-masq-agent
hubble-export-fieldmask:
enable-masquerade-to-route-source:false
l2-announcements-renew-deadline:5s
routing-mode:tunnel
k8s-client-qps:10
policy-cidr-match-mode:
remove-cilium-node-taints:true
use-full-tls-context:false
enable-gateway-api:false
hubble-prefer-ipv6:false
bpf-filter-priority:1
enable-local-redirect-policy:false
gateway-api-secrets-namespace:
ipv6-cluster-alloc-cidr:f00d::/64
proxy-xff-num-trusted-hops-ingress:0
debug:false
cmdref:
max-connected-clusters:255
enable-wireguard:false
k8s-sync-timeout:3m0s
static-cnp-path:
enable-high-scale-ipcache:false
vlan-bpf-bypass:
ipv4-service-range:auto
k8s-client-connection-timeout:30s
vtep-mac:
bpf-lb-rss-ipv6-src-cidr:
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
proxy-max-requests-per-connection:0
encryption-strict-mode-allow-remote-node-identities:false
mesh-auth-queue-size:1024
enable-ipsec-xfrm-state-caching:true
enable-unreachable-routes:false
enable-ipv4:true
ipam-multi-pool-pre-allocation:
hubble-drop-events-reasons:auth_required,policy_denied
dnsproxy-concurrency-limit:0
clustermesh-enable-endpoint-sync:false
kvstore-lease-ttl:15m0s
envoy-config-timeout:2m0s
mtu:0
hubble-event-queue-size:0
enable-ipv4-masquerade:true
clustermesh-sync-timeout:1m0s
ipam-default-ip-pool:default
enable-health-check-loadbalancer-ip:false
enable-ipv6-big-tcp:false
hubble-export-denylist:
mesh-auth-spiffe-trust-domain:spiffe.cilium
disable-iptables-feeder-rules:
enable-srv6:false
node-port-mode:snat
ipv4-pod-subnets:
enable-health-checking:true
node-labels:
identity-gc-interval:15m0s
bpf-fragments-map-max:8192
annotate-k8s-node:false
hubble-export-allowlist:
log-opt:
http-idle-timeout:0
tofqdns-proxy-port:0
enable-host-port:false
bpf-lb-algorithm:random
wireguard-persistent-keepalive:0s
hubble-skip-unknown-cgroup-ids:true
enable-active-connection-tracking:false
hubble-redact-kafka-apikey:false
endpoint-gc-interval:5m0s
ipv6-range:auto
hubble-socket-path:/var/run/cilium/hubble.sock
enable-xt-socket-fallback:true
hubble-redact-http-headers-allow:
derive-masq-ip-addr-from-device:
enable-ipv4-big-tcp:false
enable-ipsec-key-watcher:true
cilium-endpoint-gc-interval:5m0s
tofqdns-idle-connection-grace-period:0s
kvstore-periodic-sync:5m0s
pprof-address:localhost
allocator-list-timeout:3m0s
enable-wireguard-userspace-fallback:false
hubble-listen-address::4244
envoy-log:
egress-gateway-reconciliation-trigger-interval:1s
ipsec-key-rotation-duration:5m0s
identity-allocation-mode:crd
egress-gateway-policy-map-max:16384
enable-host-firewall:false
devices:
enable-ipv6:false
enable-well-known-identities:false
use-cilium-internal-ip-for-ipsec:false
enable-recorder:false
procfs:/host/proc
bpf-ct-timeout-service-any:1m0s
cni-log-file:/var/run/cilium/cilium-cni.log
tofqdns-min-ttl:0
enable-bpf-clock-probe:false
enable-l2-announcements:false
bpf-events-trace-enabled:true
cluster-health-port:4240
enable-pmtu-discovery:false
custom-cni-conf:false
hubble-redact-http-headers-deny:
enable-tcx:true
ipv6-native-routing-cidr:
disable-endpoint-crd:false
mke-cgroup-mount:
max-controller-interval:0
mesh-auth-rotated-identities-queue-size:1024
envoy-secrets-namespace:
dns-policy-unload-on-shutdown:false
proxy-max-connection-duration-seconds:0
enable-cilium-health-api-server-access:
proxy-connect-timeout:2
mesh-auth-gc-interval:5m0s
pprof-port:6060
l2-announcements-lease-duration:15s
bpf-lb-rev-nat-map-max:0
k8s-api-server:
nodes-gc-interval:5m0s
mesh-auth-enabled:true
k8s-heartbeat-timeout:30s
cluster-id:5
tunnel-protocol:vxlan
ipv6-mcast-device:
enable-node-port:false
bpf-lb-service-backend-map-max:0
ipam-cilium-node-update-rate:15s
trace-payloadlen:128
debug-verbose:
http-retry-timeout:0
socket-path:/var/run/cilium/cilium.sock
enable-ipsec:false
gops-port:9890
cflags:
lib-dir:/var/lib/cilium
bpf-sock-rev-map-max:262144
enable-ipv6-masquerade:true
tofqdns-max-deferred-connection-deletes:10000
enable-cilium-api-server-access:
bpf-ct-timeout-regular-tcp:2h13m20s
node-port-bind-protection:true
enable-local-node-route:true
bypass-ip-availability-upon-restore:false
enable-stale-cilium-endpoint-cleanup:true
identity-restore-grace-period:30s
preallocate-bpf-maps:false
k8s-client-connection-keep-alive:30s
cluster-pool-ipv4-cidr:10.4.0.0/16
prometheus-serve-addr:
bpf-root:/sys/fs/bpf
enable-external-ips:false
log-driver:
hubble-export-file-max-size-mb:10
bpf-map-dynamic-size-ratio:0.0025
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
tofqdns-dns-reject-response-code:refused
bpf-ct-timeout-regular-any:1m0s
metrics:
enable-icmp-rules:true
policy-trigger-interval:1s
hubble-metrics:
ipv4-node:auto
bpf-auth-map-max:524288
set-cilium-node-taints:true
identity-change-grace-period:5s
trace-sock:true
operator-api-serve-addr:127.0.0.1:9234
ipam:cluster-pool
allow-icmp-frag-needed:true
enable-k8s:true
local-max-addr-scope:252
http-normalize-path:true
enable-session-affinity:false
conntrack-gc-interval:0s
nat-map-stats-interval:30s
bpf-ct-timeout-regular-tcp-fin:10s
enable-k8s-networkpolicy:true
egress-masquerade-interfaces:ens+
bpf-lb-sock-terminate-pod-connections:false
enable-identity-mark:true
hubble-redact-enabled:false
monitor-aggregation-interval:5s
allow-localhost:auto
node-port-range:
tofqdns-endpoint-max-ip-per-hostname:50
dns-max-ips-per-restored-rule:1000
bpf-node-map-max:16384
enable-hubble:true
bpf-lb-sock:false
agent-labels:
force-device-detection:false
enable-ingress-controller:false
vtep-cidr:
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
dnsproxy-insecure-skip-transparent-mode-check:false
keep-config:false
proxy-portrange-min:10000
bgp-config-path:/var/lib/cilium/bgp/config.yaml
hubble-recorder-storage-path:/var/run/cilium/pcaps
unmanaged-pod-watcher-interval:15
tofqdns-proxy-response-max-delay:100ms
policy-audit-mode:false
enable-ipip-termination:false
operator-prometheus-serve-addr::9963
bpf-policy-map-full-reconciliation-interval:15m0s
http-max-grpc-timeout:0
conntrack-gc-max-interval:0s
enable-nat46x64-gateway:false
enable-custom-calls:false
node-port-algorithm:random
l2-pod-announcements-interface:
enable-ipv6-ndp:false
hubble-redact-http-urlquery:false
install-iptables-rules:true
config:
config-sources:config-map:kube-system/cilium-config
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
dnsproxy-enable-transparent-mode:true
datapath-mode:veth
enable-k8s-endpoint-slice:true
bpf-lb-mode:snat
k8s-require-ipv4-pod-cidr:false
enable-tracing:false
clustermesh-ip-identities-sync-timeout:1m0s
external-envoy-proxy:true
auto-direct-node-routes:false
dnsproxy-socket-linger-timeout:10
ipv6-node:auto
multicast-enabled:false
k8s-service-cache-size:128
enable-svc-source-range-check:true
tunnel-port:0
bpf-lb-maglev-map-max:0
enable-l2-neigh-discovery:true
fixed-identity-mapping:
install-no-conntrack-iptables-rules:false
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
ipsec-key-file:
proxy-admin-port:0
proxy-portrange-max:20000
bpf-ct-timeout-regular-tcp-syn:1m0s
exclude-local-address:
enable-ipv4-fragment-tracking:true
dnsproxy-lock-timeout:500ms
arping-refresh-period:30s
hubble-export-file-max-backups:5
hubble-event-buffer-capacity:4095
certificates-directory:/var/run/cilium/certs
enable-runtime-device-detection:true
bpf-neigh-global-max:524288
labels:
kvstore-connectivity-timeout:2m0s
hubble-export-file-compress:false
proxy-prometheus-port:0
enable-ip-masq-agent:false
max-internal-timer-delay:0s
hubble-metrics-server:
disable-external-ip-mitigation:false
bpf-lb-rss-ipv4-src-cidr:
bpf-lb-map-max:65536
bpf-events-drop-enabled:true
exclude-node-label-patterns:
ingress-secrets-namespace:
clustermesh-config:/var/lib/cilium/clustermesh/
envoy-base-id:0
cni-exclusive:true
bpf-ct-global-tcp-max:524288
enable-encryption-strict-mode:false
bpf-lb-affinity-map-max:0
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
prepend-iptables-chains:true
bpf-policy-map-max:16384
k8s-require-ipv6-pod-cidr:false
cgroup-root:/run/cilium/cgroupv2
bpf-events-policy-verdict-enabled:true
dnsproxy-concurrency-processing-grace-period:0s
mesh-auth-mutual-connect-timeout:5s
join-cluster:false
local-router-ipv4:
crd-wait-timeout:5m0s
node-port-acceleration:disabled
enable-cilium-endpoint-slice:false
bgp-announce-pod-cidr:false
enable-k8s-terminating-endpoint:true
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
enable-auto-protect-node-port-range:true
enable-bandwidth-manager:false
policy-queue-size:100
egress-multi-home-ip-rule-compat:false
ipv4-native-routing-cidr:
tofqdns-pre-cache:
http-request-timeout:3600
enable-k8s-api-discovery:false
hubble-redact-http-userinfo:true
enable-ipsec-encrypted-overlay:false
enable-host-legacy-routing:false
dnsproxy-lock-count:131
route-metric:0
bpf-lb-service-map-max:0
ipv4-range:auto
bpf-ct-timeout-service-tcp:2h13m20s
bpf-lb-dsr-l4-xlate:frontend
set-cilium-is-up-condition:true
hubble-drop-events:false
ipv6-service-range:auto
controller-group-metrics:
enable-xdp-prefilter:false
encryption-strict-mode-cidr:
bpf-lb-dsr-dispatch:opt
l2-announcements-retry-period:2s
proxy-idle-timeout-seconds:60
srv6-encap-mode:reduced
bpf-nat-global-max:524288
config-dir:/tmp/cilium/config-map
kvstore-opt:
bpf-map-event-buffers:
cluster-pool-ipv4-mask-size:24
enable-endpoint-routes:false
mesh-auth-mutual-listener-port:0
enable-bpf-masquerade:false
encrypt-interface:
bpf-lb-maglev-table-size:16381
ipv4-service-loopback-address:169.254.42.1
enable-policy:default
log-system-load:false
hubble-monitor-events:
tofqdns-enable-dns-compression:true
enable-endpoint-health-checking:true
monitor-aggregation:medium
enable-health-check-nodeport:true
local-router-ipv6:
vtep-mask:
cluster-name:cmesh5
label-prefix-file:
enable-sctp:false
enable-hubble-recorder-api:true
iptables-random-fully:false
kube-proxy-replacement:false
enable-l7-proxy:true
policy-accounting:true
enable-l2-pod-announcements:false
agent-liveness-update-interval:1s
container-ip-local-reserved-ports:auto
enable-monitor:true
direct-routing-device:
enable-node-selector-labels:false
hubble-disable-tls:false
auto-create-cilium-node-resource:true
bpf-lb-acceleration:disabled
nodeport-addresses:
fqdn-regex-compile-lru-size:1024
cni-external-routing:false
hubble-recorder-sink-queue-size:1024
disable-envoy-version-check:false
monitor-aggregation-flags:all
enable-envoy-config:false
mesh-auth-signal-backoff-duration:1s
service-no-backend-response:reject
nat-map-stats-entries:32
hubble-export-file-path:
k8s-kubeconfig-path:
version:false
cni-chaining-target:
http-retry-count:3
enable-route-mtu-for-cni-chaining:false
ipv6-pod-subnets:
hubble-flowlogs-config-path:
bpf-lb-external-clusterip:false
cni-chaining-mode:none
iptables-lock-timeout:5s
enable-service-topology:false
enable-ipv4-egress-gateway:false
synchronize-k8s-nodes:true
bpf-lb-sock-hostns-only:false
read-cni-conf:
pprof:false
bpf-lb-source-range-map-max:0
proxy-xff-num-trusted-hops-egress:0
k8s-service-proxy-name:
enable-mke:false
envoy-keep-cap-netbindservice:false
bpf-ct-global-any-max:262144
endpoint-queue-size:25
enable-metrics:true
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
k8s-namespace:kube-system
clustermesh-enable-mcs-api:false
api-rate-limit:
enable-vtep:false
identity-heartbeat-timeout:30m0s
agent-health-port:9879
encrypt-node:false
```


#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 37777288                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 37777288                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 37777288                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400cc00000 rw-p 00000000 00:00 0 
400cc00000-4010000000 ---p 00000000 00:00 0 
ffff57c13000-ffff57dd8000 rw-p 00000000 00:00 0 
ffff57ddf000-ffff57ec1000 rw-p 00000000 00:00 0 
ffff57ec1000-ffff57f02000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff57f02000-ffff57f43000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff57f43000-ffff57f83000 rw-p 00000000 00:00 0 
ffff57f83000-ffff57f85000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff57f85000-ffff57f87000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff57f87000-ffff5854e000 rw-p 00000000 00:00 0 
ffff5854e000-ffff5864e000 rw-p 00000000 00:00 0 
ffff5864e000-ffff5865f000 rw-p 00000000 00:00 0 
ffff5865f000-ffff5a65f000 rw-p 00000000 00:00 0 
ffff5a65f000-ffff5a6df000 ---p 00000000 00:00 0 
ffff5a6df000-ffff5a6e0000 rw-p 00000000 00:00 0 
ffff5a6e0000-ffff7a6df000 ---p 00000000 00:00 0 
ffff7a6df000-ffff7a6e0000 rw-p 00000000 00:00 0 
ffff7a6e0000-ffff9a66f000 ---p 00000000 00:00 0 
ffff9a66f000-ffff9a670000 rw-p 00000000 00:00 0 
ffff9a670000-ffff9e661000 ---p 00000000 00:00 0 
ffff9e661000-ffff9e662000 rw-p 00000000 00:00 0 
ffff9e662000-ffff9ee5f000 ---p 00000000 00:00 0 
ffff9ee5f000-ffff9ee60000 rw-p 00000000 00:00 0 
ffff9ee60000-ffff9ef5f000 ---p 00000000 00:00 0 
ffff9ef5f000-ffff9efbf000 rw-p 00000000 00:00 0 
ffff9efbf000-ffff9efc1000 r--p 00000000 00:00 0                          [vvar]
ffff9efc1000-ffff9efc2000 r-xp 00000000 00:00 0                          [vdso]
ffffea5d2000-ffffea5f3000 rw-p 00000000 00:00 0                          [stack]

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.4.0.207": (string) (len=6) "health",
  (string) (len=9) "10.4.0.51": (string) (len=35) "kube-system/coredns-cc6ccd49c-85l2r",
  (string) (len=10) "10.4.0.231": (string) (len=35) "kube-system/coredns-cc6ccd49c-n4vz4",
  (string) (len=10) "10.4.0.158": (string) (len=49) "kube-system/clustermesh-apiserver-b54d45b4b-z5pgz",
  (string) (len=8) "10.4.0.4": (string) (len=6) "router"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.172.128": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40019d4160)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001cb5ce0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001cb5ce0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x40006cf600)(frontends:[10.100.18.94]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x40006cf6b0)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4003530d10)(frontends:[]/ports=[etcd-metrics apiserv-metrics kvmesh-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4001d7e790)(frontends:[10.100.93.105]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x40006cf550)(frontends:[10.100.0.1]/ports=[https]/selector=map[])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4000ea1de8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40023285b0)(172.31.167.244:443/TCP,172.31.195.197:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4000ea1df0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-cchhj": (*k8s.Endpoints)(0x4000e991e0)(172.31.172.128:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4000ea1df8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-sbk62": (*k8s.Endpoints)(0x4001901ba0)(10.4.0.231:53/TCP[eu-west-3a],10.4.0.231:53/UDP[eu-west-3a],10.4.0.231:9153/TCP[eu-west-3a],10.4.0.51:53/TCP[eu-west-3a],10.4.0.51:53/UDP[eu-west-3a],10.4.0.51:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x400155c790)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-l78rp": (*k8s.Endpoints)(0x400229d6c0)(10.4.0.158:2379/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x40003688c0)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40023c0910)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4009f1bae8
  },
  gcTrigger: (chan struct {}) (cap=1) 0x40023b9f80,
  gcExited: (chan struct {}) 0x40023dc000,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x40011e6c00)({
     ObserverVec: (*prometheus.HistogramVec)(0x400108aa38)({
      MetricVec: (*prometheus.MetricVec)(0x400255c3c0)({
       metricMap: (*prometheus.metricMap)(0x400255c3f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001172c00)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x40011e6c80)({
     ObserverVec: (*prometheus.HistogramVec)(0x400108aa40)({
      MetricVec: (*prometheus.MetricVec)(0x400255c450)({
       metricMap: (*prometheus.metricMap)(0x400255c480)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001172c60)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x40011e6d00)({
     GaugeVec: (*prometheus.GaugeVec)(0x400108aa48)({
      MetricVec: (*prometheus.MetricVec)(0x400255c4e0)({
       metricMap: (*prometheus.metricMap)(0x400255c510)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001172cc0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x40011e6d80)({
     GaugeVec: (*prometheus.GaugeVec)(0x400108aa50)({
      MetricVec: (*prometheus.MetricVec)(0x400255c570)({
       metricMap: (*prometheus.metricMap)(0x400255c5a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001172d20)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x40011e6e00)({
     GaugeVec: (*prometheus.GaugeVec)(0x400108aa58)({
      MetricVec: (*prometheus.MetricVec)(0x400255c600)({
       metricMap: (*prometheus.metricMap)(0x400255c630)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001172d80)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x40011e6e80)({
     GaugeVec: (*prometheus.GaugeVec)(0x400108aa60)({
      MetricVec: (*prometheus.MetricVec)(0x400255c690)({
       metricMap: (*prometheus.metricMap)(0x400255c6c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001172de0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x40011e6f00)({
     GaugeVec: (*prometheus.GaugeVec)(0x400108aa68)({
      MetricVec: (*prometheus.MetricVec)(0x400255c720)({
       metricMap: (*prometheus.metricMap)(0x400255c750)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001172e40)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x40011e6f80)({
     GaugeVec: (*prometheus.GaugeVec)(0x400108aa70)({
      MetricVec: (*prometheus.MetricVec)(0x400255c7b0)({
       metricMap: (*prometheus.metricMap)(0x400255c7e0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001172ea0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x40011e7000)({
     ObserverVec: (*prometheus.HistogramVec)(0x400108aa78)({
      MetricVec: (*prometheus.MetricVec)(0x400255c840)({
       metricMap: (*prometheus.metricMap)(0x400255c870)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001172f00)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x40003688c0)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001c50620)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x40024515f0)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 345ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations

