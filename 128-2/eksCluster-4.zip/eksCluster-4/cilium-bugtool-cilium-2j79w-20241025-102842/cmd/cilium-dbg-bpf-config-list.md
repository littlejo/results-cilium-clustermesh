KEY             VALUE
AgentLiveness   1002953668346
UTimeOffset     3378615531250000
