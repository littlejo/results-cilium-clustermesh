CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd8d86cb2_8a01_4a83_84d7_369caed746ab.slice/cri-containerd-096d5fa6b7b4bb9f06cb49451de465dbe475dbba9f3939203784455271ba8138.scope
    537      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd8d86cb2_8a01_4a83_84d7_369caed746ab.slice/cri-containerd-7b652fa31d9dae75398518b9c588a5dbe6b19321980b1a515a4f5d4d312f6faf.scope
    545      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3dcbd2d_dc6c_4d9f_8ce7_57f7288fa3ab.slice/cri-containerd-7ce79172f22ab43c4ec17a86dfe62696d5e06942bd2633f511622a43069033c7.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3dcbd2d_dc6c_4d9f_8ce7_57f7288fa3ab.slice/cri-containerd-878a1eeac453a9db08c0c9eb20213959ede12dae4735d707a8c3fae4894de793.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0b853d1b_5e91_4730_8d8a_37de34e66fe5.slice/cri-containerd-1c677c22810e0ba7d8a928df67a3390082c5b34bee4d6bcb51e1aafea60a3095.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0b853d1b_5e91_4730_8d8a_37de34e66fe5.slice/cri-containerd-dff4210bee75a321d1f606ad778ba340f43020286cca441f549de74422675ec5.scope
    541      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf08432cc_94f5_499f_b1d1_ba9062a2aa70.slice/cri-containerd-6267771060a605f3fdd6efbe6676f68f617686df25b074befea14a717ec8717f.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf08432cc_94f5_499f_b1d1_ba9062a2aa70.slice/cri-containerd-ddc2e54d7791b694ca4993b1080b8cabcf238fed4aa1ef27cb235fc866c5e7ff.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3caf821a_2588_4977_a9ea_d8ccce49d339.slice/cri-containerd-9c45fbb5d8d9131e2223d7700e122fd9fc385f6e0ead597daa12bd54ac1ba25e.scope
    72       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3caf821a_2588_4977_a9ea_d8ccce49d339.slice/cri-containerd-dd2ebbe35646a27e406f2d8e29baa3b644c877c579084536d8cb3cede3421979.scope
    61       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc6e7896e_26bd_4ece_aaf9_954fb1086341.slice/cri-containerd-7561d024f2ce12ac9a00feb1a9898099e65e8d8e60e409e49c114afe49a252bf.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc6e7896e_26bd_4ece_aaf9_954fb1086341.slice/cri-containerd-4e1f7eb6afd9cc834a3869b411f324b6ca7dc8875d500c19cd590bc4e8e7eac6.scope
    76       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95325341_7bb3_4fa0_bbc9_99eeec1a6baf.slice/cri-containerd-321edfdc537257e63f8a72a65f6daef938edcdd67496dc025d1200d659141ca1.scope
    627      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95325341_7bb3_4fa0_bbc9_99eeec1a6baf.slice/cri-containerd-d7a71f7d1a42f19e4a3bac1345e3931659e117aa55ee9c7115308bf87912569a.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95325341_7bb3_4fa0_bbc9_99eeec1a6baf.slice/cri-containerd-bcc76faff0d09726245f6eb7d7c0f8f2100df0f544e836ccd42c7d993cb621ee.scope
    619      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95325341_7bb3_4fa0_bbc9_99eeec1a6baf.slice/cri-containerd-60cee638941a26a3eb83fa420ce53e2f123107772f1277c2b8dfb9095792a3c9.scope
    623      cgroup_device   multi                                          
