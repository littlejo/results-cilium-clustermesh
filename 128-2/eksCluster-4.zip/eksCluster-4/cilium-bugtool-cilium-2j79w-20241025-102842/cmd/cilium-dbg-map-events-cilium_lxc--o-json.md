{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:19.394Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.172.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:19.394Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:24.215Z",
  "value": "id=3849  sec_id=4     flags=0x0000 ifindex=7   mac=DA:75:E3:53:22:AA nodemac=4A:24:76:B8:A3:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:24.242Z",
  "value": "id=3313  sec_id=379782 flags=0x0000 ifindex=9   mac=FE:64:F9:21:1F:CA nodemac=EA:7E:6A:3E:55:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:24.263Z",
  "value": "id=3728  sec_id=379782 flags=0x0000 ifindex=11  mac=6A:95:67:94:22:74 nodemac=62:0E:92:3C:F2:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:24.323Z",
  "value": "id=3849  sec_id=4     flags=0x0000 ifindex=7   mac=DA:75:E3:53:22:AA nodemac=4A:24:76:B8:A3:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.000Z",
  "value": "id=3849  sec_id=4     flags=0x0000 ifindex=7   mac=DA:75:E3:53:22:AA nodemac=4A:24:76:B8:A3:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.000Z",
  "value": "id=3728  sec_id=379782 flags=0x0000 ifindex=11  mac=6A:95:67:94:22:74 nodemac=62:0E:92:3C:F2:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.000Z",
  "value": "id=3313  sec_id=379782 flags=0x0000 ifindex=9   mac=FE:64:F9:21:1F:CA nodemac=EA:7E:6A:3E:55:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.039Z",
  "value": "id=3943  sec_id=337601 flags=0x0000 ifindex=13  mac=9E:E9:4B:C9:82:01 nodemac=46:1C:44:14:B4:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:39.000Z",
  "value": "id=3943  sec_id=337601 flags=0x0000 ifindex=13  mac=9E:E9:4B:C9:82:01 nodemac=46:1C:44:14:B4:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:39.000Z",
  "value": "id=3849  sec_id=4     flags=0x0000 ifindex=7   mac=DA:75:E3:53:22:AA nodemac=4A:24:76:B8:A3:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:39.001Z",
  "value": "id=3313  sec_id=379782 flags=0x0000 ifindex=9   mac=FE:64:F9:21:1F:CA nodemac=EA:7E:6A:3E:55:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:39.001Z",
  "value": "id=3728  sec_id=379782 flags=0x0000 ifindex=11  mac=6A:95:67:94:22:74 nodemac=62:0E:92:3C:F2:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:16.170Z",
  "value": "id=383   sec_id=337601 flags=0x0000 ifindex=15  mac=AA:B6:88:DB:A0:75 nodemac=EA:76:07:AB:08:53"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.4.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.110Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:41.812Z",
  "value": "id=383   sec_id=337601 flags=0x0000 ifindex=15  mac=AA:B6:88:DB:A0:75 nodemac=EA:76:07:AB:08:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:41.816Z",
  "value": "id=3849  sec_id=4     flags=0x0000 ifindex=7   mac=DA:75:E3:53:22:AA nodemac=4A:24:76:B8:A3:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:41.816Z",
  "value": "id=3313  sec_id=379782 flags=0x0000 ifindex=9   mac=FE:64:F9:21:1F:CA nodemac=EA:7E:6A:3E:55:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:41.816Z",
  "value": "id=3728  sec_id=379782 flags=0x0000 ifindex=11  mac=6A:95:67:94:22:74 nodemac=62:0E:92:3C:F2:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:42.801Z",
  "value": "id=3313  sec_id=379782 flags=0x0000 ifindex=9   mac=FE:64:F9:21:1F:CA nodemac=EA:7E:6A:3E:55:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:42.802Z",
  "value": "id=3849  sec_id=4     flags=0x0000 ifindex=7   mac=DA:75:E3:53:22:AA nodemac=4A:24:76:B8:A3:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:42.802Z",
  "value": "id=3728  sec_id=379782 flags=0x0000 ifindex=11  mac=6A:95:67:94:22:74 nodemac=62:0E:92:3C:F2:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:42.802Z",
  "value": "id=383   sec_id=337601 flags=0x0000 ifindex=15  mac=AA:B6:88:DB:A0:75 nodemac=EA:76:07:AB:08:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:43.802Z",
  "value": "id=3849  sec_id=4     flags=0x0000 ifindex=7   mac=DA:75:E3:53:22:AA nodemac=4A:24:76:B8:A3:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:43.802Z",
  "value": "id=383   sec_id=337601 flags=0x0000 ifindex=15  mac=AA:B6:88:DB:A0:75 nodemac=EA:76:07:AB:08:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:43.802Z",
  "value": "id=3728  sec_id=379782 flags=0x0000 ifindex=11  mac=6A:95:67:94:22:74 nodemac=62:0E:92:3C:F2:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.4.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:43.802Z",
  "value": "id=3313  sec_id=379782 flags=0x0000 ifindex=9   mac=FE:64:F9:21:1F:CA nodemac=EA:7E:6A:3E:55:FB"
}

