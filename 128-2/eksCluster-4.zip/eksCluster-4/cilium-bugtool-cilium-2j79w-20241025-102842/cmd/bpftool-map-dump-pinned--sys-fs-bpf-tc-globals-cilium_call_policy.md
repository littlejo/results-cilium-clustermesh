key: 7f 01 00 00  value: 54 02 00 00
key: f1 0c 00 00  value: ed 01 00 00
key: 90 0e 00 00  value: ee 01 00 00
key: 09 0f 00 00  value: 0d 02 00 00
Found 4 elements
