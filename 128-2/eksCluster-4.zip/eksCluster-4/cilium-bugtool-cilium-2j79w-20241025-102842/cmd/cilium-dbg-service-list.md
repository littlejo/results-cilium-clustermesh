ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.167.244:443 (active)    
                                         2 => 172.31.195.197:443 (active)    
2    10.100.18.94:443     ClusterIP      1 => 172.31.172.128:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.4.0.51:53 (active)          
                                         2 => 10.4.0.231:53 (active)         
4    10.100.0.10:9153     ClusterIP      1 => 10.4.0.51:9153 (active)        
                                         2 => 10.4.0.231:9153 (active)       
5    10.100.93.105:2379   ClusterIP      1 => 10.4.0.158:2379 (active)       
