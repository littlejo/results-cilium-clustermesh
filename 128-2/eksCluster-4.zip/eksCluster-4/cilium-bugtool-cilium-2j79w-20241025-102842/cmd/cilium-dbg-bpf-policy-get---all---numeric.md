Endpoint ID: 383
Path: /sys/fs/bpf/tc/globals/cilium_policy_00383

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3829254   34918     0        
Allow    Ingress     1          ANY          NONE         disabled    2749716   27429     0        
Allow    Egress      0          ANY          NONE         disabled    3455050   32401     0        


Endpoint ID: 3313
Path: /sys/fs/bpf/tc/globals/cilium_policy_03313

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    89608   1034      0        
Allow    Egress      0          ANY          NONE         disabled    14546   152       0        


Endpoint ID: 3645
Path: /sys/fs/bpf/tc/globals/cilium_policy_03645

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3728
Path: /sys/fs/bpf/tc/globals/cilium_policy_03728

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    89793   1034      0        
Allow    Egress      0          ANY          NONE         disabled    13797   145       0        


Endpoint ID: 3849
Path: /sys/fs/bpf/tc/globals/cilium_policy_03849

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    440133   5631      0        
Allow    Ingress     1          ANY          NONE         disabled    13056    153       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


