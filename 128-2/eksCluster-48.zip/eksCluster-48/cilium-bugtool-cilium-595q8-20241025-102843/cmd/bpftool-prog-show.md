35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:51+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:14:46+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
485: sched_cls  name tail_handle_ipv4  tag 8cb87be9891549dc  gpl
	loaded_at 2024-10-25T10:14:46+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
486: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:14:46+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
487: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:14:46+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
516: sched_cls  name tail_ipv4_ct_ingress  tag a9b0dfc29c3fbf4e  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,111,84
	btf_id 161
517: sched_cls  name tail_ipv4_ct_egress  tag d1d4a69d84eb29e6  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,111,84
	btf_id 162
520: sched_cls  name tail_handle_ipv4  tag 074b71f11336dfc8  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,110
	btf_id 163
522: sched_cls  name __send_drop_notify  tag e268725ed0ff666a  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 168
523: sched_cls  name tail_handle_arp  tag 05acfa57596ebb7b  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,110
	btf_id 169
526: sched_cls  name tail_ipv4_to_endpoint  tag 0e0d40394fc5603b  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,111,41,82,83,80,109,39,110,40,37,38
	btf_id 171
529: sched_cls  name tail_handle_ipv4_cont  tag 07852ecb475774fa  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,111,41,109,82,83,39,76,74,77,110,40,37,38,81
	btf_id 175
530: sched_cls  name cil_from_container  tag 456b31a8fa2c27a6  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 110,76
	btf_id 176
534: sched_cls  name handle_policy  tag b326ef7cd132f133  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,110,82,83,111,41,80,109,39,84,75,40,37,38
	btf_id 179
536: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,110
	btf_id 182
538: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 185
539: sched_cls  name tail_handle_arp  tag e4cb2b2d3c0e14e8  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 188
540: sched_cls  name __send_drop_notify  tag e1b95f5d3c1adc82  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 189
542: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,114
	btf_id 191
543: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,114
	btf_id 192
544: sched_cls  name tail_handle_ipv4_from_host  tag 587f1acd1c7cd13a  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,114
	btf_id 193
545: sched_cls  name __send_drop_notify  tag 4fb6aef83b639d38  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 194
547: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 197
549: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 199
551: sched_cls  name tail_handle_ipv4_from_host  tag 587f1acd1c7cd13a  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 201
552: sched_cls  name __send_drop_notify  tag 4fb6aef83b639d38  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 202
554: sched_cls  name tail_ipv4_ct_ingress  tag 454e78473d25de3b  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,116,82,83,117,84
	btf_id 190
555: sched_cls  name tail_handle_ipv4_from_host  tag 587f1acd1c7cd13a  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 205
556: sched_cls  name __send_drop_notify  tag 4fb6aef83b639d38  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 206
559: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 210
560: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 211
563: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 215
564: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 216
565: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,116,82,83,117,84
	btf_id 208
568: sched_cls  name tail_handle_ipv4  tag 9d6a01f1f581d52c  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 220
569: sched_cls  name tail_handle_ipv4_from_host  tag 587f1acd1c7cd13a  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 219
570: sched_cls  name __send_drop_notify  tag 4fb6aef83b639d38  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 222
572: sched_cls  name tail_handle_ipv4_cont  tag 4f650821967c50f8  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,117,41,100,82,83,39,76,74,77,116,40,37,38,81
	btf_id 221
573: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 224
574: sched_cls  name handle_policy  tag c87913a124606b99  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,116,82,83,117,41,80,100,39,84,75,40,37,38
	btf_id 225
575: sched_cls  name tail_ipv4_to_endpoint  tag 5ea59a191647ba0a  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,117,41,82,83,80,100,39,116,40,37,38
	btf_id 226
576: sched_cls  name cil_from_container  tag 9d210a75d7be6599  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 116,76
	btf_id 227
577: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
580: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
581: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
584: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
585: sched_cls  name tail_ipv4_ct_egress  tag d1d4a69d84eb29e6  gpl
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,128,82,83,127,84
	btf_id 229
586: sched_cls  name tail_ipv4_to_endpoint  tag c33fb9bfa6da67b2  gpl
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,127,41,82,83,80,126,39,128,40,37,38
	btf_id 230
587: sched_cls  name tail_handle_ipv4_cont  tag 152d3d3b85ced3cb  gpl
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,127,41,126,82,83,39,76,74,77,128,40,37,38,81
	btf_id 231
588: sched_cls  name tail_handle_ipv4  tag bfa0c75f0b8d12d8  gpl
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,128
	btf_id 232
589: sched_cls  name tail_handle_arp  tag 1e6db99046c8a149  gpl
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,128
	btf_id 233
590: sched_cls  name tail_ipv4_ct_ingress  tag 7cc0c224fc05352b  gpl
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,128,82,83,127,84
	btf_id 234
591: sched_cls  name __send_drop_notify  tag 4b8a27b79919adbd  gpl
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 235
593: sched_cls  name handle_policy  tag e5ca86f885065b66  gpl
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,128,82,83,127,41,80,126,39,84,75,40,37,38
	btf_id 237
594: sched_cls  name cil_from_container  tag 0cd36f0f17a21d0d  gpl
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 128,76
	btf_id 238
595: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,128
	btf_id 239
596: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
599: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
600: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
603: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
643: sched_cls  name __send_drop_notify  tag 6bd0ac9e13050272  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 253
644: sched_cls  name tail_handle_ipv4_cont  tag 63879dbaed4b51bd  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,143,41,141,82,83,39,76,74,77,142,40,37,38,81
	btf_id 254
645: sched_cls  name tail_ipv4_ct_egress  tag 59d0af60a4030b1a  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 255
647: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,142
	btf_id 257
648: sched_cls  name tail_handle_arp  tag 4d8ee485e6c25da4  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,142
	btf_id 258
649: sched_cls  name cil_from_container  tag 42bf1995e257f79c  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 142,76
	btf_id 259
650: sched_cls  name tail_handle_ipv4  tag e3ab6503feb0dc2c  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,142
	btf_id 260
651: sched_cls  name tail_ipv4_ct_ingress  tag ee1e9516bff72c31  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 261
652: sched_cls  name handle_policy  tag 6dc61692d4afed99  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,142,82,83,143,41,80,141,39,84,75,40,37,38
	btf_id 262
653: sched_cls  name tail_ipv4_to_endpoint  tag a4aae10492f38ca3  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,143,41,82,83,80,141,39,142,40,37,38
	btf_id 263
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
670: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
673: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
674: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
677: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
678: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
681: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
