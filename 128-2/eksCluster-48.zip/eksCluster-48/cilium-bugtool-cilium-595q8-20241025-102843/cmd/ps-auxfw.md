USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         664  0.0  0.4 1240432 16348 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         692  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         694  0.0  0.0    352     4 ?        R    10:28   0:00  \_ hostname
root           1  3.0  7.2 1538356 282960 ?      Ssl  10:14   0:25 cilium-agent --config-dir=/tmp/cilium/config-map
root         415  0.0  0.1 1228848 6884 ?        Sl   10:14   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
