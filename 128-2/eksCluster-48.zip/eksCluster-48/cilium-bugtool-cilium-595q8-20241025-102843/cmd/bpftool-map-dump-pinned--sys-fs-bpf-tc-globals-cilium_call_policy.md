key: a0 00 00 00  value: 51 02 00 00
key: 85 01 00 00  value: 16 02 00 00
key: 4e 03 00 00  value: 8c 02 00 00
key: 9b 08 00 00  value: 3e 02 00 00
Found 4 elements
