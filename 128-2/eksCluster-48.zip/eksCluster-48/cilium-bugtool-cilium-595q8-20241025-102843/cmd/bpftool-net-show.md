xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 559
ens6(5) clsact/ingress cil_from_netdev-ens6 id 563
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 547
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 538
cilium_host(7) clsact/egress cil_from_host-cilium_host id 543
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 576
lxc07c3ad53afe4(12) clsact/ingress cil_from_container-lxc07c3ad53afe4 id 530
lxcf5b6b860ac3b(14) clsact/ingress cil_from_container-lxcf5b6b860ac3b id 594
lxc53f9f3f817da(18) clsact/ingress cil_from_container-lxc53f9f3f817da id 649

flow_dissector:

netfilter:

