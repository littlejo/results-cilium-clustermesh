[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8eb7bd06_3c02_4410_b826_0750ce20ad99.slice/cri-containerd-57bfe861a7037391930687ac63301e0d87560d55cc9f01782c114a8990491419.scope"
      }
    ],
    "ips": [
      "10.48.0.164"
    ],
    "name": "coredns-cc6ccd49c-pk99f",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36613dcf_3f6c_4fd5_9678_3fb3632d8db7.slice/cri-containerd-5f60a5f5b62008404b95d746a98901a695ab5dfbf00c09fe871c23a3576cdccb.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36613dcf_3f6c_4fd5_9678_3fb3632d8db7.slice/cri-containerd-599b078baea4f10cfaac99a4f038cea8f97bb5b938c8590e41e2bdc49092452a.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36613dcf_3f6c_4fd5_9678_3fb3632d8db7.slice/cri-containerd-09a7ac642a8cde512a8de8ba02f1bc59fba279d1631b39927da1353c374ea996.scope"
      }
    ],
    "ips": [
      "10.48.0.115"
    ],
    "name": "clustermesh-apiserver-777566c59b-8zf6x",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7530,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf24c505e_0b0d_4d6d_b32b_d1d0ed833a0c.slice/cri-containerd-27b06b03bb9639826bec193d0047f50d857ab496e457984a2a07c3df65019bd2.scope"
      }
    ],
    "ips": [
      "10.48.0.220"
    ],
    "name": "coredns-cc6ccd49c-hntvl",
    "namespace": "kube-system"
  }
]

