top - 10:28:45 up 15 min,  0 users,  load average: 0.07, 0.18, 0.17
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 27.6 us, 34.5 sy,  0.0 ni, 31.0 id,  0.0 wa,  0.0 hi,  6.9 si,  0.0 st
MiB Mem :   3836.2 total,    783.3 free,    911.9 used,   2141.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2755.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    664 root      20   0 1240432  16668  11292 S   6.7   0.4   0:00.04 cilium-+
      1 root      20   0 1538356 282960  79916 S   0.0   7.2   0:25.94 cilium-+
    415 root      20   0 1228848   6884   3840 S   0.0   0.2   0:00.27 cilium-+
    704 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    707 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    733 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
