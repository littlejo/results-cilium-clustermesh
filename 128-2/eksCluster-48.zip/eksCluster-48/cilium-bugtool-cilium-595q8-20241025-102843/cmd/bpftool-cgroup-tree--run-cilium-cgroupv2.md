CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8eb7bd06_3c02_4410_b826_0750ce20ad99.slice/cri-containerd-57bfe861a7037391930687ac63301e0d87560d55cc9f01782c114a8990491419.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8eb7bd06_3c02_4410_b826_0750ce20ad99.slice/cri-containerd-67fe79e547d0113b4bbf6ddf55c34fcfc0223e22dc794fa6f0546890edff3aef.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf24c505e_0b0d_4d6d_b32b_d1d0ed833a0c.slice/cri-containerd-27b06b03bb9639826bec193d0047f50d857ab496e457984a2a07c3df65019bd2.scope
    584      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf24c505e_0b0d_4d6d_b32b_d1d0ed833a0c.slice/cri-containerd-23c9717461fdab82452444cf47b8f8ead3921b400306681bcb323a18caa74cc3.scope
    580      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod33af6998_c926_45fc_9a9d_d69db8fb1da1.slice/cri-containerd-02e4129c5f2f39f6f29d7879e0466e98131cab7d4940440d37e730812a0144b4.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod33af6998_c926_45fc_9a9d_d69db8fb1da1.slice/cri-containerd-261b61bcb6bc5a41f255731d0a47834c9ae0698804ca039c537a53f08587bfac.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcf24962a_6d46_406e_a8b0_d5bd84a9a642.slice/cri-containerd-b09a6e6c8f2f39b23d7e691b2b74f3b722b56ac4cda7e606325d996f2a1d0568.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcf24962a_6d46_406e_a8b0_d5bd84a9a642.slice/cri-containerd-44528c23d5b539dd4a8ee0918d4a47bfde78def1d90ec4dbe4776d85132c3816.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3c1d776e_c3b5_433c_b304_f08bdf8a4bb2.slice/cri-containerd-9b32af22702c14b31d3c0f10f9ce2b21482ddad49bc66d0be686fc8d83039f43.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3c1d776e_c3b5_433c_b304_f08bdf8a4bb2.slice/cri-containerd-406121dc32ed787d6b634a587d57720773d52630425d49bc070ca6114d27cbd2.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36613dcf_3f6c_4fd5_9678_3fb3632d8db7.slice/cri-containerd-5f60a5f5b62008404b95d746a98901a695ab5dfbf00c09fe871c23a3576cdccb.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36613dcf_3f6c_4fd5_9678_3fb3632d8db7.slice/cri-containerd-599b078baea4f10cfaac99a4f038cea8f97bb5b938c8590e41e2bdc49092452a.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36613dcf_3f6c_4fd5_9678_3fb3632d8db7.slice/cri-containerd-09a7ac642a8cde512a8de8ba02f1bc59fba279d1631b39927da1353c374ea996.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36613dcf_3f6c_4fd5_9678_3fb3632d8db7.slice/cri-containerd-32fc4acb82bbe347a61649704289d031ead5e25bce185ea1ca1158234faf05f4.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod579c529e_7685_4c5c_9011_97292a73a9d8.slice/cri-containerd-6e3ab5b73b4c87d921fc4131f9f3e5da4100f2988dc37d31019196a972a17e00.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod579c529e_7685_4c5c_9011_97292a73a9d8.slice/cri-containerd-279f073cf317a97be738f3cd51534f2e058f0284c31724c3884531bf6d42a53d.scope
    93       cgroup_device   multi                                          
