REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10060     788333     677    bpf_overlay.c
Interface                 INGRESS     225642    86524407   1132   bpf_host.c
Success                   EGRESS      10281     804765     53     encap.h
Success                   EGRESS      5169      398466     1694   bpf_host.c
Success                   EGRESS      97919     12685180   1308   bpf_lxc.c
Success                   INGRESS     108063    13389420   86     l3.h
Success                   INGRESS     113603    13823193   235    trace.h
Unsupported L3 protocol   EGRESS      42        3168       1492   bpf_lxc.c
