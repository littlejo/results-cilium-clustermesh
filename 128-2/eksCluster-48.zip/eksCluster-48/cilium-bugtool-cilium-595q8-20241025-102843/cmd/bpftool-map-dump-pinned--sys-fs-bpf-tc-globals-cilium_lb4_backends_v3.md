key: 01 00 00 00  value: ac 1f 8e ab 01 bb 00 00  00 00 00 00
key: 0a 00 00 00  value: 0a 30 00 a4 00 35 00 00  00 00 00 00
key: 0d 00 00 00  value: 0a 30 00 73 09 4b 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 30 00 dc 23 c1 00 00  00 00 00 00
key: 07 00 00 00  value: ac 1f 95 73 10 94 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 30 00 dc 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f ca c1 01 bb 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 30 00 a4 23 c1 00 00  00 00 00 00
Found 8 elements
