IP ADDRESS         LOCAL ENDPOINT INFO
10.48.0.164:0      id=160   sec_id=3216961 flags=0x0000 ifindex=14  mac=CA:FD:D2:0C:60:5F nodemac=9A:F6:59:B9:5F:D2   
172.31.133.94:0    (localhost)                                                                                        
10.48.0.47:0       (localhost)                                                                                        
10.48.0.31:0       id=2203  sec_id=4     flags=0x0000 ifindex=10  mac=06:21:3E:D0:56:FB nodemac=2E:21:F0:FA:C6:A5     
172.31.149.115:0   (localhost)                                                                                        
10.48.0.115:0      id=846   sec_id=3263470 flags=0x0000 ifindex=18  mac=32:25:9C:75:04:5B nodemac=E6:98:DB:9C:78:0B   
10.48.0.220:0      id=389   sec_id=3216961 flags=0x0000 ifindex=12  mac=AA:A7:EC:10:7E:3B nodemac=56:DB:39:EC:53:0D   
