alloc: 120.11MB (125944792 bytes)
total-alloc: 1.37GB (1470972248 bytes)
sys: 206.63MB (216671572 bytes)
lookups: 0
mallocs: 48412307
frees: 47138095
heap-alloc: 120.11MB (125944792 bytes)
heap-sys: 161.30MB (169132032 bytes)
heap-idle: 20.54MB (21536768 bytes)
heap-in-use: 140.76MB (147595264 bytes)
heap-released: 1.97MB (2064384 bytes)
heap-objects: 1274212
stack-in-use: 34.66MB (36339712 bytes)
stack-sys: 34.66MB (36339712 bytes)
stack-mspan-inuse: 2.30MB (2416000 bytes)
stack-mspan-sys: 2.51MB (2627520 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.10MB (1151169 bytes)
gc-sys: 5.17MB (5419264 bytes)
next-gc: when heap-alloc >= 149.80MB (157071592 bytes)
last-gc: 2024-10-25 10:28:45.247668969 +0000 UTC
gc-pause-total: 11.250434ms
gc-pause: 1535499
gc-pause-end: 1729852125247668969
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.0003496613056738288
enable-gc: true
debug-gc: false
