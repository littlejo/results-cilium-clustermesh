{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:44.384Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.133.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:44.384Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.149.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:44.384Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:48.965Z",
  "value": "id=389   sec_id=3216961 flags=0x0000 ifindex=12  mac=AA:A7:EC:10:7E:3B nodemac=56:DB:39:EC:53:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:48.971Z",
  "value": "id=2203  sec_id=4     flags=0x0000 ifindex=10  mac=06:21:3E:D0:56:FB nodemac=2E:21:F0:FA:C6:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:49.026Z",
  "value": "id=2203  sec_id=4     flags=0x0000 ifindex=10  mac=06:21:3E:D0:56:FB nodemac=2E:21:F0:FA:C6:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:56.047Z",
  "value": "id=160   sec_id=3216961 flags=0x0000 ifindex=14  mac=CA:FD:D2:0C:60:5F nodemac=9A:F6:59:B9:5F:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:40.238Z",
  "value": "id=2203  sec_id=4     flags=0x0000 ifindex=10  mac=06:21:3E:D0:56:FB nodemac=2E:21:F0:FA:C6:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:40.239Z",
  "value": "id=389   sec_id=3216961 flags=0x0000 ifindex=12  mac=AA:A7:EC:10:7E:3B nodemac=56:DB:39:EC:53:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:40.239Z",
  "value": "id=160   sec_id=3216961 flags=0x0000 ifindex=14  mac=CA:FD:D2:0C:60:5F nodemac=9A:F6:59:B9:5F:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:40.271Z",
  "value": "id=142   sec_id=3263470 flags=0x0000 ifindex=16  mac=1A:8F:EF:7D:54:E3 nodemac=76:B0:A2:39:2D:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:41.239Z",
  "value": "id=160   sec_id=3216961 flags=0x0000 ifindex=14  mac=CA:FD:D2:0C:60:5F nodemac=9A:F6:59:B9:5F:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:41.239Z",
  "value": "id=389   sec_id=3216961 flags=0x0000 ifindex=12  mac=AA:A7:EC:10:7E:3B nodemac=56:DB:39:EC:53:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:41.239Z",
  "value": "id=2203  sec_id=4     flags=0x0000 ifindex=10  mac=06:21:3E:D0:56:FB nodemac=2E:21:F0:FA:C6:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:41.239Z",
  "value": "id=142   sec_id=3263470 flags=0x0000 ifindex=16  mac=1A:8F:EF:7D:54:E3 nodemac=76:B0:A2:39:2D:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:12.284Z",
  "value": "id=846   sec_id=3263470 flags=0x0000 ifindex=18  mac=32:25:9C:75:04:5B nodemac=E6:98:DB:9C:78:0B"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.48.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:22.618Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:08.473Z",
  "value": "id=2203  sec_id=4     flags=0x0000 ifindex=10  mac=06:21:3E:D0:56:FB nodemac=2E:21:F0:FA:C6:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:08.474Z",
  "value": "id=389   sec_id=3216961 flags=0x0000 ifindex=12  mac=AA:A7:EC:10:7E:3B nodemac=56:DB:39:EC:53:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:08.475Z",
  "value": "id=160   sec_id=3216961 flags=0x0000 ifindex=14  mac=CA:FD:D2:0C:60:5F nodemac=9A:F6:59:B9:5F:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:08.475Z",
  "value": "id=846   sec_id=3263470 flags=0x0000 ifindex=18  mac=32:25:9C:75:04:5B nodemac=E6:98:DB:9C:78:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:09.435Z",
  "value": "id=389   sec_id=3216961 flags=0x0000 ifindex=12  mac=AA:A7:EC:10:7E:3B nodemac=56:DB:39:EC:53:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:09.436Z",
  "value": "id=846   sec_id=3263470 flags=0x0000 ifindex=18  mac=32:25:9C:75:04:5B nodemac=E6:98:DB:9C:78:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:09.436Z",
  "value": "id=2203  sec_id=4     flags=0x0000 ifindex=10  mac=06:21:3E:D0:56:FB nodemac=2E:21:F0:FA:C6:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:09.436Z",
  "value": "id=160   sec_id=3216961 flags=0x0000 ifindex=14  mac=CA:FD:D2:0C:60:5F nodemac=9A:F6:59:B9:5F:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:10.436Z",
  "value": "id=389   sec_id=3216961 flags=0x0000 ifindex=12  mac=AA:A7:EC:10:7E:3B nodemac=56:DB:39:EC:53:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:10.436Z",
  "value": "id=846   sec_id=3263470 flags=0x0000 ifindex=18  mac=32:25:9C:75:04:5B nodemac=E6:98:DB:9C:78:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:10.436Z",
  "value": "id=160   sec_id=3216961 flags=0x0000 ifindex=14  mac=CA:FD:D2:0C:60:5F nodemac=9A:F6:59:B9:5F:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.48.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:10.436Z",
  "value": "id=2203  sec_id=4     flags=0x0000 ifindex=10  mac=06:21:3E:D0:56:FB nodemac=2E:21:F0:FA:C6:A5"
}

