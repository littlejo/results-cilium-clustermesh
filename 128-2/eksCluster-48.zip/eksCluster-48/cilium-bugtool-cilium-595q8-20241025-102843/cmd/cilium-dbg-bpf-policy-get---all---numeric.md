Endpoint ID: 61
Path: /sys/fs/bpf/tc/globals/cilium_policy_00061

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 160
Path: /sys/fs/bpf/tc/globals/cilium_policy_00160

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    80801   927       0        
Allow    Egress      0          ANY          NONE         disabled    14239   150       0        


Endpoint ID: 389
Path: /sys/fs/bpf/tc/globals/cilium_policy_00389

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    82290   946       0        
Allow    Egress      0          ANY          NONE         disabled    13688   143       0        


Endpoint ID: 846
Path: /sys/fs/bpf/tc/globals/cilium_policy_00846

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3808967   36451     0        
Allow    Ingress     1          ANY          NONE         disabled    3411038   34776     0        
Allow    Egress      0          ANY          NONE         disabled    5433672   50008     0        


Endpoint ID: 2203
Path: /sys/fs/bpf/tc/globals/cilium_policy_02203

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    434825   5553      0        
Allow    Ingress     1          ANY          NONE         disabled    12136    142       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


