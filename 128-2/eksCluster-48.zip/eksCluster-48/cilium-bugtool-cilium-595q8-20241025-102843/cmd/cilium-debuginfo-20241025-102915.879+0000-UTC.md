# Cilium debug information

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 33722215                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 33722215                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 33722215                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400c800000 rw-p 00000000 00:00 0 
400c800000-4010000000 ---p 00000000 00:00 0 
ffff4d69d000-ffff4d8e3000 rw-p 00000000 00:00 0 
ffff4d8eb000-ffff4da0c000 rw-p 00000000 00:00 0 
ffff4da0c000-ffff4da4d000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff4da4d000-ffff4da8e000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff4da8e000-ffff4da90000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff4da90000-ffff4da92000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff4da92000-ffff4e059000 rw-p 00000000 00:00 0 
ffff4e059000-ffff4e159000 rw-p 00000000 00:00 0 
ffff4e159000-ffff4e16a000 rw-p 00000000 00:00 0 
ffff4e16a000-ffff5016a000 rw-p 00000000 00:00 0 
ffff5016a000-ffff501ea000 ---p 00000000 00:00 0 
ffff501ea000-ffff501eb000 rw-p 00000000 00:00 0 
ffff501eb000-ffff701ea000 ---p 00000000 00:00 0 
ffff701ea000-ffff701eb000 rw-p 00000000 00:00 0 
ffff701eb000-ffff9017a000 ---p 00000000 00:00 0 
ffff9017a000-ffff9017b000 rw-p 00000000 00:00 0 
ffff9017b000-ffff9416c000 ---p 00000000 00:00 0 
ffff9416c000-ffff9416d000 rw-p 00000000 00:00 0 
ffff9416d000-ffff9496a000 ---p 00000000 00:00 0 
ffff9496a000-ffff9496b000 rw-p 00000000 00:00 0 
ffff9496b000-ffff94a6a000 ---p 00000000 00:00 0 
ffff94a6a000-ffff94aca000 rw-p 00000000 00:00 0 
ffff94aca000-ffff94acc000 r--p 00000000 00:00 0                          [vvar]
ffff94acc000-ffff94acd000 r-xp 00000000 00:00 0                          [vdso]
ffffd71c2000-ffffd71e3000 rw-p 00000000 00:00 0                          [stack]

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.48.0.115": (string) (len=50) "kube-system/clustermesh-apiserver-777566c59b-8zf6x",
  (string) (len=10) "10.48.0.47": (string) (len=6) "router",
  (string) (len=10) "10.48.0.31": (string) (len=6) "health",
  (string) (len=11) "10.48.0.220": (string) (len=35) "kube-system/coredns-cc6ccd49c-hntvl",
  (string) (len=11) "10.48.0.164": (string) (len=35) "kube-system/coredns-cc6ccd49c-pk99f"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.149.115": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4002390160)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x400187ac60,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x400187ac60,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x400100f4a0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x400100f550)(frontends:[10.100.142.72]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x400100f600)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4002944420)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40029444d0)(frontends:[10.100.58.179]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x40014719d0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4002485860)(172.31.142.171:443/TCP,172.31.202.193:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x40014719e0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-pg2kd": (*k8s.Endpoints)(0x4002d905b0)(172.31.149.115:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x40014719e8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-wp2gd": (*k8s.Endpoints)(0x400150a000)(10.48.0.164:53/TCP[eu-west-3a],10.48.0.164:53/UDP[eu-west-3a],10.48.0.164:9153/TCP[eu-west-3a],10.48.0.220:53/TCP[eu-west-3a],10.48.0.220:53/UDP[eu-west-3a],10.48.0.220:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4000fe3418)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-w7prp": (*k8s.Endpoints)(0x40033172b0)(10.48.0.115:2379/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4002511500)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4002897310)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4009a740f0
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4002895bc0,
  gcExited: (chan struct {}) 0x4002895c20,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4002447c00)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001471890)({
      MetricVec: (*prometheus.MetricVec)(0x4000b2aae0)({
       metricMap: (*prometheus.metricMap)(0x4000b2aba0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025b0ea0)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4002447c80)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001471898)({
      MetricVec: (*prometheus.MetricVec)(0x4000b2ac60)({
       metricMap: (*prometheus.metricMap)(0x4000b2ac90)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025b0f00)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4002447d00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40014718a0)({
      MetricVec: (*prometheus.MetricVec)(0x4000b2acf0)({
       metricMap: (*prometheus.metricMap)(0x4000b2ad20)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025b0f60)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4002447d80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40014718a8)({
      MetricVec: (*prometheus.MetricVec)(0x4000b2af30)({
       metricMap: (*prometheus.metricMap)(0x4000b2b080)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025b0fc0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4002447e00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40014718b0)({
      MetricVec: (*prometheus.MetricVec)(0x4000b2b0e0)({
       metricMap: (*prometheus.metricMap)(0x4000b2b140)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025b1020)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4002447e80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40014718b8)({
      MetricVec: (*prometheus.MetricVec)(0x4000b2b380)({
       metricMap: (*prometheus.metricMap)(0x4000b2b3b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025b1080)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4002447f00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40014718c0)({
      MetricVec: (*prometheus.MetricVec)(0x4000b2b4d0)({
       metricMap: (*prometheus.metricMap)(0x4000b2b500)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025b10e0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4000fec000)({
     GaugeVec: (*prometheus.GaugeVec)(0x40014718c8)({
      MetricVec: (*prometheus.MetricVec)(0x4000b2b650)({
       metricMap: (*prometheus.metricMap)(0x4000b2b680)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025b1140)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4000fec100)({
     ObserverVec: (*prometheus.HistogramVec)(0x40014718d0)({
      MetricVec: (*prometheus.MetricVec)(0x4000b2b7d0)({
       metricMap: (*prometheus.metricMap)(0x4000b2b800)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40025b11a0)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4002511500)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4000176690)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001d78930)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 369ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   },
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium environment keys

```
service-no-backend-response:reject
cluster-name:cmesh49
http-idle-timeout:0
enable-route-mtu-for-cni-chaining:false
mesh-auth-mutual-connect-timeout:5s
ip-masq-agent-config-path:/etc/config/ip-masq-agent
hubble-skip-unknown-cgroup-ids:true
enable-host-legacy-routing:false
enable-ipsec-xfrm-state-caching:true
cni-chaining-target:
max-internal-timer-delay:0s
dnsproxy-concurrency-processing-grace-period:0s
vtep-cidr:
enable-node-port:false
enable-encryption-strict-mode:false
cilium-endpoint-gc-interval:5m0s
enable-stale-cilium-endpoint-cleanup:true
lib-dir:/var/lib/cilium
conntrack-gc-max-interval:0s
mesh-auth-enabled:true
hubble-export-file-max-backups:5
proxy-portrange-min:10000
bpf-lb-external-clusterip:false
debug-verbose:
hubble-event-queue-size:0
enable-bandwidth-manager:false
k8s-client-qps:10
enable-k8s-terminating-endpoint:true
prometheus-serve-addr:
tofqdns-endpoint-max-ip-per-hostname:50
dnsproxy-lock-timeout:500ms
enable-masquerade-to-route-source:false
hubble-event-buffer-capacity:4095
enable-custom-calls:false
hubble-metrics-server:
enable-bgp-control-plane:false
max-controller-interval:0
enable-endpoint-health-checking:true
controller-group-metrics:
enable-hubble-recorder-api:true
tofqdns-enable-dns-compression:true
conntrack-gc-interval:0s
set-cilium-node-taints:true
disable-envoy-version-check:false
k8s-client-connection-keep-alive:30s
enable-cilium-health-api-server-access:
proxy-xff-num-trusted-hops-egress:0
custom-cni-conf:false
monitor-aggregation:medium
kube-proxy-replacement-healthz-bind-address:
remove-cilium-node-taints:true
k8s-heartbeat-timeout:30s
enable-host-port:false
hubble-prefer-ipv6:false
policy-trigger-interval:1s
enable-vtep:false
enable-node-selector-labels:false
dnsproxy-insecure-skip-transparent-mode-check:false
hubble-socket-path:/var/run/cilium/hubble.sock
route-metric:0
certificates-directory:/var/run/cilium/certs
enable-xt-socket-fallback:true
direct-routing-device:
enable-ipv6-ndp:false
http-request-timeout:3600
ipam-cilium-node-update-rate:15s
hubble-export-allowlist:
join-cluster:false
enable-metrics:true
bpf-ct-global-any-max:262144
bpf-lb-mode:snat
enable-unreachable-routes:false
bpf-lb-dsr-dispatch:opt
bpf-policy-map-full-reconciliation-interval:15m0s
prepend-iptables-chains:true
enable-high-scale-ipcache:false
k8s-namespace:kube-system
proxy-gid:1337
envoy-config-retry-interval:15s
tofqdns-proxy-port:0
unmanaged-pod-watcher-interval:15
enable-external-ips:false
ipv4-native-routing-cidr:
nodeport-addresses:
bpf-lb-rss-ipv6-src-cidr:
k8s-kubeconfig-path:
bpf-lb-maglev-map-max:0
hubble-export-file-compress:false
envoy-config-timeout:2m0s
enable-k8s-networkpolicy:true
enable-health-check-loadbalancer-ip:false
pprof:false
trace-sock:true
iptables-random-fully:false
http-retry-timeout:0
k8s-client-connection-timeout:30s
datapath-mode:veth
enable-nat46x64-gateway:false
policy-accounting:true
hubble-monitor-events:
enable-l7-proxy:true
bpf-lb-acceleration:disabled
bpf-node-map-max:16384
hubble-redact-http-headers-allow:
exclude-node-label-patterns:
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
envoy-secrets-namespace:
hubble-listen-address::4244
encryption-strict-mode-cidr:
kube-proxy-replacement:false
ipam-default-ip-pool:default
hubble-redact-http-urlquery:false
clustermesh-enable-mcs-api:false
enable-ipv4-masquerade:true
hubble-recorder-storage-path:/var/run/cilium/pcaps
proxy-prometheus-port:0
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
iptables-lock-timeout:5s
bpf-lb-algorithm:random
egress-gateway-policy-map-max:16384
node-port-acceleration:disabled
identity-heartbeat-timeout:30m0s
disable-endpoint-crd:false
tunnel-protocol:vxlan
cni-log-file:/var/run/cilium/cilium-cni.log
enable-ipv4-fragment-tracking:true
bpf-ct-timeout-service-any:1m0s
egress-gateway-reconciliation-trigger-interval:1s
operator-api-serve-addr:127.0.0.1:9234
log-opt:
enable-tcx:true
tunnel-port:0
ipv4-service-range:auto
agent-labels:
clustermesh-enable-endpoint-sync:false
proxy-max-connection-duration-seconds:0
hubble-recorder-sink-queue-size:1024
enable-k8s-endpoint-slice:true
enable-bpf-tproxy:false
enable-well-known-identities:false
tofqdns-min-ttl:0
proxy-admin-port:0
bpf-lb-maglev-table-size:16381
node-port-range:
clustermesh-ip-identities-sync-timeout:1m0s
enable-k8s:true
hubble-metrics:
http-retry-count:3
ipv6-service-range:auto
ipsec-key-rotation-duration:5m0s
kvstore-opt:
preallocate-bpf-maps:false
enable-service-topology:false
metrics:
tofqdns-idle-connection-grace-period:0s
encrypt-interface:
enable-bpf-clock-probe:false
cni-external-routing:false
local-router-ipv6:
k8s-api-server:
bpf-events-drop-enabled:true
bpf-lb-affinity-map-max:0
socket-path:/var/run/cilium/cilium.sock
bpf-lb-dsr-l4-xlate:frontend
monitor-aggregation-interval:5s
node-port-algorithm:random
policy-queue-size:100
dnsproxy-lock-count:131
trace-payloadlen:128
hubble-drop-events-reasons:auth_required,policy_denied
dnsproxy-socket-linger-timeout:10
bpf-lb-sock-terminate-pod-connections:false
enable-mke:false
enable-ipv4-egress-gateway:false
bpf-root:/sys/fs/bpf
bpf-ct-timeout-service-tcp-grace:1m0s
bpf-policy-map-max:16384
enable-active-connection-tracking:false
exclude-local-address:
synchronize-k8s-nodes:true
enable-pmtu-discovery:false
mtu:0
l2-announcements-renew-deadline:5s
bpf-filter-priority:1
auto-direct-node-routes:false
ipv4-pod-subnets:
kvstore-lease-ttl:15m0s
procfs:/host/proc
ipv6-range:auto
ipv4-range:auto
bgp-announce-pod-cidr:false
mesh-auth-rotated-identities-queue-size:1024
set-cilium-is-up-condition:true
bpf-ct-timeout-regular-any:1m0s
bpf-sock-rev-map-max:262144
mesh-auth-mutual-listener-port:0
vtep-mask:
enable-cilium-endpoint-slice:false
mesh-auth-spire-admin-socket:
proxy-portrange-max:20000
proxy-idle-timeout-seconds:60
ipv4-node:auto
routing-mode:tunnel
cluster-health-port:4240
enable-gateway-api:false
enable-ip-masq-agent:false
hubble-redact-kafka-apikey:false
enable-k8s-api-discovery:false
k8s-client-burst:20
k8s-service-proxy-name:
log-driver:
tofqdns-max-deferred-connection-deletes:10000
bgp-config-path:/var/lib/cilium/bgp/config.yaml
cgroup-root:/run/cilium/cgroupv2
use-full-tls-context:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
enable-xdp-prefilter:false
bypass-ip-availability-upon-restore:false
nodes-gc-interval:5m0s
enable-l2-announcements:false
l2-announcements-retry-period:2s
enable-endpoint-routes:false
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
enable-ipsec-encrypted-overlay:false
envoy-log:
hubble-redact-http-userinfo:true
disable-external-ip-mitigation:false
mesh-auth-signal-backoff-duration:1s
nat-map-stats-entries:32
restore:true
envoy-keep-cap-netbindservice:false
enable-l2-neigh-discovery:true
vtep-endpoint:
allow-localhost:auto
node-port-bind-protection:true
local-router-ipv4:
enable-ipv6-masquerade:true
wireguard-persistent-keepalive:0s
nat-map-stats-interval:30s
enable-auto-protect-node-port-range:true
bpf-lb-source-range-map-max:0
disable-iptables-feeder-rules:
enable-wireguard-userspace-fallback:false
derive-masq-ip-addr-from-device:
identity-change-grace-period:5s
encryption-strict-mode-allow-remote-node-identities:false
egress-multi-home-ip-rule-compat:false
enable-runtime-device-detection:true
bpf-lb-service-map-max:0
cni-exclusive:true
force-device-detection:false
container-ip-local-reserved-ports:auto
install-no-conntrack-iptables-rules:false
kvstore:
labels:
state-dir:/var/run/cilium
bgp-announce-lb-ip:false
monitor-queue-size:0
ipv4-service-loopback-address:169.254.42.1
enable-bbr:false
enable-health-check-nodeport:true
use-cilium-internal-ip-for-ipsec:false
enable-identity-mark:true
proxy-xff-num-trusted-hops-ingress:0
pprof-port:6060
enable-host-firewall:false
k8s-require-ipv4-pod-cidr:false
bpf-auth-map-max:524288
clustermesh-config:/var/lib/cilium/clustermesh/
hubble-export-file-max-size-mb:10
dns-policy-unload-on-shutdown:false
bpf-lb-rss-ipv4-src-cidr:
hubble-drop-events-interval:2m0s
bpf-nat-global-max:524288
enable-sctp:false
gops-port:9890
annotate-k8s-node:false
operator-prometheus-serve-addr::9963
bpf-ct-timeout-regular-tcp-syn:1m0s
log-system-load:false
kvstore-periodic-sync:5m0s
endpoint-queue-size:25
enable-hubble:true
enable-ipv6:false
enable-local-node-route:true
hubble-drop-events:false
cluster-pool-ipv4-cidr:10.48.0.0/16
enable-ipv4-big-tcp:false
k8s-service-cache-size:128
bpf-events-policy-verdict-enabled:true
bpf-neigh-global-max:524288
egress-masquerade-interfaces:ens+
auto-create-cilium-node-resource:true
cmdref:
proxy-max-requests-per-connection:0
l2-announcements-lease-duration:15s
allow-icmp-frag-needed:true
bpf-lb-service-backend-map-max:0
srv6-encap-mode:reduced
identity-restore-grace-period:30s
enable-cilium-api-server-access:
dnsproxy-concurrency-limit:0
envoy-base-id:0
ipam-multi-pool-pre-allocation:
vlan-bpf-bypass:
gateway-api-secrets-namespace:
bpf-events-trace-enabled:true
endpoint-bpf-prog-watchdog-interval:30s
enable-icmp-rules:true
bpf-ct-global-tcp-max:524288
allocator-list-timeout:3m0s
keep-config:false
mke-cgroup-mount:
cflags:
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
direct-routing-skip-unreachable:false
ipv6-pod-subnets:
arping-refresh-period:30s
enable-l2-pod-announcements:false
enable-health-checking:true
fqdn-regex-compile-lru-size:1024
enable-wireguard:false
proxy-connect-timeout:2
hubble-disable-tls:false
enable-local-redirect-policy:false
config-sources:config-map:kube-system/cilium-config
ipv6-mcast-device:
vtep-mac:
agent-liveness-update-interval:1s
label-prefix-file:
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
bpf-map-event-buffers:
tofqdns-dns-reject-response-code:refused
bpf-ct-timeout-regular-tcp-fin:10s
hubble-flowlogs-config-path:
bpf-lb-rev-nat-map-max:0
multicast-enabled:false
k8s-require-ipv6-pod-cidr:false
enable-ipip-termination:false
max-connected-clusters:255
hubble-export-file-path:
enable-ipv4:true
config-dir:/tmp/cilium/config-map
read-cni-conf:
enable-ipsec-key-watcher:true
cluster-id:49
config:
enable-ipsec:false
ipv6-cluster-alloc-cidr:f00d::/64
ipv6-native-routing-cidr:
mesh-auth-gc-interval:5m0s
k8s-sync-timeout:3m0s
kvstore-max-consecutive-quorum-errors:2
local-max-addr-scope:252
enable-ingress-controller:false
static-cnp-path:
hubble-export-denylist:
http-normalize-path:true
enable-tracing:false
enable-policy:default
enable-envoy-config:false
tofqdns-pre-cache:
dns-max-ips-per-restored-rule:1000
bpf-map-dynamic-size-ratio:0.0025
pprof-address:localhost
policy-cidr-match-mode:
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
devices:
hubble-redact-enabled:false
bpf-lb-sock-hostns-only:false
tofqdns-proxy-response-max-delay:100ms
fixed-identity-mapping:
bpf-ct-timeout-service-tcp:2h13m20s
enable-svc-source-range-check:true
ipam:cluster-pool
encrypt-node:false
hubble-redact-http-headers-deny:
policy-audit-mode:false
node-labels:
enable-srv6:false
enable-bpf-masquerade:false
monitor-aggregation-flags:all
identity-allocation-mode:crd
node-port-mode:snat
identity-gc-interval:15m0s
ipv6-node:auto
l2-pod-announcements-interface:
agent-health-port:9879
dnsproxy-enable-transparent-mode:true
endpoint-gc-interval:5m0s
cluster-pool-ipv4-mask-size:24
hubble-export-fieldmask:
bpf-fragments-map-max:8192
kvstore-connectivity-timeout:2m0s
http-max-grpc-timeout:0
mesh-auth-queue-size:1024
enable-monitor:true
bpf-lb-map-max:65536
bpf-lb-sock:false
mesh-auth-spiffe-trust-domain:spiffe.cilium
bpf-ct-timeout-regular-tcp:2h13m20s
version:false
install-iptables-rules:true
crd-wait-timeout:5m0s
ingress-secrets-namespace:
debug:false
external-envoy-proxy:true
ipsec-key-file:
enable-ipv6-big-tcp:false
clustermesh-sync-timeout:1m0s
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
cni-chaining-mode:none
api-rate-limit:
enable-session-affinity:false
enable-recorder:false
```


#### Service list

```
ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.142.171:443 (active)    
                                         2 => 172.31.202.193:443 (active)    
2    10.100.142.72:443    ClusterIP      1 => 172.31.149.115:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.48.0.220:53 (active)        
                                         2 => 10.48.0.164:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.48.0.220:9153 (active)      
                                         2 => 10.48.0.164:9153 (active)      
5    10.100.58.179:2379   ClusterIP      1 => 10.48.0.115:2379 (active)      
```

#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.48.0.0/24, 
Allocated addresses:
  10.48.0.115 (kube-system/clustermesh-apiserver-777566c59b-8zf6x)
  10.48.0.164 (kube-system/coredns-cc6ccd49c-pk99f)
  10.48.0.220 (kube-system/coredns-cc6ccd49c-hntvl)
  10.48.0.31 (health)
  10.48.0.47 (router)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 71a93cbdd2a4b02f
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    30s ago        never        0       no error   
  ct-map-pressure                                                     1s ago         never        0       no error   
  daemon-validate-config                                              17s ago        never        0       no error   
  dns-garbage-collector-job                                           33s ago        never        0       no error   
  endpoint-160-regeneration-recovery                                  never          never        0       no error   
  endpoint-2203-regeneration-recovery                                 never          never        0       no error   
  endpoint-389-regeneration-recovery                                  never          never        0       no error   
  endpoint-61-regeneration-recovery                                   never          never        0       no error   
  endpoint-846-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         4m33s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                1s ago         never        0       no error   
  ipcache-inject-labels                                               31s ago        never        0       no error   
  k8s-heartbeat                                                       4s ago         never        0       no error   
  link-cache                                                          1s ago         never        0       no error   
  local-identity-checkpoint                                           14m31s ago     never        0       no error   
  node-neighbor-link-updater                                          1s ago         never        0       no error   
  remote-etcd-cmesh1                                                  7m7s ago       never        0       no error   
  remote-etcd-cmesh10                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh100                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh101                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh102                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh103                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh104                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh105                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh106                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh107                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh108                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh109                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh11                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh110                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh111                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh112                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh113                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh114                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh115                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh116                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh117                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh118                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh119                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh12                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh120                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh121                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh122                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh123                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh124                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh125                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh126                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh127                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh128                                                7m7s ago       never        0       no error   
  remote-etcd-cmesh13                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh14                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh15                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh16                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh17                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh18                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh19                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh2                                                  7m7s ago       never        0       no error   
  remote-etcd-cmesh20                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh21                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh22                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh23                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh24                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh25                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh26                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh27                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh28                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh29                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh3                                                  7m7s ago       never        0       no error   
  remote-etcd-cmesh30                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh31                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh32                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh33                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh34                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh35                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh36                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh37                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh38                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh39                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh4                                                  7m7s ago       never        0       no error   
  remote-etcd-cmesh40                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh41                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh42                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh43                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh44                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh45                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh46                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh47                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh48                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh5                                                  7m7s ago       never        0       no error   
  remote-etcd-cmesh50                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh51                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh52                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh53                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh54                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh55                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh56                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh57                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh58                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh59                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh6                                                  7m7s ago       never        0       no error   
  remote-etcd-cmesh60                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh61                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh62                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh63                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh64                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh65                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh66                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh67                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh68                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh69                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh7                                                  7m7s ago       never        0       no error   
  remote-etcd-cmesh70                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh71                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh72                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh73                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh74                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh75                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh76                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh77                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh78                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh79                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh8                                                  7m7s ago       never        0       no error   
  remote-etcd-cmesh80                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh81                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh82                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh83                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh84                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh85                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh86                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh87                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh88                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh89                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh9                                                  7m7s ago       never        0       no error   
  remote-etcd-cmesh90                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh91                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh92                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh93                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh94                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh95                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh96                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh97                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh98                                                 7m7s ago       never        0       no error   
  remote-etcd-cmesh99                                                 7m7s ago       never        0       no error   
  resolve-identity-160                                                4m19s ago      never        0       no error   
  resolve-identity-2203                                               4m30s ago      never        0       no error   
  resolve-identity-389                                                4m29s ago      never        0       no error   
  resolve-identity-61                                                 4m31s ago      never        0       no error   
  resolve-identity-846                                                3m3s ago       never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-777566c59b-8zf6x   8m3s ago       never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-hntvl                  14m29s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-pk99f                  14m19s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      14m31s ago     never        0       no error   
  sync-policymap-160                                                  14m19s ago     never        0       no error   
  sync-policymap-2203                                                 14m26s ago     never        0       no error   
  sync-policymap-389                                                  14m26s ago     never        0       no error   
  sync-policymap-61                                                   14m30s ago     never        0       no error   
  sync-policymap-846                                                  8m3s ago       never        0       no error   
  sync-to-k8s-ciliumendpoint (160)                                    9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (389)                                    9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (846)                                    3s ago         never        0       no error   
  sync-utime                                                          31s ago        never        0       no error   
  write-cni-file                                                      14m33s ago     never        0       no error   
Proxy Status:            OK, ip 10.48.0.47, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 3211264, max 3276799
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 76.78   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
61         Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                
                                                           reserved:host                                                                                             
160        Disabled           Disabled          3216961    k8s:eks.amazonaws.com/component=coredns                                             10.48.0.164   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh49                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
389        Disabled           Disabled          3216961    k8s:eks.amazonaws.com/component=coredns                                             10.48.0.220   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh49                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
846        Disabled           Disabled          3263470    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.48.0.115   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh49                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
2203       Disabled           Disabled          4          reserved:health                                                                     10.48.0.31    ready   
```

#### BPF Policy Get 61

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 61

```
Invalid argument: unknown type 61
```


#### Endpoint Get 61

```
[
  {
    "id": 61,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-61-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "9cb25996-62f4-46fd-9a69-8c7eb7a954af"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-61",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:44.662Z",
            "success-count": 3
          },
          "uuid": "c1d04c37-9d86-4237-a41a-63e03c4320dd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-61",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:45.758Z",
            "success-count": 1
          },
          "uuid": "005c2a2c-db02-4e5b-83b0-e5a391ff34f6"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:10Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "1a:a9:2e:b7:64:90",
        "interface-name": "cilium_host",
        "mac": "1a:a9:2e:b7:64:90"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 61

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 61

```
Timestamp              Status   State                   Message
2024-10-25T10:22:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:10Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:14:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:48Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:14:47Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:47Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:14:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:14:46Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:44Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:44Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:44Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 160

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    80801   927       0        
Allow    Egress      0          ANY          NONE         disabled    14239   150       0        

```


#### BPF CT List 160

```
Invalid argument: unknown type 160
```


#### Endpoint Get 160

```
[
  {
    "id": 160,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-160-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "43d54909-17c4-4ae2-bb3d-1953ba6985d9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-160",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:56.018Z",
            "success-count": 3
          },
          "uuid": "eb2ec829-b3f6-4b6e-95b8-8e85d335ff79"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-pk99f",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:56.016Z",
            "success-count": 1
          },
          "uuid": "fded604e-ad6f-477e-9f72-0d41ec986e4d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-160",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:56.048Z",
            "success-count": 1
          },
          "uuid": "13930aa1-9be5-44d7-9af5-daa577d9b405"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (160)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:16.092Z",
            "success-count": 88
          },
          "uuid": "673e9a96-e8c5-4e09-b679-b8180ea177f2"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "67fe79e547d0113b4bbf6ddf55c34fcfc0223e22dc794fa6f0546890edff3aef:eth0",
        "container-id": "67fe79e547d0113b4bbf6ddf55c34fcfc0223e22dc794fa6f0546890edff3aef",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-pk99f",
        "pod-name": "kube-system/coredns-cc6ccd49c-pk99f"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3216961,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh49",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh49",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:10Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.48.0.164",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "9a:f6:59:b9:5f:d2",
        "interface-index": 14,
        "interface-name": "lxcf5b6b860ac3b",
        "mac": "ca:fd:d2:0c:60:5f"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3216961,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3216961,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 160

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 160

```
Timestamp              Status   State                   Message
2024-10-25T10:22:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:10Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:56Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:56Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:56Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3216961

```
ID        LABELS
3216961   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh49
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 389

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    82290   946       0        
Allow    Egress      0          ANY          NONE         disabled    13688   143       0        

```


#### BPF CT List 389

```
Invalid argument: unknown type 389
```


#### Endpoint Get 389

```
[
  {
    "id": 389,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-389-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c53c0856-41e8-4661-97a5-d9079c0871d5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-389",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:46.378Z",
            "success-count": 3
          },
          "uuid": "f42d9166-57af-455a-a4af-b767177c8ab9"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-hntvl",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:46.377Z",
            "success-count": 1
          },
          "uuid": "82d29ea8-b911-4f51-b647-e19c04f7d97f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-389",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:48.968Z",
            "success-count": 1
          },
          "uuid": "4bca9fe2-0bb2-4e8b-8555-261d046bf61c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (389)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:16.457Z",
            "success-count": 89
          },
          "uuid": "9a8b6afb-37fd-4d8f-b4ce-0ad3a0b984c1"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "23c9717461fdab82452444cf47b8f8ead3921b400306681bcb323a18caa74cc3:eth0",
        "container-id": "23c9717461fdab82452444cf47b8f8ead3921b400306681bcb323a18caa74cc3",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-hntvl",
        "pod-name": "kube-system/coredns-cc6ccd49c-hntvl"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3216961,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh49",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh49",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:10Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.48.0.220",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "56:db:39:ec:53:0d",
        "interface-index": 12,
        "interface-name": "lxc07c3ad53afe4",
        "mac": "aa:a7:ec:10:7e:3b"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3216961,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3216961,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 389

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 389

```
Timestamp              Status    State                   Message
2024-10-25T10:22:10Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:10Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:10Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:22:10Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:08Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:08Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:08Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:08Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:41Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:41Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:41Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:41Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:40Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:40Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:40Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:40Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:48Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:48Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:47Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:47Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:14:46Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:46Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:46Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:14:46Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:46Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 3216961

```
ID        LABELS
3216961   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh49
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 846

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3806167   36416     0        
Allow    Ingress     1          ANY          NONE         disabled    3409124   34747     0        
Allow    Egress      0          ANY          NONE         disabled    5430230   49970     0        

```


#### BPF CT List 846

```
Invalid argument: unknown type 846
```


#### Endpoint Get 846

```
[
  {
    "id": 846,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-846-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "6f512ad5-96c1-4fc3-8a83-6291e4069175"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-846",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:12.250Z",
            "success-count": 2
          },
          "uuid": "aa2a3d58-13ff-468f-9ac6-0b737d57dfb4"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-777566c59b-8zf6x",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:12.248Z",
            "success-count": 1
          },
          "uuid": "5230d1c0-73cf-42c4-b773-d359a733364c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-846",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:12.285Z",
            "success-count": 1
          },
          "uuid": "a643f308-3aff-4bde-9c53-88ef61df7e51"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (846)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:12.309Z",
            "success-count": 50
          },
          "uuid": "829aeb82-7dff-4035-8883-9df57fb22681"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "32fc4acb82bbe347a61649704289d031ead5e25bce185ea1ca1158234faf05f4:eth0",
        "container-id": "32fc4acb82bbe347a61649704289d031ead5e25bce185ea1ca1158234faf05f4",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-777566c59b-8zf6x",
        "pod-name": "kube-system/clustermesh-apiserver-777566c59b-8zf6x"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3263470,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh49",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=777566c59b"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh49",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:10Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.48.0.115",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "e6:98:db:9c:78:0b",
        "interface-index": 18,
        "interface-name": "lxc53f9f3f817da",
        "mac": "32:25:9c:75:04:5b"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3263470,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3263470,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 846

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 846

```
Timestamp              Status   State                   Message
2024-10-25T10:22:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:10Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:12Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:12Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:12Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3263470

```
ID        LABELS
3263470   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh49
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 2203

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    434825   5553      0        
Allow    Ingress     1          ANY          NONE         disabled    12136    142       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 2203

```
Invalid argument: unknown type 2203
```


#### Endpoint Get 2203

```
[
  {
    "id": 2203,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2203-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7c98fac2-4bde-41ce-bcdb-ce75a9f7acd5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2203",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:45.749Z",
            "success-count": 3
          },
          "uuid": "367468aa-a1ba-4106-8be8-b9be09e0bb81"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2203",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:48.973Z",
            "success-count": 1
          },
          "uuid": "2695dfa8-091a-4d58-84ce-cc2ff0892ae2"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:10Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.48.0.31",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "2e:21:f0:fa:c6:a5",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "06:21:3e:d0:56:fb"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2203

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2203

```
Timestamp              Status   State                   Message
2024-10-25T10:22:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:10Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:48Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:48Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:47Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:14:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:45Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:45Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:44Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Policy get

```
:
 []
Revision: 1

```


#### Cilium encryption


