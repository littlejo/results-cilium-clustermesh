Node 0, zone      DMA      1      0      3      2      1      4      4      2      2      3    166 
Node 0, zone   Normal    349     52     23     21     17      8      2      1      2      1      8 
