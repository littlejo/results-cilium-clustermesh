Total: 536
TCP:   1065 (estab 288, closed 757, orphaned 1, timewait 301)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  308       299       9        
INET	  318       305       13       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.149.115%ens5:68         0.0.0.0:*    uid:192 ino:15815 sk:259 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:24730 sk:25a cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15553 sk:25b cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:41733      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:24656 sk:25c fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:24729 sk:25d cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15554 sk:25e cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::465:3dff:fee5:fd19]%ens5:546           [::]:*    uid:192 ino:15813 sk:25f cgroup:unreachable:c4e v6only:1 <->                   
