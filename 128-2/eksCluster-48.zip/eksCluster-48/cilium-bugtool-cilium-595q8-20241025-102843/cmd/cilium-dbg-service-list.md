ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.142.171:443 (active)    
                                         2 => 172.31.202.193:443 (active)    
2    10.100.142.72:443    ClusterIP      1 => 172.31.149.115:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.48.0.220:53 (active)        
                                         2 => 10.48.0.164:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.48.0.220:9153 (active)      
                                         2 => 10.48.0.164:9153 (active)      
5    10.100.58.179:2379   ClusterIP      1 => 10.48.0.115:2379 (active)      
