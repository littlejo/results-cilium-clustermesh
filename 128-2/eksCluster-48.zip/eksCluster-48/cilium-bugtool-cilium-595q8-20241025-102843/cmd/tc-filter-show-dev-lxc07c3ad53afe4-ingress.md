filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc07c3ad53afe4 direct-action not_in_hw id 530 tag 456b31a8fa2c27a6 jited 
