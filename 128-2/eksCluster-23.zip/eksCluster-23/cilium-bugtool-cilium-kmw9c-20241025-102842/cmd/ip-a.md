1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:57:68:4d:17:69 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.206.64/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2633sec preferred_lft 2633sec
    inet6 fe80::857:68ff:fe4d:1769/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:df:c5:f7:fd:eb brd ff:ff:ff:ff:ff:ff
    inet6 fe80::58df:c5ff:fef7:fdeb/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:77:da:82:f1:70 brd ff:ff:ff:ff:ff:ff
    inet 10.23.0.5/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::877:daff:fe82:f170/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether d2:51:cb:78:3e:df brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d051:cbff:fe78:3edf/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:7f:01:0d:63:13 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::907f:1ff:fe0d:6313/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc59136785e048@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:41:83:d7:89:ce brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::d041:83ff:fed7:89ce/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc590713cb6aa5@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:ed:fb:43:21:c0 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::5ced:fbff:fe43:21c0/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc9c4bd045d82e@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:05:d0:b1:28:db brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::ac05:d0ff:feb1:28db/64 scope link 
       valid_lft forever preferred_lft forever
