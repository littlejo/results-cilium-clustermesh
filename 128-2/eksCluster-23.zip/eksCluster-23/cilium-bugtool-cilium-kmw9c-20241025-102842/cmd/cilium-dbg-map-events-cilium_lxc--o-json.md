{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:17.077Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.206.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:17.077Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:20.154Z",
  "value": "id=827   sec_id=1589556 flags=0x0000 ifindex=9   mac=CE:7B:DB:9E:E3:D8 nodemac=D2:41:83:D7:89:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:23.380Z",
  "value": "id=1345  sec_id=4     flags=0x0000 ifindex=7   mac=B2:A6:31:A5:7A:CC nodemac=92:7F:01:0D:63:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:23.382Z",
  "value": "id=1287  sec_id=1589556 flags=0x0000 ifindex=11  mac=86:B0:7D:90:7B:43 nodemac=5E:ED:FB:43:21:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:23.450Z",
  "value": "id=827   sec_id=1589556 flags=0x0000 ifindex=9   mac=CE:7B:DB:9E:E3:D8 nodemac=D2:41:83:D7:89:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:23.488Z",
  "value": "id=1345  sec_id=4     flags=0x0000 ifindex=7   mac=B2:A6:31:A5:7A:CC nodemac=92:7F:01:0D:63:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:23.532Z",
  "value": "id=1287  sec_id=1589556 flags=0x0000 ifindex=11  mac=86:B0:7D:90:7B:43 nodemac=5E:ED:FB:43:21:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:41.822Z",
  "value": "id=827   sec_id=1589556 flags=0x0000 ifindex=9   mac=CE:7B:DB:9E:E3:D8 nodemac=D2:41:83:D7:89:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:41.822Z",
  "value": "id=1287  sec_id=1589556 flags=0x0000 ifindex=11  mac=86:B0:7D:90:7B:43 nodemac=5E:ED:FB:43:21:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:41.822Z",
  "value": "id=1345  sec_id=4     flags=0x0000 ifindex=7   mac=B2:A6:31:A5:7A:CC nodemac=92:7F:01:0D:63:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:41.855Z",
  "value": "id=1923  sec_id=1592160 flags=0x0000 ifindex=13  mac=F6:54:F7:96:99:B1 nodemac=36:E2:FA:8A:70:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:42.822Z",
  "value": "id=1345  sec_id=4     flags=0x0000 ifindex=7   mac=B2:A6:31:A5:7A:CC nodemac=92:7F:01:0D:63:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:42.822Z",
  "value": "id=827   sec_id=1589556 flags=0x0000 ifindex=9   mac=CE:7B:DB:9E:E3:D8 nodemac=D2:41:83:D7:89:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:42.823Z",
  "value": "id=1923  sec_id=1592160 flags=0x0000 ifindex=13  mac=F6:54:F7:96:99:B1 nodemac=36:E2:FA:8A:70:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:42.823Z",
  "value": "id=1287  sec_id=1589556 flags=0x0000 ifindex=11  mac=86:B0:7D:90:7B:43 nodemac=5E:ED:FB:43:21:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:28.643Z",
  "value": "id=3610  sec_id=1592160 flags=0x0000 ifindex=15  mac=DA:DF:73:A0:AC:D1 nodemac=AE:05:D0:B1:28:DB"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.23.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:39.197Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:39.470Z",
  "value": "id=1345  sec_id=4     flags=0x0000 ifindex=7   mac=B2:A6:31:A5:7A:CC nodemac=92:7F:01:0D:63:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:39.470Z",
  "value": "id=3610  sec_id=1592160 flags=0x0000 ifindex=15  mac=DA:DF:73:A0:AC:D1 nodemac=AE:05:D0:B1:28:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:39.471Z",
  "value": "id=827   sec_id=1589556 flags=0x0000 ifindex=9   mac=CE:7B:DB:9E:E3:D8 nodemac=D2:41:83:D7:89:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:39.471Z",
  "value": "id=1287  sec_id=1589556 flags=0x0000 ifindex=11  mac=86:B0:7D:90:7B:43 nodemac=5E:ED:FB:43:21:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:40.470Z",
  "value": "id=3610  sec_id=1592160 flags=0x0000 ifindex=15  mac=DA:DF:73:A0:AC:D1 nodemac=AE:05:D0:B1:28:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:40.471Z",
  "value": "id=827   sec_id=1589556 flags=0x0000 ifindex=9   mac=CE:7B:DB:9E:E3:D8 nodemac=D2:41:83:D7:89:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:40.471Z",
  "value": "id=1287  sec_id=1589556 flags=0x0000 ifindex=11  mac=86:B0:7D:90:7B:43 nodemac=5E:ED:FB:43:21:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:40.471Z",
  "value": "id=1345  sec_id=4     flags=0x0000 ifindex=7   mac=B2:A6:31:A5:7A:CC nodemac=92:7F:01:0D:63:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:41.470Z",
  "value": "id=1345  sec_id=4     flags=0x0000 ifindex=7   mac=B2:A6:31:A5:7A:CC nodemac=92:7F:01:0D:63:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:41.470Z",
  "value": "id=827   sec_id=1589556 flags=0x0000 ifindex=9   mac=CE:7B:DB:9E:E3:D8 nodemac=D2:41:83:D7:89:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:41.471Z",
  "value": "id=3610  sec_id=1592160 flags=0x0000 ifindex=15  mac=DA:DF:73:A0:AC:D1 nodemac=AE:05:D0:B1:28:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:41.471Z",
  "value": "id=1287  sec_id=1589556 flags=0x0000 ifindex=11  mac=86:B0:7D:90:7B:43 nodemac=5E:ED:FB:43:21:C0"
}

