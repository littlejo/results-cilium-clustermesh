Node 0, zone      DMA      5      6      4      4     10      9      8      7      6      6    222 
Node 0, zone   Normal     48    135     15     45     24    102     41     18      5      5     39 
