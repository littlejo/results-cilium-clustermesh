CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5bf4b93b_1785_4d33_9304_44cc88937f18.slice/cri-containerd-5f3c501494340af87bbc70d48ec881f031fb1c82124ecaf5f7f0112cadcf9aae.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5bf4b93b_1785_4d33_9304_44cc88937f18.slice/cri-containerd-37cc7aaeee898a9a94d2d619655d197a679c8906d5c6067a6ef2922c0c55552a.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e7aa56a_6586_41db_9f78_751090521f40.slice/cri-containerd-9cfcaa1b851585c40cbf6bcdebb5735904ed082c83f4f33ca817c31abe063985.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e7aa56a_6586_41db_9f78_751090521f40.slice/cri-containerd-049eda9c037b218f645777b03bda6a0c732aafa95c445e859a0735ac7d34b013.scope
    67       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1a450312_9f8a_4d8d_bca6_f663d2783670.slice/cri-containerd-33afbbcf0ff2de8a6510a540a90aec41d9891624a10e8a9c18de113f84548c1a.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1a450312_9f8a_4d8d_bca6_f663d2783670.slice/cri-containerd-b84882b633a77aceeacb2275205eddbeed51ef34225832b56b3981cf2a0ad82d.scope
    517      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9e92a080_8f57_4fa3_b53b_74197c211c83.slice/cri-containerd-90e722a63112b7bb00c3c5bda2a7b57d112400959a55c40d27274d6732baa1f7.scope
    461      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9e92a080_8f57_4fa3_b53b_74197c211c83.slice/cri-containerd-a4595541fd5390b777f18c7e3b286cfce07d2e83e6215ef22010ba3002dc434e.scope
    469      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9e9dc214_3c3a_4be8_94de_25b5fcbe5a1b.slice/cri-containerd-badb81870af312e41222792f9b18b2ae22229d36f76bf924ca41d3f95b5c45f5.scope
    64       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9e9dc214_3c3a_4be8_94de_25b5fcbe5a1b.slice/cri-containerd-813424b7d80b906363c2a62a011786e9087e8407bca6e84924b460857d655b92.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36f0482d_5529_4e24_8e39_68e222d4c9c6.slice/cri-containerd-938f63c59f65576d859770102976df2627a9ca4a0db5de09de3a061895e96e67.scope
    627      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36f0482d_5529_4e24_8e39_68e222d4c9c6.slice/cri-containerd-544a8e41e50292ecbda582315361e244a97c8e8b00ce5da92b52c0c4dae0f4f7.scope
    631      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36f0482d_5529_4e24_8e39_68e222d4c9c6.slice/cri-containerd-fc894e0552e5c371c26d0361101404751250dc2a5e50f0a1eae954415c8bef60.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36f0482d_5529_4e24_8e39_68e222d4c9c6.slice/cri-containerd-d74bbc2a17427dd042544a3e7b681fb92d7518692c5a15b8f10e5a7e7fa5c1b3.scope
    607      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6d1781a2_5b1c_4a06_92a6_f915673a034a.slice/cri-containerd-47bde6eadda6199d5faea1d0a995ad0aca1d75ea106ce56b8e6c00a8b56879e7.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6d1781a2_5b1c_4a06_92a6_f915673a034a.slice/cri-containerd-5dcfaf1354e67d7a628df4c21525ce80ae4be63c178e230e010249a06d798c03.scope
    71       cgroup_device   multi                                          
