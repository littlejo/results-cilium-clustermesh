KEY             VALUE
AgentLiveness   1008635520508
UTimeOffset     3378615517578125
