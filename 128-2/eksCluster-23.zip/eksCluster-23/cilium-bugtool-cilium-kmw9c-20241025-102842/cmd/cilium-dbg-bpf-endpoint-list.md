IP ADDRESS        LOCAL ENDPOINT INFO
10.23.0.202:0     id=1345  sec_id=4     flags=0x0000 ifindex=7   mac=B2:A6:31:A5:7A:CC nodemac=92:7F:01:0D:63:13     
172.31.206.64:0   (localhost)                                                                                        
10.23.0.92:0      id=827   sec_id=1589556 flags=0x0000 ifindex=9   mac=CE:7B:DB:9E:E3:D8 nodemac=D2:41:83:D7:89:CE   
10.23.0.221:0     id=1287  sec_id=1589556 flags=0x0000 ifindex=11  mac=86:B0:7D:90:7B:43 nodemac=5E:ED:FB:43:21:C0   
10.23.0.5:0       (localhost)                                                                                        
10.23.0.174:0     id=3610  sec_id=1592160 flags=0x0000 ifindex=15  mac=DA:DF:73:A0:AC:D1 nodemac=AE:05:D0:B1:28:DB   
