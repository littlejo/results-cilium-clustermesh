Endpoint ID: 827
Path: /sys/fs/bpf/tc/globals/cilium_policy_00827

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    89859   1035      0        
Allow    Egress      0          ANY          NONE         disabled    15188   161       0        


Endpoint ID: 1287
Path: /sys/fs/bpf/tc/globals/cilium_policy_01287

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    88064   1005      0        
Allow    Egress      0          ANY          NONE         disabled    14233   150       0        


Endpoint ID: 1345
Path: /sys/fs/bpf/tc/globals/cilium_policy_01345

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    437494   5587      0        
Allow    Ingress     1          ANY          NONE         disabled    13168    154       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1843
Path: /sys/fs/bpf/tc/globals/cilium_policy_01843

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3610
Path: /sys/fs/bpf/tc/globals/cilium_policy_03610

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3836778   36545     0        
Allow    Ingress     1          ANY          NONE         disabled    3841746   37700     0        
Allow    Egress      0          ANY          NONE         disabled    5149522   47414     0        


