alloc: 85.23MB (89370936 bytes)
total-alloc: 1.46GB (1567936568 bytes)
sys: 214.63MB (225060180 bytes)
lookups: 0
mallocs: 49588680
frees: 48792562
heap-alloc: 85.23MB (89370936 bytes)
heap-sys: 167.98MB (176136192 bytes)
heap-idle: 45.84MB (48070656 bytes)
heap-in-use: 122.13MB (128065536 bytes)
heap-released: 504.00KB (516096 bytes)
heap-objects: 796118
stack-in-use: 36.00MB (37748736 bytes)
stack-sys: 36.00MB (37748736 bytes)
stack-mspan-inuse: 2.06MB (2159680 bytes)
stack-mspan-sys: 2.66MB (2790720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 917.97KB (940001 bytes)
gc-sys: 5.16MB (5413240 bytes)
next-gc: when heap-alloc >= 146.22MB (153326216 bytes)
last-gc: 2024-10-25 10:28:53.117376534 +0000 UTC
gc-pause-total: 19.216567ms
gc-pause: 73823
gc-pause-end: 1729852133117376534
num-gc: 75
num-forced-gc: 0
gc-cpu-fraction: 0.00036930487627216067
enable-gc: true
debug-gc: false
