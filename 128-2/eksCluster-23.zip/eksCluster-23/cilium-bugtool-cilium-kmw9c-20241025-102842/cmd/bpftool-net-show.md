xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 547
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 543
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 538
cilium_host(4) clsact/egress cil_from_host-cilium_host id 535
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 463
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 464
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 506
lxc59136785e048(9) clsact/ingress cil_from_container-lxc59136785e048 id 499
lxc590713cb6aa5(11) clsact/ingress cil_from_container-lxc590713cb6aa5 id 527
lxc9c4bd045d82e(15) clsact/ingress cil_from_container-lxc9c4bd045d82e id 601

flow_dissector:

netfilter:

