REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     10233     800531      677    bpf_overlay.c
Interface                 INGRESS     236234    102767733   1132   bpf_host.c
Success                   EGRESS      105137    13864056    1308   bpf_lxc.c
Success                   EGRESS      10540     821727      53     encap.h
Success                   EGRESS      5322      409023      1694   bpf_host.c
Success                   INGRESS     116508    14397795    86     l3.h
Success                   INGRESS     122068    14833209    235    trace.h
Unsupported L3 protocol   EGRESS      37        2762        1492   bpf_lxc.c
