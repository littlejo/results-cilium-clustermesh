key: 3b 03 00 00  value: f1 01 00 00
key: 07 05 00 00  value: 06 02 00 00
key: 41 05 00 00  value: f7 01 00 00
key: 1a 0e 00 00  value: 58 02 00 00
Found 4 elements
