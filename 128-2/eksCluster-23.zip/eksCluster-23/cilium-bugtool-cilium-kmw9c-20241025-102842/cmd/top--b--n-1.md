top - 10:28:43 up 16 min,  0 users,  load average: 0.09, 0.16, 0.16
Tasks:   7 total,   3 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 46.7 us, 46.7 sy,  0.0 ni,  6.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1161.9 free,    917.8 used,   1756.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2750.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538356 290804  78276 S  40.0   7.4   0:28.81 cilium-+
    392 root      20   0 1228848   5964   2864 S   0.0   0.2   0:00.26 cilium-+
    656 root      20   0 1240432  15832  10832 R   0.0   0.4   0:00.03 cilium-+
    691 root      20   0    6576   2424   2100 R   0.0   0.1   0:00.00 top
    695 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    700 root      20   0 1228744   3660   2976 S   0.0   0.1   0:00.00 gops
    732 root      20   0    3728    488    436 R   0.0   0.0   0:00.00 bash
