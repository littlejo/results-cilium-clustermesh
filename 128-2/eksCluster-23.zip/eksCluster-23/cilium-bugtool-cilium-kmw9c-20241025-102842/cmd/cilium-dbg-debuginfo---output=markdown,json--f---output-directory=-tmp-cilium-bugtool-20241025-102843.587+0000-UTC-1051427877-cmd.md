markdown output at /tmp/cilium-bugtool-20241025-102843.587+0000-UTC-1051427877/cmd/cilium-debuginfo-20241025-102914.295+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102843.587+0000-UTC-1051427877/cmd/cilium-debuginfo-20241025-102914.295+0000-UTC.json
