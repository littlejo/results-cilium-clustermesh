ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.155.236:443 (active)   
                                          2 => 172.31.223.128:443 (active)   
2    10.100.201.114:443    ClusterIP      1 => 172.31.206.64:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.23.0.92:53 (active)        
                                          2 => 10.23.0.221:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.23.0.92:9153 (active)      
                                          2 => 10.23.0.221:9153 (active)     
5    10.100.232.162:2379   ClusterIP      1 => 10.23.0.174:2379 (active)     
