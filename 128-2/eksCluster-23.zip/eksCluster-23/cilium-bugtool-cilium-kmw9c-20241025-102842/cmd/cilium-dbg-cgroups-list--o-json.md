[
  {
    "containers": [
      {
        "cgroup-id": 6858,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1a450312_9f8a_4d8d_bca6_f663d2783670.slice/cri-containerd-33afbbcf0ff2de8a6510a540a90aec41d9891624a10e8a9c18de113f84548c1a.scope"
      }
    ],
    "ips": [
      "10.23.0.221"
    ],
    "name": "coredns-cc6ccd49c-szcdc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8286,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36f0482d_5529_4e24_8e39_68e222d4c9c6.slice/cri-containerd-938f63c59f65576d859770102976df2627a9ca4a0db5de09de3a061895e96e67.scope"
      },
      {
        "cgroup-id": 8202,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36f0482d_5529_4e24_8e39_68e222d4c9c6.slice/cri-containerd-fc894e0552e5c371c26d0361101404751250dc2a5e50f0a1eae954415c8bef60.scope"
      },
      {
        "cgroup-id": 8370,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36f0482d_5529_4e24_8e39_68e222d4c9c6.slice/cri-containerd-544a8e41e50292ecbda582315361e244a97c8e8b00ce5da92b52c0c4dae0f4f7.scope"
      }
    ],
    "ips": [
      "10.23.0.174"
    ],
    "name": "clustermesh-apiserver-55b457c4d-kmvdj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6690,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9e92a080_8f57_4fa3_b53b_74197c211c83.slice/cri-containerd-a4595541fd5390b777f18c7e3b286cfce07d2e83e6215ef22010ba3002dc434e.scope"
      }
    ],
    "ips": [
      "10.23.0.92"
    ],
    "name": "coredns-cc6ccd49c-bgmf4",
    "namespace": "kube-system"
  }
]

