key: 05 00 00 00  value: 0a 17 00 dd 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f ce 40 10 94 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 9b ec 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 17 00 dd 23 c1 00 00  00 00 00 00
key: 07 00 00 00  value: ac 1f df 80 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 17 00 ae 09 4b 00 00  00 00 00 00
key: 04 00 00 00  value: 0a 17 00 5c 23 c1 00 00  00 00 00 00
key: 03 00 00 00  value: 0a 17 00 5c 00 35 00 00  00 00 00 00
Found 8 elements
