fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxc59136785e048 proto kernel metric 256 pref medium
fe80::/64 dev lxc590713cb6aa5 proto kernel metric 256 pref medium
fe80::/64 dev lxc9c4bd045d82e proto kernel metric 256 pref medium
