markdown output at /tmp/cilium-bugtool-20241025-102845.98+0000-UTC-769744832/cmd/cilium-debuginfo-20241025-102916.043+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102845.98+0000-UTC-769744832/cmd/cilium-debuginfo-20241025-102916.043+0000-UTC.json
