alloc: 89.58MB (93935432 bytes)
total-alloc: 1.35GB (1446237544 bytes)
sys: 210.76MB (220996948 bytes)
lookups: 0
mallocs: 47965667
frees: 47312777
heap-alloc: 89.58MB (93935432 bytes)
heap-sys: 165.39MB (173424640 bytes)
heap-idle: 38.59MB (40460288 bytes)
heap-in-use: 126.80MB (132964352 bytes)
heap-released: 2.50MB (2621440 bytes)
heap-objects: 652890
stack-in-use: 34.56MB (36241408 bytes)
stack-sys: 34.56MB (36241408 bytes)
stack-mspan-inuse: 1.99MB (2089120 bytes)
stack-mspan-sys: 2.57MB (2692800 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.05MB (1104473 bytes)
gc-sys: 5.28MB (5533856 bytes)
next-gc: when heap-alloc >= 148.97MB (156208152 bytes)
last-gc: 2024-10-25 10:29:08.842415503 +0000 UTC
gc-pause-total: 12.376513ms
gc-pause: 256912
gc-pause-end: 1729852148842415503
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.0003015332025950509
enable-gc: true
debug-gc: false
