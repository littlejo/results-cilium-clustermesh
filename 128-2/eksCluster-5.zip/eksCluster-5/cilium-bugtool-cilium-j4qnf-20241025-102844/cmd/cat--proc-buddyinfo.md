Node 0, zone      DMA      2      3      2      0      7     11      5      2      3      3    167 
Node 0, zone   Normal    173     28     17     10      4     10      8      2      2      1      8 
