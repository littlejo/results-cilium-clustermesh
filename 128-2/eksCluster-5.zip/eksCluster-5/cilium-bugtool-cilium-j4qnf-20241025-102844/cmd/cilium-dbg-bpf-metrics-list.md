REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10137     792716     677    bpf_overlay.c
Interface                 INGRESS     217866    99961351   1132   bpf_host.c
Success                   EGRESS      10299     806483     53     encap.h
Success                   EGRESS      5262      404538     1694   bpf_host.c
Success                   EGRESS      89317     12084477   1308   bpf_lxc.c
Success                   INGRESS     101349    12298549   86     l3.h
Success                   INGRESS     106873    12730633   235    trace.h
Unsupported L3 protocol   EGRESS      40        3012       1492   bpf_lxc.c
