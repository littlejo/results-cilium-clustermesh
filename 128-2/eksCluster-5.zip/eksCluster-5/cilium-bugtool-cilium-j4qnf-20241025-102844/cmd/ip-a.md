1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:8d:6e:10:7e:7f brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.239.114/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2679sec preferred_lft 2679sec
    inet6 fe80::88d:6eff:fe10:7e7f/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:3e:b9:ec:6c:ad brd ff:ff:ff:ff:ff:ff
    inet6 fe80::743e:b9ff:feec:6cad/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:07:49:1e:07:82 brd ff:ff:ff:ff:ff:ff
    inet 10.5.0.166/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a807:49ff:fe1e:782/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 1e:43:b3:b9:fd:f3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1c43:b3ff:feb9:fdf3/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:16:4a:06:74:97 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::2416:4aff:fe06:7497/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc80522580316f@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:2a:73:a8:8b:c2 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::242a:73ff:fea8:8bc2/64 scope link 
       valid_lft forever preferred_lft forever
11: lxcf3b338791708@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:e9:00:5e:0f:13 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::bce9:ff:fe5e:f13/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc08b6b9e1e3e7@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:d3:81:1c:20:b1 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::20d3:81ff:fe1c:20b1/64 scope link 
       valid_lft forever preferred_lft forever
