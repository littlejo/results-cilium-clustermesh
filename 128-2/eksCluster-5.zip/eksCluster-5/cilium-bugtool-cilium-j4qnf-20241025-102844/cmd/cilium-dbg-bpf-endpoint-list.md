IP ADDRESS         LOCAL ENDPOINT INFO
10.5.0.156:0       id=508   sec_id=447746 flags=0x0000 ifindex=11  mac=FE:BC:C5:67:42:1C nodemac=BE:E9:00:5E:0F:13   
10.5.0.101:0       id=3170  sec_id=447746 flags=0x0000 ifindex=9   mac=C2:C6:58:94:C5:D6 nodemac=26:2A:73:A8:8B:C2   
10.5.0.166:0       (localhost)                                                                                       
10.5.0.90:0        id=93    sec_id=399993 flags=0x0000 ifindex=15  mac=86:0E:D0:8A:69:E3 nodemac=22:D3:81:1C:20:B1   
172.31.239.114:0   (localhost)                                                                                       
10.5.0.44:0        id=168   sec_id=4     flags=0x0000 ifindex=7   mac=2E:23:55:39:9A:6E nodemac=26:16:4A:06:74:97    
