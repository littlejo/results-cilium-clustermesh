CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf379aad_ea9f_41fb_bd24_a2139efed1c0.slice/cri-containerd-e840d9484c1585d5697cbe52fd528b7c836e0be50413ca8a48a27a1aac56aca0.scope
    562      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf379aad_ea9f_41fb_bd24_a2139efed1c0.slice/cri-containerd-8a64496ac73cd1e6948e9da6939998600861fec07206bfe3ab151535642aa02a.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod35e72107_17d7_40e2_ac85_30e380fde51c.slice/cri-containerd-0de35443597a1ba00551f2b646a50a65658cc10e907419a65554baa661d8f4a4.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod35e72107_17d7_40e2_ac85_30e380fde51c.slice/cri-containerd-58c65e728f49a71b725250905561c0e51640961119281db0637ed55389ebd784.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfc33fe78_9acf_4e39_979e_d4e2906901fe.slice/cri-containerd-833c0463e9becb93a5d75da6d8547c9b06860457dc59f5f982489a75109d6bd7.scope
    120      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfc33fe78_9acf_4e39_979e_d4e2906901fe.slice/cri-containerd-0f7dbfa0b45121f44536bcbe9673086a0db4c246bd383b1530ac6ecdd7e6bb9d.scope
    74       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod340451b3_ed74_4860_a71b_c89bc4c8fda9.slice/cri-containerd-37d56c266b3b4874233b133cf839cb534a1b4c3fe24f7b14e20ea2f82bb6e1f2.scope
    566      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod340451b3_ed74_4860_a71b_c89bc4c8fda9.slice/cri-containerd-15b109b3a8fe6b7d6f3a10a881ea249387cbbb3f6a578df4af70f675f8e13f24.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podabec1b9f_ca86_4567_ab95_fb44eb57d623.slice/cri-containerd-9f56250e4fd9348ab3486907e514fea025d5a781bb85996ef2a140ee644a59a6.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podabec1b9f_ca86_4567_ab95_fb44eb57d623.slice/cri-containerd-b87e4953bd0a48d2c261664a524f1b287f5506739c9ea02f0e009f4df2418466.scope
    82       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podece5b838_51b8_43cb_9e79_bddc36ebbbb6.slice/cri-containerd-47335126fff05a0d6c01274ff0df976c429b7cc4f3819bb7ab4d657af862ca3d.scope
    86       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podece5b838_51b8_43cb_9e79_bddc36ebbbb6.slice/cri-containerd-2088dad6c62ce985dca0f19ccea3cf6119179cfd092bcd36d63ab50aace02295.scope
    70       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod03c5525b_3b9f_4eb1_b4c6_28af559e2cd3.slice/cri-containerd-a1b0d238dcc026145dc0013c863afc24e33744410000447fc0d9aa67d5f4a84a.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod03c5525b_3b9f_4eb1_b4c6_28af559e2cd3.slice/cri-containerd-4070651b7b2c2bf5849e264d0a1b3f56eb6e8f9f2ceebf88a9c94945d0e0b016.scope
    636      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod03c5525b_3b9f_4eb1_b4c6_28af559e2cd3.slice/cri-containerd-86e80971eabdac2f05c1c9fcce8e3000c5e4b68528f75fc08e427e64474fc788.scope
    644      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod03c5525b_3b9f_4eb1_b4c6_28af559e2cd3.slice/cri-containerd-1ad3f67e6a82858d3dea24322096c23fb3cf72e9397fa13fcf612a51b622711b.scope
    620      cgroup_device   multi                                          
