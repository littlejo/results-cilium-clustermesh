ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.184.62:443 (active)     
                                          2 => 172.31.230.86:443 (active)     
2    10.100.246.85:443     ClusterIP      1 => 172.31.239.114:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.5.0.101:9153 (active)       
                                          2 => 10.5.0.156:9153 (active)       
4    10.100.0.10:53        ClusterIP      1 => 10.5.0.101:53 (active)         
                                          2 => 10.5.0.156:53 (active)         
5    10.100.204.174:2379   ClusterIP      1 => 10.5.0.90:2379 (active)        
