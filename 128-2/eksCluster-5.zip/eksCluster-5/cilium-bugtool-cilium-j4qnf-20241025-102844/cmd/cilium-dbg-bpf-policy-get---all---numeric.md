Endpoint ID: 93
Path: /sys/fs/bpf/tc/globals/cilium_policy_00093

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3858503   35867     0        
Allow    Ingress     1          ANY          NONE         disabled    3057622   30741     0        
Allow    Egress      0          ANY          NONE         disabled    4048962   37715     0        


Endpoint ID: 168
Path: /sys/fs/bpf/tc/globals/cilium_policy_00168

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    433084   5536      0        
Allow    Ingress     1          ANY          NONE         disabled    12984    152       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 508
Path: /sys/fs/bpf/tc/globals/cilium_policy_00508

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    84241   964       0        
Allow    Egress      0          ANY          NONE         disabled    13909   147       0        


Endpoint ID: 625
Path: /sys/fs/bpf/tc/globals/cilium_policy_00625

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3170
Path: /sys/fs/bpf/tc/globals/cilium_policy_03170

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    85460   986       0        
Allow    Egress      0          ANY          NONE         disabled    13986   146       0        


