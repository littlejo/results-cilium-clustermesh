35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:17+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:17+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:18+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:18+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:18+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:18+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:18+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:34+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
67: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
70: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
71: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
74: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
79: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
82: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
83: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
86: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
117: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
120: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
461: sched_cls  name tail_handle_ipv4  tag 066e78b835ccd9cc  gpl
	loaded_at 2024-10-25T10:14:08+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 71,70,77,72,93
	btf_id 114
462: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:14:08+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 72,93
	btf_id 115
463: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:14:08+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 116
464: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:14:08+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 117
487: sched_cls  name tail_ipv4_ct_ingress  tag 05646d497dadb1a8  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,104,78,79,105,80
	btf_id 145
489: sched_cls  name tail_ipv4_ct_egress  tag 8f692e5b828b787b  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,104,78,79,105,80
	btf_id 147
493: sched_cls  name tail_handle_ipv4_cont  tag 6725b7d8c71ded5c  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,105,37,101,78,79,35,72,70,73,104,36,33,34,77
	btf_id 149
494: sched_cls  name cil_from_container  tag 2c88b62ed00c7a88  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 104,72
	btf_id 153
495: sched_cls  name tail_handle_arp  tag d8e07c1ce4814b7b  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,104
	btf_id 154
498: sched_cls  name handle_policy  tag f35788bd3700c35b  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,104,78,79,105,37,76,101,35,80,71,36,33,34
	btf_id 156
499: sched_cls  name __send_drop_notify  tag 8ff5f48b14c3dc38  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 158
502: sched_cls  name tail_ipv4_to_endpoint  tag 08c492f8dc090790  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,105,37,78,79,76,101,35,104,36,33,34
	btf_id 159
506: sched_cls  name __send_drop_notify  tag fb6d16565f39f2a3  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 166
507: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 72,71,107
	btf_id 167
508: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 168
509: sched_cls  name tail_handle_ipv4  tag 8152a74fc248076b  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,104
	btf_id 162
510: sched_cls  name tail_handle_ipv4_from_host  tag 939984be64fbe6d3  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,107
	btf_id 169
511: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,104
	btf_id 170
512: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,107
	btf_id 171
516: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 177
517: sched_cls  name tail_handle_ipv4_from_host  tag 939984be64fbe6d3  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,109
	btf_id 179
518: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,111
	btf_id 178
519: sched_cls  name __send_drop_notify  tag 81c57d25076c15c7  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 180
520: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,109
	btf_id 181
523: sched_cls  name __send_drop_notify  tag fb6d16565f39f2a3  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 185
524: sched_cls  name tail_ipv4_to_endpoint  tag e9d2005738db6e9e  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,112,37,78,79,76,108,35,111,36,33,34
	btf_id 183
527: sched_cls  name tail_handle_ipv4_from_host  tag 939984be64fbe6d3  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,113
	btf_id 189
528: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,113
	btf_id 190
530: sched_cls  name tail_handle_arp  tag dc59d4474d477167  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,111
	btf_id 192
531: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 72,113,71
	btf_id 193
532: sched_cls  name __send_drop_notify  tag fb6d16565f39f2a3  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 194
533: sched_cls  name tail_handle_ipv4_cont  tag 91a4560b8e141cf7  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 71,116,37,94,78,79,35,72,70,73,115,36,33,34,77
	btf_id 197
534: sched_cls  name tail_handle_ipv4  tag 01f3bfff1075d397  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,111
	btf_id 195
535: sched_cls  name tail_ipv4_ct_egress  tag 8f692e5b828b787b  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,111,78,79,112,80
	btf_id 199
536: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 72,115,78,79,116,80
	btf_id 198
537: sched_cls  name tail_ipv4_ct_ingress  tag a16f72694c1ece10  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,111,78,79,112,80
	btf_id 200
538: sched_cls  name cil_from_container  tag 91f5efd962bbff9d  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,72
	btf_id 202
540: sched_cls  name tail_handle_ipv4  tag 24c3731574cb5ca4  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,115
	btf_id 201
541: sched_cls  name tail_ipv4_ct_ingress  tag b32c9abc6fc780ac  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 72,115,78,79,116,80
	btf_id 205
542: sched_cls  name cil_from_container  tag c9afefcea6eaf455  gpl
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 115,72
	btf_id 206
543: sched_cls  name tail_handle_arp  tag b1d02f15e9220a36  gpl
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,115
	btf_id 207
544: sched_cls  name __send_drop_notify  tag c2dee3501169335a  gpl
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 208
545: sched_cls  name handle_policy  tag b1f44042dc1dbb75  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,111,78,79,112,37,76,108,35,80,71,36,33,34
	btf_id 204
546: sched_cls  name tail_handle_ipv4_cont  tag e3e45002e45014b6  gpl
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,112,37,108,78,79,35,72,70,73,111,36,33,34,77
	btf_id 210
547: sched_cls  name handle_policy  tag 3185599c979b4d21  gpl
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 72,115,78,79,116,37,76,94,35,80,71,36,33,34
	btf_id 209
548: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,115
	btf_id 211
550: sched_cls  name tail_ipv4_to_endpoint  tag a35acf4c654b07ab  gpl
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 71,72,116,37,78,79,76,94,35,115,36,33,34
	btf_id 213
551: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
554: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
555: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
558: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
559: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
562: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
563: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
566: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
606: sched_cls  name tail_handle_arp  tag 573e561146f72a62  gpl
	loaded_at 2024-10-25T10:22:41+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,132
	btf_id 229
607: sched_cls  name tail_handle_ipv4  tag 2c0e7e2bd906b0be  gpl
	loaded_at 2024-10-25T10:22:41+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,132
	btf_id 230
608: sched_cls  name tail_ipv4_ct_ingress  tag d380c1a1ddfa8755  gpl
	loaded_at 2024-10-25T10:22:41+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,132,78,79,133,80
	btf_id 231
609: sched_cls  name tail_ipv4_ct_egress  tag 3ebabc26ba39a1ca  gpl
	loaded_at 2024-10-25T10:22:41+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,132,78,79,133,80
	btf_id 232
610: sched_cls  name cil_from_container  tag bdfca6039e782238  gpl
	loaded_at 2024-10-25T10:22:41+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 132,72
	btf_id 233
611: sched_cls  name handle_policy  tag d86afb80031818d1  gpl
	loaded_at 2024-10-25T10:22:41+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,132,78,79,133,37,76,131,35,80,71,36,33,34
	btf_id 234
612: sched_cls  name tail_handle_ipv4_cont  tag 205d1ac035571b0f  gpl
	loaded_at 2024-10-25T10:22:41+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,133,37,131,78,79,35,72,70,73,132,36,33,34,77
	btf_id 235
613: sched_cls  name tail_ipv4_to_endpoint  tag 31da21ab7e13b016  gpl
	loaded_at 2024-10-25T10:22:41+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,133,37,78,79,76,131,35,132,36,33,34
	btf_id 236
614: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:41+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,132
	btf_id 237
616: sched_cls  name __send_drop_notify  tag a7586061cfa50f91  gpl
	loaded_at 2024-10-25T10:22:41+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 239
617: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
620: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
633: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
636: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
637: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
640: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
641: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
644: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
