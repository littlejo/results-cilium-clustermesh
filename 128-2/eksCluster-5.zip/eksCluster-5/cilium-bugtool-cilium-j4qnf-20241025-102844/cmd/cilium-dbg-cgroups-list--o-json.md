[
  {
    "containers": [
      {
        "cgroup-id": 8622,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod03c5525b_3b9f_4eb1_b4c6_28af559e2cd3.slice/cri-containerd-4070651b7b2c2bf5849e264d0a1b3f56eb6e8f9f2ceebf88a9c94945d0e0b016.scope"
      },
      {
        "cgroup-id": 8790,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod03c5525b_3b9f_4eb1_b4c6_28af559e2cd3.slice/cri-containerd-86e80971eabdac2f05c1c9fcce8e3000c5e4b68528f75fc08e427e64474fc788.scope"
      },
      {
        "cgroup-id": 8706,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod03c5525b_3b9f_4eb1_b4c6_28af559e2cd3.slice/cri-containerd-a1b0d238dcc026145dc0013c863afc24e33744410000447fc0d9aa67d5f4a84a.scope"
      }
    ],
    "ips": [
      "10.5.0.90"
    ],
    "name": "clustermesh-apiserver-6ff445c446-wb5ct",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7194,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf379aad_ea9f_41fb_bd24_a2139efed1c0.slice/cri-containerd-e840d9484c1585d5697cbe52fd528b7c836e0be50413ca8a48a27a1aac56aca0.scope"
      }
    ],
    "ips": [
      "10.5.0.101"
    ],
    "name": "coredns-cc6ccd49c-9ktbk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7278,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod340451b3_ed74_4860_a71b_c89bc4c8fda9.slice/cri-containerd-37d56c266b3b4874233b133cf839cb534a1b4c3fe24f7b14e20ea2f82bb6e1f2.scope"
      }
    ],
    "ips": [
      "10.5.0.156"
    ],
    "name": "coredns-cc6ccd49c-pmfk8",
    "namespace": "kube-system"
  }
]

