key: 5d 00 00 00  value: 63 02 00 00
key: a8 00 00 00  value: 23 02 00 00
key: fc 01 00 00  value: 21 02 00 00
key: 62 0c 00 00  value: f2 01 00 00
Found 4 elements
