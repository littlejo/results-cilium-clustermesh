# Cilium debug information

#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4         STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                   
93         Disabled           Disabled          399993     k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.5.0.90    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh6                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                              
                                                           k8s:k8s-app=clustermesh-apiserver                                                                        
168        Disabled           Disabled          4          reserved:health                                                                     10.5.0.44    ready   
508        Disabled           Disabled          447746     k8s:eks.amazonaws.com/component=coredns                                             10.5.0.156   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh6                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                          
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                              
                                                           k8s:k8s-app=kube-dns                                                                                     
625        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                  ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                    
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                              
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                               
                                                           reserved:host                                                                                            
3170       Disabled           Disabled          447746     k8s:eks.amazonaws.com/component=coredns                                             10.5.0.101   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh6                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                          
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                              
                                                           k8s:k8s-app=kube-dns                                                                                     
```

#### BPF Policy Get 93

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3857417   35855     0        
Allow    Ingress     1          ANY          NONE         disabled    3057622   30741     0        
Allow    Egress      0          ANY          NONE         disabled    4017976   37376     0        

```


#### BPF CT List 93

```
Invalid argument: unknown type 93
```


#### Endpoint Get 93

```
[
  {
    "id": 93,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-93-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "9f3e027d-e0b3-48c6-b349-eed51e51f122"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-93",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:41.959Z",
            "success-count": 2
          },
          "uuid": "87ee64ee-522d-462c-b1bc-15fdbb6bcfc8"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-6ff445c446-wb5ct",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:41.957Z",
            "success-count": 1
          },
          "uuid": "0f09abc8-0ca0-444d-8be0-5e284b35304c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-93",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:41.995Z",
            "success-count": 1
          },
          "uuid": "1bff102d-2ebe-48ec-862e-bfbce2eb05a2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (93)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:12.005Z",
            "success-count": 41
          },
          "uuid": "d8ba6b24-d5ba-41df-91d2-51dc75639e09"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "1ad3f67e6a82858d3dea24322096c23fb3cf72e9397fa13fcf612a51b622711b:eth0",
        "container-id": "1ad3f67e6a82858d3dea24322096c23fb3cf72e9397fa13fcf612a51b622711b",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-6ff445c446-wb5ct",
        "pod-name": "kube-system/clustermesh-apiserver-6ff445c446-wb5ct"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 399993,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh6",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6ff445c446"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh6",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:53Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.5.0.90",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "22:d3:81:1c:20:b1",
        "interface-index": 15,
        "interface-name": "lxc08b6b9e1e3e7",
        "mac": "86:0e:d0:8a:69:e3"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 399993,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 399993,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 93

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 93

```
Timestamp              Status   State                   Message
2024-10-25T10:22:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:53Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:22:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:41Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:22:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:22:41Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:22:41Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 399993

```
ID       LABELS
399993   k8s:app.kubernetes.io/name=clustermesh-apiserver
         k8s:app.kubernetes.io/part-of=cilium
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh6
         k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 168

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    432084   5524      0        
Allow    Ingress     1          ANY          NONE         disabled    12984    152       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 168

```
Invalid argument: unknown type 168
```


#### Endpoint Get 168

```
[
  {
    "id": 168,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-168-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b9859967-89d7-4bfe-b017-1ca0c39c7678"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-168",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:07.546Z",
            "success-count": 4
          },
          "uuid": "3faca461-82e6-4264-93f0-b3a76e5d5426"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-168",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:10.951Z",
            "success-count": 2
          },
          "uuid": "2611d0be-133a-4f95-b7d6-7213b28a4a96"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:53Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.5.0.44",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "26:16:4a:06:74:97",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "2e:23:55:39:9a:6e"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 168

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 168

```
Timestamp              Status   State                   Message
2024-10-25T10:22:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:53Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:10Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:09Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:14:08Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:07Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:07Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:06Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 508

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    84241   964       0        
Allow    Egress      0          ANY          NONE         disabled    13909   147       0        

```


#### BPF CT List 508

```
Invalid argument: unknown type 508
```


#### Endpoint Get 508

```
[
  {
    "id": 508,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-508-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "a3d9a511-6cf1-4c29-9395-75687000a9b7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-508",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:10.241Z",
            "success-count": 4
          },
          "uuid": "2a15693f-2a09-4df1-a902-796412a3664c"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-pmfk8",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:10.239Z",
            "success-count": 1
          },
          "uuid": "06d468e6-ac11-4cc7-8035-2dc592d59599"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-508",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:11.012Z",
            "success-count": 2
          },
          "uuid": "570bf566-79af-40e9-af77-86b11085b9c6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (508)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:10.314Z",
            "success-count": 92
          },
          "uuid": "a2139735-a723-4acb-8bea-71585c3be44e"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "15b109b3a8fe6b7d6f3a10a881ea249387cbbb3f6a578df4af70f675f8e13f24:eth0",
        "container-id": "15b109b3a8fe6b7d6f3a10a881ea249387cbbb3f6a578df4af70f675f8e13f24",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-pmfk8",
        "pod-name": "kube-system/coredns-cc6ccd49c-pmfk8"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 447746,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh6",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh6",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:53Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.5.0.156",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "be:e9:00:5e:0f:13",
        "interface-index": 11,
        "interface-name": "lxcf3b338791708",
        "mac": "fe:bc:c5:67:42:1c"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 447746,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 447746,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 508

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 508

```
Timestamp              Status   State                   Message
2024-10-25T10:22:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:53Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:10Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:10Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:10Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 447746

```
ID       LABELS
447746   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh6
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 625

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 625

```
Invalid argument: unknown type 625
```


#### Endpoint Get 625

```
[
  {
    "id": 625,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-625-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "1f3607aa-2bd4-467f-bb43-8196ca49db6d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-625",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:06.538Z",
            "success-count": 4
          },
          "uuid": "5f333836-2d27-4443-b062-8d676e514928"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-625",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:07.678Z",
            "success-count": 2
          },
          "uuid": "5d646b1e-300f-4e24-bcae-c5ac8182d3bd"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:53Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "aa:07:49:1e:07:82",
        "interface-name": "cilium_host",
        "mac": "aa:07:49:1e:07:82"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 625

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 625

```
Timestamp              Status   State                   Message
2024-10-25T10:22:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:53Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:14:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:10Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:14:09Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:09Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:14:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:14:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:06Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:06Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:06Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 3170

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    85460   986       0        
Allow    Egress      0          ANY          NONE         disabled    13986   146       0        

```


#### BPF CT List 3170

```
Invalid argument: unknown type 3170
```


#### Endpoint Get 3170

```
[
  {
    "id": 3170,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3170-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "12ac84ff-14fc-4de4-bc74-6d423ee45e5d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3170",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:08.106Z",
            "success-count": 4
          },
          "uuid": "79b27c46-9ca1-4d41-9dae-039e263fcbdf"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-9ktbk",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:08.104Z",
            "success-count": 1
          },
          "uuid": "5eb00e93-014b-4d2a-b79c-c43e6b82f353"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3170",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:10.956Z",
            "success-count": 2
          },
          "uuid": "32eecf20-7c3d-4a7a-8960-a78596aa4152"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3170)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:08.193Z",
            "success-count": 92
          },
          "uuid": "4878aa54-0922-42e7-9975-ff86b2708a45"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "8a64496ac73cd1e6948e9da6939998600861fec07206bfe3ab151535642aa02a:eth0",
        "container-id": "8a64496ac73cd1e6948e9da6939998600861fec07206bfe3ab151535642aa02a",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-9ktbk",
        "pod-name": "kube-system/coredns-cc6ccd49c-9ktbk"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 447746,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh6",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh6",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:53Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.5.0.101",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "26:2a:73:a8:8b:c2",
        "interface-index": 9,
        "interface-name": "lxc80522580316f",
        "mac": "c2:c6:58:94:c5:d6"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 447746,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 447746,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3170

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3170

```
Timestamp              Status    State                   Message
2024-10-25T10:22:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:53Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:22:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:51Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:51Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:51Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:51Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:40Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:40Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:40Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:40Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:39Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:39Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:39Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:39Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:10Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:10Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:09Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:09Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:14:08Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:08Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:08Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:14:08Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:08Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 447746

```
ID       LABELS
447746   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh6
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.184.62:443 (active)     
                                          2 => 172.31.230.86:443 (active)     
2    10.100.246.85:443     ClusterIP      1 => 172.31.239.114:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.5.0.101:9153 (active)       
                                          2 => 10.5.0.156:9153 (active)       
4    10.100.0.10:53        ClusterIP      1 => 10.5.0.101:53 (active)         
                                          2 => 10.5.0.156:53 (active)         
5    10.100.204.174:2379   ClusterIP      1 => 10.5.0.90:2379 (active)        
```

#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.5.0.166": (string) (len=6) "router",
  (string) (len=9) "10.5.0.44": (string) (len=6) "health",
  (string) (len=10) "10.5.0.101": (string) (len=35) "kube-system/coredns-cc6ccd49c-9ktbk",
  (string) (len=10) "10.5.0.156": (string) (len=35) "kube-system/coredns-cc6ccd49c-pmfk8",
  (string) (len=9) "10.5.0.90": (string) (len=50) "kube-system/clustermesh-apiserver-6ff445c446-wb5ct"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.239.114": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001c20370)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001cb80c0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001cb80c0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4001c20580)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4002df7760)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4002df78c0)(frontends:[10.100.204.174]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4001c20420)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4001c204d0)(frontends:[10.100.246.85]/ports=[peer-service]/selector=map[k8s-app:cilium])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x400167c8c8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-t8wsn": (*k8s.Endpoints)(0x4002d9fa00)(172.31.239.114:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x400167c8d0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-dvn24": (*k8s.Endpoints)(0x4002a75d40)(10.5.0.101:53/TCP[eu-west-3b],10.5.0.101:53/UDP[eu-west-3b],10.5.0.101:9153/TCP[eu-west-3b],10.5.0.156:53/TCP[eu-west-3b],10.5.0.156:53/UDP[eu-west-3b],10.5.0.156:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001571420)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-prs58": (*k8s.Endpoints)(0x400380a820)(10.5.0.90:2379/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x400167c8c0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4002443d40)(172.31.184.62:443/TCP,172.31.230.86:443/TCP)
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x400181bb20)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4001c74820)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4003209b60
  },
  gcTrigger: (chan struct {}) (cap=1) 0x400196fce0,
  gcExited: (chan struct {}) 0x400196fe00,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001b9e400)({
     ObserverVec: (*prometheus.HistogramVec)(0x400192e070)({
      MetricVec: (*prometheus.MetricVec)(0x4001bebd70)({
       metricMap: (*prometheus.metricMap)(0x4001bebda0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001f78a80)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001b9e480)({
     ObserverVec: (*prometheus.HistogramVec)(0x400192e078)({
      MetricVec: (*prometheus.MetricVec)(0x4001bebe00)({
       metricMap: (*prometheus.metricMap)(0x4001bebe30)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001f78ae0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001b9e500)({
     GaugeVec: (*prometheus.GaugeVec)(0x400192e080)({
      MetricVec: (*prometheus.MetricVec)(0x4001bebe90)({
       metricMap: (*prometheus.metricMap)(0x4001bebec0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001f78b40)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001b9e580)({
     GaugeVec: (*prometheus.GaugeVec)(0x400192e088)({
      MetricVec: (*prometheus.MetricVec)(0x4001bebf20)({
       metricMap: (*prometheus.metricMap)(0x4001bebf50)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001f78ba0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001b9e600)({
     GaugeVec: (*prometheus.GaugeVec)(0x400192e090)({
      MetricVec: (*prometheus.MetricVec)(0x4001c08030)({
       metricMap: (*prometheus.metricMap)(0x4001c08060)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001f78c00)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001b9e680)({
     GaugeVec: (*prometheus.GaugeVec)(0x400192e098)({
      MetricVec: (*prometheus.MetricVec)(0x4001c080c0)({
       metricMap: (*prometheus.metricMap)(0x4001c080f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001f78c60)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001b9e700)({
     GaugeVec: (*prometheus.GaugeVec)(0x400192e0a0)({
      MetricVec: (*prometheus.MetricVec)(0x4001c08150)({
       metricMap: (*prometheus.metricMap)(0x4001c08180)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001f78cc0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001b9e780)({
     GaugeVec: (*prometheus.GaugeVec)(0x400192e0a8)({
      MetricVec: (*prometheus.MetricVec)(0x4001c081e0)({
       metricMap: (*prometheus.metricMap)(0x4001c08210)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001f78d20)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001b9e800)({
     ObserverVec: (*prometheus.HistogramVec)(0x400192e0b0)({
      MetricVec: (*prometheus.MetricVec)(0x4001c08270)({
       metricMap: (*prometheus.metricMap)(0x4001c082a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001f78d80)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x400181bb20)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001c1ad20)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001c11008)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 476ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.5.0.0/24, 
Allocated addresses:
  10.5.0.101 (kube-system/coredns-cc6ccd49c-9ktbk)
  10.5.0.156 (kube-system/coredns-cc6ccd49c-pmfk8)
  10.5.0.166 (router)
  10.5.0.44 (health)
  10.5.0.90 (kube-system/clustermesh-apiserver-6ff445c446-wb5ct)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 420da6524f4896ad
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    9s ago         never        0       no error   
  ct-map-pressure                                                     11s ago        never        0       no error   
  daemon-validate-config                                              57s ago        never        0       no error   
  dns-garbage-collector-job                                           13s ago        never        0       no error   
  endpoint-168-regeneration-recovery                                  never          never        0       no error   
  endpoint-3170-regeneration-recovery                                 never          never        0       no error   
  endpoint-508-regeneration-recovery                                  never          never        0       no error   
  endpoint-625-regeneration-recovery                                  never          never        0       no error   
  endpoint-93-regeneration-recovery                                   never          never        0       no error   
  endpoint-gc                                                         13s ago        never        0       no error   
  ep-bpf-prog-watchdog                                                11s ago        never        0       no error   
  ipcache-inject-labels                                               11s ago        never        0       no error   
  k8s-heartbeat                                                       14s ago        never        0       no error   
  link-cache                                                          11s ago        never        0       no error   
  local-identity-checkpoint                                           14m51s ago     never        0       no error   
  node-neighbor-link-updater                                          11s ago        never        0       no error   
  remote-etcd-cmesh1                                                  6m25s ago      never        0       no error   
  remote-etcd-cmesh10                                                 6m26s ago      never        0       no error   
  remote-etcd-cmesh100                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh101                                                6m26s ago      never        0       no error   
  remote-etcd-cmesh102                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh103                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh104                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh105                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh106                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh107                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh108                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh109                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh11                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh110                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh111                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh112                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh113                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh114                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh115                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh116                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh117                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh118                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh119                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh12                                                 6m26s ago      never        0       no error   
  remote-etcd-cmesh120                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh121                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh122                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh123                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh124                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh125                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh126                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh127                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh128                                                6m25s ago      never        0       no error   
  remote-etcd-cmesh13                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh14                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh15                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh16                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh17                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh18                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh19                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh2                                                  6m25s ago      never        0       no error   
  remote-etcd-cmesh20                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh21                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh22                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh23                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh24                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh25                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh26                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh27                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh28                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh29                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh3                                                  6m25s ago      never        0       no error   
  remote-etcd-cmesh30                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh31                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh32                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh33                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh34                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh35                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh36                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh37                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh38                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh39                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh4                                                  6m25s ago      never        0       no error   
  remote-etcd-cmesh40                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh41                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh42                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh43                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh44                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh45                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh46                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh47                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh48                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh49                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh5                                                  6m25s ago      never        0       no error   
  remote-etcd-cmesh50                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh51                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh52                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh53                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh54                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh55                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh56                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh57                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh58                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh59                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh60                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh61                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh62                                                 6m26s ago      never        0       no error   
  remote-etcd-cmesh63                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh64                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh65                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh66                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh67                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh68                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh69                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh7                                                  6m25s ago      never        0       no error   
  remote-etcd-cmesh70                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh71                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh72                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh73                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh74                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh75                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh76                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh77                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh78                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh79                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh8                                                  6m25s ago      never        0       no error   
  remote-etcd-cmesh80                                                 6m26s ago      never        0       no error   
  remote-etcd-cmesh81                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh82                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh83                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh84                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh85                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh86                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh87                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh88                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh89                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh9                                                  6m25s ago      never        0       no error   
  remote-etcd-cmesh90                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh91                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh92                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh93                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh94                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh95                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh96                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh97                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh98                                                 6m25s ago      never        0       no error   
  remote-etcd-cmesh99                                                 6m25s ago      never        0       no error   
  resolve-identity-168                                                10s ago        never        0       no error   
  resolve-identity-3170                                               9s ago         never        0       no error   
  resolve-identity-508                                                7s ago         never        0       no error   
  resolve-identity-625                                                11s ago        never        0       no error   
  resolve-identity-93                                                 1m35s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-6ff445c446-wb5ct   6m35s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-9ktbk                  15m9s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-pmfk8                  15m7s ago      never        0       no error   
  sync-lb-maps-with-k8s-services                                      15m11s ago     never        0       no error   
  sync-policymap-168                                                  6s ago         never        0       no error   
  sync-policymap-3170                                                 6s ago         never        0       no error   
  sync-policymap-508                                                  6s ago         never        0       no error   
  sync-policymap-625                                                  10s ago        never        0       no error   
  sync-policymap-93                                                   6m35s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (3170)                                   9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (508)                                    7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (93)                                     15s ago        never        0       no error   
  sync-utime                                                          11s ago        never        0       no error   
  write-cni-file                                                      15m13s ago     never        0       no error   
Proxy Status:            OK, ip 10.5.0.166, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 393216, max 458751
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 69.22   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 4293645                           /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 4293645                           /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 4293645                           /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d000000 rw-p 00000000 00:00 0 
400d000000-4010000000 ---p 00000000 00:00 0 
ffff61ac2000-ffff61d58000 rw-p 00000000 00:00 0 
ffff61d60000-ffff61e81000 rw-p 00000000 00:00 0 
ffff61e81000-ffff61ec2000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff61ec2000-ffff61f03000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff61f03000-ffff61f05000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff61f05000-ffff61f07000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff61f07000-ffff6249e000 rw-p 00000000 00:00 0 
ffff6249e000-ffff6259e000 rw-p 00000000 00:00 0 
ffff6259e000-ffff625af000 rw-p 00000000 00:00 0 
ffff625af000-ffff645af000 rw-p 00000000 00:00 0 
ffff645af000-ffff6462f000 ---p 00000000 00:00 0 
ffff6462f000-ffff64630000 rw-p 00000000 00:00 0 
ffff64630000-ffff8462f000 ---p 00000000 00:00 0 
ffff8462f000-ffff84630000 rw-p 00000000 00:00 0 
ffff84630000-ffffa45bf000 ---p 00000000 00:00 0 
ffffa45bf000-ffffa45c0000 rw-p 00000000 00:00 0 
ffffa45c0000-ffffa85b1000 ---p 00000000 00:00 0 
ffffa85b1000-ffffa85b2000 rw-p 00000000 00:00 0 
ffffa85b2000-ffffa8daf000 ---p 00000000 00:00 0 
ffffa8daf000-ffffa8db0000 rw-p 00000000 00:00 0 
ffffa8db0000-ffffa8eaf000 ---p 00000000 00:00 0 
ffffa8eaf000-ffffa8f0f000 rw-p 00000000 00:00 0 
ffffa8f0f000-ffffa8f11000 r--p 00000000 00:00 0                          [vvar]
ffffa8f11000-ffffa8f12000 r-xp 00000000 00:00 0                          [vdso]
fffffb8cf000-fffffb8f0000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium environment keys

```
metrics:
enable-ipv4-big-tcp:false
bpf-nat-global-max:524288
disable-external-ip-mitigation:false
certificates-directory:/var/run/cilium/certs
bpf-sock-rev-map-max:262144
bpf-lb-sock:false
vlan-bpf-bypass:
cluster-id:6
disable-endpoint-crd:false
node-port-bind-protection:true
hubble-export-file-compress:false
enable-host-port:false
synchronize-k8s-nodes:true
monitor-aggregation-interval:5s
enable-ipv6:false
enable-l7-proxy:true
clustermesh-enable-mcs-api:false
identity-restore-grace-period:30s
enable-ipsec-xfrm-state-caching:true
ipam-default-ip-pool:default
enable-high-scale-ipcache:false
crd-wait-timeout:5m0s
tofqdns-dns-reject-response-code:refused
enable-k8s-api-discovery:false
exclude-node-label-patterns:
agent-liveness-update-interval:1s
operator-api-serve-addr:127.0.0.1:9234
force-device-detection:false
enable-k8s-networkpolicy:true
kvstore-opt:
egress-gateway-reconciliation-trigger-interval:1s
enable-route-mtu-for-cni-chaining:false
label-prefix-file:
cluster-health-port:4240
enable-l2-announcements:false
trace-payloadlen:128
direct-routing-skip-unreachable:false
bpf-fragments-map-max:8192
enable-active-connection-tracking:false
local-max-addr-scope:252
ipv6-range:auto
enable-pmtu-discovery:false
enable-encryption-strict-mode:false
endpoint-gc-interval:5m0s
srv6-encap-mode:reduced
vtep-mask:
iptables-lock-timeout:5s
clustermesh-ip-identities-sync-timeout:1m0s
enable-masquerade-to-route-source:false
tofqdns-endpoint-max-ip-per-hostname:50
hubble-monitor-events:
bpf-lb-rss-ipv4-src-cidr:
k8s-heartbeat-timeout:30s
node-port-mode:snat
unmanaged-pod-watcher-interval:15
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
proxy-portrange-min:10000
enable-node-selector-labels:false
disable-iptables-feeder-rules:
config-dir:/tmp/cilium/config-map
hubble-redact-http-headers-allow:
cflags:
l2-announcements-retry-period:2s
ipsec-key-file:
vtep-cidr:
hubble-skip-unknown-cgroup-ids:true
enable-ipsec-key-watcher:true
bpf-ct-timeout-regular-tcp-fin:10s
ipv6-mcast-device:
allocator-list-timeout:3m0s
prepend-iptables-chains:true
hubble-redact-http-headers-deny:
enable-envoy-config:false
ipv6-cluster-alloc-cidr:f00d::/64
enable-l2-pod-announcements:false
bpf-lb-map-max:65536
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
tunnel-protocol:vxlan
bpf-ct-global-tcp-max:524288
ip-masq-agent-config-path:/etc/config/ip-masq-agent
bpf-auth-map-max:524288
enable-cilium-health-api-server-access:
policy-accounting:true
bpf-lb-rev-nat-map-max:0
k8s-client-qps:10
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
bpf-events-policy-verdict-enabled:true
hubble-redact-kafka-apikey:false
hubble-export-file-max-backups:5
mke-cgroup-mount:
annotate-k8s-node:false
set-cilium-node-taints:true
hubble-event-buffer-capacity:4095
bpf-lb-service-backend-map-max:0
hubble-metrics-server:
bpf-ct-timeout-service-any:1m0s
node-port-acceleration:disabled
allow-localhost:auto
log-system-load:false
envoy-base-id:0
enable-hubble:true
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
dnsproxy-lock-timeout:500ms
log-opt:
ipv6-node:auto
bpf-neigh-global-max:524288
tofqdns-min-ttl:0
enable-wireguard:false
http-retry-count:3
envoy-config-retry-interval:15s
ipam-multi-pool-pre-allocation:
dns-max-ips-per-restored-rule:1000
k8s-kubeconfig-path:
encryption-strict-mode-allow-remote-node-identities:false
local-router-ipv4:
http-retry-timeout:0
max-connected-clusters:255
node-labels:
enable-tracing:false
enable-ipv6-ndp:false
bgp-config-path:/var/lib/cilium/bgp/config.yaml
proxy-idle-timeout-seconds:60
cilium-endpoint-gc-interval:5m0s
exclude-local-address:
enable-ipv6-big-tcp:false
mesh-auth-signal-backoff-duration:1s
enable-external-ips:false
hubble-drop-events:false
enable-metrics:true
ipam-cilium-node-update-rate:15s
bpf-ct-timeout-regular-tcp-syn:1m0s
enable-runtime-device-detection:true
ingress-secrets-namespace:
enable-health-check-loadbalancer-ip:false
socket-path:/var/run/cilium/cilium.sock
cni-log-file:/var/run/cilium/cilium-cni.log
use-cilium-internal-ip-for-ipsec:false
keep-config:false
lib-dir:/var/lib/cilium
policy-queue-size:100
bpf-ct-timeout-service-tcp-grace:1m0s
mesh-auth-enabled:true
enable-identity-mark:true
nodeport-addresses:
mesh-auth-mutual-listener-port:0
enable-session-affinity:false
dnsproxy-insecure-skip-transparent-mode-check:false
datapath-mode:veth
api-rate-limit:
hubble-recorder-storage-path:/var/run/cilium/pcaps
enable-auto-protect-node-port-range:true
conntrack-gc-interval:0s
ipv4-node:auto
bpf-lb-dsr-dispatch:opt
tofqdns-pre-cache:
bgp-announce-lb-ip:false
enable-k8s-endpoint-slice:true
dns-policy-unload-on-shutdown:false
enable-ipsec:false
hubble-flowlogs-config-path:
cluster-name:cmesh6
bpf-policy-map-full-reconciliation-interval:15m0s
enable-k8s-terminating-endpoint:true
ipv4-service-loopback-address:169.254.42.1
encryption-strict-mode-cidr:
route-metric:0
enable-bandwidth-manager:false
trace-sock:true
proxy-max-requests-per-connection:0
mesh-auth-rotated-identities-queue-size:1024
enable-ipv4-masquerade:true
cluster-pool-ipv4-cidr:10.5.0.0/16
k8s-sync-timeout:3m0s
enable-ipv4-egress-gateway:false
enable-endpoint-health-checking:true
ipv4-service-range:auto
container-ip-local-reserved-ports:auto
hubble-listen-address::4244
l2-pod-announcements-interface:
hubble-event-queue-size:0
proxy-xff-num-trusted-hops-ingress:0
direct-routing-device:
controller-group-metrics:
restore:true
bpf-lb-source-range-map-max:0
kvstore-max-consecutive-quorum-errors:2
mesh-auth-mutual-connect-timeout:5s
envoy-config-timeout:2m0s
bpf-root:/sys/fs/bpf
debug:false
proxy-prometheus-port:0
dnsproxy-concurrency-limit:0
dnsproxy-enable-transparent-mode:true
read-cni-conf:
clustermesh-sync-timeout:1m0s
policy-trigger-interval:1s
bpf-map-event-buffers:
allow-icmp-frag-needed:true
http-normalize-path:true
enable-ipip-termination:false
enable-ingress-controller:false
enable-tcx:true
identity-allocation-mode:crd
dnsproxy-concurrency-processing-grace-period:0s
operator-prometheus-serve-addr::9963
enable-ip-masq-agent:false
prometheus-serve-addr:
service-no-backend-response:reject
tunnel-port:0
ipv6-native-routing-cidr:
identity-heartbeat-timeout:30m0s
endpoint-bpf-prog-watchdog-interval:30s
set-cilium-is-up-condition:true
bpf-lb-sock-terminate-pod-connections:false
hubble-recorder-sink-queue-size:1024
hubble-prefer-ipv6:false
enable-bpf-clock-probe:false
endpoint-queue-size:25
hubble-redact-http-urlquery:false
routing-mode:tunnel
clustermesh-config:/var/lib/cilium/clustermesh/
enable-well-known-identities:false
enable-bbr:false
derive-masq-ip-addr-from-device:
enable-monitor:true
pprof-address:localhost
proxy-admin-port:0
enable-service-topology:false
kvstore-connectivity-timeout:2m0s
max-internal-timer-delay:0s
cluster-pool-ipv4-mask-size:24
tofqdns-max-deferred-connection-deletes:10000
proxy-max-connection-duration-seconds:0
kube-proxy-replacement-healthz-bind-address:
use-full-tls-context:false
enable-policy:default
enable-wireguard-userspace-fallback:false
cni-chaining-target:
cni-exclusive:true
k8s-require-ipv4-pod-cidr:false
enable-vtep:false
join-cluster:false
node-port-algorithm:random
egress-gateway-policy-map-max:16384
cni-chaining-mode:none
monitor-queue-size:0
debug-verbose:
bpf-node-map-max:16384
tofqdns-proxy-port:0
local-router-ipv6:
bpf-ct-global-any-max:262144
bpf-events-drop-enabled:true
bpf-lb-algorithm:random
nat-map-stats-entries:32
policy-audit-mode:false
enable-icmp-rules:true
monitor-aggregation:medium
bpf-lb-maglev-table-size:16381
node-port-range:
enable-local-node-route:true
bpf-filter-priority:1
hubble-redact-http-userinfo:true
bypass-ip-availability-upon-restore:false
gateway-api-secrets-namespace:
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
enable-cilium-api-server-access:
k8s-service-cache-size:128
egress-masquerade-interfaces:ens+
vtep-endpoint:
log-driver:
bpf-lb-external-clusterip:false
envoy-log:
enable-gateway-api:false
mesh-auth-spire-admin-socket:
bpf-lb-maglev-map-max:0
tofqdns-enable-dns-compression:true
http-idle-timeout:0
version:false
remove-cilium-node-taints:true
k8s-api-server:
kvstore-lease-ttl:15m0s
install-no-conntrack-iptables-rules:false
fqdn-regex-compile-lru-size:1024
custom-cni-conf:false
enable-ipv4:true
auto-create-cilium-node-resource:true
hubble-disable-tls:false
bpf-ct-timeout-regular-tcp:2h13m20s
enable-stale-cilium-endpoint-cleanup:true
enable-bgp-control-plane:false
enable-bpf-masquerade:false
hubble-metrics:
enable-ipv6-masquerade:true
iptables-random-fully:false
enable-node-port:false
monitor-aggregation-flags:all
k8s-service-proxy-name:
install-iptables-rules:true
vtep-mac:
ipam:cluster-pool
encrypt-interface:
tofqdns-proxy-response-max-delay:100ms
enable-xdp-prefilter:false
k8s-client-connection-timeout:30s
http-request-timeout:3600
enable-ipsec-encrypted-overlay:false
bpf-ct-timeout-service-tcp:2h13m20s
config:
proxy-xff-num-trusted-hops-egress:0
k8s-require-ipv6-pod-cidr:false
ipv4-range:auto
enable-sctp:false
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
dnsproxy-lock-count:131
policy-cidr-match-mode:
wireguard-persistent-keepalive:0s
max-controller-interval:0
hubble-export-allowlist:
bpf-ct-timeout-regular-any:1m0s
bpf-lb-acceleration:disabled
bpf-lb-affinity-map-max:0
pprof-port:6060
enable-cilium-endpoint-slice:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
static-cnp-path:
mesh-auth-spiffe-trust-domain:spiffe.cilium
enable-recorder:false
arping-refresh-period:30s
bpf-events-trace-enabled:true
enable-ipv4-fragment-tracking:true
ipv6-pod-subnets:
procfs:/host/proc
envoy-keep-cap-netbindservice:false
kvstore-periodic-sync:5m0s
l2-announcements-renew-deadline:5s
hubble-export-file-max-size-mb:10
k8s-namespace:kube-system
auto-direct-node-routes:false
hubble-export-file-path:
proxy-portrange-max:20000
hubble-drop-events-interval:2m0s
proxy-gid:1337
enable-health-checking:true
enable-custom-calls:false
ipv4-native-routing-cidr:
tofqdns-idle-connection-grace-period:0s
ipv4-pod-subnets:
fixed-identity-mapping:
egress-multi-home-ip-rule-compat:false
enable-local-redirect-policy:false
mesh-auth-queue-size:1024
agent-health-port:9879
external-envoy-proxy:true
k8s-client-burst:20
proxy-connect-timeout:2
hubble-export-fieldmask:
cni-external-routing:false
enable-mke:false
preallocate-bpf-maps:false
labels:
kvstore:
kube-proxy-replacement:false
dnsproxy-socket-linger-timeout:10
config-sources:config-map:kube-system/cilium-config
bgp-announce-pod-cidr:false
l2-announcements-lease-duration:15s
enable-svc-source-range-check:true
hubble-drop-events-reasons:auth_required,policy_denied
pprof:false
mesh-auth-gc-interval:5m0s
hubble-redact-enabled:false
enable-host-firewall:false
bpf-map-dynamic-size-ratio:0.0025
nodes-gc-interval:5m0s
conntrack-gc-max-interval:0s
bpf-lb-mode:snat
mtu:0
identity-gc-interval:15m0s
k8s-client-connection-keep-alive:30s
enable-nat46x64-gateway:false
bpf-policy-map-max:16384
ipsec-key-rotation-duration:5m0s
hubble-export-denylist:
enable-unreachable-routes:false
agent-labels:
ipv6-service-range:auto
bpf-lb-dsr-l4-xlate:frontend
clustermesh-enable-endpoint-sync:false
enable-l2-neigh-discovery:true
gops-port:9890
identity-change-grace-period:5s
bpf-lb-service-map-max:0
bpf-lb-sock-hostns-only:false
nat-map-stats-interval:30s
state-dir:/var/run/cilium
cmdref:
encrypt-node:false
bpf-lb-rss-ipv6-src-cidr:
enable-bpf-tproxy:false
multicast-enabled:false
enable-host-legacy-routing:false
disable-envoy-version-check:false
hubble-socket-path:/var/run/cilium/hubble.sock
envoy-secrets-namespace:
devices:
cgroup-root:/run/cilium/cgroupv2
enable-health-check-nodeport:true
http-max-grpc-timeout:0
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
enable-hubble-recorder-api:true
enable-endpoint-routes:false
enable-srv6:false
enable-k8s:true
enable-xt-socket-fallback:true
```

