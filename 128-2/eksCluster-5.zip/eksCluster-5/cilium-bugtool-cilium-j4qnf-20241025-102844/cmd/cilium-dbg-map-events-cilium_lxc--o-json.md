{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:06.325Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.239.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:06.325Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:10.950Z",
  "value": "id=168   sec_id=4     flags=0x0000 ifindex=7   mac=2E:23:55:39:9A:6E nodemac=26:16:4A:06:74:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:10.954Z",
  "value": "id=3170  sec_id=447746 flags=0x0000 ifindex=9   mac=C2:C6:58:94:C5:D6 nodemac=26:2A:73:A8:8B:C2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:11.010Z",
  "value": "id=508   sec_id=447746 flags=0x0000 ifindex=11  mac=FE:BC:C5:67:42:1C nodemac=BE:E9:00:5E:0F:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:11.027Z",
  "value": "id=168   sec_id=4     flags=0x0000 ifindex=7   mac=2E:23:55:39:9A:6E nodemac=26:16:4A:06:74:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:39.662Z",
  "value": "id=168   sec_id=4     flags=0x0000 ifindex=7   mac=2E:23:55:39:9A:6E nodemac=26:16:4A:06:74:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:39.663Z",
  "value": "id=3170  sec_id=447746 flags=0x0000 ifindex=9   mac=C2:C6:58:94:C5:D6 nodemac=26:2A:73:A8:8B:C2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:39.664Z",
  "value": "id=508   sec_id=447746 flags=0x0000 ifindex=11  mac=FE:BC:C5:67:42:1C nodemac=BE:E9:00:5E:0F:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:39.692Z",
  "value": "id=15    sec_id=399993 flags=0x0000 ifindex=13  mac=A6:F3:C3:76:D0:52 nodemac=A6:5F:1F:11:DC:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:40.659Z",
  "value": "id=3170  sec_id=447746 flags=0x0000 ifindex=9   mac=C2:C6:58:94:C5:D6 nodemac=26:2A:73:A8:8B:C2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:40.659Z",
  "value": "id=15    sec_id=399993 flags=0x0000 ifindex=13  mac=A6:F3:C3:76:D0:52 nodemac=A6:5F:1F:11:DC:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:40.659Z",
  "value": "id=508   sec_id=447746 flags=0x0000 ifindex=11  mac=FE:BC:C5:67:42:1C nodemac=BE:E9:00:5E:0F:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:40.660Z",
  "value": "id=168   sec_id=4     flags=0x0000 ifindex=7   mac=2E:23:55:39:9A:6E nodemac=26:16:4A:06:74:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:41.994Z",
  "value": "id=93    sec_id=399993 flags=0x0000 ifindex=15  mac=86:0E:D0:8A:69:E3 nodemac=22:D3:81:1C:20:B1"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.5.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:47.864Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:51.786Z",
  "value": "id=168   sec_id=4     flags=0x0000 ifindex=7   mac=2E:23:55:39:9A:6E nodemac=26:16:4A:06:74:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:51.786Z",
  "value": "id=3170  sec_id=447746 flags=0x0000 ifindex=9   mac=C2:C6:58:94:C5:D6 nodemac=26:2A:73:A8:8B:C2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:51.787Z",
  "value": "id=508   sec_id=447746 flags=0x0000 ifindex=11  mac=FE:BC:C5:67:42:1C nodemac=BE:E9:00:5E:0F:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:51.787Z",
  "value": "id=93    sec_id=399993 flags=0x0000 ifindex=15  mac=86:0E:D0:8A:69:E3 nodemac=22:D3:81:1C:20:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.777Z",
  "value": "id=168   sec_id=4     flags=0x0000 ifindex=7   mac=2E:23:55:39:9A:6E nodemac=26:16:4A:06:74:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.778Z",
  "value": "id=3170  sec_id=447746 flags=0x0000 ifindex=9   mac=C2:C6:58:94:C5:D6 nodemac=26:2A:73:A8:8B:C2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.778Z",
  "value": "id=508   sec_id=447746 flags=0x0000 ifindex=11  mac=FE:BC:C5:67:42:1C nodemac=BE:E9:00:5E:0F:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.778Z",
  "value": "id=93    sec_id=399993 flags=0x0000 ifindex=15  mac=86:0E:D0:8A:69:E3 nodemac=22:D3:81:1C:20:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.777Z",
  "value": "id=508   sec_id=447746 flags=0x0000 ifindex=11  mac=FE:BC:C5:67:42:1C nodemac=BE:E9:00:5E:0F:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.777Z",
  "value": "id=168   sec_id=4     flags=0x0000 ifindex=7   mac=2E:23:55:39:9A:6E nodemac=26:16:4A:06:74:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.778Z",
  "value": "id=93    sec_id=399993 flags=0x0000 ifindex=15  mac=86:0E:D0:8A:69:E3 nodemac=22:D3:81:1C:20:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.778Z",
  "value": "id=3170  sec_id=447746 flags=0x0000 ifindex=9   mac=C2:C6:58:94:C5:D6 nodemac=26:2A:73:A8:8B:C2"
}

