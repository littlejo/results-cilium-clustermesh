KEY             VALUE
AgentLiveness   960885127321
UTimeOffset     3378615615234375
