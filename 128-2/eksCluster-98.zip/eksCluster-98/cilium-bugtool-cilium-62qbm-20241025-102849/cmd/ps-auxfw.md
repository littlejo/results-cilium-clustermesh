USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         681  0.0  0.0  13060  1228 ?        R    10:28   0:00 /usr/sbin/runc init
root         673  0.0  0.2 1616264 8680 ?        Ssl  10:28   0:00 /usr/sbin/runc init
root         659  0.0  0.4 1240432 16580 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         679  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         682  0.0  0.4 1240432 16580 ?       R    10:28   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         632  0.0  0.0 1228744 3648 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  3.4  7.2 1538356 285156 ?      Ssl  10:15   0:27 cilium-agent --config-dir=/tmp/cilium/config-map
root         403  0.0  0.1 1228848 6016 ?        Sl   10:15   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
