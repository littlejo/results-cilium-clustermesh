1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d0:04:7c:c0:e9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.173.171/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2728sec preferred_lft 2728sec
    inet6 fe80::4d0:4ff:fe7c:c0e9/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:0b:0f:30:ca:ff brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.145.95/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::40b:fff:fe30:caff/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:18:30:dc:cc:e6 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a818:30ff:fedc:cce6/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:c0:4d:f2:7c:38 brd ff:ff:ff:ff:ff:ff
    inet 10.98.0.55/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::28c0:4dff:fef2:7c38/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 02:de:43:1a:8b:0b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::de:43ff:fe1a:8b0b/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:e3:a7:35:7f:a6 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::14e3:a7ff:fe35:7fa6/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc50eaa77db4cf@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:98:79:97:6d:26 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::5c98:79ff:fe97:6d26/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcfd6d5a9a04b6@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:44:64:19:a0:2d brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::5444:64ff:fe19:a02d/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc5ef227f39400@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:76:bb:a1:50:01 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::1876:bbff:fea1:5001/64 scope link 
       valid_lft forever preferred_lft forever
