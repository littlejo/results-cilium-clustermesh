REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10246     802746     677    bpf_overlay.c
Interface                 INGRESS     233346    87049880   1132   bpf_host.c
Success                   EGRESS      10486     819213     53     encap.h
Success                   EGRESS      105744    13921741   1308   bpf_lxc.c
Success                   EGRESS      12248     1935984    86     l3.h
Success                   EGRESS      5158      396956     1694   bpf_host.c
Success                   INGRESS     117318    14478346   86     l3.h
Success                   INGRESS     135176    16854628   235    trace.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
