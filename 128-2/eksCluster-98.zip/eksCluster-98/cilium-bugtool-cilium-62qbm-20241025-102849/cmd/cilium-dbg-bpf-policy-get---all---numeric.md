Endpoint ID: 1452
Path: /sys/fs/bpf/tc/globals/cilium_policy_01452

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3884092   36752     0        
Allow    Ingress     1          ANY          NONE         disabled    3834658   37728     0        
Allow    Egress      0          ANY          NONE         disabled    4995218   46317     0        


Endpoint ID: 1626
Path: /sys/fs/bpf/tc/globals/cilium_policy_01626

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1732
Path: /sys/fs/bpf/tc/globals/cilium_policy_01732

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    337371   3029      0        
Allow    Ingress     1          ANY          NONE         disabled    78380    901       0        
Allow    Egress      0          ANY          NONE         disabled    64497    617       0        


Endpoint ID: 2384
Path: /sys/fs/bpf/tc/globals/cilium_policy_02384

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    441052   5620      0        
Allow    Ingress     1          ANY          NONE         disabled    12050    143       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2527
Path: /sys/fs/bpf/tc/globals/cilium_policy_02527

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    342183   3095      0        
Allow    Ingress     1          ANY          NONE         disabled    77984    895       0        
Allow    Egress      0          ANY          NONE         disabled    66396    638       0        


