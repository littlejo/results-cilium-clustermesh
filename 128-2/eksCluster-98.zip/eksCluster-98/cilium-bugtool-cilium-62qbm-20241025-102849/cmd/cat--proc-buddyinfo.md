Node 0, zone      DMA    140     14      4      3      1      2      3      3      2      3    160 
Node 0, zone   Normal    614    107     35     24     21      8      4      4      2      5      5 
