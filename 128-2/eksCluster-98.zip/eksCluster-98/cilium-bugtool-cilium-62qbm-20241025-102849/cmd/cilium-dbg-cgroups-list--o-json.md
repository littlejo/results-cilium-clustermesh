[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaf0eb382_9ba1_4914_bccc_32c926bf4f58.slice/cri-containerd-1e72e21e9228594441b3366c4cf1bc977188291acd8525c4f7f33ee241cf3fbf.scope"
      }
    ],
    "ips": [
      "10.98.0.216"
    ],
    "name": "coredns-cc6ccd49c-j9446",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod83a57e1b_796a_4e54_91ea_f4eaf243012f.slice/cri-containerd-86d40c7096e93d3e976c965d2c0b14ee6b5dc93597880c8b7c3e417dfe8b0950.scope"
      }
    ],
    "ips": [
      "10.98.0.210"
    ],
    "name": "coredns-cc6ccd49c-n2mlv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod34ed0e55_bac9_4f6d_8dcb_2a9d100b6d02.slice/cri-containerd-9f3a765c18f371319e77e2a6c9660b23eb60a35eddd1ee0ffef802b6147f0d74.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod34ed0e55_bac9_4f6d_8dcb_2a9d100b6d02.slice/cri-containerd-49a8cbd90846928d6a94693f097d0371354bc05082ab31a54ca45cae4b0b116b.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod34ed0e55_bac9_4f6d_8dcb_2a9d100b6d02.slice/cri-containerd-4d3a7a46b8d9e8ab0af4aee085b34c6be6e989d355fab8cc1dbf4f92b7df5a8a.scope"
      }
    ],
    "ips": [
      "10.98.0.167"
    ],
    "name": "clustermesh-apiserver-7f5c896f94-hq45n",
    "namespace": "kube-system"
  }
]

