key: ac 05 00 00  value: 8a 02 00 00
key: c4 06 00 00  value: 26 02 00 00
key: 50 09 00 00  value: 48 02 00 00
key: df 09 00 00  value: 09 02 00 00
Found 4 elements
