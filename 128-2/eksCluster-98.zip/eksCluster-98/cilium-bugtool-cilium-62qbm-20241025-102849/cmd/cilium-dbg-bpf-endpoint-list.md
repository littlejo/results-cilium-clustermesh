IP ADDRESS         LOCAL ENDPOINT INFO
10.98.0.216:0      id=2527  sec_id=6545166 flags=0x0000 ifindex=12  mac=DE:52:EF:05:D6:D3 nodemac=5E:98:79:97:6D:26   
10.98.0.167:0      id=1452  sec_id=6522857 flags=0x0000 ifindex=18  mac=DA:2A:93:58:35:8A nodemac=1A:76:BB:A1:50:01   
172.31.173.171:0   (localhost)                                                                                        
172.31.145.95:0    (localhost)                                                                                        
10.98.0.210:0      id=1732  sec_id=6545166 flags=0x0000 ifindex=14  mac=86:7F:63:67:9E:B2 nodemac=56:44:64:19:A0:2D   
10.98.0.126:0      id=2384  sec_id=4     flags=0x0000 ifindex=10  mac=F6:CD:75:55:F8:CA nodemac=16:E3:A7:35:7F:A6     
10.98.0.55:0       (localhost)                                                                                        
