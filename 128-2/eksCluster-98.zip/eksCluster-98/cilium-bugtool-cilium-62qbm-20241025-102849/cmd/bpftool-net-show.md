xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 564
ens6(5) clsact/ingress cil_from_netdev-ens6 id 573
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 555
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 549
cilium_host(7) clsact/egress cil_from_host-cilium_host id 546
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 482
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 483
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 582
lxc50eaa77db4cf(12) clsact/ingress cil_from_container-lxc50eaa77db4cf id 526
lxcfd6d5a9a04b6(14) clsact/ingress cil_from_container-lxcfd6d5a9a04b6 id 551
lxc5ef227f39400(18) clsact/ingress cil_from_container-lxc5ef227f39400 id 640

flow_dissector:

netfilter:

