# Cilium debug information

#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium encryption



#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.98.0.167": (string) (len=50) "kube-system/clustermesh-apiserver-7f5c896f94-hq45n",
  (string) (len=10) "10.98.0.55": (string) (len=6) "router",
  (string) (len=11) "10.98.0.126": (string) (len=6) "health",
  (string) (len=11) "10.98.0.216": (string) (len=35) "kube-system/coredns-cc6ccd49c-j9446",
  (string) (len=11) "10.98.0.210": (string) (len=35) "kube-system/coredns-cc6ccd49c-n2mlv"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.173.171": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001b3c420)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x40025b1860,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x40025b1860,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x40006dd130)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4002134d10)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4002075600)(frontends:[10.100.254.199]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x40006dcf20)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x40006dcfd0)(frontends:[10.100.137.62]/ports=[peer-service]/selector=map[k8s-app:cilium])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x40015b21e8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40021aeb60)(172.31.157.132:443/TCP,172.31.244.104:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x40015b21f0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-27d6x": (*k8s.Endpoints)(0x4001d62b60)(172.31.173.171:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x40015b21f8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-495bc": (*k8s.Endpoints)(0x4002fd8dd0)(10.98.0.210:53/TCP[eu-west-3a],10.98.0.210:53/UDP[eu-west-3a],10.98.0.210:9153/TCP[eu-west-3a],10.98.0.216:53/TCP[eu-west-3a],10.98.0.216:53/UDP[eu-west-3a],10.98.0.216:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40015eba78)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-bsh4z": (*k8s.Endpoints)(0x40067e5c70)(10.98.0.167:2379/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4002482070)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4002359310)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x40062ca450
  },
  gcTrigger: (chan struct {}) (cap=1) 0x400235b7a0,
  gcExited: (chan struct {}) 0x400235b800,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x40024ded80)({
     ObserverVec: (*prometheus.HistogramVec)(0x40015b3da0)({
      MetricVec: (*prometheus.MetricVec)(0x40026bf050)({
       metricMap: (*prometheus.metricMap)(0x40026bf080)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400246ede0)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x40024dee00)({
     ObserverVec: (*prometheus.HistogramVec)(0x40015b3da8)({
      MetricVec: (*prometheus.MetricVec)(0x40026bf0e0)({
       metricMap: (*prometheus.metricMap)(0x40026bf110)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400246ee40)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x40024dee80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40015b3db0)({
      MetricVec: (*prometheus.MetricVec)(0x40026bf170)({
       metricMap: (*prometheus.metricMap)(0x40026bf1a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400246eea0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x40024def00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40015b3db8)({
      MetricVec: (*prometheus.MetricVec)(0x40026bf200)({
       metricMap: (*prometheus.metricMap)(0x40026bf230)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400246ef00)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x40024def80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40015b3dc0)({
      MetricVec: (*prometheus.MetricVec)(0x40026bf290)({
       metricMap: (*prometheus.metricMap)(0x40026bf2c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400246ef60)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x40024df000)({
     GaugeVec: (*prometheus.GaugeVec)(0x40015b3dc8)({
      MetricVec: (*prometheus.MetricVec)(0x40026bf320)({
       metricMap: (*prometheus.metricMap)(0x40026bf350)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400246efc0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x40024df080)({
     GaugeVec: (*prometheus.GaugeVec)(0x40015b3dd0)({
      MetricVec: (*prometheus.MetricVec)(0x40026bf3b0)({
       metricMap: (*prometheus.metricMap)(0x40026bf3e0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400246f020)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x40024df100)({
     GaugeVec: (*prometheus.GaugeVec)(0x40015b3dd8)({
      MetricVec: (*prometheus.MetricVec)(0x40026bf440)({
       metricMap: (*prometheus.metricMap)(0x40026bf470)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400246f080)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x40024df180)({
     ObserverVec: (*prometheus.HistogramVec)(0x40015b3de0)({
      MetricVec: (*prometheus.MetricVec)(0x40026bf4d0)({
       metricMap: (*prometheus.metricMap)(0x40026bf500)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400246f0e0)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4002482070)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4002483110)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x40026ad6f8)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 287ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.98.0.0/24, 
Allocated addresses:
  10.98.0.126 (health)
  10.98.0.167 (kube-system/clustermesh-apiserver-7f5c896f94-hq45n)
  10.98.0.210 (kube-system/coredns-cc6ccd49c-n2mlv)
  10.98.0.216 (kube-system/coredns-cc6ccd49c-j9446)
  10.98.0.55 (router)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m25s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m26s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1127f980370343e9
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    51s ago        never        0       no error   
  ct-map-pressure                                                     22s ago        never        0       no error   
  daemon-validate-config                                              39s ago        never        0       no error   
  dns-garbage-collector-job                                           54s ago        never        0       no error   
  endpoint-1452-regeneration-recovery                                 never          never        0       no error   
  endpoint-1626-regeneration-recovery                                 never          never        0       no error   
  endpoint-1732-regeneration-recovery                                 never          never        0       no error   
  endpoint-2384-regeneration-recovery                                 never          never        0       no error   
  endpoint-2527-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                         3m54s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                22s ago        never        0       no error   
  ipcache-inject-labels                                               52s ago        never        0       no error   
  k8s-heartbeat                                                       25s ago        never        0       no error   
  link-cache                                                          7s ago         never        0       no error   
  local-identity-checkpoint                                           13m52s ago     never        0       no error   
  node-neighbor-link-updater                                          2s ago         never        0       no error   
  remote-etcd-cmesh1                                                  7m25s ago      never        0       no error   
  remote-etcd-cmesh10                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh100                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh101                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh102                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh103                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh104                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh105                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh106                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh107                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh108                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh109                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh11                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh110                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh111                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh112                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh113                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh114                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh115                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh116                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh117                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh118                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh119                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh12                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh120                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh121                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh122                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh123                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh124                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh125                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh126                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh127                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh128                                                7m25s ago      never        0       no error   
  remote-etcd-cmesh13                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh14                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh15                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh16                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh17                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh18                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh19                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh2                                                  7m25s ago      never        0       no error   
  remote-etcd-cmesh20                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh21                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh22                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh23                                                 7m26s ago      never        0       no error   
  remote-etcd-cmesh24                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh25                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh26                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh27                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh28                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh29                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh3                                                  7m25s ago      never        0       no error   
  remote-etcd-cmesh30                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh31                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh32                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh33                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh34                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh35                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh36                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh37                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh38                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh39                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh4                                                  7m25s ago      never        0       no error   
  remote-etcd-cmesh40                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh41                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh42                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh43                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh44                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh45                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh46                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh47                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh48                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh49                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh5                                                  7m25s ago      never        0       no error   
  remote-etcd-cmesh50                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh51                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh52                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh53                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh54                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh55                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh56                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh57                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh58                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh59                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh6                                                  7m25s ago      never        0       no error   
  remote-etcd-cmesh60                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh61                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh62                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh63                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh64                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh65                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh66                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh67                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh68                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh69                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh7                                                  7m25s ago      never        0       no error   
  remote-etcd-cmesh70                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh71                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh72                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh73                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh74                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh75                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh76                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh77                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh78                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh79                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh8                                                  7m25s ago      never        0       no error   
  remote-etcd-cmesh80                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh81                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh82                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh83                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh84                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh85                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh86                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh87                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh88                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh89                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh9                                                  7m25s ago      never        0       no error   
  remote-etcd-cmesh90                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh91                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh92                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh93                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh94                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh95                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh96                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh97                                                 7m25s ago      never        0       no error   
  remote-etcd-cmesh98                                                 7m25s ago      never        0       no error   
  resolve-identity-1452                                               2m36s ago      never        0       no error   
  resolve-identity-1626                                               3m52s ago      never        0       no error   
  resolve-identity-1732                                               3m51s ago      never        0       no error   
  resolve-identity-2384                                               3m51s ago      never        0       no error   
  resolve-identity-2527                                               3m51s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-7f5c896f94-hq45n   7m36s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-j9446                  13m51s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-n2mlv                  13m51s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      13m52s ago     never        0       no error   
  sync-policymap-1452                                                 7m36s ago      never        0       no error   
  sync-policymap-1626                                                 13m51s ago     never        0       no error   
  sync-policymap-1732                                                 13m47s ago     never        0       no error   
  sync-policymap-2384                                                 13m47s ago     never        0       no error   
  sync-policymap-2527                                                 13m47s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (1452)                                   6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1732)                                   10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2527)                                   11s ago        never        0       no error   
  sync-utime                                                          52s ago        never        0       no error   
  write-cni-file                                                      13m54s ago     never        0       no error   
Proxy Status:            OK, ip 10.98.0.55, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 6488064, max 6553599
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 96.75   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
version:false
use-cilium-internal-ip-for-ipsec:false
tofqdns-pre-cache:
enable-metrics:true
bgp-config-path:/var/lib/cilium/bgp/config.yaml
set-cilium-node-taints:true
tofqdns-endpoint-max-ip-per-hostname:50
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
ingress-secrets-namespace:
cni-exclusive:true
bpf-map-event-buffers:
enable-local-redirect-policy:false
gateway-api-secrets-namespace:
dns-max-ips-per-restored-rule:1000
enable-ip-masq-agent:false
enable-ipsec:false
local-max-addr-scope:252
policy-queue-size:100
proxy-idle-timeout-seconds:60
ipam-default-ip-pool:default
dnsproxy-socket-linger-timeout:10
dnsproxy-lock-timeout:500ms
enable-health-checking:true
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
log-driver:
ipv6-node:auto
hubble-redact-enabled:false
proxy-xff-num-trusted-hops-ingress:0
kvstore-opt:
container-ip-local-reserved-ports:auto
cni-external-routing:false
tofqdns-proxy-port:0
disable-envoy-version-check:false
enable-node-selector-labels:false
policy-audit-mode:false
k8s-service-proxy-name:
enable-hubble:true
bpf-root:/sys/fs/bpf
vtep-mac:
enable-xt-socket-fallback:true
static-cnp-path:
conntrack-gc-interval:0s
enable-cilium-endpoint-slice:false
cmdref:
agent-health-port:9879
ipam-cilium-node-update-rate:15s
hubble-event-queue-size:0
exclude-node-label-patterns:
clustermesh-sync-timeout:1m0s
agent-liveness-update-interval:1s
pprof:false
lib-dir:/var/lib/cilium
bpf-sock-rev-map-max:262144
config-sources:config-map:kube-system/cilium-config
bpf-policy-map-full-reconciliation-interval:15m0s
node-port-mode:snat
enable-policy:default
trace-payloadlen:128
enable-l2-neigh-discovery:true
trace-sock:true
hubble-export-file-path:
k8s-heartbeat-timeout:30s
clustermesh-enable-endpoint-sync:false
custom-cni-conf:false
enable-wireguard:false
ipv4-service-range:auto
http-retry-count:3
ipam-multi-pool-pre-allocation:
cluster-pool-ipv4-cidr:10.98.0.0/16
agent-labels:
endpoint-gc-interval:5m0s
enable-k8s-terminating-endpoint:true
bpf-lb-sock:false
bpf-map-dynamic-size-ratio:0.0025
bpf-lb-external-clusterip:false
kvstore-lease-ttl:15m0s
hubble-recorder-sink-queue-size:1024
bpf-lb-service-map-max:0
allocator-list-timeout:3m0s
cni-chaining-mode:none
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
crd-wait-timeout:5m0s
mesh-auth-spire-admin-socket:
bpf-ct-timeout-regular-tcp-fin:10s
cluster-pool-ipv4-mask-size:24
hubble-skip-unknown-cgroup-ids:true
k8s-client-burst:20
set-cilium-is-up-condition:true
identity-allocation-mode:crd
install-no-conntrack-iptables-rules:false
tofqdns-dns-reject-response-code:refused
enable-tracing:false
bpf-lb-mode:snat
hubble-export-file-max-backups:5
enable-mke:false
k8s-require-ipv4-pod-cidr:false
monitor-aggregation:medium
bpf-lb-dsr-l4-xlate:frontend
node-labels:
enable-recorder:false
dnsproxy-concurrency-limit:0
hubble-metrics:
ipv4-range:auto
enable-runtime-device-detection:true
hubble-drop-events-reasons:auth_required,policy_denied
tunnel-port:0
policy-accounting:true
k8s-api-server:
fqdn-regex-compile-lru-size:1024
cluster-health-port:4240
kvstore-max-consecutive-quorum-errors:2
enable-active-connection-tracking:false
enable-auto-protect-node-port-range:true
max-controller-interval:0
node-port-bind-protection:true
gops-port:9890
kvstore:
http-normalize-path:true
enable-k8s-endpoint-slice:true
tofqdns-min-ttl:0
enable-cilium-api-server-access:
tofqdns-proxy-response-max-delay:100ms
fixed-identity-mapping:
prometheus-serve-addr:
enable-host-firewall:false
enable-ipv4-big-tcp:false
enable-health-check-loadbalancer-ip:false
enable-icmp-rules:true
mke-cgroup-mount:
enable-monitor:true
envoy-secrets-namespace:
annotate-k8s-node:false
k8s-require-ipv6-pod-cidr:false
bpf-fragments-map-max:8192
mesh-auth-rotated-identities-queue-size:1024
enable-ipv4-masquerade:true
cgroup-root:/run/cilium/cgroupv2
enable-host-legacy-routing:false
node-port-algorithm:random
enable-srv6:false
node-port-range:
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
hubble-export-fieldmask:
hubble-disable-tls:false
hubble-redact-kafka-apikey:false
mesh-auth-spiffe-trust-domain:spiffe.cilium
enable-cilium-health-api-server-access:
identity-heartbeat-timeout:30m0s
bpf-neigh-global-max:524288
vtep-mask:
l2-announcements-renew-deadline:5s
ipv6-cluster-alloc-cidr:f00d::/64
monitor-aggregation-interval:5s
enable-k8s:true
allow-localhost:auto
multicast-enabled:false
enable-masquerade-to-route-source:false
enable-sctp:false
enable-ipv6-big-tcp:false
enable-l2-announcements:false
cni-chaining-target:
bpf-lb-sock-terminate-pod-connections:false
hubble-redact-http-urlquery:false
encryption-strict-mode-allow-remote-node-identities:false
hubble-redact-http-headers-allow:
http-request-timeout:3600
bpf-ct-timeout-service-tcp-grace:1m0s
identity-change-grace-period:5s
egress-gateway-reconciliation-trigger-interval:1s
endpoint-queue-size:25
max-connected-clusters:255
enable-svc-source-range-check:true
direct-routing-device:
operator-api-serve-addr:127.0.0.1:9234
enable-bpf-clock-probe:false
label-prefix-file:
enable-well-known-identities:false
mtu:0
policy-trigger-interval:1s
egress-multi-home-ip-rule-compat:false
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
hubble-recorder-storage-path:/var/run/cilium/pcaps
envoy-base-id:0
bpf-ct-timeout-service-any:1m0s
restore:true
policy-cidr-match-mode:
tofqdns-enable-dns-compression:true
egress-gateway-policy-map-max:16384
proxy-prometheus-port:0
encrypt-interface:
enable-bpf-tproxy:false
srv6-encap-mode:reduced
prepend-iptables-chains:true
bpf-lb-sock-hostns-only:false
proxy-portrange-max:20000
enable-route-mtu-for-cni-chaining:false
enable-k8s-networkpolicy:true
remove-cilium-node-taints:true
bpf-ct-timeout-regular-any:1m0s
http-idle-timeout:0
enable-identity-mark:true
bpf-lb-rss-ipv4-src-cidr:
clustermesh-config:/var/lib/cilium/clustermesh/
k8s-client-connection-keep-alive:30s
proxy-xff-num-trusted-hops-egress:0
auto-create-cilium-node-resource:true
controller-group-metrics:
bpf-lb-maglev-table-size:16381
mesh-auth-mutual-connect-timeout:5s
ip-masq-agent-config-path:/etc/config/ip-masq-agent
enable-local-node-route:true
hubble-prefer-ipv6:false
enable-stale-cilium-endpoint-cleanup:true
enable-custom-calls:false
enable-l7-proxy:true
conntrack-gc-max-interval:0s
kvstore-periodic-sync:5m0s
enable-unreachable-routes:false
clustermesh-ip-identities-sync-timeout:1m0s
k8s-client-connection-timeout:30s
routing-mode:tunnel
enable-pmtu-discovery:false
enable-external-ips:false
bgp-announce-lb-ip:false
ipv4-service-loopback-address:169.254.42.1
ipv6-range:auto
mesh-auth-signal-backoff-duration:1s
clustermesh-enable-mcs-api:false
tofqdns-max-deferred-connection-deletes:10000
vtep-cidr:
external-envoy-proxy:true
nodes-gc-interval:5m0s
auto-direct-node-routes:false
enable-ingress-controller:false
proxy-gid:1337
disable-endpoint-crd:false
enable-ipsec-key-watcher:true
proxy-max-connection-duration-seconds:0
bgp-announce-pod-cidr:false
enable-vtep:false
bpf-ct-timeout-regular-tcp:2h13m20s
enable-nat46x64-gateway:false
hubble-export-denylist:
enable-bpf-masquerade:false
monitor-aggregation-flags:all
k8s-namespace:kube-system
bpf-lb-dsr-dispatch:opt
disable-iptables-feeder-rules:
enable-tcx:true
hubble-drop-events-interval:2m0s
enable-ipv4-egress-gateway:false
service-no-backend-response:reject
hubble-export-allowlist:
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
hubble-metrics-server:
proxy-max-requests-per-connection:0
unmanaged-pod-watcher-interval:15
state-dir:/var/run/cilium
synchronize-k8s-nodes:true
bpf-lb-source-range-map-max:0
bpf-policy-map-max:16384
identity-restore-grace-period:30s
bpf-ct-global-tcp-max:524288
allow-icmp-frag-needed:true
encryption-strict-mode-cidr:
ipv6-service-range:auto
bpf-nat-global-max:524288
cni-log-file:/var/run/cilium/cilium-cni.log
hubble-event-buffer-capacity:4095
endpoint-bpf-prog-watchdog-interval:30s
operator-prometheus-serve-addr::9963
bpf-ct-timeout-service-tcp:2h13m20s
ipv6-mcast-device:
dnsproxy-insecure-skip-transparent-mode-check:false
egress-masquerade-interfaces:ens+
enable-ipv4-fragment-tracking:true
proxy-admin-port:0
hubble-redact-http-userinfo:true
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
bpf-lb-rev-nat-map-max:0
http-max-grpc-timeout:0
wireguard-persistent-keepalive:0s
datapath-mode:veth
mesh-auth-mutual-listener-port:0
enable-l2-pod-announcements:false
ipv6-pod-subnets:
enable-bgp-control-plane:false
route-metric:0
enable-hubble-recorder-api:true
l2-pod-announcements-interface:
bpf-ct-global-any-max:262144
enable-encryption-strict-mode:false
config-dir:/tmp/cilium/config-map
kvstore-connectivity-timeout:2m0s
enable-endpoint-health-checking:true
envoy-log:
bpf-lb-map-max:65536
tunnel-protocol:vxlan
hubble-flowlogs-config-path:
vlan-bpf-bypass:
hubble-export-file-max-size-mb:10
bypass-ip-availability-upon-restore:false
local-router-ipv6:
enable-gateway-api:false
dns-policy-unload-on-shutdown:false
join-cluster:false
enable-xdp-prefilter:false
bpf-lb-acceleration:disabled
enable-high-scale-ipcache:false
node-port-acceleration:disabled
enable-k8s-api-discovery:false
enable-session-affinity:false
bpf-ct-timeout-regular-tcp-syn:1m0s
iptables-lock-timeout:5s
log-opt:
ipsec-key-rotation-duration:5m0s
labels:
tofqdns-idle-connection-grace-period:0s
cluster-id:99
read-cni-conf:
enable-node-port:false
http-retry-timeout:0
local-router-ipv4:
api-rate-limit:
socket-path:/var/run/cilium/cilium.sock
bpf-node-map-max:16384
kube-proxy-replacement-healthz-bind-address:
enable-ipv6:false
dnsproxy-lock-count:131
devices:
enable-health-check-nodeport:true
arping-refresh-period:30s
max-internal-timer-delay:0s
pprof-address:localhost
preallocate-bpf-maps:false
ipv4-native-routing-cidr:
kube-proxy-replacement:false
bpf-lb-algorithm:random
bpf-auth-map-max:524288
enable-service-topology:false
derive-masq-ip-addr-from-device:
procfs:/host/proc
dnsproxy-enable-transparent-mode:true
enable-wireguard-userspace-fallback:false
bpf-lb-maglev-map-max:0
nat-map-stats-entries:32
keep-config:false
cilium-endpoint-gc-interval:5m0s
use-full-tls-context:false
bpf-filter-priority:1
ipv4-node:auto
force-device-detection:false
enable-host-port:false
nodeport-addresses:
vtep-endpoint:
log-system-load:false
install-iptables-rules:true
enable-ipsec-encrypted-overlay:false
cluster-name:cmesh99
cflags:
ipam:cluster-pool
enable-ipip-termination:false
enable-ipv6-ndp:false
mesh-auth-queue-size:1024
hubble-monitor-events:
ipv4-pod-subnets:
envoy-config-timeout:2m0s
ipsec-key-file:
exclude-local-address:
k8s-sync-timeout:3m0s
hubble-export-file-compress:false
l2-announcements-retry-period:2s
envoy-keep-cap-netbindservice:false
hubble-drop-events:false
enable-ipsec-xfrm-state-caching:true
proxy-connect-timeout:2
debug-verbose:
hubble-redact-http-headers-deny:
certificates-directory:/var/run/cilium/certs
metrics:
disable-external-ip-mitigation:false
hubble-socket-path:/var/run/cilium/hubble.sock
k8s-kubeconfig-path:
iptables-random-fully:false
monitor-queue-size:0
k8s-service-cache-size:128
enable-endpoint-routes:false
dnsproxy-concurrency-processing-grace-period:0s
bpf-events-drop-enabled:true
debug:false
proxy-portrange-min:10000
k8s-client-qps:10
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
envoy-config-retry-interval:15s
l2-announcements-lease-duration:15s
mesh-auth-enabled:true
hubble-listen-address::4244
ipv6-native-routing-cidr:
enable-ipv4:true
config:
bpf-events-policy-verdict-enabled:true
bpf-events-trace-enabled:true
bpf-lb-affinity-map-max:0
enable-ipv6-masquerade:true
pprof-port:6060
bpf-lb-rss-ipv6-src-cidr:
identity-gc-interval:15m0s
enable-bandwidth-manager:false
enable-envoy-config:false
mesh-auth-gc-interval:5m0s
enable-bbr:false
encrypt-node:false
bpf-lb-service-backend-map-max:0
direct-routing-skip-unreachable:false
nat-map-stats-interval:30s
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
1452       Disabled           Disabled          6522857    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.98.0.167   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh99                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
1626       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                
                                                           reserved:host                                                                                             
1732       Disabled           Disabled          6545166    k8s:eks.amazonaws.com/component=coredns                                             10.98.0.210   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh99                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
2384       Disabled           Disabled          4          reserved:health                                                                     10.98.0.126   ready   
2527       Disabled           Disabled          6545166    k8s:eks.amazonaws.com/component=coredns                                             10.98.0.216   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh99                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
```

#### BPF Policy Get 1452

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3878300   36688     0        
Allow    Ingress     1          ANY          NONE         disabled    3834658   37728     0        
Allow    Egress      0          ANY          NONE         disabled    4990940   46270     0        

```


#### BPF CT List 1452

```
Invalid argument: unknown type 1452
```


#### Endpoint Get 1452

```
[
  {
    "id": 1452,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1452-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c659e6ad-9104-47d8-a47f-2a41e5164c46"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1452",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:44.980Z",
            "success-count": 2
          },
          "uuid": "8307bf3f-1ecb-481f-9a7f-f0d64ba0abec"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-7f5c896f94-hq45n",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:44.978Z",
            "success-count": 1
          },
          "uuid": "23345f80-20cd-4a6c-af88-798ba6df7a02"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1452",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:45.056Z",
            "success-count": 1
          },
          "uuid": "eed9ae3e-c6d4-43a5-a549-f270960b3288"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1452)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:15.035Z",
            "success-count": 47
          },
          "uuid": "d50c9b21-e42e-4146-b1cf-8aa09d65daec"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "0cb47ea93de9ff6f7b3af942e295919a78b4aba09ce2c37b9bc57c938079724d:eth0",
        "container-id": "0cb47ea93de9ff6f7b3af942e295919a78b4aba09ce2c37b9bc57c938079724d",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-7f5c896f94-hq45n",
        "pod-name": "kube-system/clustermesh-apiserver-7f5c896f94-hq45n"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6522857,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh99",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7f5c896f94"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh99",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:58Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.98.0.167",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "1a:76:bb:a1:50:01",
        "interface-index": 18,
        "interface-name": "lxc5ef227f39400",
        "mac": "da:2a:93:58:35:8a"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6522857,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6522857,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1452

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1452

```
Timestamp              Status   State                   Message
2024-10-25T10:21:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:58Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:44Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:44Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:44Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 6522857

```
ID        LABELS
6522857   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh99
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1626

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1626

```
Invalid argument: unknown type 1626
```


#### Endpoint Get 1626

```
[
  {
    "id": 1626,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1626-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5f8888cb-f284-482e-9dc8-ccb6ac16fb2f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1626",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:29.504Z",
            "success-count": 3
          },
          "uuid": "dd97d69a-7127-4092-aa2f-46f9d71d42d0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1626",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:30.640Z",
            "success-count": 1
          },
          "uuid": "c7469a06-125e-4f56-a0e3-023467173370"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:58Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "2a:c0:4d:f2:7c:38",
        "interface-name": "cilium_host",
        "mac": "2a:c0:4d:f2:7c:38"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1626

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1626

```
Timestamp              Status   State                   Message
2024-10-25T10:21:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:58Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:15:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:34Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:15:32Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:31Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:15:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:15:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:29Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:29Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:29Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 1732

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    337371   3029      0        
Allow    Ingress     1          ANY          NONE         disabled    78380    901       0        
Allow    Egress      0          ANY          NONE         disabled    64497    617       0        

```


#### BPF CT List 1732

```
Invalid argument: unknown type 1732
```


#### Endpoint Get 1732

```
[
  {
    "id": 1732,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1732-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5c84d163-d5d5-466e-b85e-36f739072aa2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1732",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:30.789Z",
            "success-count": 3
          },
          "uuid": "b0e0efe0-2b5d-4f20-b46e-bb066879ea46"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-n2mlv",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:30.788Z",
            "success-count": 1
          },
          "uuid": "80714937-3e7e-4444-8f6a-291e48d84c03"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1732",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:34.081Z",
            "success-count": 1
          },
          "uuid": "5df53523-2c82-4010-8eb8-03ed1ad14379"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1732)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:20.861Z",
            "success-count": 85
          },
          "uuid": "89dcb1d9-4e4d-46cd-9cd7-166a57169ccd"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "60a2654a2dfebd7fb0b2998b0bf209eacb119aac2dab3d15e234e02c5a6f0a43:eth0",
        "container-id": "60a2654a2dfebd7fb0b2998b0bf209eacb119aac2dab3d15e234e02c5a6f0a43",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-n2mlv",
        "pod-name": "kube-system/coredns-cc6ccd49c-n2mlv"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6545166,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh99",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh99",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:58Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.98.0.210",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "56:44:64:19:a0:2d",
        "interface-index": 14,
        "interface-name": "lxcfd6d5a9a04b6",
        "mac": "86:7f:63:67:9e:b2"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6545166,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6545166,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1732

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1732

```
Timestamp              Status   State                   Message
2024-10-25T10:21:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:58Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:34Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:31Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:15:31Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:30Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:30Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 6545166

```
ID        LABELS
6545166   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh99
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 2384

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    440364   5611      0        
Allow    Ingress     1          ANY          NONE         disabled    12050    143       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 2384

```
Invalid argument: unknown type 2384
```


#### Endpoint Get 2384

```
[
  {
    "id": 2384,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2384-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "bb53c4c3-1c85-4337-88e6-8d7cbaf70d49"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2384",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:30.586Z",
            "success-count": 3
          },
          "uuid": "69045f2e-9b1e-4d16-b9dd-b8df95671a96"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2384",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:34.036Z",
            "success-count": 1
          },
          "uuid": "19485117-cce5-4387-beaf-a639e0c4bcf3"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:58Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.98.0.126",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "16:e3:a7:35:7f:a6",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "f6:cd:75:55:f8:ca"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2384

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2384

```
Timestamp              Status   State                   Message
2024-10-25T10:21:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:58Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:34Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:31Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:15:31Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:30Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:30Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:29Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 2527

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    342183   3095      0        
Allow    Ingress     1          ANY          NONE         disabled    77984    895       0        
Allow    Egress      0          ANY          NONE         disabled    66396    638       0        

```


#### BPF CT List 2527

```
Invalid argument: unknown type 2527
```


#### Endpoint Get 2527

```
[
  {
    "id": 2527,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2527-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "287ee72c-2bd8-44d2-af57-85ae21512fef"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2527",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:30.737Z",
            "success-count": 3
          },
          "uuid": "9e6f210a-9940-42ee-b0cd-72389807a4f9"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-j9446",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:30.735Z",
            "success-count": 1
          },
          "uuid": "51d3348c-e082-4afa-a4e6-a14f2723951a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2527",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:34.041Z",
            "success-count": 1
          },
          "uuid": "5dd4160c-4d78-4586-9a1e-a133c4ebf353"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2527)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:20.833Z",
            "success-count": 85
          },
          "uuid": "a06d3cdc-49e1-41b9-bbfd-3acd6d72b198"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "61d17b7d374250aae06b5a4dfe4d94ee66be2745d0bfd36fc6e98dddcf7f9bf7:eth0",
        "container-id": "61d17b7d374250aae06b5a4dfe4d94ee66be2745d0bfd36fc6e98dddcf7f9bf7",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-j9446",
        "pod-name": "kube-system/coredns-cc6ccd49c-j9446"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6545166,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh99",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh99",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:58Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.98.0.216",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "5e:98:79:97:6d:26",
        "interface-index": 12,
        "interface-name": "lxc50eaa77db4cf",
        "mac": "de:52:ef:05:d6:d3"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6545166,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6545166,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2527

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2527

```
Timestamp              Status    State                   Message
2024-10-25T10:21:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:58Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:21:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:15Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:15Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:15Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:15Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:14Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:14Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:14Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:14Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:34Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:34Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:32Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:31Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:15:31Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:30Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:30Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:15:30Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:30Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 6545166

```
ID        LABELS
6545166   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh99
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.157.132:443 (active)    
                                          2 => 172.31.244.104:443 (active)    
2    10.100.137.62:443     ClusterIP      1 => 172.31.173.171:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.98.0.210:53 (active)        
                                          2 => 10.98.0.216:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.98.0.210:9153 (active)      
                                          2 => 10.98.0.216:9153 (active)      
5    10.100.254.199:2379   ClusterIP      1 => 10.98.0.167:2379 (active)      
```

#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 33635660                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 33635660                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 33635660                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d400000 rw-p 00000000 00:00 0 
400d400000-4010000000 ---p 00000000 00:00 0 
ffff6332a000-ffff63530000 rw-p 00000000 00:00 0 
ffff63538000-ffff63659000 rw-p 00000000 00:00 0 
ffff63659000-ffff6369a000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff6369a000-ffff636db000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff636db000-ffff636dd000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff636dd000-ffff636df000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff636df000-ffff63ce6000 rw-p 00000000 00:00 0 
ffff63ce6000-ffff63de6000 rw-p 00000000 00:00 0 
ffff63de6000-ffff63df7000 rw-p 00000000 00:00 0 
ffff63df7000-ffff65df7000 rw-p 00000000 00:00 0 
ffff65df7000-ffff65e77000 ---p 00000000 00:00 0 
ffff65e77000-ffff65e78000 rw-p 00000000 00:00 0 
ffff65e78000-ffff85e77000 ---p 00000000 00:00 0 
ffff85e77000-ffff85e78000 rw-p 00000000 00:00 0 
ffff85e78000-ffffa5e07000 ---p 00000000 00:00 0 
ffffa5e07000-ffffa5e08000 rw-p 00000000 00:00 0 
ffffa5e08000-ffffa9df9000 ---p 00000000 00:00 0 
ffffa9df9000-ffffa9dfa000 rw-p 00000000 00:00 0 
ffffa9dfa000-ffffaa5f7000 ---p 00000000 00:00 0 
ffffaa5f7000-ffffaa5f8000 rw-p 00000000 00:00 0 
ffffaa5f8000-ffffaa6f7000 ---p 00000000 00:00 0 
ffffaa6f7000-ffffaa757000 rw-p 00000000 00:00 0 
ffffaa757000-ffffaa759000 r--p 00000000 00:00 0                          [vvar]
ffffaa759000-ffffaa75a000 r-xp 00000000 00:00 0                          [vdso]
ffffc2617000-ffffc2638000 rw-p 00000000 00:00 0                          [stack]

```

