CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4b92cca1_4249_4fcc_9026_744a13945969.slice/cri-containerd-53c970a2776e51467a073861a578f0ec38ce37921079a309c0ea27ed84f72ec9.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4b92cca1_4249_4fcc_9026_744a13945969.slice/cri-containerd-fc7d818cb958c80a1ad304efe23fa0cc128b757a647fce081f9025b07ede238e.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod83a57e1b_796a_4e54_91ea_f4eaf243012f.slice/cri-containerd-86d40c7096e93d3e976c965d2c0b14ee6b5dc93597880c8b7c3e417dfe8b0950.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod83a57e1b_796a_4e54_91ea_f4eaf243012f.slice/cri-containerd-60a2654a2dfebd7fb0b2998b0bf209eacb119aac2dab3d15e234e02c5a6f0a43.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaf0eb382_9ba1_4914_bccc_32c926bf4f58.slice/cri-containerd-1e72e21e9228594441b3366c4cf1bc977188291acd8525c4f7f33ee241cf3fbf.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaf0eb382_9ba1_4914_bccc_32c926bf4f58.slice/cri-containerd-61d17b7d374250aae06b5a4dfe4d94ee66be2745d0bfd36fc6e98dddcf7f9bf7.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95eb83e5_65a6_47f5_b11f_dd9f1b875ffd.slice/cri-containerd-8d668be5ea31991068a0824a05efa09d865799d80d30979e336eb2e0bbec13de.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95eb83e5_65a6_47f5_b11f_dd9f1b875ffd.slice/cri-containerd-e906856a0b08162edc86bd83cf89a025bfa9bfe66d96b5d094286545cb195cff.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8a85fdfb_3927_4f27_ade0_2fc37a7d60ce.slice/cri-containerd-b17ced65303f0c68fb71bb7355afb6208ebefa329eae8a37823c98ad4018bee9.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8a85fdfb_3927_4f27_ade0_2fc37a7d60ce.slice/cri-containerd-822f26f8c72a38b1b1166cfd0378b7fb24ec329df13c7e20b87368f209ad22b7.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podabb8460f_86d9_4207_8bc3_2a76abe3ae9c.slice/cri-containerd-23abc6a8f1a5ee2882a9233f9384744d9d389d5522a1a87a4df2a3eabcd7cb4e.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podabb8460f_86d9_4207_8bc3_2a76abe3ae9c.slice/cri-containerd-2c0abd0d65916dd872dc344c047d978db91e7d5f9df022aefb8be38ef77ebdcf.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod34ed0e55_bac9_4f6d_8dcb_2a9d100b6d02.slice/cri-containerd-0cb47ea93de9ff6f7b3af942e295919a78b4aba09ce2c37b9bc57c938079724d.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod34ed0e55_bac9_4f6d_8dcb_2a9d100b6d02.slice/cri-containerd-4d3a7a46b8d9e8ab0af4aee085b34c6be6e989d355fab8cc1dbf4f92b7df5a8a.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod34ed0e55_bac9_4f6d_8dcb_2a9d100b6d02.slice/cri-containerd-49a8cbd90846928d6a94693f097d0371354bc05082ab31a54ca45cae4b0b116b.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod34ed0e55_bac9_4f6d_8dcb_2a9d100b6d02.slice/cri-containerd-9f3a765c18f371319e77e2a6c9660b23eb60a35eddd1ee0ffef802b6147f0d74.scope
    674      cgroup_device   multi                                          
