alloc: 77.47MB (81230440 bytes)
total-alloc: 1.48GB (1590304024 bytes)
sys: 214.63MB (225060180 bytes)
lookups: 0
mallocs: 50132364
frees: 49601684
heap-alloc: 77.47MB (81230440 bytes)
heap-sys: 168.66MB (176857088 bytes)
heap-idle: 42.29MB (44343296 bytes)
heap-in-use: 126.38MB (132513792 bytes)
heap-released: 1.50MB (1572864 bytes)
heap-objects: 530680
stack-in-use: 35.31MB (37027840 bytes)
stack-sys: 35.31MB (37027840 bytes)
stack-mspan-inuse: 2.05MB (2145920 bytes)
stack-mspan-sys: 2.61MB (2741760 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 940.60KB (963177 bytes)
gc-sys: 5.17MB (5425552 bytes)
next-gc: when heap-alloc >= 148.99MB (156231848 bytes)
last-gc: 2024-10-25 10:29:18.888374956 +0000 UTC
gc-pause-total: 19.992631ms
gc-pause: 82882
gc-pause-end: 1729852158888374956
num-gc: 75
num-forced-gc: 0
gc-cpu-fraction: 0.0004443864279249809
enable-gc: true
debug-gc: false
