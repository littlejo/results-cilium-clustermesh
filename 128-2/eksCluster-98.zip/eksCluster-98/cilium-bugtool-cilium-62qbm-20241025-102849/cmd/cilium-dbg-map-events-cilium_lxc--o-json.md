{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:29.345Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.145.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:29.345Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.173.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:29.345Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:34.034Z",
  "value": "id=2384  sec_id=4     flags=0x0000 ifindex=10  mac=F6:CD:75:55:F8:CA nodemac=16:E3:A7:35:7F:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:34.040Z",
  "value": "id=2527  sec_id=6545166 flags=0x0000 ifindex=12  mac=DE:52:EF:05:D6:D3 nodemac=5E:98:79:97:6D:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:34.078Z",
  "value": "id=1732  sec_id=6545166 flags=0x0000 ifindex=14  mac=86:7F:63:67:9E:B2 nodemac=56:44:64:19:A0:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:34.123Z",
  "value": "id=2384  sec_id=4     flags=0x0000 ifindex=10  mac=F6:CD:75:55:F8:CA nodemac=16:E3:A7:35:7F:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:14.349Z",
  "value": "id=2527  sec_id=6545166 flags=0x0000 ifindex=12  mac=DE:52:EF:05:D6:D3 nodemac=5E:98:79:97:6D:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:14.350Z",
  "value": "id=1732  sec_id=6545166 flags=0x0000 ifindex=14  mac=86:7F:63:67:9E:B2 nodemac=56:44:64:19:A0:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:14.350Z",
  "value": "id=2384  sec_id=4     flags=0x0000 ifindex=10  mac=F6:CD:75:55:F8:CA nodemac=16:E3:A7:35:7F:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:14.381Z",
  "value": "id=1679  sec_id=6522857 flags=0x0000 ifindex=16  mac=C6:0E:49:6E:12:EE nodemac=DA:8B:76:69:0E:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:15.349Z",
  "value": "id=1732  sec_id=6545166 flags=0x0000 ifindex=14  mac=86:7F:63:67:9E:B2 nodemac=56:44:64:19:A0:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:15.349Z",
  "value": "id=2384  sec_id=4     flags=0x0000 ifindex=10  mac=F6:CD:75:55:F8:CA nodemac=16:E3:A7:35:7F:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:15.349Z",
  "value": "id=2527  sec_id=6545166 flags=0x0000 ifindex=12  mac=DE:52:EF:05:D6:D3 nodemac=5E:98:79:97:6D:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:15.349Z",
  "value": "id=1679  sec_id=6522857 flags=0x0000 ifindex=16  mac=C6:0E:49:6E:12:EE nodemac=DA:8B:76:69:0E:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:45.056Z",
  "value": "id=1452  sec_id=6522857 flags=0x0000 ifindex=18  mac=DA:2A:93:58:35:8A nodemac=1A:76:BB:A1:50:01"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.98.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:55.550Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:55.911Z",
  "value": "id=2527  sec_id=6545166 flags=0x0000 ifindex=12  mac=DE:52:EF:05:D6:D3 nodemac=5E:98:79:97:6D:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:55.912Z",
  "value": "id=1732  sec_id=6545166 flags=0x0000 ifindex=14  mac=86:7F:63:67:9E:B2 nodemac=56:44:64:19:A0:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:55.912Z",
  "value": "id=1452  sec_id=6522857 flags=0x0000 ifindex=18  mac=DA:2A:93:58:35:8A nodemac=1A:76:BB:A1:50:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:55.913Z",
  "value": "id=2384  sec_id=4     flags=0x0000 ifindex=10  mac=F6:CD:75:55:F8:CA nodemac=16:E3:A7:35:7F:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:56.911Z",
  "value": "id=1452  sec_id=6522857 flags=0x0000 ifindex=18  mac=DA:2A:93:58:35:8A nodemac=1A:76:BB:A1:50:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:56.912Z",
  "value": "id=2384  sec_id=4     flags=0x0000 ifindex=10  mac=F6:CD:75:55:F8:CA nodemac=16:E3:A7:35:7F:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:56.912Z",
  "value": "id=2527  sec_id=6545166 flags=0x0000 ifindex=12  mac=DE:52:EF:05:D6:D3 nodemac=5E:98:79:97:6D:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:56.913Z",
  "value": "id=1732  sec_id=6545166 flags=0x0000 ifindex=14  mac=86:7F:63:67:9E:B2 nodemac=56:44:64:19:A0:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:57.910Z",
  "value": "id=2527  sec_id=6545166 flags=0x0000 ifindex=12  mac=DE:52:EF:05:D6:D3 nodemac=5E:98:79:97:6D:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:57.910Z",
  "value": "id=1732  sec_id=6545166 flags=0x0000 ifindex=14  mac=86:7F:63:67:9E:B2 nodemac=56:44:64:19:A0:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:57.910Z",
  "value": "id=1452  sec_id=6522857 flags=0x0000 ifindex=18  mac=DA:2A:93:58:35:8A nodemac=1A:76:BB:A1:50:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:57.911Z",
  "value": "id=2384  sec_id=4     flags=0x0000 ifindex=10  mac=F6:CD:75:55:F8:CA nodemac=16:E3:A7:35:7F:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:58.910Z",
  "value": "id=1452  sec_id=6522857 flags=0x0000 ifindex=18  mac=DA:2A:93:58:35:8A nodemac=1A:76:BB:A1:50:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:58.910Z",
  "value": "id=2384  sec_id=4     flags=0x0000 ifindex=10  mac=F6:CD:75:55:F8:CA nodemac=16:E3:A7:35:7F:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:58.910Z",
  "value": "id=2527  sec_id=6545166 flags=0x0000 ifindex=12  mac=DE:52:EF:05:D6:D3 nodemac=5E:98:79:97:6D:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:58.911Z",
  "value": "id=1732  sec_id=6545166 flags=0x0000 ifindex=14  mac=86:7F:63:67:9E:B2 nodemac=56:44:64:19:A0:2D"
}

