USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         640  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root         632  0.0  0.1 1228744 4036 ?        Ssl  10:28   0:00 /bin/gops memstats 1
root         631  2.0  0.4 1240432 16568 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         679  0.0  0.0      0     0 ?        Z    10:28   0:00  \_ [cat] <defunct>
root         680  0.0  0.0   6408  1636 ?        R    10:28   0:00  \_ ps auxfw
root           1  3.5  7.5 1538100 297212 ?      Ssl  10:16   0:25 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.0  0.1 1228848 6892 ?        Sl   10:16   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
