1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:14:0a:95:d7:87 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.189.5/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2796sec preferred_lft 2796sec
    inet6 fe80::414:aff:fe95:d787/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:a3:ee:3c:f1:c7 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.175.175/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4a3:eeff:fe3c:f1c7/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:f3:a4:e0:bd:9e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::bcf3:a4ff:fee0:bd9e/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:82:c9:4c:14:e6 brd ff:ff:ff:ff:ff:ff
    inet 10.34.0.2/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::2082:c9ff:fe4c:14e6/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 3e:7d:7d:80:03:54 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3c7d:7dff:fe80:354/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:4a:01:91:9e:48 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::a84a:1ff:fe91:9e48/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc2f63dbc1315c@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:f3:2d:a4:1b:39 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::4f3:2dff:fea4:1b39/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcb0e3b5dff904@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:05:1b:1c:2f:73 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::1005:1bff:fe1c:2f73/64 scope link 
       valid_lft forever preferred_lft forever
18: lxce0b8099d2c6e@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:6c:a2:5e:5f:28 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::286c:a2ff:fe5e:5f28/64 scope link 
       valid_lft forever preferred_lft forever
