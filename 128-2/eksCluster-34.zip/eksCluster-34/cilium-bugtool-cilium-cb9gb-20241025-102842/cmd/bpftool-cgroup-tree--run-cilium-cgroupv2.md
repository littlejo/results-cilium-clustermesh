CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4f33ead0_31eb_4ff9_944b_72f8fbf012a0.slice/cri-containerd-5ab2a15ae80a9f0ca2df52b3a41053b944b405f39fa473384a19403d14ddbe8e.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4f33ead0_31eb_4ff9_944b_72f8fbf012a0.slice/cri-containerd-5c69d14f8f69b95eb9b1e91725bb8f298f5d632b5341b32f1488bc0915c0dd51.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod758c9aef_48cb_4dcd_aeec_61da8f7ef12f.slice/cri-containerd-4c166a60c012c3f992945000b06feb6af651549969598deba89845323225cce2.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod758c9aef_48cb_4dcd_aeec_61da8f7ef12f.slice/cri-containerd-631d85e4a5340ddb08fb4f18cec3fe584b6ff1c55437b5649f8c7e817147970d.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddd96afa4_1605_4c35_b54d_f20d56acec76.slice/cri-containerd-57513250cfb9a5a0d04aaaa922879422906788beac1f54e0bc818b920cba7e83.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddd96afa4_1605_4c35_b54d_f20d56acec76.slice/cri-containerd-ea5d9b00e13894b939cf79a5f25c01d4b9c89f49d796dad18a9a881f1fb920a4.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3159ff1f_d501_430a_9e47_cc25cbfb7e95.slice/cri-containerd-cbc49f397d52bb22cbe3bf7a5dc2e61b72de73d0d712fdb6777cfe78f1752d79.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3159ff1f_d501_430a_9e47_cc25cbfb7e95.slice/cri-containerd-c38575546a63debfd021247605592300c0e53a35f101c0ab94b3ddb183448554.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec00dda3_1384_40ea_bc9d_259d26eceed9.slice/cri-containerd-28030e1beaa50a885e78926ac70e3aca78b91d67d6e5fb3f0d5b0821b92df9b5.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec00dda3_1384_40ea_bc9d_259d26eceed9.slice/cri-containerd-5cbd536e1065dd49eebb4654729ebd69a13be9d3bbc58b3b5adcda4f39487537.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec00dda3_1384_40ea_bc9d_259d26eceed9.slice/cri-containerd-bd7ba4eeafd424b24fe1bd65f1382c49e5389c39661c30acd0905ad987420a78.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec00dda3_1384_40ea_bc9d_259d26eceed9.slice/cri-containerd-cdf8bc5ee026ad34001b01c60b86f0ad14f642dd0ce91cf4fd0cde83358d27bd.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda094780b_1ebb_4bb4_bfe5_17aa1bdbc413.slice/cri-containerd-e6dc4e4c2013bf92334d8db1e1d074fe730845bfad2a1e6a6a76519032998ced.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda094780b_1ebb_4bb4_bfe5_17aa1bdbc413.slice/cri-containerd-9ab53e1ecc991ca29336e121cdcac85dd43ab1be7680bf24e22ea38c251bfa17.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1bf94302_b6f6_4427_8b98_adf7913e5f6a.slice/cri-containerd-0655d47a690d28523c0fee6d5f33208b5874d4690b4ec2aacc494e8974c7cb48.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1bf94302_b6f6_4427_8b98_adf7913e5f6a.slice/cri-containerd-b04abd2c2c88536eef53229f9eced22ce47539f7c8ed6b5c04e3606ef4a29cbc.scope
    102      cgroup_device   multi                                          
