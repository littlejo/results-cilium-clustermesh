Endpoint ID: 977
Path: /sys/fs/bpf/tc/globals/cilium_policy_00977

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2505
Path: /sys/fs/bpf/tc/globals/cilium_policy_02505

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    429092   5459      0        
Allow    Ingress     1          ANY          NONE         disabled    10526    123       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2761
Path: /sys/fs/bpf/tc/globals/cilium_policy_02761

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3917773   37003     0        
Allow    Ingress     1          ANY          NONE         disabled    3700552   36285     0        
Allow    Egress      0          ANY          NONE         disabled    4685356   43352     0        


Endpoint ID: 3033
Path: /sys/fs/bpf/tc/globals/cilium_policy_03033

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69269   795       0        
Allow    Egress      0          ANY          NONE         disabled    13177   136       0        


Endpoint ID: 3112
Path: /sys/fs/bpf/tc/globals/cilium_policy_03112

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69335   796       0        
Allow    Egress      0          ANY          NONE         disabled    12807   131       0        


