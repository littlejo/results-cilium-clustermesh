top - 10:28:43 up 13 min,  0 users,  load average: 0.09, 0.17, 0.13
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 20.0 us, 30.0 sy,  0.0 ni, 50.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    754.7 free,    938.6 used,   2142.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2728.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 297212  78080 S   6.7   7.6   0:25.55 cilium-+
    631 root      20   0 1240432  16772  11480 S   6.7   0.4   0:00.03 cilium-+
    394 root      20   0 1228848   6892   3836 S   0.0   0.2   0:00.26 cilium-+
    632 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    640 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    697 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    715 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
