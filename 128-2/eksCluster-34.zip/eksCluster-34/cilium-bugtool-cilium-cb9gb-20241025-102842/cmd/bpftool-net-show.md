xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 562
ens6(5) clsact/ingress cil_from_netdev-ens6 id 563
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 549
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 543
cilium_host(7) clsact/egress cil_from_host-cilium_host id 539
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 583
lxc2f63dbc1315c(12) clsact/ingress cil_from_container-lxc2f63dbc1315c id 529
lxcb0e3b5dff904(14) clsact/ingress cil_from_container-lxcb0e3b5dff904 id 573
lxce0b8099d2c6e(18) clsact/ingress cil_from_container-lxce0b8099d2c6e id 643

flow_dissector:

netfilter:

