32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:15:12+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:15:12+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:15:13+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:15:13+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:15:13+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:15:13+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:15:27+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:37+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:16:48+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 124
482: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:16:48+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 125
483: sched_cls  name tail_handle_ipv4  tag 1242859dc231984d  gpl
	loaded_at 2024-10-25T10:16:48+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 126
484: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:16:48+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
518: sched_cls  name tail_ipv4_ct_egress  tag da43c538e83ad4a6  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 168
519: sched_cls  name tail_handle_arp  tag d65344e77e236392  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 169
520: sched_cls  name tail_handle_ipv4_cont  tag f68f8f715c61402a  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 170
521: sched_cls  name __send_drop_notify  tag a4af04e8f9c22c96  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 171
526: sched_cls  name handle_policy  tag 73e5b5260d05d228  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 172
529: sched_cls  name cil_from_container  tag 17b90160ed3c895c  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 179
531: sched_cls  name tail_handle_arp  tag 171bd913da5aea26  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 182
532: sched_cls  name tail_ipv4_to_endpoint  tag 1797101c2db207d4  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,113,40,37,38
	btf_id 180
533: sched_cls  name tail_handle_ipv4  tag 9cd81ec6fd14bc2f  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 183
534: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 185
535: sched_cls  name tail_handle_ipv4  tag f2e6e70f692a3f93  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 184
536: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 187
537: sched_cls  name tail_ipv4_ct_ingress  tag 2f927af33f0ebcb8  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 188
538: sched_cls  name tail_ipv4_to_endpoint  tag 9d5b6fa45927d59c  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 186
539: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,118
	btf_id 191
540: sched_cls  name tail_ipv4_ct_egress  tag da43c538e83ad4a6  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 189
541: sched_cls  name __send_drop_notify  tag aa5e67a0867d1675  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 192
543: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 195
544: sched_cls  name tail_handle_ipv4_from_host  tag 19f3f5240b4a003b  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 196
545: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 197
546: sched_cls  name tail_ipv4_ct_ingress  tag e3b23f5c273a0f9b  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 193
549: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 202
550: sched_cls  name tail_handle_ipv4_from_host  tag 19f3f5240b4a003b  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 203
551: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 204
554: sched_cls  name __send_drop_notify  tag aa5e67a0867d1675  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 207
556: sched_cls  name __send_drop_notify  tag aa5e67a0867d1675  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 210
558: sched_cls  name tail_handle_ipv4_cont  tag f269a3160ccb017a  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 199
560: sched_cls  name tail_handle_ipv4_from_host  tag 19f3f5240b4a003b  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 214
561: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 215
562: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 216
563: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 218
565: sched_cls  name __send_drop_notify  tag aa5e67a0867d1675  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 220
568: sched_cls  name tail_handle_ipv4_from_host  tag 19f3f5240b4a003b  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 223
569: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 224
570: sched_cls  name handle_policy  tag afaa066d448fe758  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 213
571: sched_cls  name __send_drop_notify  tag 3fb6b2abec554f2f  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 225
573: sched_cls  name cil_from_container  tag 90d9b36db3b94fde  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 227
575: sched_cls  name tail_ipv4_to_endpoint  tag 7dbfb6defd94d3a5  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,126,41,82,83,80,100,39,125,40,37,38
	btf_id 230
576: sched_cls  name tail_ipv4_ct_ingress  tag 5f49ac7213190524  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 231
577: sched_cls  name tail_handle_ipv4_cont  tag e71e9c44bfb314ea  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,126,41,100,82,83,39,76,74,77,125,40,37,38,81
	btf_id 232
578: sched_cls  name __send_drop_notify  tag 13bac1b89297c7b8  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 233
579: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 234
580: sched_cls  name tail_handle_arp  tag a2ec79cce401fea9  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,125
	btf_id 235
581: sched_cls  name tail_handle_ipv4  tag f20b246e77f67891  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,125
	btf_id 236
582: sched_cls  name handle_policy  tag 6524643e93a01362  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,125,82,83,126,41,80,100,39,84,75,40,37,38
	btf_id 237
583: sched_cls  name cil_from_container  tag d362c62d5a8c736d  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 125,76
	btf_id 238
584: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,125
	btf_id 239
585: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
588: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
589: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
592: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
593: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
596: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: sched_cls  name tail_handle_ipv4  tag f8fdce1757d743c0  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,143
	btf_id 253
641: sched_cls  name tail_handle_arp  tag 666ab9487fdccf1a  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,143
	btf_id 254
642: sched_cls  name handle_policy  tag ec2a0e0974f8eae5  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,143,82,83,142,41,80,141,39,84,75,40,37,38
	btf_id 255
643: sched_cls  name cil_from_container  tag 1636787f6d487c8c  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 143,76
	btf_id 256
644: sched_cls  name tail_ipv4_ct_ingress  tag 4b7088d1b878614b  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 257
645: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,143
	btf_id 258
647: sched_cls  name tail_ipv4_to_endpoint  tag cec81ecf8ea672b5  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,142,41,82,83,80,141,39,143,40,37,38
	btf_id 260
648: sched_cls  name tail_ipv4_ct_egress  tag b629d9a3fb4ffdf0  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 261
649: sched_cls  name __send_drop_notify  tag 823a348e5439b233  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 262
650: sched_cls  name tail_handle_ipv4_cont  tag 71693816176af610  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,142,41,141,82,83,39,76,74,77,143,40,37,38,81
	btf_id 263
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
667: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
670: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
671: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
674: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
675: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
678: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
