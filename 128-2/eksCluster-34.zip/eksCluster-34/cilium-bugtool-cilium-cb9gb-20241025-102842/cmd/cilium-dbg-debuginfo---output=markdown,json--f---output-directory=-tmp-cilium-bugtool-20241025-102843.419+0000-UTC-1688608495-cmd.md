markdown output at /tmp/cilium-bugtool-20241025-102843.419+0000-UTC-1688608495/cmd/cilium-debuginfo-20241025-102913.961+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102843.419+0000-UTC-1688608495/cmd/cilium-debuginfo-20241025-102913.961+0000-UTC.json
