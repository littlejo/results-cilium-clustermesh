REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     232440    86240384   1132   bpf_host.c
Interface                 INGRESS     9965      782349     677    bpf_overlay.c
Success                   EGRESS      10211     799950     53     encap.h
Success                   EGRESS      102757    13685201   1308   bpf_lxc.c
Success                   EGRESS      5187      399785     1694   bpf_host.c
Success                   INGRESS     115063    14073509   86     l3.h
Success                   INGRESS     120490    14499979   235    trace.h
Unsupported L3 protocol   EGRESS      37        2762       1492   bpf_lxc.c
