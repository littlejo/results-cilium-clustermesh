alloc: 79.99MB (83873592 bytes)
total-alloc: 1.42GB (1524314504 bytes)
sys: 222.38MB (233186644 bytes)
lookups: 0
mallocs: 48975746
frees: 48283225
heap-alloc: 79.99MB (83873592 bytes)
heap-sys: 175.01MB (183508992 bytes)
heap-idle: 54.86MB (57524224 bytes)
heap-in-use: 120.15MB (125984768 bytes)
heap-released: 3.46MB (3629056 bytes)
heap-objects: 692521
stack-in-use: 36.97MB (38764544 bytes)
stack-sys: 36.97MB (38764544 bytes)
stack-mspan-inuse: 2.02MB (2118240 bytes)
stack-mspan-sys: 2.54MB (2660160 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 825.09KB (844897 bytes)
gc-sys: 5.16MB (5407072 bytes)
next-gc: when heap-alloc >= 146.18MB (153285976 bytes)
last-gc: 2024-10-25 10:28:55.531072662 +0000 UTC
gc-pause-total: 15.970535ms
gc-pause: 89683
gc-pause-end: 1729852135531072662
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00045261133021562303
enable-gc: true
debug-gc: false
