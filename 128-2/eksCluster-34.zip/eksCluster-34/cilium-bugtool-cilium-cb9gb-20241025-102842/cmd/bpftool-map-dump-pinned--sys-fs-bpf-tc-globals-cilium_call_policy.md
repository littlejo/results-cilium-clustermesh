key: c9 09 00 00  value: 46 02 00 00
key: c9 0a 00 00  value: 82 02 00 00
key: d9 0b 00 00  value: 0e 02 00 00
key: 28 0c 00 00  value: 3a 02 00 00
Found 4 elements
