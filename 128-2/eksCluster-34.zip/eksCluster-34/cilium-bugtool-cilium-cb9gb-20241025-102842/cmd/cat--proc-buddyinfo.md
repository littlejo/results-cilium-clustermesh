Node 0, zone      DMA     31      5      8      2      3      4      8      2      4      3    159 
Node 0, zone   Normal    453      9     11      9      5      5      9      5      4      1      7 
