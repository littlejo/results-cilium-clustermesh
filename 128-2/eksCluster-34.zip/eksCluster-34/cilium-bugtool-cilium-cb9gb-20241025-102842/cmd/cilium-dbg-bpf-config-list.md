KEY             VALUE
AgentLiveness   844552909963
UTimeOffset     3378615837890625
