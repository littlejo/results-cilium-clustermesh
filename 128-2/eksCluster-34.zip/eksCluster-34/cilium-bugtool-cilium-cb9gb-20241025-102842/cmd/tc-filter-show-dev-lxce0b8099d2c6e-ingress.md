filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxce0b8099d2c6e direct-action not_in_hw id 643 tag 1636787f6d487c8c jited 
