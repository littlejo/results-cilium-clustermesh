[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4f33ead0_31eb_4ff9_944b_72f8fbf012a0.slice/cri-containerd-5c69d14f8f69b95eb9b1e91725bb8f298f5d632b5341b32f1488bc0915c0dd51.scope"
      }
    ],
    "ips": [
      "10.34.0.226"
    ],
    "name": "coredns-cc6ccd49c-76wvd",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec00dda3_1384_40ea_bc9d_259d26eceed9.slice/cri-containerd-28030e1beaa50a885e78926ac70e3aca78b91d67d6e5fb3f0d5b0821b92df9b5.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec00dda3_1384_40ea_bc9d_259d26eceed9.slice/cri-containerd-bd7ba4eeafd424b24fe1bd65f1382c49e5389c39661c30acd0905ad987420a78.scope"
      },
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec00dda3_1384_40ea_bc9d_259d26eceed9.slice/cri-containerd-cdf8bc5ee026ad34001b01c60b86f0ad14f642dd0ce91cf4fd0cde83358d27bd.scope"
      }
    ],
    "ips": [
      "10.34.0.188"
    ],
    "name": "clustermesh-apiserver-6ff6d88f79-k67cz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddd96afa4_1605_4c35_b54d_f20d56acec76.slice/cri-containerd-ea5d9b00e13894b939cf79a5f25c01d4b9c89f49d796dad18a9a881f1fb920a4.scope"
      }
    ],
    "ips": [
      "10.34.0.217"
    ],
    "name": "coredns-cc6ccd49c-p2njr",
    "namespace": "kube-system"
  }
]

