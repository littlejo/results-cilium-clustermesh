ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.198.8:443 (active)     
                                         2 => 172.31.152.168:443 (active)   
2    10.100.13.156:443    ClusterIP      1 => 172.31.189.5:4244 (active)    
3    10.100.0.10:53       ClusterIP      1 => 10.34.0.226:53 (active)       
                                         2 => 10.34.0.217:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.34.0.226:9153 (active)     
                                         2 => 10.34.0.217:9153 (active)     
5    10.100.132.87:2379   ClusterIP      1 => 10.34.0.188:2379 (active)     
