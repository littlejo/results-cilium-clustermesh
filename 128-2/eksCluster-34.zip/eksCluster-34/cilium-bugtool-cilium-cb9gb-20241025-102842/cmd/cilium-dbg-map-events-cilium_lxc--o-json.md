{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:45.998Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.175.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:45.998Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.189.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:45.998Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:50.674Z",
  "value": "id=2505  sec_id=4     flags=0x0000 ifindex=10  mac=26:AB:7E:82:5C:52 nodemac=AA:4A:01:91:9E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:50.688Z",
  "value": "id=3033  sec_id=2345099 flags=0x0000 ifindex=12  mac=EA:0E:2D:F2:F5:3A nodemac=06:F3:2D:A4:1B:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:50.718Z",
  "value": "id=3112  sec_id=2345099 flags=0x0000 ifindex=14  mac=8E:54:4F:E0:27:25 nodemac=12:05:1B:1C:2F:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:50.768Z",
  "value": "id=2505  sec_id=4     flags=0x0000 ifindex=10  mac=26:AB:7E:82:5C:52 nodemac=AA:4A:01:91:9E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:59.275Z",
  "value": "id=3033  sec_id=2345099 flags=0x0000 ifindex=12  mac=EA:0E:2D:F2:F5:3A nodemac=06:F3:2D:A4:1B:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:59.276Z",
  "value": "id=3112  sec_id=2345099 flags=0x0000 ifindex=14  mac=8E:54:4F:E0:27:25 nodemac=12:05:1B:1C:2F:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:59.276Z",
  "value": "id=2505  sec_id=4     flags=0x0000 ifindex=10  mac=26:AB:7E:82:5C:52 nodemac=AA:4A:01:91:9E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:59.303Z",
  "value": "id=1774  sec_id=2302320 flags=0x0000 ifindex=16  mac=46:39:EF:5E:88:EF nodemac=B6:4E:13:87:7A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:59.303Z",
  "value": "id=1774  sec_id=2302320 flags=0x0000 ifindex=16  mac=46:39:EF:5E:88:EF nodemac=B6:4E:13:87:7A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:00.274Z",
  "value": "id=2505  sec_id=4     flags=0x0000 ifindex=10  mac=26:AB:7E:82:5C:52 nodemac=AA:4A:01:91:9E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:00.274Z",
  "value": "id=1774  sec_id=2302320 flags=0x0000 ifindex=16  mac=46:39:EF:5E:88:EF nodemac=B6:4E:13:87:7A:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:00.275Z",
  "value": "id=3112  sec_id=2345099 flags=0x0000 ifindex=14  mac=8E:54:4F:E0:27:25 nodemac=12:05:1B:1C:2F:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:00.275Z",
  "value": "id=3033  sec_id=2345099 flags=0x0000 ifindex=12  mac=EA:0E:2D:F2:F5:3A nodemac=06:F3:2D:A4:1B:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.236Z",
  "value": "id=2761  sec_id=2302320 flags=0x0000 ifindex=18  mac=8E:CD:E1:E7:C9:63 nodemac=2A:6C:A2:5E:5F:28"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.34.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:11.699Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:12.531Z",
  "value": "id=3112  sec_id=2345099 flags=0x0000 ifindex=14  mac=8E:54:4F:E0:27:25 nodemac=12:05:1B:1C:2F:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:12.531Z",
  "value": "id=2505  sec_id=4     flags=0x0000 ifindex=10  mac=26:AB:7E:82:5C:52 nodemac=AA:4A:01:91:9E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:12.532Z",
  "value": "id=2761  sec_id=2302320 flags=0x0000 ifindex=18  mac=8E:CD:E1:E7:C9:63 nodemac=2A:6C:A2:5E:5F:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:12.532Z",
  "value": "id=3033  sec_id=2345099 flags=0x0000 ifindex=12  mac=EA:0E:2D:F2:F5:3A nodemac=06:F3:2D:A4:1B:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:13.529Z",
  "value": "id=2761  sec_id=2302320 flags=0x0000 ifindex=18  mac=8E:CD:E1:E7:C9:63 nodemac=2A:6C:A2:5E:5F:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:13.529Z",
  "value": "id=3033  sec_id=2345099 flags=0x0000 ifindex=12  mac=EA:0E:2D:F2:F5:3A nodemac=06:F3:2D:A4:1B:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:13.530Z",
  "value": "id=2505  sec_id=4     flags=0x0000 ifindex=10  mac=26:AB:7E:82:5C:52 nodemac=AA:4A:01:91:9E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:13.530Z",
  "value": "id=3112  sec_id=2345099 flags=0x0000 ifindex=14  mac=8E:54:4F:E0:27:25 nodemac=12:05:1B:1C:2F:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:14.530Z",
  "value": "id=2761  sec_id=2302320 flags=0x0000 ifindex=18  mac=8E:CD:E1:E7:C9:63 nodemac=2A:6C:A2:5E:5F:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:14.531Z",
  "value": "id=3033  sec_id=2345099 flags=0x0000 ifindex=12  mac=EA:0E:2D:F2:F5:3A nodemac=06:F3:2D:A4:1B:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:14.531Z",
  "value": "id=2505  sec_id=4     flags=0x0000 ifindex=10  mac=26:AB:7E:82:5C:52 nodemac=AA:4A:01:91:9E:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.34.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:14.531Z",
  "value": "id=3112  sec_id=2345099 flags=0x0000 ifindex=14  mac=8E:54:4F:E0:27:25 nodemac=12:05:1B:1C:2F:73"
}

