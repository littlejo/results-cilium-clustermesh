xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 554
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 549
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 537
cilium_host(4) clsact/egress cil_from_host-cilium_host id 538
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 468
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 469
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 510
lxc3e422815693e(9) clsact/ingress cil_from_container-lxc3e422815693e id 500
lxc0858213dc8eb(11) clsact/ingress cil_from_container-lxc0858213dc8eb id 532
lxc9d4bca3c20a5(15) clsact/ingress cil_from_container-lxc9d4bca3c20a5 id 610

flow_dissector:

netfilter:

