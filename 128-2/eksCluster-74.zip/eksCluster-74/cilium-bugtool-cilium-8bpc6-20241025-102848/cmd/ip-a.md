1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:21:f5:f8:bc:9d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.135.32/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2669sec preferred_lft 2669sec
    inet6 fe80::421:f5ff:fef8:bc9d/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:98:48:82:df:40 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ec98:48ff:fe82:df40/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:87:ee:12:a7:18 brd ff:ff:ff:ff:ff:ff
    inet 10.74.0.98/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::ec87:eeff:fe12:a718/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether d2:03:d6:bf:55:38 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d003:d6ff:febf:5538/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:1b:fb:ad:cc:35 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::141b:fbff:fead:cc35/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc3e422815693e@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:88:6f:38:41:30 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::5888:6fff:fe38:4130/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc0858213dc8eb@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:a8:89:dd:a1:de brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::34a8:89ff:fedd:a1de/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc9d4bca3c20a5@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:10:0b:95:df:57 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::a010:bff:fe95:df57/64 scope link 
       valid_lft forever preferred_lft forever
