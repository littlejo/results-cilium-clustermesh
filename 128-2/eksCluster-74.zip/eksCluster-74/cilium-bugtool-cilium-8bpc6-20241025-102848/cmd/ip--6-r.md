fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxc3e422815693e proto kernel metric 256 pref medium
fe80::/64 dev lxc0858213dc8eb proto kernel metric 256 pref medium
fe80::/64 dev lxc9d4bca3c20a5 proto kernel metric 256 pref medium
