Endpoint ID: 163
Path: /sys/fs/bpf/tc/globals/cilium_policy_00163

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 264
Path: /sys/fs/bpf/tc/globals/cilium_policy_00264

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    88019   1015      0        
Allow    Egress      0          ANY          NONE         disabled    14274   151       0        


Endpoint ID: 597
Path: /sys/fs/bpf/tc/globals/cilium_policy_00597

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    86322   992       0        
Allow    Egress      0          ANY          NONE         disabled    13850   145       0        


Endpoint ID: 728
Path: /sys/fs/bpf/tc/globals/cilium_policy_00728

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    443926   5664      0        
Allow    Ingress     1          ANY          NONE         disabled    12970    151       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1147
Path: /sys/fs/bpf/tc/globals/cilium_policy_01147

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3913785   37114     0        
Allow    Ingress     1          ANY          NONE         disabled    3818834   37601     0        
Allow    Egress      0          ANY          NONE         disabled    4977858   46097     0        


