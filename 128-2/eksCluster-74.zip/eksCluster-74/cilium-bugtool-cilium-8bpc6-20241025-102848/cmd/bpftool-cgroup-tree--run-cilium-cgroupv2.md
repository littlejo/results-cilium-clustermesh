CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5d03eea7_a320_47dd_8647_8f5108397fa3.slice/cri-containerd-affc3834dd09e6b56a800a9117776bd7e38c9a81b537798347192b5d1927585b.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5d03eea7_a320_47dd_8647_8f5108397fa3.slice/cri-containerd-d996e7d3f3e01222f0d187cb9b4d5c3804f3d9c3f46b93276a9808b94f1c5f99.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod75ef43be_6ee1_4b79_81fb_c7e43395fc42.slice/cri-containerd-79b4b4b6b2385510660194517f6b1ff9002ec2d7443e443b8613b3ae6ca1dfc5.scope
    465      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod75ef43be_6ee1_4b79_81fb_c7e43395fc42.slice/cri-containerd-6ce3b6aa417e9d0696d7c2b1c80af564ff0c788b60f07990336b2f1a402f5ee1.scope
    473      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod17b533a0_1cc5_45f5_98fa_c57753327ca4.slice/cri-containerd-622044a90ad0fb7c091e44d58ee9325ae0ec6e24e4ee91a7d223d5e83aa0d24d.scope
    67       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod17b533a0_1cc5_45f5_98fa_c57753327ca4.slice/cri-containerd-bdaffbaeb3c6680848b9ea8dfd43b0e2f30daed3570fe72d283abf4f68116214.scope
    110      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod731bdf83_0c1c_43e3_ba7c_f344b2f3fe20.slice/cri-containerd-17e46273033f55fa2add36103a2ef88df6977893a7f884931e81a184ef1926ac.scope
    522      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod731bdf83_0c1c_43e3_ba7c_f344b2f3fe20.slice/cri-containerd-db66a8815e982858f6c0bd247d1273e2eccd9f5fd19cbbe887f8eaf749d6aaa7.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd4861ce6_9508_4460_9934_c602a66de396.slice/cri-containerd-043cb045edbfc25e68cc5f76050fb4b8f1eff1bcaa4f23ba8c1218e6edeb3a37.scope
    83       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd4861ce6_9508_4460_9934_c602a66de396.slice/cri-containerd-935765ab484845f68034055fc17b4bf2d3f511d8ead3db35721e401c9626efcc.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda082417a_89b2_450c_aefc_97ec67b8942b.slice/cri-containerd-7f4d401deb47424b0452b522e06e61abfd14178fdeb8c1b3fad4d1fa2348322f.scope
    627      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda082417a_89b2_450c_aefc_97ec67b8942b.slice/cri-containerd-fdb95fb3897066833d2d112290e55464d083e83b4fa718b608c4de6e7b31b307.scope
    631      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda082417a_89b2_450c_aefc_97ec67b8942b.slice/cri-containerd-ae9d2fd4bc143a68454e0131f2659e103bff111ddede4c72d2a0698b74a7b648.scope
    635      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda082417a_89b2_450c_aefc_97ec67b8942b.slice/cri-containerd-defc9393f8b552d1a9fbe9f611797a71d99c656c57caf9201b4d218a590ac372.scope
    615      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3f30e550_eacc_467c_b422_683a608176ef.slice/cri-containerd-5a5fae7a7fbaea8fcaf3665224a8cb4188d0105511ab8a3118fcded375251b87.scope
    71       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3f30e550_eacc_467c_b422_683a608176ef.slice/cri-containerd-34cc1743d22757243b6b8b6dab00f466507786aafbd223b4e61426cc846889f2.scope
    79       cgroup_device   multi                                          
