Node 0, zone      DMA      3      2      3      2      1      1      2      1      4      7    220 
Node 0, zone   Normal      2      2      2      2      3      7      9      1      2      0      9 
