USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         702  0.0  0.4 1240432 16568 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         729  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         731  0.0  0.4 1240432 16568 ?       R    10:28   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         696  0.0  0.0 1228744 3656 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  3.0  7.2 1538100 286068 ?      Ssl  10:13   0:27 cilium-agent --config-dir=/tmp/cilium/config-map
root         414  0.0  0.1 1228848 5956 ?        Sl   10:13   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
