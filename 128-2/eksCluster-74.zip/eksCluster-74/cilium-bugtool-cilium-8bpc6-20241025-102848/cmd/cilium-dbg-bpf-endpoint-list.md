IP ADDRESS        LOCAL ENDPOINT INFO
10.74.0.84:0      id=597   sec_id=4918468 flags=0x0000 ifindex=11  mac=C2:E3:81:16:B7:73 nodemac=36:A8:89:DD:A1:DE   
10.74.0.28:0      id=1147  sec_id=4925712 flags=0x0000 ifindex=15  mac=5E:94:93:84:DE:44 nodemac=A2:10:0B:95:DF:57   
10.74.0.148:0     id=728   sec_id=4     flags=0x0000 ifindex=7   mac=0E:91:AE:68:49:F4 nodemac=16:1B:FB:AD:CC:35     
172.31.135.32:0   (localhost)                                                                                        
10.74.0.163:0     id=264   sec_id=4918468 flags=0x0000 ifindex=9   mac=86:67:94:13:89:CD nodemac=5A:88:6F:38:41:30   
10.74.0.98:0      (localhost)                                                                                        
