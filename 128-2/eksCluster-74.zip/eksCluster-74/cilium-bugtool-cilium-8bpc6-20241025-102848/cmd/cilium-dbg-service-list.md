ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.225.129:443 (active)   
                                         2 => 172.31.156.42:443 (active)    
2    10.100.30.211:443    ClusterIP      1 => 172.31.135.32:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.74.0.163:9153 (active)     
                                         2 => 10.74.0.84:9153 (active)      
4    10.100.0.10:53       ClusterIP      1 => 10.74.0.163:53 (active)       
                                         2 => 10.74.0.84:53 (active)        
5    10.100.93.116:2379   ClusterIP      1 => 10.74.0.28:2379 (active)      
