{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:56.809Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.135.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:56.809Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:00.042Z",
  "value": "id=264   sec_id=4918468 flags=0x0000 ifindex=9   mac=86:67:94:13:89:CD nodemac=5A:88:6F:38:41:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:03.236Z",
  "value": "id=728   sec_id=4     flags=0x0000 ifindex=7   mac=0E:91:AE:68:49:F4 nodemac=16:1B:FB:AD:CC:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:03.249Z",
  "value": "id=597   sec_id=4918468 flags=0x0000 ifindex=11  mac=C2:E3:81:16:B7:73 nodemac=36:A8:89:DD:A1:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:03.299Z",
  "value": "id=264   sec_id=4918468 flags=0x0000 ifindex=9   mac=86:67:94:13:89:CD nodemac=5A:88:6F:38:41:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:03.353Z",
  "value": "id=728   sec_id=4     flags=0x0000 ifindex=7   mac=0E:91:AE:68:49:F4 nodemac=16:1B:FB:AD:CC:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:03.418Z",
  "value": "id=597   sec_id=4918468 flags=0x0000 ifindex=11  mac=C2:E3:81:16:B7:73 nodemac=36:A8:89:DD:A1:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:32.173Z",
  "value": "id=264   sec_id=4918468 flags=0x0000 ifindex=9   mac=86:67:94:13:89:CD nodemac=5A:88:6F:38:41:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:32.175Z",
  "value": "id=728   sec_id=4     flags=0x0000 ifindex=7   mac=0E:91:AE:68:49:F4 nodemac=16:1B:FB:AD:CC:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:32.175Z",
  "value": "id=597   sec_id=4918468 flags=0x0000 ifindex=11  mac=C2:E3:81:16:B7:73 nodemac=36:A8:89:DD:A1:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:32.213Z",
  "value": "id=551   sec_id=4925712 flags=0x0000 ifindex=13  mac=DA:37:10:58:41:34 nodemac=8A:06:E6:ED:35:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:33.173Z",
  "value": "id=597   sec_id=4918468 flags=0x0000 ifindex=11  mac=C2:E3:81:16:B7:73 nodemac=36:A8:89:DD:A1:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:33.174Z",
  "value": "id=728   sec_id=4     flags=0x0000 ifindex=7   mac=0E:91:AE:68:49:F4 nodemac=16:1B:FB:AD:CC:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:33.174Z",
  "value": "id=551   sec_id=4925712 flags=0x0000 ifindex=13  mac=DA:37:10:58:41:34 nodemac=8A:06:E6:ED:35:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:33.174Z",
  "value": "id=264   sec_id=4918468 flags=0x0000 ifindex=9   mac=86:67:94:13:89:CD nodemac=5A:88:6F:38:41:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:45.602Z",
  "value": "id=1147  sec_id=4925712 flags=0x0000 ifindex=15  mac=5E:94:93:84:DE:44 nodemac=A2:10:0B:95:DF:57"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.74.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:52.586Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:52.835Z",
  "value": "id=597   sec_id=4918468 flags=0x0000 ifindex=11  mac=C2:E3:81:16:B7:73 nodemac=36:A8:89:DD:A1:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:52.835Z",
  "value": "id=1147  sec_id=4925712 flags=0x0000 ifindex=15  mac=5E:94:93:84:DE:44 nodemac=A2:10:0B:95:DF:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:52.836Z",
  "value": "id=728   sec_id=4     flags=0x0000 ifindex=7   mac=0E:91:AE:68:49:F4 nodemac=16:1B:FB:AD:CC:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:52.836Z",
  "value": "id=264   sec_id=4918468 flags=0x0000 ifindex=9   mac=86:67:94:13:89:CD nodemac=5A:88:6F:38:41:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:53.838Z",
  "value": "id=728   sec_id=4     flags=0x0000 ifindex=7   mac=0E:91:AE:68:49:F4 nodemac=16:1B:FB:AD:CC:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:53.839Z",
  "value": "id=1147  sec_id=4925712 flags=0x0000 ifindex=15  mac=5E:94:93:84:DE:44 nodemac=A2:10:0B:95:DF:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:53.839Z",
  "value": "id=264   sec_id=4918468 flags=0x0000 ifindex=9   mac=86:67:94:13:89:CD nodemac=5A:88:6F:38:41:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:53.840Z",
  "value": "id=597   sec_id=4918468 flags=0x0000 ifindex=11  mac=C2:E3:81:16:B7:73 nodemac=36:A8:89:DD:A1:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:54.839Z",
  "value": "id=1147  sec_id=4925712 flags=0x0000 ifindex=15  mac=5E:94:93:84:DE:44 nodemac=A2:10:0B:95:DF:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:54.839Z",
  "value": "id=597   sec_id=4918468 flags=0x0000 ifindex=11  mac=C2:E3:81:16:B7:73 nodemac=36:A8:89:DD:A1:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:54.839Z",
  "value": "id=264   sec_id=4918468 flags=0x0000 ifindex=9   mac=86:67:94:13:89:CD nodemac=5A:88:6F:38:41:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:54.839Z",
  "value": "id=728   sec_id=4     flags=0x0000 ifindex=7   mac=0E:91:AE:68:49:F4 nodemac=16:1B:FB:AD:CC:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:55.839Z",
  "value": "id=728   sec_id=4     flags=0x0000 ifindex=7   mac=0E:91:AE:68:49:F4 nodemac=16:1B:FB:AD:CC:35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:55.840Z",
  "value": "id=264   sec_id=4918468 flags=0x0000 ifindex=9   mac=86:67:94:13:89:CD nodemac=5A:88:6F:38:41:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:55.840Z",
  "value": "id=1147  sec_id=4925712 flags=0x0000 ifindex=15  mac=5E:94:93:84:DE:44 nodemac=A2:10:0B:95:DF:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:55.840Z",
  "value": "id=597   sec_id=4918468 flags=0x0000 ifindex=11  mac=C2:E3:81:16:B7:73 nodemac=36:A8:89:DD:A1:DE"
}

