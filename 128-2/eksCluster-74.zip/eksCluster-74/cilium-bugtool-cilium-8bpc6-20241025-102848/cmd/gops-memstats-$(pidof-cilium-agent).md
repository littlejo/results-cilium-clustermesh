alloc: 126.53MB (132672184 bytes)
total-alloc: 1.45GB (1559755944 bytes)
sys: 214.38MB (224798036 bytes)
lookups: 0
mallocs: 49464136
frees: 48169049
heap-alloc: 126.53MB (132672184 bytes)
heap-sys: 167.27MB (175390720 bytes)
heap-idle: 19.82MB (20783104 bytes)
heap-in-use: 147.45MB (154607616 bytes)
heap-released: 3.62MB (3801088 bytes)
heap-objects: 1295087
stack-in-use: 36.69MB (38469632 bytes)
stack-sys: 36.69MB (38469632 bytes)
stack-mspan-inuse: 2.35MB (2466720 bytes)
stack-mspan-sys: 2.47MB (2594880 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 855.31KB (875833 bytes)
gc-sys: 5.18MB (5433672 bytes)
next-gc: when heap-alloc >= 151.43MB (158789640 bytes)
last-gc: 2024-10-25 10:28:49.619717534 +0000 UTC
gc-pause-total: 11.363711ms
gc-pause: 371417
gc-pause-end: 1729852129619717534
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.0004192758854478086
enable-gc: true
debug-gc: false
