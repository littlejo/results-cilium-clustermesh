# Cilium debug information

#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 16780651                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 16780651                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 16780651                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d000000 rw-p 00000000 00:00 0 
400d000000-4010000000 ---p 00000000 00:00 0 
ffff3b12e000-ffff3b354000 rw-p 00000000 00:00 0 
ffff3b35c000-ffff3b47d000 rw-p 00000000 00:00 0 
ffff3b47d000-ffff3b4be000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff3b4be000-ffff3b4ff000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff3b4ff000-ffff3b501000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff3b501000-ffff3b503000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff3b503000-ffff3baaa000 rw-p 00000000 00:00 0 
ffff3baaa000-ffff3bbaa000 rw-p 00000000 00:00 0 
ffff3bbaa000-ffff3bbbb000 rw-p 00000000 00:00 0 
ffff3bbbb000-ffff3dbbb000 rw-p 00000000 00:00 0 
ffff3dbbb000-ffff3dc3b000 ---p 00000000 00:00 0 
ffff3dc3b000-ffff3dc3c000 rw-p 00000000 00:00 0 
ffff3dc3c000-ffff5dc3b000 ---p 00000000 00:00 0 
ffff5dc3b000-ffff5dc3c000 rw-p 00000000 00:00 0 
ffff5dc3c000-ffff7dbcb000 ---p 00000000 00:00 0 
ffff7dbcb000-ffff7dbcc000 rw-p 00000000 00:00 0 
ffff7dbcc000-ffff81bbd000 ---p 00000000 00:00 0 
ffff81bbd000-ffff81bbe000 rw-p 00000000 00:00 0 
ffff81bbe000-ffff823bb000 ---p 00000000 00:00 0 
ffff823bb000-ffff823bc000 rw-p 00000000 00:00 0 
ffff823bc000-ffff824bb000 ---p 00000000 00:00 0 
ffff824bb000-ffff8251b000 rw-p 00000000 00:00 0 
ffff8251b000-ffff8251d000 r--p 00000000 00:00 0                          [vvar]
ffff8251d000-ffff8251e000 r-xp 00000000 00:00 0                          [vdso]
ffffc4659000-ffffc467a000 rw-p 00000000 00:00 0                          [stack]

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.74.0.98": (string) (len=6) "router",
  (string) (len=11) "10.74.0.148": (string) (len=6) "health",
  (string) (len=11) "10.74.0.163": (string) (len=35) "kube-system/coredns-cc6ccd49c-lz786",
  (string) (len=10) "10.74.0.84": (string) (len=35) "kube-system/coredns-cc6ccd49c-qnxq9",
  (string) (len=10) "10.74.0.28": (string) (len=50) "kube-system/clustermesh-apiserver-6cdfbf8df6-q6dv2"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.135.32": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001345290)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001d20180,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001d20180,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4001344370)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x40032dc840)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40037402c0)(frontends:[10.100.93.116]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4001344210)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x40013442c0)(frontends:[10.100.30.211]/ports=[peer-service]/selector=map[k8s-app:cilium])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x40018658a8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40026d3790)(172.31.156.42:443/TCP,172.31.225.129:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x40018658b0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-fc99n": (*k8s.Endpoints)(0x40030bfba0)(172.31.135.32:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x40018658b8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-9ckmr": (*k8s.Endpoints)(0x4003750410)(10.74.0.163:53/TCP[eu-west-3a],10.74.0.163:53/UDP[eu-west-3a],10.74.0.163:9153/TCP[eu-west-3a],10.74.0.84:53/TCP[eu-west-3a],10.74.0.84:53/UDP[eu-west-3a],10.74.0.84:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001ab4860)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-rl4nk": (*k8s.Endpoints)(0x4006e60340)(10.74.0.28:2379/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001976460)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4001ca4dc0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400b0ff428
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4001c30e40,
  gcExited: (chan struct {}) 0x4001c30f60,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001957a00)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001574a08)({
      MetricVec: (*prometheus.MetricVec)(0x4001b8fb00)({
       metricMap: (*prometheus.metricMap)(0x4001b8fb30)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019d4120)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001957a80)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001574a10)({
      MetricVec: (*prometheus.MetricVec)(0x4001b8fb90)({
       metricMap: (*prometheus.metricMap)(0x4001b8fbc0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019d4180)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001957b00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001574a18)({
      MetricVec: (*prometheus.MetricVec)(0x4001b8fc20)({
       metricMap: (*prometheus.metricMap)(0x4001b8fc50)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019d41e0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001957b80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001574a20)({
      MetricVec: (*prometheus.MetricVec)(0x4001b8fcb0)({
       metricMap: (*prometheus.metricMap)(0x4001b8fce0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019d4240)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001957c00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001574a28)({
      MetricVec: (*prometheus.MetricVec)(0x4001b8fd40)({
       metricMap: (*prometheus.metricMap)(0x4001b8fd70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019d42a0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001957c80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001574a30)({
      MetricVec: (*prometheus.MetricVec)(0x4001b8fdd0)({
       metricMap: (*prometheus.metricMap)(0x4001b8fe00)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019d4300)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001957d00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001574a38)({
      MetricVec: (*prometheus.MetricVec)(0x4001b8fe60)({
       metricMap: (*prometheus.metricMap)(0x4001b8fe90)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019d4360)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001957d80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001574a40)({
      MetricVec: (*prometheus.MetricVec)(0x4001b8fef0)({
       metricMap: (*prometheus.metricMap)(0x4001b8ff20)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019d43c0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001957e00)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001574a48)({
      MetricVec: (*prometheus.MetricVec)(0x4001ba8000)({
       metricMap: (*prometheus.metricMap)(0x4001ba8030)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019d4420)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001976460)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001406230)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001d0e7b0)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 435ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.74.0.0/24, 
Allocated addresses:
  10.74.0.148 (health)
  10.74.0.163 (kube-system/coredns-cc6ccd49c-lz786)
  10.74.0.28 (kube-system/clustermesh-apiserver-6cdfbf8df6-q6dv2)
  10.74.0.84 (kube-system/coredns-cc6ccd49c-qnxq9)
  10.74.0.98 (router)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m28s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 7m27s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1755ffc7b2edbdbb
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    21s ago        never        0       no error   
  ct-map-pressure                                                     23s ago        never        0       no error   
  daemon-validate-config                                              8s ago         never        0       no error   
  dns-garbage-collector-job                                           26s ago        never        0       no error   
  endpoint-1147-regeneration-recovery                                 never          never        0       no error   
  endpoint-163-regeneration-recovery                                  never          never        0       no error   
  endpoint-264-regeneration-recovery                                  never          never        0       no error   
  endpoint-597-regeneration-recovery                                  never          never        0       no error   
  endpoint-728-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         26s ago        never        0       no error   
  ep-bpf-prog-watchdog                                                23s ago        never        0       no error   
  ipcache-inject-labels                                               23s ago        never        0       no error   
  k8s-heartbeat                                                       26s ago        never        0       no error   
  link-cache                                                          8s ago         never        0       no error   
  local-identity-checkpoint                                           15m13s ago     never        0       no error   
  node-neighbor-link-updater                                          3s ago         never        0       no error   
  remote-etcd-cmesh1                                                  7m27s ago      never        0       no error   
  remote-etcd-cmesh10                                                 7m26s ago      never        0       no error   
  remote-etcd-cmesh100                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh101                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh102                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh103                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh104                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh105                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh106                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh107                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh108                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh109                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh11                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh110                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh111                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh112                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh113                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh114                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh115                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh116                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh117                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh118                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh119                                                7m28s ago      never        0       no error   
  remote-etcd-cmesh12                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh120                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh121                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh122                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh123                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh124                                                7m26s ago      never        0       no error   
  remote-etcd-cmesh125                                                7m26s ago      never        0       no error   
  remote-etcd-cmesh126                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh127                                                7m26s ago      never        0       no error   
  remote-etcd-cmesh128                                                7m27s ago      never        0       no error   
  remote-etcd-cmesh13                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh14                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh15                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh16                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh17                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh18                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh19                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh2                                                  7m26s ago      never        0       no error   
  remote-etcd-cmesh20                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh21                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh22                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh23                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh24                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh25                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh26                                                 7m26s ago      never        0       no error   
  remote-etcd-cmesh27                                                 7m26s ago      never        0       no error   
  remote-etcd-cmesh28                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh29                                                 7m26s ago      never        0       no error   
  remote-etcd-cmesh3                                                  7m27s ago      never        0       no error   
  remote-etcd-cmesh30                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh31                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh32                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh33                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh34                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh35                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh36                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh37                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh38                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh39                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh4                                                  7m27s ago      never        0       no error   
  remote-etcd-cmesh40                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh41                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh42                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh43                                                 7m26s ago      never        0       no error   
  remote-etcd-cmesh44                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh45                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh46                                                 7m26s ago      never        0       no error   
  remote-etcd-cmesh47                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh48                                                 7m26s ago      never        0       no error   
  remote-etcd-cmesh49                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh5                                                  7m27s ago      never        0       no error   
  remote-etcd-cmesh50                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh51                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh52                                                 7m26s ago      never        0       no error   
  remote-etcd-cmesh53                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh54                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh55                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh56                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh57                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh58                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh59                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh6                                                  7m27s ago      never        0       no error   
  remote-etcd-cmesh60                                                 7m26s ago      never        0       no error   
  remote-etcd-cmesh61                                                 7m26s ago      never        0       no error   
  remote-etcd-cmesh62                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh63                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh64                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh65                                                 7m26s ago      never        0       no error   
  remote-etcd-cmesh66                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh67                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh68                                                 7m26s ago      never        0       no error   
  remote-etcd-cmesh69                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh7                                                  7m26s ago      never        0       no error   
  remote-etcd-cmesh70                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh71                                                 7m26s ago      never        0       no error   
  remote-etcd-cmesh72                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh73                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh74                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh76                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh77                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh78                                                 7m26s ago      never        0       no error   
  remote-etcd-cmesh79                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh8                                                  7m27s ago      never        0       no error   
  remote-etcd-cmesh80                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh81                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh82                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh83                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh84                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh85                                                 7m26s ago      never        0       no error   
  remote-etcd-cmesh86                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh87                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh88                                                 7m26s ago      never        0       no error   
  remote-etcd-cmesh89                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh9                                                  7m27s ago      never        0       no error   
  remote-etcd-cmesh90                                                 7m26s ago      never        0       no error   
  remote-etcd-cmesh91                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh92                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh93                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh94                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh95                                                 7m26s ago      never        0       no error   
  remote-etcd-cmesh96                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh97                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh98                                                 7m27s ago      never        0       no error   
  remote-etcd-cmesh99                                                 7m27s ago      never        0       no error   
  resolve-identity-1147                                               2m35s ago      never        0       no error   
  resolve-identity-163                                                23s ago        never        0       no error   
  resolve-identity-264                                                23s ago        never        0       no error   
  resolve-identity-597                                                22s ago        never        0       no error   
  resolve-identity-728                                                22s ago        never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-6cdfbf8df6-q6dv2   7m35s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-lz786                  15m23s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-qnxq9                  15m22s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      15m23s ago     never        0       no error   
  sync-policymap-1147                                                 7m35s ago      never        0       no error   
  sync-policymap-163                                                  22s ago        never        0       no error   
  sync-policymap-264                                                  20s ago        never        0       no error   
  sync-policymap-597                                                  17s ago        never        0       no error   
  sync-policymap-728                                                  17s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1147)                                   5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (264)                                    12s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (597)                                    12s ago        never        0       no error   
  sync-utime                                                          23s ago        never        0       no error   
  write-cni-file                                                      15m26s ago     never        0       no error   
Proxy Status:            OK, ip 10.74.0.98, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 4915200, max 4980735
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 75.57   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
enable-runtime-device-detection:true
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
ipv4-service-range:auto
enable-local-redirect-policy:false
debug:false
enable-ipv4-masquerade:true
crd-wait-timeout:5m0s
enable-metrics:true
ipv6-range:auto
local-router-ipv4:
identity-heartbeat-timeout:30m0s
node-labels:
enable-tcx:true
srv6-encap-mode:reduced
bgp-announce-lb-ip:false
ipam-multi-pool-pre-allocation:
enable-identity-mark:true
ipv4-range:auto
node-port-acceleration:disabled
hubble-export-file-max-size-mb:10
iptables-random-fully:false
http-idle-timeout:0
auto-direct-node-routes:false
debug-verbose:
ip-masq-agent-config-path:/etc/config/ip-masq-agent
bpf-lb-sock:false
ipv4-service-loopback-address:169.254.42.1
exclude-node-label-patterns:
monitor-queue-size:0
enable-well-known-identities:false
bpf-lb-service-map-max:0
enable-ipsec-encrypted-overlay:false
join-cluster:false
dnsproxy-lock-timeout:500ms
enable-host-port:false
enable-node-selector-labels:false
encrypt-node:false
bpf-lb-mode:snat
tofqdns-max-deferred-connection-deletes:10000
auto-create-cilium-node-resource:true
service-no-backend-response:reject
disable-envoy-version-check:false
use-full-tls-context:false
hubble-recorder-storage-path:/var/run/cilium/pcaps
conntrack-gc-interval:0s
tofqdns-proxy-port:0
enable-sctp:false
bpf-ct-global-any-max:262144
enable-ipv6-big-tcp:false
k8s-sync-timeout:3m0s
bpf-ct-timeout-service-any:1m0s
k8s-client-connection-timeout:30s
certificates-directory:/var/run/cilium/certs
pprof:false
enable-wireguard-userspace-fallback:false
hubble-skip-unknown-cgroup-ids:true
kvstore-opt:
identity-gc-interval:15m0s
hubble-redact-http-headers-allow:
bpf-lb-dsr-l4-xlate:frontend
enable-custom-calls:false
ipv6-node:auto
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
kvstore-lease-ttl:15m0s
enable-k8s-terminating-endpoint:true
bpf-root:/sys/fs/bpf
metrics:
enable-bpf-tproxy:false
enable-endpoint-health-checking:true
kvstore-periodic-sync:5m0s
operator-api-serve-addr:127.0.0.1:9234
log-opt:
bpf-map-event-buffers:
proxy-portrange-min:10000
annotate-k8s-node:false
hubble-prefer-ipv6:false
local-max-addr-scope:252
bpf-nat-global-max:524288
enable-host-legacy-routing:false
envoy-keep-cap-netbindservice:false
agent-liveness-update-interval:1s
proxy-gid:1337
enable-ipsec-xfrm-state-caching:true
hubble-event-queue-size:0
dnsproxy-socket-linger-timeout:10
proxy-max-connection-duration-seconds:0
bpf-ct-timeout-regular-tcp-syn:1m0s
nodeport-addresses:
config:
bpf-events-drop-enabled:true
vtep-mac:
encryption-strict-mode-allow-remote-node-identities:false
hubble-export-file-max-backups:5
k8s-heartbeat-timeout:30s
monitor-aggregation:medium
agent-health-port:9879
cflags:
enable-masquerade-to-route-source:false
hubble-metrics-server:
devices:
bpf-sock-rev-map-max:262144
enable-hubble-recorder-api:true
enable-stale-cilium-endpoint-cleanup:true
labels:
install-iptables-rules:true
bpf-map-dynamic-size-ratio:0.0025
allow-icmp-frag-needed:true
log-driver:
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
bpf-lb-map-max:65536
enable-l2-neigh-discovery:true
enable-vtep:false
max-connected-clusters:255
enable-cilium-api-server-access:
derive-masq-ip-addr-from-device:
mesh-auth-enabled:true
bpf-ct-timeout-service-tcp-grace:1m0s
set-cilium-node-taints:true
ipsec-key-rotation-duration:5m0s
enable-encryption-strict-mode:false
cluster-pool-ipv4-cidr:10.74.0.0/16
identity-restore-grace-period:30s
enable-k8s-endpoint-slice:true
k8s-service-proxy-name:
policy-queue-size:100
custom-cni-conf:false
l2-announcements-renew-deadline:5s
tofqdns-endpoint-max-ip-per-hostname:50
cmdref:
ipv6-service-range:auto
identity-change-grace-period:5s
bpf-policy-map-full-reconciliation-interval:15m0s
egress-masquerade-interfaces:ens+
vtep-endpoint:
install-no-conntrack-iptables-rules:false
bpf-filter-priority:1
bpf-ct-timeout-regular-tcp:2h13m20s
procfs:/host/proc
enable-srv6:false
enable-cilium-endpoint-slice:false
enable-bpf-clock-probe:false
enable-ipv6:false
enable-ipv4:true
k8s-require-ipv4-pod-cidr:false
enable-k8s-api-discovery:false
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
enable-bandwidth-manager:false
k8s-api-server:
mesh-auth-rotated-identities-queue-size:1024
local-router-ipv6:
preallocate-bpf-maps:false
egress-gateway-reconciliation-trigger-interval:1s
bpf-lb-algorithm:random
vlan-bpf-bypass:
enable-bgp-control-plane:false
arping-refresh-period:30s
bpf-ct-timeout-regular-tcp-fin:10s
node-port-mode:snat
bpf-lb-dsr-dispatch:opt
bpf-lb-rss-ipv4-src-cidr:
hubble-monitor-events:
use-cilium-internal-ip-for-ipsec:false
enable-l7-proxy:true
ipv4-pod-subnets:
http-retry-count:3
tofqdns-idle-connection-grace-period:0s
unmanaged-pod-watcher-interval:15
tofqdns-proxy-response-max-delay:100ms
k8s-client-burst:20
policy-audit-mode:false
enable-cilium-health-api-server-access:
hubble-flowlogs-config-path:
restore:true
enable-icmp-rules:true
dnsproxy-enable-transparent-mode:true
enable-bbr:false
multicast-enabled:false
enable-mke:false
dnsproxy-insecure-skip-transparent-mode-check:false
enable-k8s-networkpolicy:true
proxy-admin-port:0
policy-accounting:true
enable-auto-protect-node-port-range:true
mesh-auth-mutual-connect-timeout:5s
enable-ingress-controller:false
enable-host-firewall:false
bgp-config-path:/var/lib/cilium/bgp/config.yaml
enable-health-check-loadbalancer-ip:false
cni-external-routing:false
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
enable-ipsec-key-watcher:true
trace-payloadlen:128
nat-map-stats-interval:30s
hubble-export-denylist:
http-max-grpc-timeout:0
state-dir:/var/run/cilium
allocator-list-timeout:3m0s
enable-xdp-prefilter:false
max-internal-timer-delay:0s
max-controller-interval:0
hubble-drop-events:false
enable-health-check-nodeport:true
bpf-auth-map-max:524288
proxy-connect-timeout:2
monitor-aggregation-interval:5s
kube-proxy-replacement:false
ipv6-native-routing-cidr:
k8s-namespace:kube-system
enable-monitor:true
mesh-auth-gc-interval:5m0s
tunnel-port:0
hubble-export-allowlist:
label-prefix-file:
bpf-neigh-global-max:524288
socket-path:/var/run/cilium/cilium.sock
pprof-port:6060
mesh-auth-mutual-listener-port:0
synchronize-k8s-nodes:true
tofqdns-dns-reject-response-code:refused
trace-sock:true
remove-cilium-node-taints:true
proxy-max-requests-per-connection:0
ipv6-cluster-alloc-cidr:f00d::/64
mtu:0
fqdn-regex-compile-lru-size:1024
ipam-cilium-node-update-rate:15s
kvstore:
disable-endpoint-crd:false
direct-routing-skip-unreachable:false
dnsproxy-lock-count:131
hubble-recorder-sink-queue-size:1024
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
ipam:cluster-pool
config-sources:config-map:kube-system/cilium-config
fixed-identity-mapping:
endpoint-bpf-prog-watchdog-interval:30s
route-metric:0
gateway-api-secrets-namespace:
hubble-export-file-compress:false
l2-announcements-lease-duration:15s
pprof-address:localhost
bpf-ct-timeout-service-tcp:2h13m20s
enable-k8s:true
cluster-name:cmesh75
disable-iptables-feeder-rules:
bpf-lb-maglev-map-max:0
prometheus-serve-addr:
envoy-log:
encryption-strict-mode-cidr:
vtep-cidr:
envoy-config-timeout:2m0s
monitor-aggregation-flags:all
bpf-lb-affinity-map-max:0
enable-unreachable-routes:false
encrypt-interface:
identity-allocation-mode:crd
container-ip-local-reserved-ports:auto
hubble-metrics:
direct-routing-device:
enable-tracing:false
hubble-redact-http-urlquery:false
tofqdns-min-ttl:0
ipv4-node:auto
enable-hubble:true
mke-cgroup-mount:
cni-chaining-target:
vtep-mask:
envoy-secrets-namespace:
api-rate-limit:
mesh-auth-queue-size:1024
bpf-events-trace-enabled:true
bpf-policy-map-max:16384
enable-service-topology:false
enable-local-node-route:true
hubble-redact-http-headers-deny:
bpf-lb-source-range-map-max:0
hubble-export-fieldmask:
enable-ipv6-ndp:false
bpf-lb-rss-ipv6-src-cidr:
enable-pmtu-discovery:false
enable-envoy-config:false
iptables-lock-timeout:5s
bpf-lb-rev-nat-map-max:0
enable-ipv4-egress-gateway:false
l2-announcements-retry-period:2s
egress-gateway-policy-map-max:16384
disable-external-ip-mitigation:false
enable-ipip-termination:false
wireguard-persistent-keepalive:0s
bgp-announce-pod-cidr:false
hubble-drop-events-interval:2m0s
bpf-lb-service-backend-map-max:0
tofqdns-enable-dns-compression:true
enable-xt-socket-fallback:true
version:false
enable-active-connection-tracking:false
static-cnp-path:
dns-policy-unload-on-shutdown:false
enable-ipv4-fragment-tracking:true
tunnel-protocol:vxlan
l2-pod-announcements-interface:
hubble-drop-events-reasons:auth_required,policy_denied
hubble-socket-path:/var/run/cilium/hubble.sock
bpf-events-policy-verdict-enabled:true
routing-mode:tunnel
policy-cidr-match-mode:
dns-max-ips-per-restored-rule:1000
endpoint-queue-size:25
bpf-lb-acceleration:disabled
mesh-auth-spire-admin-socket:
exclude-local-address:
bpf-lb-maglev-table-size:16381
mesh-auth-signal-backoff-duration:1s
cni-log-file:/var/run/cilium/cilium-cni.log
proxy-prometheus-port:0
bpf-fragments-map-max:8192
enable-gateway-api:false
mesh-auth-spiffe-trust-domain:spiffe.cilium
k8s-service-cache-size:128
controller-group-metrics:
bpf-node-map-max:16384
cilium-endpoint-gc-interval:5m0s
read-cni-conf:
dnsproxy-concurrency-limit:0
tofqdns-pre-cache:
kvstore-max-consecutive-quorum-errors:2
cluster-pool-ipv4-mask-size:24
hubble-redact-http-userinfo:true
proxy-portrange-max:20000
bpf-lb-external-clusterip:false
enable-policy:default
enable-ip-masq-agent:false
enable-l2-pod-announcements:false
bpf-lb-sock-hostns-only:false
lib-dir:/var/lib/cilium
enable-bpf-masquerade:false
cgroup-root:/run/cilium/cgroupv2
external-envoy-proxy:true
ipv4-native-routing-cidr:
node-port-range:
cni-exclusive:true
nat-map-stats-entries:32
dnsproxy-concurrency-processing-grace-period:0s
node-port-bind-protection:true
enable-route-mtu-for-cni-chaining:false
clustermesh-sync-timeout:1m0s
ipv6-mcast-device:
enable-endpoint-routes:false
hubble-redact-kafka-apikey:false
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
hubble-listen-address::4244
hubble-disable-tls:false
k8s-client-connection-keep-alive:30s
hubble-export-file-path:
k8s-kubeconfig-path:
clustermesh-ip-identities-sync-timeout:1m0s
ipsec-key-file:
force-device-detection:false
set-cilium-is-up-condition:true
log-system-load:false
kube-proxy-replacement-healthz-bind-address:
envoy-config-retry-interval:15s
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
hubble-redact-enabled:false
enable-session-affinity:false
enable-ipsec:false
proxy-xff-num-trusted-hops-egress:0
envoy-base-id:0
gops-port:9890
config-dir:/tmp/cilium/config-map
cluster-id:75
k8s-require-ipv6-pod-cidr:false
proxy-idle-timeout-seconds:60
node-port-algorithm:random
enable-wireguard:false
kvstore-connectivity-timeout:2m0s
http-request-timeout:3600
bpf-ct-global-tcp-max:524288
egress-multi-home-ip-rule-compat:false
clustermesh-config:/var/lib/cilium/clustermesh/
proxy-xff-num-trusted-hops-ingress:0
datapath-mode:veth
nodes-gc-interval:5m0s
allow-localhost:auto
enable-nat46x64-gateway:false
enable-svc-source-range-check:true
prepend-iptables-chains:true
ipv6-pod-subnets:
enable-node-port:false
enable-health-checking:true
conntrack-gc-max-interval:0s
cluster-health-port:4240
enable-ipv4-big-tcp:false
cni-chaining-mode:none
http-normalize-path:true
enable-external-ips:false
clustermesh-enable-mcs-api:false
k8s-client-qps:10
endpoint-gc-interval:5m0s
operator-prometheus-serve-addr::9963
bpf-ct-timeout-regular-any:1m0s
enable-ipv6-masquerade:true
http-retry-timeout:0
enable-recorder:false
ingress-secrets-namespace:
agent-labels:
keep-config:false
ipam-default-ip-pool:default
enable-l2-announcements:false
clustermesh-enable-endpoint-sync:false
enable-high-scale-ipcache:false
bpf-lb-sock-terminate-pod-connections:false
bypass-ip-availability-upon-restore:false
hubble-event-buffer-capacity:4095
policy-trigger-interval:1s
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
163        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                
                                                           reserved:host                                                                                             
264        Disabled           Disabled          4918468    k8s:eks.amazonaws.com/component=coredns                                             10.74.0.163   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh75                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
597        Disabled           Disabled          4918468    k8s:eks.amazonaws.com/component=coredns                                             10.74.0.84    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh75                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
728        Disabled           Disabled          4          reserved:health                                                                     10.74.0.148   ready   
1147       Disabled           Disabled          4925712    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.74.0.28    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh75                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
```

#### BPF Policy Get 163

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 163

```
Invalid argument: unknown type 163
```


#### Endpoint Get 163

```
[
  {
    "id": 163,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-163-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "e055a5b0-ebd2-45cd-bce8-7bf35c965570"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-163",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:56.934Z",
            "success-count": 4
          },
          "uuid": "cb9794da-611f-4676-86ec-5b80c5295a1d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-163",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:58.073Z",
            "success-count": 2
          },
          "uuid": "39e1c6a5-53b4-45c1-a02c-a6f1929e6ca1"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:55Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "ee:87:ee:12:a7:18",
        "interface-name": "cilium_host",
        "mac": "ee:87:ee:12:a7:18"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 163

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 163

```
Timestamp              Status   State                   Message
2024-10-25T10:21:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:55Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:03Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:00Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:13:58Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:56Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:56Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:56Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 264

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    88019   1015      0        
Allow    Egress      0          ANY          NONE         disabled    14274   151       0        

```


#### BPF CT List 264

```
Invalid argument: unknown type 264
```


#### Endpoint Get 264

```
[
  {
    "id": 264,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-264-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "15288c40-338c-41c0-b4f1-e2fbc63956c9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-264",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:57.788Z",
            "success-count": 4
          },
          "uuid": "dc23e7b6-b403-4228-882b-b66d846f9713"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-lz786",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:13:57.784Z",
            "success-count": 1
          },
          "uuid": "f1749b16-679e-4a70-aed5-29c42eb744cc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-264",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:00.044Z",
            "success-count": 2
          },
          "uuid": "2c23172b-dac5-46da-b789-f384e71d00bd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (264)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:17.867Z",
            "success-count": 94
          },
          "uuid": "cd49ad1d-4bad-40c8-ade6-2992862f629f"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "79b4b4b6b2385510660194517f6b1ff9002ec2d7443e443b8613b3ae6ca1dfc5:eth0",
        "container-id": "79b4b4b6b2385510660194517f6b1ff9002ec2d7443e443b8613b3ae6ca1dfc5",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-lz786",
        "pod-name": "kube-system/coredns-cc6ccd49c-lz786"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4918468,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh75",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh75",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:55Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.74.0.163",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "5a:88:6f:38:41:30",
        "interface-index": 9,
        "interface-name": "lxc3e422815693e",
        "mac": "86:67:94:13:89:cd"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4918468,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4918468,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 264

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 264

```
Timestamp              Status   State                   Message
2024-10-25T10:21:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:55Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:14:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:03Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:14:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:14:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:57Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:57Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:13:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:57Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:57Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4918468

```
ID        LABELS
4918468   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh75
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 597

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    86322   992       0        
Allow    Egress      0          ANY          NONE         disabled    13850   145       0        

```


#### BPF CT List 597

```
Invalid argument: unknown type 597
```


#### Endpoint Get 597

```
[
  {
    "id": 597,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-597-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c6777732-f489-44ad-b248-ee1893e62917"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-597",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:57.864Z",
            "success-count": 4
          },
          "uuid": "70740d27-9e6a-4d4f-9187-67f8828a15f6"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-qnxq9",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:13:57.862Z",
            "success-count": 1
          },
          "uuid": "c7015a6f-dc9f-42ad-87e6-cb3781f9ee72"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-597",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:03.257Z",
            "success-count": 2
          },
          "uuid": "1ef8f854-4738-474e-ba7c-72012684e722"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (597)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:17.950Z",
            "success-count": 94
          },
          "uuid": "417bc043-19cf-42bd-901d-59fffd66dd15"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "17e46273033f55fa2add36103a2ef88df6977893a7f884931e81a184ef1926ac:eth0",
        "container-id": "17e46273033f55fa2add36103a2ef88df6977893a7f884931e81a184ef1926ac",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-qnxq9",
        "pod-name": "kube-system/coredns-cc6ccd49c-qnxq9"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4918468,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh75",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh75",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:55Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.74.0.84",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "36:a8:89:dd:a1:de",
        "interface-index": 11,
        "interface-name": "lxc0858213dc8eb",
        "mac": "c2:e3:81:16:b7:73"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4918468,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4918468,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 597

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 597

```
Timestamp              Status   State                   Message
2024-10-25T10:21:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:55Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:14:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:03Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:14:03Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:13:58Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:57Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:57Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4918468

```
ID        LABELS
4918468   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh75
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 728

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    443486   5659      0        
Allow    Ingress     1          ANY          NONE         disabled    12970    151       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 728

```
Invalid argument: unknown type 728
```


#### Endpoint Get 728

```
[
  {
    "id": 728,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-728-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "03132db3-0a6f-4d8c-9bc4-6c257cd0e610"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-728",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:58.001Z",
            "success-count": 4
          },
          "uuid": "8f231ad2-7745-48b7-8e25-e94ed34d3ccc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-728",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:03.238Z",
            "success-count": 2
          },
          "uuid": "6adae27a-5e94-422c-ada1-1c03f24d9de7"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:55Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.74.0.148",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "16:1b:fb:ad:cc:35",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "0e:91:ae:68:49:f4"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 728

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 728

```
Timestamp              Status   State                   Message
2024-10-25T10:21:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:55Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:14:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:03Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:14:03Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:14:00Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:57Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:56Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 1147

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3913785   37114     0        
Allow    Ingress     1          ANY          NONE         disabled    3818834   37601     0        
Allow    Egress      0          ANY          NONE         disabled    4977562   46094     0        

```


#### BPF CT List 1147

```
Invalid argument: unknown type 1147
```


#### Endpoint Get 1147

```
[
  {
    "id": 1147,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1147-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "92af8ca2-a4e7-48c6-9fa5-d926e4ecc427"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1147",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:45.562Z",
            "success-count": 2
          },
          "uuid": "d0eea2a9-cb5b-4bab-b759-631a98f692d1"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-6cdfbf8df6-q6dv2",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:45.562Z",
            "success-count": 1
          },
          "uuid": "b3713082-9a61-4fb5-8fc3-f6598cb02ee1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1147",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:45.602Z",
            "success-count": 1
          },
          "uuid": "c42f3c6c-194c-4f8b-a0d2-e621cd2f37ed"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1147)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:15.606Z",
            "success-count": 47
          },
          "uuid": "e2529eee-56bf-4861-b9a1-380d76f65e3f"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "defc9393f8b552d1a9fbe9f611797a71d99c656c57caf9201b4d218a590ac372:eth0",
        "container-id": "defc9393f8b552d1a9fbe9f611797a71d99c656c57caf9201b4d218a590ac372",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-6cdfbf8df6-q6dv2",
        "pod-name": "kube-system/clustermesh-apiserver-6cdfbf8df6-q6dv2"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4925712,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh75",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6cdfbf8df6"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh75",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:55Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.74.0.28",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "a2:10:0b:95:df:57",
        "interface-index": 15,
        "interface-name": "lxc9d4bca3c20a5",
        "mac": "5e:94:93:84:de:44"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4925712,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4925712,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1147

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1147

```
Timestamp              Status   State                   Message
2024-10-25T10:21:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:55Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:45Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:45Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:45Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4925712

```
ID        LABELS
4925712   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh75
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### Service list

```
ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.225.129:443 (active)   
                                         2 => 172.31.156.42:443 (active)    
2    10.100.30.211:443    ClusterIP      1 => 172.31.135.32:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.74.0.163:9153 (active)     
                                         2 => 10.74.0.84:9153 (active)      
4    10.100.0.10:53       ClusterIP      1 => 10.74.0.163:53 (active)       
                                         2 => 10.74.0.84:53 (active)        
5    10.100.93.116:2379   ClusterIP      1 => 10.74.0.28:2379 (active)      
```

#### Cilium encryption


