REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     10710     843161      677    bpf_overlay.c
Interface                 INGRESS     234663    102502640   1132   bpf_host.c
Success                   EGRESS      104610    13785162    1308   bpf_lxc.c
Success                   EGRESS      11248     882255      53     encap.h
Success                   EGRESS      5710      444233      1694   bpf_host.c
Success                   INGRESS     115777    14242507    86     l3.h
Success                   INGRESS     121426    14685341    235    trace.h
Unsupported L3 protocol   EGRESS      37        2742        1492   bpf_lxc.c
