KEY             VALUE
AgentLiveness   971364477302
UTimeOffset     3378615603515625
