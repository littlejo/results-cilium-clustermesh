key: 08 01 00 00  value: f2 01 00 00
key: 55 02 00 00  value: 11 02 00 00
key: d8 02 00 00  value: 03 02 00 00
key: 7b 04 00 00  value: 61 02 00 00
Found 4 elements
