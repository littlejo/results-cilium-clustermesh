key: 02 00 00 00  value: ac 1f 87 20 10 94 00 00  00 00 00 00
key: 04 00 00 00  value: 0a 4a 00 a3 00 35 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 4a 00 54 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: 0a 4a 00 a3 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 4a 00 1c 09 4b 00 00  00 00 00 00
key: 03 00 00 00  value: ac 1f 9c 2a 01 bb 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 4a 00 54 23 c1 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f e1 81 01 bb 00 00  00 00 00 00
Found 8 elements
