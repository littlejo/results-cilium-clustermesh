[
  {
    "containers": [
      {
        "cgroup-id": 8538,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda082417a_89b2_450c_aefc_97ec67b8942b.slice/cri-containerd-fdb95fb3897066833d2d112290e55464d083e83b4fa718b608c4de6e7b31b307.scope"
      },
      {
        "cgroup-id": 8454,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda082417a_89b2_450c_aefc_97ec67b8942b.slice/cri-containerd-7f4d401deb47424b0452b522e06e61abfd14178fdeb8c1b3fad4d1fa2348322f.scope"
      },
      {
        "cgroup-id": 8622,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda082417a_89b2_450c_aefc_97ec67b8942b.slice/cri-containerd-ae9d2fd4bc143a68454e0131f2659e103bff111ddede4c72d2a0698b74a7b648.scope"
      }
    ],
    "ips": [
      "10.74.0.28"
    ],
    "name": "clustermesh-apiserver-6cdfbf8df6-q6dv2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6942,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod75ef43be_6ee1_4b79_81fb_c7e43395fc42.slice/cri-containerd-6ce3b6aa417e9d0696d7c2b1c80af564ff0c788b60f07990336b2f1a402f5ee1.scope"
      }
    ],
    "ips": [
      "10.74.0.163"
    ],
    "name": "coredns-cc6ccd49c-lz786",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7110,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod731bdf83_0c1c_43e3_ba7c_f344b2f3fe20.slice/cri-containerd-db66a8815e982858f6c0bd247d1273e2eccd9f5fd19cbbe887f8eaf749d6aaa7.scope"
      }
    ],
    "ips": [
      "10.74.0.84"
    ],
    "name": "coredns-cc6ccd49c-qnxq9",
    "namespace": "kube-system"
  }
]

