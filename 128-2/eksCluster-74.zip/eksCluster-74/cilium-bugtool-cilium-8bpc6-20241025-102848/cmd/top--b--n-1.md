top - 10:28:50 up 15 min,  0 users,  load average: 0.34, 0.29, 0.22
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 32.1 us, 32.1 sy,  0.0 ni, 32.1 id,  0.0 wa,  0.0 hi,  3.6 si,  0.0 st
MiB Mem :   3836.2 total,   1007.1 free,    911.4 used,   1917.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2756.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    702 root      20   0 1240432  16568  11484 S   6.7   0.4   0:00.03 cilium-+
      1 root      20   0 1538100 286068  78708 S   0.0   7.3   0:27.48 cilium-+
    414 root      20   0 1228848   5956   2928 S   0.0   0.2   0:00.27 cilium-+
    696 root      20   0 1228744   3656   2976 S   0.0   0.1   0:00.00 gops
    741 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    760 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
