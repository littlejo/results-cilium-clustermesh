32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:11+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:11+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:11+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:12+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:13+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:13+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:13+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:13+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:27+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
64: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
67: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
68: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
71: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
72: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
75: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
80: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
83: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
107: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
110: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
462: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
465: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
466: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 124
467: sched_cls  name tail_handle_ipv4  tag 83e603a6c167510b  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 69,68,75,70,95
	btf_id 125
468: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 70,95
	btf_id 126
469: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
470: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
473: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
496: sched_cls  name tail_ipv4_to_endpoint  tag 18ab34a75de226c2  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,104,35,76,77,74,85,33,103,34,31,32
	btf_id 154
497: sched_cls  name tail_handle_arp  tag 843e1f7eaffa0652  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,103
	btf_id 155
498: sched_cls  name handle_policy  tag 573f9b7401889d3d  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,103,76,77,104,35,74,85,33,78,69,34,31,32
	btf_id 156
499: sched_cls  name tail_handle_ipv4_cont  tag 3f9d2198e64a3197  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,104,35,85,76,77,33,70,68,71,103,34,31,32,75
	btf_id 157
500: sched_cls  name cil_from_container  tag b373c13920b9f6ed  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 103,70
	btf_id 158
501: sched_cls  name tail_handle_ipv4  tag bf01f5ebf595918a  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,103
	btf_id 159
502: sched_cls  name tail_ipv4_ct_egress  tag 0d23ed3f6f344354  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,103,76,77,104,78
	btf_id 160
503: sched_cls  name __send_drop_notify  tag 39e7283830752ff0  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 161
505: sched_cls  name tail_ipv4_ct_ingress  tag d3fe6e605282b4e0  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,103,76,77,104,78
	btf_id 163
506: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,103
	btf_id 164
508: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 70,105,76,77,106,78
	btf_id 167
509: sched_cls  name tail_handle_ipv4  tag 08c77dae3394121d  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,105
	btf_id 168
510: sched_cls  name cil_from_container  tag a2430a9826ee77c5  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 105,70
	btf_id 169
511: sched_cls  name tail_handle_ipv4_cont  tag c6195011b3d014dc  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 69,106,35,97,76,77,33,70,68,71,105,34,31,32,75
	btf_id 170
512: sched_cls  name tail_handle_arp  tag 1dd89a17da35a5ac  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,105
	btf_id 171
513: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,105
	btf_id 172
514: sched_cls  name tail_ipv4_to_endpoint  tag 21a8e83f7ac7217b  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 69,70,106,35,76,77,74,97,33,105,34,31,32
	btf_id 173
515: sched_cls  name handle_policy  tag 260f9356f3af9f02  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 70,105,76,77,106,35,74,97,33,78,69,34,31,32
	btf_id 174
516: sched_cls  name tail_ipv4_ct_ingress  tag 53126b6dd99396eb  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 70,105,76,77,106,78
	btf_id 176
517: sched_cls  name __send_drop_notify  tag ca831355bce09fd1  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 177
518: sched_cls  name tail_handle_ipv4_cont  tag 19310d2124b066d3  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,108,35,96,76,77,33,70,68,71,107,34,31,32,75
	btf_id 179
519: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
522: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
523: sched_cls  name tail_ipv4_ct_egress  tag 0d23ed3f6f344354  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,107,76,77,108,78
	btf_id 180
525: sched_cls  name tail_ipv4_ct_ingress  tag 9c3a4fb55c4abe49  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,107,76,77,108,78
	btf_id 182
526: sched_cls  name __send_drop_notify  tag cec692a68a0bcf77  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 183
527: sched_cls  name tail_handle_ipv4  tag 472f0ab6d520fea3  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,107
	btf_id 184
528: sched_cls  name tail_handle_arp  tag 7fec5f1f883ef8b7  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,107
	btf_id 185
529: sched_cls  name handle_policy  tag 9b9954813db2df41  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,107,76,77,108,35,74,96,33,78,69,34,31,32
	btf_id 186
530: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,107
	btf_id 187
531: sched_cls  name tail_ipv4_to_endpoint  tag b32ef381955c21bb  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,108,35,76,77,74,96,33,107,34,31,32
	btf_id 188
532: sched_cls  name cil_from_container  tag 9f94704ef0a9f569  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 107,70
	btf_id 189
533: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
536: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
537: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 191
538: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 70,69,111
	btf_id 192
539: sched_cls  name tail_handle_ipv4_from_host  tag e320f2fd4c5b6c25  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,111
	btf_id 193
542: sched_cls  name __send_drop_notify  tag e8f7eb02e37e0a37  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 196
543: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,111
	btf_id 197
544: sched_cls  name tail_handle_ipv4_from_host  tag e320f2fd4c5b6c25  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,114
	btf_id 199
547: sched_cls  name __send_drop_notify  tag e8f7eb02e37e0a37  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 202
548: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,114
	btf_id 203
549: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 204
552: sched_cls  name tail_handle_ipv4_from_host  tag e320f2fd4c5b6c25  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,116
	btf_id 208
554: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 70,116,69
	btf_id 210
555: sched_cls  name __send_drop_notify  tag e8f7eb02e37e0a37  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 211
556: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,116
	btf_id 212
598: sched_cls  name tail_handle_ipv4  tag a881831bb3293a93  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,128
	btf_id 228
599: sched_cls  name tail_ipv4_ct_egress  tag 8cbc7360bb856fb5  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,128,76,77,129,78
	btf_id 229
600: sched_cls  name tail_ipv4_to_endpoint  tag 660d3e1982ff48f7  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,129,35,76,77,74,127,33,128,34,31,32
	btf_id 230
601: sched_cls  name tail_handle_ipv4_cont  tag eedffe37a6c3a732  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,129,35,127,76,77,33,70,68,71,128,34,31,32,75
	btf_id 231
602: sched_cls  name tail_handle_arp  tag 28bdba9bb298b853  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,128
	btf_id 232
603: sched_cls  name tail_ipv4_ct_ingress  tag 19300aae9bc6ada8  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,128,76,77,129,78
	btf_id 233
604: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,128
	btf_id 234
609: sched_cls  name handle_policy  tag 307b723723d4020d  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,128,76,77,129,35,74,127,33,78,69,34,31,32
	btf_id 235
610: sched_cls  name cil_from_container  tag 83a71237fbbfdafd  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 128,70
	btf_id 236
611: sched_cls  name __send_drop_notify  tag 66e175853f3c9653  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 237
612: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
615: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
624: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
627: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
628: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
631: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
632: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
635: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
