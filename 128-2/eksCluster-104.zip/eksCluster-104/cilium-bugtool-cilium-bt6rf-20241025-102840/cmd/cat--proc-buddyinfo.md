Node 0, zone      DMA     64     87     21      4      6      2      8      3      3      3    170 
Node 0, zone   Normal      3     46      9      4     15     11      2      1      4      3      7 
