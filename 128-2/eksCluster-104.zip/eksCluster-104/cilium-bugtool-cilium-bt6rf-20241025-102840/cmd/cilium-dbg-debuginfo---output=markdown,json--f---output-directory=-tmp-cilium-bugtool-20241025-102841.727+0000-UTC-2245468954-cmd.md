markdown output at /tmp/cilium-bugtool-20241025-102841.727+0000-UTC-2245468954/cmd/cilium-debuginfo-20241025-102912.212+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102841.727+0000-UTC-2245468954/cmd/cilium-debuginfo-20241025-102912.212+0000-UTC.json
