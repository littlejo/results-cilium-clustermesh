ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.200.28:443 (active)     
                                          2 => 172.31.135.166:443 (active)    
2    10.100.185.64:443     ClusterIP      1 => 172.31.188.169:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.104.0.7:53 (active)         
                                          2 => 10.104.0.224:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.104.0.7:9153 (active)       
                                          2 => 10.104.0.224:9153 (active)     
5    10.100.231.126:2379   ClusterIP      1 => 10.104.0.193:2379 (active)     
