1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:66:2f:9c:90:73 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.188.169/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2811sec preferred_lft 2811sec
    inet6 fe80::466:2fff:fe9c:9073/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:f3:2e:70:4f:53 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.153.253/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4f3:2eff:fe70:4f53/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:cb:ae:0e:a4:99 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6ccb:aeff:fe0e:a499/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:6d:12:e5:58:cf brd ff:ff:ff:ff:ff:ff
    inet 10.104.0.34/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::1c6d:12ff:fee5:58cf/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether f2:23:a6:c2:c5:30 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f023:a6ff:fec2:c530/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:0c:8d:f3:09:2e brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::9c0c:8dff:fef3:92e/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc3b15af571d42@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:de:82:70:03:a4 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::a4de:82ff:fe70:3a4/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce25f7301315c@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:93:d2:79:eb:9c brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::bc93:d2ff:fe79:eb9c/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf6a1c3f90ac4@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:53:79:bc:bb:d7 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::53:79ff:febc:bbd7/64 scope link 
       valid_lft forever preferred_lft forever
