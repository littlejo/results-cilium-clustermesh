35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:15:25+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:15:25+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:15:26+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:15:26+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:26+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:26+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:15:26+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:15:26+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:37+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
66: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:15:41+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:16:54+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
485: sched_cls  name tail_handle_ipv4  tag 45770b493b5e7a42  gpl
	loaded_at 2024-10-25T10:16:54+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
486: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:16:54+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
487: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:16:54+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
516: sched_cls  name __send_drop_notify  tag 91f2e4715a6562cf  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 163
518: sched_cls  name tail_ipv4_ct_egress  tag a16bbf356ff5c57a  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 164
522: sched_cls  name handle_policy  tag 9a440185dd3c12d6  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 166
523: sched_cls  name tail_handle_ipv4_cont  tag 8c1f5f9959dc1e8f  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 170
525: sched_cls  name tail_handle_ipv4  tag b2a94f7cc206184a  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 171
529: sched_cls  name tail_ipv4_to_endpoint  tag f7a4342c21307820  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,113,40,37,38
	btf_id 173
530: sched_cls  name tail_handle_arp  tag e14062cf7ea1e937  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 177
535: sched_cls  name tail_ipv4_ct_ingress  tag 983805e37802ca3f  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 178
536: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 184
538: sched_cls  name cil_from_container  tag 64b4678bd9f4ec24  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 186
539: sched_cls  name tail_ipv4_ct_ingress  tag f93f85df4f06989c  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 183
540: sched_cls  name __send_drop_notify  tag 87859992bc3b2c03  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 189
542: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,118
	btf_id 191
544: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 193
545: sched_cls  name tail_handle_ipv4_from_host  tag 110f12b4c1436948  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 194
546: sched_cls  name tail_ipv4_to_endpoint  tag 287e9a3a12ac427f  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 187
547: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 196
548: sched_cls  name __send_drop_notify  tag 87859992bc3b2c03  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 198
552: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 202
553: sched_cls  name tail_handle_ipv4_from_host  tag 110f12b4c1436948  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 203
554: sched_cls  name handle_policy  tag e6092cc4114b3fa8  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 195
555: sched_cls  name __send_drop_notify  tag 2329da5e1af0ab62  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 204
556: sched_cls  name cil_from_container  tag 80fe01561a1fcbf0  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 205
557: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 207
561: sched_cls  name tail_handle_ipv4_from_host  tag 110f12b4c1436948  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 212
562: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 213
563: sched_cls  name __send_drop_notify  tag 87859992bc3b2c03  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 214
564: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 215
565: sched_cls  name tail_ipv4_ct_egress  tag a16bbf356ff5c57a  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 206
568: sched_cls  name tail_handle_ipv4_cont  tag e0eb86fdcbd95395  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 217
569: sched_cls  name tail_handle_ipv4_from_host  tag 110f12b4c1436948  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 220
570: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 221
571: sched_cls  name __send_drop_notify  tag 87859992bc3b2c03  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 223
572: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 224
574: sched_cls  name tail_handle_ipv4  tag 7a684351305072c3  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 222
575: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 226
576: sched_cls  name tail_handle_arp  tag 57d5e8684866e0e3  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 227
577: sched_cls  name tail_ipv4_to_endpoint  tag 1b5ca410afad3c69  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,125,41,82,83,80,100,39,126,40,37,38
	btf_id 229
579: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,126
	btf_id 231
580: sched_cls  name handle_policy  tag cfe31287a7171e44  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,126,82,83,125,41,80,100,39,84,75,40,37,38
	btf_id 232
581: sched_cls  name tail_handle_ipv4  tag fe38b3c65bc90a35  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,126
	btf_id 233
582: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 234
583: sched_cls  name tail_ipv4_ct_ingress  tag 0b991624025103bc  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 235
584: sched_cls  name __send_drop_notify  tag 6fcdfe1aae6c123b  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 236
585: sched_cls  name cil_from_container  tag 8eec2c65f593ecf3  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 126,76
	btf_id 237
586: sched_cls  name tail_handle_ipv4_cont  tag 750c57e246b7a1d7  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,125,41,100,82,83,39,76,74,77,126,40,37,38,81
	btf_id 238
587: sched_cls  name tail_handle_arp  tag 55f87b83f6569ac8  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,126
	btf_id 239
588: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
591: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
592: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
595: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
596: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
599: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
600: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
603: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
643: sched_cls  name tail_ipv4_ct_ingress  tag 11544ee7bb5a639d  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 253
645: sched_cls  name cil_from_container  tag 1432c34e75889f92  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 142,76
	btf_id 255
646: sched_cls  name handle_policy  tag 307a3f03175391c9  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,142,82,83,143,41,80,141,39,84,75,40,37,38
	btf_id 256
647: sched_cls  name tail_ipv4_to_endpoint  tag fa8dfc86d4357c53  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,143,41,82,83,80,141,39,142,40,37,38
	btf_id 257
648: sched_cls  name tail_handle_arp  tag 9052b048aa01bd3b  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,142
	btf_id 258
649: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,142
	btf_id 259
650: sched_cls  name tail_ipv4_ct_egress  tag f96aa0f60db65622  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 260
651: sched_cls  name tail_handle_ipv4  tag 82bd395ce0d4ec7e  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,142
	btf_id 261
652: sched_cls  name __send_drop_notify  tag b4388d802dc3002a  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 262
653: sched_cls  name tail_handle_ipv4_cont  tag 41c223a6374bf238  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,143,41,141,82,83,39,76,74,77,142,40,37,38,81
	btf_id 263
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
670: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
673: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
674: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
677: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
678: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
681: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
