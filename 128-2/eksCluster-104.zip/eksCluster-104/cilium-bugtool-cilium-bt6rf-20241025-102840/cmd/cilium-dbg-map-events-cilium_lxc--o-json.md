{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:52.631Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.153.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:52.631Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.188.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:52.631Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:57.076Z",
  "value": "id=48    sec_id=4     flags=0x0000 ifindex=10  mac=9A:5B:68:88:42:E4 nodemac=9E:0C:8D:F3:09:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:57.082Z",
  "value": "id=980   sec_id=6936077 flags=0x0000 ifindex=12  mac=FE:35:6E:7A:AB:4D nodemac=A6:DE:82:70:03:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:57.114Z",
  "value": "id=1261  sec_id=6936077 flags=0x0000 ifindex=14  mac=BE:82:B0:88:4C:F7 nodemac=BE:93:D2:79:EB:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:57.155Z",
  "value": "id=48    sec_id=4     flags=0x0000 ifindex=10  mac=9A:5B:68:88:42:E4 nodemac=9E:0C:8D:F3:09:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:08.925Z",
  "value": "id=48    sec_id=4     flags=0x0000 ifindex=10  mac=9A:5B:68:88:42:E4 nodemac=9E:0C:8D:F3:09:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:08.926Z",
  "value": "id=980   sec_id=6936077 flags=0x0000 ifindex=12  mac=FE:35:6E:7A:AB:4D nodemac=A6:DE:82:70:03:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:08.926Z",
  "value": "id=1261  sec_id=6936077 flags=0x0000 ifindex=14  mac=BE:82:B0:88:4C:F7 nodemac=BE:93:D2:79:EB:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:08.956Z",
  "value": "id=2298  sec_id=6911961 flags=0x0000 ifindex=16  mac=F6:87:E8:C2:52:76 nodemac=4E:E7:44:93:D5:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:09.921Z",
  "value": "id=48    sec_id=4     flags=0x0000 ifindex=10  mac=9A:5B:68:88:42:E4 nodemac=9E:0C:8D:F3:09:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:09.921Z",
  "value": "id=2298  sec_id=6911961 flags=0x0000 ifindex=16  mac=F6:87:E8:C2:52:76 nodemac=4E:E7:44:93:D5:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:09.922Z",
  "value": "id=980   sec_id=6936077 flags=0x0000 ifindex=12  mac=FE:35:6E:7A:AB:4D nodemac=A6:DE:82:70:03:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:09.922Z",
  "value": "id=1261  sec_id=6936077 flags=0x0000 ifindex=14  mac=BE:82:B0:88:4C:F7 nodemac=BE:93:D2:79:EB:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:45.272Z",
  "value": "id=1214  sec_id=6911961 flags=0x0000 ifindex=18  mac=AA:9C:D0:BB:8B:7A nodemac=02:53:79:BC:BB:D7"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.104.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:50.875Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:15.994Z",
  "value": "id=980   sec_id=6936077 flags=0x0000 ifindex=12  mac=FE:35:6E:7A:AB:4D nodemac=A6:DE:82:70:03:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:15.995Z",
  "value": "id=1261  sec_id=6936077 flags=0x0000 ifindex=14  mac=BE:82:B0:88:4C:F7 nodemac=BE:93:D2:79:EB:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:15.995Z",
  "value": "id=1214  sec_id=6911961 flags=0x0000 ifindex=18  mac=AA:9C:D0:BB:8B:7A nodemac=02:53:79:BC:BB:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:15.996Z",
  "value": "id=48    sec_id=4     flags=0x0000 ifindex=10  mac=9A:5B:68:88:42:E4 nodemac=9E:0C:8D:F3:09:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:16.987Z",
  "value": "id=48    sec_id=4     flags=0x0000 ifindex=10  mac=9A:5B:68:88:42:E4 nodemac=9E:0C:8D:F3:09:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:16.988Z",
  "value": "id=1214  sec_id=6911961 flags=0x0000 ifindex=18  mac=AA:9C:D0:BB:8B:7A nodemac=02:53:79:BC:BB:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:16.988Z",
  "value": "id=980   sec_id=6936077 flags=0x0000 ifindex=12  mac=FE:35:6E:7A:AB:4D nodemac=A6:DE:82:70:03:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:16.988Z",
  "value": "id=1261  sec_id=6936077 flags=0x0000 ifindex=14  mac=BE:82:B0:88:4C:F7 nodemac=BE:93:D2:79:EB:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:17.988Z",
  "value": "id=1261  sec_id=6936077 flags=0x0000 ifindex=14  mac=BE:82:B0:88:4C:F7 nodemac=BE:93:D2:79:EB:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:17.988Z",
  "value": "id=1214  sec_id=6911961 flags=0x0000 ifindex=18  mac=AA:9C:D0:BB:8B:7A nodemac=02:53:79:BC:BB:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:17.988Z",
  "value": "id=48    sec_id=4     flags=0x0000 ifindex=10  mac=9A:5B:68:88:42:E4 nodemac=9E:0C:8D:F3:09:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:17.989Z",
  "value": "id=980   sec_id=6936077 flags=0x0000 ifindex=12  mac=FE:35:6E:7A:AB:4D nodemac=A6:DE:82:70:03:A4"
}

