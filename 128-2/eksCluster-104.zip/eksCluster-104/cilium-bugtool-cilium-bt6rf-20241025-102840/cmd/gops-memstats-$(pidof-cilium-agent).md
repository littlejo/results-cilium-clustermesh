alloc: 87.91MB (92176176 bytes)
total-alloc: 1.35GB (1445036152 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 48033937
frees: 47290535
heap-alloc: 87.91MB (92176176 bytes)
heap-sys: 165.30MB (173326336 bytes)
heap-idle: 45.18MB (47374336 bytes)
heap-in-use: 120.12MB (125952000 bytes)
heap-released: 3.47MB (3637248 bytes)
heap-objects: 743402
stack-in-use: 34.66MB (36339712 bytes)
stack-sys: 34.66MB (36339712 bytes)
stack-mspan-inuse: 1.97MB (2069760 bytes)
stack-mspan-sys: 2.49MB (2611200 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 892.98KB (914409 bytes)
gc-sys: 5.16MB (5411000 bytes)
next-gc: when heap-alloc >= 147.80MB (154983560 bytes)
last-gc: 2024-10-25 10:28:55.056146132 +0000 UTC
gc-pause-total: 11.929724ms
gc-pause: 108818
gc-pause-end: 1729852135056146132
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.0003886463086804812
enable-gc: true
debug-gc: false
