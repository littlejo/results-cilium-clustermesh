IP ADDRESS         LOCAL ENDPOINT INFO
172.31.153.253:0   (localhost)                                                                                        
172.31.188.169:0   (localhost)                                                                                        
10.104.0.7:0       id=1261  sec_id=6936077 flags=0x0000 ifindex=14  mac=BE:82:B0:88:4C:F7 nodemac=BE:93:D2:79:EB:9C   
10.104.0.154:0     id=48    sec_id=4     flags=0x0000 ifindex=10  mac=9A:5B:68:88:42:E4 nodemac=9E:0C:8D:F3:09:2E     
10.104.0.224:0     id=980   sec_id=6936077 flags=0x0000 ifindex=12  mac=FE:35:6E:7A:AB:4D nodemac=A6:DE:82:70:03:A4   
10.104.0.193:0     id=1214  sec_id=6911961 flags=0x0000 ifindex=18  mac=AA:9C:D0:BB:8B:7A nodemac=02:53:79:BC:BB:D7   
10.104.0.34:0      (localhost)                                                                                        
