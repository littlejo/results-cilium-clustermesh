Endpoint ID: 48
Path: /sys/fs/bpf/tc/globals/cilium_policy_00048

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    429502   5461      0        
Allow    Ingress     1          ANY          NONE         disabled    10558    123       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 725
Path: /sys/fs/bpf/tc/globals/cilium_policy_00725

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 980
Path: /sys/fs/bpf/tc/globals/cilium_policy_00980

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69148   791       0        
Allow    Egress      0          ANY          NONE         disabled    12985   132       0        


Endpoint ID: 1214
Path: /sys/fs/bpf/tc/globals/cilium_policy_01214

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3856707   36578     0        
Allow    Ingress     1          ANY          NONE         disabled    3275226   33297     0        
Allow    Egress      0          ANY          NONE         disabled    4895195   45078     0        


Endpoint ID: 1261
Path: /sys/fs/bpf/tc/globals/cilium_policy_01261

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    68862   791       0        
Allow    Egress      0          ANY          NONE         disabled    12201   123       0        


