REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10063     789330     677    bpf_overlay.c
Interface                 INGRESS     221285    85208365   1132   bpf_host.c
Success                   EGRESS      10288     805062     53     encap.h
Success                   EGRESS      5268      405062     1694   bpf_host.c
Success                   EGRESS      93836     12447646   1308   bpf_lxc.c
Success                   INGRESS     104904    12919165   86     l3.h
Success                   INGRESS     110348    13347339   235    trace.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
