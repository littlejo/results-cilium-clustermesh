key: 30 00 00 00  value: 44 02 00 00
key: d4 03 00 00  value: 0a 02 00 00
key: be 04 00 00  value: 86 02 00 00
key: ed 04 00 00  value: 2a 02 00 00
Found 4 elements
