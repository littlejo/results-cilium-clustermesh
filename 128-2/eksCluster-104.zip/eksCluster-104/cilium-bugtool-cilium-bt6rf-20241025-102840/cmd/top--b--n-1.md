top - 10:28:41 up 13 min,  0 users,  load average: 0.10, 0.14, 0.14
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 10.0 us, 23.3 sy,  0.0 ni, 66.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    783.2 free,    910.9 used,   2142.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2756.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 279092  78212 S  13.3   7.1   0:22.72 cilium-+
    680 root      20   0 1240432  16428  11420 S   6.7   0.4   0:00.03 cilium-+
    416 root      20   0 1228848   5556   2924 S   0.0   0.1   0:00.26 cilium-+
    648 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    654 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    661 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    687 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    717 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    735 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
