CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod14577d3b_1bbc_4ffa_ad58_3b4c879124fe.slice/cri-containerd-965556a9e0b95c17c650d973cd04858c1770bbd7fe3fefdb0bf949359a4aba4c.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod14577d3b_1bbc_4ffa_ad58_3b4c879124fe.slice/cri-containerd-bc373cfaa433b76520f42dbe0f9bad5ef9d3577998d03c20adacaf4c3dbca369.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc4abf3fd_6157_4229_945c_b32a5ca50752.slice/cri-containerd-b9f9cded6051ead2dfa8ea0513143fe9f296302c0fab1e68e0fe091b14759015.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc4abf3fd_6157_4229_945c_b32a5ca50752.slice/cri-containerd-677594961d27e511ee5a6d742f69ac6450fc0b470b43a49bbcdab8464ea3d358.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd682e127_8784_4c40_9d2d_944ddfb84ceb.slice/cri-containerd-85aaed85bd7df9d046a892c5e6fa3d74f77be871a8b52ac4e6b2f885c422866a.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd682e127_8784_4c40_9d2d_944ddfb84ceb.slice/cri-containerd-f24675896a142c98a5513059939f94d0713f206d30579ff4b3a8543afc17e7e4.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod342faaea_5300_4d32_a876_8d1766daf325.slice/cri-containerd-a48fb78544533148405c1ca97fe6e51e44cbd1eeb0e32ec0a97da5a6d5b7ced6.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod342faaea_5300_4d32_a876_8d1766daf325.slice/cri-containerd-2290c0c85654edd19cb6dff835b03ad3b36c46b9f442d42ef49fbc14d212e52c.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc89855e0_6cb2_4186_bff9_a34772e6083b.slice/cri-containerd-f02ad133e9eb0812bf465290878b399e6d0db68775974bfe16b7c8cbbcecd9c4.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc89855e0_6cb2_4186_bff9_a34772e6083b.slice/cri-containerd-99364e2ee8f900065c0876f0729b2bcf401afee2b966c6d993270e20210d0e34.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc89855e0_6cb2_4186_bff9_a34772e6083b.slice/cri-containerd-aedf9c4a139a17263340fa65bbf4de6f299a86fb5919346e9064d24854807f09.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc89855e0_6cb2_4186_bff9_a34772e6083b.slice/cri-containerd-12e983ab548ddc01d66e1807e95af144af5a7f263d87fa408198e1786ea5c702.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod97abb52a_2660_4a97_ae98_2b3cafa8b328.slice/cri-containerd-a9777c87532dbfe4cc8a76c07655d3221aa60c708bc27d252a69d8089b82c364.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod97abb52a_2660_4a97_ae98_2b3cafa8b328.slice/cri-containerd-34959832d264ad8c56a1875d275f6c65b9c60b3a3c813ac13ac8d5877318f6cc.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf5002c83_fbd1_487f_a398_4ce05e377ba6.slice/cri-containerd-e97bcd0f4095da0501cfc28223857196a5a9d721cc3e57528b26dd436adcafbf.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf5002c83_fbd1_487f_a398_4ce05e377ba6.slice/cri-containerd-d4f01a2f16d6d56984503af5d409e6ce94b026bcf17329a2e21955da5abad057.scope
    101      cgroup_device   multi                                          
