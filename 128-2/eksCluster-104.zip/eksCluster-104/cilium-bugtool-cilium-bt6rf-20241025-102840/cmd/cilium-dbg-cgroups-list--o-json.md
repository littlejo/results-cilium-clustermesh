[
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc4abf3fd_6157_4229_945c_b32a5ca50752.slice/cri-containerd-b9f9cded6051ead2dfa8ea0513143fe9f296302c0fab1e68e0fe091b14759015.scope"
      }
    ],
    "ips": [
      "10.104.0.7"
    ],
    "name": "coredns-cc6ccd49c-kxzvc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9220,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc89855e0_6cb2_4186_bff9_a34772e6083b.slice/cri-containerd-f02ad133e9eb0812bf465290878b399e6d0db68775974bfe16b7c8cbbcecd9c4.scope"
      },
      {
        "cgroup-id": 9136,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc89855e0_6cb2_4186_bff9_a34772e6083b.slice/cri-containerd-99364e2ee8f900065c0876f0729b2bcf401afee2b966c6d993270e20210d0e34.scope"
      },
      {
        "cgroup-id": 9304,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc89855e0_6cb2_4186_bff9_a34772e6083b.slice/cri-containerd-12e983ab548ddc01d66e1807e95af144af5a7f263d87fa408198e1786ea5c702.scope"
      }
    ],
    "ips": [
      "10.104.0.193"
    ],
    "name": "clustermesh-apiserver-7474669c9f-lxkpt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod342faaea_5300_4d32_a876_8d1766daf325.slice/cri-containerd-a48fb78544533148405c1ca97fe6e51e44cbd1eeb0e32ec0a97da5a6d5b7ced6.scope"
      }
    ],
    "ips": [
      "10.104.0.224"
    ],
    "name": "coredns-cc6ccd49c-9dpp8",
    "namespace": "kube-system"
  }
]

