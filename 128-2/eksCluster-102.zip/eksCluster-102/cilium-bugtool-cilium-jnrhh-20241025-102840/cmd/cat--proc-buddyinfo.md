Node 0, zone      DMA     46     10      3      2      3      0      4     10      7      8    170 
Node 0, zone   Normal    676    200     58      5     26     10      5      5      2      2      6 
