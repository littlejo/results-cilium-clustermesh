IP ADDRESS         LOCAL ENDPOINT INFO
10.102.0.155:0     id=3589  sec_id=6765596 flags=0x0000 ifindex=12  mac=4A:10:82:63:8F:0D nodemac=CA:CA:B0:EE:02:36   
172.31.184.93:0    (localhost)                                                                                        
10.102.0.132:0     id=294   sec_id=6771774 flags=0x0000 ifindex=18  mac=1A:5D:29:8D:E7:10 nodemac=F6:CA:05:B8:24:46   
10.102.0.29:0      id=129   sec_id=6765596 flags=0x0000 ifindex=14  mac=FA:13:A6:3B:E7:4D nodemac=32:5F:52:5F:11:3D   
10.102.0.61:0      id=600   sec_id=4     flags=0x0000 ifindex=10  mac=22:F1:33:E7:A3:B1 nodemac=56:74:22:63:70:BE     
10.102.0.20:0      (localhost)                                                                                        
172.31.130.106:0   (localhost)                                                                                        
