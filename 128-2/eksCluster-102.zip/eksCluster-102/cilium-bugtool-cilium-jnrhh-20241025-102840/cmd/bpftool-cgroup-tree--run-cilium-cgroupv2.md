CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0618d04_bf84_41a0_b6af_f0c37dce3e6b.slice/cri-containerd-1c89e624959334fa6be9cb433fd7b6d10f36f2697162b8723cadee456d2fe8c0.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0618d04_bf84_41a0_b6af_f0c37dce3e6b.slice/cri-containerd-75d7ec5804616ceceb2f3c1c42545cf030012f618fef96c24c2047da5060a3bf.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4dad04a6_4e1b_4e27_8484_c618a00552d0.slice/cri-containerd-337852897cd3e6c65b2ad5bdaba25b13818d964c906e80340d9c9476a1983840.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4dad04a6_4e1b_4e27_8484_c618a00552d0.slice/cri-containerd-f413aa66be0608b7eb291a1546788871e54e786b86bb9fc8b873fdc4eb6cc975.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf99b0845_9b14_4318_97cc_af835f3123c0.slice/cri-containerd-582fc8684431e2d0cff24aacbfccc3725dada5ebb9d6a4e5ad0af600a2c54213.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf99b0845_9b14_4318_97cc_af835f3123c0.slice/cri-containerd-fb568c9e5c664e28382c37b7b4aa2add7dab3520404ec0ce61d940b03fb5bbb0.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod26e9e3c6_ced2_431f_a599_fbb8378922e6.slice/cri-containerd-6df5c6fbbbcaae447899ab5192ee17e00db076078cb5d2c631cd60fb5ad0434b.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod26e9e3c6_ced2_431f_a599_fbb8378922e6.slice/cri-containerd-5a618c7629563247e97792a3861f68367135b4458cbc7827fa8bd2cb40f2eb58.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61c11a9b_0410_46fb_bc87_a78dce22d1d6.slice/cri-containerd-162fd16943a359b9344dd8c9c82e537a6113f16e3a7824c95fcb24061e483f62.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61c11a9b_0410_46fb_bc87_a78dce22d1d6.slice/cri-containerd-a0b094d79ba6dc8413747f2dac46c4bc87bc4e07c5dac8a2bc97f986a3a52d73.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61c11a9b_0410_46fb_bc87_a78dce22d1d6.slice/cri-containerd-3e02aa070ac4a212d990844db5a1d8d6d8b3d0c39ed43a845e382067ac0555a9.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61c11a9b_0410_46fb_bc87_a78dce22d1d6.slice/cri-containerd-567b692dc736aab658f8a63e4ce92dfd14d82f17526c5486b859adafeffa7a63.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9d2db02_10e2_420e_914f_bc4211880c4c.slice/cri-containerd-ffaad079974570cebea8ef5a58246607d2ea1b0b4f77e6ad6dc0314ffbaf2797.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9d2db02_10e2_420e_914f_bc4211880c4c.slice/cri-containerd-76c8ddfac768021026e305c3a12d41529d2284c9ce6b12dacc42d80a61b29909.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod59d959ff_965a_4b5b_aea3_bb09903eff8e.slice/cri-containerd-cf2d5782c3e88fa43c1bf62bd0a92c0fbb5ece60b5878c8eb444e8cd8fca1815.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod59d959ff_965a_4b5b_aea3_bb09903eff8e.slice/cri-containerd-628bb9342f7690872c3fcfb96c3d63d5e939855b90e70a1ab2ca24f98eb5c156.scope
    105      cgroup_device   multi                                          
