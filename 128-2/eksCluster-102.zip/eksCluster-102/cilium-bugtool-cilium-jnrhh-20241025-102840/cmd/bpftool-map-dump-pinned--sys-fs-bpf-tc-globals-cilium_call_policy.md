key: 81 00 00 00  value: 24 02 00 00
key: 26 01 00 00  value: 71 02 00 00
key: 58 02 00 00  value: 29 02 00 00
key: 05 0e 00 00  value: 13 02 00 00
Found 4 elements
