xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 507
ens6(5) clsact/ingress cil_from_netdev-ens6 id 515
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 498
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 492
cilium_host(7) clsact/egress cil_from_host-cilium_host id 490
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 540
lxc25cb002bebd6(12) clsact/ingress cil_from_container-lxc25cb002bebd6 id 520
lxca4141759b4a8(14) clsact/ingress cil_from_container-lxca4141759b4a8 id 543
lxc13c9d38a60cc(18) clsact/ingress cil_from_container-lxc13c9d38a60cc id 624

flow_dissector:

netfilter:

