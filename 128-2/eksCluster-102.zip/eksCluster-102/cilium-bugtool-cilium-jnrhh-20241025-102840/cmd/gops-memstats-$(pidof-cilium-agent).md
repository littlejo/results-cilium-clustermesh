alloc: 81.67MB (85637208 bytes)
total-alloc: 1.28GB (1371715264 bytes)
sys: 197.88MB (207493444 bytes)
lookups: 0
mallocs: 46905103
frees: 46202668
heap-alloc: 81.67MB (85637208 bytes)
heap-sys: 153.76MB (161226752 bytes)
heap-idle: 38.16MB (40009728 bytes)
heap-in-use: 115.60MB (121217024 bytes)
heap-released: 3.49MB (3661824 bytes)
heap-objects: 702435
stack-in-use: 34.22MB (35880960 bytes)
stack-sys: 34.22MB (35880960 bytes)
stack-mspan-inuse: 1.94MB (2035840 bytes)
stack-mspan-sys: 2.30MB (2415360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 857.70KB (878289 bytes)
gc-sys: 4.86MB (5100616 bytes)
next-gc: when heap-alloc >= 147.09MB (154239656 bytes)
last-gc: 2024-10-25 10:28:57.98963502 +0000 UTC
gc-pause-total: 5.916387ms
gc-pause: 94344
gc-pause-end: 1729852137989635020
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00036968929270827524
enable-gc: true
debug-gc: false
