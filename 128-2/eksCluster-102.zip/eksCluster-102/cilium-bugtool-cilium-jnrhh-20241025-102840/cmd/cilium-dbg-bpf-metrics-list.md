REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     201594    82949068   1132   bpf_host.c
Interface                 INGRESS     8575      671012     677    bpf_overlay.c
Success                   EGRESS      3751      285426     1694   bpf_host.c
Success                   EGRESS      8014      630363     53     encap.h
Success                   EGRESS      85075     11669791   1308   bpf_lxc.c
Success                   INGRESS     94170     11580042   86     l3.h
Success                   INGRESS     99643     12009534   235    trace.h
Unsupported L3 protocol   EGRESS      37        2762       1492   bpf_lxc.c
