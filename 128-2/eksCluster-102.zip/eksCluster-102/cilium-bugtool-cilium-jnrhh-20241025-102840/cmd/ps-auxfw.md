USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         812  0.0  0.1 1229000 4052 ?        Ssl  10:28   0:00 /bin/gops memstats 1
root         804  0.0  0.1 1228744 4036 ?        Ssl  10:28   0:00 /bin/gops stats 1
root         794  0.0  0.4 1240432 16268 ?       Dsl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         826  0.0  0.4 1240432 16268 ?       R    10:28   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         827  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         780  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         774  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops stack 1
root           1  2.8  6.7 1472048 265132 ?      Ssl  10:16   0:20 cilium-agent --config-dir=/tmp/cilium/config-map
root         397  0.0  0.1 1228848 7104 ?        Sl   10:16   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
