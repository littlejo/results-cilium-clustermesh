{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.495Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.130.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.495Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.184.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.495Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:00.167Z",
  "value": "id=600   sec_id=4     flags=0x0000 ifindex=10  mac=22:F1:33:E7:A3:B1 nodemac=56:74:22:63:70:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:00.171Z",
  "value": "id=3589  sec_id=6765596 flags=0x0000 ifindex=12  mac=4A:10:82:63:8F:0D nodemac=CA:CA:B0:EE:02:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:00.209Z",
  "value": "id=129   sec_id=6765596 flags=0x0000 ifindex=14  mac=FA:13:A6:3B:E7:4D nodemac=32:5F:52:5F:11:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:00.242Z",
  "value": "id=600   sec_id=4     flags=0x0000 ifindex=10  mac=22:F1:33:E7:A3:B1 nodemac=56:74:22:63:70:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:11.183Z",
  "value": "id=600   sec_id=4     flags=0x0000 ifindex=10  mac=22:F1:33:E7:A3:B1 nodemac=56:74:22:63:70:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:11.184Z",
  "value": "id=3589  sec_id=6765596 flags=0x0000 ifindex=12  mac=4A:10:82:63:8F:0D nodemac=CA:CA:B0:EE:02:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:11.185Z",
  "value": "id=129   sec_id=6765596 flags=0x0000 ifindex=14  mac=FA:13:A6:3B:E7:4D nodemac=32:5F:52:5F:11:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:11.215Z",
  "value": "id=3787  sec_id=6771774 flags=0x0000 ifindex=16  mac=6E:AA:BE:55:D0:A3 nodemac=92:77:5A:77:EF:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:11.215Z",
  "value": "id=3787  sec_id=6771774 flags=0x0000 ifindex=16  mac=6E:AA:BE:55:D0:A3 nodemac=92:77:5A:77:EF:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:12.184Z",
  "value": "id=3787  sec_id=6771774 flags=0x0000 ifindex=16  mac=6E:AA:BE:55:D0:A3 nodemac=92:77:5A:77:EF:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:12.184Z",
  "value": "id=600   sec_id=4     flags=0x0000 ifindex=10  mac=22:F1:33:E7:A3:B1 nodemac=56:74:22:63:70:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:12.185Z",
  "value": "id=3589  sec_id=6765596 flags=0x0000 ifindex=12  mac=4A:10:82:63:8F:0D nodemac=CA:CA:B0:EE:02:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:12.185Z",
  "value": "id=129   sec_id=6765596 flags=0x0000 ifindex=14  mac=FA:13:A6:3B:E7:4D nodemac=32:5F:52:5F:11:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.373Z",
  "value": "id=294   sec_id=6771774 flags=0x0000 ifindex=18  mac=1A:5D:29:8D:E7:10 nodemac=F6:CA:05:B8:24:46"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.102.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:00.118Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:17.108Z",
  "value": "id=294   sec_id=6771774 flags=0x0000 ifindex=18  mac=1A:5D:29:8D:E7:10 nodemac=F6:CA:05:B8:24:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:17.109Z",
  "value": "id=600   sec_id=4     flags=0x0000 ifindex=10  mac=22:F1:33:E7:A3:B1 nodemac=56:74:22:63:70:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:17.109Z",
  "value": "id=3589  sec_id=6765596 flags=0x0000 ifindex=12  mac=4A:10:82:63:8F:0D nodemac=CA:CA:B0:EE:02:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:17.110Z",
  "value": "id=129   sec_id=6765596 flags=0x0000 ifindex=14  mac=FA:13:A6:3B:E7:4D nodemac=32:5F:52:5F:11:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:18.086Z",
  "value": "id=294   sec_id=6771774 flags=0x0000 ifindex=18  mac=1A:5D:29:8D:E7:10 nodemac=F6:CA:05:B8:24:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:18.086Z",
  "value": "id=3589  sec_id=6765596 flags=0x0000 ifindex=12  mac=4A:10:82:63:8F:0D nodemac=CA:CA:B0:EE:02:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:18.087Z",
  "value": "id=600   sec_id=4     flags=0x0000 ifindex=10  mac=22:F1:33:E7:A3:B1 nodemac=56:74:22:63:70:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:18.087Z",
  "value": "id=129   sec_id=6765596 flags=0x0000 ifindex=14  mac=FA:13:A6:3B:E7:4D nodemac=32:5F:52:5F:11:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:19.087Z",
  "value": "id=129   sec_id=6765596 flags=0x0000 ifindex=14  mac=FA:13:A6:3B:E7:4D nodemac=32:5F:52:5F:11:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:19.088Z",
  "value": "id=3589  sec_id=6765596 flags=0x0000 ifindex=12  mac=4A:10:82:63:8F:0D nodemac=CA:CA:B0:EE:02:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:19.088Z",
  "value": "id=294   sec_id=6771774 flags=0x0000 ifindex=18  mac=1A:5D:29:8D:E7:10 nodemac=F6:CA:05:B8:24:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:19.088Z",
  "value": "id=600   sec_id=4     flags=0x0000 ifindex=10  mac=22:F1:33:E7:A3:B1 nodemac=56:74:22:63:70:BE"
}

