[
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61c11a9b_0410_46fb_bc87_a78dce22d1d6.slice/cri-containerd-162fd16943a359b9344dd8c9c82e537a6113f16e3a7824c95fcb24061e483f62.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61c11a9b_0410_46fb_bc87_a78dce22d1d6.slice/cri-containerd-a0b094d79ba6dc8413747f2dac46c4bc87bc4e07c5dac8a2bc97f986a3a52d73.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61c11a9b_0410_46fb_bc87_a78dce22d1d6.slice/cri-containerd-3e02aa070ac4a212d990844db5a1d8d6d8b3d0c39ed43a845e382067ac0555a9.scope"
      }
    ],
    "ips": [
      "10.102.0.132"
    ],
    "name": "clustermesh-apiserver-6c7b5ccd57-w6lps",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf99b0845_9b14_4318_97cc_af835f3123c0.slice/cri-containerd-582fc8684431e2d0cff24aacbfccc3725dada5ebb9d6a4e5ad0af600a2c54213.scope"
      }
    ],
    "ips": [
      "10.102.0.29"
    ],
    "name": "coredns-cc6ccd49c-ckxjk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod26e9e3c6_ced2_431f_a599_fbb8378922e6.slice/cri-containerd-6df5c6fbbbcaae447899ab5192ee17e00db076078cb5d2c631cd60fb5ad0434b.scope"
      }
    ],
    "ips": [
      "10.102.0.155"
    ],
    "name": "coredns-cc6ccd49c-rq4r6",
    "namespace": "kube-system"
  }
]

