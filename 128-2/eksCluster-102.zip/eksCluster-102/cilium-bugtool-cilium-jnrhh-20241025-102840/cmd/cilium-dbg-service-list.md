ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.162.155:443 (active)   
                                         2 => 172.31.198.127:443 (active)   
2    10.100.209.187:443   ClusterIP      1 => 172.31.184.93:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.102.0.29:53 (active)       
                                         2 => 10.102.0.155:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.102.0.29:9153 (active)     
                                         2 => 10.102.0.155:9153 (active)    
5    10.100.61.134:2379   ClusterIP      1 => 10.102.0.132:2379 (active)    
