Endpoint ID: 129
Path: /sys/fs/bpf/tc/globals/cilium_policy_00129

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69232   798       0        
Allow    Egress      0          ANY          NONE         disabled    13713   141       0        


Endpoint ID: 133
Path: /sys/fs/bpf/tc/globals/cilium_policy_00133

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 294
Path: /sys/fs/bpf/tc/globals/cilium_policy_00294

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3853886   35534     0        
Allow    Ingress     1          ANY          NONE         disabled    2494702   24627     0        
Allow    Egress      0          ANY          NONE         disabled    3803791   35447     0        


Endpoint ID: 600
Path: /sys/fs/bpf/tc/globals/cilium_policy_00600

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    430686   5488      0        
Allow    Ingress     1          ANY          NONE         disabled    10048    116       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3589
Path: /sys/fs/bpf/tc/globals/cilium_policy_03589

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    68581   786       0        
Allow    Egress      0          ANY          NONE         disabled    12171   123       0        


