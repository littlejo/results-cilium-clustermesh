[
  {
    "containers": [
      {
        "cgroup-id": 6690,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod13595903_c625_4533_b82f_792b3915fb24.slice/cri-containerd-fefc0e604fbc9014b49d21936d9f3ebebc881b8689073c3185025bacce55f240.scope"
      }
    ],
    "ips": [
      "10.37.0.216"
    ],
    "name": "coredns-cc6ccd49c-gh552",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6858,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ceaffe9_4089_41ec_adc7_149abc26db81.slice/cri-containerd-3554d296bf97051da892d28093ab6a02e570cd12a48645e77c422acdd98228b9.scope"
      }
    ],
    "ips": [
      "10.37.0.121"
    ],
    "name": "coredns-cc6ccd49c-bprc6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8286,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c2e6940_3057_4c55_8383_3468568a87e0.slice/cri-containerd-0851feb252d0a7218448a27eee0ac020ac1dd0e40350a42352129289f6c8555b.scope"
      },
      {
        "cgroup-id": 8202,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c2e6940_3057_4c55_8383_3468568a87e0.slice/cri-containerd-1116aba609f3b17ac74368455ca0578ef6276678cbedaf24599ac5a194203e57.scope"
      },
      {
        "cgroup-id": 8370,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c2e6940_3057_4c55_8383_3468568a87e0.slice/cri-containerd-7845b4fe64143bb099db6ecd7f9f64444d391adfbcfd07b8f0b2d28bcf09c8eb.scope"
      }
    ],
    "ips": [
      "10.37.0.31"
    ],
    "name": "clustermesh-apiserver-7b7fb9b4b4-6fqsq",
    "namespace": "kube-system"
  }
]

