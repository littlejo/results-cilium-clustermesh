filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcd2e7efeea59d direct-action not_in_hw id 550 tag efaa0bf4d1f7fb5e jited 
