markdown output at /tmp/cilium-bugtool-20241025-102843.745+0000-UTC-90371565/cmd/cilium-debuginfo-20241025-102914.448+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102843.745+0000-UTC-90371565/cmd/cilium-debuginfo-20241025-102914.448+0000-UTC.json
