IP ADDRESS         LOCAL ENDPOINT INFO
10.37.0.31:0       id=749   sec_id=2537688 flags=0x0000 ifindex=15  mac=AE:F9:24:A1:BA:43 nodemac=B6:B2:B9:2C:22:4B   
10.37.0.251:0      (localhost)                                                                                        
10.37.0.216:0      id=3304  sec_id=2492322 flags=0x0000 ifindex=9   mac=12:1E:45:A0:F1:EA nodemac=2A:F5:07:C3:1A:45   
10.37.0.134:0      id=3563  sec_id=4     flags=0x0000 ifindex=7   mac=7E:35:8A:A9:C7:63 nodemac=A2:7B:0D:E9:BC:3B     
10.37.0.121:0      id=319   sec_id=2492322 flags=0x0000 ifindex=11  mac=96:78:0E:AB:99:E8 nodemac=C2:B9:3E:86:41:70   
172.31.235.234:0   (localhost)                                                                                        
