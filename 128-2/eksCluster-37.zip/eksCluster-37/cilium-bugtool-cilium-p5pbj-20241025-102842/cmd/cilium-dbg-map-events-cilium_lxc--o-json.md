{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:18.118Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.235.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:18.118Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:20.888Z",
  "value": "id=3304  sec_id=2492322 flags=0x0000 ifindex=9   mac=12:1E:45:A0:F1:EA nodemac=2A:F5:07:C3:1A:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:24.325Z",
  "value": "id=319   sec_id=2492322 flags=0x0000 ifindex=11  mac=96:78:0E:AB:99:E8 nodemac=C2:B9:3E:86:41:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:24.334Z",
  "value": "id=3563  sec_id=4     flags=0x0000 ifindex=7   mac=7E:35:8A:A9:C7:63 nodemac=A2:7B:0D:E9:BC:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:24.390Z",
  "value": "id=319   sec_id=2492322 flags=0x0000 ifindex=11  mac=96:78:0E:AB:99:E8 nodemac=C2:B9:3E:86:41:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:24.393Z",
  "value": "id=3304  sec_id=2492322 flags=0x0000 ifindex=9   mac=12:1E:45:A0:F1:EA nodemac=2A:F5:07:C3:1A:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:59.432Z",
  "value": "id=3563  sec_id=4     flags=0x0000 ifindex=7   mac=7E:35:8A:A9:C7:63 nodemac=A2:7B:0D:E9:BC:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:59.432Z",
  "value": "id=319   sec_id=2492322 flags=0x0000 ifindex=11  mac=96:78:0E:AB:99:E8 nodemac=C2:B9:3E:86:41:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:59.432Z",
  "value": "id=3304  sec_id=2492322 flags=0x0000 ifindex=9   mac=12:1E:45:A0:F1:EA nodemac=2A:F5:07:C3:1A:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:59.461Z",
  "value": "id=1520  sec_id=2537688 flags=0x0000 ifindex=13  mac=DA:09:AD:0D:EA:E2 nodemac=0E:75:C6:E2:21:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:00.432Z",
  "value": "id=3563  sec_id=4     flags=0x0000 ifindex=7   mac=7E:35:8A:A9:C7:63 nodemac=A2:7B:0D:E9:BC:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:00.432Z",
  "value": "id=3304  sec_id=2492322 flags=0x0000 ifindex=9   mac=12:1E:45:A0:F1:EA nodemac=2A:F5:07:C3:1A:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:00.433Z",
  "value": "id=1520  sec_id=2537688 flags=0x0000 ifindex=13  mac=DA:09:AD:0D:EA:E2 nodemac=0E:75:C6:E2:21:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:00.433Z",
  "value": "id=319   sec_id=2492322 flags=0x0000 ifindex=11  mac=96:78:0E:AB:99:E8 nodemac=C2:B9:3E:86:41:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:47.098Z",
  "value": "id=749   sec_id=2537688 flags=0x0000 ifindex=15  mac=AE:F9:24:A1:BA:43 nodemac=B6:B2:B9:2C:22:4B"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.37.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.207Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:25.978Z",
  "value": "id=749   sec_id=2537688 flags=0x0000 ifindex=15  mac=AE:F9:24:A1:BA:43 nodemac=B6:B2:B9:2C:22:4B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:25.978Z",
  "value": "id=3304  sec_id=2492322 flags=0x0000 ifindex=9   mac=12:1E:45:A0:F1:EA nodemac=2A:F5:07:C3:1A:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:25.979Z",
  "value": "id=319   sec_id=2492322 flags=0x0000 ifindex=11  mac=96:78:0E:AB:99:E8 nodemac=C2:B9:3E:86:41:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:25.979Z",
  "value": "id=3563  sec_id=4     flags=0x0000 ifindex=7   mac=7E:35:8A:A9:C7:63 nodemac=A2:7B:0D:E9:BC:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:26.978Z",
  "value": "id=749   sec_id=2537688 flags=0x0000 ifindex=15  mac=AE:F9:24:A1:BA:43 nodemac=B6:B2:B9:2C:22:4B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:26.979Z",
  "value": "id=3304  sec_id=2492322 flags=0x0000 ifindex=9   mac=12:1E:45:A0:F1:EA nodemac=2A:F5:07:C3:1A:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:26.979Z",
  "value": "id=319   sec_id=2492322 flags=0x0000 ifindex=11  mac=96:78:0E:AB:99:E8 nodemac=C2:B9:3E:86:41:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:26.979Z",
  "value": "id=3563  sec_id=4     flags=0x0000 ifindex=7   mac=7E:35:8A:A9:C7:63 nodemac=A2:7B:0D:E9:BC:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:27.979Z",
  "value": "id=3563  sec_id=4     flags=0x0000 ifindex=7   mac=7E:35:8A:A9:C7:63 nodemac=A2:7B:0D:E9:BC:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:27.979Z",
  "value": "id=749   sec_id=2537688 flags=0x0000 ifindex=15  mac=AE:F9:24:A1:BA:43 nodemac=B6:B2:B9:2C:22:4B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:27.980Z",
  "value": "id=3304  sec_id=2492322 flags=0x0000 ifindex=9   mac=12:1E:45:A0:F1:EA nodemac=2A:F5:07:C3:1A:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.37.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:27.980Z",
  "value": "id=319   sec_id=2492322 flags=0x0000 ifindex=11  mac=96:78:0E:AB:99:E8 nodemac=C2:B9:3E:86:41:70"
}

