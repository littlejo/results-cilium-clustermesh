ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.158.202:443 (active)    
                                          2 => 172.31.244.210:443 (active)    
2    10.100.204.61:443     ClusterIP      1 => 172.31.235.234:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.37.0.216:53 (active)        
                                          2 => 10.37.0.121:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.37.0.216:9153 (active)      
                                          2 => 10.37.0.121:9153 (active)      
5    10.100.253.109:2379   ClusterIP      1 => 10.37.0.31:2379 (active)       
