alloc: 78.83MB (82660120 bytes)
total-alloc: 1.32GB (1419786424 bytes)
sys: 202.32MB (212146500 bytes)
lookups: 0
mallocs: 47565874
frees: 46892234
heap-alloc: 78.83MB (82660120 bytes)
heap-sys: 157.66MB (165322752 bytes)
heap-idle: 43.13MB (45228032 bytes)
heap-in-use: 114.53MB (120094720 bytes)
heap-released: 3.43MB (3596288 bytes)
heap-objects: 673640
stack-in-use: 34.31MB (35979264 bytes)
stack-sys: 34.31MB (35979264 bytes)
stack-mspan-inuse: 1.92MB (2008960 bytes)
stack-mspan-sys: 2.43MB (2545920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 979.93KB (1003449 bytes)
gc-sys: 5.06MB (5301320 bytes)
next-gc: when heap-alloc >= 147.63MB (154797544 bytes)
last-gc: 2024-10-25 10:28:57.989874085 +0000 UTC
gc-pause-total: 5.607574ms
gc-pause: 171897
gc-pause-end: 1729852137989874085
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.00028471324520760576
enable-gc: true
debug-gc: false
