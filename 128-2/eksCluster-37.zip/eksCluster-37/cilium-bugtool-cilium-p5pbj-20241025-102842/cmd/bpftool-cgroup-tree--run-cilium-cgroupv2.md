CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod61ec6451_9d21_4885_a81c_7ad5e840cf28.slice/cri-containerd-89bd2e1aadbcb182510cc47b303a81dda1c0712f0c11edd83ba3ebee44836efe.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod61ec6451_9d21_4885_a81c_7ad5e840cf28.slice/cri-containerd-a77ba4b87c2b1d5faa92c5fc792dbf42457f23e5f471eaed276966c595b3328b.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod13595903_c625_4533_b82f_792b3915fb24.slice/cri-containerd-f7f23a305cd7c66d40bb97b1c066ef9889fc4fecdefbe60724154a13204ab8a7.scope
    458      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod13595903_c625_4533_b82f_792b3915fb24.slice/cri-containerd-fefc0e604fbc9014b49d21936d9f3ebebc881b8689073c3185025bacce55f240.scope
    466      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ceaffe9_4089_41ec_adc7_149abc26db81.slice/cri-containerd-3554d296bf97051da892d28093ab6a02e570cd12a48645e77c422acdd98228b9.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ceaffe9_4089_41ec_adc7_149abc26db81.slice/cri-containerd-c09e1947ef2c7fd3f120a7a852f8e4dff14f0b51efa0d144f9c469c17122c12a.scope
    556      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod33bb5420_b9c1_47ed_8338_2068401f7595.slice/cri-containerd-ed4efd9bc97dc0b60ddd89c567d071d8a128d8460373fe8a3ea2e61b77db002d.scope
    72       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod33bb5420_b9c1_47ed_8338_2068401f7595.slice/cri-containerd-5e9f9ad1bf77e05cdd2e34b4a46a8b4445dd5b12172327c32c1ad11fafbfef63.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd1f2ee50_b869_4149_90f2_951ebae8b3f2.slice/cri-containerd-67a9d6197b6c1cad0b26455c070b2ad559ef5a330797224a526b79b33afba9ba.scope
    76       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd1f2ee50_b869_4149_90f2_951ebae8b3f2.slice/cri-containerd-36ce2d1a856d435fe330dc9d11190c773739d0e8a94d78800424921205628e8f.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf20355b3_0383_4a5f_8a0c_2393d4145cde.slice/cri-containerd-577d3799cfaf5c7c6fd3adaed4937d30f41ef8c2c768a2f2249c53971eafa37e.scope
    69       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf20355b3_0383_4a5f_8a0c_2393d4145cde.slice/cri-containerd-d941630ed6c09f0ec4922cc63f3136963df40d9765c230f6de2ff8d1bd909b94.scope
    61       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c2e6940_3057_4c55_8383_3468568a87e0.slice/cri-containerd-7845b4fe64143bb099db6ecd7f9f64444d391adfbcfd07b8f0b2d28bcf09c8eb.scope
    638      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c2e6940_3057_4c55_8383_3468568a87e0.slice/cri-containerd-0851feb252d0a7218448a27eee0ac020ac1dd0e40350a42352129289f6c8555b.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c2e6940_3057_4c55_8383_3468568a87e0.slice/cri-containerd-0665e43811474e653b845d16c6e48bfeeb8a7d9773e0e07c6a94973ba1e05511.scope
    614      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c2e6940_3057_4c55_8383_3468568a87e0.slice/cri-containerd-1116aba609f3b17ac74368455ca0578ef6276678cbedaf24599ac5a194203e57.scope
    630      cgroup_device   multi                                          
