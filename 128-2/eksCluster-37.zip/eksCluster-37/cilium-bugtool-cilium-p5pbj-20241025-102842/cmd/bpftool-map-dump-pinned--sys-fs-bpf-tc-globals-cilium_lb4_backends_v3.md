key: 03 00 00 00  value: 0a 25 00 d8 23 c1 00 00  00 00 00 00
key: 07 00 00 00  value: ac 1f f4 d2 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 25 00 1f 09 4b 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 25 00 79 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f eb ea 10 94 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 9e ca 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: 0a 25 00 79 00 35 00 00  00 00 00 00
key: 04 00 00 00  value: 0a 25 00 d8 00 35 00 00  00 00 00 00
Found 8 elements
