# Cilium debug information

#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.37.0.0/24, 
Allocated addresses:
  10.37.0.121 (kube-system/coredns-cc6ccd49c-bprc6)
  10.37.0.134 (health)
  10.37.0.216 (kube-system/coredns-cc6ccd49c-gh552)
  10.37.0.251 (router)
  10.37.0.31 (kube-system/clustermesh-apiserver-7b7fb9b4b4-6fqsq)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: b08df240df90ea9e
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    55s ago        never        0       no error   
  ct-map-pressure                                                     26s ago        never        0       no error   
  daemon-validate-config                                              42s ago        never        0       no error   
  dns-garbage-collector-job                                           1m0s ago       never        0       no error   
  endpoint-2422-regeneration-recovery                                 never          never        0       no error   
  endpoint-319-regeneration-recovery                                  never          never        0       no error   
  endpoint-3304-regeneration-recovery                                 never          never        0       no error   
  endpoint-3563-regeneration-recovery                                 never          never        0       no error   
  endpoint-749-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         5m0s ago       never        0       no error   
  ep-bpf-prog-watchdog                                                26s ago        never        0       no error   
  ipcache-inject-labels                                               56s ago        never        0       no error   
  k8s-heartbeat                                                       10s ago        never        0       no error   
  link-cache                                                          11s ago        never        0       no error   
  local-identity-checkpoint                                           14m32s ago     never        0       no error   
  node-neighbor-link-updater                                          6s ago         never        0       no error   
  remote-etcd-cmesh1                                                  5m48s ago      never        0       no error   
  remote-etcd-cmesh10                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh100                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh101                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh102                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh103                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh104                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh105                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh106                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh107                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh108                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh109                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh11                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh110                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh111                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh112                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh113                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh114                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh115                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh116                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh117                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh118                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh119                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh12                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh120                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh121                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh122                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh123                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh124                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh125                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh126                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh127                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh128                                                5m48s ago      never        0       no error   
  remote-etcd-cmesh13                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh14                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh15                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh16                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh17                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh18                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh19                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh2                                                  5m48s ago      never        0       no error   
  remote-etcd-cmesh20                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh21                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh22                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh23                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh24                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh25                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh26                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh27                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh28                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh29                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh3                                                  5m48s ago      never        0       no error   
  remote-etcd-cmesh30                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh31                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh32                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh33                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh34                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh35                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh36                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh37                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh39                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh4                                                  5m48s ago      never        0       no error   
  remote-etcd-cmesh40                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh41                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh42                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh43                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh44                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh45                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh46                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh47                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh48                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh49                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh5                                                  5m48s ago      never        0       no error   
  remote-etcd-cmesh50                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh51                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh52                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh53                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh54                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh55                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh56                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh57                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh58                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh59                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh6                                                  5m48s ago      never        0       no error   
  remote-etcd-cmesh60                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh61                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh62                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh63                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh64                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh65                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh66                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh67                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh68                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh69                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh7                                                  5m48s ago      never        0       no error   
  remote-etcd-cmesh70                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh71                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh72                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh73                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh74                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh75                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh76                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh77                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh78                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh79                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh8                                                  5m48s ago      never        0       no error   
  remote-etcd-cmesh80                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh81                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh82                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh83                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh84                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh85                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh86                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh87                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh88                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh89                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh9                                                  5m48s ago      never        0       no error   
  remote-etcd-cmesh90                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh91                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh92                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh93                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh94                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh95                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh96                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh97                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh98                                                 5m48s ago      never        0       no error   
  remote-etcd-cmesh99                                                 5m48s ago      never        0       no error   
  resolve-identity-2422                                               4m56s ago      never        0       no error   
  resolve-identity-319                                                4m55s ago      never        0       no error   
  resolve-identity-3304                                               4m55s ago      never        0       no error   
  resolve-identity-3563                                               4m55s ago      never        0       no error   
  resolve-identity-749                                                1m27s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-7b7fb9b4b4-6fqsq   6m27s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-bprc6                  14m55s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-gh552                  14m55s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      14m56s ago     never        0       no error   
  sync-policymap-2422                                                 14m55s ago     never        0       no error   
  sync-policymap-319                                                  14m50s ago     never        0       no error   
  sync-policymap-3304                                                 14m53s ago     never        0       no error   
  sync-policymap-3563                                                 14m50s ago     never        0       no error   
  sync-policymap-749                                                  6m27s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (319)                                    5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3304)                                   5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (749)                                    7s ago         never        0       no error   
  sync-utime                                                          56s ago        never        0       no error   
  write-cni-file                                                      15m0s ago      never        0       no error   
Proxy Status:            OK, ip 10.37.0.251, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 2490368, max 2555903
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 66.98   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 37771464                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 37771464                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 37771464                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400c000000 rw-p 00000000 00:00 0 
ffff3b415000-ffff3b60a000 rw-p 00000000 00:00 0 
ffff3b612000-ffff3b6f3000 rw-p 00000000 00:00 0 
ffff3b6f3000-ffff3b734000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff3b734000-ffff3b775000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff3b775000-ffff3b7b5000 rw-p 00000000 00:00 0 
ffff3b7b5000-ffff3b7b7000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff3b7b7000-ffff3b7b9000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff3b7b9000-ffff3bd80000 rw-p 00000000 00:00 0 
ffff3bd80000-ffff3be80000 rw-p 00000000 00:00 0 
ffff3be80000-ffff3be91000 rw-p 00000000 00:00 0 
ffff3be91000-ffff3de91000 rw-p 00000000 00:00 0 
ffff3de91000-ffff3df11000 ---p 00000000 00:00 0 
ffff3df11000-ffff3df12000 rw-p 00000000 00:00 0 
ffff3df12000-ffff5df11000 ---p 00000000 00:00 0 
ffff5df11000-ffff5df12000 rw-p 00000000 00:00 0 
ffff5df12000-ffff7dea1000 ---p 00000000 00:00 0 
ffff7dea1000-ffff7dea2000 rw-p 00000000 00:00 0 
ffff7dea2000-ffff81e93000 ---p 00000000 00:00 0 
ffff81e93000-ffff81e94000 rw-p 00000000 00:00 0 
ffff81e94000-ffff82691000 ---p 00000000 00:00 0 
ffff82691000-ffff82692000 rw-p 00000000 00:00 0 
ffff82692000-ffff82791000 ---p 00000000 00:00 0 
ffff82791000-ffff827f1000 rw-p 00000000 00:00 0 
ffff827f1000-ffff827f3000 r--p 00000000 00:00 0                          [vvar]
ffff827f3000-ffff827f4000 r-xp 00000000 00:00 0                          [vdso]
ffffde0f9000-ffffde11a000 rw-p 00000000 00:00 0                          [stack]

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.37.0.251": (string) (len=6) "router",
  (string) (len=11) "10.37.0.134": (string) (len=6) "health",
  (string) (len=11) "10.37.0.216": (string) (len=35) "kube-system/coredns-cc6ccd49c-gh552",
  (string) (len=11) "10.37.0.121": (string) (len=35) "kube-system/coredns-cc6ccd49c-bprc6",
  (string) (len=10) "10.37.0.31": (string) (len=50) "kube-system/clustermesh-apiserver-7b7fb9b4b4-6fqsq"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.235.234": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001aec6e0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4000ef8120,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4000ef8120,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4001e3fad0)(frontends:[10.100.0.10]/ports=[metrics dns dns-tcp]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4002363340)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40023633f0)(frontends:[10.100.253.109]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4001e3f8c0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4001e3f970)(frontends:[10.100.204.61]/ports=[peer-service]/selector=map[k8s-app:cilium])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4001235ed0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4002301790)(172.31.158.202:443/TCP,172.31.244.210:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4001235ed8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-6rqzb": (*k8s.Endpoints)(0x40020452b0)(172.31.235.234:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4001235ee0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-wtq52": (*k8s.Endpoints)(0x4000dc4750)(10.37.0.121:53/TCP[eu-west-3b],10.37.0.121:53/UDP[eu-west-3b],10.37.0.121:9153/TCP[eu-west-3b],10.37.0.216:53/TCP[eu-west-3b],10.37.0.216:53/UDP[eu-west-3b],10.37.0.216:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4000daeb08)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-7xspm": (*k8s.Endpoints)(0x40030c8ea0)(10.37.0.31:2379/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001af2000)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40026ef400)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400389c558
  },
  gcTrigger: (chan struct {}) (cap=1) 0x40026ed8c0,
  gcExited: (chan struct {}) 0x40026ed920,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001ad6000)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001c362e8)({
      MetricVec: (*prometheus.MetricVec)(0x400269a360)({
       metricMap: (*prometheus.metricMap)(0x400269a390)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a6e000)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001ad6080)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001c362f0)({
      MetricVec: (*prometheus.MetricVec)(0x400269a3f0)({
       metricMap: (*prometheus.metricMap)(0x400269a420)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a6e060)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001ad6100)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001c362f8)({
      MetricVec: (*prometheus.MetricVec)(0x400269a480)({
       metricMap: (*prometheus.metricMap)(0x400269a4b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a6e0c0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001ad6180)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001c36300)({
      MetricVec: (*prometheus.MetricVec)(0x400269a510)({
       metricMap: (*prometheus.metricMap)(0x400269a540)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a6e120)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001ad6200)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001c36308)({
      MetricVec: (*prometheus.MetricVec)(0x400269a5a0)({
       metricMap: (*prometheus.metricMap)(0x400269a5d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a6e180)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001ad6280)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001c36310)({
      MetricVec: (*prometheus.MetricVec)(0x400269a630)({
       metricMap: (*prometheus.metricMap)(0x400269a660)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a6e1e0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001ad6300)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001c36318)({
      MetricVec: (*prometheus.MetricVec)(0x400269a6c0)({
       metricMap: (*prometheus.metricMap)(0x400269a6f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a6e240)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001ad6380)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001c36320)({
      MetricVec: (*prometheus.MetricVec)(0x400269a750)({
       metricMap: (*prometheus.metricMap)(0x400269a780)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a6e2a0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001ad6400)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001c36328)({
      MetricVec: (*prometheus.MetricVec)(0x400269a7e0)({
       metricMap: (*prometheus.metricMap)(0x400269a810)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a6e300)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001af2000)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001af32d0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4002498498)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 370ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.158.202:443 (active)    
                                          2 => 172.31.244.210:443 (active)    
2    10.100.204.61:443     ClusterIP      1 => 172.31.235.234:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.37.0.216:53 (active)        
                                          2 => 10.37.0.121:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.37.0.216:9153 (active)      
                                          2 => 10.37.0.121:9153 (active)      
5    10.100.253.109:2379   ClusterIP      1 => 10.37.0.31:2379 (active)       
```

#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium environment keys

```
http-retry-timeout:0
hubble-recorder-storage-path:/var/run/cilium/pcaps
bgp-config-path:/var/lib/cilium/bgp/config.yaml
bpf-fragments-map-max:8192
disable-envoy-version-check:false
bpf-lb-source-range-map-max:0
cni-chaining-mode:none
unmanaged-pod-watcher-interval:15
disable-iptables-feeder-rules:
proxy-connect-timeout:2
bypass-ip-availability-upon-restore:false
ipv6-node:auto
mesh-auth-spire-admin-socket:
mesh-auth-queue-size:1024
bgp-announce-lb-ip:false
node-port-algorithm:random
max-connected-clusters:255
service-no-backend-response:reject
set-cilium-node-taints:true
enable-masquerade-to-route-source:false
k8s-require-ipv4-pod-cidr:false
tofqdns-idle-connection-grace-period:0s
iptables-random-fully:false
enable-ipsec-xfrm-state-caching:true
bpf-sock-rev-map-max:262144
debug-verbose:
enable-ipip-termination:false
tunnel-port:0
envoy-config-timeout:2m0s
hubble-redact-http-headers-deny:
enable-ipv4-big-tcp:false
enable-endpoint-routes:false
dnsproxy-lock-timeout:500ms
cgroup-root:/run/cilium/cgroupv2
enable-well-known-identities:false
clustermesh-config:/var/lib/cilium/clustermesh/
enable-host-firewall:false
allocator-list-timeout:3m0s
enable-monitor:true
tunnel-protocol:vxlan
container-ip-local-reserved-ports:auto
lib-dir:/var/lib/cilium
http-normalize-path:true
enable-vtep:false
enable-host-legacy-routing:false
conntrack-gc-interval:0s
enable-icmp-rules:true
prometheus-serve-addr:
fixed-identity-mapping:
k8s-api-server:
dnsproxy-insecure-skip-transparent-mode-check:false
enable-sctp:false
hubble-prefer-ipv6:false
endpoint-gc-interval:5m0s
vtep-mac:
egress-gateway-reconciliation-trigger-interval:1s
mke-cgroup-mount:
cluster-id:38
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
egress-masquerade-interfaces:ens+
metrics:
join-cluster:false
monitor-queue-size:0
kvstore-opt:
policy-audit-mode:false
mesh-auth-gc-interval:5m0s
proxy-xff-num-trusted-hops-ingress:0
enable-k8s-api-discovery:false
enable-k8s-networkpolicy:true
ipam-cilium-node-update-rate:15s
annotate-k8s-node:false
ipv4-service-range:auto
kvstore-lease-ttl:15m0s
local-router-ipv4:
bpf-lb-maglev-table-size:16381
agent-liveness-update-interval:1s
kube-proxy-replacement-healthz-bind-address:
synchronize-k8s-nodes:true
egress-gateway-policy-map-max:16384
policy-queue-size:100
mtu:0
enable-hubble:true
bpf-ct-timeout-service-tcp:2h13m20s
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
enable-ipsec:false
enable-local-redirect-policy:false
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
ipsec-key-rotation-duration:5m0s
pprof-address:localhost
trace-payloadlen:128
dnsproxy-lock-count:131
k8s-service-cache-size:128
policy-trigger-interval:1s
prepend-iptables-chains:true
auto-create-cilium-node-resource:true
remove-cilium-node-taints:true
enable-tcx:true
pprof:false
vtep-endpoint:
bpf-ct-timeout-service-any:1m0s
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
derive-masq-ip-addr-from-device:
gateway-api-secrets-namespace:
read-cni-conf:
hubble-flowlogs-config-path:
enable-metrics:true
enable-node-port:false
cluster-pool-ipv4-cidr:10.37.0.0/16
bpf-lb-map-max:65536
install-iptables-rules:true
kvstore-connectivity-timeout:2m0s
node-port-bind-protection:true
bpf-events-policy-verdict-enabled:true
bpf-lb-acceleration:disabled
ipv4-service-loopback-address:169.254.42.1
enable-auto-protect-node-port-range:true
node-labels:
max-controller-interval:0
enable-health-check-nodeport:true
enable-hubble-recorder-api:true
enable-policy:default
certificates-directory:/var/run/cilium/certs
vtep-cidr:
envoy-log:
srv6-encap-mode:reduced
tofqdns-proxy-port:0
enable-host-port:false
direct-routing-skip-unreachable:false
install-no-conntrack-iptables-rules:false
ipv6-service-range:auto
enable-runtime-device-detection:true
config:
enable-local-node-route:true
bpf-lb-external-clusterip:false
ingress-secrets-namespace:
hubble-export-file-compress:false
bpf-lb-sock-terminate-pod-connections:false
enable-bpf-masquerade:false
hubble-export-file-max-size-mb:10
bpf-node-map-max:16384
bpf-lb-rss-ipv4-src-cidr:
enable-custom-calls:false
enable-wireguard-userspace-fallback:false
bpf-map-event-buffers:
enable-cilium-health-api-server-access:
cluster-pool-ipv4-mask-size:24
tofqdns-enable-dns-compression:true
enable-xt-socket-fallback:true
hubble-export-denylist:
dns-max-ips-per-restored-rule:1000
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
proxy-portrange-min:10000
enable-encryption-strict-mode:false
k8s-service-proxy-name:
disable-external-ip-mitigation:false
proxy-admin-port:0
enable-high-scale-ipcache:false
nodeport-addresses:
bpf-ct-timeout-service-tcp-grace:1m0s
ipv4-pod-subnets:
hubble-skip-unknown-cgroup-ids:true
routing-mode:tunnel
mesh-auth-mutual-connect-timeout:5s
config-sources:config-map:kube-system/cilium-config
auto-direct-node-routes:false
cflags:
log-system-load:false
max-internal-timer-delay:0s
http-retry-count:3
tofqdns-proxy-response-max-delay:100ms
k8s-client-burst:20
local-router-ipv6:
policy-cidr-match-mode:
tofqdns-pre-cache:
keep-config:false
pprof-port:6060
trace-sock:true
bpf-lb-sock:false
enable-bpf-clock-probe:false
procfs:/host/proc
enable-l2-neigh-discovery:true
clustermesh-ip-identities-sync-timeout:1m0s
k8s-require-ipv6-pod-cidr:false
devices:
l2-announcements-renew-deadline:5s
bpf-ct-timeout-regular-tcp-fin:10s
cni-log-file:/var/run/cilium/cilium-cni.log
kube-proxy-replacement:false
hubble-monitor-events:
hubble-redact-http-userinfo:true
hubble-export-file-max-backups:5
bgp-announce-pod-cidr:false
k8s-client-qps:10
bpf-ct-timeout-regular-tcp:2h13m20s
enable-bgp-control-plane:false
enable-srv6:false
enable-ipv4:true
endpoint-bpf-prog-watchdog-interval:30s
ipam-multi-pool-pre-allocation:
enable-recorder:false
bpf-root:/sys/fs/bpf
cni-chaining-target:
bpf-events-drop-enabled:true
gops-port:9890
enable-ipsec-key-watcher:true
enable-external-ips:false
hubble-redact-http-headers-allow:
bpf-policy-map-full-reconciliation-interval:15m0s
http-max-grpc-timeout:0
endpoint-queue-size:25
hubble-recorder-sink-queue-size:1024
enable-tracing:false
set-cilium-is-up-condition:true
enable-l2-pod-announcements:false
k8s-heartbeat-timeout:30s
ipv6-native-routing-cidr:
enable-envoy-config:false
conntrack-gc-max-interval:0s
enable-ipv6:false
enable-health-checking:true
hubble-metrics:
enable-cilium-api-server-access:
bpf-lb-service-backend-map-max:0
http-idle-timeout:0
envoy-secrets-namespace:
k8s-namespace:kube-system
cmdref:
proxy-gid:1337
local-max-addr-scope:252
arping-refresh-period:30s
proxy-max-requests-per-connection:0
hubble-event-queue-size:0
clustermesh-sync-timeout:1m0s
multicast-enabled:false
enable-ipsec-encrypted-overlay:false
enable-ipv4-fragment-tracking:true
hubble-listen-address::4244
enable-ip-masq-agent:false
agent-health-port:9879
enable-bandwidth-manager:false
custom-cni-conf:false
cilium-endpoint-gc-interval:5m0s
nodes-gc-interval:5m0s
ipv4-node:auto
envoy-config-retry-interval:15s
k8s-sync-timeout:3m0s
allow-localhost:auto
proxy-xff-num-trusted-hops-egress:0
bpf-lb-service-map-max:0
mesh-auth-spiffe-trust-domain:spiffe.cilium
node-port-acceleration:disabled
ipv4-range:auto
enable-stale-cilium-endpoint-cleanup:true
enable-unreachable-routes:false
hubble-metrics-server:
datapath-mode:veth
label-prefix-file:
bpf-events-trace-enabled:true
enable-route-mtu-for-cni-chaining:false
bpf-auth-map-max:524288
identity-change-grace-period:5s
envoy-keep-cap-netbindservice:false
enable-nat46x64-gateway:false
mesh-auth-mutual-listener-port:0
envoy-base-id:0
nat-map-stats-entries:32
enable-ipv4-masquerade:true
enable-ipv4-egress-gateway:false
agent-labels:
bpf-filter-priority:1
hubble-export-fieldmask:
enable-identity-mark:true
bpf-ct-timeout-regular-any:1m0s
allow-icmp-frag-needed:true
preallocate-bpf-maps:false
mesh-auth-rotated-identities-queue-size:1024
identity-restore-grace-period:30s
controller-group-metrics:
enable-bpf-tproxy:false
l2-announcements-retry-period:2s
dns-policy-unload-on-shutdown:false
hubble-drop-events:false
hubble-disable-tls:false
exclude-local-address:
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
proxy-portrange-max:20000
ipv6-cluster-alloc-cidr:f00d::/64
force-device-detection:false
identity-heartbeat-timeout:30m0s
monitor-aggregation:medium
bpf-lb-dsr-l4-xlate:frontend
enable-ingress-controller:false
cluster-health-port:4240
bpf-lb-maglev-map-max:0
enable-node-selector-labels:false
ipv4-native-routing-cidr:
l2-pod-announcements-interface:
enable-ipv6-ndp:false
use-full-tls-context:false
fqdn-regex-compile-lru-size:1024
enable-k8s:true
encrypt-interface:
ipv6-pod-subnets:
enable-pmtu-discovery:false
enable-health-check-loadbalancer-ip:false
bpf-lb-algorithm:random
enable-ipv6-masquerade:true
socket-path:/var/run/cilium/cilium.sock
kvstore-max-consecutive-quorum-errors:2
bpf-policy-map-max:16384
policy-accounting:true
bpf-ct-global-tcp-max:524288
identity-gc-interval:15m0s
enable-endpoint-health-checking:true
direct-routing-device:
enable-active-connection-tracking:false
encryption-strict-mode-allow-remote-node-identities:false
bpf-neigh-global-max:524288
debug:false
hubble-redact-enabled:false
bpf-lb-sock-hostns-only:false
iptables-lock-timeout:5s
enable-gateway-api:false
tofqdns-dns-reject-response-code:refused
bpf-lb-rss-ipv6-src-cidr:
bpf-lb-affinity-map-max:0
tofqdns-max-deferred-connection-deletes:10000
tofqdns-min-ttl:0
nat-map-stats-interval:30s
k8s-client-connection-keep-alive:30s
crd-wait-timeout:5m0s
hubble-drop-events-reasons:auth_required,policy_denied
config-dir:/tmp/cilium/config-map
node-port-range:
k8s-kubeconfig-path:
node-port-mode:snat
dnsproxy-enable-transparent-mode:true
encryption-strict-mode-cidr:
enable-l2-announcements:false
ipsec-key-file:
dnsproxy-concurrency-processing-grace-period:0s
ipv6-mcast-device:
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
ipam-default-ip-pool:default
operator-prometheus-serve-addr::9963
operator-api-serve-addr:127.0.0.1:9234
log-opt:
cni-exclusive:true
hubble-export-allowlist:
disable-endpoint-crd:false
hubble-drop-events-interval:2m0s
monitor-aggregation-interval:5s
ipam:cluster-pool
bpf-ct-global-any-max:262144
exclude-node-label-patterns:
enable-k8s-endpoint-slice:true
labels:
egress-multi-home-ip-rule-compat:false
ip-masq-agent-config-path:/etc/config/ip-masq-agent
http-request-timeout:3600
enable-service-topology:false
proxy-max-connection-duration-seconds:0
hubble-redact-kafka-apikey:false
enable-k8s-terminating-endpoint:true
enable-cilium-endpoint-slice:false
enable-ipv6-big-tcp:false
hubble-export-file-path:
bpf-lb-dsr-dispatch:opt
bpf-lb-rev-nat-map-max:0
kvstore-periodic-sync:5m0s
clustermesh-enable-mcs-api:false
vlan-bpf-bypass:
dnsproxy-socket-linger-timeout:10
l2-announcements-lease-duration:15s
enable-mke:false
encrypt-node:false
cluster-name:cmesh38
dnsproxy-concurrency-limit:0
route-metric:0
hubble-event-buffer-capacity:4095
restore:true
monitor-aggregation-flags:all
kvstore:
state-dir:/var/run/cilium
bpf-lb-mode:snat
use-cilium-internal-ip-for-ipsec:false
enable-bbr:false
bpf-ct-timeout-regular-tcp-syn:1m0s
wireguard-persistent-keepalive:0s
hubble-redact-http-urlquery:false
version:false
mesh-auth-signal-backoff-duration:1s
identity-allocation-mode:crd
log-driver:
proxy-idle-timeout-seconds:60
ipv6-range:auto
bpf-nat-global-max:524288
enable-xdp-prefilter:false
bpf-map-dynamic-size-ratio:0.0025
proxy-prometheus-port:0
static-cnp-path:
enable-session-affinity:false
enable-l7-proxy:true
api-rate-limit:
hubble-socket-path:/var/run/cilium/hubble.sock
mesh-auth-enabled:true
vtep-mask:
enable-svc-source-range-check:true
k8s-client-connection-timeout:30s
cni-external-routing:false
clustermesh-enable-endpoint-sync:false
external-envoy-proxy:true
tofqdns-endpoint-max-ip-per-hostname:50
enable-wireguard:false
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
319        Disabled           Disabled          2492322    k8s:eks.amazonaws.com/component=coredns                                             10.37.0.121   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh38                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
749        Disabled           Disabled          2537688    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.37.0.31    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh38                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
2422       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                
                                                           reserved:host                                                                                             
3304       Disabled           Disabled          2492322    k8s:eks.amazonaws.com/component=coredns                                             10.37.0.216   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh38                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
3563       Disabled           Disabled          4          reserved:health                                                                     10.37.0.134   ready   
```

#### BPF Policy Get 319

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    84212   968       0        
Allow    Egress      0          ANY          NONE         disabled    13555   141       0        

```


#### BPF CT List 319

```
Invalid argument: unknown type 319
```


#### Endpoint Get 319

```
[
  {
    "id": 319,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-319-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "27617b49-5b66-457b-a3b8-953ae3fdd7fd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-319",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:18.778Z",
            "success-count": 3
          },
          "uuid": "e6c94071-59a1-4a71-93b6-418a928a3d0c"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-bprc6",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:18.776Z",
            "success-count": 1
          },
          "uuid": "6cde1e93-d475-42e6-9d54-d58b5744437d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-319",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:24.326Z",
            "success-count": 1
          },
          "uuid": "5e3fc384-a024-4376-b340-d622483624dd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (319)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:08.859Z",
            "success-count": 91
          },
          "uuid": "a1973b27-1ffc-471c-8784-ccbffa754b6f"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "c09e1947ef2c7fd3f120a7a852f8e4dff14f0b51efa0d144f9c469c17122c12a:eth0",
        "container-id": "c09e1947ef2c7fd3f120a7a852f8e4dff14f0b51efa0d144f9c469c17122c12a",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-bprc6",
        "pod-name": "kube-system/coredns-cc6ccd49c-bprc6"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2492322,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh38",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh38",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.37.0.121",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "c2:b9:3e:86:41:70",
        "interface-index": 11,
        "interface-name": "lxcd2e7efeea59d",
        "mac": "96:78:0e:ab:99:e8"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2492322,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2492322,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 319

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 319

```
Timestamp              Status   State                   Message
2024-10-25T10:23:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:24Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:19Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:18Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:18Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2492322

```
ID        LABELS
2492322   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh38
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 749

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3876889   35941     0        
Allow    Ingress     1          ANY          NONE         disabled    2826394   28273     0        
Allow    Egress      0          ANY          NONE         disabled    3931094   36497     0        

```


#### BPF CT List 749

```
Invalid argument: unknown type 749
```


#### Endpoint Get 749

```
[
  {
    "id": 749,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-749-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "ddcdec1e-d758-41d6-b4d3-b714bfb2d8fa"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-749",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:47.060Z",
            "success-count": 2
          },
          "uuid": "b34b7a40-4a8e-473f-852e-213c9e3e1120"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-7b7fb9b4b4-6fqsq",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:47.058Z",
            "success-count": 1
          },
          "uuid": "a99be854-9a36-47c2-a76a-d7a3dd9dcfd0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-749",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:47.098Z",
            "success-count": 1
          },
          "uuid": "b42124c6-b4c3-4bc9-b169-f0dd1800301f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (749)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:07.098Z",
            "success-count": 40
          },
          "uuid": "0d8565b2-73af-4ed1-be17-b1a4ba0d09b1"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "0665e43811474e653b845d16c6e48bfeeb8a7d9773e0e07c6a94973ba1e05511:eth0",
        "container-id": "0665e43811474e653b845d16c6e48bfeeb8a7d9773e0e07c6a94973ba1e05511",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-7b7fb9b4b4-6fqsq",
        "pod-name": "kube-system/clustermesh-apiserver-7b7fb9b4b4-6fqsq"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2537688,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh38",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7b7fb9b4b4"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh38",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.37.0.31",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "b6:b2:b9:2c:22:4b",
        "interface-index": 15,
        "interface-name": "lxcc50bb74b2b0d",
        "mac": "ae:f9:24:a1:ba:43"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2537688,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2537688,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 749

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 749

```
Timestamp              Status   State                   Message
2024-10-25T10:23:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:22:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:47Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:22:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:22:47Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:22:47Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2537688

```
ID        LABELS
2537688   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh38
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 2422

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2422

```
Invalid argument: unknown type 2422
```


#### Endpoint Get 2422

```
[
  {
    "id": 2422,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2422-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "068df35e-546a-4124-a7b7-94bb4643f726"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2422",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:18.303Z",
            "success-count": 3
          },
          "uuid": "dcee3e2f-53c8-4f95-8f1b-bff68696536f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2422",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:19.394Z",
            "success-count": 1
          },
          "uuid": "aa7c3571-2b64-4738-9c6b-9037f8869650"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:27Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "0a:f6:93:04:ef:3a",
        "interface-name": "cilium_host",
        "mac": "0a:f6:93:04:ef:3a"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2422

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2422

```
Timestamp              Status   State                   Message
2024-10-25T10:23:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:14:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:24Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:14:23Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:14:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:14:19Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:18Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:18Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:18Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 3304

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    84909   975       0        
Allow    Egress      0          ANY          NONE         disabled    13535   142       0        

```


#### BPF CT List 3304

```
Invalid argument: unknown type 3304
```


#### Endpoint Get 3304

```
[
  {
    "id": 3304,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3304-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d1a48928-793d-4313-8711-b223f1c5a52e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3304",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:18.741Z",
            "success-count": 3
          },
          "uuid": "1cae4b5d-aecd-4d06-a1c8-69c35429e0d6"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-gh552",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:18.737Z",
            "success-count": 1
          },
          "uuid": "2b1b5d98-e4b8-4e94-88e8-d7fad5810aad"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3304",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:20.889Z",
            "success-count": 1
          },
          "uuid": "4a32b8a1-1f75-4cf5-af1d-88ba35c2a46a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3304)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:08.817Z",
            "success-count": 91
          },
          "uuid": "3d3b25a3-5a5a-4db2-bb8d-61ef73033128"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "f7f23a305cd7c66d40bb97b1c066ef9889fc4fecdefbe60724154a13204ab8a7:eth0",
        "container-id": "f7f23a305cd7c66d40bb97b1c066ef9889fc4fecdefbe60724154a13204ab8a7",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-gh552",
        "pod-name": "kube-system/coredns-cc6ccd49c-gh552"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2492322,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh38",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh38",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:27Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.37.0.216",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "2a:f5:07:c3:1a:45",
        "interface-index": 9,
        "interface-name": "lxcd4fe52c2ca9f",
        "mac": "12:1e:45:a0:f1:ea"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2492322,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2492322,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3304

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3304

```
Timestamp              Status    State                   Message
2024-10-25T10:23:27Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:27Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:27Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:23:27Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:26Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:26Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:26Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:26Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:25Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:25Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:25Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:25Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:24Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:24Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:24Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:21Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:20Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:19Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:18Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:18Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:18Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:14:18Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:18Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 2492322

```
ID        LABELS
2492322   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh38
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 3563

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    439076   5605      0        
Allow    Ingress     1          ANY          NONE         disabled    11628    134       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 3563

```
Invalid argument: unknown type 3563
```


#### Endpoint Get 3563

```
[
  {
    "id": 3563,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3563-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "9846f054-f7ec-4b3f-b420-98c52f425d81"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3563",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:19.398Z",
            "success-count": 3
          },
          "uuid": "419f14e4-a668-4971-b789-9358877a88b9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3563",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:24.337Z",
            "success-count": 1
          },
          "uuid": "b9a5d04f-6f8b-4f51-b34b-c255e4f9cdb2"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:27Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.37.0.134",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "a2:7b:0d:e9:bc:3b",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "7e:35:8a:a9:c7:63"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3563

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3563

```
Timestamp              Status   State                   Message
2024-10-25T10:23:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:27Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:23Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:14:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:19Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:18Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```

