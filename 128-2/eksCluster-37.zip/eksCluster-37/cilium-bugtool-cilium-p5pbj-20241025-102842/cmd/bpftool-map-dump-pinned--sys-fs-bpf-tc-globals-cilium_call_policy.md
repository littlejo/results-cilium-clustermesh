key: 3f 01 00 00  value: 20 02 00 00
key: ed 02 00 00  value: 5b 02 00 00
key: e8 0c 00 00  value: 28 02 00 00
key: eb 0d 00 00  value: fa 01 00 00
Found 4 elements
