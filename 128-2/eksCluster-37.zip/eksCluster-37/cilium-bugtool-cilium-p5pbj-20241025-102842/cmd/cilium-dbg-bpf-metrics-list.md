REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     209731    99405896   1132   bpf_host.c
Interface                 INGRESS     8912      693806     677    bpf_overlay.c
Success                   EGRESS      3984      300924     1694   bpf_host.c
Success                   EGRESS      8490      661645     53     encap.h
Success                   EGRESS      87594     11963416   1308   bpf_lxc.c
Success                   INGRESS     104561    12512889   235    trace.h
Success                   INGRESS     98984     12076101   86     l3.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
