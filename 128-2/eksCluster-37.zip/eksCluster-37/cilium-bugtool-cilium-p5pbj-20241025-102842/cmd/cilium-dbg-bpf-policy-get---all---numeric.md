Endpoint ID: 319
Path: /sys/fs/bpf/tc/globals/cilium_policy_00319

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    85107   978       0        
Allow    Egress      0          ANY          NONE         disabled    13555   141       0        


Endpoint ID: 749
Path: /sys/fs/bpf/tc/globals/cilium_policy_00749

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3905327   36251     0        
Allow    Ingress     1          ANY          NONE         disabled    2870894   28766     0        
Allow    Egress      0          ANY          NONE         disabled    3936714   36561     0        


Endpoint ID: 2422
Path: /sys/fs/bpf/tc/globals/cilium_policy_02422

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3304
Path: /sys/fs/bpf/tc/globals/cilium_policy_03304

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    84909   975       0        
Allow    Egress      0          ANY          NONE         disabled    13535   142       0        


Endpoint ID: 3563
Path: /sys/fs/bpf/tc/globals/cilium_policy_03563

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    439076   5605      0        
Allow    Ingress     1          ANY          NONE         disabled    11628    134       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


