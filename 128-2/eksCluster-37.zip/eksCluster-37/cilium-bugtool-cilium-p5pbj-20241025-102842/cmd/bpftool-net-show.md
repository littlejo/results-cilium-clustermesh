xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 530
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 521
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 517
cilium_host(4) clsact/egress cil_from_host-cilium_host id 513
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 461
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 462
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 493
lxcd4fe52c2ca9f(9) clsact/ingress cil_from_container-lxcd4fe52c2ca9f id 538
lxcd2e7efeea59d(11) clsact/ingress cil_from_container-lxcd2e7efeea59d id 550
lxcc50bb74b2b0d(15) clsact/ingress cil_from_container-lxcc50bb74b2b0d id 600

flow_dissector:

netfilter:

