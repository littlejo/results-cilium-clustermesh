32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:19+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:19+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:19+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:19+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:19+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:20+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
58: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
61: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
62: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
65: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
66: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
69: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
72: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
73: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
76: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
455: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
458: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
459: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 124
460: sched_cls  name tail_handle_ipv4  tag fe60ab2e11ce17a6  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,93
	btf_id 125
461: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,93
	btf_id 126
462: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
463: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
466: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
492: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,105,74,75,106,76
	btf_id 160
493: sched_cls  name cil_from_container  tag aad6a9a6186f6dd8  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 105,68
	btf_id 161
495: sched_cls  name tail_handle_ipv4_cont  tag 4f80eae82bad385a  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,106,33,102,74,75,31,68,66,69,105,32,29,30,73
	btf_id 162
496: sched_cls  name tail_ipv4_ct_ingress  tag 568c5abcdbd200ee  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,105,74,75,106,76
	btf_id 164
497: sched_cls  name tail_ipv4_to_endpoint  tag 45b1299bd61912cf  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,106,33,74,75,72,102,31,105,32,29,30
	btf_id 165
500: sched_cls  name tail_handle_arp  tag 7c9a5db4d3c3c620  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,105
	btf_id 167
506: sched_cls  name handle_policy  tag 53ef6c112a33707e  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,105,74,75,106,33,72,102,31,76,67,32,29,30
	btf_id 169
507: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,105
	btf_id 174
508: sched_cls  name tail_handle_ipv4  tag 9ba7fca9d9afece2  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,105
	btf_id 175
509: sched_cls  name __send_drop_notify  tag a0bc9a5acd031bc9  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 178
510: sched_cls  name tail_handle_ipv4  tag ab48b123117fdd23  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,107
	btf_id 177
511: sched_cls  name __send_drop_notify  tag 97924c823c2c6940  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 181
512: sched_cls  name tail_handle_ipv4_from_host  tag 18fdc5e6bce0ee90  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,110
	btf_id 182
513: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,110
	btf_id 183
514: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,110
	btf_id 184
517: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 187
518: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,112
	btf_id 189
521: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 192
522: sched_cls  name __send_drop_notify  tag 97924c823c2c6940  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 193
523: sched_cls  name tail_handle_ipv4_from_host  tag 18fdc5e6bce0ee90  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,112
	btf_id 194
526: sched_cls  name __send_drop_notify  tag 97924c823c2c6940  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 198
527: sched_cls  name tail_handle_ipv4_from_host  tag 18fdc5e6bce0ee90  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,114
	btf_id 199
529: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,114
	btf_id 201
530: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,114,67
	btf_id 202
532: sched_cls  name tail_ipv4_to_endpoint  tag dcbbb0b4cc7fed59  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,108,33,74,75,72,83,31,107,32,29,30
	btf_id 179
534: sched_cls  name tail_handle_arp  tag 998baf16905e5958  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,107
	btf_id 207
535: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,107
	btf_id 208
536: sched_cls  name tail_ipv4_to_endpoint  tag fa75d800e2e07a49  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,115,33,74,75,72,94,31,116,32,29,30
	btf_id 206
538: sched_cls  name cil_from_container  tag 8cde6d84d804d958  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 107,68
	btf_id 209
539: sched_cls  name tail_handle_ipv4  tag 6302cb311a596e6c  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,116
	btf_id 211
540: sched_cls  name tail_handle_ipv4_cont  tag 55d21e8736dec778  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,115,33,94,74,75,31,68,66,69,116,32,29,30,73
	btf_id 213
541: sched_cls  name tail_ipv4_ct_ingress  tag 69b096151c69145b  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,107,74,75,108,76
	btf_id 212
542: sched_cls  name tail_ipv4_ct_ingress  tag c2e52af9ab1a1121  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,116,74,75,115,76
	btf_id 214
543: sched_cls  name tail_handle_ipv4_cont  tag 38e70e396f8f3937  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,108,33,83,74,75,31,68,66,69,107,32,29,30,73
	btf_id 215
544: sched_cls  name handle_policy  tag f31a0fdbb1ddac6e  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,116,74,75,115,33,72,94,31,76,67,32,29,30
	btf_id 216
545: sched_cls  name tail_ipv4_ct_egress  tag 4d02f6a900f5217b  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,107,74,75,108,76
	btf_id 217
546: sched_cls  name __send_drop_notify  tag 6a4701dfcf9737dc  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 218
547: sched_cls  name tail_handle_arp  tag 63cdcdf4cd414bb2  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,116
	btf_id 219
548: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,116
	btf_id 221
549: sched_cls  name tail_ipv4_ct_egress  tag 4d02f6a900f5217b  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,116,74,75,115,76
	btf_id 222
550: sched_cls  name cil_from_container  tag efaa0bf4d1f7fb5e  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,68
	btf_id 223
551: sched_cls  name __send_drop_notify  tag d18a5724a89b0833  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 224
552: sched_cls  name handle_policy  tag 33065091518cd1a7  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,107,74,75,108,33,72,83,31,76,67,32,29,30
	btf_id 220
553: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
556: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
557: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
560: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
600: sched_cls  name cil_from_container  tag af165977304d9edc  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 130,68
	btf_id 239
601: sched_cls  name tail_ipv4_to_endpoint  tag b17d32ca41d597a1  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,131,33,74,75,72,129,31,130,32,29,30
	btf_id 240
602: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,130
	btf_id 241
603: sched_cls  name handle_policy  tag 1b4481a8daebd6b9  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,130,74,75,131,33,72,129,31,76,67,32,29,30
	btf_id 242
604: sched_cls  name tail_handle_ipv4  tag 8b140e8c4fe2de76  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,130
	btf_id 243
606: sched_cls  name tail_handle_arp  tag 0350a8b4907374ce  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,130
	btf_id 245
607: sched_cls  name __send_drop_notify  tag 01b41bc27dd1ec8e  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 246
608: sched_cls  name tail_ipv4_ct_ingress  tag 17aaa52f51c38b95  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,130,74,75,131,76
	btf_id 247
609: sched_cls  name tail_handle_ipv4_cont  tag 712532a6ee8343fc  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,131,33,129,74,75,31,68,66,69,130,32,29,30,73
	btf_id 248
610: sched_cls  name tail_ipv4_ct_egress  tag f73e63a5231227b1  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,130,74,75,131,76
	btf_id 249
611: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
614: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
627: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
630: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
631: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
634: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
635: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
638: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
