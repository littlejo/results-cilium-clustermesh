fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxcd4fe52c2ca9f proto kernel metric 256 pref medium
fe80::/64 dev lxcd2e7efeea59d proto kernel metric 256 pref medium
fe80::/64 dev lxcc50bb74b2b0d proto kernel metric 256 pref medium
