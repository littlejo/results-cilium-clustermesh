1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:86:57:29:1a:b9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.235.234/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2684sec preferred_lft 2684sec
    inet6 fe80::886:57ff:fe29:1ab9/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:de:bd:e7:1e:bb brd ff:ff:ff:ff:ff:ff
    inet6 fe80::74de:bdff:fee7:1ebb/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:f6:93:04:ef:3a brd ff:ff:ff:ff:ff:ff
    inet 10.37.0.251/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::8f6:93ff:fe04:ef3a/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 82:1e:41:6e:57:1e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::801e:41ff:fe6e:571e/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:7b:0d:e9:bc:3b brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a07b:dff:fee9:bc3b/64 scope link 
       valid_lft forever preferred_lft forever
9: lxcd4fe52c2ca9f@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:f5:07:c3:1a:45 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::28f5:7ff:fec3:1a45/64 scope link 
       valid_lft forever preferred_lft forever
11: lxcd2e7efeea59d@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:b9:3e:86:41:70 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c0b9:3eff:fe86:4170/64 scope link 
       valid_lft forever preferred_lft forever
15: lxcc50bb74b2b0d@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:b2:b9:2c:22:4b brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::b4b2:b9ff:fe2c:224b/64 scope link 
       valid_lft forever preferred_lft forever
