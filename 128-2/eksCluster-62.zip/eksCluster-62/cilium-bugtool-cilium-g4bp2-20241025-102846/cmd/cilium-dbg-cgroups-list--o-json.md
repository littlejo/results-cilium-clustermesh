[
  {
    "containers": [
      {
        "cgroup-id": 9249,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb52ec7f9_739f_4b65_812a_391df725e36b.slice/cri-containerd-e2c2904e82a0b7c9c718907677b5ba130fb3ccc13c57579e2752e4348d34c7bf.scope"
      },
      {
        "cgroup-id": 9165,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb52ec7f9_739f_4b65_812a_391df725e36b.slice/cri-containerd-842f7e67e6e40aacd33f8cebe6f9701ebc12b1ed524723b142394991e3787173.scope"
      },
      {
        "cgroup-id": 9333,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb52ec7f9_739f_4b65_812a_391df725e36b.slice/cri-containerd-973e412c0fa5010bb76acb4fed809a5376d859de7d86a1d6c2606b5c7dfcab4f.scope"
      }
    ],
    "ips": [
      "10.62.0.241"
    ],
    "name": "clustermesh-apiserver-6cd5d55dd9-h7rz8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7737,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c07173e_3094_424b_8a5d_4d873b76445f.slice/cri-containerd-e2f5ed353fe17490db8dcf01304dd8c36defc5dbcc6b03d4bd6624d9605b79f6.scope"
      }
    ],
    "ips": [
      "10.62.0.148"
    ],
    "name": "coredns-cc6ccd49c-kw982",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7821,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9dea3f96_774a_4cd9_a22d_788d7f817810.slice/cri-containerd-4fadad39de5aa6025b9b32028e98c3190358adbc569a4f3919343b9c27970018.scope"
      }
    ],
    "ips": [
      "10.62.0.113"
    ],
    "name": "coredns-cc6ccd49c-2f9m5",
    "namespace": "kube-system"
  }
]

