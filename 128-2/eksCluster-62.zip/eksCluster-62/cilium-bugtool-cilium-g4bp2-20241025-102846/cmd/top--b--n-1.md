top - 10:28:49 up 14 min,  0 users,  load average: 0.11, 0.12, 0.11
Tasks:   9 total,   2 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 50.0 us, 43.3 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   3836.2 total,    751.6 free,    942.8 used,   2141.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2724.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    691 root      20   0 1244340  22660  14524 S  40.0   0.6   0:00.07 hubble
      1 root      20   0 1538356 281908  78208 S   6.7   7.2   0:22.45 cilium-+
    645 root      20   0 1240432  16288  11356 S   6.7   0.4   0:00.03 cilium-+
    396 root      20   0 1228848   6856   3836 S   0.0   0.2   0:00.27 cilium-+
    671 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    685 root      20   0    2208    792    712 S   0.0   0.0   0:00.00 timeout
    700 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    715 root      20   0 1616264   8728   6228 S   0.0   0.2   0:00.00 runc:[2+
    721 root      20   0    3132    984    864 R   0.0   0.0   0:00.00 bpftool
