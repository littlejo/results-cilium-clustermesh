Endpoint ID: 16
Path: /sys/fs/bpf/tc/globals/cilium_policy_00016

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    444340   5679      0        
Allow    Ingress     1          ANY          NONE         disabled    10828    125       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 135
Path: /sys/fs/bpf/tc/globals/cilium_policy_00135

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 624
Path: /sys/fs/bpf/tc/globals/cilium_policy_00624

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3933467   36656     0        
Allow    Ingress     1          ANY          NONE         disabled    2905946   29166     0        
Allow    Egress      0          ANY          NONE         disabled    4250754   39486     0        


Endpoint ID: 1525
Path: /sys/fs/bpf/tc/globals/cilium_policy_01525

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    76260   876       0        
Allow    Egress      0          ANY          NONE         disabled    13606   142       0        


Endpoint ID: 3664
Path: /sys/fs/bpf/tc/globals/cilium_policy_03664

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    76590   881       0        
Allow    Egress      0          ANY          NONE         disabled    12450   127       0        


