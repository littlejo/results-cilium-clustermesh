ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.175.153:443 (active)    
                                         2 => 172.31.201.218:443 (active)    
2    10.100.141.129:443   ClusterIP      1 => 172.31.134.163:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.62.0.113:9153 (active)      
                                         2 => 10.62.0.148:9153 (active)      
4    10.100.0.10:53       ClusterIP      1 => 10.62.0.113:53 (active)        
                                         2 => 10.62.0.148:53 (active)        
5    10.100.62.89:2379    ClusterIP      1 => 10.62.0.241:2379 (active)      
