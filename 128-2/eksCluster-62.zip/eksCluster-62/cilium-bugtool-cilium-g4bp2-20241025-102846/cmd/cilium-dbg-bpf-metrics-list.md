REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     213722    84516429   1132   bpf_host.c
Interface                 INGRESS     9699      755670     677    bpf_overlay.c
Success                   EGRESS      4691      356999     1694   bpf_host.c
Success                   EGRESS      90086     12156914   1308   bpf_lxc.c
Success                   EGRESS      9495      741545     53     encap.h
Success                   INGRESS     100965    12364691   86     l3.h
Success                   INGRESS     106622    12807268   235    trace.h
Unsupported L3 protocol   EGRESS      37        2762       1492   bpf_lxc.c
