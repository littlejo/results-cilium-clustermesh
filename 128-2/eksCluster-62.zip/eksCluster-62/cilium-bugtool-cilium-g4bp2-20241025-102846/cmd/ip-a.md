1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:42:e9:45:5e:1f brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.134.163/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2734sec preferred_lft 2734sec
    inet6 fe80::442:e9ff:fe45:5e1f/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:08:34:00:c8:eb brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.166.175/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::408:34ff:fe00:c8eb/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:8a:c5:44:df:55 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::888a:c5ff:fe44:df55/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:fb:b1:b9:0b:31 brd ff:ff:ff:ff:ff:ff
    inet 10.62.0.19/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::94fb:b1ff:feb9:b31/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether be:3c:16:a0:08:89 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::bc3c:16ff:fea0:889/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:25:1a:9a:b6:b7 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::bc25:1aff:fe9a:b6b7/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc88d515d7ebb5@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:7b:69:ae:9f:1b brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::2c7b:69ff:feae:9f1b/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcd58852ce964e@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:d4:59:14:dc:b2 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::20d4:59ff:fe14:dcb2/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc52ad32723533@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:56:70:fa:31:80 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::e056:70ff:fefa:3180/64 scope link 
       valid_lft forever preferred_lft forever
