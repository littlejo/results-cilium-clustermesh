{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:46.406Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.134.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:46.406Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.166.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:46.406Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:50.862Z",
  "value": "id=16    sec_id=4     flags=0x0000 ifindex=10  mac=5E:1E:D0:80:9A:CE nodemac=BE:25:1A:9A:B6:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:50.865Z",
  "value": "id=3664  sec_id=4179164 flags=0x0000 ifindex=12  mac=36:58:69:9B:87:CC nodemac=2E:7B:69:AE:9F:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:50.935Z",
  "value": "id=1525  sec_id=4179164 flags=0x0000 ifindex=14  mac=3A:C6:F4:11:D0:45 nodemac=22:D4:59:14:DC:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:50.978Z",
  "value": "id=16    sec_id=4     flags=0x0000 ifindex=10  mac=5E:1E:D0:80:9A:CE nodemac=BE:25:1A:9A:B6:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:51.023Z",
  "value": "id=3664  sec_id=4179164 flags=0x0000 ifindex=12  mac=36:58:69:9B:87:CC nodemac=2E:7B:69:AE:9F:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:26.949Z",
  "value": "id=16    sec_id=4     flags=0x0000 ifindex=10  mac=5E:1E:D0:80:9A:CE nodemac=BE:25:1A:9A:B6:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:26.949Z",
  "value": "id=3664  sec_id=4179164 flags=0x0000 ifindex=12  mac=36:58:69:9B:87:CC nodemac=2E:7B:69:AE:9F:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:26.949Z",
  "value": "id=1525  sec_id=4179164 flags=0x0000 ifindex=14  mac=3A:C6:F4:11:D0:45 nodemac=22:D4:59:14:DC:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:26.994Z",
  "value": "id=174   sec_id=4147480 flags=0x0000 ifindex=16  mac=BE:50:4A:C1:ED:72 nodemac=46:B4:B3:BB:0D:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:27.949Z",
  "value": "id=3664  sec_id=4179164 flags=0x0000 ifindex=12  mac=36:58:69:9B:87:CC nodemac=2E:7B:69:AE:9F:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:27.949Z",
  "value": "id=174   sec_id=4147480 flags=0x0000 ifindex=16  mac=BE:50:4A:C1:ED:72 nodemac=46:B4:B3:BB:0D:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:27.950Z",
  "value": "id=1525  sec_id=4179164 flags=0x0000 ifindex=14  mac=3A:C6:F4:11:D0:45 nodemac=22:D4:59:14:DC:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:27.950Z",
  "value": "id=16    sec_id=4     flags=0x0000 ifindex=10  mac=5E:1E:D0:80:9A:CE nodemac=BE:25:1A:9A:B6:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:32.149Z",
  "value": "id=624   sec_id=4147480 flags=0x0000 ifindex=18  mac=CE:FA:A8:3D:91:5E nodemac=E2:56:70:FA:31:80"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.62.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:37.103Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:20.204Z",
  "value": "id=16    sec_id=4     flags=0x0000 ifindex=10  mac=5E:1E:D0:80:9A:CE nodemac=BE:25:1A:9A:B6:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:20.204Z",
  "value": "id=3664  sec_id=4179164 flags=0x0000 ifindex=12  mac=36:58:69:9B:87:CC nodemac=2E:7B:69:AE:9F:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:20.205Z",
  "value": "id=1525  sec_id=4179164 flags=0x0000 ifindex=14  mac=3A:C6:F4:11:D0:45 nodemac=22:D4:59:14:DC:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:20.205Z",
  "value": "id=624   sec_id=4147480 flags=0x0000 ifindex=18  mac=CE:FA:A8:3D:91:5E nodemac=E2:56:70:FA:31:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:21.198Z",
  "value": "id=16    sec_id=4     flags=0x0000 ifindex=10  mac=5E:1E:D0:80:9A:CE nodemac=BE:25:1A:9A:B6:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:21.198Z",
  "value": "id=624   sec_id=4147480 flags=0x0000 ifindex=18  mac=CE:FA:A8:3D:91:5E nodemac=E2:56:70:FA:31:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:21.198Z",
  "value": "id=3664  sec_id=4179164 flags=0x0000 ifindex=12  mac=36:58:69:9B:87:CC nodemac=2E:7B:69:AE:9F:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:21.198Z",
  "value": "id=1525  sec_id=4179164 flags=0x0000 ifindex=14  mac=3A:C6:F4:11:D0:45 nodemac=22:D4:59:14:DC:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.198Z",
  "value": "id=624   sec_id=4147480 flags=0x0000 ifindex=18  mac=CE:FA:A8:3D:91:5E nodemac=E2:56:70:FA:31:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.198Z",
  "value": "id=1525  sec_id=4179164 flags=0x0000 ifindex=14  mac=3A:C6:F4:11:D0:45 nodemac=22:D4:59:14:DC:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.199Z",
  "value": "id=3664  sec_id=4179164 flags=0x0000 ifindex=12  mac=36:58:69:9B:87:CC nodemac=2E:7B:69:AE:9F:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.62.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.199Z",
  "value": "id=16    sec_id=4     flags=0x0000 ifindex=10  mac=5E:1E:D0:80:9A:CE nodemac=BE:25:1A:9A:B6:B7"
}

