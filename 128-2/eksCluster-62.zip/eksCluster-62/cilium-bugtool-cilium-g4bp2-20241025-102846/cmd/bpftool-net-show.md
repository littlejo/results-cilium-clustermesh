xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 573
ens6(5) clsact/ingress cil_from_netdev-ens6 id 586
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 569
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 562
cilium_host(7) clsact/egress cil_from_host-cilium_host id 559
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 530
lxc88d515d7ebb5(12) clsact/ingress cil_from_container-lxc88d515d7ebb5 id 534
lxcd58852ce964e(14) clsact/ingress cil_from_container-lxcd58852ce964e id 514
lxc52ad32723533(18) clsact/ingress cil_from_container-lxc52ad32723533 id 627

flow_dissector:

netfilter:

