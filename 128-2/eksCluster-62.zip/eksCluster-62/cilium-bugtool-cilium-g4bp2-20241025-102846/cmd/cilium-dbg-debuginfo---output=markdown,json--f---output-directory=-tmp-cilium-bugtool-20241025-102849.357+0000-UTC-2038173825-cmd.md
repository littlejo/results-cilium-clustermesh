markdown output at /tmp/cilium-bugtool-20241025-102849.357+0000-UTC-2038173825/cmd/cilium-debuginfo-20241025-102920.111+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102849.357+0000-UTC-2038173825/cmd/cilium-debuginfo-20241025-102920.111+0000-UTC.json
