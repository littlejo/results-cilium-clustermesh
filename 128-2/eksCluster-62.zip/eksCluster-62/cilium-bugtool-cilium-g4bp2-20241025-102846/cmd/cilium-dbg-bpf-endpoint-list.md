IP ADDRESS         LOCAL ENDPOINT INFO
10.62.0.73:0       id=16    sec_id=4     flags=0x0000 ifindex=10  mac=5E:1E:D0:80:9A:CE nodemac=BE:25:1A:9A:B6:B7     
172.31.166.175:0   (localhost)                                                                                        
10.62.0.113:0      id=1525  sec_id=4179164 flags=0x0000 ifindex=14  mac=3A:C6:F4:11:D0:45 nodemac=22:D4:59:14:DC:B2   
172.31.134.163:0   (localhost)                                                                                        
10.62.0.19:0       (localhost)                                                                                        
10.62.0.148:0      id=3664  sec_id=4179164 flags=0x0000 ifindex=12  mac=36:58:69:9B:87:CC nodemac=2E:7B:69:AE:9F:1B   
10.62.0.241:0      id=624   sec_id=4147480 flags=0x0000 ifindex=18  mac=CE:FA:A8:3D:91:5E nodemac=E2:56:70:FA:31:80   
