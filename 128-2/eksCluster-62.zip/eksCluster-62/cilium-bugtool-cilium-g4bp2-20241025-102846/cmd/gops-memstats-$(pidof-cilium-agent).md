alloc: 71.50MB (74972624 bytes)
total-alloc: 1.33GB (1429664512 bytes)
sys: 214.63MB (225060180 bytes)
lookups: 0
mallocs: 47668499
frees: 47188168
heap-alloc: 71.50MB (74972624 bytes)
heap-sys: 171.84MB (180191232 bytes)
heap-idle: 53.91MB (56532992 bytes)
heap-in-use: 117.93MB (123658240 bytes)
heap-released: 1.93MB (2023424 bytes)
heap-objects: 480331
stack-in-use: 32.16MB (33718272 bytes)
stack-sys: 32.16MB (33718272 bytes)
stack-mspan-inuse: 1.93MB (2025440 bytes)
stack-mspan-sys: 2.52MB (2643840 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.08MB (1130761 bytes)
gc-sys: 5.12MB (5370136 bytes)
next-gc: when heap-alloc >= 149.61MB (156874904 bytes)
last-gc: 2024-10-25 10:29:19.71599668 +0000 UTC
gc-pause-total: 11.137165ms
gc-pause: 89560
gc-pause-end: 1729852159715996680
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00036676387847655114
enable-gc: true
debug-gc: false
