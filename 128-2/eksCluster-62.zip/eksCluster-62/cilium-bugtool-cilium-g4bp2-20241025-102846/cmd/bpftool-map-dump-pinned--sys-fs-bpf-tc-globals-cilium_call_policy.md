key: 10 00 00 00  value: 13 02 00 00
key: 70 02 00 00  value: 7a 02 00 00
key: f5 05 00 00  value: 04 02 00 00
key: 50 0e 00 00  value: 25 02 00 00
Found 4 elements
