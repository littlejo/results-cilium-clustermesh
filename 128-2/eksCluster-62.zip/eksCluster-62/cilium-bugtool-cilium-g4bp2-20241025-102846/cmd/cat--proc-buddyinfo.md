Node 0, zone      DMA     15      2      1      1    173    105     40     15     14      7    149 
Node 0, zone   Normal      9      1      1      2      2      1     10      6      6      3      6 
