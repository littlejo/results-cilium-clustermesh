 10:28:49 up 14 min,  0 users,  load average: 0.11, 0.12, 0.11
