CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c07173e_3094_424b_8a5d_4d873b76445f.slice/cri-containerd-2a9904de4aaf3b4b2c7788615a48c640530b5ccbf615d53ec3b260dcf9fd7119.scope
    542      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c07173e_3094_424b_8a5d_4d873b76445f.slice/cri-containerd-e2f5ed353fe17490db8dcf01304dd8c36defc5dbcc6b03d4bd6624d9605b79f6.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9dea3f96_774a_4cd9_a22d_788d7f817810.slice/cri-containerd-623a8b00828e2a821c954b709a1a50bf05241600e823949184caea8ceacca289.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9dea3f96_774a_4cd9_a22d_788d7f817810.slice/cri-containerd-4fadad39de5aa6025b9b32028e98c3190358adbc569a4f3919343b9c27970018.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfb5b2f80_32e0_4a8b_b9b9_d938e94eb457.slice/cri-containerd-0add09b62c554c30bd545d0b907ca2fdad982b41194042c77e1fba637884c014.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfb5b2f80_32e0_4a8b_b9b9_d938e94eb457.slice/cri-containerd-2ba35afa68d02cca868f6cd0dc10e1b124941619de942a2cbc2c8ec8584df6ba.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod50711ebf_e0d6_4848_8a5a_40d05c8421e9.slice/cri-containerd-5288e1e89b282efeae1c368856ccc7ab1f856cceed7999e3b8a2834c931ab9d3.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod50711ebf_e0d6_4848_8a5a_40d05c8421e9.slice/cri-containerd-ac85bf22ae2522a98898d2897f6cd1fd2b34fec84426984868113cd4e1e1ba16.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd7df82aa_34ce_425c_a579_69de6f4c6f89.slice/cri-containerd-3531bf08025836c88e8f2d986db7b6f3452ad45c9ba4b90243014bf25d2094b4.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd7df82aa_34ce_425c_a579_69de6f4c6f89.slice/cri-containerd-960b79e5aa56374abdfe2ac630974b5da4e9166fcdebf33070e02b3b2b3b3514.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod291715d4_cbfd_406b_bcf2_2a9e31d46517.slice/cri-containerd-4e87ff7455aa82a2d2b4a8c4f0756de9dc899e57e23a91908985fd8c74090252.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod291715d4_cbfd_406b_bcf2_2a9e31d46517.slice/cri-containerd-c14eccbd3201b9ec1435509e00c6fc7b10517f7e4f0529e6b23daee21d5cdf61.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb52ec7f9_739f_4b65_812a_391df725e36b.slice/cri-containerd-842f7e67e6e40aacd33f8cebe6f9701ebc12b1ed524723b142394991e3787173.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb52ec7f9_739f_4b65_812a_391df725e36b.slice/cri-containerd-48162c7e5587a9f7c6aef5e975badf50926a21da458d1b1e28630b6c27c4dc97.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb52ec7f9_739f_4b65_812a_391df725e36b.slice/cri-containerd-e2c2904e82a0b7c9c718907677b5ba130fb3ccc13c57579e2752e4348d34c7bf.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb52ec7f9_739f_4b65_812a_391df725e36b.slice/cri-containerd-973e412c0fa5010bb76acb4fed809a5376d859de7d86a1d6c2606b5c7dfcab4f.scope
    664      cgroup_device   multi                                          
