fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxc6a790732204a proto kernel metric 256 pref medium
fe80::/64 dev lxc02574ff94d5d proto kernel metric 256 pref medium
fe80::/64 dev lxc421abc9e40de proto kernel metric 256 pref medium
