top - 10:28:43 up 16 min,  0 users,  load average: 0.10, 0.16, 0.18
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 48.3 us, 17.2 sy,  0.0 ni, 34.5 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1199.4 free,    880.6 used,   1756.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2787.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538356 280264  77664 S  40.0   7.1   0:30.12 cilium-+
    659 root      20   0 1240432  16424  11420 S   6.7   0.4   0:00.03 cilium-+
    390 root      20   0 1228848   5772   2872 S   0.0   0.1   0:00.27 cilium-+
    628 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    647 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    676 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
    681 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    708 root      20   0    6576   2416   2092 R   0.0   0.1   0:00.00 top
    727 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
