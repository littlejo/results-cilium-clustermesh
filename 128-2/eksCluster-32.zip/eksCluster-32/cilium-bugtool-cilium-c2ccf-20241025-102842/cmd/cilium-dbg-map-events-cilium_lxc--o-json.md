{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:12:50.476Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.186.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:12:50.476Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:12:55.055Z",
  "value": "id=756   sec_id=2186963 flags=0x0000 ifindex=9   mac=1A:B8:4E:24:7C:EF nodemac=6A:B0:7A:5C:B2:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:12:55.075Z",
  "value": "id=3753  sec_id=4     flags=0x0000 ifindex=7   mac=BE:B4:0C:7D:AD:88 nodemac=82:65:5F:FB:B9:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:12:55.130Z",
  "value": "id=2857  sec_id=2186963 flags=0x0000 ifindex=11  mac=F2:30:00:B8:BE:9A nodemac=E2:CD:25:95:0C:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:12:55.209Z",
  "value": "id=756   sec_id=2186963 flags=0x0000 ifindex=9   mac=1A:B8:4E:24:7C:EF nodemac=6A:B0:7A:5C:B2:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:12:55.284Z",
  "value": "id=3753  sec_id=4     flags=0x0000 ifindex=7   mac=BE:B4:0C:7D:AD:88 nodemac=82:65:5F:FB:B9:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:11.130Z",
  "value": "id=3753  sec_id=4     flags=0x0000 ifindex=7   mac=BE:B4:0C:7D:AD:88 nodemac=82:65:5F:FB:B9:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:11.130Z",
  "value": "id=2857  sec_id=2186963 flags=0x0000 ifindex=11  mac=F2:30:00:B8:BE:9A nodemac=E2:CD:25:95:0C:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:11.131Z",
  "value": "id=756   sec_id=2186963 flags=0x0000 ifindex=9   mac=1A:B8:4E:24:7C:EF nodemac=6A:B0:7A:5C:B2:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:11.163Z",
  "value": "id=146   sec_id=2174873 flags=0x0000 ifindex=13  mac=6E:9E:0D:98:98:C0 nodemac=5E:07:4D:A8:34:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:12.131Z",
  "value": "id=3753  sec_id=4     flags=0x0000 ifindex=7   mac=BE:B4:0C:7D:AD:88 nodemac=82:65:5F:FB:B9:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:12.131Z",
  "value": "id=2857  sec_id=2186963 flags=0x0000 ifindex=11  mac=F2:30:00:B8:BE:9A nodemac=E2:CD:25:95:0C:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:12.131Z",
  "value": "id=146   sec_id=2174873 flags=0x0000 ifindex=13  mac=6E:9E:0D:98:98:C0 nodemac=5E:07:4D:A8:34:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:12.131Z",
  "value": "id=756   sec_id=2186963 flags=0x0000 ifindex=9   mac=1A:B8:4E:24:7C:EF nodemac=6A:B0:7A:5C:B2:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:12.102Z",
  "value": "id=1236  sec_id=2174873 flags=0x0000 ifindex=15  mac=BE:BE:CB:DC:95:B4 nodemac=6A:39:D9:F5:0A:64"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.32.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:22.738Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:23.027Z",
  "value": "id=1236  sec_id=2174873 flags=0x0000 ifindex=15  mac=BE:BE:CB:DC:95:B4 nodemac=6A:39:D9:F5:0A:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:23.028Z",
  "value": "id=3753  sec_id=4     flags=0x0000 ifindex=7   mac=BE:B4:0C:7D:AD:88 nodemac=82:65:5F:FB:B9:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:23.029Z",
  "value": "id=756   sec_id=2186963 flags=0x0000 ifindex=9   mac=1A:B8:4E:24:7C:EF nodemac=6A:B0:7A:5C:B2:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:23.029Z",
  "value": "id=2857  sec_id=2186963 flags=0x0000 ifindex=11  mac=F2:30:00:B8:BE:9A nodemac=E2:CD:25:95:0C:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:24.027Z",
  "value": "id=1236  sec_id=2174873 flags=0x0000 ifindex=15  mac=BE:BE:CB:DC:95:B4 nodemac=6A:39:D9:F5:0A:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:24.028Z",
  "value": "id=2857  sec_id=2186963 flags=0x0000 ifindex=11  mac=F2:30:00:B8:BE:9A nodemac=E2:CD:25:95:0C:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:24.028Z",
  "value": "id=3753  sec_id=4     flags=0x0000 ifindex=7   mac=BE:B4:0C:7D:AD:88 nodemac=82:65:5F:FB:B9:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:24.028Z",
  "value": "id=756   sec_id=2186963 flags=0x0000 ifindex=9   mac=1A:B8:4E:24:7C:EF nodemac=6A:B0:7A:5C:B2:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:25.028Z",
  "value": "id=3753  sec_id=4     flags=0x0000 ifindex=7   mac=BE:B4:0C:7D:AD:88 nodemac=82:65:5F:FB:B9:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:25.029Z",
  "value": "id=1236  sec_id=2174873 flags=0x0000 ifindex=15  mac=BE:BE:CB:DC:95:B4 nodemac=6A:39:D9:F5:0A:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:25.029Z",
  "value": "id=756   sec_id=2186963 flags=0x0000 ifindex=9   mac=1A:B8:4E:24:7C:EF nodemac=6A:B0:7A:5C:B2:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.32.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:25.029Z",
  "value": "id=2857  sec_id=2186963 flags=0x0000 ifindex=11  mac=F2:30:00:B8:BE:9A nodemac=E2:CD:25:95:0C:6C"
}

