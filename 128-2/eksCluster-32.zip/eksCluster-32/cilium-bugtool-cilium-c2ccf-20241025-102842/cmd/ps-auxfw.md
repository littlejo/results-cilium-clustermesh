USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         681  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops memstats 1
root         676  0.0  0.0 1228744 3776 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         659  0.0  0.4 1240176 16220 ?       Dsl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         696  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         699  0.0  0.4 1240176 16220 ?       R    10:28   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         647  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops stats 1
root         628  0.0  0.0 1228744 3596 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root         627  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops stack 1
root           1  3.1  7.0 1472752 275796 ?      Ssl  10:12   0:29 cilium-agent --config-dir=/tmp/cilium/config-map
root         390  0.0  0.1 1228848 5772 ?        Sl   10:12   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
