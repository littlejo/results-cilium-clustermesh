35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:05+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:12:05+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:12:06+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:12:06+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:12:06+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:06+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:12:10+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
61: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
64: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
71: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:12:23+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
72: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
75: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
447: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:12:52+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 112
448: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:12:52+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 113
449: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:12:52+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 114
450: sched_cls  name tail_handle_ipv4  tag 1c5a2c71101ce2a3  gpl
	loaded_at 2024-10-25T10:12:52+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 115
474: sched_cls  name tail_ipv4_ct_egress  tag dcb9c400277027be  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,98,74,75,97,76
	btf_id 142
475: sched_cls  name tail_handle_ipv4_cont  tag 8ddb8f1b5f2ab018  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,97,33,96,74,75,31,68,66,69,98,32,29,30,73
	btf_id 143
476: sched_cls  name tail_ipv4_to_endpoint  tag fdf7b5693a6d0b6d  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,97,33,74,75,72,96,31,98,32,29,30
	btf_id 144
477: sched_cls  name __send_drop_notify  tag a211bdcc728743df  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 145
478: sched_cls  name tail_handle_ipv4  tag 0c4a88f622aebfac  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,98
	btf_id 146
479: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,98
	btf_id 147
480: sched_cls  name tail_ipv4_ct_ingress  tag 67b910b82490b9a2  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,98,74,75,97,76
	btf_id 148
481: sched_cls  name tail_handle_arp  tag 8347a583400dee38  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,98
	btf_id 149
482: sched_cls  name cil_from_container  tag 84e5ca31b034c287  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 98,68
	btf_id 150
483: sched_cls  name handle_policy  tag 2ce7d9d08e6317a1  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,98,74,75,97,33,72,96,31,76,67,32,29,30
	btf_id 151
484: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
487: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
489: sched_cls  name tail_ipv4_ct_egress  tag dcb9c400277027be  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,100,74,75,99,76
	btf_id 154
490: sched_cls  name tail_handle_ipv4_cont  tag 1ee8c41f7698b307  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,99,33,90,74,75,31,68,66,69,100,32,29,30,73
	btf_id 155
491: sched_cls  name tail_handle_arp  tag 1cde1f82c39a6919  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,100
	btf_id 156
492: sched_cls  name cil_from_container  tag ebb939de21f85594  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 100,68
	btf_id 157
493: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,100
	btf_id 158
494: sched_cls  name __send_drop_notify  tag 00c4eee8cfd80896  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 159
495: sched_cls  name tail_handle_ipv4  tag 7827ef42d6173517  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,100
	btf_id 160
496: sched_cls  name tail_ipv4_to_endpoint  tag d42a00a2bfab6d76  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,99,33,74,75,72,90,31,100,32,29,30
	btf_id 161
497: sched_cls  name handle_policy  tag f129c0c735dd81cc  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,100,74,75,99,33,72,90,31,76,67,32,29,30
	btf_id 162
498: sched_cls  name tail_ipv4_ct_ingress  tag 37dbce226b48d56e  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,100,74,75,99,76
	btf_id 163
499: sched_cls  name tail_ipv4_to_endpoint  tag 4ff199d1914927f0  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,103,33,74,75,72,91,31,102,32,29,30
	btf_id 165
501: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,102,74,75,103,76
	btf_id 167
502: sched_cls  name tail_ipv4_ct_ingress  tag dba5dd07ded48c31  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,102,74,75,103,76
	btf_id 168
503: sched_cls  name cil_from_container  tag 9f16186bc7cdad50  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 102,68
	btf_id 169
504: sched_cls  name tail_handle_ipv4  tag 74b587e148d48e1f  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,102
	btf_id 170
505: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,102
	btf_id 171
506: sched_cls  name handle_policy  tag 555ae42a2b0f9c92  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,102,74,75,103,33,72,91,31,76,67,32,29,30
	btf_id 172
507: sched_cls  name tail_handle_ipv4_cont  tag 38997316085ab0e2  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,103,33,91,74,75,31,68,66,69,102,32,29,30,73
	btf_id 173
508: sched_cls  name tail_handle_arp  tag 23edd7fd383b537d  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,102
	btf_id 174
509: sched_cls  name __send_drop_notify  tag 867db3e287e6cd38  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 175
510: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
513: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
514: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,106
	btf_id 177
515: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 178
516: sched_cls  name tail_handle_ipv4_from_host  tag d9140b79f3a6d474  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,106
	btf_id 179
518: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,106
	btf_id 181
519: sched_cls  name __send_drop_notify  tag 6370aef4a0bd6bdb  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 182
521: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 185
522: sched_cls  name tail_handle_ipv4_from_host  tag d9140b79f3a6d474  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,108
	btf_id 186
524: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,108
	btf_id 188
525: sched_cls  name __send_drop_notify  tag 6370aef4a0bd6bdb  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 189
528: sched_cls  name tail_handle_ipv4_from_host  tag d9140b79f3a6d474  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,110
	btf_id 193
530: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,110
	btf_id 195
531: sched_cls  name __send_drop_notify  tag 6370aef4a0bd6bdb  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 196
532: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,110,67
	btf_id 197
535: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
538: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
539: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
542: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
582: sched_cls  name tail_ipv4_ct_ingress  tag 67a16dd65130724c  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,124,74,75,125,76
	btf_id 215
583: sched_cls  name tail_ipv4_to_endpoint  tag 9af165eaf2c6654e  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,125,33,74,75,72,123,31,124,32,29,30
	btf_id 216
584: sched_cls  name tail_ipv4_ct_egress  tag 0d731fe70c115fae  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,124,74,75,125,76
	btf_id 217
586: sched_cls  name tail_handle_ipv4  tag fa093e231cc68219  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,124
	btf_id 219
587: sched_cls  name tail_handle_ipv4_cont  tag 8ad43c3cb09c25bd  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,125,33,123,74,75,31,68,66,69,124,32,29,30,73
	btf_id 220
588: sched_cls  name tail_handle_arp  tag 198d832f5b942725  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,124
	btf_id 221
589: sched_cls  name handle_policy  tag 27087627289d719e  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,124,74,75,125,33,72,123,31,76,67,32,29,30
	btf_id 222
590: sched_cls  name cil_from_container  tag c6a4c83535bcebfb  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 124,68
	btf_id 223
591: sched_cls  name __send_drop_notify  tag cb33d2f50301209a  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 224
592: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,124
	btf_id 225
593: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
596: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
609: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
612: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
613: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
616: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
617: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
620: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
