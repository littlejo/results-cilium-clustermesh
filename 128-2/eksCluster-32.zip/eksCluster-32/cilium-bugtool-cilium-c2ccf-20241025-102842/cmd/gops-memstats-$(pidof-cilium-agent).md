alloc: 128.48MB (134725712 bytes)
total-alloc: 1.41GB (1517717808 bytes)
sys: 210.63MB (220865876 bytes)
lookups: 0
mallocs: 49036605
frees: 47750262
heap-alloc: 128.48MB (134725712 bytes)
heap-sys: 165.11MB (173129728 bytes)
heap-idle: 17.64MB (18497536 bytes)
heap-in-use: 147.47MB (154632192 bytes)
heap-released: 2.96MB (3104768 bytes)
heap-objects: 1286343
stack-in-use: 34.84MB (36536320 bytes)
stack-sys: 34.84MB (36536320 bytes)
stack-mspan-inuse: 2.31MB (2421440 bytes)
stack-mspan-sys: 2.49MB (2611200 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.07MB (1123737 bytes)
gc-sys: 5.18MB (5431624 bytes)
next-gc: when heap-alloc >= 158.63MB (166333384 bytes)
last-gc: 2024-10-25 10:28:43.48844117 +0000 UTC
gc-pause-total: 20.876156ms
gc-pause: 2185264
gc-pause-end: 1729852123488441170
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.0003787921648876096
enable-gc: true
debug-gc: false
