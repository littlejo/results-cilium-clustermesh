key: f4 02 00 00  value: f1 01 00 00
key: d4 04 00 00  value: 4d 02 00 00
key: 29 0b 00 00  value: e3 01 00 00
key: a9 0e 00 00  value: fa 01 00 00
Found 4 elements
