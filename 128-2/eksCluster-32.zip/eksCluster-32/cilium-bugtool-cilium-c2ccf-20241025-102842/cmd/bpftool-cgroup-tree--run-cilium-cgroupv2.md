CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ea33271_8702_4ffa_9b94_3fda451757b0.slice/cri-containerd-34cfbe2c806eaea74407dedb345861e28438356784a79b14b4da3c50a95b937b.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ea33271_8702_4ffa_9b94_3fda451757b0.slice/cri-containerd-b30471e4ba43df3a04082171003204968e6305c8801209ce2943be77607178af.scope
    513      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc4108859_b476_4ec8_9336_d232e2e2bf42.slice/cri-containerd-86d418f95b9e0a2fec5b00ddbbbe7d2dc469a8d280419c2052d35326f61e4f4e.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc4108859_b476_4ec8_9336_d232e2e2bf42.slice/cri-containerd-2bd2c7c8de74d4f41b9cef89256c60555220001e31c52e2777187cb7f8a7f007.scope
    71       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcf0bd969_8d9e_44b5_90e9_0bfd9c18fad5.slice/cri-containerd-a5b29741368bb2fa98a1eba9d9c395b6db435cb736dffbacc9aa884e6bdfbd7b.scope
    487      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcf0bd969_8d9e_44b5_90e9_0bfd9c18fad5.slice/cri-containerd-e6e819bf6b79517d2c69371f75aa11098666ffe4dfc30c4ad05483380aad800a.scope
    542      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7fd2bde4_296a_4b73_aef3_b9ef980cc6ab.slice/cri-containerd-d9c7a92e711402bbb52bad7d9ef008934809ce15e4dba1c53ffc060eac4f7a83.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7fd2bde4_296a_4b73_aef3_b9ef980cc6ab.slice/cri-containerd-83a9b8767aaa588a005979d11a7f41338fadc9935c271efe323aebc1ac5907af.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71671f31_b7aa_4d5c_92f4_f8e97147e78f.slice/cri-containerd-cf6b38628dc205b55e077520450290dcce43a15ea4d0c9501e199ee20abe7e4e.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71671f31_b7aa_4d5c_92f4_f8e97147e78f.slice/cri-containerd-1566e32669021e51b4a8a7a7c199c81d93542704fc954f0aee03306e47e3f6de.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podabdf294b_4292_48a7_86c0_1158c518539c.slice/cri-containerd-9101dafdb08d0fe0a2e115aa111192558b1b0e99c9516643f6a18de3d9a27f6a.scope
    612      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podabdf294b_4292_48a7_86c0_1158c518539c.slice/cri-containerd-ef30f097e03db4f6b678c6dd5d19f10b30a3c11ba0c648f4472006cfbea38664.scope
    616      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podabdf294b_4292_48a7_86c0_1158c518539c.slice/cri-containerd-7919d58e2a1dc8abde3f6c72700d3a709a84ef7322921bc583ca25a20fb32ec9.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podabdf294b_4292_48a7_86c0_1158c518539c.slice/cri-containerd-aa13e5a97419f37edef7d2ace7a75b77af73ff9cba3b4ca1f9b0be0aac4abb0b.scope
    620      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf92f866a_3bf1_485f_8b0a_d7e1efb0beee.slice/cri-containerd-441308febb0d4b065cb5908b7e72573e805064d0d45da158ba35d5a0825cdce5.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf92f866a_3bf1_485f_8b0a_d7e1efb0beee.slice/cri-containerd-9fc49437e74e3b97deedce5801466fc73d428a223f2437d49962923eac900dea.scope
    64       cgroup_device   multi                                          
