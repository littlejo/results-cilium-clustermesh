IP ADDRESS        LOCAL ENDPOINT INFO
10.32.0.29:0      id=3753  sec_id=4     flags=0x0000 ifindex=7   mac=BE:B4:0C:7D:AD:88 nodemac=82:65:5F:FB:B9:98     
172.31.186.90:0   (localhost)                                                                                        
10.32.0.51:0      id=756   sec_id=2186963 flags=0x0000 ifindex=9   mac=1A:B8:4E:24:7C:EF nodemac=6A:B0:7A:5C:B2:A2   
10.32.0.96:0      id=2857  sec_id=2186963 flags=0x0000 ifindex=11  mac=F2:30:00:B8:BE:9A nodemac=E2:CD:25:95:0C:6C   
10.32.0.142:0     (localhost)                                                                                        
10.32.0.46:0      id=1236  sec_id=2174873 flags=0x0000 ifindex=15  mac=BE:BE:CB:DC:95:B4 nodemac=6A:39:D9:F5:0A:64   
