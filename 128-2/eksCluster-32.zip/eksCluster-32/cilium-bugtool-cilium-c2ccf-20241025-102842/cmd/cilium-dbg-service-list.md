ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.136.18:443 (active)    
                                         2 => 172.31.231.70:443 (active)    
2    10.100.75.253:443    ClusterIP      1 => 172.31.186.90:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.32.0.51:53 (active)        
                                         2 => 10.32.0.96:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.32.0.51:9153 (active)      
                                         2 => 10.32.0.96:9153 (active)      
5    10.100.248.72:2379   ClusterIP      1 => 10.32.0.46:2379 (active)      
