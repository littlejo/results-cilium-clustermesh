REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     10651     836877      677    bpf_overlay.c
Interface                 INGRESS     235566    102546942   1132   bpf_host.c
Success                   EGRESS      100542    13055380    1308   bpf_lxc.c
Success                   EGRESS      11257     881460      53     encap.h
Success                   EGRESS      308       48718       86     l3.h
Success                   EGRESS      5746      446817      1694   bpf_host.c
Success                   INGRESS     112559    13829863    86     l3.h
Success                   INGRESS     118421    14312547    235    trace.h
Unsupported L3 protocol   EGRESS      35        2586        1492   bpf_lxc.c
