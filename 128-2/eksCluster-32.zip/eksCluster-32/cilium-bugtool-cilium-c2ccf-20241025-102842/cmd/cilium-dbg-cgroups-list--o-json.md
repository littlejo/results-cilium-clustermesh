[
  {
    "containers": [
      {
        "cgroup-id": 8301,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podabdf294b_4292_48a7_86c0_1158c518539c.slice/cri-containerd-ef30f097e03db4f6b678c6dd5d19f10b30a3c11ba0c648f4472006cfbea38664.scope"
      },
      {
        "cgroup-id": 8217,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podabdf294b_4292_48a7_86c0_1158c518539c.slice/cri-containerd-9101dafdb08d0fe0a2e115aa111192558b1b0e99c9516643f6a18de3d9a27f6a.scope"
      },
      {
        "cgroup-id": 8385,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podabdf294b_4292_48a7_86c0_1158c518539c.slice/cri-containerd-aa13e5a97419f37edef7d2ace7a75b77af73ff9cba3b4ca1f9b0be0aac4abb0b.scope"
      }
    ],
    "ips": [
      "10.32.0.46"
    ],
    "name": "clustermesh-apiserver-6f49498686-t88mv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6873,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcf0bd969_8d9e_44b5_90e9_0bfd9c18fad5.slice/cri-containerd-e6e819bf6b79517d2c69371f75aa11098666ffe4dfc30c4ad05483380aad800a.scope"
      }
    ],
    "ips": [
      "10.32.0.51"
    ],
    "name": "coredns-cc6ccd49c-22f9p",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6789,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ea33271_8702_4ffa_9b94_3fda451757b0.slice/cri-containerd-34cfbe2c806eaea74407dedb345861e28438356784a79b14b4da3c50a95b937b.scope"
      }
    ],
    "ips": [
      "10.32.0.96"
    ],
    "name": "coredns-cc6ccd49c-ggctg",
    "namespace": "kube-system"
  }
]

