Endpoint ID: 756
Path: /sys/fs/bpf/tc/globals/cilium_policy_00756

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    8716    78        0        
Allow    Ingress     1          ANY          NONE         disabled    93066   1073      0        
Allow    Egress      0          ANY          NONE         disabled    17254   178       0        


Endpoint ID: 1236
Path: /sys/fs/bpf/tc/globals/cilium_policy_01236

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3783638   36147     0        
Allow    Ingress     1          ANY          NONE         disabled    3693899   37698     0        
Allow    Egress      0          ANY          NONE         disabled    5428555   49841     0        


Endpoint ID: 1504
Path: /sys/fs/bpf/tc/globals/cilium_policy_01504

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2857
Path: /sys/fs/bpf/tc/globals/cilium_policy_02857

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    8392    76        0        
Allow    Ingress     1          ANY          NONE         disabled    93066   1073      0        
Allow    Egress      0          ANY          NONE         disabled    17601   181       0        


Endpoint ID: 3753
Path: /sys/fs/bpf/tc/globals/cilium_policy_03753

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    436723   5588      0        
Allow    Ingress     1          ANY          NONE         disabled    14924    178       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


