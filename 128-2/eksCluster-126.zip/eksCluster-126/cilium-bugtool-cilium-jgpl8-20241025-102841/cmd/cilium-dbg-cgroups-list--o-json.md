[
  {
    "containers": [
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod229ac65a_18f0_4373_8768_aaafb5f35d8c.slice/cri-containerd-71ec58d940f7d9fa09a56d84b9fc325bc2fc1d26f3df8cd9162ce8cd799e6b85.scope"
      },
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod229ac65a_18f0_4373_8768_aaafb5f35d8c.slice/cri-containerd-489fb73f74d091990bd329aec171c360ff77a86c47e02e1574fc2e7e822a4949.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod229ac65a_18f0_4373_8768_aaafb5f35d8c.slice/cri-containerd-8e7bc9650196f65797d7b8efbdead16a39c3eb96f8d930fd13a4bae4612ddee3.scope"
      }
    ],
    "ips": [
      "10.126.0.14"
    ],
    "name": "clustermesh-apiserver-67b7c554fd-7rvqz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7530,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode1ab0f82_fc45_4113_9000_da8a09a747c8.slice/cri-containerd-4e4f72de90e9fccc1058a963234e1018556a1b0180d3b559c07b451a4cfcc40b.scope"
      }
    ],
    "ips": [
      "10.126.0.236"
    ],
    "name": "coredns-cc6ccd49c-szvgs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod370cc6d2_0c76_4b65_a5ba_8ead6cee9fc2.slice/cri-containerd-d06fe2263dc2cf3669d605ae6f156cdc3e0daa12ddca3bc891a41074da19527f.scope"
      }
    ],
    "ips": [
      "10.126.0.147"
    ],
    "name": "coredns-cc6ccd49c-d46j4",
    "namespace": "kube-system"
  }
]

