CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0cd45ba0_1aba_4759_bbf6_a629ccb0bbf5.slice/cri-containerd-44fc8b1fb13272510fd725204db8b77d8e47597a8f81a963adae8b4612b63818.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0cd45ba0_1aba_4759_bbf6_a629ccb0bbf5.slice/cri-containerd-0b5a14e68e687184a818943e81ef4d7d3d5b25cb91fa5a45a8ad5080828c287d.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7ae87de9_87f6_4a1c_a69e_d622cfd58fd0.slice/cri-containerd-9aeb63a98660289761da6bdb14b2c76c72fc473d68d37b8da13dc908b0238e93.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7ae87de9_87f6_4a1c_a69e_d622cfd58fd0.slice/cri-containerd-25e218490449ec39e8b3173f41b2cbe31bdfbee0726e9304235858974370fcec.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod370cc6d2_0c76_4b65_a5ba_8ead6cee9fc2.slice/cri-containerd-d06fe2263dc2cf3669d605ae6f156cdc3e0daa12ddca3bc891a41074da19527f.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod370cc6d2_0c76_4b65_a5ba_8ead6cee9fc2.slice/cri-containerd-59bbf7748808f3ec68be8998eb6922cbf006b5ea99076b91415b8867a79acc5f.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode1ab0f82_fc45_4113_9000_da8a09a747c8.slice/cri-containerd-3db27798c5080e7eb621cf3b2e0069e3927e362c3f9dc0050e6b445820d606a0.scope
    574      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode1ab0f82_fc45_4113_9000_da8a09a747c8.slice/cri-containerd-4e4f72de90e9fccc1058a963234e1018556a1b0180d3b559c07b451a4cfcc40b.scope
    578      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod229ac65a_18f0_4373_8768_aaafb5f35d8c.slice/cri-containerd-71ec58d940f7d9fa09a56d84b9fc325bc2fc1d26f3df8cd9162ce8cd799e6b85.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod229ac65a_18f0_4373_8768_aaafb5f35d8c.slice/cri-containerd-489fb73f74d091990bd329aec171c360ff77a86c47e02e1574fc2e7e822a4949.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod229ac65a_18f0_4373_8768_aaafb5f35d8c.slice/cri-containerd-90c11cd8d6fa44cf5ac4897868d56a3dd181861040911f922baa894f2127f104.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod229ac65a_18f0_4373_8768_aaafb5f35d8c.slice/cri-containerd-8e7bc9650196f65797d7b8efbdead16a39c3eb96f8d930fd13a4bae4612ddee3.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod87895c08_9d6b_4f6b_8618_862d9205cbf8.slice/cri-containerd-e3a2a3c3b16b09d3151c14245acd297afa3369e51748b9fd345ee9a233a5f5b3.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod87895c08_9d6b_4f6b_8618_862d9205cbf8.slice/cri-containerd-f2657c4be4db3f8a16d7f87c5befd09c3171bbe96fb0b67c0b555d290135d98c.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod27e7ea12_3f02_4133_86b6_bb6ad0aefa8a.slice/cri-containerd-f8d66aa2e7675ea6a73a0c3ba8b4f21148609e7e410ab196d30510a6654a12c6.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod27e7ea12_3f02_4133_86b6_bb6ad0aefa8a.slice/cri-containerd-b4d045f38696f74564fa971c5d7d3070dcad244b126d60b92d78d5e0da00c55c.scope
    99       cgroup_device   multi                                          
