Total: 556
TCP:   1071 (estab 302, closed 750, orphaned 0, timewait 295)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  321       310       11       
INET	  331       316       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.181.107%ens5:68         0.0.0.0:*    uid:192 ino:15623 sk:25e cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:24353 sk:25f cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:14222 sk:260 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:33297      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=40)) ino:23364 sk:261 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:24352 sk:262 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:14223 sk:263 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::47a:56ff:fe49:6657]%ens5:546           [::]:*    uid:192 ino:15621 sk:264 cgroup:unreachable:c4e v6only:1 <->                   
