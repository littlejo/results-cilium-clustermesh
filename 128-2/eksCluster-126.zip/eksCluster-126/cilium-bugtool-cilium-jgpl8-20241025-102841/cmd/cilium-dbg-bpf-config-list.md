KEY             VALUE
AgentLiveness   929164890699
UTimeOffset     3378615671875000
