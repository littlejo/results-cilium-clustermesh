ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.203.38:443 (active)     
                                         2 => 172.31.137.35:443 (active)     
2    10.100.237.170:443   ClusterIP      1 => 172.31.181.107:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.126.0.236:53 (active)       
                                         2 => 10.126.0.147:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.126.0.236:9153 (active)     
                                         2 => 10.126.0.147:9153 (active)     
5    10.100.231.34:2379   ClusterIP      1 => 10.126.0.14:2379 (active)      
