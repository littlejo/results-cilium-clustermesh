Endpoint ID: 31
Path: /sys/fs/bpf/tc/globals/cilium_policy_00031

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    81826   940       0        
Allow    Egress      0          ANY          NONE         disabled    14200   148       0        


Endpoint ID: 415
Path: /sys/fs/bpf/tc/globals/cilium_policy_00415

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3877837   36586     0        
Allow    Ingress     1          ANY          NONE         disabled    3030273   30550     0        
Allow    Egress      0          ANY          NONE         disabled    4703964   43407     0        


Endpoint ID: 477
Path: /sys/fs/bpf/tc/globals/cilium_policy_00477

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1110
Path: /sys/fs/bpf/tc/globals/cilium_policy_01110

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    79992   914       0        
Allow    Egress      0          ANY          NONE         disabled    13997   146       0        


Endpoint ID: 1982
Path: /sys/fs/bpf/tc/globals/cilium_policy_01982

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    438520   5601      0        
Allow    Ingress     1          ANY          NONE         disabled    11908    138       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


