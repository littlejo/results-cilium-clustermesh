IP ADDRESS         LOCAL ENDPOINT INFO
172.31.177.223:0   (localhost)                                                                                        
10.126.0.44:0      id=1982  sec_id=4     flags=0x0000 ifindex=10  mac=6E:D1:5F:DC:5B:73 nodemac=DE:FF:93:36:FD:CC     
10.126.0.236:0     id=31    sec_id=8323263 flags=0x0000 ifindex=12  mac=CA:0D:A2:70:E4:9C nodemac=5E:B0:E5:AB:9D:F6   
172.31.181.107:0   (localhost)                                                                                        
10.126.0.14:0      id=415   sec_id=8349339 flags=0x0000 ifindex=18  mac=E6:8D:DB:86:2F:1B nodemac=56:31:D2:CE:8B:FC   
10.126.0.166:0     (localhost)                                                                                        
10.126.0.147:0     id=1110  sec_id=8323263 flags=0x0000 ifindex=14  mac=F6:48:9E:C0:3F:3F nodemac=7A:E0:F2:5F:BA:CD   
