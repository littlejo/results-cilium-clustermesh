29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 124
479: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 125
480: sched_cls  name tail_handle_ipv4  tag 0f1d025780a6639a  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 126
481: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
513: sched_cls  name cil_from_container  tag 2008c0d55f6d69e5  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 165
516: sched_cls  name handle_policy  tag 015bf2b9aafc4b3f  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 167
524: sched_cls  name tail_handle_ipv4  tag 89cf099bbd4d21df  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 170
525: sched_cls  name tail_handle_arp  tag 8252331fa19f8e88  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 177
526: sched_cls  name __send_drop_notify  tag eff14bcf174ad570  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 178
527: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 179
528: sched_cls  name tail_handle_ipv4_from_host  tag 99191f4711b4e04b  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,114
	btf_id 182
530: sched_cls  name __send_drop_notify  tag 02af2f3b89bcb828  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 184
531: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,114
	btf_id 185
532: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 186
534: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,114
	btf_id 188
535: sched_cls  name tail_ipv4_to_endpoint  tag aa3568c570e36cb3  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 180
537: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 191
539: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 194
540: sched_cls  name tail_handle_ipv4_from_host  tag 99191f4711b4e04b  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 195
542: sched_cls  name __send_drop_notify  tag 02af2f3b89bcb828  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 197
543: sched_cls  name tail_ipv4_ct_ingress  tag 51491bac6e5ecf43  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 192
546: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 202
547: sched_cls  name tail_handle_ipv4_cont  tag 5c95a61db2f762dd  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 198
548: sched_cls  name tail_handle_ipv4_from_host  tag 99191f4711b4e04b  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 203
549: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,118,75
	btf_id 205
550: sched_cls  name __send_drop_notify  tag 02af2f3b89bcb828  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 206
552: sched_cls  name tail_ipv4_ct_egress  tag c49d9e777e86efbc  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 204
553: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 209
554: sched_cls  name tail_handle_arp  tag c8f768f9b780b2fd  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,123
	btf_id 212
555: sched_cls  name tail_ipv4_ct_ingress  tag c7282232c899b0e8  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,123,82,83,122,84
	btf_id 213
556: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,123
	btf_id 214
557: sched_cls  name tail_handle_ipv4_cont  tag 9a657a3ed11c43eb  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,122,41,100,82,83,39,76,74,77,123,40,37,38,81
	btf_id 215
558: sched_cls  name tail_handle_ipv4_from_host  tag 99191f4711b4e04b  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 210
559: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 216
560: sched_cls  name __send_drop_notify  tag 02af2f3b89bcb828  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 218
563: sched_cls  name handle_policy  tag 9254876e31b07aa6  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,123,82,83,122,41,80,100,39,84,75,40,37,38
	btf_id 217
565: sched_cls  name cil_from_container  tag c759eb43d50add31  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 123,76
	btf_id 222
566: sched_cls  name __send_drop_notify  tag a05ef60c61685099  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 223
567: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,123,82,83,122,84
	btf_id 224
568: sched_cls  name tail_handle_ipv4  tag d22c297d0b7c7b51  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,123
	btf_id 225
569: sched_cls  name tail_ipv4_to_endpoint  tag 306ae7a45b4cd28e  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,122,41,82,83,80,100,39,123,40,37,38
	btf_id 226
571: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
574: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
575: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
578: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
579: sched_cls  name tail_handle_ipv4_cont  tag eb4b24a829d2171f  gpl
	loaded_at 2024-10-25T10:15:00+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,127,41,126,82,83,39,76,74,77,128,40,37,38,81
	btf_id 229
581: sched_cls  name handle_policy  tag 5c0162cfeaf8f7f6  gpl
	loaded_at 2024-10-25T10:15:00+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,128,82,83,127,41,80,126,39,84,75,40,37,38
	btf_id 231
582: sched_cls  name tail_handle_ipv4  tag e028daab1fa40386  gpl
	loaded_at 2024-10-25T10:15:00+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,128
	btf_id 232
583: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:00+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,128
	btf_id 233
584: sched_cls  name tail_handle_arp  tag acb580faca20bbf3  gpl
	loaded_at 2024-10-25T10:15:00+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,128
	btf_id 234
585: sched_cls  name cil_from_container  tag 75e7e3ee0f559c31  gpl
	loaded_at 2024-10-25T10:15:00+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 128,76
	btf_id 235
586: sched_cls  name __send_drop_notify  tag 4cf4212cf56b5335  gpl
	loaded_at 2024-10-25T10:15:00+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 236
587: sched_cls  name tail_ipv4_to_endpoint  tag 14a2a85be62f63a3  gpl
	loaded_at 2024-10-25T10:15:00+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,127,41,82,83,80,126,39,128,40,37,38
	btf_id 237
588: sched_cls  name tail_ipv4_ct_ingress  tag 82c133749b977fc6  gpl
	loaded_at 2024-10-25T10:15:00+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,128,82,83,127,84
	btf_id 238
589: sched_cls  name tail_ipv4_ct_egress  tag c49d9e777e86efbc  gpl
	loaded_at 2024-10-25T10:15:00+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,128,82,83,127,84
	btf_id 239
590: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
593: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
594: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
597: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
637: sched_cls  name tail_handle_arp  tag d4d4a1bd03460506  gpl
	loaded_at 2024-10-25T10:21:59+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,143
	btf_id 253
638: sched_cls  name tail_handle_ipv4_cont  tag ed70226fb84af2fd  gpl
	loaded_at 2024-10-25T10:21:59+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,142,41,141,82,83,39,76,74,77,143,40,37,38,81
	btf_id 254
640: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:59+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,143
	btf_id 256
641: sched_cls  name __send_drop_notify  tag 82622a35f115d476  gpl
	loaded_at 2024-10-25T10:21:59+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 257
642: sched_cls  name tail_ipv4_ct_egress  tag d35e97ed17acbd89  gpl
	loaded_at 2024-10-25T10:21:59+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 258
643: sched_cls  name tail_handle_ipv4  tag e878bbf082b44623  gpl
	loaded_at 2024-10-25T10:21:59+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,143
	btf_id 259
644: sched_cls  name tail_ipv4_to_endpoint  tag f49379927971075a  gpl
	loaded_at 2024-10-25T10:21:59+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,142,41,82,83,80,141,39,143,40,37,38
	btf_id 260
645: sched_cls  name cil_from_container  tag faf03b44a4e32e5c  gpl
	loaded_at 2024-10-25T10:21:59+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 143,76
	btf_id 261
646: sched_cls  name tail_ipv4_ct_ingress  tag 6c01976ee3927fcc  gpl
	loaded_at 2024-10-25T10:21:59+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 262
647: sched_cls  name handle_policy  tag 0ae7b4042f7aa6eb  gpl
	loaded_at 2024-10-25T10:21:59+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,143,82,83,142,41,80,141,39,84,75,40,37,38
	btf_id 263
648: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
651: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
664: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
667: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
668: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
671: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
672: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
675: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
