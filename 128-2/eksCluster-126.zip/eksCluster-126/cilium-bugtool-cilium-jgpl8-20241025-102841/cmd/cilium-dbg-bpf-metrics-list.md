REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     220278    85193819   1132   bpf_host.c
Interface                 INGRESS     9502      741867     677    bpf_overlay.c
Success                   EGRESS      4577      349427     1694   bpf_host.c
Success                   EGRESS      92637     12342067   1308   bpf_lxc.c
Success                   EGRESS      9353      730870     53     encap.h
Success                   INGRESS     103188    12718781   86     l3.h
Success                   INGRESS     108762    13155127   235    trace.h
Unsupported L3 protocol   EGRESS      41        3098       1492   bpf_lxc.c
