xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 549
ens6(5) clsact/ingress cil_from_netdev-ens6 id 559
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 537
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 532
cilium_host(7) clsact/egress cil_from_host-cilium_host id 531
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 478
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 565
lxcd5ed6a8495f9(12) clsact/ingress cil_from_container-lxcd5ed6a8495f9 id 513
lxc6be51bfda6a0(14) clsact/ingress cil_from_container-lxc6be51bfda6a0 id 585
lxc2883bbf394b0(18) clsact/ingress cil_from_container-lxc2883bbf394b0 id 645

flow_dissector:

netfilter:

