key: 1f 00 00 00  value: 04 02 00 00
key: 9f 01 00 00  value: 87 02 00 00
key: 56 04 00 00  value: 45 02 00 00
key: be 07 00 00  value: 33 02 00 00
Found 4 elements
