alloc: 96.18MB (100848544 bytes)
total-alloc: 1.34GB (1436270488 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 47863552
frees: 47070384
heap-alloc: 96.18MB (100848544 bytes)
heap-sys: 165.48MB (173522944 bytes)
heap-idle: 36.85MB (38641664 bytes)
heap-in-use: 128.63MB (134881280 bytes)
heap-released: 1.19MB (1245184 bytes)
heap-objects: 793168
stack-in-use: 34.47MB (36143104 bytes)
stack-sys: 34.47MB (36143104 bytes)
stack-mspan-inuse: 1.99MB (2083200 bytes)
stack-mspan-sys: 2.49MB (2611200 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 872.25KB (893185 bytes)
gc-sys: 5.17MB (5423360 bytes)
next-gc: when heap-alloc >= 147.53MB (154701320 bytes)
last-gc: 2024-10-25 10:28:53.100093782 +0000 UTC
gc-pause-total: 12.196478ms
gc-pause: 73503
gc-pause-end: 1729852133100093782
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00032894145208108727
enable-gc: true
debug-gc: false
