Node 0, zone      DMA    220     83     10     17     22     12      8      2      1      3    155 
Node 0, zone   Normal     10      0      1      2      8     11      0      6      3      1      8 
