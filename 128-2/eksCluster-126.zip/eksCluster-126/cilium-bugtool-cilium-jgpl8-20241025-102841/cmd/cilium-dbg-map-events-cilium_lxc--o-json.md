{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:48.604Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.177.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:48.604Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.181.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:48.604Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:53.112Z",
  "value": "id=1982  sec_id=4     flags=0x0000 ifindex=10  mac=6E:D1:5F:DC:5B:73 nodemac=DE:FF:93:36:FD:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:53.128Z",
  "value": "id=31    sec_id=8323263 flags=0x0000 ifindex=12  mac=CA:0D:A2:70:E4:9C nodemac=5E:B0:E5:AB:9D:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:53.162Z",
  "value": "id=1982  sec_id=4     flags=0x0000 ifindex=10  mac=6E:D1:5F:DC:5B:73 nodemac=DE:FF:93:36:FD:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:00.711Z",
  "value": "id=1110  sec_id=8323263 flags=0x0000 ifindex=14  mac=F6:48:9E:C0:3F:3F nodemac=7A:E0:F2:5F:BA:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:41.616Z",
  "value": "id=1982  sec_id=4     flags=0x0000 ifindex=10  mac=6E:D1:5F:DC:5B:73 nodemac=DE:FF:93:36:FD:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:41.617Z",
  "value": "id=31    sec_id=8323263 flags=0x0000 ifindex=12  mac=CA:0D:A2:70:E4:9C nodemac=5E:B0:E5:AB:9D:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:41.618Z",
  "value": "id=1110  sec_id=8323263 flags=0x0000 ifindex=14  mac=F6:48:9E:C0:3F:3F nodemac=7A:E0:F2:5F:BA:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:41.647Z",
  "value": "id=1848  sec_id=8349339 flags=0x0000 ifindex=16  mac=66:EE:AB:DF:B0:B5 nodemac=F6:40:B5:40:03:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.14:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:59.958Z",
  "value": "id=415   sec_id=8349339 flags=0x0000 ifindex=18  mac=E6:8D:DB:86:2F:1B nodemac=56:31:D2:CE:8B:FC"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.126.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:10.252Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.355Z",
  "value": "id=31    sec_id=8323263 flags=0x0000 ifindex=12  mac=CA:0D:A2:70:E4:9C nodemac=5E:B0:E5:AB:9D:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.355Z",
  "value": "id=1110  sec_id=8323263 flags=0x0000 ifindex=14  mac=F6:48:9E:C0:3F:3F nodemac=7A:E0:F2:5F:BA:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.14:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.356Z",
  "value": "id=415   sec_id=8349339 flags=0x0000 ifindex=18  mac=E6:8D:DB:86:2F:1B nodemac=56:31:D2:CE:8B:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.356Z",
  "value": "id=1982  sec_id=4     flags=0x0000 ifindex=10  mac=6E:D1:5F:DC:5B:73 nodemac=DE:FF:93:36:FD:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:58.356Z",
  "value": "id=31    sec_id=8323263 flags=0x0000 ifindex=12  mac=CA:0D:A2:70:E4:9C nodemac=5E:B0:E5:AB:9D:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.14:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:58.356Z",
  "value": "id=415   sec_id=8349339 flags=0x0000 ifindex=18  mac=E6:8D:DB:86:2F:1B nodemac=56:31:D2:CE:8B:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:58.357Z",
  "value": "id=1110  sec_id=8323263 flags=0x0000 ifindex=14  mac=F6:48:9E:C0:3F:3F nodemac=7A:E0:F2:5F:BA:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:58.357Z",
  "value": "id=1982  sec_id=4     flags=0x0000 ifindex=10  mac=6E:D1:5F:DC:5B:73 nodemac=DE:FF:93:36:FD:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:59.356Z",
  "value": "id=1982  sec_id=4     flags=0x0000 ifindex=10  mac=6E:D1:5F:DC:5B:73 nodemac=DE:FF:93:36:FD:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:59.357Z",
  "value": "id=1110  sec_id=8323263 flags=0x0000 ifindex=14  mac=F6:48:9E:C0:3F:3F nodemac=7A:E0:F2:5F:BA:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:59.357Z",
  "value": "id=31    sec_id=8323263 flags=0x0000 ifindex=12  mac=CA:0D:A2:70:E4:9C nodemac=5E:B0:E5:AB:9D:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.14:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:59.357Z",
  "value": "id=415   sec_id=8349339 flags=0x0000 ifindex=18  mac=E6:8D:DB:86:2F:1B nodemac=56:31:D2:CE:8B:FC"
}

