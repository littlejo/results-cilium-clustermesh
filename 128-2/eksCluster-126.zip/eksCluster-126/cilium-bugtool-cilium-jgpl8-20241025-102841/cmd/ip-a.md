1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:7a:56:49:66:57 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.181.107/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2710sec preferred_lft 2710sec
    inet6 fe80::47a:56ff:fe49:6657/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:23:dc:41:b3:ab brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.177.223/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::423:dcff:fe41:b3ab/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:e0:69:f1:53:f7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::20e0:69ff:fef1:53f7/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:49:df:bd:9d:c7 brd ff:ff:ff:ff:ff:ff
    inet 10.126.0.166/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::4c49:dfff:febd:9dc7/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 26:6c:f5:46:09:64 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::246c:f5ff:fe46:964/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:ff:93:36:fd:cc brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::dcff:93ff:fe36:fdcc/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcd5ed6a8495f9@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:b0:e5:ab:9d:f6 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::5cb0:e5ff:feab:9df6/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc6be51bfda6a0@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:e0:f2:5f:ba:cd brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::78e0:f2ff:fe5f:bacd/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc2883bbf394b0@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:31:d2:ce:8b:fc brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::5431:d2ff:fece:8bfc/64 scope link 
       valid_lft forever preferred_lft forever
