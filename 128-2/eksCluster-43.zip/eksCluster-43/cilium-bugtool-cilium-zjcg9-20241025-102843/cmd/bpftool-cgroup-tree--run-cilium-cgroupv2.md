CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf45cdd2e_1c68_48a2_be8b_cac52308842d.slice/cri-containerd-6f1965b0dab76123188044bf5d657996dc918b38b3f100180620fb23d7b08e1e.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf45cdd2e_1c68_48a2_be8b_cac52308842d.slice/cri-containerd-c36232cc016145363f576e00f3029fff20f4582a3ea78038dda68d7d66204802.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6974c946_bf9a_4942_9125_45869120be77.slice/cri-containerd-92c5ad3c9a2fc2523c13244f958ad9296c348281a5e86c0e12347d145a928587.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6974c946_bf9a_4942_9125_45869120be77.slice/cri-containerd-2eea958309e49003af7d41b2735b90af8ef65b12d6b46738664f3a3a0887e647.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0389408d_3fe8_47cd_80ac_3749447a09df.slice/cri-containerd-6992df6f28c1088f9e62c12a11924ac33476a74cf6ea29b33fd1d93f19a77d78.scope
    580      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0389408d_3fe8_47cd_80ac_3749447a09df.slice/cri-containerd-cd77c861180f8c9bdf82768d621ded499215ce75a95b1494fd45f0c865cce66b.scope
    584      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ada44e2_6b5f_415b_9a69_8f7b0b006c53.slice/cri-containerd-45d9023e703efc34fd8b6497cbb3a3d38d15db651c559863457d5b3201044be4.scope
    607      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ada44e2_6b5f_415b_9a69_8f7b0b006c53.slice/cri-containerd-d8703c889736938c0568b65c3ce5f37154f7c779556a9196b84db43ebd8966cb.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod27ef9549_b51e_46bc_9d73_3831a2e9ceb1.slice/cri-containerd-f73d38020739025b23650170fe14e1ee7139a084fe71d9d346a2bef0707c1f56.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod27ef9549_b51e_46bc_9d73_3831a2e9ceb1.slice/cri-containerd-53eef76b9b81b1b5f8dee5ce5a72fa862f195b13d9ed33ce63d63b07e9203323.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod678da133_6db7_4135_aba3_f29cd7c55555.slice/cri-containerd-2ad65a64c73d957012fc03f841a729f38cbee7986718e74993e2ab7eb4aac7da.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod678da133_6db7_4135_aba3_f29cd7c55555.slice/cri-containerd-35ca3ef91a2937bc2b1d0b365ce72ff592c427b5f1d95d37d3eaa58817a0ee93.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode54d24ac_5866_4eb5_be47_21797e285741.slice/cri-containerd-7575570db8579d80a06d03647a1ef4b10e5332a6f8c1298b77f60f8b5ce3d341.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode54d24ac_5866_4eb5_be47_21797e285741.slice/cri-containerd-c3cf46f56bd720f967b99a6ca4d4d8fad119e45ee0279e9e34470926c485eee5.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode54d24ac_5866_4eb5_be47_21797e285741.slice/cri-containerd-359133b09a7164fd7d4f13634e21a95840aba8d59705462fcdf16d10a7f2549c.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode54d24ac_5866_4eb5_be47_21797e285741.slice/cri-containerd-23747a7b932c719b782547063050b13ed8ff8e1f69ab7c9721c98367dbf86cae.scope
    677      cgroup_device   multi                                          
