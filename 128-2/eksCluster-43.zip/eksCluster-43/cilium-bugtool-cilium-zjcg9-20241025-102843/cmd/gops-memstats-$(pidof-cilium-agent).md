alloc: 134.58MB (141118304 bytes)
total-alloc: 1.30GB (1400695168 bytes)
sys: 202.32MB (212146500 bytes)
lookups: 0
mallocs: 47449129
frees: 45966628
heap-alloc: 134.58MB (141118304 bytes)
heap-sys: 157.45MB (165101568 bytes)
heap-idle: 6.90MB (7233536 bytes)
heap-in-use: 150.55MB (157868032 bytes)
heap-released: 688.00KB (704512 bytes)
heap-objects: 1482501
stack-in-use: 34.50MB (36175872 bytes)
stack-sys: 34.50MB (36175872 bytes)
stack-mspan-inuse: 2.45MB (2564000 bytes)
stack-mspan-sys: 2.49MB (2611200 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 881.95KB (903113 bytes)
gc-sys: 5.09MB (5336208 bytes)
next-gc: when heap-alloc >= 144.85MB (151886776 bytes)
last-gc: 2024-10-25 10:28:29.300035708 +0000 UTC
gc-pause-total: 13.32913ms
gc-pause: 96321
gc-pause-end: 1729852109300035708
num-gc: 71
num-forced-gc: 0
gc-cpu-fraction: 0.0003966948844494896
enable-gc: true
debug-gc: false
