filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcbc85d0e2e322 direct-action not_in_hw id 647 tag 1ea459dc3f930a76 jited 
