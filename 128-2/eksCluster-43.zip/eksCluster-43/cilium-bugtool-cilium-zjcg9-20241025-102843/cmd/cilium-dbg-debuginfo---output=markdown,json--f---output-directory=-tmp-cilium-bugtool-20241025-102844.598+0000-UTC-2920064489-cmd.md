markdown output at /tmp/cilium-bugtool-20241025-102844.598+0000-UTC-2920064489/cmd/cilium-debuginfo-20241025-102915.105+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102844.598+0000-UTC-2920064489/cmd/cilium-debuginfo-20241025-102915.105+0000-UTC.json
