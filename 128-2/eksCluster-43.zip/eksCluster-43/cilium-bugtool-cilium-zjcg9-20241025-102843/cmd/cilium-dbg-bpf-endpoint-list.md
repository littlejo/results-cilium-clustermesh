IP ADDRESS         LOCAL ENDPOINT INFO
172.31.255.108:0   (localhost)                                                                                        
10.43.0.94:0       id=174   sec_id=2928214 flags=0x0000 ifindex=18  mac=4A:56:AB:9B:55:A2 nodemac=2E:C3:35:0B:AC:76   
10.43.0.168:0      id=316   sec_id=2916653 flags=0x0000 ifindex=14  mac=62:65:16:3F:C5:6C nodemac=82:3E:E6:E8:A3:0E   
10.43.0.247:0      id=818   sec_id=2916653 flags=0x0000 ifindex=12  mac=7A:51:E1:EB:42:4F nodemac=5E:1B:84:38:91:9E   
10.43.0.254:0      (localhost)                                                                                        
172.31.251.101:0   (localhost)                                                                                        
10.43.0.137:0      id=1380  sec_id=4     flags=0x0000 ifindex=10  mac=5A:A1:A5:F8:DA:03 nodemac=E2:AC:57:8E:A2:3C     
