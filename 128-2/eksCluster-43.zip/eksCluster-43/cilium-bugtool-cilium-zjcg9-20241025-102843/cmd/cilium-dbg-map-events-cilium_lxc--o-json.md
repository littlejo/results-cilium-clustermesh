{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:05.163Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.251.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:05.163Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.255.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:05.163Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:09.510Z",
  "value": "id=818   sec_id=2916653 flags=0x0000 ifindex=12  mac=7A:51:E1:EB:42:4F nodemac=5E:1B:84:38:91:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:09.513Z",
  "value": "id=1380  sec_id=4     flags=0x0000 ifindex=10  mac=5A:A1:A5:F8:DA:03 nodemac=E2:AC:57:8E:A2:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:09.553Z",
  "value": "id=1380  sec_id=4     flags=0x0000 ifindex=10  mac=5A:A1:A5:F8:DA:03 nodemac=E2:AC:57:8E:A2:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:17.745Z",
  "value": "id=316   sec_id=2916653 flags=0x0000 ifindex=14  mac=62:65:16:3F:C5:6C nodemac=82:3E:E6:E8:A3:0E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:19.387Z",
  "value": "id=1380  sec_id=4     flags=0x0000 ifindex=10  mac=5A:A1:A5:F8:DA:03 nodemac=E2:AC:57:8E:A2:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:19.388Z",
  "value": "id=818   sec_id=2916653 flags=0x0000 ifindex=12  mac=7A:51:E1:EB:42:4F nodemac=5E:1B:84:38:91:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:19.389Z",
  "value": "id=316   sec_id=2916653 flags=0x0000 ifindex=14  mac=62:65:16:3F:C5:6C nodemac=82:3E:E6:E8:A3:0E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:19.418Z",
  "value": "id=1772  sec_id=2928214 flags=0x0000 ifindex=16  mac=06:3D:42:EB:CD:0F nodemac=5A:10:F5:F6:69:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:20.388Z",
  "value": "id=1380  sec_id=4     flags=0x0000 ifindex=10  mac=5A:A1:A5:F8:DA:03 nodemac=E2:AC:57:8E:A2:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:20.388Z",
  "value": "id=1772  sec_id=2928214 flags=0x0000 ifindex=16  mac=06:3D:42:EB:CD:0F nodemac=5A:10:F5:F6:69:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:20.389Z",
  "value": "id=818   sec_id=2916653 flags=0x0000 ifindex=12  mac=7A:51:E1:EB:42:4F nodemac=5E:1B:84:38:91:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:20.389Z",
  "value": "id=316   sec_id=2916653 flags=0x0000 ifindex=14  mac=62:65:16:3F:C5:6C nodemac=82:3E:E6:E8:A3:0E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:47.765Z",
  "value": "id=174   sec_id=2928214 flags=0x0000 ifindex=18  mac=4A:56:AB:9B:55:A2 nodemac=2E:C3:35:0B:AC:76"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.43.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.787Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.972Z",
  "value": "id=174   sec_id=2928214 flags=0x0000 ifindex=18  mac=4A:56:AB:9B:55:A2 nodemac=2E:C3:35:0B:AC:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.974Z",
  "value": "id=1380  sec_id=4     flags=0x0000 ifindex=10  mac=5A:A1:A5:F8:DA:03 nodemac=E2:AC:57:8E:A2:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.974Z",
  "value": "id=818   sec_id=2916653 flags=0x0000 ifindex=12  mac=7A:51:E1:EB:42:4F nodemac=5E:1B:84:38:91:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.975Z",
  "value": "id=316   sec_id=2916653 flags=0x0000 ifindex=14  mac=62:65:16:3F:C5:6C nodemac=82:3E:E6:E8:A3:0E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.961Z",
  "value": "id=1380  sec_id=4     flags=0x0000 ifindex=10  mac=5A:A1:A5:F8:DA:03 nodemac=E2:AC:57:8E:A2:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.961Z",
  "value": "id=174   sec_id=2928214 flags=0x0000 ifindex=18  mac=4A:56:AB:9B:55:A2 nodemac=2E:C3:35:0B:AC:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.962Z",
  "value": "id=818   sec_id=2916653 flags=0x0000 ifindex=12  mac=7A:51:E1:EB:42:4F nodemac=5E:1B:84:38:91:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.962Z",
  "value": "id=316   sec_id=2916653 flags=0x0000 ifindex=14  mac=62:65:16:3F:C5:6C nodemac=82:3E:E6:E8:A3:0E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:19.962Z",
  "value": "id=174   sec_id=2928214 flags=0x0000 ifindex=18  mac=4A:56:AB:9B:55:A2 nodemac=2E:C3:35:0B:AC:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:19.963Z",
  "value": "id=1380  sec_id=4     flags=0x0000 ifindex=10  mac=5A:A1:A5:F8:DA:03 nodemac=E2:AC:57:8E:A2:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:19.963Z",
  "value": "id=818   sec_id=2916653 flags=0x0000 ifindex=12  mac=7A:51:E1:EB:42:4F nodemac=5E:1B:84:38:91:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.43.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:19.964Z",
  "value": "id=316   sec_id=2916653 flags=0x0000 ifindex=14  mac=62:65:16:3F:C5:6C nodemac=82:3E:E6:E8:A3:0E"
}

