REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     207963    83472605   1132   bpf_host.c
Interface                 INGRESS     9421      737031     677    bpf_overlay.c
Success                   EGRESS      4543      347159     1694   bpf_host.c
Success                   EGRESS      88146     12009365   1308   bpf_lxc.c
Success                   EGRESS      9238      723839     53     encap.h
Success                   INGRESS     105030    12537492   235    trace.h
Success                   INGRESS     99503     12103714   86     l3.h
Unsupported L3 protocol   EGRESS      42        3188       1492   bpf_lxc.c
