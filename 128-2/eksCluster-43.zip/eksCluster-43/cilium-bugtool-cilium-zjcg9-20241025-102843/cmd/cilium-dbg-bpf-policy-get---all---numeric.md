Endpoint ID: 174
Path: /sys/fs/bpf/tc/globals/cilium_policy_00174

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3898282   36122     0        
Allow    Ingress     1          ANY          NONE         disabled    2954360   29814     0        
Allow    Egress      0          ANY          NONE         disabled    3930928   36584     0        


Endpoint ID: 316
Path: /sys/fs/bpf/tc/globals/cilium_policy_00316

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    66372   760       0        
Allow    Egress      0          ANY          NONE         disabled    12445   125       0        


Endpoint ID: 818
Path: /sys/fs/bpf/tc/globals/cilium_policy_00818

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    68836   792       0        
Allow    Egress      0          ANY          NONE         disabled    12992   134       0        


Endpoint ID: 1380
Path: /sys/fs/bpf/tc/globals/cilium_policy_01380

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    434540   5537      0        
Allow    Ingress     1          ANY          NONE         disabled    9932     114       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3326
Path: /sys/fs/bpf/tc/globals/cilium_policy_03326

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


