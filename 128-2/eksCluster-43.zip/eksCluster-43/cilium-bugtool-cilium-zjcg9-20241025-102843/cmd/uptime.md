 10:28:44 up 12 min,  0 users,  load average: 0.01, 0.10, 0.10
