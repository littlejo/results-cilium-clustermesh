[
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode54d24ac_5866_4eb5_be47_21797e285741.slice/cri-containerd-23747a7b932c719b782547063050b13ed8ff8e1f69ab7c9721c98367dbf86cae.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode54d24ac_5866_4eb5_be47_21797e285741.slice/cri-containerd-359133b09a7164fd7d4f13634e21a95840aba8d59705462fcdf16d10a7f2549c.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode54d24ac_5866_4eb5_be47_21797e285741.slice/cri-containerd-c3cf46f56bd720f967b99a6ca4d4d8fad119e45ee0279e9e34470926c485eee5.scope"
      }
    ],
    "ips": [
      "10.43.0.94"
    ],
    "name": "clustermesh-apiserver-6459bfdd66-j5tqg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7535,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0389408d_3fe8_47cd_80ac_3749447a09df.slice/cri-containerd-cd77c861180f8c9bdf82768d621ded499215ce75a95b1494fd45f0c865cce66b.scope"
      }
    ],
    "ips": [
      "10.43.0.247"
    ],
    "name": "coredns-cc6ccd49c-x5jsh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8039,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ada44e2_6b5f_415b_9a69_8f7b0b006c53.slice/cri-containerd-45d9023e703efc34fd8b6497cbb3a3d38d15db651c559863457d5b3201044be4.scope"
      }
    ],
    "ips": [
      "10.43.0.168"
    ],
    "name": "coredns-cc6ccd49c-5pnbm",
    "namespace": "kube-system"
  }
]

