filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc2f8b00fac30f direct-action not_in_hw id 597 tag b1aa5fcfd00228ca jited 
