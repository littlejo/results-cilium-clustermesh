Node 0, zone      DMA    204     24     11     23      9      4      2      1      2      4    166 
Node 0, zone   Normal    361     59     24     27     22      9      3      7      4      4      5 
