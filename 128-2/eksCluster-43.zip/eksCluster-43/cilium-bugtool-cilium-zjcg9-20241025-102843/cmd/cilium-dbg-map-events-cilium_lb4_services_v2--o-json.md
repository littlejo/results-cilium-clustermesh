{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.052Z",
  "value": "1 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.052Z",
  "value": "2 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.052Z",
  "value": "0 2 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.142.91:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.052Z",
  "value": "0 0 (2) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.052Z",
  "value": "4 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.052Z",
  "value": "3 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.052Z",
  "value": "0 1 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.052Z",
  "value": "6 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.052Z",
  "value": "5 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.052Z",
  "value": "0 1 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.142.91:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:06.192Z",
  "value": "7 0 (2) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.142.91:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:06.192Z",
  "value": "0 1 (2) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:07.179Z",
  "value": "4 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:07.179Z",
  "value": "0 1 (3) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.0.10:53 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:07.179Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:07.179Z",
  "value": "6 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:07.179Z",
  "value": "0 1 (4) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.0.10:9153 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:07.179Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.706Z",
  "value": "6 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.706Z",
  "value": "0 1 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.706Z",
  "value": "4 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.706Z",
  "value": "0 1 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.744Z",
  "value": "4 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.744Z",
  "value": "8 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.744Z",
  "value": "0 2 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.744Z",
  "value": "6 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.744Z",
  "value": "9 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.744Z",
  "value": "0 2 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.140.145:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:15.099Z",
  "value": "0 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:16.928Z",
  "value": "8 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:16.928Z",
  "value": "4 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:16.928Z",
  "value": "0 1 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:16.928Z",
  "value": "9 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:16.928Z",
  "value": "6 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:16.928Z",
  "value": "0 1 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:18.772Z",
  "value": "8 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:18.772Z",
  "value": "10 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (3)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:18.772Z",
  "value": "4 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:18.772Z",
  "value": "0 2 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:18.772Z",
  "value": "9 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:18.772Z",
  "value": "11 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (3)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:18.772Z",
  "value": "6 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:18.772Z",
  "value": "0 2 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:22.183Z",
  "value": "9 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:22.183Z",
  "value": "11 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:22.183Z",
  "value": "0 2 (4) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.0.10:9153 (3)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:22.183Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:22.183Z",
  "value": "8 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:22.183Z",
  "value": "10 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:22.183Z",
  "value": "0 2 (3) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.0.10:53 (3)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:22.183Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.140.145:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:23.735Z",
  "value": "0 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.140.145:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:26.759Z",
  "value": "12 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.140.145:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:26.759Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.140.145:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:48.375Z",
  "value": "12 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.140.145:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:48.375Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.140.145:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.361Z",
  "value": "12 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.140.145:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.361Z",
  "value": "13 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.140.145:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.361Z",
  "value": "0 2 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.140.145:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.430Z",
  "value": "13 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.140.145:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.430Z",
  "value": "12 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.140.145:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.430Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.140.145:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.871Z",
  "value": "13 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.140.145:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.871Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.140.145:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.871Z",
  "value": "\u003cnil\u003e"
}

