KEY             VALUE
AgentLiveness   806720619278
UTimeOffset     3378615914062500
