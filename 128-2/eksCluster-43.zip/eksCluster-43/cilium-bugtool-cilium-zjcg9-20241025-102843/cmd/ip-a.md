1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:ae:2e:ec:fe:57 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.251.101/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2834sec preferred_lft 2834sec
    inet6 fe80::8ae:2eff:feec:fe57/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:9d:e2:ee:aa:b7 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.255.108/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::89d:e2ff:feee:aab7/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:ca:07:e2:b2:ae brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e8ca:7ff:fee2:b2ae/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:49:4c:c9:00:08 brd ff:ff:ff:ff:ff:ff
    inet 10.43.0.254/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d049:4cff:fec9:8/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 8a:8d:f3:91:8a:e1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::888d:f3ff:fe91:8ae1/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:ac:57:8e:a2:3c brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::e0ac:57ff:fe8e:a23c/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc10f61e2cdeef@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:1b:84:38:91:9e brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::5c1b:84ff:fe38:919e/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc2f8b00fac30f@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:3e:e6:e8:a3:0e brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::803e:e6ff:fee8:a30e/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcbc85d0e2e322@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:c3:35:0b:ac:76 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::2cc3:35ff:fe0b:ac76/64 scope link 
       valid_lft forever preferred_lft forever
