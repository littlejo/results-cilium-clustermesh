key: ae 00 00 00  value: 83 02 00 00
key: 3c 01 00 00  value: 4f 02 00 00
key: 32 03 00 00  value: 0e 02 00 00
key: 64 05 00 00  value: 37 02 00 00
Found 4 elements
