ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.206.52:443 (active)     
                                          2 => 172.31.137.27:443 (active)     
2    10.100.142.91:443     ClusterIP      1 => 172.31.251.101:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.43.0.247:53 (active)        
                                          2 => 10.43.0.168:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.43.0.247:9153 (active)      
                                          2 => 10.43.0.168:9153 (active)      
5    10.100.140.145:2379   ClusterIP      1 => 10.43.0.94:2379 (active)       
