KEY             VALUE
AgentLiveness   866407453796
UTimeOffset     3378615796875000
