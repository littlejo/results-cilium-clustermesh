filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcff8c7baf8805 direct-action not_in_hw id 523 tag 7285f27b75c3cf71 jited 
