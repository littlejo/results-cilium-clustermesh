CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf46211b9_af4b_4498_8143_af32472a3e36.slice/cri-containerd-8ad9ab13ae8063b1fd322c408e4074985e0e5a2df60dcf607e5fac14dd4e5b19.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf46211b9_af4b_4498_8143_af32472a3e36.slice/cri-containerd-ee75c88fc09165698f7099bddefe1e976215f4dd302b5ae72c79c50ffaf6e87d.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8ef914df_ad24_4573_81cf_d9aad1047cbe.slice/cri-containerd-d772b677a7196fbc48bdd206b2e36b64dd041984acb046fbe9928f44342f8eaf.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8ef914df_ad24_4573_81cf_d9aad1047cbe.slice/cri-containerd-2f4481d5c2ed875936ac70f851080dcf9bc4a9c946bf3259b798053628df1cb7.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod25b3942d_13ca_481c_a31b_46cfa0d98d4f.slice/cri-containerd-f8009f85f81145dda513f7100599b6ec982435d48fcfbcfbf68ac1f1f4668a86.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod25b3942d_13ca_481c_a31b_46cfa0d98d4f.slice/cri-containerd-7baf49220800751467faf50dfdfb9d6243357a3911555afa8e7eeb0879d7ff4c.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2b1dcc0a_5965_4178_8f6a_af0d2f409287.slice/cri-containerd-b98ad38e4a3a2ad241ed17b540e9b049fe71553479300cfe4694d98d42124c7f.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2b1dcc0a_5965_4178_8f6a_af0d2f409287.slice/cri-containerd-4559e62ca2c29a4ecbefba422bbd539fe25407a4526a239129161093835abd19.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8efac77f_7f67_4388_897f_73899da8dbcf.slice/cri-containerd-2940b8d14ec16d6a7c5d7f1998421245ddcf8e71f28bab7cc86f3cf9110311cc.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8efac77f_7f67_4388_897f_73899da8dbcf.slice/cri-containerd-59aadfe1d5d71d998f9349113a800e20c9a6b550d28b130cddf24839e0e57772.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8efac77f_7f67_4388_897f_73899da8dbcf.slice/cri-containerd-3523a1e6b260b73934882e4bb285208439fa09a37043273d8a5403d5cbd36590.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8efac77f_7f67_4388_897f_73899da8dbcf.slice/cri-containerd-5bee8e7a2317f731876f41abf93b8399087da059c2030f34e88840efe9285649.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0d16d5cf_d87e_4e0c_8e23_97464a0b6e75.slice/cri-containerd-a44af245e99ba2bc3dd5ffc6beb05ad1c7c007012b16ea8a04af8e0eb0527b06.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0d16d5cf_d87e_4e0c_8e23_97464a0b6e75.slice/cri-containerd-132390bda7d1630e78d2ba4c64a30c1df735cd3e759c13d78ac66b33fc2c33b3.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode8698ccd_c114_4c24_9bf8_3304e979d0c7.slice/cri-containerd-e8f2d7208d8863f7ebb38b165d2b68998709b615a6fb17ea5d0a2b7f5d30812d.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode8698ccd_c114_4c24_9bf8_3304e979d0c7.slice/cri-containerd-87f97a487ecec7a791e58a4e17745424c3a7d6871ca371375d76c8ef50c96d8f.scope
    106      cgroup_device   multi                                          
