alloc: 110.45MB (115817056 bytes)
total-alloc: 1.36GB (1462027432 bytes)
sys: 214.13MB (224535892 bytes)
lookups: 0
mallocs: 48328889
frees: 47149957
heap-alloc: 110.45MB (115817056 bytes)
heap-sys: 169.35MB (177577984 bytes)
heap-idle: 39.13MB (41033728 bytes)
heap-in-use: 130.22MB (136544256 bytes)
heap-released: 8.05MB (8445952 bytes)
heap-objects: 1178932
stack-in-use: 34.62MB (36306944 bytes)
stack-sys: 34.62MB (36306944 bytes)
stack-mspan-inuse: 2.14MB (2244800 bytes)
stack-mspan-sys: 2.40MB (2513280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 706.17KB (723121 bytes)
gc-sys: 5.16MB (5411120 bytes)
next-gc: when heap-alloc >= 147.68MB (154855064 bytes)
last-gc: 2024-10-25 10:28:44.975168896 +0000 UTC
gc-pause-total: 19.283527ms
gc-pause: 7695248
gc-pause-end: 1729852124975168896
num-gc: 71
num-forced-gc: 0
gc-cpu-fraction: 0.00041923784506724403
enable-gc: true
debug-gc: false
