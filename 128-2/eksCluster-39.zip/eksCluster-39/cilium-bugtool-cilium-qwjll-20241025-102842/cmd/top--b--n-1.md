top - 10:28:44 up 13 min,  0 users,  load average: 0.13, 0.13, 0.13
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 42.9 us, 35.7 sy,  0.0 ni, 21.4 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    779.3 free,    913.7 used,   2143.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2753.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1537844 283360  80188 S  53.3   7.2   0:19.96 cilium-+
    625 root      20   0 1240432  16604  11548 S  13.3   0.4   0:00.03 cilium-+
    399 root      20   0 1228848   5536   2868 S   0.0   0.1   0:00.25 cilium-+
    650 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    651 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    695 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    713 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
