{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:35.850Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.196.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:35.850Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.246.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:35.850Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:40.238Z",
  "value": "id=20    sec_id=2681750 flags=0x0000 ifindex=12  mac=7E:0A:44:99:B4:AC nodemac=FA:81:62:4A:F9:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:40.253Z",
  "value": "id=3540  sec_id=4     flags=0x0000 ifindex=10  mac=02:DF:5F:6A:A9:69 nodemac=EE:16:FF:27:39:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:40.259Z",
  "value": "id=20    sec_id=2681750 flags=0x0000 ifindex=12  mac=7E:0A:44:99:B4:AC nodemac=FA:81:62:4A:F9:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:40.301Z",
  "value": "id=2797  sec_id=2681750 flags=0x0000 ifindex=14  mac=3A:F2:71:53:0A:23 nodemac=92:75:FA:AB:DA:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:40.324Z",
  "value": "id=3540  sec_id=4     flags=0x0000 ifindex=10  mac=02:DF:5F:6A:A9:69 nodemac=EE:16:FF:27:39:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:54.920Z",
  "value": "id=2797  sec_id=2681750 flags=0x0000 ifindex=14  mac=3A:F2:71:53:0A:23 nodemac=92:75:FA:AB:DA:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:54.920Z",
  "value": "id=3540  sec_id=4     flags=0x0000 ifindex=10  mac=02:DF:5F:6A:A9:69 nodemac=EE:16:FF:27:39:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:54.921Z",
  "value": "id=20    sec_id=2681750 flags=0x0000 ifindex=12  mac=7E:0A:44:99:B4:AC nodemac=FA:81:62:4A:F9:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:54.948Z",
  "value": "id=806   sec_id=2668485 flags=0x0000 ifindex=16  mac=7E:0F:52:CF:0E:67 nodemac=76:D1:D3:2F:99:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:54.948Z",
  "value": "id=806   sec_id=2668485 flags=0x0000 ifindex=16  mac=7E:0F:52:CF:0E:67 nodemac=76:D1:D3:2F:99:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.920Z",
  "value": "id=3540  sec_id=4     flags=0x0000 ifindex=10  mac=02:DF:5F:6A:A9:69 nodemac=EE:16:FF:27:39:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.920Z",
  "value": "id=20    sec_id=2681750 flags=0x0000 ifindex=12  mac=7E:0A:44:99:B4:AC nodemac=FA:81:62:4A:F9:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.920Z",
  "value": "id=806   sec_id=2668485 flags=0x0000 ifindex=16  mac=7E:0F:52:CF:0E:67 nodemac=76:D1:D3:2F:99:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.920Z",
  "value": "id=2797  sec_id=2681750 flags=0x0000 ifindex=14  mac=3A:F2:71:53:0A:23 nodemac=92:75:FA:AB:DA:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:12.079Z",
  "value": "id=1573  sec_id=2668485 flags=0x0000 ifindex=18  mac=E6:2B:62:FE:9A:E2 nodemac=CA:E5:0D:0F:0C:22"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.39.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:22.272Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:51.699Z",
  "value": "id=20    sec_id=2681750 flags=0x0000 ifindex=12  mac=7E:0A:44:99:B4:AC nodemac=FA:81:62:4A:F9:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:51.699Z",
  "value": "id=2797  sec_id=2681750 flags=0x0000 ifindex=14  mac=3A:F2:71:53:0A:23 nodemac=92:75:FA:AB:DA:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:51.700Z",
  "value": "id=1573  sec_id=2668485 flags=0x0000 ifindex=18  mac=E6:2B:62:FE:9A:E2 nodemac=CA:E5:0D:0F:0C:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:51.704Z",
  "value": "id=3540  sec_id=4     flags=0x0000 ifindex=10  mac=02:DF:5F:6A:A9:69 nodemac=EE:16:FF:27:39:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:52.691Z",
  "value": "id=2797  sec_id=2681750 flags=0x0000 ifindex=14  mac=3A:F2:71:53:0A:23 nodemac=92:75:FA:AB:DA:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:52.691Z",
  "value": "id=1573  sec_id=2668485 flags=0x0000 ifindex=18  mac=E6:2B:62:FE:9A:E2 nodemac=CA:E5:0D:0F:0C:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:52.691Z",
  "value": "id=3540  sec_id=4     flags=0x0000 ifindex=10  mac=02:DF:5F:6A:A9:69 nodemac=EE:16:FF:27:39:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:52.691Z",
  "value": "id=20    sec_id=2681750 flags=0x0000 ifindex=12  mac=7E:0A:44:99:B4:AC nodemac=FA:81:62:4A:F9:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.175:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:53.691Z",
  "value": "id=20    sec_id=2681750 flags=0x0000 ifindex=12  mac=7E:0A:44:99:B4:AC nodemac=FA:81:62:4A:F9:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:53.691Z",
  "value": "id=1573  sec_id=2668485 flags=0x0000 ifindex=18  mac=E6:2B:62:FE:9A:E2 nodemac=CA:E5:0D:0F:0C:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:53.691Z",
  "value": "id=2797  sec_id=2681750 flags=0x0000 ifindex=14  mac=3A:F2:71:53:0A:23 nodemac=92:75:FA:AB:DA:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:53.691Z",
  "value": "id=3540  sec_id=4     flags=0x0000 ifindex=10  mac=02:DF:5F:6A:A9:69 nodemac=EE:16:FF:27:39:50"
}

