Endpoint ID: 20
Path: /sys/fs/bpf/tc/globals/cilium_policy_00020

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69636   797       0        
Allow    Egress      0          ANY          NONE         disabled    13382   138       0        


Endpoint ID: 1145
Path: /sys/fs/bpf/tc/globals/cilium_policy_01145

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1573
Path: /sys/fs/bpf/tc/globals/cilium_policy_01573

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3815747   36571     0        
Allow    Ingress     1          ANY          NONE         disabled    3469637   35402     0        
Allow    Egress      0          ANY          NONE         disabled    5440199   49965     0        


Endpoint ID: 2797
Path: /sys/fs/bpf/tc/globals/cilium_policy_02797

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    70230   806       0        
Allow    Egress      0          ANY          NONE         disabled    13593   141       0        


Endpoint ID: 3540
Path: /sys/fs/bpf/tc/globals/cilium_policy_03540

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    432082   5505      0        
Allow    Ingress     1          ANY          NONE         disabled    10930    129       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


