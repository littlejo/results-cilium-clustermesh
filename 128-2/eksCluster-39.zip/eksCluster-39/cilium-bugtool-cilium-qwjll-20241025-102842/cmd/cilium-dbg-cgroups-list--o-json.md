[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod25b3942d_13ca_481c_a31b_46cfa0d98d4f.slice/cri-containerd-7baf49220800751467faf50dfdfb9d6243357a3911555afa8e7eeb0879d7ff4c.scope"
      }
    ],
    "ips": [
      "10.39.0.175"
    ],
    "name": "coredns-cc6ccd49c-6rrvh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8efac77f_7f67_4388_897f_73899da8dbcf.slice/cri-containerd-5bee8e7a2317f731876f41abf93b8399087da059c2030f34e88840efe9285649.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8efac77f_7f67_4388_897f_73899da8dbcf.slice/cri-containerd-59aadfe1d5d71d998f9349113a800e20c9a6b550d28b130cddf24839e0e57772.scope"
      },
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8efac77f_7f67_4388_897f_73899da8dbcf.slice/cri-containerd-2940b8d14ec16d6a7c5d7f1998421245ddcf8e71f28bab7cc86f3cf9110311cc.scope"
      }
    ],
    "ips": [
      "10.39.0.246"
    ],
    "name": "clustermesh-apiserver-947b46b-6bnkd",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8ef914df_ad24_4573_81cf_d9aad1047cbe.slice/cri-containerd-d772b677a7196fbc48bdd206b2e36b64dd041984acb046fbe9928f44342f8eaf.scope"
      }
    ],
    "ips": [
      "10.39.0.151"
    ],
    "name": "coredns-cc6ccd49c-j2vbm",
    "namespace": "kube-system"
  }
]

