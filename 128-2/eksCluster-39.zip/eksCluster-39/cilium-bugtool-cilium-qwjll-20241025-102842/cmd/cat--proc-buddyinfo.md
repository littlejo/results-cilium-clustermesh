Node 0, zone      DMA      3      1      2      1     16     11      5      4      4      5    161 
Node 0, zone   Normal     77     34     35     11      6      3     13      3      3      2      7 
