REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10091     790823     677    bpf_overlay.c
Interface                 INGRESS     226648    86184370   1132   bpf_host.c
Success                   EGRESS      10334     808075     53     encap.h
Success                   EGRESS      5255      404289     1694   bpf_host.c
Success                   EGRESS      97922     12721807   1308   bpf_lxc.c
Success                   INGRESS     108583    13434387   86     l3.h
Success                   INGRESS     114068    13864827   235    trace.h
Unsupported L3 protocol   EGRESS      39        2942       1492   bpf_lxc.c
