REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     216385    84723600   1132   bpf_host.c
Interface                 INGRESS     9614      749521     677    bpf_overlay.c
Success                   EGRESS      4704      358057     1694   bpf_host.c
Success                   EGRESS      90776     12183347   1308   bpf_lxc.c
Success                   EGRESS      9499      740597     53     encap.h
Success                   INGRESS     102081    12507926   86     l3.h
Success                   INGRESS     107640    12943296   235    trace.h
Unsupported L3 protocol   EGRESS      38        2852       1492   bpf_lxc.c
