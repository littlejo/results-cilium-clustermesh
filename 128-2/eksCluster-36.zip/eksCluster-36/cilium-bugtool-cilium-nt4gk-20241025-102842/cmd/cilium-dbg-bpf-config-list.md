KEY             VALUE
AgentLiveness   884000106036
UTimeOffset     3378615761718750
