{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:18.413Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.129.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:18.413Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.142.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:18.413Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:23.304Z",
  "value": "id=1192  sec_id=4     flags=0x0000 ifindex=10  mac=2E:CD:34:40:F8:52 nodemac=7A:9F:52:D0:28:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:23.307Z",
  "value": "id=85    sec_id=2448634 flags=0x0000 ifindex=12  mac=92:D6:12:DA:AC:D4 nodemac=06:D6:05:66:AB:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:23.359Z",
  "value": "id=1192  sec_id=4     flags=0x0000 ifindex=10  mac=2E:CD:34:40:F8:52 nodemac=7A:9F:52:D0:28:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:23.360Z",
  "value": "id=85    sec_id=2448634 flags=0x0000 ifindex=12  mac=92:D6:12:DA:AC:D4 nodemac=06:D6:05:66:AB:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:23.364Z",
  "value": "id=213   sec_id=2448634 flags=0x0000 ifindex=14  mac=4A:83:82:B7:BF:DE nodemac=66:CD:C7:3E:99:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.749Z",
  "value": "id=1192  sec_id=4     flags=0x0000 ifindex=10  mac=2E:CD:34:40:F8:52 nodemac=7A:9F:52:D0:28:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.750Z",
  "value": "id=85    sec_id=2448634 flags=0x0000 ifindex=12  mac=92:D6:12:DA:AC:D4 nodemac=06:D6:05:66:AB:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.750Z",
  "value": "id=213   sec_id=2448634 flags=0x0000 ifindex=14  mac=4A:83:82:B7:BF:DE nodemac=66:CD:C7:3E:99:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.782Z",
  "value": "id=438   sec_id=2473754 flags=0x0000 ifindex=16  mac=06:F2:6E:A1:4B:08 nodemac=9A:25:A6:A9:08:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:47.749Z",
  "value": "id=85    sec_id=2448634 flags=0x0000 ifindex=12  mac=92:D6:12:DA:AC:D4 nodemac=06:D6:05:66:AB:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:47.750Z",
  "value": "id=213   sec_id=2448634 flags=0x0000 ifindex=14  mac=4A:83:82:B7:BF:DE nodemac=66:CD:C7:3E:99:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:47.750Z",
  "value": "id=1192  sec_id=4     flags=0x0000 ifindex=10  mac=2E:CD:34:40:F8:52 nodemac=7A:9F:52:D0:28:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:47.750Z",
  "value": "id=438   sec_id=2473754 flags=0x0000 ifindex=16  mac=06:F2:6E:A1:4B:08 nodemac=9A:25:A6:A9:08:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:16.733Z",
  "value": "id=393   sec_id=2473754 flags=0x0000 ifindex=18  mac=32:09:32:3E:76:17 nodemac=72:80:36:D4:7B:2D"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.36.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:21.824Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:59.840Z",
  "value": "id=393   sec_id=2473754 flags=0x0000 ifindex=18  mac=32:09:32:3E:76:17 nodemac=72:80:36:D4:7B:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:59.841Z",
  "value": "id=213   sec_id=2448634 flags=0x0000 ifindex=14  mac=4A:83:82:B7:BF:DE nodemac=66:CD:C7:3E:99:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:59.841Z",
  "value": "id=85    sec_id=2448634 flags=0x0000 ifindex=12  mac=92:D6:12:DA:AC:D4 nodemac=06:D6:05:66:AB:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:59.841Z",
  "value": "id=1192  sec_id=4     flags=0x0000 ifindex=10  mac=2E:CD:34:40:F8:52 nodemac=7A:9F:52:D0:28:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:00.840Z",
  "value": "id=213   sec_id=2448634 flags=0x0000 ifindex=14  mac=4A:83:82:B7:BF:DE nodemac=66:CD:C7:3E:99:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:00.840Z",
  "value": "id=393   sec_id=2473754 flags=0x0000 ifindex=18  mac=32:09:32:3E:76:17 nodemac=72:80:36:D4:7B:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:00.840Z",
  "value": "id=1192  sec_id=4     flags=0x0000 ifindex=10  mac=2E:CD:34:40:F8:52 nodemac=7A:9F:52:D0:28:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:00.840Z",
  "value": "id=85    sec_id=2448634 flags=0x0000 ifindex=12  mac=92:D6:12:DA:AC:D4 nodemac=06:D6:05:66:AB:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:01.840Z",
  "value": "id=85    sec_id=2448634 flags=0x0000 ifindex=12  mac=92:D6:12:DA:AC:D4 nodemac=06:D6:05:66:AB:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:01.840Z",
  "value": "id=1192  sec_id=4     flags=0x0000 ifindex=10  mac=2E:CD:34:40:F8:52 nodemac=7A:9F:52:D0:28:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:01.840Z",
  "value": "id=213   sec_id=2448634 flags=0x0000 ifindex=14  mac=4A:83:82:B7:BF:DE nodemac=66:CD:C7:3E:99:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:01.840Z",
  "value": "id=393   sec_id=2473754 flags=0x0000 ifindex=18  mac=32:09:32:3E:76:17 nodemac=72:80:36:D4:7B:2D"
}

