markdown output at /tmp/cilium-bugtool-20241025-102843.694+0000-UTC-3526882337/cmd/cilium-debuginfo-20241025-102914.236+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102843.694+0000-UTC-3526882337/cmd/cilium-debuginfo-20241025-102914.236+0000-UTC.json
