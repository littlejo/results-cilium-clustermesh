ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.211.66:443 (active)    
                                         2 => 172.31.177.173:443 (active)   
2    10.100.165.101:443   ClusterIP      1 => 172.31.142.96:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.36.0.153:9153 (active)     
                                         2 => 10.36.0.114:9153 (active)     
4    10.100.0.10:53       ClusterIP      1 => 10.36.0.153:53 (active)       
                                         2 => 10.36.0.114:53 (active)       
5    10.100.64.100:2379   ClusterIP      1 => 10.36.0.138:2379 (active)     
