# Cilium debug information

#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 33859440                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 33859440                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 33859440                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d000000 rw-p 00000000 00:00 0 
400d000000-4010000000 ---p 00000000 00:00 0 
ffff76985000-ffff76b6b000 rw-p 00000000 00:00 0 
ffff76b73000-ffff76c94000 rw-p 00000000 00:00 0 
ffff76c94000-ffff76cd5000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff76cd5000-ffff76d16000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff76d16000-ffff76d18000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff76d18000-ffff76d1a000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff76d1a000-ffff772c1000 rw-p 00000000 00:00 0 
ffff772c1000-ffff773c1000 rw-p 00000000 00:00 0 
ffff773c1000-ffff773d2000 rw-p 00000000 00:00 0 
ffff773d2000-ffff793d2000 rw-p 00000000 00:00 0 
ffff793d2000-ffff79452000 ---p 00000000 00:00 0 
ffff79452000-ffff79453000 rw-p 00000000 00:00 0 
ffff79453000-ffff99452000 ---p 00000000 00:00 0 
ffff99452000-ffff99453000 rw-p 00000000 00:00 0 
ffff99453000-ffffb93e2000 ---p 00000000 00:00 0 
ffffb93e2000-ffffb93e3000 rw-p 00000000 00:00 0 
ffffb93e3000-ffffbd3d4000 ---p 00000000 00:00 0 
ffffbd3d4000-ffffbd3d5000 rw-p 00000000 00:00 0 
ffffbd3d5000-ffffbdbd2000 ---p 00000000 00:00 0 
ffffbdbd2000-ffffbdbd3000 rw-p 00000000 00:00 0 
ffffbdbd3000-ffffbdcd2000 ---p 00000000 00:00 0 
ffffbdcd2000-ffffbdd32000 rw-p 00000000 00:00 0 
ffffbdd32000-ffffbdd34000 r--p 00000000 00:00 0                          [vvar]
ffffbdd34000-ffffbdd35000 r-xp 00000000 00:00 0                          [vdso]
ffffcf6b6000-ffffcf6d7000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.36.0.0/24, 
Allocated addresses:
  10.36.0.114 (kube-system/coredns-cc6ccd49c-lj52n)
  10.36.0.138 (kube-system/clustermesh-apiserver-65d76cbf76-jns9h)
  10.36.0.153 (kube-system/coredns-cc6ccd49c-gdxzd)
  10.36.0.163 (health)
  10.36.0.35 (router)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e00e71aaddcc7268
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    53s ago        never        0       no error   
  ct-map-pressure                                                     25s ago        never        0       no error   
  daemon-validate-config                                              43s ago        never        0       no error   
  dns-garbage-collector-job                                           58s ago        never        0       no error   
  endpoint-1192-regeneration-recovery                                 never          never        0       no error   
  endpoint-213-regeneration-recovery                                  never          never        0       no error   
  endpoint-393-regeneration-recovery                                  never          never        0       no error   
  endpoint-491-regeneration-recovery                                  never          never        0       no error   
  endpoint-85-regeneration-recovery                                   never          never        0       no error   
  endpoint-gc                                                         2m58s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                25s ago        never        0       no error   
  ipcache-inject-labels                                               55s ago        never        0       no error   
  k8s-heartbeat                                                       28s ago        never        0       no error   
  link-cache                                                          10s ago        never        0       no error   
  local-identity-checkpoint                                           12m55s ago     never        0       no error   
  node-neighbor-link-updater                                          5s ago         never        0       no error   
  remote-etcd-cmesh1                                                  6m14s ago      never        0       no error   
  remote-etcd-cmesh10                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh100                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh101                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh102                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh103                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh104                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh105                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh106                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh107                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh108                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh109                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh11                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh110                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh111                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh112                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh113                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh114                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh115                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh116                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh117                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh118                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh119                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh12                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh120                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh121                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh122                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh123                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh124                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh125                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh126                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh127                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh128                                                6m14s ago      never        0       no error   
  remote-etcd-cmesh13                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh14                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh15                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh16                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh17                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh18                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh19                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh2                                                  6m14s ago      never        0       no error   
  remote-etcd-cmesh20                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh21                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh22                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh23                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh24                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh25                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh26                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh27                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh28                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh29                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh3                                                  6m14s ago      never        0       no error   
  remote-etcd-cmesh30                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh31                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh32                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh33                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh34                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh35                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh36                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh38                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh39                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh4                                                  6m14s ago      never        0       no error   
  remote-etcd-cmesh40                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh41                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh42                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh43                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh44                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh45                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh46                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh47                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh48                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh49                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh5                                                  6m14s ago      never        0       no error   
  remote-etcd-cmesh50                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh51                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh52                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh53                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh54                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh55                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh56                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh57                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh58                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh59                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh6                                                  6m14s ago      never        0       no error   
  remote-etcd-cmesh60                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh61                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh62                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh63                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh64                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh65                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh66                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh67                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh68                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh69                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh7                                                  6m14s ago      never        0       no error   
  remote-etcd-cmesh70                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh71                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh72                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh73                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh74                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh75                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh76                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh77                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh78                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh79                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh8                                                  6m14s ago      never        0       no error   
  remote-etcd-cmesh80                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh81                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh82                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh83                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh84                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh85                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh86                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh87                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh88                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh89                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh9                                                  6m14s ago      never        0       no error   
  remote-etcd-cmesh90                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh91                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh92                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh93                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh94                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh95                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh96                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh97                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh98                                                 6m14s ago      never        0       no error   
  remote-etcd-cmesh99                                                 6m14s ago      never        0       no error   
  resolve-identity-1192                                               2m54s ago      never        0       no error   
  resolve-identity-213                                                2m52s ago      never        0       no error   
  resolve-identity-393                                                1m57s ago      never        0       no error   
  resolve-identity-491                                                2m55s ago      never        0       no error   
  resolve-identity-85                                                 2m53s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-65d76cbf76-jns9h   6m57s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-gdxzd                  12m53s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-lj52n                  12m52s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      12m55s ago     never        0       no error   
  sync-policymap-1192                                                 12m50s ago     never        0       no error   
  sync-policymap-213                                                  12m50s ago     never        0       no error   
  sync-policymap-393                                                  6m57s ago      never        0       no error   
  sync-policymap-491                                                  12m54s ago     never        0       no error   
  sync-policymap-85                                                   12m50s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (213)                                    2s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (393)                                    7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (85)                                     2s ago         never        0       no error   
  sync-utime                                                          55s ago        never        0       no error   
  write-cni-file                                                      12m58s ago     never        0       no error   
Proxy Status:            OK, ip 10.36.0.35, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 2424832, max 2490367
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 79.86   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.36.0.35": (string) (len=6) "router",
  (string) (len=11) "10.36.0.163": (string) (len=6) "health",
  (string) (len=11) "10.36.0.153": (string) (len=35) "kube-system/coredns-cc6ccd49c-gdxzd",
  (string) (len=11) "10.36.0.114": (string) (len=35) "kube-system/coredns-cc6ccd49c-lj52n",
  (string) (len=11) "10.36.0.138": (string) (len=50) "kube-system/clustermesh-apiserver-65d76cbf76-jns9h"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.142.96": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001bc0630)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001233d40,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001233d40,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4000b66630)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4000b666e0)(frontends:[10.100.165.101]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4000b66840)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4001464840)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4000dbef20)(frontends:[10.100.64.100]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x40017847b8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40025864e0)(172.31.177.173:443/TCP,172.31.211.66:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x40017847c0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-nbdfz": (*k8s.Endpoints)(0x400270ac30)(172.31.142.96:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x40017847c8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-zp2dp": (*k8s.Endpoints)(0x40036cbad0)(10.36.0.114:53/TCP[eu-west-3a],10.36.0.114:53/UDP[eu-west-3a],10.36.0.114:9153/TCP[eu-west-3a],10.36.0.153:53/TCP[eu-west-3a],10.36.0.153:53/UDP[eu-west-3a],10.36.0.153:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001701458)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-mcrcb": (*k8s.Endpoints)(0x4002f00f70)(10.36.0.138:2379/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4002276000)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x400278a870)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400a720930
  },
  gcTrigger: (chan struct {}) (cap=1) 0x400278d4a0,
  gcExited: (chan struct {}) 0x400278d500,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4002267980)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001784ec0)({
      MetricVec: (*prometheus.MetricVec)(0x40008744b0)({
       metricMap: (*prometheus.metricMap)(0x4000874db0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002421f20)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4002267a00)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001784ec8)({
      MetricVec: (*prometheus.MetricVec)(0x4000874e40)({
       metricMap: (*prometheus.metricMap)(0x4000874e70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40023750e0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4002267a80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001784ed0)({
      MetricVec: (*prometheus.MetricVec)(0x4000874ed0)({
       metricMap: (*prometheus.metricMap)(0x4000874f00)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002375140)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4002267b00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001784ed8)({
      MetricVec: (*prometheus.MetricVec)(0x4000874f90)({
       metricMap: (*prometheus.metricMap)(0x4000874ff0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40023751a0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4002267b80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001784ee0)({
      MetricVec: (*prometheus.MetricVec)(0x4000875050)({
       metricMap: (*prometheus.metricMap)(0x4000875080)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002375200)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4002267c00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001784ee8)({
      MetricVec: (*prometheus.MetricVec)(0x40008750e0)({
       metricMap: (*prometheus.metricMap)(0x4000875110)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002375260)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4002267c80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001784ef0)({
      MetricVec: (*prometheus.MetricVec)(0x4000875170)({
       metricMap: (*prometheus.metricMap)(0x40008751a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40023752c0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4002267d00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001784ef8)({
      MetricVec: (*prometheus.MetricVec)(0x4000875260)({
       metricMap: (*prometheus.metricMap)(0x40008752c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002375320)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4002267d80)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001784f00)({
      MetricVec: (*prometheus.MetricVec)(0x4000875320)({
       metricMap: (*prometheus.metricMap)(0x4000875350)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002375380)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4002276000)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40023773b0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x40017be3f0)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 386ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption



#### Cilium environment keys

```
enable-k8s-networkpolicy:true
dns-policy-unload-on-shutdown:false
tofqdns-proxy-port:0
proxy-portrange-max:20000
hubble-recorder-sink-queue-size:1024
tofqdns-pre-cache:
local-router-ipv4:
gateway-api-secrets-namespace:
bypass-ip-availability-upon-restore:false
agent-labels:
bpf-lb-map-max:65536
proxy-xff-num-trusted-hops-ingress:0
enable-ipv6-big-tcp:false
trace-sock:true
restore:true
ipam-multi-pool-pre-allocation:
clustermesh-sync-timeout:1m0s
bpf-lb-source-range-map-max:0
enable-wireguard:false
hubble-event-queue-size:0
enable-service-topology:false
proxy-max-connection-duration-seconds:0
hubble-monitor-events:
enable-host-legacy-routing:false
bpf-events-policy-verdict-enabled:true
enable-l7-proxy:true
enable-ingress-controller:false
bpf-lb-rss-ipv4-src-cidr:
bpf-policy-map-max:16384
devices:
enable-cilium-api-server-access:
http-request-timeout:3600
bgp-config-path:/var/lib/cilium/bgp/config.yaml
monitor-aggregation-flags:all
bpf-lb-sock:false
enable-session-affinity:false
envoy-config-retry-interval:15s
agent-health-port:9879
metrics:
identity-gc-interval:15m0s
enable-node-port:false
nat-map-stats-entries:32
bpf-fragments-map-max:8192
debug-verbose:
join-cluster:false
policy-accounting:true
bpf-lb-rev-nat-map-max:0
clustermesh-ip-identities-sync-timeout:1m0s
bpf-lb-mode:snat
fixed-identity-mapping:
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
egress-gateway-reconciliation-trigger-interval:1s
force-device-detection:false
bpf-lb-maglev-table-size:16381
ipv6-node:auto
cilium-endpoint-gc-interval:5m0s
dnsproxy-concurrency-limit:0
annotate-k8s-node:false
enable-pmtu-discovery:false
preallocate-bpf-maps:false
enable-ipv4-masquerade:true
endpoint-bpf-prog-watchdog-interval:30s
envoy-keep-cap-netbindservice:false
pprof-address:localhost
tofqdns-enable-dns-compression:true
bpf-ct-global-any-max:262144
enable-active-connection-tracking:false
cni-external-routing:false
encrypt-node:false
operator-api-serve-addr:127.0.0.1:9234
enable-tracing:false
http-max-grpc-timeout:0
enable-endpoint-health-checking:true
envoy-secrets-namespace:
ipv6-service-range:auto
version:false
exclude-local-address:
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
k8s-require-ipv6-pod-cidr:false
static-cnp-path:
tofqdns-max-deferred-connection-deletes:10000
cmdref:
mesh-auth-rotated-identities-queue-size:1024
route-metric:0
node-port-acceleration:disabled
direct-routing-skip-unreachable:false
enable-bpf-masquerade:false
enable-ipv6:false
controller-group-metrics:
enable-health-checking:true
state-dir:/var/run/cilium
socket-path:/var/run/cilium/cilium.sock
mke-cgroup-mount:
hubble-redact-http-urlquery:false
node-port-mode:snat
enable-ipsec-xfrm-state-caching:true
enable-mke:false
enable-icmp-rules:true
enable-ipv4-egress-gateway:false
enable-custom-calls:false
node-labels:
bpf-ct-timeout-service-tcp:2h13m20s
l2-announcements-retry-period:2s
enable-local-node-route:true
config-sources:config-map:kube-system/cilium-config
proxy-xff-num-trusted-hops-egress:0
encryption-strict-mode-cidr:
hubble-redact-http-headers-deny:
ipv6-pod-subnets:
synchronize-k8s-nodes:true
hubble-redact-enabled:false
tofqdns-dns-reject-response-code:refused
enable-policy:default
node-port-algorithm:random
bpf-ct-timeout-service-any:1m0s
ipv4-node:auto
ingress-secrets-namespace:
trace-payloadlen:128
bpf-map-event-buffers:
k8s-service-proxy-name:
bpf-lb-service-backend-map-max:0
bpf-lb-affinity-map-max:0
max-internal-timer-delay:0s
remove-cilium-node-taints:true
log-system-load:false
identity-restore-grace-period:30s
auto-create-cilium-node-resource:true
enable-bpf-clock-probe:false
encryption-strict-mode-allow-remote-node-identities:false
bpf-ct-timeout-regular-any:1m0s
enable-l2-neigh-discovery:true
direct-routing-device:
enable-ip-masq-agent:false
ipam-cilium-node-update-rate:15s
allow-icmp-frag-needed:true
l2-announcements-renew-deadline:5s
enable-ipv6-masquerade:true
enable-vtep:false
procfs:/host/proc
vtep-mask:
unmanaged-pod-watcher-interval:15
ipsec-key-rotation-duration:5m0s
max-connected-clusters:255
ipv4-service-range:auto
mesh-auth-spire-admin-socket:
conntrack-gc-max-interval:0s
tunnel-protocol:vxlan
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
ipv6-mcast-device:
proxy-admin-port:0
kvstore-lease-ttl:15m0s
enable-external-ips:false
external-envoy-proxy:true
wireguard-persistent-keepalive:0s
keep-config:false
vlan-bpf-bypass:
bpf-lb-dsr-l4-xlate:frontend
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
custom-cni-conf:false
tofqdns-idle-connection-grace-period:0s
enable-endpoint-routes:false
cluster-name:cmesh37
enable-health-check-nodeport:true
identity-allocation-mode:crd
fqdn-regex-compile-lru-size:1024
hubble-export-allowlist:
k8s-require-ipv4-pod-cidr:false
k8s-kubeconfig-path:
enable-node-selector-labels:false
vtep-cidr:
read-cni-conf:
routing-mode:tunnel
ip-masq-agent-config-path:/etc/config/ip-masq-agent
kvstore-opt:
vtep-endpoint:
cluster-pool-ipv4-mask-size:24
enable-wireguard-userspace-fallback:false
ipv4-range:auto
srv6-encap-mode:reduced
bpf-events-trace-enabled:true
bpf-lb-sock-terminate-pod-connections:false
operator-prometheus-serve-addr::9963
bpf-map-dynamic-size-ratio:0.0025
hubble-export-fieldmask:
bpf-ct-timeout-regular-tcp-fin:10s
service-no-backend-response:reject
enable-k8s-terminating-endpoint:true
hubble-flowlogs-config-path:
config-dir:/tmp/cilium/config-map
clustermesh-enable-endpoint-sync:false
proxy-max-requests-per-connection:0
kvstore-connectivity-timeout:2m0s
hubble-redact-http-userinfo:true
use-cilium-internal-ip-for-ipsec:false
enable-bpf-tproxy:false
agent-liveness-update-interval:1s
api-rate-limit:
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
enable-health-check-loadbalancer-ip:false
cluster-health-port:4240
enable-encryption-strict-mode:false
enable-k8s-endpoint-slice:true
local-router-ipv6:
clustermesh-config:/var/lib/cilium/clustermesh/
allow-localhost:auto
iptables-lock-timeout:5s
encrypt-interface:
proxy-connect-timeout:2
log-opt:
monitor-queue-size:0
enable-stale-cilium-endpoint-cleanup:true
k8s-client-burst:20
cluster-id:37
monitor-aggregation:medium
nodeport-addresses:
tunnel-port:0
kvstore-periodic-sync:5m0s
proxy-gid:1337
auto-direct-node-routes:false
policy-cidr-match-mode:
enable-ipv6-ndp:false
bpf-lb-rss-ipv6-src-cidr:
enable-gateway-api:false
kube-proxy-replacement-healthz-bind-address:
http-retry-timeout:0
enable-hubble-recorder-api:true
derive-masq-ip-addr-from-device:
disable-endpoint-crd:false
l2-announcements-lease-duration:15s
enable-envoy-config:false
debug:false
dns-max-ips-per-restored-rule:1000
http-idle-timeout:0
hubble-redact-kafka-apikey:false
bpf-ct-timeout-regular-tcp:2h13m20s
enable-host-firewall:false
proxy-prometheus-port:0
install-no-conntrack-iptables-rules:false
bpf-sock-rev-map-max:262144
bpf-events-drop-enabled:true
enable-bgp-control-plane:false
enable-cilium-endpoint-slice:false
cgroup-root:/run/cilium/cgroupv2
bgp-announce-pod-cidr:false
pprof-port:6060
clustermesh-enable-mcs-api:false
tofqdns-min-ttl:0
ipv4-native-routing-cidr:
enable-hubble:true
iptables-random-fully:false
prepend-iptables-chains:true
l2-pod-announcements-interface:
enable-ipv4-big-tcp:false
identity-heartbeat-timeout:30m0s
cni-chaining-target:
k8s-client-qps:10
http-retry-count:3
nodes-gc-interval:5m0s
bpf-nat-global-max:524288
ipv6-range:auto
enable-recorder:false
enable-host-port:false
enable-unreachable-routes:false
enable-xdp-prefilter:false
http-normalize-path:true
dnsproxy-lock-count:131
bpf-ct-timeout-service-tcp-grace:1m0s
hubble-export-denylist:
policy-trigger-interval:1s
enable-ipip-termination:false
proxy-idle-timeout-seconds:60
bpf-ct-timeout-regular-tcp-syn:1m0s
conntrack-gc-interval:0s
enable-identity-mark:true
enable-masquerade-to-route-source:false
pprof:false
enable-nat46x64-gateway:false
dnsproxy-enable-transparent-mode:true
enable-bandwidth-manager:false
tofqdns-proxy-response-max-delay:100ms
bpf-lb-service-map-max:0
envoy-log:
hubble-drop-events-interval:2m0s
enable-cilium-health-api-server-access:
hubble-export-file-max-size-mb:10
log-driver:
dnsproxy-socket-linger-timeout:10
ipv6-cluster-alloc-cidr:f00d::/64
mesh-auth-queue-size:1024
bpf-ct-global-tcp-max:524288
node-port-bind-protection:true
mesh-auth-gc-interval:5m0s
crd-wait-timeout:5m0s
ipsec-key-file:
mesh-auth-spiffe-trust-domain:spiffe.cilium
disable-external-ip-mitigation:false
exclude-node-label-patterns:
hubble-disable-tls:false
bpf-lb-external-clusterip:false
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
tofqdns-endpoint-max-ip-per-hostname:50
vtep-mac:
enable-svc-source-range-check:true
hubble-export-file-path:
k8s-api-server:
hubble-listen-address::4244
enable-tcx:true
disable-iptables-feeder-rules:
k8s-namespace:kube-system
enable-k8s:true
cni-log-file:/var/run/cilium/cilium-cni.log
policy-audit-mode:false
hubble-socket-path:/var/run/cilium/hubble.sock
k8s-client-connection-keep-alive:30s
enable-ipsec-encrypted-overlay:false
disable-envoy-version-check:false
node-port-range:
ipv4-pod-subnets:
hubble-export-file-compress:false
enable-local-redirect-policy:false
enable-route-mtu-for-cni-chaining:false
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
bpf-lb-maglev-map-max:0
gops-port:9890
bpf-lb-dsr-dispatch:opt
egress-gateway-policy-map-max:16384
bpf-lb-sock-hostns-only:false
install-iptables-rules:true
enable-bbr:false
enable-well-known-identities:false
datapath-mode:veth
mtu:0
enable-l2-announcements:false
hubble-metrics-server:
hubble-metrics:
proxy-portrange-min:10000
k8s-client-connection-timeout:30s
cflags:
bpf-neigh-global-max:524288
enable-srv6:false
monitor-aggregation-interval:5s
bpf-auth-map-max:524288
hubble-skip-unknown-cgroup-ids:true
cni-exclusive:true
set-cilium-node-taints:true
container-ip-local-reserved-ports:auto
nat-map-stats-interval:30s
k8s-heartbeat-timeout:30s
hubble-redact-http-headers-allow:
hubble-drop-events-reasons:auth_required,policy_denied
enable-l2-pod-announcements:false
egress-masquerade-interfaces:ens+
k8s-sync-timeout:3m0s
mesh-auth-mutual-listener-port:0
label-prefix-file:
ipam:cluster-pool
hubble-event-buffer-capacity:4095
ipv6-native-routing-cidr:
multicast-enabled:false
mesh-auth-signal-backoff-duration:1s
labels:
k8s-service-cache-size:128
allocator-list-timeout:3m0s
enable-high-scale-ipcache:false
cluster-pool-ipv4-cidr:10.36.0.0/16
policy-queue-size:100
enable-ipsec:false
enable-ipv4-fragment-tracking:true
local-max-addr-scope:252
kvstore:
config:
bpf-filter-priority:1
ipv4-service-loopback-address:169.254.42.1
hubble-prefer-ipv6:false
endpoint-queue-size:25
lib-dir:/var/lib/cilium
cni-chaining-mode:none
bpf-root:/sys/fs/bpf
use-full-tls-context:false
hubble-export-file-max-backups:5
endpoint-gc-interval:5m0s
enable-monitor:true
enable-ipv4:true
enable-ipsec-key-watcher:true
enable-xt-socket-fallback:true
enable-auto-protect-node-port-range:true
enable-runtime-device-detection:true
kube-proxy-replacement:false
certificates-directory:/var/run/cilium/certs
set-cilium-is-up-condition:true
max-controller-interval:0
envoy-base-id:0
bpf-lb-algorithm:random
envoy-config-timeout:2m0s
dnsproxy-insecure-skip-transparent-mode-check:false
prometheus-serve-addr:
hubble-recorder-storage-path:/var/run/cilium/pcaps
mesh-auth-enabled:true
bpf-lb-acceleration:disabled
bpf-policy-map-full-reconciliation-interval:15m0s
enable-metrics:true
enable-k8s-api-discovery:false
bpf-node-map-max:16384
kvstore-max-consecutive-quorum-errors:2
enable-sctp:false
dnsproxy-lock-timeout:500ms
mesh-auth-mutual-connect-timeout:5s
egress-multi-home-ip-rule-compat:false
ipam-default-ip-pool:default
hubble-drop-events:false
arping-refresh-period:30s
bgp-announce-lb-ip:false
identity-change-grace-period:5s
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
dnsproxy-concurrency-processing-grace-period:0s
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
85         Disabled           Disabled          2448634    k8s:eks.amazonaws.com/component=coredns                                             10.36.0.153   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh37                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
213        Disabled           Disabled          2448634    k8s:eks.amazonaws.com/component=coredns                                             10.36.0.114   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh37                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
393        Disabled           Disabled          2473754    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.36.0.138   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh37                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
491        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                
                                                           reserved:host                                                                                             
1192       Disabled           Disabled          4          reserved:health                                                                     10.36.0.163   ready   
```

#### BPF Policy Get 85

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    72944   840       0        
Allow    Egress      0          ANY          NONE         disabled    12654   128       0        

```


#### BPF CT List 85

```
Invalid argument: unknown type 85
```


#### Endpoint Get 85

```
[
  {
    "id": 85,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-85-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "239f37d3-257c-4f38-800a-72406eedc853"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-85",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:21.237Z",
            "success-count": 3
          },
          "uuid": "3981205d-8e93-407c-9168-97de99dde7e9"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-gdxzd",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:21.235Z",
            "success-count": 1
          },
          "uuid": "4a19902f-94eb-47fe-8f76-bd5d2d2c1d10"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-85",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:23.313Z",
            "success-count": 1
          },
          "uuid": "15a83f5a-3f82-45a2-965f-068fb959097e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (85)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:11.301Z",
            "success-count": 79
          },
          "uuid": "afb00c12-ef71-49f1-9a39-38736f72c209"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "af65d8543d633d4836aa4f727ff709254ae0794707c7d615899f6d6e503d5645:eth0",
        "container-id": "af65d8543d633d4836aa4f727ff709254ae0794707c7d615899f6d6e503d5645",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-gdxzd",
        "pod-name": "kube-system/coredns-cc6ccd49c-gdxzd"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2448634,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh37",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh37",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:01Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.36.0.153",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "06:d6:05:66:ab:c3",
        "interface-index": 12,
        "interface-name": "lxc3c072016f17c",
        "mac": "92:d6:12:da:ac:d4"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2448634,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2448634,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 85

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 85

```
Timestamp              Status   State                   Message
2024-10-25T10:23:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:01Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:47Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:46Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:23Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:16:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:22Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:16:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:16:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:16:21Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:16:21Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2448634

```
ID        LABELS
2448634   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh37
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 213

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    72482   833       0        
Allow    Egress      0          ANY          NONE         disabled    13459   139       0        

```


#### BPF CT List 213

```
Invalid argument: unknown type 213
```


#### Endpoint Get 213

```
[
  {
    "id": 213,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-213-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f9f6043e-bcb5-473e-a233-d90df7c53c79"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-213",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:21.326Z",
            "success-count": 3
          },
          "uuid": "4f286c11-6ee2-4200-a446-9b2aadab5144"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-lj52n",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:21.324Z",
            "success-count": 1
          },
          "uuid": "9cd47a8c-8676-4c6a-9513-2752d566bc08"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-213",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:23.365Z",
            "success-count": 1
          },
          "uuid": "7c0e775a-b539-448d-a632-c9dd42d4ebcc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (213)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:11.391Z",
            "success-count": 79
          },
          "uuid": "762c6451-2531-4b9d-a668-09243f67b958"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "726c85339dfa3b8ed347fa08cc5991f5a1013c7394052119418b3bff573ff6ee:eth0",
        "container-id": "726c85339dfa3b8ed347fa08cc5991f5a1013c7394052119418b3bff573ff6ee",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-lj52n",
        "pod-name": "kube-system/coredns-cc6ccd49c-lj52n"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2448634,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh37",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh37",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:01Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.36.0.114",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "66:cd:c7:3e:99:e6",
        "interface-index": 14,
        "interface-name": "lxc64a26b290c9f",
        "mac": "4a:83:82:b7:bf:de"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2448634,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2448634,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 213

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 213

```
Timestamp              Status   State                   Message
2024-10-25T10:23:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:01Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:47Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:46Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:16:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:23Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:16:22Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:16:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:16:21Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:16:21Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2448634

```
ID        LABELS
2448634   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh37
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 393

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3875045   36296     0        
Allow    Ingress     1          ANY          NONE         disabled    3045801   30826     0        
Allow    Egress      0          ANY          NONE         disabled    4421729   40812     0        

```


#### BPF CT List 393

```
Invalid argument: unknown type 393
```


#### Endpoint Get 393

```
[
  {
    "id": 393,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-393-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "31062cb0-63a4-46a1-a26f-081509a55b27"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-393",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:16.697Z",
            "success-count": 2
          },
          "uuid": "71a759ab-b3cd-48f2-93d7-128a0c340706"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-65d76cbf76-jns9h",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:16.695Z",
            "success-count": 1
          },
          "uuid": "56daf6a0-ac41-456f-b880-dc093c9abb19"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-393",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:16.734Z",
            "success-count": 1
          },
          "uuid": "37b6c0cc-f119-47e8-8ef1-7b92a9030b08"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (393)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:06.732Z",
            "success-count": 43
          },
          "uuid": "a11b7fdb-75ac-4583-9ca9-bd0ceda02ed9"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "fefa2bb53f8adf3d446ace0b50bc6edd253eb06e27bccfa913375ecf43dffdb5:eth0",
        "container-id": "fefa2bb53f8adf3d446ace0b50bc6edd253eb06e27bccfa913375ecf43dffdb5",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-65d76cbf76-jns9h",
        "pod-name": "kube-system/clustermesh-apiserver-65d76cbf76-jns9h"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2473754,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh37",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=65d76cbf76"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh37",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:01Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.36.0.138",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "72:80:36:d4:7b:2d",
        "interface-index": 18,
        "interface-name": "lxce9fed6e122ca",
        "mac": "32:09:32:3e:76:17"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2473754,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2473754,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 393

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 393

```
Timestamp              Status   State                   Message
2024-10-25T10:23:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:01Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:22:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:16Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:22:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:22:16Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:22:16Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2473754

```
ID        LABELS
2473754   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh37
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 491

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 491

```
Invalid argument: unknown type 491
```


#### Endpoint Get 491

```
[
  {
    "id": 491,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-491-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "34ccb760-4f60-4917-b23b-ad1a9813421d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-491",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:18.575Z",
            "success-count": 3
          },
          "uuid": "248b22b8-0f2c-4d68-9eed-591348204a65"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-491",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:19.721Z",
            "success-count": 1
          },
          "uuid": "4dc51351-e764-4bf2-8142-a634ce1e5e47"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:01Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "22:77:d2:64:43:e4",
        "interface-name": "cilium_host",
        "mac": "22:77:d2:64:43:e4"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 491

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 491

```
Timestamp              Status   State                   Message
2024-10-25T10:23:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:01Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:47Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:46Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:22Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:16:22Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:16:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:20Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:16:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:16:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:16:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:18Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:16:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:16:18Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:16:18Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 1192

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    437972   5592      0        
Allow    Ingress     1          ANY          NONE         disabled    9784     112       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 1192

```
Invalid argument: unknown type 1192
```


#### Endpoint Get 1192

```
[
  {
    "id": 1192,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1192-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c6c414aa-7e89-40e4-ac72-789e93aa0496"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1192",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:19.611Z",
            "success-count": 3
          },
          "uuid": "37cedaa7-2569-467e-ba07-7bb0b532667d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1192",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:23.305Z",
            "success-count": 1
          },
          "uuid": "7ff0c310-d1a2-4cc1-91bb-c2589062660f"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:01Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.36.0.163",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "7a:9f:52:d0:28:33",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "2e:cd:34:40:f8:52"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1192

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1192

```
Timestamp              Status   State                   Message
2024-10-25T10:23:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:01Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:47Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:46Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:16:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:23Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:16:23Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:16:22Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:16:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:16:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:16:19Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:16:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:16:19Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:16:18Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Service list

```
ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.211.66:443 (active)    
                                         2 => 172.31.177.173:443 (active)   
2    10.100.165.101:443   ClusterIP      1 => 172.31.142.96:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.36.0.153:9153 (active)     
                                         2 => 10.36.0.114:9153 (active)     
4    10.100.0.10:53       ClusterIP      1 => 10.36.0.153:53 (active)       
                                         2 => 10.36.0.114:53 (active)       
5    10.100.64.100:2379   ClusterIP      1 => 10.36.0.138:2379 (active)     
```
