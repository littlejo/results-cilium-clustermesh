key: 55 00 00 00  value: 0d 02 00 00
key: d5 00 00 00  value: 15 02 00 00
key: 89 01 00 00  value: 67 02 00 00
key: a8 04 00 00  value: 17 02 00 00
Found 4 elements
