alloc: 120.55MB (126404160 bytes)
total-alloc: 1.32GB (1421410808 bytes)
sys: 214.13MB (224535892 bytes)
lookups: 0
mallocs: 47685942
frees: 46494356
heap-alloc: 120.55MB (126404160 bytes)
heap-sys: 169.67MB (177913856 bytes)
heap-idle: 28.58MB (29966336 bytes)
heap-in-use: 141.09MB (147947520 bytes)
heap-released: 13.75MB (14417920 bytes)
heap-objects: 1191586
stack-in-use: 34.28MB (35946496 bytes)
stack-sys: 34.28MB (35946496 bytes)
stack-mspan-inuse: 2.18MB (2289760 bytes)
stack-mspan-sys: 2.41MB (2529600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 704.15KB (721049 bytes)
gc-sys: 5.19MB (5437768 bytes)
next-gc: when heap-alloc >= 153.96MB (161443144 bytes)
last-gc: 2024-10-25 10:28:43.550520528 +0000 UTC
gc-pause-total: 12.068185ms
gc-pause: 63122
gc-pause-end: 1729852123550520528
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.00045663322188184776
enable-gc: true
debug-gc: false
