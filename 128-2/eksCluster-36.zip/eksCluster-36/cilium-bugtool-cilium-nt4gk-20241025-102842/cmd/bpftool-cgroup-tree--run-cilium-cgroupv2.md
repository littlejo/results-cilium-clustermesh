CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6fbb9b18_94b9_4932_b4ac_8d5b1b58bbfd.slice/cri-containerd-4cfe9d938b09499f76bbef015b6aed345606911f4b0e2086c04c69cdfc1af182.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6fbb9b18_94b9_4932_b4ac_8d5b1b58bbfd.slice/cri-containerd-4ab59e6ba056bba8d4ef3adc6efb7a4cb67ba1e83d2d06fbd6affd0cdafdd357.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ca7f938_ea1c_4833_b937_03f072737ac6.slice/cri-containerd-394d46ee07d3ff1eb38156c358ae5d333df9192a7c5fd417f6e1ab79ee8aec2e.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ca7f938_ea1c_4833_b937_03f072737ac6.slice/cri-containerd-883c4bc0ebbf443add8b52f989b186b72cf065060b04025abb9b89db9822028a.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod92ce7754_4e76_44fc_a706_56d57c0570cd.slice/cri-containerd-5e5c73ce1b7c43f97ec9a768e8b01ccb38e3e9ef70e418f238ab0879b48b9575.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod92ce7754_4e76_44fc_a706_56d57c0570cd.slice/cri-containerd-726c85339dfa3b8ed347fa08cc5991f5a1013c7394052119418b3bff573ff6ee.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod14ffe8fc_39be_41b4_adb9_1fcef87af0d6.slice/cri-containerd-af65d8543d633d4836aa4f727ff709254ae0794707c7d615899f6d6e503d5645.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod14ffe8fc_39be_41b4_adb9_1fcef87af0d6.slice/cri-containerd-ed777a8257199378bdb9f4c1fbde32e3901b52b04abf4286b476d1e82394a012.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfaf2b48a_f3f4_44f4_956d_a2aa761cd8c0.slice/cri-containerd-85aa3b789b0ece90269f388f445ecb1595d722f2808f660b81f981f49cdeb88e.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfaf2b48a_f3f4_44f4_956d_a2aa761cd8c0.slice/cri-containerd-fefa2bb53f8adf3d446ace0b50bc6edd253eb06e27bccfa913375ecf43dffdb5.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfaf2b48a_f3f4_44f4_956d_a2aa761cd8c0.slice/cri-containerd-b843d8fff0c7c5f460b42bd5bb77d4cafcb28aedf51436b08ae643409363cfce.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfaf2b48a_f3f4_44f4_956d_a2aa761cd8c0.slice/cri-containerd-87490a49e77a12197612dc80d8586c347f206e120941e8ad0412ac9d8e331027.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod24be9bfd_e34d_40c0_bbc9_ae5baa69670a.slice/cri-containerd-84d276928eea7d5f298c7d3473abb62e75538bb3acb3cf68c04268c5f63ecf93.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod24be9bfd_e34d_40c0_bbc9_ae5baa69670a.slice/cri-containerd-7bb601a2385828a2df53097bba72fd1767d4bf7bc7686ce17d823b529a2193d1.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc61afc14_899c_4198_9310_ef93239b684b.slice/cri-containerd-79e11b1b58278c80f26a6c794a1f4342fcccd9776bc52e215495549ba4cca14c.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc61afc14_899c_4198_9310_ef93239b684b.slice/cri-containerd-187572f9bf627c6347bc8f85071ebb689b6dc69037128c6dcb16e0c96b9196d7.scope
    91       cgroup_device   multi                                          
