1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ca:fb:c1:a0:5d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.142.96/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2757sec preferred_lft 2757sec
    inet6 fe80::4ca:fbff:fec1:a05d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:57:f1:d0:95:8d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.129.15/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::457:f1ff:fed0:958d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:8b:61:02:5c:74 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::488b:61ff:fe02:5c74/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:77:d2:64:43:e4 brd ff:ff:ff:ff:ff:ff
    inet 10.36.0.35/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::2077:d2ff:fe64:43e4/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether f6:1e:82:c7:4f:9f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f41e:82ff:fec7:4f9f/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:9f:52:d0:28:33 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::789f:52ff:fed0:2833/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc3c072016f17c@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:d6:05:66:ab:c3 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::4d6:5ff:fe66:abc3/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc64a26b290c9f@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:cd:c7:3e:99:e6 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::64cd:c7ff:fe3e:99e6/64 scope link 
       valid_lft forever preferred_lft forever
18: lxce9fed6e122ca@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:80:36:d4:7b:2d brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::7080:36ff:fed4:7b2d/64 scope link 
       valid_lft forever preferred_lft forever
