IP ADDRESS        LOCAL ENDPOINT INFO
172.31.142.96:0   (localhost)                                                                                        
10.36.0.35:0      (localhost)                                                                                        
172.31.129.15:0   (localhost)                                                                                        
10.36.0.114:0     id=213   sec_id=2448634 flags=0x0000 ifindex=14  mac=4A:83:82:B7:BF:DE nodemac=66:CD:C7:3E:99:E6   
10.36.0.138:0     id=393   sec_id=2473754 flags=0x0000 ifindex=18  mac=32:09:32:3E:76:17 nodemac=72:80:36:D4:7B:2D   
10.36.0.153:0     id=85    sec_id=2448634 flags=0x0000 ifindex=12  mac=92:D6:12:DA:AC:D4 nodemac=06:D6:05:66:AB:C3   
10.36.0.163:0     id=1192  sec_id=4     flags=0x0000 ifindex=10  mac=2E:CD:34:40:F8:52 nodemac=7A:9F:52:D0:28:33     
