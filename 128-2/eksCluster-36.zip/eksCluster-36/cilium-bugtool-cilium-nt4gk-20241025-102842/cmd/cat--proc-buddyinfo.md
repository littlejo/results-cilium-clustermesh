Node 0, zone      DMA      1     14     20     22      6      1      4      2      8      3    162 
Node 0, zone   Normal    505     56     14      7     25      8      6      8      7      2      5 
