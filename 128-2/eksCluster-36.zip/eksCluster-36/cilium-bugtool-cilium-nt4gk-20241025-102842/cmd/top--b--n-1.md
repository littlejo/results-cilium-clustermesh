top - 10:28:43 up 14 min,  0 users,  load average: 0.03, 0.15, 0.16
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 36.7 us, 33.3 sy,  0.0 ni, 30.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    785.5 free,    908.4 used,   2142.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2758.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1537844 280136  79008 S   6.2   7.1   0:22.86 cilium-+
    735 root      20   0 1243764  18864  13308 S   6.2   0.5   0:00.01 hubble
    393 root      20   0 1228848   6188   3056 S   0.0   0.2   0:00.26 cilium-+
    650 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    663 root      20   0 1240432  16412  11356 S   0.0   0.4   0:00.02 cilium-+
    697 root      20   0    6576   2424   2100 R   0.0   0.1   0:00.00 top
    715 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    727 root      20   0    2208    780    700 S   0.0   0.0   0:00.00 timeout
