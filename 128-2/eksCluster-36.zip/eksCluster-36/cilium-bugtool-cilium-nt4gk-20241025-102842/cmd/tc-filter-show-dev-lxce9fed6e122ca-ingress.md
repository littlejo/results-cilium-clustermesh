filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxce9fed6e122ca direct-action not_in_hw id 618 tag f775540b704117cc jited 
