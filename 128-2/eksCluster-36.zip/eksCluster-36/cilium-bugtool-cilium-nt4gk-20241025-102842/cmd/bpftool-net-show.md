xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 497
ens6(5) clsact/ingress cil_from_netdev-ens6 id 506
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 492
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 485
cilium_host(7) clsact/egress cil_from_host-cilium_host id 487
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 548
lxc3c072016f17c(12) clsact/ingress cil_from_container-lxc3c072016f17c id 524
lxc64a26b290c9f(14) clsact/ingress cil_from_container-lxc64a26b290c9f id 534
lxce9fed6e122ca(18) clsact/ingress cil_from_container-lxce9fed6e122ca id 618

flow_dissector:

netfilter:

