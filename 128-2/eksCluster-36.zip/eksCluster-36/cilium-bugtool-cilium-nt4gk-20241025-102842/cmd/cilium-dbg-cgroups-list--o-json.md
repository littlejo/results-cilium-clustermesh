[
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod92ce7754_4e76_44fc_a706_56d57c0570cd.slice/cri-containerd-5e5c73ce1b7c43f97ec9a768e8b01ccb38e3e9ef70e418f238ab0879b48b9575.scope"
      }
    ],
    "ips": [
      "10.36.0.114"
    ],
    "name": "coredns-cc6ccd49c-lj52n",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9220,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfaf2b48a_f3f4_44f4_956d_a2aa761cd8c0.slice/cri-containerd-85aa3b789b0ece90269f388f445ecb1595d722f2808f660b81f981f49cdeb88e.scope"
      },
      {
        "cgroup-id": 9136,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfaf2b48a_f3f4_44f4_956d_a2aa761cd8c0.slice/cri-containerd-b843d8fff0c7c5f460b42bd5bb77d4cafcb28aedf51436b08ae643409363cfce.scope"
      },
      {
        "cgroup-id": 9304,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfaf2b48a_f3f4_44f4_956d_a2aa761cd8c0.slice/cri-containerd-87490a49e77a12197612dc80d8586c347f206e120941e8ad0412ac9d8e331027.scope"
      }
    ],
    "ips": [
      "10.36.0.138"
    ],
    "name": "clustermesh-apiserver-65d76cbf76-jns9h",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod14ffe8fc_39be_41b4_adb9_1fcef87af0d6.slice/cri-containerd-ed777a8257199378bdb9f4c1fbde32e3901b52b04abf4286b476d1e82394a012.scope"
      }
    ],
    "ips": [
      "10.36.0.153"
    ],
    "name": "coredns-cc6ccd49c-gdxzd",
    "namespace": "kube-system"
  }
]

