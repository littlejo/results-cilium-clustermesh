REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     10096     790135      677    bpf_overlay.c
Interface                 INGRESS     229324    102058328   1132   bpf_host.c
Success                   EGRESS      10299     806175      53     encap.h
Success                   EGRESS      5196      400163      1694   bpf_host.c
Success                   EGRESS      98820     12839452    1308   bpf_lxc.c
Success                   INGRESS     109260    13494429    86     l3.h
Success                   INGRESS     114809    13928307    235    trace.h
Unsupported L3 protocol   EGRESS      37        2742        1492   bpf_lxc.c
