[
  {
    "containers": [
      {
        "cgroup-id": 8286,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7fe7f270_cc63_4669_8ff0_0e95d8d68697.slice/cri-containerd-3e2e282111c1b6ae199b445b3f8f311266e5f8eff9a7042aefaf950696ae5cfc.scope"
      },
      {
        "cgroup-id": 8202,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7fe7f270_cc63_4669_8ff0_0e95d8d68697.slice/cri-containerd-90168419bd7263ab93ec4f6d6f26d2f7a57e9f5293c0ca1a744e47df9b4cf841.scope"
      },
      {
        "cgroup-id": 8370,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7fe7f270_cc63_4669_8ff0_0e95d8d68697.slice/cri-containerd-9ab771326b0f442bf3f9f6d003968a190e2ebcd7da956abecb072ff0898563e6.scope"
      }
    ],
    "ips": [
      "10.6.0.174"
    ],
    "name": "clustermesh-apiserver-7f79d77f7f-gkmhp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6858,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbd93b6bb_ff96_492b_9d74_522485cb4d99.slice/cri-containerd-694cc2131a386aee0ea2413cbe63beebfe39fce5a2887f7253f436b6c476aaac.scope"
      }
    ],
    "ips": [
      "10.6.0.201"
    ],
    "name": "coredns-cc6ccd49c-fw7f9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6774,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod65ab75d0_1577_402d_8695_0b2d02f9a726.slice/cri-containerd-f3e791c73659c9d9a1795adc8ed587ec3cf45df2b1bd8faf6d6949fd001f9fce.scope"
      }
    ],
    "ips": [
      "10.6.0.236"
    ],
    "name": "coredns-cc6ccd49c-g456q",
    "namespace": "kube-system"
  }
]

