fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxc3d939290b401 proto kernel metric 256 pref medium
fe80::/64 dev lxc059d76200a31 proto kernel metric 256 pref medium
fe80::/64 dev lxcbdd10a3b9e82 proto kernel metric 256 pref medium
