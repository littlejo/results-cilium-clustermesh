CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod65ab75d0_1577_402d_8695_0b2d02f9a726.slice/cri-containerd-fd4e7be563b28a015b65addd15c3f935795306c40882567ae7664d6db6d538c2.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod65ab75d0_1577_402d_8695_0b2d02f9a726.slice/cri-containerd-f3e791c73659c9d9a1795adc8ed587ec3cf45df2b1bd8faf6d6949fd001f9fce.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca14b458_ab23_4a24_b212_48459246c120.slice/cri-containerd-99ac4331d1f5b1ae165fabc58855ed8d57700e5a448bb0988c9fef444e03d8b9.scope
    100      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca14b458_ab23_4a24_b212_48459246c120.slice/cri-containerd-bde8078011748f7f5890f9aca7f6ec336a315c40d2c2604c8abf4ba2a40f03c8.scope
    58       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5e92645a_03e5_48d9_91e6_b5ded3570dc2.slice/cri-containerd-f08b23f96acc9ff080c09f16fc8248741c0735143c493305975c61ec91263fc6.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5e92645a_03e5_48d9_91e6_b5ded3570dc2.slice/cri-containerd-08dbebcdded967a5228ccef0241c5f010e8f7a08c01986f619b7bc43c44ca904.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbd93b6bb_ff96_492b_9d74_522485cb4d99.slice/cri-containerd-f4b99c6ba1bdb7a6dc830dd83c11628339f0d570689f832dc535bb8a013b52c8.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbd93b6bb_ff96_492b_9d74_522485cb4d99.slice/cri-containerd-694cc2131a386aee0ea2413cbe63beebfe39fce5a2887f7253f436b6c476aaac.scope
    542      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2374a576_f7e4_44fc_9c48_eaedbdee36f6.slice/cri-containerd-53f3409eacfd2fc201bc0172582315ed93660a06b4535403760eddbf57399bf2.scope
    69       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2374a576_f7e4_44fc_9c48_eaedbdee36f6.slice/cri-containerd-dcba58ab12bd008110b2d3ef170b398717c3454b3b5f65f15143e5d0f9c48bb0.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26942e9a_e4fc_41e6_a248_7ccc56d160dd.slice/cri-containerd-3372d26804f07dfb8ef41640e703926cea4a7a8f202b47b846f3dfe5b7854c01.scope
    73       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26942e9a_e4fc_41e6_a248_7ccc56d160dd.slice/cri-containerd-64e98f886d8829c2648cc348feeb334654420a9b92719bc91e41b8215b4acb40.scope
    62       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7fe7f270_cc63_4669_8ff0_0e95d8d68697.slice/cri-containerd-90168419bd7263ab93ec4f6d6f26d2f7a57e9f5293c0ca1a744e47df9b4cf841.scope
    616      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7fe7f270_cc63_4669_8ff0_0e95d8d68697.slice/cri-containerd-9ab771326b0f442bf3f9f6d003968a190e2ebcd7da956abecb072ff0898563e6.scope
    624      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7fe7f270_cc63_4669_8ff0_0e95d8d68697.slice/cri-containerd-c29756914cb47f3c4d456ad280242861ad002d4298db4ed13ec7d7e47b908824.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7fe7f270_cc63_4669_8ff0_0e95d8d68697.slice/cri-containerd-3e2e282111c1b6ae199b445b3f8f311266e5f8eff9a7042aefaf950696ae5cfc.scope
    620      cgroup_device   multi                                          
