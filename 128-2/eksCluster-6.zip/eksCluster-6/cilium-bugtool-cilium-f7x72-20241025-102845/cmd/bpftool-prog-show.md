29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:10+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:10+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:10+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:10+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:10+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:12:10+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:12:11+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:12:11+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:11+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:11+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:12:11+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:11+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:12:14+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
55: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
58: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
59: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
62: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:12:24+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
66: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
69: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
70: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
73: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
97: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
100: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
441: sched_cls  name tail_handle_ipv4  tag 17db63111b66308f  gpl
	loaded_at 2024-10-25T10:12:54+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 112
442: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:12:54+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 113
443: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:12:54+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 114
444: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:12:54+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 115
467: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,100
	btf_id 143
469: sched_cls  name tail_ipv4_ct_ingress  tag a344a202b73727cb  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,100,74,75,101,76
	btf_id 145
473: sched_cls  name tail_handle_ipv4  tag 0b5497efd4c5455e  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,100
	btf_id 147
476: sched_cls  name tail_ipv4_ct_egress  tag 34bed9a71507d359  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,100,74,75,101,76
	btf_id 152
477: sched_cls  name tail_ipv4_to_endpoint  tag 5639886e6e86b5ee  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,101,33,74,75,72,97,31,100,32,29,30
	btf_id 154
481: sched_cls  name handle_policy  tag 09988bfcb26059e9  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,100,74,75,101,33,72,97,31,76,67,32,29,30
	btf_id 155
482: sched_cls  name cil_from_container  tag dbdb958c8f5358d2  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 100,68
	btf_id 159
483: sched_cls  name __send_drop_notify  tag 6c266df9f50dee11  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 160
486: sched_cls  name tail_handle_ipv4_cont  tag 5297dd6ea9711c5e  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,101,33,97,74,75,31,68,66,69,100,32,29,30,73
	btf_id 162
487: sched_cls  name cil_from_container  tag 086f45308500cb78  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 104,68
	btf_id 164
488: sched_cls  name tail_handle_arp  tag aa9cfd666eccd845  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,100
	btf_id 165
490: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 169
491: sched_cls  name __send_drop_notify  tag b52a1eb94d09c198  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 170
492: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,106
	btf_id 171
494: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,106
	btf_id 173
496: sched_cls  name tail_handle_ipv4_from_host  tag 935370cf2a7adec2  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,106
	btf_id 175
497: sched_cls  name tail_ipv4_to_endpoint  tag 61252a8391e98976  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,103,33,74,75,72,102,31,104,32,29,30
	btf_id 167
499: sched_cls  name tail_handle_ipv4_from_host  tag 935370cf2a7adec2  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,108
	btf_id 179
500: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 180
501: sched_cls  name __send_drop_notify  tag b52a1eb94d09c198  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 181
502: sched_cls  name tail_ipv4_ct_egress  tag 34bed9a71507d359  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 176
505: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,108
	btf_id 185
507: sched_cls  name tail_handle_ipv4_cont  tag ef88bbd04b199eba  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,103,33,102,74,75,31,68,66,69,104,32,29,30,73
	btf_id 183
508: sched_cls  name __send_drop_notify  tag acfe0e53ebb3231a  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 189
510: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,109
	btf_id 190
511: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,109,67
	btf_id 192
512: sched_cls  name tail_handle_ipv4_from_host  tag 935370cf2a7adec2  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,109
	btf_id 193
514: sched_cls  name __send_drop_notify  tag b52a1eb94d09c198  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 195
515: sched_cls  name tail_ipv4_ct_ingress  tag d18864721f6f0784  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 191
516: sched_cls  name tail_handle_arp  tag 9f27c47fd6fe21a4  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,104
	btf_id 196
517: sched_cls  name tail_handle_arp  tag e321f21bf02ec327  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,111
	btf_id 199
518: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,111
	btf_id 200
519: sched_cls  name handle_policy  tag ea427480c93149b3  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,104,74,75,103,33,72,102,31,76,67,32,29,30
	btf_id 197
520: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,104
	btf_id 202
521: sched_cls  name handle_policy  tag 2348a8a7f39cd337  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,111,74,75,112,33,72,90,31,76,67,32,29,30
	btf_id 201
522: sched_cls  name __send_drop_notify  tag fabf44e09ffe2794  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 204
523: sched_cls  name tail_handle_ipv4  tag ce4ee917209ca70b  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,104
	btf_id 203
524: sched_cls  name tail_handle_ipv4  tag 923c3e900554158b  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,111
	btf_id 205
525: sched_cls  name tail_ipv4_ct_ingress  tag 08b1826169a15a7e  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,111,74,75,112,76
	btf_id 206
526: sched_cls  name cil_from_container  tag d7264669c807666c  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 111,68
	btf_id 207
527: sched_cls  name tail_handle_ipv4_cont  tag fb84c2f2b90af826  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,112,33,90,74,75,31,68,66,69,111,32,29,30,73
	btf_id 208
529: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:12:57+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,111,74,75,112,76
	btf_id 210
530: sched_cls  name tail_ipv4_to_endpoint  tag 6205d160d7f9e29a  gpl
	loaded_at 2024-10-25T10:12:57+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,112,33,74,75,72,90,31,111,32,29,30
	btf_id 211
531: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
534: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
535: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
538: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
539: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
542: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
543: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
546: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
586: sched_cls  name __send_drop_notify  tag 16ed2fa202fa6ad7  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 227
587: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,129
	btf_id 228
588: sched_cls  name cil_from_container  tag ceaddc8a367d9871  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 129,68
	btf_id 229
589: sched_cls  name tail_ipv4_ct_ingress  tag b2a1eb10b3dca62c  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,129,74,75,128,76
	btf_id 230
590: sched_cls  name tail_ipv4_to_endpoint  tag ce91e786abf6726e  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,128,33,74,75,72,127,31,129,32,29,30
	btf_id 231
591: sched_cls  name tail_handle_ipv4  tag ced5e792c2044488  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,129
	btf_id 232
592: sched_cls  name tail_handle_ipv4_cont  tag 88d2933b6881bad5  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,128,33,127,74,75,31,68,66,69,129,32,29,30,73
	btf_id 233
593: sched_cls  name tail_ipv4_ct_egress  tag 10e32ab694b37133  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,129,74,75,128,76
	btf_id 234
594: sched_cls  name tail_handle_arp  tag 227fd5a491b47793  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,129
	btf_id 235
595: sched_cls  name handle_policy  tag 79256357e876d7e4  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,129,74,75,128,33,72,127,31,76,67,32,29,30
	btf_id 236
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
613: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
616: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
617: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
620: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
621: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
624: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
