Node 0, zone      DMA      5      6      4      4     10      9      8      7      6      6    222 
Node 0, zone   Normal     15      2      1      3      1      5     26      8      4      2     48 
