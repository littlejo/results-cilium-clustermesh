KEY             VALUE
AgentLiveness   1029222514665
UTimeOffset     3378615484375000
