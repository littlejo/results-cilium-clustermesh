markdown output at /tmp/cilium-bugtool-20241025-102847.22+0000-UTC-3567857266/cmd/cilium-debuginfo-20241025-102917.856+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102847.22+0000-UTC-3567857266/cmd/cilium-debuginfo-20241025-102917.856+0000-UTC.json
