key: 14 09 00 00  value: 09 02 00 00
key: 29 0e 00 00  value: 53 02 00 00
key: 35 0e 00 00  value: 07 02 00 00
key: c0 0e 00 00  value: e1 01 00 00
Found 4 elements
