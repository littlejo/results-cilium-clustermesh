 10:28:47 up 16 min,  0 users,  load average: 0.17, 0.18, 0.14
