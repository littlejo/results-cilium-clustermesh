IP ADDRESS         LOCAL ENDPOINT INFO
10.6.0.201:0       id=3637  sec_id=462596 flags=0x0000 ifindex=11  mac=9A:FF:D2:1F:7F:26 nodemac=7A:6E:84:1B:B1:A8   
10.6.0.79:0        id=2324  sec_id=4     flags=0x0000 ifindex=7   mac=3A:B0:11:D6:2F:5D nodemac=06:C9:14:CC:07:66    
10.6.0.236:0       id=3776  sec_id=462596 flags=0x0000 ifindex=9   mac=22:1D:D3:07:DD:96 nodemac=FA:FE:21:37:9E:0C   
172.31.174.163:0   (localhost)                                                                                       
10.6.0.174:0       id=3625  sec_id=523246 flags=0x0000 ifindex=15  mac=D2:9B:62:17:E7:4B nodemac=9E:D9:23:75:EF:6A   
10.6.0.9:0         (localhost)                                                                                       
