{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:12:52.664Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.174.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:12:52.664Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:12:56.933Z",
  "value": "id=2324  sec_id=4     flags=0x0000 ifindex=7   mac=3A:B0:11:D6:2F:5D nodemac=06:C9:14:CC:07:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:12:56.936Z",
  "value": "id=3776  sec_id=462596 flags=0x0000 ifindex=9   mac=22:1D:D3:07:DD:96 nodemac=FA:FE:21:37:9E:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:12:56.986Z",
  "value": "id=3637  sec_id=462596 flags=0x0000 ifindex=11  mac=9A:FF:D2:1F:7F:26 nodemac=7A:6E:84:1B:B1:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:12:57.014Z",
  "value": "id=2324  sec_id=4     flags=0x0000 ifindex=7   mac=3A:B0:11:D6:2F:5D nodemac=06:C9:14:CC:07:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:14.989Z",
  "value": "id=3776  sec_id=462596 flags=0x0000 ifindex=9   mac=22:1D:D3:07:DD:96 nodemac=FA:FE:21:37:9E:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:14.989Z",
  "value": "id=3637  sec_id=462596 flags=0x0000 ifindex=11  mac=9A:FF:D2:1F:7F:26 nodemac=7A:6E:84:1B:B1:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:14.990Z",
  "value": "id=2324  sec_id=4     flags=0x0000 ifindex=7   mac=3A:B0:11:D6:2F:5D nodemac=06:C9:14:CC:07:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:15.021Z",
  "value": "id=62    sec_id=523246 flags=0x0000 ifindex=13  mac=0A:76:44:53:87:3C nodemac=06:D8:79:7F:15:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:15.989Z",
  "value": "id=62    sec_id=523246 flags=0x0000 ifindex=13  mac=0A:76:44:53:87:3C nodemac=06:D8:79:7F:15:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:15.989Z",
  "value": "id=3637  sec_id=462596 flags=0x0000 ifindex=11  mac=9A:FF:D2:1F:7F:26 nodemac=7A:6E:84:1B:B1:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:15.990Z",
  "value": "id=2324  sec_id=4     flags=0x0000 ifindex=7   mac=3A:B0:11:D6:2F:5D nodemac=06:C9:14:CC:07:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:15.990Z",
  "value": "id=3776  sec_id=462596 flags=0x0000 ifindex=9   mac=22:1D:D3:07:DD:96 nodemac=FA:FE:21:37:9E:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:12.081Z",
  "value": "id=3625  sec_id=523246 flags=0x0000 ifindex=15  mac=D2:9B:62:17:E7:4B nodemac=9E:D9:23:75:EF:6A"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.6.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:17.642Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.672Z",
  "value": "id=2324  sec_id=4     flags=0x0000 ifindex=7   mac=3A:B0:11:D6:2F:5D nodemac=06:C9:14:CC:07:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.672Z",
  "value": "id=3776  sec_id=462596 flags=0x0000 ifindex=9   mac=22:1D:D3:07:DD:96 nodemac=FA:FE:21:37:9E:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.673Z",
  "value": "id=3637  sec_id=462596 flags=0x0000 ifindex=11  mac=9A:FF:D2:1F:7F:26 nodemac=7A:6E:84:1B:B1:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.673Z",
  "value": "id=3625  sec_id=523246 flags=0x0000 ifindex=15  mac=D2:9B:62:17:E7:4B nodemac=9E:D9:23:75:EF:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:08.672Z",
  "value": "id=3776  sec_id=462596 flags=0x0000 ifindex=9   mac=22:1D:D3:07:DD:96 nodemac=FA:FE:21:37:9E:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:08.672Z",
  "value": "id=3625  sec_id=523246 flags=0x0000 ifindex=15  mac=D2:9B:62:17:E7:4B nodemac=9E:D9:23:75:EF:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:08.672Z",
  "value": "id=3637  sec_id=462596 flags=0x0000 ifindex=11  mac=9A:FF:D2:1F:7F:26 nodemac=7A:6E:84:1B:B1:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:08.672Z",
  "value": "id=2324  sec_id=4     flags=0x0000 ifindex=7   mac=3A:B0:11:D6:2F:5D nodemac=06:C9:14:CC:07:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:09.672Z",
  "value": "id=3637  sec_id=462596 flags=0x0000 ifindex=11  mac=9A:FF:D2:1F:7F:26 nodemac=7A:6E:84:1B:B1:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:09.672Z",
  "value": "id=2324  sec_id=4     flags=0x0000 ifindex=7   mac=3A:B0:11:D6:2F:5D nodemac=06:C9:14:CC:07:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:09.672Z",
  "value": "id=3625  sec_id=523246 flags=0x0000 ifindex=15  mac=D2:9B:62:17:E7:4B nodemac=9E:D9:23:75:EF:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:09.673Z",
  "value": "id=3776  sec_id=462596 flags=0x0000 ifindex=9   mac=22:1D:D3:07:DD:96 nodemac=FA:FE:21:37:9E:0C"
}

