Endpoint ID: 1150
Path: /sys/fs/bpf/tc/globals/cilium_policy_01150

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2324
Path: /sys/fs/bpf/tc/globals/cilium_policy_02324

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    435746   5573      0        
Allow    Ingress     1          ANY          NONE         disabled    13152    152       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3625
Path: /sys/fs/bpf/tc/globals/cilium_policy_03625

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3810325   36422     0        
Allow    Ingress     1          ANY          NONE         disabled    3389971   34583     0        
Allow    Egress      0          ANY          NONE         disabled    5459641   50234     0        


Endpoint ID: 3637
Path: /sys/fs/bpf/tc/globals/cilium_policy_03637

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    92142   1059      0        
Allow    Egress      0          ANY          NONE         disabled    14230   149       0        


Endpoint ID: 3776
Path: /sys/fs/bpf/tc/globals/cilium_policy_03776

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    92802   1069      0        
Allow    Egress      0          ANY          NONE         disabled    15413   163       0        


