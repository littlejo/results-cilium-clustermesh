alloc: 135.96MB (142565248 bytes)
total-alloc: 1.38GB (1484105408 bytes)
sys: 206.13MB (216147284 bytes)
lookups: 0
mallocs: 48583810
frees: 47193776
heap-alloc: 135.96MB (142565248 bytes)
heap-sys: 161.27MB (169099264 bytes)
heap-idle: 11.38MB (11927552 bytes)
heap-in-use: 149.89MB (157171712 bytes)
heap-released: 432.00KB (442368 bytes)
heap-objects: 1390034
stack-in-use: 34.69MB (36372480 bytes)
stack-sys: 34.69MB (36372480 bytes)
stack-mspan-inuse: 2.32MB (2430880 bytes)
stack-mspan-sys: 2.35MB (2464320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 799.85KB (819049 bytes)
gc-sys: 5.12MB (5365704 bytes)
next-gc: when heap-alloc >= 142.75MB (149689160 bytes)
last-gc: 2024-10-25 10:28:37.7675835 +0000 UTC
gc-pause-total: 8.381978ms
gc-pause: 130735
gc-pause-end: 1729852117767583500
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.00031176227696153215
enable-gc: true
debug-gc: false
