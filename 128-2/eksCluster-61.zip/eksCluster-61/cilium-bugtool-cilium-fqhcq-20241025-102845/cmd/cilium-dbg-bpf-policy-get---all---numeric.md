Endpoint ID: 762
Path: /sys/fs/bpf/tc/globals/cilium_policy_00762

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 967
Path: /sys/fs/bpf/tc/globals/cilium_policy_00967

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    80797   933       0        
Allow    Egress      0          ANY          NONE         disabled    12724   132       0        


Endpoint ID: 1201
Path: /sys/fs/bpf/tc/globals/cilium_policy_01201

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3615380   34376     0        
Allow    Ingress     1          ANY          NONE         disabled    3255659   33011     0        
Allow    Egress      0          ANY          NONE         disabled    4544209   42476     0        


Endpoint ID: 1608
Path: /sys/fs/bpf/tc/globals/cilium_policy_01608

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    402820   5137      0        
Allow    Ingress     1          ANY          NONE         disabled    11900    138       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2698
Path: /sys/fs/bpf/tc/globals/cilium_policy_02698

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    80401   927       0        
Allow    Egress      0          ANY          NONE         disabled    14591   153       0        


