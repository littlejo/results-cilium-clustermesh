1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:21:db:62:84:43 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.242.183/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2698sec preferred_lft 2698sec
    inet6 fe80::821:dbff:fe62:8443/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:64:8a:65:72:e5 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b864:8aff:fe65:72e5/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:c7:aa:9d:0a:ae brd ff:ff:ff:ff:ff:ff
    inet 10.61.0.25/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::4cc7:aaff:fe9d:aae/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether a2:bc:1d:43:da:cd brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a0bc:1dff:fe43:dacd/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:56:2b:e7:7f:0f brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::b856:2bff:fee7:7f0f/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc021c9783fc33@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:7f:f5:14:9f:d9 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::5c7f:f5ff:fe14:9fd9/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc65cca3511c31@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:d7:3d:b9:7b:06 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::f0d7:3dff:feb9:7b06/64 scope link 
       valid_lft forever preferred_lft forever
15: lxcf624e9293047@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:43:21:cb:5c:e1 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::1443:21ff:fecb:5ce1/64 scope link 
       valid_lft forever preferred_lft forever
