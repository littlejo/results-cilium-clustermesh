filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc65cca3511c31 direct-action not_in_hw id 481 tag a3215c75780d0ce5 jited 
