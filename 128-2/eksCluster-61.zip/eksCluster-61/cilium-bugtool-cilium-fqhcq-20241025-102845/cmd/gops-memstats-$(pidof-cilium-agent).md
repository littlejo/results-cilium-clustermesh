alloc: 113.57MB (119091728 bytes)
total-alloc: 1.32GB (1422085608 bytes)
sys: 206.38MB (216409428 bytes)
lookups: 0
mallocs: 47638430
frees: 46552495
heap-alloc: 113.57MB (119091728 bytes)
heap-sys: 161.29MB (169123840 bytes)
heap-idle: 25.84MB (27090944 bytes)
heap-in-use: 135.45MB (142032896 bytes)
heap-released: 2.09MB (2195456 bytes)
heap-objects: 1085935
stack-in-use: 34.69MB (36372480 bytes)
stack-sys: 34.69MB (36372480 bytes)
stack-mspan-inuse: 2.13MB (2232640 bytes)
stack-mspan-sys: 2.44MB (2562240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 927.26KB (949513 bytes)
gc-sys: 5.15MB (5402952 bytes)
next-gc: when heap-alloc >= 142.78MB (149720040 bytes)
last-gc: 2024-10-25 10:28:06.972467095 +0000 UTC
gc-pause-total: 8.100296ms
gc-pause: 73149
gc-pause-end: 1729852086972467095
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.00032266844294167435
enable-gc: true
debug-gc: false
