IP ADDRESS         LOCAL ENDPOINT INFO
10.61.0.34:0       id=2698  sec_id=4066606 flags=0x0000 ifindex=9   mac=52:A3:64:90:7A:F2 nodemac=5E:7F:F5:14:9F:D9   
10.61.0.165:0      id=1608  sec_id=4     flags=0x0000 ifindex=7   mac=32:BC:A3:83:BC:20 nodemac=BA:56:2B:E7:7F:0F     
10.61.0.25:0       (localhost)                                                                                        
10.61.0.18:0       id=967   sec_id=4066606 flags=0x0000 ifindex=11  mac=36:35:01:9A:43:1C nodemac=F2:D7:3D:B9:7B:06   
10.61.0.97:0       id=1201  sec_id=4086854 flags=0x0000 ifindex=15  mac=1E:67:8B:FA:55:A9 nodemac=16:43:21:CB:5C:E1   
172.31.242.183:0   (localhost)                                                                                        
