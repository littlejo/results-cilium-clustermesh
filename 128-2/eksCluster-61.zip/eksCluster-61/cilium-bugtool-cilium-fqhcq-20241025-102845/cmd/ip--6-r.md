fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxc021c9783fc33 proto kernel metric 256 pref medium
fe80::/64 dev lxc65cca3511c31 proto kernel metric 256 pref medium
fe80::/64 dev lxcf624e9293047 proto kernel metric 256 pref medium
