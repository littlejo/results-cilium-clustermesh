key: c7 03 00 00  value: e4 01 00 00
key: b1 04 00 00  value: 4c 02 00 00
key: 48 06 00 00  value: eb 01 00 00
key: 8a 0a 00 00  value: f3 01 00 00
Found 4 elements
