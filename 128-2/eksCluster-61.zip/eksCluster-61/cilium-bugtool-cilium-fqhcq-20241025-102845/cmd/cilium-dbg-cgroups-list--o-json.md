[
  {
    "containers": [
      {
        "cgroup-id": 8622,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode2be54db_7531_4d82_b85c_aac6493cc511.slice/cri-containerd-fbfcdbbae54e0ce4e77f743202d8319381f48786f75ae537047762cece92b428.scope"
      },
      {
        "cgroup-id": 8538,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode2be54db_7531_4d82_b85c_aac6493cc511.slice/cri-containerd-fa7aaf546f2451d1f7a18a428c0884aec717f5d1db8bed7e32cdcb57c0ae8063.scope"
      },
      {
        "cgroup-id": 8454,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode2be54db_7531_4d82_b85c_aac6493cc511.slice/cri-containerd-339cc1703ee284d655b495159f120cae591419be23d45933af057e320c06048c.scope"
      }
    ],
    "ips": [
      "10.61.0.97"
    ],
    "name": "clustermesh-apiserver-59ddb7ff56-7h6vw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7110,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4b5a626_ae65_4d81_8e53_421f07bed60e.slice/cri-containerd-38ec102e1a1360cbf7eec0eb2e44c42b66f0a43997d31fc556ced8a0ed07882d.scope"
      }
    ],
    "ips": [
      "10.61.0.18"
    ],
    "name": "coredns-cc6ccd49c-h28xg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7026,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod37f82d03_6e25_48d0_ad5a_e69d826fbeb4.slice/cri-containerd-b8b52e8253c8cff02e9f28aee574a32be6db349380043c0c5958ec4b7397c840.scope"
      }
    ],
    "ips": [
      "10.61.0.34"
    ],
    "name": "coredns-cc6ccd49c-qn8jg",
    "namespace": "kube-system"
  }
]

