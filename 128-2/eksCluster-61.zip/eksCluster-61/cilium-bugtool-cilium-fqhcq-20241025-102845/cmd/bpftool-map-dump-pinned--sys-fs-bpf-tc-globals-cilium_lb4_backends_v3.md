key: 01 00 00 00  value: ac 1f 8c da 01 bb 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f ff 7d 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 3d 00 12 00 35 00 00  00 00 00 00
key: 04 00 00 00  value: 0a 3d 00 22 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 3d 00 61 09 4b 00 00  00 00 00 00
key: 05 00 00 00  value: 0a 3d 00 22 00 35 00 00  00 00 00 00
key: 03 00 00 00  value: ac 1f f2 b7 10 94 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 3d 00 12 23 c1 00 00  00 00 00 00
Found 8 elements
