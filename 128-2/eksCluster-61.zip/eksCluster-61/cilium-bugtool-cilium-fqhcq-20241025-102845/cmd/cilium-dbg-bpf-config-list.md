KEY             VALUE
AgentLiveness   917378428096
UTimeOffset     3378615652343750
