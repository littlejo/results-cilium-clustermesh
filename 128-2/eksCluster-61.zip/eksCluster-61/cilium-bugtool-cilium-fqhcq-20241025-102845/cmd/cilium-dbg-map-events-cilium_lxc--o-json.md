{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:32.819Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.242.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:32.819Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:37.433Z",
  "value": "id=1608  sec_id=4     flags=0x0000 ifindex=7   mac=32:BC:A3:83:BC:20 nodemac=BA:56:2B:E7:7F:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:37.435Z",
  "value": "id=2698  sec_id=4066606 flags=0x0000 ifindex=9   mac=52:A3:64:90:7A:F2 nodemac=5E:7F:F5:14:9F:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:37.498Z",
  "value": "id=967   sec_id=4066606 flags=0x0000 ifindex=11  mac=36:35:01:9A:43:1C nodemac=F2:D7:3D:B9:7B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:37.538Z",
  "value": "id=1608  sec_id=4     flags=0x0000 ifindex=7   mac=32:BC:A3:83:BC:20 nodemac=BA:56:2B:E7:7F:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:37.584Z",
  "value": "id=2698  sec_id=4066606 flags=0x0000 ifindex=9   mac=52:A3:64:90:7A:F2 nodemac=5E:7F:F5:14:9F:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:25.950Z",
  "value": "id=967   sec_id=4066606 flags=0x0000 ifindex=11  mac=36:35:01:9A:43:1C nodemac=F2:D7:3D:B9:7B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:25.951Z",
  "value": "id=1608  sec_id=4     flags=0x0000 ifindex=7   mac=32:BC:A3:83:BC:20 nodemac=BA:56:2B:E7:7F:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:25.952Z",
  "value": "id=2698  sec_id=4066606 flags=0x0000 ifindex=9   mac=52:A3:64:90:7A:F2 nodemac=5E:7F:F5:14:9F:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:25.986Z",
  "value": "id=158   sec_id=4086854 flags=0x0000 ifindex=13  mac=5A:09:8C:B9:FD:29 nodemac=36:52:E0:33:E1:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:25.986Z",
  "value": "id=158   sec_id=4086854 flags=0x0000 ifindex=13  mac=5A:09:8C:B9:FD:29 nodemac=36:52:E0:33:E1:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:44.551Z",
  "value": "id=1201  sec_id=4086854 flags=0x0000 ifindex=15  mac=1E:67:8B:FA:55:A9 nodemac=16:43:21:CB:5C:E1"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.61.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:51.385Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.148Z",
  "value": "id=967   sec_id=4066606 flags=0x0000 ifindex=11  mac=36:35:01:9A:43:1C nodemac=F2:D7:3D:B9:7B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.148Z",
  "value": "id=1201  sec_id=4086854 flags=0x0000 ifindex=15  mac=1E:67:8B:FA:55:A9 nodemac=16:43:21:CB:5C:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.149Z",
  "value": "id=1608  sec_id=4     flags=0x0000 ifindex=7   mac=32:BC:A3:83:BC:20 nodemac=BA:56:2B:E7:7F:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.149Z",
  "value": "id=2698  sec_id=4066606 flags=0x0000 ifindex=9   mac=52:A3:64:90:7A:F2 nodemac=5E:7F:F5:14:9F:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:03.126Z",
  "value": "id=1608  sec_id=4     flags=0x0000 ifindex=7   mac=32:BC:A3:83:BC:20 nodemac=BA:56:2B:E7:7F:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:03.126Z",
  "value": "id=1201  sec_id=4086854 flags=0x0000 ifindex=15  mac=1E:67:8B:FA:55:A9 nodemac=16:43:21:CB:5C:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:03.126Z",
  "value": "id=967   sec_id=4066606 flags=0x0000 ifindex=11  mac=36:35:01:9A:43:1C nodemac=F2:D7:3D:B9:7B:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:03.127Z",
  "value": "id=2698  sec_id=4066606 flags=0x0000 ifindex=9   mac=52:A3:64:90:7A:F2 nodemac=5E:7F:F5:14:9F:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:04.127Z",
  "value": "id=1201  sec_id=4086854 flags=0x0000 ifindex=15  mac=1E:67:8B:FA:55:A9 nodemac=16:43:21:CB:5C:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:04.127Z",
  "value": "id=1608  sec_id=4     flags=0x0000 ifindex=7   mac=32:BC:A3:83:BC:20 nodemac=BA:56:2B:E7:7F:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:04.128Z",
  "value": "id=2698  sec_id=4066606 flags=0x0000 ifindex=9   mac=52:A3:64:90:7A:F2 nodemac=5E:7F:F5:14:9F:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:04.128Z",
  "value": "id=967   sec_id=4066606 flags=0x0000 ifindex=11  mac=36:35:01:9A:43:1C nodemac=F2:D7:3D:B9:7B:06"
}

