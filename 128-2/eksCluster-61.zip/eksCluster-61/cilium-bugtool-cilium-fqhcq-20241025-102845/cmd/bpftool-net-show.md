xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 535
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 526
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 516
cilium_host(4) clsact/egress cil_from_host-cilium_host id 515
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 450
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 451
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 494
lxc021c9783fc33(9) clsact/ingress cil_from_container-lxc021c9783fc33 id 501
lxc65cca3511c31(11) clsact/ingress cil_from_container-lxc65cca3511c31 id 481
lxcf624e9293047(15) clsact/ingress cil_from_container-lxcf624e9293047 id 593

flow_dissector:

netfilter:

