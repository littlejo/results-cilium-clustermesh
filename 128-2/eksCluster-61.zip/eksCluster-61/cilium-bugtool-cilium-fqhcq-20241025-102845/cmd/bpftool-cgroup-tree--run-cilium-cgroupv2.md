CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod78ef2dd1_5005_47cf_aad6_8c0ff05479ef.slice/cri-containerd-90205261204ff03e8a681271312bda9b3882b436d5ab098142d9aaa6dfd0d252.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod78ef2dd1_5005_47cf_aad6_8c0ff05479ef.slice/cri-containerd-c700a0079ef43430585e966b2df32f1ea957f6db5852de79de3efd3c0bc5fa6a.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod512250be_d484_4e0d_950b_f492adee0314.slice/cri-containerd-1ac4d42856ab4d80f55a3605b61e638150b58fe136a01bfe4fb37415c3af4fe9.scope
    64       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod512250be_d484_4e0d_950b_f492adee0314.slice/cri-containerd-c188b3fac4b3e19e35f4f422afab4b15b211d8055933373f91a79bdacbead7fa.scope
    107      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod37f82d03_6e25_48d0_ad5a_e69d826fbeb4.slice/cri-containerd-8bc985e2588dc57429ff929eb296f7f07d4d75259c0c30ba072262b9cfc9e5d9.scope
    510      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod37f82d03_6e25_48d0_ad5a_e69d826fbeb4.slice/cri-containerd-b8b52e8253c8cff02e9f28aee574a32be6db349380043c0c5958ec4b7397c840.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4b5a626_ae65_4d81_8e53_421f07bed60e.slice/cri-containerd-38ec102e1a1360cbf7eec0eb2e44c42b66f0a43997d31fc556ced8a0ed07882d.scope
    543      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4b5a626_ae65_4d81_8e53_421f07bed60e.slice/cri-containerd-02f6effd932a0c7ff7b12e03051970e584d3f1b49d01f93a8bacd193eba0c9ed.scope
    514      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode2be54db_7531_4d82_b85c_aac6493cc511.slice/cri-containerd-23797a7d4f8bbd51d5eecf4e77ccdfd36044c458da6232ea69d5736a1aeba221.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode2be54db_7531_4d82_b85c_aac6493cc511.slice/cri-containerd-fa7aaf546f2451d1f7a18a428c0884aec717f5d1db8bed7e32cdcb57c0ae8063.scope
    617      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode2be54db_7531_4d82_b85c_aac6493cc511.slice/cri-containerd-339cc1703ee284d655b495159f120cae591419be23d45933af057e320c06048c.scope
    613      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode2be54db_7531_4d82_b85c_aac6493cc511.slice/cri-containerd-fbfcdbbae54e0ce4e77f743202d8319381f48786f75ae537047762cece92b428.scope
    621      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1ba4c378_459f_43f9_b711_d8c78d28ca7a.slice/cri-containerd-a21ddebe5d8c914344673aef22a78e9098b02555ad35b0dda9d6655c92b6e1b7.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1ba4c378_459f_43f9_b711_d8c78d28ca7a.slice/cri-containerd-2f4b90c1e4ad268a0ed89c2ab816203e5aa774764f4a7701b125ea0e4935f6da.scope
    76       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61f5bbb0_8b47_4e3a_b5e5_580548927a47.slice/cri-containerd-4c92e52aed9f9bc33ba76345c4ef7a7566d33bb2ba25aa9f2eec51adc905fc56.scope
    80       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61f5bbb0_8b47_4e3a_b5e5_580548927a47.slice/cri-containerd-29122b3232e862bc3ea3a0281a03f2950d4b819ebdac863f4f8369ce3909c7f4.scope
    72       cgroup_device   multi                                          
