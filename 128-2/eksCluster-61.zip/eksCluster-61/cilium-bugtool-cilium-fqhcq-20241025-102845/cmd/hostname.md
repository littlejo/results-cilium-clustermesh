ip-172-31-242-183.eu-west-3.compute.internal
