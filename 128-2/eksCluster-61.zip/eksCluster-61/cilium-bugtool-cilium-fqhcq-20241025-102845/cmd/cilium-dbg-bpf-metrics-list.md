REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     207597    98541975   1132   bpf_host.c
Interface                 INGRESS     9569      751211     677    bpf_overlay.c
Success                   EGRESS      5129      396069     1694   bpf_host.c
Success                   EGRESS      88451     11421461   1308   bpf_lxc.c
Success                   EGRESS      9931      777729     53     encap.h
Success                   INGRESS     103819    12275521   235    trace.h
Success                   INGRESS     98730     11876473   86     l3.h
Unsupported L3 protocol   EGRESS      35        2586       1492   bpf_lxc.c
