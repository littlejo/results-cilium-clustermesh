markdown output at /tmp/cilium-bugtool-20241025-102847.146+0000-UTC-4160250903/cmd/cilium-debuginfo-20241025-102848.496+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102847.146+0000-UTC-4160250903/cmd/cilium-debuginfo-20241025-102848.496+0000-UTC.json
