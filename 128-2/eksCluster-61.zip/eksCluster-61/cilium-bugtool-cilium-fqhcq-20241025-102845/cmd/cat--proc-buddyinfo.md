Node 0, zone      DMA     35     37     36     28     30     29     21     19     11      9    211 
Node 0, zone   Normal      2      2      1      3      2     23     19      7      6      3     12 
