IP ADDRESS         LOCAL ENDPOINT INFO
10.82.0.139:0      id=516   sec_id=4     flags=0x0000 ifindex=10  mac=C6:A5:CB:0B:4F:14 nodemac=BA:14:B6:DB:BC:CF     
172.31.136.111:0   (localhost)                                                                                        
172.31.139.233:0   (localhost)                                                                                        
10.82.0.65:0       id=815   sec_id=5467195 flags=0x0000 ifindex=12  mac=C6:8C:46:C5:43:16 nodemac=7E:D5:82:F6:D1:43   
10.82.0.146:0      (localhost)                                                                                        
10.82.0.95:0       id=66    sec_id=5467195 flags=0x0000 ifindex=14  mac=46:7A:04:C4:0A:19 nodemac=66:D2:51:86:3E:DA   
10.82.0.217:0      id=1254  sec_id=5486641 flags=0x0000 ifindex=18  mac=52:4D:F2:63:44:BA nodemac=4E:23:89:69:09:3E   
