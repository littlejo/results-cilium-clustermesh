top - 10:28:49 up 13 min,  0 users,  load average: 0.24, 0.28, 0.18
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 31.0 us, 37.9 sy,  0.0 ni, 27.6 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   3836.2 total,    795.9 free,    897.7 used,   2142.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2769.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1472496 272368  78088 S  33.3   6.9   0:23.22 cilium-+
    421 root      20   0 1228848   6296   2924 S   0.0   0.2   0:00.26 cilium-+
    629 root      20   0 1240432  15756  11228 S   0.0   0.4   0:00.02 cilium-+
    667 root      20   0    6576   2424   2100 R   0.0   0.1   0:00.00 top
    690 root      20   0 1228744   3660   2976 S   0.0   0.1   0:00.00 gops
    692 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
