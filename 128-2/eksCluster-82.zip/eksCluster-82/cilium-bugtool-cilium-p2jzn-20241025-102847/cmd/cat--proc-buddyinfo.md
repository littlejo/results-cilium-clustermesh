Node 0, zone      DMA      1      2      2      2     14     32     12      3      2      3    171 
Node 0, zone   Normal     63      2     18      2      5     11      7      2      1      6      6 
