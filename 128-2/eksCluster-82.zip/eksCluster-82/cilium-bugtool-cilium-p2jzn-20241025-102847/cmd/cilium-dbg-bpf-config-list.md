KEY             VALUE
AgentLiveness   819293804779
UTimeOffset     3378615841796875
