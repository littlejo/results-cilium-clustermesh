ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.132.191:443 (active)    
                                        2 => 172.31.252.152:443 (active)    
2    10.100.22.125:443   ClusterIP      1 => 172.31.139.233:4244 (active)   
3    10.100.0.10:9153    ClusterIP      1 => 10.82.0.95:9153 (active)       
                                        2 => 10.82.0.65:9153 (active)       
4    10.100.0.10:53      ClusterIP      1 => 10.82.0.95:53 (active)         
                                        2 => 10.82.0.65:53 (active)         
5    10.100.92.11:2379   ClusterIP      1 => 10.82.0.217:2379 (active)      
