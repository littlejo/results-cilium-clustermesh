[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda966952e_d6ca_4711_9a67_3d3a2763f047.slice/cri-containerd-c33da2b5f7e323efa2d88d9bd1b1b35399e6b029dcd1e1188e69a84478540f23.scope"
      }
    ],
    "ips": [
      "10.82.0.65"
    ],
    "name": "coredns-cc6ccd49c-cd7xq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23d0122e_5529_4b18_9d06_15ea6c8f879c.slice/cri-containerd-6058cf88cfd3c6d11a9e7ef75a1084d481ebde5a8787a08d947480faf97ba746.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23d0122e_5529_4b18_9d06_15ea6c8f879c.slice/cri-containerd-6a07d9e77e8baa0ab5e1ce5e9215722a2d36442775d0bf27a3051dc2fddab6ee.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23d0122e_5529_4b18_9d06_15ea6c8f879c.slice/cri-containerd-91b0a4bdf4ccf6f231299d30e481231cb99c3689c36c6c31061ade9519ba3946.scope"
      }
    ],
    "ips": [
      "10.82.0.217"
    ],
    "name": "clustermesh-apiserver-6669554d88-hf76n",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf46980a9_1b0f_4e3a_b12c_748ee664df8c.slice/cri-containerd-86348228477fd13b6770db8886d417a46d2c05e38f95b862e3818cd4f94f24f9.scope"
      }
    ],
    "ips": [
      "10.82.0.95"
    ],
    "name": "coredns-cc6ccd49c-v5956",
    "namespace": "kube-system"
  }
]

