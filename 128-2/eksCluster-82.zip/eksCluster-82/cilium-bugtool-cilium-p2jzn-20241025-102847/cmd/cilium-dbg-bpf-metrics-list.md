REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10095     795473     677    bpf_overlay.c
Interface                 INGRESS     198620    82405963   1132   bpf_host.c
Success                   EGRESS      10797     847099     53     encap.h
Success                   EGRESS      5598      436985     1694   bpf_host.c
Success                   EGRESS      88306     11254240   1308   bpf_lxc.c
Success                   INGRESS     104243    12265853   235    trace.h
Success                   INGRESS     99097     11863459   86     l3.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
