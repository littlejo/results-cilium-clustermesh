{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.727Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.136.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.727Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.139.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.727Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:51.362Z",
  "value": "id=516   sec_id=4     flags=0x0000 ifindex=10  mac=C6:A5:CB:0B:4F:14 nodemac=BA:14:B6:DB:BC:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:51.365Z",
  "value": "id=815   sec_id=5467195 flags=0x0000 ifindex=12  mac=C6:8C:46:C5:43:16 nodemac=7E:D5:82:F6:D1:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:51.434Z",
  "value": "id=66    sec_id=5467195 flags=0x0000 ifindex=14  mac=46:7A:04:C4:0A:19 nodemac=66:D2:51:86:3E:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:51.443Z",
  "value": "id=516   sec_id=4     flags=0x0000 ifindex=10  mac=C6:A5:CB:0B:4F:14 nodemac=BA:14:B6:DB:BC:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:03.639Z",
  "value": "id=516   sec_id=4     flags=0x0000 ifindex=10  mac=C6:A5:CB:0B:4F:14 nodemac=BA:14:B6:DB:BC:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:03.640Z",
  "value": "id=815   sec_id=5467195 flags=0x0000 ifindex=12  mac=C6:8C:46:C5:43:16 nodemac=7E:D5:82:F6:D1:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:03.640Z",
  "value": "id=66    sec_id=5467195 flags=0x0000 ifindex=14  mac=46:7A:04:C4:0A:19 nodemac=66:D2:51:86:3E:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:03.673Z",
  "value": "id=4090  sec_id=5486641 flags=0x0000 ifindex=16  mac=3A:01:11:84:42:84 nodemac=DA:43:AD:B5:EE:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:04.640Z",
  "value": "id=516   sec_id=4     flags=0x0000 ifindex=10  mac=C6:A5:CB:0B:4F:14 nodemac=BA:14:B6:DB:BC:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:04.640Z",
  "value": "id=815   sec_id=5467195 flags=0x0000 ifindex=12  mac=C6:8C:46:C5:43:16 nodemac=7E:D5:82:F6:D1:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:04.640Z",
  "value": "id=4090  sec_id=5486641 flags=0x0000 ifindex=16  mac=3A:01:11:84:42:84 nodemac=DA:43:AD:B5:EE:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:04.640Z",
  "value": "id=66    sec_id=5467195 flags=0x0000 ifindex=14  mac=46:7A:04:C4:0A:19 nodemac=66:D2:51:86:3E:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:28.789Z",
  "value": "id=1254  sec_id=5486641 flags=0x0000 ifindex=18  mac=52:4D:F2:63:44:BA nodemac=4E:23:89:69:09:3E"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.82.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:39.210Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:39.553Z",
  "value": "id=815   sec_id=5467195 flags=0x0000 ifindex=12  mac=C6:8C:46:C5:43:16 nodemac=7E:D5:82:F6:D1:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:39.553Z",
  "value": "id=66    sec_id=5467195 flags=0x0000 ifindex=14  mac=46:7A:04:C4:0A:19 nodemac=66:D2:51:86:3E:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:39.554Z",
  "value": "id=1254  sec_id=5486641 flags=0x0000 ifindex=18  mac=52:4D:F2:63:44:BA nodemac=4E:23:89:69:09:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:39.554Z",
  "value": "id=516   sec_id=4     flags=0x0000 ifindex=10  mac=C6:A5:CB:0B:4F:14 nodemac=BA:14:B6:DB:BC:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:40.553Z",
  "value": "id=1254  sec_id=5486641 flags=0x0000 ifindex=18  mac=52:4D:F2:63:44:BA nodemac=4E:23:89:69:09:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:40.553Z",
  "value": "id=815   sec_id=5467195 flags=0x0000 ifindex=12  mac=C6:8C:46:C5:43:16 nodemac=7E:D5:82:F6:D1:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:40.553Z",
  "value": "id=516   sec_id=4     flags=0x0000 ifindex=10  mac=C6:A5:CB:0B:4F:14 nodemac=BA:14:B6:DB:BC:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:40.554Z",
  "value": "id=66    sec_id=5467195 flags=0x0000 ifindex=14  mac=46:7A:04:C4:0A:19 nodemac=66:D2:51:86:3E:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:41.554Z",
  "value": "id=815   sec_id=5467195 flags=0x0000 ifindex=12  mac=C6:8C:46:C5:43:16 nodemac=7E:D5:82:F6:D1:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:41.554Z",
  "value": "id=66    sec_id=5467195 flags=0x0000 ifindex=14  mac=46:7A:04:C4:0A:19 nodemac=66:D2:51:86:3E:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:41.554Z",
  "value": "id=516   sec_id=4     flags=0x0000 ifindex=10  mac=C6:A5:CB:0B:4F:14 nodemac=BA:14:B6:DB:BC:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:41.554Z",
  "value": "id=1254  sec_id=5486641 flags=0x0000 ifindex=18  mac=52:4D:F2:63:44:BA nodemac=4E:23:89:69:09:3E"
}

