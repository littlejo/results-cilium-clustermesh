CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd86c81b3_a221_440c_8758_ff1ea4352020.slice/cri-containerd-b6835f5858ef780627e6ea5c1e6533bd95c352d81094d1f9debfb81749727ef5.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd86c81b3_a221_440c_8758_ff1ea4352020.slice/cri-containerd-921235a771b3a652d3610ba9df09502cf1d7519f2d06ea1ee6860332dfc36f8b.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod05e315c2_5686_4ee3_b18d_e4a90dea384c.slice/cri-containerd-0f80ecdcda6fa438c4dbb8345c279e273297c71b2f6edb1e64d9dd1cf8e1f7a4.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod05e315c2_5686_4ee3_b18d_e4a90dea384c.slice/cri-containerd-728d57c5e9169eb056dca6783cdd4182b067d43373f721c9223fd2c827cf1e13.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda966952e_d6ca_4711_9a67_3d3a2763f047.slice/cri-containerd-1f95075dfaafa86219b15fedf610c28ee645f48daaf1ec1b8171bb0976fbf3ee.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda966952e_d6ca_4711_9a67_3d3a2763f047.slice/cri-containerd-c33da2b5f7e323efa2d88d9bd1b1b35399e6b029dcd1e1188e69a84478540f23.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf46980a9_1b0f_4e3a_b12c_748ee664df8c.slice/cri-containerd-86348228477fd13b6770db8886d417a46d2c05e38f95b862e3818cd4f94f24f9.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf46980a9_1b0f_4e3a_b12c_748ee664df8c.slice/cri-containerd-d0a7078aa5bf1691f0ada59bd3c389f0bc4af64e755e317a82866477f467e453.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a9fdeac_3976_40d5_a314_58d047014d4a.slice/cri-containerd-efa2270327dcaf635c2bbcc547e9826ac705bd189d381b7e4fb2f88164fe7614.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a9fdeac_3976_40d5_a314_58d047014d4a.slice/cri-containerd-a28b7b2b1a0dd57562871a53855910afbeb1b542869d784d0d2738cbd9df8cd4.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23d0122e_5529_4b18_9d06_15ea6c8f879c.slice/cri-containerd-6058cf88cfd3c6d11a9e7ef75a1084d481ebde5a8787a08d947480faf97ba746.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23d0122e_5529_4b18_9d06_15ea6c8f879c.slice/cri-containerd-6a07d9e77e8baa0ab5e1ce5e9215722a2d36442775d0bf27a3051dc2fddab6ee.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23d0122e_5529_4b18_9d06_15ea6c8f879c.slice/cri-containerd-8234795990b52fa861d082d37f4864b3de74e2e6416037263399ad56f66d5c0b.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23d0122e_5529_4b18_9d06_15ea6c8f879c.slice/cri-containerd-91b0a4bdf4ccf6f231299d30e481231cb99c3689c36c6c31061ade9519ba3946.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c154170_b3a3_414c_8116_d3cc1c9cd604.slice/cri-containerd-9507da9adaee86b6883ef16dbfdd6c11abba27c21c09ff6047cc6ed6e15e8727.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c154170_b3a3_414c_8116_d3cc1c9cd604.slice/cri-containerd-ad40f045d26550f1ef42748d42ca62d2911c5a2cd5419b6abf91420d692e11ba.scope
    91       cgroup_device   multi                                          
