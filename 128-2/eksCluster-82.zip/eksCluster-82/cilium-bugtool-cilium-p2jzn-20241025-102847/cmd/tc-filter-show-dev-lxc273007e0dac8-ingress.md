filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc273007e0dac8 direct-action not_in_hw id 522 tag 65d0f7e865c56911 jited 
