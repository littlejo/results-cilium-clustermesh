1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ec:22:bf:57:ad brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.139.233/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2791sec preferred_lft 2791sec
    inet6 fe80::4ec:22ff:febf:57ad/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:06:2c:9c:2c:d3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.136.111/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::406:2cff:fe9c:2cd3/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:de:bc:4f:72:bd brd ff:ff:ff:ff:ff:ff
    inet6 fe80::90de:bcff:fe4f:72bd/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:c6:bb:c0:34:12 brd ff:ff:ff:ff:ff:ff
    inet 10.82.0.146/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::84c6:bbff:fec0:3412/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 6a:8f:ab:36:7a:14 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::688f:abff:fe36:7a14/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:14:b6:db:bc:cf brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b814:b6ff:fedb:bccf/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc273007e0dac8@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:d5:82:f6:d1:43 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::7cd5:82ff:fef6:d143/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce1d6ea186c6a@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:d2:51:86:3e:da brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::64d2:51ff:fe86:3eda/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc775c58a55f94@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:23:89:69:09:3e brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::4c23:89ff:fe69:93e/64 scope link 
       valid_lft forever preferred_lft forever
