key: 42 00 00 00  value: 28 02 00 00
key: 04 02 00 00  value: 23 02 00 00
key: 2f 03 00 00  value: 13 02 00 00
key: e6 04 00 00  value: 61 02 00 00
Found 4 elements
