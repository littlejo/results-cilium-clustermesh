Endpoint ID: 66
Path: /sys/fs/bpf/tc/globals/cilium_policy_00066

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    67670   780       0        
Allow    Egress      0          ANY          NONE         disabled    13079   135       0        


Endpoint ID: 516
Path: /sys/fs/bpf/tc/globals/cilium_policy_00516

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    407344   5209      0        
Allow    Ingress     1          ANY          NONE         disabled    11004    130       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 815
Path: /sys/fs/bpf/tc/globals/cilium_policy_00815

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    66680   765       0        
Allow    Egress      0          ANY          NONE         disabled    12712   130       0        


Endpoint ID: 928
Path: /sys/fs/bpf/tc/globals/cilium_policy_00928

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1254
Path: /sys/fs/bpf/tc/globals/cilium_policy_01254

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3302420   32302     0        
Allow    Ingress     1          ANY          NONE         disabled    3432914   35030     0        
Allow    Egress      0          ANY          NONE         disabled    4469688   42535     0        


