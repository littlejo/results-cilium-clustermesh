alloc: 73.91MB (77499816 bytes)
total-alloc: 1.32GB (1414776776 bytes)
sys: 198.32MB (207952196 bytes)
lookups: 0
mallocs: 47750745
frees: 47147508
heap-alloc: 73.91MB (77499816 bytes)
heap-sys: 155.25MB (162791424 bytes)
heap-idle: 40.34MB (42303488 bytes)
heap-in-use: 114.91MB (120487936 bytes)
heap-released: 1.03MB (1081344 bytes)
heap-objects: 603237
stack-in-use: 32.75MB (34340864 bytes)
stack-sys: 32.75MB (34340864 bytes)
stack-mspan-inuse: 1.96MB (2052960 bytes)
stack-mspan-sys: 2.41MB (2529600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 968.50KB (991745 bytes)
gc-sys: 5.06MB (5303584 bytes)
next-gc: when heap-alloc >= 144.93MB (151973112 bytes)
last-gc: 2024-10-25 10:28:46.088170498 +0000 UTC
gc-pause-total: 10.519522ms
gc-pause: 70730
gc-pause-end: 1729852126088170498
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.000437652018304927
enable-gc: true
debug-gc: false
