CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc265533f_9c3f_4694_9353_94dcd4a85bb3.slice/cri-containerd-b96bb3d11b750775679306f107f18216f9fc0b0dc3052edc399934136d193575.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc265533f_9c3f_4694_9353_94dcd4a85bb3.slice/cri-containerd-b90bf4b0b26369dbd6e5695300e4c0893a9303d7b032f0e87c4d6ef3365fc575.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca70d10e_bfc9_4978_9512_c66a474bd835.slice/cri-containerd-630033b4ec2ae7a122bd23407e7851dd22bb94f9aba32f554f8e32c680698234.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca70d10e_bfc9_4978_9512_c66a474bd835.slice/cri-containerd-be687823794d8ec4403246371b3bfeba050eec8fb05b0207a7325cfdf59fd007.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf0d487b8_a806_4a31_8afb_26117ec76a13.slice/cri-containerd-f649b9877798f0cfa50ba3c78bc77c18836f92548b0e2ba304f2b532175b1fd6.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf0d487b8_a806_4a31_8afb_26117ec76a13.slice/cri-containerd-56e1c5583adbf7246fd85cf09e7f274b64d9b0460afc7d7475938325f1d45cdf.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6af48cf9_3d50_4a85_bf0b_0a8dbd73f593.slice/cri-containerd-210bb9abaac996f16b7c07e8b5d49da57f7a674fc55116f099ab7252785c3d6f.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6af48cf9_3d50_4a85_bf0b_0a8dbd73f593.slice/cri-containerd-61f95270c8cc190da1b4b864dafd5597ff7b1f39809787b1f739041eac83e80b.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1c99c46d_f50c_4c40_b7f8_2563c5983a49.slice/cri-containerd-61b81864060f16138b9912449636b6f1863f0fe193504a85850f5c1b16b1f1b4.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1c99c46d_f50c_4c40_b7f8_2563c5983a49.slice/cri-containerd-07c97666e95f7587bc47768afe5b72f2c972c468d5454f462e602454059acb78.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1c99c46d_f50c_4c40_b7f8_2563c5983a49.slice/cri-containerd-a51ff1d86f7b5c914651efc045ce705892a43142005fb1ca12947c31abe0823c.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1c99c46d_f50c_4c40_b7f8_2563c5983a49.slice/cri-containerd-6e61b06d5188572adc917a512468b6615f69ce35b7c46d505cc80813f5a16cb1.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9a4da0d_06ab_4276_a7c8_10def1c340a4.slice/cri-containerd-cdaf0fe80017066f4f096e72de848184b847d54dccd9161d7240e4f4ecafe508.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9a4da0d_06ab_4276_a7c8_10def1c340a4.slice/cri-containerd-9700324d40411eaa834dbe186eca27ef472b053d5d01bbdc3406d825996c67b4.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd076b550_aa69_4689_805d_abb53e978a3f.slice/cri-containerd-e7cd3371c2ba66ab8cc9cfd1d464ff5676fa539dbb29d59675b35b5b4d04aafa.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd076b550_aa69_4689_805d_abb53e978a3f.slice/cri-containerd-bde7a25bc78c4ff6e6e592177f2a036842e39d2794ecf0deb0776e941eb52984.scope
    109      cgroup_device   multi                                          
