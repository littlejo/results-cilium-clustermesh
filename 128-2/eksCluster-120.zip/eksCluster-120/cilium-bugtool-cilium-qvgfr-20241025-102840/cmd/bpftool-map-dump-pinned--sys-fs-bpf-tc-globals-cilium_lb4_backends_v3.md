key: 07 00 00 00  value: 0a 78 00 81 23 c1 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 78 00 9e 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 78 00 d0 09 4b 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f df 91 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 78 00 9e 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f 95 e1 10 94 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 78 00 81 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 80 b3 01 bb 00 00  00 00 00 00
Found 8 elements
