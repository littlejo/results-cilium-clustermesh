Total: 580
TCP:   1338 (estab 323, closed 996, orphaned 0, timewait 524)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  342       330       12       
INET	  352       336       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:40743      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=43)) ino:24059 sk:357 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.149.225%ens5:68         0.0.0.0:*    uid:192 ino:14136 sk:358 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:24126 sk:359 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15638 sk:35a cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:24125 sk:35b cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15639 sk:35c cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::41b:a6ff:fef1:c9e9]%ens5:546           [::]:*    uid:192 ino:15828 sk:35d cgroup:unreachable:c4e v6only:1 <->                   
