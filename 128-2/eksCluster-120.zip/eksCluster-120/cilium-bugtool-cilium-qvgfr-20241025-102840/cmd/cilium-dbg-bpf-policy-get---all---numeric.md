Endpoint ID: 88
Path: /sys/fs/bpf/tc/globals/cilium_policy_00088

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    77209   888       0        
Allow    Egress      0          ANY          NONE         disabled    13780   143       0        


Endpoint ID: 554
Path: /sys/fs/bpf/tc/globals/cilium_policy_00554

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3888070   35944     0        
Allow    Ingress     1          ANY          NONE         disabled    2786512   27796     0        
Allow    Egress      0          ANY          NONE         disabled    3960237   36891     0        


Endpoint ID: 1805
Path: /sys/fs/bpf/tc/globals/cilium_policy_01805

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3052
Path: /sys/fs/bpf/tc/globals/cilium_policy_03052

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    77143   887       0        
Allow    Egress      0          ANY          NONE         disabled    13223   137       0        


Endpoint ID: 3259
Path: /sys/fs/bpf/tc/globals/cilium_policy_03259

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    435237   5547      0        
Allow    Ingress     1          ANY          NONE         disabled    11202    130       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


