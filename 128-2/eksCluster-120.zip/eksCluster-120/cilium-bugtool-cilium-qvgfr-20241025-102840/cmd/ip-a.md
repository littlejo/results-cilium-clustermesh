1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:1b:a6:f1:c9:e9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.149.225/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2739sec preferred_lft 2739sec
    inet6 fe80::41b:a6ff:fef1:c9e9/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:51:f3:87:c2:a5 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.168.206/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::451:f3ff:fe87:c2a5/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:fc:51:3b:ad:da brd ff:ff:ff:ff:ff:ff
    inet6 fe80::40fc:51ff:fe3b:adda/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:88:d7:20:bf:4e brd ff:ff:ff:ff:ff:ff
    inet 10.120.0.242/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::bc88:d7ff:fe20:bf4e/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether da:a6:40:c4:c6:fa brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d8a6:40ff:fec4:c6fa/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:f8:6a:16:c4:3f brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::fcf8:6aff:fe16:c43f/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcbb7e7b9632f2@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:89:15:4b:e4:12 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ac89:15ff:fe4b:e412/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc24125f3b9e7a@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:4a:01:88:c3:58 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::184a:1ff:fe88:c358/64 scope link 
       valid_lft forever preferred_lft forever
18: lxced0874e40e1b@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:8c:84:bc:ba:68 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c88c:84ff:febc:ba68/64 scope link 
       valid_lft forever preferred_lft forever
