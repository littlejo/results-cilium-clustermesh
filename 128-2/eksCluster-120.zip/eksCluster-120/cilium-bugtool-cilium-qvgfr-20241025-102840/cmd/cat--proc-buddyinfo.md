Node 0, zone      DMA    144     74     26      7      4      3      2      3      1      2    168 
Node 0, zone   Normal      2      2      1      2      1     12      3      1      1      3      8 
