key: 58 00 00 00  value: 16 02 00 00
key: 2a 02 00 00  value: 85 02 00 00
key: ec 0b 00 00  value: 2f 02 00 00
key: bb 0c 00 00  value: 44 02 00 00
Found 4 elements
