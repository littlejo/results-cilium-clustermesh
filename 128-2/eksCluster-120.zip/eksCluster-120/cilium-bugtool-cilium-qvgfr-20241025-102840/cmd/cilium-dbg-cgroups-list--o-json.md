[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc265533f_9c3f_4694_9353_94dcd4a85bb3.slice/cri-containerd-b90bf4b0b26369dbd6e5695300e4c0893a9303d7b032f0e87c4d6ef3365fc575.scope"
      }
    ],
    "ips": [
      "10.120.0.129"
    ],
    "name": "coredns-cc6ccd49c-jvhz4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podca70d10e_bfc9_4978_9512_c66a474bd835.slice/cri-containerd-630033b4ec2ae7a122bd23407e7851dd22bb94f9aba32f554f8e32c680698234.scope"
      }
    ],
    "ips": [
      "10.120.0.158"
    ],
    "name": "coredns-cc6ccd49c-44p5w",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1c99c46d_f50c_4c40_b7f8_2563c5983a49.slice/cri-containerd-61b81864060f16138b9912449636b6f1863f0fe193504a85850f5c1b16b1f1b4.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1c99c46d_f50c_4c40_b7f8_2563c5983a49.slice/cri-containerd-a51ff1d86f7b5c914651efc045ce705892a43142005fb1ca12947c31abe0823c.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1c99c46d_f50c_4c40_b7f8_2563c5983a49.slice/cri-containerd-6e61b06d5188572adc917a512468b6615f69ce35b7c46d505cc80813f5a16cb1.scope"
      }
    ],
    "ips": [
      "10.120.0.208"
    ],
    "name": "clustermesh-apiserver-78b66fbf65-xpwq2",
    "namespace": "kube-system"
  }
]

