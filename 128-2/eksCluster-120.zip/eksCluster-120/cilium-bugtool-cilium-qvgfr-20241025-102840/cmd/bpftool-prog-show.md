35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:14:13+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:13+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:14:13+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:14:14+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:14:28+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name tail_handle_ipv4  tag 32cad05661e7d8ff  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
485: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
486: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
487: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:15:40+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
516: sched_cls  name cil_from_container  tag 9bef69480498e760  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 162
518: sched_cls  name tail_ipv4_to_endpoint  tag 13228b31053aa34c  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,113,40,37,38
	btf_id 164
519: sched_cls  name __send_drop_notify  tag 52da3de20a9aacf2  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 166
520: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 167
522: sched_cls  name tail_ipv4_ct_egress  tag c20d917cf64fb495  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 168
523: sched_cls  name tail_handle_ipv4  tag 713b2b0d67ce900c  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 170
525: sched_cls  name tail_handle_ipv4_cont  tag d81a8912fee53336  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 171
527: sched_cls  name tail_handle_arp  tag 4b7a6edbdce73bff  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 173
534: sched_cls  name handle_policy  tag 803f52411352a380  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 175
537: sched_cls  name tail_ipv4_ct_ingress  tag b2592e2efb729d56  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 183
538: sched_cls  name tail_handle_arp  tag 57bf3896e31fe180  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 185
539: sched_cls  name __send_drop_notify  tag 796e3021e3ec508f  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 187
540: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,117
	btf_id 188
542: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 191
543: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 192
544: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 189
546: sched_cls  name tail_handle_ipv4_from_host  tag ab511219f693b1c1  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 195
547: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 197
549: sched_cls  name tail_handle_ipv4_from_host  tag ab511219f693b1c1  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 199
550: sched_cls  name __send_drop_notify  tag 796e3021e3ec508f  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 200
553: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 203
554: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 205
555: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 206
556: sched_cls  name tail_handle_ipv4_from_host  tag ab511219f693b1c1  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 207
557: sched_cls  name __send_drop_notify  tag 796e3021e3ec508f  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 208
559: sched_cls  name handle_policy  tag 7b3b12348010a59a  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 194
563: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 215
564: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 216
565: sched_cls  name tail_handle_ipv4_from_host  tag ab511219f693b1c1  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 217
566: sched_cls  name __send_drop_notify  tag 796e3021e3ec508f  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 218
569: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,125
	btf_id 222
570: sched_cls  name tail_handle_ipv4_cont  tag 7da4c78a6347d73f  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,126,41,100,82,83,39,76,74,77,125,40,37,38,81
	btf_id 223
571: sched_cls  name tail_ipv4_to_endpoint  tag c7a3b441a8807948  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 211
572: sched_cls  name tail_ipv4_to_endpoint  tag a137e8a18daef56d  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,126,41,82,83,80,100,39,125,40,37,38
	btf_id 224
573: sched_cls  name tail_handle_ipv4  tag e235cb43a818b5a4  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 225
574: sched_cls  name tail_ipv4_ct_ingress  tag 43f6bc3bd64c79f6  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 226
575: sched_cls  name tail_handle_ipv4_cont  tag efd5333875c8ac2e  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 228
576: sched_cls  name cil_from_container  tag d6d133f745cd0e40  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 229
577: sched_cls  name __send_drop_notify  tag 8da624fd57c52099  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 230
579: sched_cls  name tail_ipv4_ct_ingress  tag beacc495452089c8  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 232
580: sched_cls  name handle_policy  tag d9cecc9926196040  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,125,82,83,126,41,80,100,39,84,75,40,37,38
	btf_id 227
581: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 234
582: sched_cls  name __send_drop_notify  tag 17699fde8c878e05  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 235
583: sched_cls  name tail_ipv4_ct_egress  tag c20d917cf64fb495  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 233
584: sched_cls  name tail_handle_ipv4  tag 8e08eabb78a58b14  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,125
	btf_id 236
585: sched_cls  name cil_from_container  tag 7a32d7c7edf255ce  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 125,76
	btf_id 237
586: sched_cls  name tail_handle_arp  tag 4014998b489e35b7  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,125
	btf_id 238
588: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
591: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
592: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
595: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
596: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
599: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
600: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
603: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
643: sched_cls  name tail_handle_ipv4  tag a68ebd5a5b684995  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,143
	btf_id 253
644: sched_cls  name tail_ipv4_to_endpoint  tag 7ee1c3fab862274f  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,142,41,82,83,80,141,39,143,40,37,38
	btf_id 254
645: sched_cls  name handle_policy  tag d7548f8907566039  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,143,82,83,142,41,80,141,39,84,75,40,37,38
	btf_id 255
646: sched_cls  name tail_ipv4_ct_egress  tag 5d39380d5657b724  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 256
647: sched_cls  name tail_handle_ipv4_cont  tag 52a29d8e842b46c9  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,142,41,141,82,83,39,76,74,77,143,40,37,38,81
	btf_id 257
648: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,143
	btf_id 258
649: sched_cls  name tail_ipv4_ct_ingress  tag da7fca09795fc3f7  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 259
650: sched_cls  name __send_drop_notify  tag 076c7ffa453fa676  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 260
651: sched_cls  name tail_handle_arp  tag e6b11fcb2908d62f  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,143
	btf_id 261
653: sched_cls  name cil_from_container  tag 1b95e29049ebf1ed  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 143,76
	btf_id 263
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
670: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
673: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
674: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
677: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
678: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
681: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
