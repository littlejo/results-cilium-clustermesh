alloc: 122.87MB (128838920 bytes)
total-alloc: 1.31GB (1411545600 bytes)
sys: 206.51MB (216540500 bytes)
lookups: 0
mallocs: 47486722
frees: 46280543
heap-alloc: 122.87MB (128838920 bytes)
heap-sys: 161.39MB (169230336 bytes)
heap-idle: 17.22MB (18055168 bytes)
heap-in-use: 144.17MB (151175168 bytes)
heap-released: 1016.00KB (1040384 bytes)
heap-objects: 1206179
stack-in-use: 34.56MB (36241408 bytes)
stack-sys: 34.56MB (36241408 bytes)
stack-mspan-inuse: 2.23MB (2337600 bytes)
stack-mspan-sys: 2.51MB (2627520 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 879.14KB (900241 bytes)
gc-sys: 5.28MB (5540024 bytes)
next-gc: when heap-alloc >= 168.21MB (176376472 bytes)
last-gc: 2024-10-25 10:28:42.181752428 +0000 UTC
gc-pause-total: 6.138719ms
gc-pause: 198862
gc-pause-end: 1729852122181752428
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.000353404450120379
enable-gc: true
debug-gc: false
