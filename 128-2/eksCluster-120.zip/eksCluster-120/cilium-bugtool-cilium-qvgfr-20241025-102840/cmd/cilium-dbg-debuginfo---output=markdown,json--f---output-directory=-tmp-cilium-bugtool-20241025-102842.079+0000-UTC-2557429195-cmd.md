markdown output at /tmp/cilium-bugtool-20241025-102842.079+0000-UTC-2557429195/cmd/cilium-debuginfo-20241025-102912.898+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102842.079+0000-UTC-2557429195/cmd/cilium-debuginfo-20241025-102912.898+0000-UTC.json
