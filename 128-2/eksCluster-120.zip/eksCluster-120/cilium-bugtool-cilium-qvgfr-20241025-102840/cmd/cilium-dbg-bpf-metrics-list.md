REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     210669    84038395   1132   bpf_host.c
Interface                 INGRESS     9560      746147     677    bpf_overlay.c
Success                   EGRESS      4681      356371     1694   bpf_host.c
Success                   EGRESS      87843     12005943   1308   bpf_lxc.c
Success                   EGRESS      9383      732908     53     encap.h
Success                   INGRESS     104184    12485581   235    trace.h
Success                   INGRESS     98656     12051899   86     l3.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
