{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:37.735Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.149.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:37.735Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.168.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:37.735Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:42.350Z",
  "value": "id=3259  sec_id=4     flags=0x0000 ifindex=10  mac=36:E4:D1:E1:40:86 nodemac=FE:F8:6A:16:C4:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:42.351Z",
  "value": "id=88    sec_id=7963982 flags=0x0000 ifindex=12  mac=7A:94:A3:13:BD:B6 nodemac=AE:89:15:4B:E4:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:42.412Z",
  "value": "id=3052  sec_id=7963982 flags=0x0000 ifindex=14  mac=CE:C0:0E:0A:8A:3C nodemac=1A:4A:01:88:C3:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:42.418Z",
  "value": "id=3259  sec_id=4     flags=0x0000 ifindex=10  mac=36:E4:D1:E1:40:86 nodemac=FE:F8:6A:16:C4:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:20.448Z",
  "value": "id=3052  sec_id=7963982 flags=0x0000 ifindex=14  mac=CE:C0:0E:0A:8A:3C nodemac=1A:4A:01:88:C3:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:20.449Z",
  "value": "id=3259  sec_id=4     flags=0x0000 ifindex=10  mac=36:E4:D1:E1:40:86 nodemac=FE:F8:6A:16:C4:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:20.449Z",
  "value": "id=88    sec_id=7963982 flags=0x0000 ifindex=12  mac=7A:94:A3:13:BD:B6 nodemac=AE:89:15:4B:E4:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:20.477Z",
  "value": "id=501   sec_id=7943068 flags=0x0000 ifindex=16  mac=FA:3B:9E:96:3F:A9 nodemac=06:DB:8D:AF:B1:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:21.448Z",
  "value": "id=88    sec_id=7963982 flags=0x0000 ifindex=12  mac=7A:94:A3:13:BD:B6 nodemac=AE:89:15:4B:E4:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:21.448Z",
  "value": "id=3052  sec_id=7963982 flags=0x0000 ifindex=14  mac=CE:C0:0E:0A:8A:3C nodemac=1A:4A:01:88:C3:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:21.449Z",
  "value": "id=501   sec_id=7943068 flags=0x0000 ifindex=16  mac=FA:3B:9E:96:3F:A9 nodemac=06:DB:8D:AF:B1:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:21.449Z",
  "value": "id=3259  sec_id=4     flags=0x0000 ifindex=10  mac=36:E4:D1:E1:40:86 nodemac=FE:F8:6A:16:C4:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:47.024Z",
  "value": "id=554   sec_id=7943068 flags=0x0000 ifindex=18  mac=AE:6C:B6:58:E2:07 nodemac=CA:8C:84:BC:BA:68"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.120.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.419Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:31.143Z",
  "value": "id=3052  sec_id=7963982 flags=0x0000 ifindex=14  mac=CE:C0:0E:0A:8A:3C nodemac=1A:4A:01:88:C3:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:31.143Z",
  "value": "id=554   sec_id=7943068 flags=0x0000 ifindex=18  mac=AE:6C:B6:58:E2:07 nodemac=CA:8C:84:BC:BA:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:31.144Z",
  "value": "id=3259  sec_id=4     flags=0x0000 ifindex=10  mac=36:E4:D1:E1:40:86 nodemac=FE:F8:6A:16:C4:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:31.146Z",
  "value": "id=88    sec_id=7963982 flags=0x0000 ifindex=12  mac=7A:94:A3:13:BD:B6 nodemac=AE:89:15:4B:E4:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:32.143Z",
  "value": "id=88    sec_id=7963982 flags=0x0000 ifindex=12  mac=7A:94:A3:13:BD:B6 nodemac=AE:89:15:4B:E4:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:32.143Z",
  "value": "id=554   sec_id=7943068 flags=0x0000 ifindex=18  mac=AE:6C:B6:58:E2:07 nodemac=CA:8C:84:BC:BA:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:32.143Z",
  "value": "id=3052  sec_id=7963982 flags=0x0000 ifindex=14  mac=CE:C0:0E:0A:8A:3C nodemac=1A:4A:01:88:C3:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:32.144Z",
  "value": "id=3259  sec_id=4     flags=0x0000 ifindex=10  mac=36:E4:D1:E1:40:86 nodemac=FE:F8:6A:16:C4:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:33.144Z",
  "value": "id=3259  sec_id=4     flags=0x0000 ifindex=10  mac=36:E4:D1:E1:40:86 nodemac=FE:F8:6A:16:C4:3F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:33.144Z",
  "value": "id=88    sec_id=7963982 flags=0x0000 ifindex=12  mac=7A:94:A3:13:BD:B6 nodemac=AE:89:15:4B:E4:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.208:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:33.144Z",
  "value": "id=554   sec_id=7943068 flags=0x0000 ifindex=18  mac=AE:6C:B6:58:E2:07 nodemac=CA:8C:84:BC:BA:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:33.144Z",
  "value": "id=3052  sec_id=7963982 flags=0x0000 ifindex=14  mac=CE:C0:0E:0A:8A:3C nodemac=1A:4A:01:88:C3:58"
}

