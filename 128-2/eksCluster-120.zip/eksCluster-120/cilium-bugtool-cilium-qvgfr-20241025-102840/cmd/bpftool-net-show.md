xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 555
ens6(5) clsact/ingress cil_from_netdev-ens6 id 564
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 553
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 542
cilium_host(7) clsact/egress cil_from_host-cilium_host id 540
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 585
lxcbb7e7b9632f2(12) clsact/ingress cil_from_container-lxcbb7e7b9632f2 id 516
lxc24125f3b9e7a(14) clsact/ingress cil_from_container-lxc24125f3b9e7a id 576
lxced0874e40e1b(18) clsact/ingress cil_from_container-lxced0874e40e1b id 653

flow_dissector:

netfilter:

