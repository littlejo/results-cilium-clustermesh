ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.128.179:443 (active)    
                                          2 => 172.31.223.145:443 (active)    
2    10.100.251.122:443    ClusterIP      1 => 172.31.149.225:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.120.0.129:53 (active)       
                                          2 => 10.120.0.158:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.120.0.129:9153 (active)     
                                          2 => 10.120.0.158:9153 (active)     
5    10.100.119.171:2379   ClusterIP      1 => 10.120.0.208:2379 (active)     
