IP ADDRESS         LOCAL ENDPOINT INFO
10.120.0.208:0     id=554   sec_id=7943068 flags=0x0000 ifindex=18  mac=AE:6C:B6:58:E2:07 nodemac=CA:8C:84:BC:BA:68   
10.120.0.242:0     (localhost)                                                                                        
10.120.0.129:0     id=88    sec_id=7963982 flags=0x0000 ifindex=12  mac=7A:94:A3:13:BD:B6 nodemac=AE:89:15:4B:E4:12   
10.120.0.158:0     id=3052  sec_id=7963982 flags=0x0000 ifindex=14  mac=CE:C0:0E:0A:8A:3C nodemac=1A:4A:01:88:C3:58   
172.31.168.206:0   (localhost)                                                                                        
172.31.149.225:0   (localhost)                                                                                        
10.120.0.130:0     id=3259  sec_id=4     flags=0x0000 ifindex=10  mac=36:E4:D1:E1:40:86 nodemac=FE:F8:6A:16:C4:3F     
