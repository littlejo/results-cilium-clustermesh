CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04c888bb_d00c_465d_a302_4d8bcf65bbe2.slice/cri-containerd-90ffc0ffc764f2b02e659b57273ee2c1688a50c80cbeeb506ac02e0c2bbf7cd7.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04c888bb_d00c_465d_a302_4d8bcf65bbe2.slice/cri-containerd-8692a136a5c7bdd796227b60c60bcd4fde4f63b18fe0a08c1dc14e3a3b584175.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod21fd8f81_19bb_4083_8e10_02b743573339.slice/cri-containerd-b0db96495db04be3df882ee17fdb69668937dee6896638e4b4b308d706dbf6cb.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod21fd8f81_19bb_4083_8e10_02b743573339.slice/cri-containerd-09d556cf94e8f6e9ffcc115456de8e54da3b4322480e3d923954b8760342862b.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod867c7df2_8931_425c_bf43_ffb3eb200bae.slice/cri-containerd-89ad98d1b33ae432815bca12c1a6dc9ec634ff0e9171396f974379515e9c1408.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod867c7df2_8931_425c_bf43_ffb3eb200bae.slice/cri-containerd-33ba5b48ec98cea9d2f6345cf0d3cc64a0b451a88a93f09a5a51c7470f131a06.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaf1c4f54_bdf6_45ab_966f_5ee1dcb2f9fb.slice/cri-containerd-9a52f8efeea706a18412b0cef7c13b10b08d896b99d4f6d0e144c5c379e0d5ec.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaf1c4f54_bdf6_45ab_966f_5ee1dcb2f9fb.slice/cri-containerd-b94319c45774433848767715b5bd69782ce29cc916df278942cfc23bbc514e39.scope
    545      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod807ca712_1b56_4534_8087_680758e38076.slice/cri-containerd-d4e6948c50f9b7d68f4792f3e2b29311c38b348acc9f1e567a87d5ce2585eadd.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod807ca712_1b56_4534_8087_680758e38076.slice/cri-containerd-23da47100544d928deba4ed52fc7cf399ce3a00ed1e73d4c478f7193359af3d9.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8a76ea73_6dc8_4163_b57c_f019e94afaf3.slice/cri-containerd-f0ccf01b57d761c79d56cde49888bd023af7c7c63fb8fee55df449cd2c097b24.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8a76ea73_6dc8_4163_b57c_f019e94afaf3.slice/cri-containerd-adf33f5fa56342bc7fd826dd8cf58767cff0cf4765157e293719ea09f2489ca2.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8a76ea73_6dc8_4163_b57c_f019e94afaf3.slice/cri-containerd-4dc9031061a2ea3954ccc0163d40a020a7f59f874f05a032306c647d9ff981f1.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8a76ea73_6dc8_4163_b57c_f019e94afaf3.slice/cri-containerd-023066266f501ee13a1b24eb6460db3a8b67ef6c726e2f5f4bc9f1bb74fb50ad.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaad286b7_b69f_42f7_b062_8ec64646d730.slice/cri-containerd-e5a5a3435f678ce9373d014ea4dff7a44e861f173548391b5fb7fb852d81c18d.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaad286b7_b69f_42f7_b062_8ec64646d730.slice/cri-containerd-a85ca9026e86ecdebfc4b5daa2561a66989c4f5072baf4cb445a8072882dfe8a.scope
    105      cgroup_device   multi                                          
