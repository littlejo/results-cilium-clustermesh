{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:37.074Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.220.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:37.074Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.224.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:37.074Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:41.402Z",
  "value": "id=1331  sec_id=8008002 flags=0x0000 ifindex=14  mac=5E:3C:BC:DA:9E:85 nodemac=DA:0A:15:2E:0F:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:41.406Z",
  "value": "id=477   sec_id=4     flags=0x0000 ifindex=10  mac=3A:27:1C:19:49:D3 nodemac=EA:1D:8E:74:91:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:41.446Z",
  "value": "id=2667  sec_id=8008002 flags=0x0000 ifindex=12  mac=FE:FB:11:21:B1:1F nodemac=16:08:91:B1:77:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:41.518Z",
  "value": "id=1331  sec_id=8008002 flags=0x0000 ifindex=14  mac=5E:3C:BC:DA:9E:85 nodemac=DA:0A:15:2E:0F:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:41.568Z",
  "value": "id=477   sec_id=4     flags=0x0000 ifindex=10  mac=3A:27:1C:19:49:D3 nodemac=EA:1D:8E:74:91:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.589Z",
  "value": "id=477   sec_id=4     flags=0x0000 ifindex=10  mac=3A:27:1C:19:49:D3 nodemac=EA:1D:8E:74:91:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.589Z",
  "value": "id=1331  sec_id=8008002 flags=0x0000 ifindex=14  mac=5E:3C:BC:DA:9E:85 nodemac=DA:0A:15:2E:0F:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.590Z",
  "value": "id=2667  sec_id=8008002 flags=0x0000 ifindex=12  mac=FE:FB:11:21:B1:1F nodemac=16:08:91:B1:77:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.620Z",
  "value": "id=65    sec_id=8019820 flags=0x0000 ifindex=16  mac=AE:B9:1B:12:76:D1 nodemac=9A:B2:51:76:A7:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.589Z",
  "value": "id=477   sec_id=4     flags=0x0000 ifindex=10  mac=3A:27:1C:19:49:D3 nodemac=EA:1D:8E:74:91:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.589Z",
  "value": "id=65    sec_id=8019820 flags=0x0000 ifindex=16  mac=AE:B9:1B:12:76:D1 nodemac=9A:B2:51:76:A7:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.589Z",
  "value": "id=2667  sec_id=8008002 flags=0x0000 ifindex=12  mac=FE:FB:11:21:B1:1F nodemac=16:08:91:B1:77:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.589Z",
  "value": "id=1331  sec_id=8008002 flags=0x0000 ifindex=14  mac=5E:3C:BC:DA:9E:85 nodemac=DA:0A:15:2E:0F:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:00.685Z",
  "value": "id=234   sec_id=8019820 flags=0x0000 ifindex=18  mac=AE:7F:B5:17:2C:D1 nodemac=46:C6:BF:87:7D:9A"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.121.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:14.543Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.769Z",
  "value": "id=234   sec_id=8019820 flags=0x0000 ifindex=18  mac=AE:7F:B5:17:2C:D1 nodemac=46:C6:BF:87:7D:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.770Z",
  "value": "id=477   sec_id=4     flags=0x0000 ifindex=10  mac=3A:27:1C:19:49:D3 nodemac=EA:1D:8E:74:91:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.770Z",
  "value": "id=1331  sec_id=8008002 flags=0x0000 ifindex=14  mac=5E:3C:BC:DA:9E:85 nodemac=DA:0A:15:2E:0F:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:17.770Z",
  "value": "id=2667  sec_id=8008002 flags=0x0000 ifindex=12  mac=FE:FB:11:21:B1:1F nodemac=16:08:91:B1:77:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.770Z",
  "value": "id=477   sec_id=4     flags=0x0000 ifindex=10  mac=3A:27:1C:19:49:D3 nodemac=EA:1D:8E:74:91:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.770Z",
  "value": "id=234   sec_id=8019820 flags=0x0000 ifindex=18  mac=AE:7F:B5:17:2C:D1 nodemac=46:C6:BF:87:7D:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.770Z",
  "value": "id=2667  sec_id=8008002 flags=0x0000 ifindex=12  mac=FE:FB:11:21:B1:1F nodemac=16:08:91:B1:77:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.770Z",
  "value": "id=1331  sec_id=8008002 flags=0x0000 ifindex=14  mac=5E:3C:BC:DA:9E:85 nodemac=DA:0A:15:2E:0F:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:19.771Z",
  "value": "id=477   sec_id=4     flags=0x0000 ifindex=10  mac=3A:27:1C:19:49:D3 nodemac=EA:1D:8E:74:91:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:19.771Z",
  "value": "id=234   sec_id=8019820 flags=0x0000 ifindex=18  mac=AE:7F:B5:17:2C:D1 nodemac=46:C6:BF:87:7D:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:19.771Z",
  "value": "id=1331  sec_id=8008002 flags=0x0000 ifindex=14  mac=5E:3C:BC:DA:9E:85 nodemac=DA:0A:15:2E:0F:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.121.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:19.772Z",
  "value": "id=2667  sec_id=8008002 flags=0x0000 ifindex=12  mac=FE:FB:11:21:B1:1F nodemac=16:08:91:B1:77:95"
}

