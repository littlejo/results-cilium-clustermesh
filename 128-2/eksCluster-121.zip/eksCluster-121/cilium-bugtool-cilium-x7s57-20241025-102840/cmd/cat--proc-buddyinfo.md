Node 0, zone      DMA      0      1      4      3      4     14     10      2      2      2    164 
Node 0, zone   Normal    219     54     13      6     29     16      2      4      0      1      8 
