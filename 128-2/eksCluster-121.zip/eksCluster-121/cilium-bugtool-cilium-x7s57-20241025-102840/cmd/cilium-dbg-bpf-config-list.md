KEY             VALUE
AgentLiveness   861632738768
UTimeOffset     3378615802734375
