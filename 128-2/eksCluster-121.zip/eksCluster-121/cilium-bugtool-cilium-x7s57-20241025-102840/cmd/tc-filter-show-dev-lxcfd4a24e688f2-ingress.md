filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcfd4a24e688f2 direct-action not_in_hw id 523 tag 5e581c12bcbe19de jited 
