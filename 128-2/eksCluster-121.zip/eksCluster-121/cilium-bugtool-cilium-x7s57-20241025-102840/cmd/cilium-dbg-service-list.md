ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.172.121:443 (active)   
                                         2 => 172.31.218.160:443 (active)   
2    10.100.215.58:443    ClusterIP      1 => 172.31.220.42:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.121.0.129:53 (active)      
                                         2 => 10.121.0.39:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.121.0.129:9153 (active)    
                                         2 => 10.121.0.39:9153 (active)     
5    10.100.22.177:2379   ClusterIP      1 => 10.121.0.206:2379 (active)    
