REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     218506    84765691   1132   bpf_host.c
Interface                 INGRESS     9565      746592     677    bpf_overlay.c
Success                   EGRESS      4698      357549     1694   bpf_host.c
Success                   EGRESS      7560      1194900    86     l3.h
Success                   EGRESS      91880     12262272   1308   bpf_lxc.c
Success                   EGRESS      9425      735659     53     encap.h
Success                   INGRESS     101985    12627556   86     l3.h
Success                   INGRESS     115061    14255405   235    trace.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
