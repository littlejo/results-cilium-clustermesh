key: ea 00 00 00  value: 7a 02 00 00
key: dd 01 00 00  value: 26 02 00 00
key: 33 05 00 00  value: 13 02 00 00
key: 6b 0a 00 00  value: 01 02 00 00
Found 4 elements
