xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 579
ens6(5) clsact/ingress cil_from_netdev-ens6 id 586
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 568
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 560
cilium_host(7) clsact/egress cil_from_host-cilium_host id 564
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 533
lxc1b2f5d289892(12) clsact/ingress cil_from_container-lxc1b2f5d289892 id 516
lxcfd4a24e688f2(14) clsact/ingress cil_from_container-lxcfd4a24e688f2 id 523
lxcbd405af01812(18) clsact/ingress cil_from_container-lxcbd405af01812 id 636

flow_dissector:

netfilter:

