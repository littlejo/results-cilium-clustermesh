USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         682  0.0  0.4 1240432 16628 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         705  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         706  0.0  0.0   3852  1272 ?        R    10:28   0:00  \_ bash -c hostname
root         671  0.0  0.0 1228744 3776 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root         670  0.0  0.0 1228744 3596 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root           1  2.5  7.4 1538100 292036 ?      Ssl  10:16   0:19 cilium-agent --config-dir=/tmp/cilium/config-map
root         406  0.0  0.1 1228848 6016 ?        Sl   10:16   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
