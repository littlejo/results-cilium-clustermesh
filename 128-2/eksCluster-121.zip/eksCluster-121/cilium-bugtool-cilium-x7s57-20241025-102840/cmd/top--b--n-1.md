top - 10:28:42 up 13 min,  0 users,  load average: 0.20, 0.20, 0.16
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 35.7 us, 28.6 sy,  0.0 ni, 28.6 id,  0.0 wa,  0.0 hi,  7.1 si,  0.0 st
MiB Mem :   3836.2 total,    769.6 free,    924.0 used,   2142.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2743.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    747 root      20   0 1244340  20404  14016 S  20.0   0.5   0:00.03 hubble
      1 root      20   0 1538100 292036  78784 S   6.7   7.4   0:19.03 cilium-+
    406 root      20   0 1228848   6016   2872 S   0.0   0.2   0:00.24 cilium-+
    670 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    671 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
    682 root      20   0 1240432  16628  11356 S   0.0   0.4   0:00.02 cilium-+
    717 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    735 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    741 root      20   0    2208    780    700 S   0.0   0.0   0:00.00 timeout
