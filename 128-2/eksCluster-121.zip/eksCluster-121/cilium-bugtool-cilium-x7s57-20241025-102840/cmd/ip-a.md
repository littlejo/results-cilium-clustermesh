1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:94:47:23:4c:b5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.220.42/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2778sec preferred_lft 2778sec
    inet6 fe80::894:47ff:fe23:4cb5/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:dd:5e:f4:d5:69 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.224.95/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8dd:5eff:fef4:d569/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:c2:1a:30:ae:a2 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::80c2:1aff:fe30:aea2/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:8c:32:bc:b0:07 brd ff:ff:ff:ff:ff:ff
    inet 10.121.0.119/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::888c:32ff:febc:b007/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether de:1a:9e:d1:1b:68 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::dc1a:9eff:fed1:1b68/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:1d:8e:74:91:fc brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::e81d:8eff:fe74:91fc/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc1b2f5d289892@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:08:91:b1:77:95 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::1408:91ff:feb1:7795/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcfd4a24e688f2@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:0a:15:2e:0f:77 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d80a:15ff:fe2e:f77/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcbd405af01812@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:c6:bf:87:7d:9a brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::44c6:bfff:fe87:7d9a/64 scope link 
       valid_lft forever preferred_lft forever
