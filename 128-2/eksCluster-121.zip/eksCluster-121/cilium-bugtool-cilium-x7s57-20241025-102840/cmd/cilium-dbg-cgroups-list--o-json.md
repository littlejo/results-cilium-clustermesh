[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod867c7df2_8931_425c_bf43_ffb3eb200bae.slice/cri-containerd-89ad98d1b33ae432815bca12c1a6dc9ec634ff0e9171396f974379515e9c1408.scope"
      }
    ],
    "ips": [
      "10.121.0.129"
    ],
    "name": "coredns-cc6ccd49c-mc8zr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8a76ea73_6dc8_4163_b57c_f019e94afaf3.slice/cri-containerd-023066266f501ee13a1b24eb6460db3a8b67ef6c726e2f5f4bc9f1bb74fb50ad.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8a76ea73_6dc8_4163_b57c_f019e94afaf3.slice/cri-containerd-adf33f5fa56342bc7fd826dd8cf58767cff0cf4765157e293719ea09f2489ca2.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8a76ea73_6dc8_4163_b57c_f019e94afaf3.slice/cri-containerd-f0ccf01b57d761c79d56cde49888bd023af7c7c63fb8fee55df449cd2c097b24.scope"
      }
    ],
    "ips": [
      "10.121.0.206"
    ],
    "name": "clustermesh-apiserver-6bd457c78f-h8tg7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaf1c4f54_bdf6_45ab_966f_5ee1dcb2f9fb.slice/cri-containerd-9a52f8efeea706a18412b0cef7c13b10b08d896b99d4f6d0e144c5c379e0d5ec.scope"
      }
    ],
    "ips": [
      "10.121.0.39"
    ],
    "name": "coredns-cc6ccd49c-8h96d",
    "namespace": "kube-system"
  }
]

