 10:28:42 up 13 min,  0 users,  load average: 0.20, 0.20, 0.16
