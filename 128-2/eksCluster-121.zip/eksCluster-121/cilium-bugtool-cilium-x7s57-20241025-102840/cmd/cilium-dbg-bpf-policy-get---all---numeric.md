Endpoint ID: 234
Path: /sys/fs/bpf/tc/globals/cilium_policy_00234

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3887777   36714     0        
Allow    Ingress     1          ANY          NONE         disabled    2884360   28991     0        
Allow    Egress      0          ANY          NONE         disabled    4670092   43082     0        


Endpoint ID: 249
Path: /sys/fs/bpf/tc/globals/cilium_policy_00249

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 477
Path: /sys/fs/bpf/tc/globals/cilium_policy_00477

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    434005   5529      0        
Allow    Ingress     1          ANY          NONE         disabled    10946    129       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1331
Path: /sys/fs/bpf/tc/globals/cilium_policy_01331

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    204921   1845      0        
Allow    Ingress     1          ANY          NONE         disabled    70375    806       0        
Allow    Egress      0          ANY          NONE         disabled    59145    563       0        


Endpoint ID: 2667
Path: /sys/fs/bpf/tc/globals/cilium_policy_02667

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    214497   1935      0        
Allow    Ingress     1          ANY          NONE         disabled    70428    809       0        
Allow    Egress      0          ANY          NONE         disabled    58919    564       0        


