alloc: 83.37MB (87421296 bytes)
total-alloc: 1.34GB (1442349248 bytes)
sys: 214.38MB (224798036 bytes)
lookups: 0
mallocs: 48100137
frees: 47429548
heap-alloc: 83.37MB (87421296 bytes)
heap-sys: 169.48MB (177717248 bytes)
heap-idle: 50.58MB (53035008 bytes)
heap-in-use: 118.91MB (124682240 bytes)
heap-released: 1.53MB (1605632 bytes)
heap-objects: 670589
stack-in-use: 34.47MB (36143104 bytes)
stack-sys: 34.47MB (36143104 bytes)
stack-mspan-inuse: 1.94MB (2030880 bytes)
stack-mspan-sys: 2.44MB (2562240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 937.75KB (960257 bytes)
gc-sys: 5.17MB (5419288 bytes)
next-gc: when heap-alloc >= 146.89MB (154029480 bytes)
last-gc: 2024-10-25 10:29:00.10968718 +0000 UTC
gc-pause-total: 6.397538ms
gc-pause: 58018
gc-pause-end: 1729852140109687180
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00036091758883199774
enable-gc: true
debug-gc: false
