IP ADDRESS        LOCAL ENDPOINT INFO
172.31.224.95:0   (localhost)                                                                                        
10.121.0.129:0    id=1331  sec_id=8008002 flags=0x0000 ifindex=14  mac=5E:3C:BC:DA:9E:85 nodemac=DA:0A:15:2E:0F:77   
10.121.0.39:0     id=2667  sec_id=8008002 flags=0x0000 ifindex=12  mac=FE:FB:11:21:B1:1F nodemac=16:08:91:B1:77:95   
172.31.220.42:0   (localhost)                                                                                        
10.121.0.119:0    (localhost)                                                                                        
10.121.0.206:0    id=234   sec_id=8019820 flags=0x0000 ifindex=18  mac=AE:7F:B5:17:2C:D1 nodemac=46:C6:BF:87:7D:9A   
10.121.0.254:0    id=477   sec_id=4     flags=0x0000 ifindex=10  mac=3A:27:1C:19:49:D3 nodemac=EA:1D:8E:74:91:FC     
