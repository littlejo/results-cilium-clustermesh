ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.152.157:443 (active)    
                                          2 => 172.31.224.4:443 (active)      
2    10.100.13.127:443     ClusterIP      1 => 172.31.225.158:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.97.0.52:53 (active)         
                                          2 => 10.97.0.251:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.97.0.52:9153 (active)       
                                          2 => 10.97.0.251:9153 (active)      
5    10.100.161.120:2379   ClusterIP      1 => 10.97.0.222:2379 (active)      
