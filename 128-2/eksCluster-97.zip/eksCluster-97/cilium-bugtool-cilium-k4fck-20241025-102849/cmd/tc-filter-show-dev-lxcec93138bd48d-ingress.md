filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcec93138bd48d direct-action not_in_hw id 615 tag 662c88b2c6232740 jited 
