1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:e6:bc:2d:09:8b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.225.158/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2726sec preferred_lft 2726sec
    inet6 fe80::8e6:bcff:fe2d:98b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:a7:a9:58:14:2d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.207.205/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8a7:a9ff:fe58:142d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:a7:93:1a:94:72 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::7ca7:93ff:fe1a:9472/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:9a:df:1a:40:5e brd ff:ff:ff:ff:ff:ff
    inet 10.97.0.95/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a49a:dfff:fe1a:405e/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 42:e2:10:53:7f:78 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::40e2:10ff:fe53:7f78/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:e1:a9:76:66:00 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::90e1:a9ff:fe76:6600/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc4701d294134d@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:47:38:cb:d5:ca brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::847:38ff:fecb:d5ca/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc0714b6e322bc@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:77:0a:99:0d:86 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::7077:aff:fe99:d86/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcec93138bd48d@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:2a:45:4e:55:d3 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::bc2a:45ff:fe4e:55d3/64 scope link 
       valid_lft forever preferred_lft forever
