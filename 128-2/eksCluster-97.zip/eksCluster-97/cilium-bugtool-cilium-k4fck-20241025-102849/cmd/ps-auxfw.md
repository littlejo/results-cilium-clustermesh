USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         676  0.0  0.0 1228744 3596 ?        Ssl  10:28   0:00 /bin/gops stats 1
root         675  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         670  0.0  0.3 1240432 15620 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         704  0.0  0.0   6408  1644 ?        R    10:28   0:00  \_ ps auxfw
root         705  0.0  0.0   2068   240 ?        R    10:28   0:00  \_ hostname
root         653  0.0  0.0 1228744 3780 ?        Ssl  10:28   0:00 /bin/gops stack 1
root         647  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  3.0  7.2 1538100 286068 ?      Ssl  10:15   0:25 cilium-agent --config-dir=/tmp/cilium/config-map
root         417  0.0  0.1 1228848 5940 ?        Sl   10:15   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
