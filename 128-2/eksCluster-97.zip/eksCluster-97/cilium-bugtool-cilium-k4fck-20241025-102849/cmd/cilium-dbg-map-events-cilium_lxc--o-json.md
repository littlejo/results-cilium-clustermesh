{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:22.630Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.207.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:22.630Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.225.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:22.630Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:27.257Z",
  "value": "id=466   sec_id=4     flags=0x0000 ifindex=10  mac=4A:51:C9:12:C9:0D nodemac=92:E1:A9:76:66:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:27.257Z",
  "value": "id=272   sec_id=6429657 flags=0x0000 ifindex=12  mac=B2:F6:7F:C5:FA:8A nodemac=0A:47:38:CB:D5:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:27.259Z",
  "value": "id=272   sec_id=6429657 flags=0x0000 ifindex=12  mac=B2:F6:7F:C5:FA:8A nodemac=0A:47:38:CB:D5:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:27.319Z",
  "value": "id=466   sec_id=4     flags=0x0000 ifindex=10  mac=4A:51:C9:12:C9:0D nodemac=92:E1:A9:76:66:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:34.632Z",
  "value": "id=2080  sec_id=6429657 flags=0x0000 ifindex=14  mac=B2:9D:EC:8C:58:84 nodemac=72:77:0A:99:0D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.960Z",
  "value": "id=272   sec_id=6429657 flags=0x0000 ifindex=12  mac=B2:F6:7F:C5:FA:8A nodemac=0A:47:38:CB:D5:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.960Z",
  "value": "id=466   sec_id=4     flags=0x0000 ifindex=10  mac=4A:51:C9:12:C9:0D nodemac=92:E1:A9:76:66:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.960Z",
  "value": "id=2080  sec_id=6429657 flags=0x0000 ifindex=14  mac=B2:9D:EC:8C:58:84 nodemac=72:77:0A:99:0D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.991Z",
  "value": "id=1272  sec_id=6454857 flags=0x0000 ifindex=16  mac=E6:AE:74:47:E5:8B nodemac=02:E5:3F:8A:C6:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.991Z",
  "value": "id=1272  sec_id=6454857 flags=0x0000 ifindex=16  mac=E6:AE:74:47:E5:8B nodemac=02:E5:3F:8A:C6:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:12.960Z",
  "value": "id=466   sec_id=4     flags=0x0000 ifindex=10  mac=4A:51:C9:12:C9:0D nodemac=92:E1:A9:76:66:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:12.960Z",
  "value": "id=1272  sec_id=6454857 flags=0x0000 ifindex=16  mac=E6:AE:74:47:E5:8B nodemac=02:E5:3F:8A:C6:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:12.961Z",
  "value": "id=272   sec_id=6429657 flags=0x0000 ifindex=12  mac=B2:F6:7F:C5:FA:8A nodemac=0A:47:38:CB:D5:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:12.961Z",
  "value": "id=2080  sec_id=6429657 flags=0x0000 ifindex=14  mac=B2:9D:EC:8C:58:84 nodemac=72:77:0A:99:0D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:00.154Z",
  "value": "id=430   sec_id=6454857 flags=0x0000 ifindex=18  mac=4E:F1:80:C8:B0:7A nodemac=BE:2A:45:4E:55:D3"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.97.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:10.466Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:03.146Z",
  "value": "id=430   sec_id=6454857 flags=0x0000 ifindex=18  mac=4E:F1:80:C8:B0:7A nodemac=BE:2A:45:4E:55:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:03.148Z",
  "value": "id=466   sec_id=4     flags=0x0000 ifindex=10  mac=4A:51:C9:12:C9:0D nodemac=92:E1:A9:76:66:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:03.148Z",
  "value": "id=272   sec_id=6429657 flags=0x0000 ifindex=12  mac=B2:F6:7F:C5:FA:8A nodemac=0A:47:38:CB:D5:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:03.148Z",
  "value": "id=2080  sec_id=6429657 flags=0x0000 ifindex=14  mac=B2:9D:EC:8C:58:84 nodemac=72:77:0A:99:0D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:04.145Z",
  "value": "id=430   sec_id=6454857 flags=0x0000 ifindex=18  mac=4E:F1:80:C8:B0:7A nodemac=BE:2A:45:4E:55:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:04.145Z",
  "value": "id=272   sec_id=6429657 flags=0x0000 ifindex=12  mac=B2:F6:7F:C5:FA:8A nodemac=0A:47:38:CB:D5:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:04.146Z",
  "value": "id=466   sec_id=4     flags=0x0000 ifindex=10  mac=4A:51:C9:12:C9:0D nodemac=92:E1:A9:76:66:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:04.146Z",
  "value": "id=2080  sec_id=6429657 flags=0x0000 ifindex=14  mac=B2:9D:EC:8C:58:84 nodemac=72:77:0A:99:0D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:05.146Z",
  "value": "id=2080  sec_id=6429657 flags=0x0000 ifindex=14  mac=B2:9D:EC:8C:58:84 nodemac=72:77:0A:99:0D:86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:05.146Z",
  "value": "id=430   sec_id=6454857 flags=0x0000 ifindex=18  mac=4E:F1:80:C8:B0:7A nodemac=BE:2A:45:4E:55:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:05.146Z",
  "value": "id=466   sec_id=4     flags=0x0000 ifindex=10  mac=4A:51:C9:12:C9:0D nodemac=92:E1:A9:76:66:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:05.146Z",
  "value": "id=272   sec_id=6429657 flags=0x0000 ifindex=12  mac=B2:F6:7F:C5:FA:8A nodemac=0A:47:38:CB:D5:CA"
}

