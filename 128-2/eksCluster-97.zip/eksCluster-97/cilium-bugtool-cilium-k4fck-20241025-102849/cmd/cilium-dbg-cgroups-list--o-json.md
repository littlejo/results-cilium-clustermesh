[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ad82889_2d84_4a4e_957e_3bdbc5f22667.slice/cri-containerd-8b8c3e0e5c5654ef9bee21ccba4b24c689a32a2f7edb94d0c0e8e0e621f1eb9b.scope"
      }
    ],
    "ips": [
      "10.97.0.251"
    ],
    "name": "coredns-cc6ccd49c-r8k22",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod78dc2954_3336_4bab_8ac8_ea52f67fb240.slice/cri-containerd-a146cc71fb9394ece777368d682bd3cc67b7e3c1a86e82aa2b2cbb988bf5958a.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod78dc2954_3336_4bab_8ac8_ea52f67fb240.slice/cri-containerd-e3b0fd69d42457e3a6821a06b19954a670e000255edfc6b500b21203023147ad.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod78dc2954_3336_4bab_8ac8_ea52f67fb240.slice/cri-containerd-75e6262dd6819c7ba7ce62354b7a03d259f3e6558339b4ab8a080dd381884e0d.scope"
      }
    ],
    "ips": [
      "10.97.0.222"
    ],
    "name": "clustermesh-apiserver-5f4b96578-qqwxf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7535,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6d61cdac_de72_41c7_abf8_887ff87547f5.slice/cri-containerd-15a23311673b910be8d328cd4c8bf1e29d2d76f9e5473b9be68f294e1b0777ad.scope"
      }
    ],
    "ips": [
      "10.97.0.52"
    ],
    "name": "coredns-cc6ccd49c-vfbbz",
    "namespace": "kube-system"
  }
]

