xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 501
ens6(5) clsact/ingress cil_from_netdev-ens6 id 511
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 498
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 489
cilium_host(7) clsact/egress cil_from_host-cilium_host id 485
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 482
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 541
lxc4701d294134d(12) clsact/ingress cil_from_container-lxc4701d294134d id 528
lxc0714b6e322bc(14) clsact/ingress cil_from_container-lxc0714b6e322bc id 563
lxcec93138bd48d(18) clsact/ingress cil_from_container-lxcec93138bd48d id 615

flow_dissector:

netfilter:

