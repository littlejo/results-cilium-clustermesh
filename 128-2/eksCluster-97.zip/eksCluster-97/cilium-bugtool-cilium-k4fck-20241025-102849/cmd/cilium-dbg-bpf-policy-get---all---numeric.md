Endpoint ID: 272
Path: /sys/fs/bpf/tc/globals/cilium_policy_00272

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    78351   903       0        
Allow    Egress      0          ANY          NONE         disabled    14167   149       0        


Endpoint ID: 430
Path: /sys/fs/bpf/tc/globals/cilium_policy_00430

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3897476   36727     0        
Allow    Ingress     1          ANY          NONE         disabled    3091544   31240     0        
Allow    Egress      0          ANY          NONE         disabled    4721462   43774     0        


Endpoint ID: 466
Path: /sys/fs/bpf/tc/globals/cilium_policy_00466

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    445113   5691      0        
Allow    Ingress     1          ANY          NONE         disabled    11092    129       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1759
Path: /sys/fs/bpf/tc/globals/cilium_policy_01759

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2080
Path: /sys/fs/bpf/tc/globals/cilium_policy_02080

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    77405   888       0        
Allow    Egress      0          ANY          NONE         disabled    13940   146       0        


