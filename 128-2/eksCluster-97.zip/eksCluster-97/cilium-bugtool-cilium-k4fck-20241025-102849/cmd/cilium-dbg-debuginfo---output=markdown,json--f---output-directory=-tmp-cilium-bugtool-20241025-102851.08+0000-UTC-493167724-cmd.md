markdown output at /tmp/cilium-bugtool-20241025-102851.08+0000-UTC-493167724/cmd/cilium-debuginfo-20241025-102921.723+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102851.08+0000-UTC-493167724/cmd/cilium-debuginfo-20241025-102921.723+0000-UTC.json
