alloc: 106.16MB (111320544 bytes)
total-alloc: 1.34GB (1434928488 bytes)
sys: 218.38MB (228992340 bytes)
lookups: 0
mallocs: 47892214
frees: 46904980
heap-alloc: 106.16MB (111320544 bytes)
heap-sys: 173.48MB (181911552 bytes)
heap-idle: 41.73MB (43761664 bytes)
heap-in-use: 131.75MB (138149888 bytes)
heap-released: 2.61MB (2736128 bytes)
heap-objects: 987234
stack-in-use: 34.47MB (36143104 bytes)
stack-sys: 34.47MB (36143104 bytes)
stack-mspan-inuse: 2.06MB (2156800 bytes)
stack-mspan-sys: 2.46MB (2578560 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 936.31KB (958785 bytes)
gc-sys: 5.16MB (5415144 bytes)
next-gc: when heap-alloc >= 147.12MB (154267400 bytes)
last-gc: 2024-10-25 10:28:54.973023948 +0000 UTC
gc-pause-total: 6.647669ms
gc-pause: 118525
gc-pause-end: 1729852134973023948
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0003812003942721651
enable-gc: true
debug-gc: false
