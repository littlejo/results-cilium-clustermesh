KEY             VALUE
AgentLiveness   914188663257
UTimeOffset     3378615716796875
