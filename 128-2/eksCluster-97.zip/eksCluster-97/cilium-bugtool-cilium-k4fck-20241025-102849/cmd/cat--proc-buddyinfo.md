Node 0, zone      DMA      2      2      1     15     11     15      8      6      0      2    161 
Node 0, zone   Normal    121      3      2      2      3      2      2      7      3      3      7 
