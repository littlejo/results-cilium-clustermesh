CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0c128d25_63fd_483f_9ae1_c509999232dc.slice/cri-containerd-7fa7314aeb79fc15674c08774e06314f0855ecbcb147cce19650d85e51c5e505.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0c128d25_63fd_483f_9ae1_c509999232dc.slice/cri-containerd-5883f521b4f637e944b00a63b78e883cd2aecca7e910df1a528577f61fbe53cb.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f3a3be9_ae25_4182_bab7_21e8df9ab129.slice/cri-containerd-536e1e550a26d1b865b617868ec91e27ac648b162582027f1636e15c87bfccea.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3f3a3be9_ae25_4182_bab7_21e8df9ab129.slice/cri-containerd-ff315c740819d1167329d82571d43d6d437cfde907b97b53f0bb53e503767d5f.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ad82889_2d84_4a4e_957e_3bdbc5f22667.slice/cri-containerd-1a6712f564cb830492fe7aecd31baf7a5bf571697ad2e92badbf1c5362ca9722.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ad82889_2d84_4a4e_957e_3bdbc5f22667.slice/cri-containerd-8b8c3e0e5c5654ef9bee21ccba4b24c689a32a2f7edb94d0c0e8e0e621f1eb9b.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6d61cdac_de72_41c7_abf8_887ff87547f5.slice/cri-containerd-15a23311673b910be8d328cd4c8bf1e29d2d76f9e5473b9be68f294e1b0777ad.scope
    553      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6d61cdac_de72_41c7_abf8_887ff87547f5.slice/cri-containerd-63e4cee10f43b2ae2b0ba3ec85dd09f1590bb497e54ccbfcb284ba2e56f94673.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddd9267bd_a10f_4d5a_871a_743a845fb33d.slice/cri-containerd-c954b660e82130e5c45b14992a800d8777c7d0bc5783b9998a34db8be132bab4.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddd9267bd_a10f_4d5a_871a_743a845fb33d.slice/cri-containerd-eca7992b506d203a23e50405ddbd3fec1340a01fa883129c6a0bfae2b939ffaf.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb4dc049f_56c0_44d5_8613_f37d26ce8bcb.slice/cri-containerd-67b2c86f05a583a40ad087d01a407bbd203262009f8868400545739d9014d500.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb4dc049f_56c0_44d5_8613_f37d26ce8bcb.slice/cri-containerd-327c3c62bbfddf9112379be875effa4bcda5b56a243a90aba22aacae9d5902f3.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod78dc2954_3336_4bab_8ac8_ea52f67fb240.slice/cri-containerd-a146cc71fb9394ece777368d682bd3cc67b7e3c1a86e82aa2b2cbb988bf5958a.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod78dc2954_3336_4bab_8ac8_ea52f67fb240.slice/cri-containerd-187c992e2961eb487b7bb4fa7b97f596d8382fb03bb2180a468669500faca2fa.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod78dc2954_3336_4bab_8ac8_ea52f67fb240.slice/cri-containerd-75e6262dd6819c7ba7ce62354b7a03d259f3e6558339b4ab8a080dd381884e0d.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod78dc2954_3336_4bab_8ac8_ea52f67fb240.slice/cri-containerd-e3b0fd69d42457e3a6821a06b19954a670e000255edfc6b500b21203023147ad.scope
    642      cgroup_device   multi                                          
