key: 10 01 00 00  value: 04 02 00 00
key: ae 01 00 00  value: 68 02 00 00
key: d2 01 00 00  value: 1f 02 00 00
key: 20 08 00 00  value: 32 02 00 00
Found 4 elements
