top - 10:28:51 up 14 min,  0 users,  load average: 0.06, 0.14, 0.11
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 10.7 us, 25.0 sy,  0.0 ni, 60.7 id,  0.0 wa,  0.0 hi,  3.6 si,  0.0 st
MiB Mem :   3836.2 total,    775.8 free,    918.3 used,   2142.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2748.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 286068  78016 S   6.7   7.3   0:25.11 cilium-+
    417 root      20   0 1228848   5940   2868 S   0.0   0.2   0:00.28 cilium-+
    647 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    653 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
    670 root      20   0 1240432  15876  10832 S   0.0   0.4   0:00.02 cilium-+
    675 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    676 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    715 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    733 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
