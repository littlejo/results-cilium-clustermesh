IP ADDRESS         LOCAL ENDPOINT INFO
172.31.167.92:0    (localhost)                                                                                        
10.88.0.151:0      id=220   sec_id=4     flags=0x0000 ifindex=10  mac=AE:AC:3C:A8:33:28 nodemac=7A:4F:7B:BD:E8:23     
10.88.0.171:0      id=912   sec_id=5869258 flags=0x0000 ifindex=18  mac=9A:F2:D6:BB:D4:E2 nodemac=22:42:4A:3B:4C:A8   
10.88.0.198:0      id=697   sec_id=5885380 flags=0x0000 ifindex=12  mac=6A:44:05:CB:17:57 nodemac=3A:76:38:3E:A4:D2   
172.31.190.222:0   (localhost)                                                                                        
10.88.0.157:0      (localhost)                                                                                        
10.88.0.201:0      id=2045  sec_id=5885380 flags=0x0000 ifindex=14  mac=86:20:32:13:87:7B nodemac=86:CD:39:3D:B4:DF   
