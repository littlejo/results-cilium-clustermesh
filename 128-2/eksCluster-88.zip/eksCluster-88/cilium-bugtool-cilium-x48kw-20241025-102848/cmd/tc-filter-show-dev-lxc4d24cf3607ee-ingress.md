filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc4d24cf3607ee direct-action not_in_hw id 531 tag 9a4e8eae90c823e9 jited 
