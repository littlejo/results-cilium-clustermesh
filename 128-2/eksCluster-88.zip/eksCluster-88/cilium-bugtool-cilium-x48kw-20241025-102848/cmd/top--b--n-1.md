top - 10:28:51 up 14 min,  0 users,  load average: 0.15, 0.23, 0.18
Tasks:   6 total,   2 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 53.3 us, 46.7 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    750.0 free,    945.1 used,   2141.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2722.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 279020  77436 S  40.0   7.1   0:24.55 cilium-+
    418 root      20   0 1228848   6012   2872 S   0.0   0.2   0:00.27 cilium-+
    676 root      20   0 1240176  16432  11484 S   0.0   0.4   0:00.02 cilium-+
    682 root      20   0 1228744   3604   2912 S   0.0   0.1   0:00.00 gops
    733 root      20   0    6576   2424   2100 R   0.0   0.1   0:00.00 top
    744 root      20   0    3880   2252   1864 R   0.0   0.1   0:00.00 iptable+
