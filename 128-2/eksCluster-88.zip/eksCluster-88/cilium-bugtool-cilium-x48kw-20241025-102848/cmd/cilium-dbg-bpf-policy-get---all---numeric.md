Endpoint ID: 207
Path: /sys/fs/bpf/tc/globals/cilium_policy_00207

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 220
Path: /sys/fs/bpf/tc/globals/cilium_policy_00220

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    449982   5751      0        
Allow    Ingress     1          ANY          NONE         disabled    11530    135       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 697
Path: /sys/fs/bpf/tc/globals/cilium_policy_00697

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    77118   889       0        
Allow    Egress      0          ANY          NONE         disabled    12794   132       0        


Endpoint ID: 912
Path: /sys/fs/bpf/tc/globals/cilium_policy_00912

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3822662   36419     0        
Allow    Ingress     1          ANY          NONE         disabled    3420181   34864     0        
Allow    Egress      0          ANY          NONE         disabled    5255815   48477     0        


Endpoint ID: 2045
Path: /sys/fs/bpf/tc/globals/cilium_policy_02045

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    77118   889       0        
Allow    Egress      0          ANY          NONE         disabled    13322   137       0        


