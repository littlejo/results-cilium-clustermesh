{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:51.633Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.167.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:51.633Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.190.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:51.633Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:54.907Z",
  "value": "id=697   sec_id=5885380 flags=0x0000 ifindex=12  mac=6A:44:05:CB:17:57 nodemac=3A:76:38:3E:A4:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:58.076Z",
  "value": "id=220   sec_id=4     flags=0x0000 ifindex=10  mac=AE:AC:3C:A8:33:28 nodemac=7A:4F:7B:BD:E8:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:58.089Z",
  "value": "id=2045  sec_id=5885380 flags=0x0000 ifindex=14  mac=86:20:32:13:87:7B nodemac=86:CD:39:3D:B4:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:58.136Z",
  "value": "id=697   sec_id=5885380 flags=0x0000 ifindex=12  mac=6A:44:05:CB:17:57 nodemac=3A:76:38:3E:A4:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:58.182Z",
  "value": "id=220   sec_id=4     flags=0x0000 ifindex=10  mac=AE:AC:3C:A8:33:28 nodemac=7A:4F:7B:BD:E8:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:58.226Z",
  "value": "id=2045  sec_id=5885380 flags=0x0000 ifindex=14  mac=86:20:32:13:87:7B nodemac=86:CD:39:3D:B4:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:32.757Z",
  "value": "id=697   sec_id=5885380 flags=0x0000 ifindex=12  mac=6A:44:05:CB:17:57 nodemac=3A:76:38:3E:A4:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:32.757Z",
  "value": "id=2045  sec_id=5885380 flags=0x0000 ifindex=14  mac=86:20:32:13:87:7B nodemac=86:CD:39:3D:B4:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:32.758Z",
  "value": "id=220   sec_id=4     flags=0x0000 ifindex=10  mac=AE:AC:3C:A8:33:28 nodemac=7A:4F:7B:BD:E8:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:32.790Z",
  "value": "id=278   sec_id=5869258 flags=0x0000 ifindex=16  mac=7A:A6:9F:3A:6D:E7 nodemac=BE:C0:41:CB:8D:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:33.758Z",
  "value": "id=2045  sec_id=5885380 flags=0x0000 ifindex=14  mac=86:20:32:13:87:7B nodemac=86:CD:39:3D:B4:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:33.758Z",
  "value": "id=278   sec_id=5869258 flags=0x0000 ifindex=16  mac=7A:A6:9F:3A:6D:E7 nodemac=BE:C0:41:CB:8D:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:33.758Z",
  "value": "id=220   sec_id=4     flags=0x0000 ifindex=10  mac=AE:AC:3C:A8:33:28 nodemac=7A:4F:7B:BD:E8:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:33.758Z",
  "value": "id=697   sec_id=5885380 flags=0x0000 ifindex=12  mac=6A:44:05:CB:17:57 nodemac=3A:76:38:3E:A4:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:27.844Z",
  "value": "id=912   sec_id=5869258 flags=0x0000 ifindex=18  mac=9A:F2:D6:BB:D4:E2 nodemac=22:42:4A:3B:4C:A8"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.88.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:33.084Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.942Z",
  "value": "id=220   sec_id=4     flags=0x0000 ifindex=10  mac=AE:AC:3C:A8:33:28 nodemac=7A:4F:7B:BD:E8:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.943Z",
  "value": "id=912   sec_id=5869258 flags=0x0000 ifindex=18  mac=9A:F2:D6:BB:D4:E2 nodemac=22:42:4A:3B:4C:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.944Z",
  "value": "id=697   sec_id=5885380 flags=0x0000 ifindex=12  mac=6A:44:05:CB:17:57 nodemac=3A:76:38:3E:A4:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.945Z",
  "value": "id=2045  sec_id=5885380 flags=0x0000 ifindex=14  mac=86:20:32:13:87:7B nodemac=86:CD:39:3D:B4:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.941Z",
  "value": "id=2045  sec_id=5885380 flags=0x0000 ifindex=14  mac=86:20:32:13:87:7B nodemac=86:CD:39:3D:B4:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.941Z",
  "value": "id=220   sec_id=4     flags=0x0000 ifindex=10  mac=AE:AC:3C:A8:33:28 nodemac=7A:4F:7B:BD:E8:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.941Z",
  "value": "id=912   sec_id=5869258 flags=0x0000 ifindex=18  mac=9A:F2:D6:BB:D4:E2 nodemac=22:42:4A:3B:4C:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.942Z",
  "value": "id=697   sec_id=5885380 flags=0x0000 ifindex=12  mac=6A:44:05:CB:17:57 nodemac=3A:76:38:3E:A4:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:03.941Z",
  "value": "id=2045  sec_id=5885380 flags=0x0000 ifindex=14  mac=86:20:32:13:87:7B nodemac=86:CD:39:3D:B4:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:03.941Z",
  "value": "id=697   sec_id=5885380 flags=0x0000 ifindex=12  mac=6A:44:05:CB:17:57 nodemac=3A:76:38:3E:A4:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:03.941Z",
  "value": "id=220   sec_id=4     flags=0x0000 ifindex=10  mac=AE:AC:3C:A8:33:28 nodemac=7A:4F:7B:BD:E8:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.88.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:03.942Z",
  "value": "id=912   sec_id=5869258 flags=0x0000 ifindex=18  mac=9A:F2:D6:BB:D4:E2 nodemac=22:42:4A:3B:4C:A8"
}

