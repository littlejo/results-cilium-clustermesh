markdown output at /tmp/cilium-bugtool-20241025-102851.151+0000-UTC-63330733/cmd/cilium-debuginfo-20241025-102921.977+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102851.151+0000-UTC-63330733/cmd/cilium-debuginfo-20241025-102921.977+0000-UTC.json
