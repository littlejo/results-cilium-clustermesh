CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod00ec2141_4ed0_46de_8e0e_cbf6c83cc867.slice/cri-containerd-7c89b4fe43a91652adbe2f461cc4d6941c4bfe226c8b4cbbf01e4a6da130bd74.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod00ec2141_4ed0_46de_8e0e_cbf6c83cc867.slice/cri-containerd-f31ce6a23e400f0d3cbc0399e9dd131233957d549b4a54d584c5c64e6b06ba4e.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddda5ed53_2d13_4c24_baaa_1fa1b5f3b4fb.slice/cri-containerd-3bed43de57dbb81d2898c964d9cbd37297818f7885d3d9aa3f0c73c3d2a1d039.scope
    499      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddda5ed53_2d13_4c24_baaa_1fa1b5f3b4fb.slice/cri-containerd-e00b44348f463a520d9fb9b605e9390a637b108e79aff87d48e971d5729196f7.scope
    495      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8219adb9_bfa3_4a3c_8f74_d01286483db4.slice/cri-containerd-54b31eeacee3d6d10d4fdd6ab4a242cec1428b55d972110c0b8cebba68ef1839.scope
    566      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8219adb9_bfa3_4a3c_8f74_d01286483db4.slice/cri-containerd-e5898e5b5cce8754ca6947d3396e5bf2e52503d4ed0cd6c2a302f2e59531d50d.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc2023e2_188f_4c5d_92f1_87d4b6f4f508.slice/cri-containerd-357a744a24c59411b2e5c7d15ad86fda36ad465888b3f7fa6f0bb948983274a1.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc2023e2_188f_4c5d_92f1_87d4b6f4f508.slice/cri-containerd-8ed44d5f4293979cb2bda97c18527eb001cceac594b6943807105735f753814a.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd69f16e6_e7cd_4900_bb1e_83e519cad19d.slice/cri-containerd-b1c02ed7e59deebf79f5431010f3ce7283f7a9120cc4d6a9b91d5a4a9e4a895b.scope
    648      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd69f16e6_e7cd_4900_bb1e_83e519cad19d.slice/cri-containerd-a9ec14de632108c132f094943d42b95f5c21e1b08df42782561fa4a824485c63.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd69f16e6_e7cd_4900_bb1e_83e519cad19d.slice/cri-containerd-0af1acc729107b29d88d6992005e09d88f129f60cc9dcd0052f2614d5425df75.scope
    672      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd69f16e6_e7cd_4900_bb1e_83e519cad19d.slice/cri-containerd-de2c592fe1911db22fb634d7e987fe82600b85d5dcc675529752744e87102b9b.scope
    668      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod59061acc_89f6_4860_9b4c_79a36b76f8ca.slice/cri-containerd-6349b468d107800d072f1cbd350b4ed6780baae447d6d2bf4b18be9bd27389d8.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod59061acc_89f6_4860_9b4c_79a36b76f8ca.slice/cri-containerd-ba28d138cad5ed527ee86d7b8faf99ecb2bcf5b876ba6597ed8f8257da8751a4.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod931bfb62_da13_4c06_8945_d74757100efb.slice/cri-containerd-9ee1c95e8ff0ac87393424ff36fee33dd6570dd5c244c8a60fb8d9901ed3a02d.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod931bfb62_da13_4c06_8945_d74757100efb.slice/cri-containerd-aef364ed3b8ac474fbc714e7ad9c634164516bb55c1f2ee564d98693025a0506.scope
    106      cgroup_device   multi                                          
