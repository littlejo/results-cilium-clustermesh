# Cilium debug information

#### Service list

```
ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.129.235:443 (active)   
                                          2 => 172.31.236.179:443 (active)   
2    10.100.141.45:443     ClusterIP      1 => 172.31.167.92:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.88.0.198:53 (active)       
                                          2 => 10.88.0.201:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.88.0.198:9153 (active)     
                                          2 => 10.88.0.201:9153 (active)     
5    10.100.240.229:2379   ClusterIP      1 => 10.88.0.171:2379 (active)     
```

#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 21025859                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 21025859                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 21025859                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d400000 rw-p 00000000 00:00 0 
400d400000-4010000000 ---p 00000000 00:00 0 
ffff70678000-ffff7084d000 rw-p 00000000 00:00 0 
ffff70854000-ffff709b6000 rw-p 00000000 00:00 0 
ffff709b6000-ffff709f7000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff709f7000-ffff70a38000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff70a38000-ffff70a3a000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff70a3a000-ffff70a3c000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff70a3c000-ffff70ff3000 rw-p 00000000 00:00 0 
ffff70ff3000-ffff710f3000 rw-p 00000000 00:00 0 
ffff710f3000-ffff71104000 rw-p 00000000 00:00 0 
ffff71104000-ffff73104000 rw-p 00000000 00:00 0 
ffff73104000-ffff73184000 ---p 00000000 00:00 0 
ffff73184000-ffff73185000 rw-p 00000000 00:00 0 
ffff73185000-ffff93184000 ---p 00000000 00:00 0 
ffff93184000-ffff93185000 rw-p 00000000 00:00 0 
ffff93185000-ffffb3114000 ---p 00000000 00:00 0 
ffffb3114000-ffffb3115000 rw-p 00000000 00:00 0 
ffffb3115000-ffffb7106000 ---p 00000000 00:00 0 
ffffb7106000-ffffb7107000 rw-p 00000000 00:00 0 
ffffb7107000-ffffb7904000 ---p 00000000 00:00 0 
ffffb7904000-ffffb7905000 rw-p 00000000 00:00 0 
ffffb7905000-ffffb7a04000 ---p 00000000 00:00 0 
ffffb7a04000-ffffb7a64000 rw-p 00000000 00:00 0 
ffffb7a64000-ffffb7a66000 r--p 00000000 00:00 0                          [vvar]
ffffb7a66000-ffffb7a67000 r-xp 00000000 00:00 0                          [vdso]
ffffd9f71000-ffffd9f92000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.88.0.0/24, 
Allocated addresses:
  10.88.0.151 (health)
  10.88.0.157 (router)
  10.88.0.171 (kube-system/clustermesh-apiserver-6cb6c6c7b4-jzrjx)
  10.88.0.198 (kube-system/coredns-cc6ccd49c-st56c)
  10.88.0.201 (kube-system/coredns-cc6ccd49c-gwnwm)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1369f71585c68fd8
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    29s ago        never        0       no error   
  ct-map-pressure                                                     30s ago        never        0       no error   
  daemon-validate-config                                              17s ago        never        0       no error   
  dns-garbage-collector-job                                           32s ago        never        0       no error   
  endpoint-2045-regeneration-recovery                                 never          never        0       no error   
  endpoint-207-regeneration-recovery                                  never          never        0       no error   
  endpoint-220-regeneration-recovery                                  never          never        0       no error   
  endpoint-697-regeneration-recovery                                  never          never        0       no error   
  endpoint-912-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         3m32s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                30s ago        never        0       no error   
  ipcache-inject-labels                                               30s ago        never        0       no error   
  k8s-heartbeat                                                       32s ago        never        0       no error   
  link-cache                                                          15s ago        never        0       no error   
  local-identity-checkpoint                                           13m30s ago     never        0       no error   
  node-neighbor-link-updater                                          10s ago        never        0       no error   
  remote-etcd-cmesh1                                                  7m19s ago      never        0       no error   
  remote-etcd-cmesh10                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh100                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh101                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh102                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh103                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh104                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh105                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh106                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh107                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh108                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh109                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh11                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh110                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh111                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh112                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh113                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh114                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh115                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh116                                                7m20s ago      never        0       no error   
  remote-etcd-cmesh117                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh118                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh119                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh12                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh120                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh121                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh122                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh123                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh124                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh125                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh126                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh127                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh128                                                7m19s ago      never        0       no error   
  remote-etcd-cmesh13                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh14                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh15                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh16                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh17                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh18                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh19                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh2                                                  7m19s ago      never        0       no error   
  remote-etcd-cmesh20                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh21                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh22                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh23                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh24                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh25                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh26                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh27                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh28                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh29                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh3                                                  7m19s ago      never        0       no error   
  remote-etcd-cmesh30                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh31                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh32                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh33                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh34                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh35                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh36                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh37                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh38                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh39                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh4                                                  7m19s ago      never        0       no error   
  remote-etcd-cmesh40                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh41                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh42                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh43                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh44                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh45                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh46                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh47                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh48                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh49                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh5                                                  7m19s ago      never        0       no error   
  remote-etcd-cmesh50                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh51                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh52                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh53                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh54                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh55                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh56                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh57                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh58                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh59                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh6                                                  7m19s ago      never        0       no error   
  remote-etcd-cmesh60                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh61                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh62                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh63                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh64                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh65                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh66                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh67                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh68                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh69                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh7                                                  7m19s ago      never        0       no error   
  remote-etcd-cmesh70                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh71                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh72                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh73                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh74                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh75                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh76                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh77                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh78                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh79                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh8                                                  7m19s ago      never        0       no error   
  remote-etcd-cmesh80                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh81                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh82                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh83                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh84                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh85                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh86                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh87                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh88                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh9                                                  7m19s ago      never        0       no error   
  remote-etcd-cmesh90                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh91                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh92                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh93                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh94                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh95                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh96                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh97                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh98                                                 7m19s ago      never        0       no error   
  remote-etcd-cmesh99                                                 7m19s ago      never        0       no error   
  resolve-identity-2045                                               3m29s ago      never        0       no error   
  resolve-identity-207                                                3m30s ago      never        0       no error   
  resolve-identity-220                                                3m29s ago      never        0       no error   
  resolve-identity-697                                                3m29s ago      never        0       no error   
  resolve-identity-912                                                2m54s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-6cb6c6c7b4-jzrjx   7m54s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-gwnwm                  13m29s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-st56c                  13m29s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      13m30s ago     never        0       no error   
  sync-policymap-2045                                                 13m23s ago     never        0       no error   
  sync-policymap-207                                                  13m29s ago     never        0       no error   
  sync-policymap-220                                                  13m23s ago     never        0       no error   
  sync-policymap-697                                                  13m27s ago     never        0       no error   
  sync-policymap-912                                                  7m54s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (2045)                                   9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (697)                                    9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (912)                                    14s ago        never        0       no error   
  sync-utime                                                          30s ago        never        0       no error   
  write-cni-file                                                      13m32s ago     never        0       no error   
Proxy Status:            OK, ip 10.88.0.157, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 5832704, max 5898239
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 82.79   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
dnsproxy-socket-linger-timeout:10
policy-queue-size:100
nat-map-stats-entries:32
disable-endpoint-crd:false
enable-service-topology:false
nodes-gc-interval:5m0s
bgp-config-path:/var/lib/cilium/bgp/config.yaml
identity-allocation-mode:crd
k8s-client-connection-keep-alive:30s
read-cni-conf:
kvstore-connectivity-timeout:2m0s
bpf-lb-sock:false
hubble-prefer-ipv6:false
dns-max-ips-per-restored-rule:1000
multicast-enabled:false
enable-route-mtu-for-cni-chaining:false
k8s-require-ipv6-pod-cidr:false
enable-ipsec-key-watcher:true
bpf-ct-global-any-max:262144
cmdref:
l2-announcements-lease-duration:15s
hubble-event-queue-size:0
cluster-health-port:4240
hubble-metrics:
bpf-lb-algorithm:random
ipv4-service-loopback-address:169.254.42.1
node-labels:
enable-ip-masq-agent:false
enable-bbr:false
enable-ipv6-ndp:false
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
auto-create-cilium-node-resource:true
hubble-redact-http-userinfo:true
ipam-multi-pool-pre-allocation:
encryption-strict-mode-allow-remote-node-identities:false
enable-well-known-identities:false
enable-gateway-api:false
prometheus-serve-addr:
enable-ipsec-xfrm-state-caching:true
identity-gc-interval:15m0s
enable-ipv6-big-tcp:false
tofqdns-proxy-port:0
kvstore-max-consecutive-quorum-errors:2
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
nodeport-addresses:
http-idle-timeout:0
clustermesh-enable-mcs-api:false
crd-wait-timeout:5m0s
max-controller-interval:0
node-port-algorithm:random
exclude-node-label-patterns:
prepend-iptables-chains:true
lib-dir:/var/lib/cilium
allow-localhost:auto
enable-cilium-endpoint-slice:false
enable-l2-announcements:false
encrypt-node:false
tofqdns-proxy-response-max-delay:100ms
enable-k8s-api-discovery:false
config-sources:config-map:kube-system/cilium-config
static-cnp-path:
bpf-lb-rss-ipv6-src-cidr:
mke-cgroup-mount:
hubble-drop-events-interval:2m0s
enable-bpf-clock-probe:false
ipv6-node:auto
labels:
enable-policy:default
tofqdns-max-deferred-connection-deletes:10000
enable-health-checking:true
hubble-skip-unknown-cgroup-ids:true
disable-external-ip-mitigation:false
clustermesh-config:/var/lib/cilium/clustermesh/
hubble-export-file-compress:false
bpf-ct-timeout-service-tcp-grace:1m0s
trace-sock:true
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
mesh-auth-gc-interval:5m0s
hubble-recorder-storage-path:/var/run/cilium/pcaps
enable-ipsec:false
ipv6-range:auto
http-normalize-path:true
hubble-export-file-path:
use-full-tls-context:false
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
agent-liveness-update-interval:1s
nat-map-stats-interval:30s
enable-bpf-tproxy:false
bpf-events-policy-verdict-enabled:true
annotate-k8s-node:false
http-retry-timeout:0
bpf-lb-rss-ipv4-src-cidr:
remove-cilium-node-taints:true
bpf-lb-external-clusterip:false
hubble-redact-http-headers-allow:
enable-envoy-config:false
node-port-mode:snat
clustermesh-sync-timeout:1m0s
pprof:false
node-port-bind-protection:true
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
proxy-admin-port:0
enable-ipv4:true
preallocate-bpf-maps:false
dns-policy-unload-on-shutdown:false
vlan-bpf-bypass:
config-dir:/tmp/cilium/config-map
enable-stale-cilium-endpoint-cleanup:true
ipv4-service-range:auto
proxy-connect-timeout:2
enable-health-check-nodeport:true
enable-external-ips:false
enable-ipsec-encrypted-overlay:false
enable-masquerade-to-route-source:false
monitor-aggregation-flags:all
enable-xt-socket-fallback:true
ipv6-cluster-alloc-cidr:f00d::/64
conntrack-gc-max-interval:0s
cni-external-routing:false
hubble-listen-address::4244
custom-cni-conf:false
enable-active-connection-tracking:false
hubble-redact-http-urlquery:false
dnsproxy-enable-transparent-mode:true
mesh-auth-mutual-connect-timeout:5s
conntrack-gc-interval:0s
enable-ipv4-masquerade:true
enable-node-selector-labels:false
hubble-export-file-max-size-mb:10
log-system-load:false
local-max-addr-scope:252
tofqdns-endpoint-max-ip-per-hostname:50
enable-wireguard-userspace-fallback:false
enable-hubble-recorder-api:true
proxy-idle-timeout-seconds:60
ip-masq-agent-config-path:/etc/config/ip-masq-agent
endpoint-bpf-prog-watchdog-interval:30s
ipsec-key-rotation-duration:5m0s
enable-cilium-api-server-access:
identity-heartbeat-timeout:30m0s
bpf-ct-timeout-regular-any:1m0s
operator-prometheus-serve-addr::9963
pprof-address:localhost
enable-monitor:true
mesh-auth-rotated-identities-queue-size:1024
enable-cilium-health-api-server-access:
bpf-ct-timeout-service-tcp:2h13m20s
enable-session-affinity:false
external-envoy-proxy:true
enable-l2-pod-announcements:false
bpf-auth-map-max:524288
kvstore-lease-ttl:15m0s
vtep-mac:
cluster-pool-ipv4-mask-size:24
force-device-detection:false
kube-proxy-replacement-healthz-bind-address:
certificates-directory:/var/run/cilium/certs
hubble-disable-tls:false
bpf-lb-rev-nat-map-max:0
vtep-mask:
envoy-config-timeout:2m0s
tofqdns-pre-cache:
bpf-lb-service-backend-map-max:0
ipam-default-ip-pool:default
hubble-redact-http-headers-deny:
join-cluster:false
bpf-ct-timeout-regular-tcp-fin:10s
service-no-backend-response:reject
bpf-ct-global-tcp-max:524288
hubble-export-allowlist:
envoy-log:
kvstore:
tofqdns-min-ttl:0
proxy-xff-num-trusted-hops-egress:0
mesh-auth-signal-backoff-duration:1s
k8s-api-server:
routing-mode:tunnel
hubble-export-fieldmask:
bpf-map-dynamic-size-ratio:0.0025
bpf-ct-timeout-regular-tcp-syn:1m0s
config:
bpf-ct-timeout-service-any:1m0s
pprof-port:6060
tofqdns-enable-dns-compression:true
ipv4-node:auto
fqdn-regex-compile-lru-size:1024
enable-icmp-rules:true
exclude-local-address:
enable-bgp-control-plane:false
dnsproxy-concurrency-limit:0
enable-hubble:true
bpf-lb-mode:snat
enable-endpoint-routes:false
k8s-sync-timeout:3m0s
enable-srv6:false
enable-pmtu-discovery:false
direct-routing-device:
agent-health-port:9879
kube-proxy-replacement:false
enable-k8s-networkpolicy:true
allocator-list-timeout:3m0s
enable-vtep:false
gateway-api-secrets-namespace:
debug:false
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
envoy-secrets-namespace:
keep-config:false
log-driver:
hubble-recorder-sink-queue-size:1024
k8s-client-burst:20
unmanaged-pod-watcher-interval:15
bpf-events-drop-enabled:true
egress-gateway-reconciliation-trigger-interval:1s
bpf-node-map-max:16384
endpoint-queue-size:25
controller-group-metrics:
restore:true
enable-wireguard:false
monitor-aggregation-interval:5s
cni-chaining-mode:none
version:false
container-ip-local-reserved-ports:auto
route-metric:0
bgp-announce-pod-cidr:false
devices:
max-connected-clusters:255
bpf-ct-timeout-regular-tcp:2h13m20s
mesh-auth-enabled:true
cflags:
bpf-lb-affinity-map-max:0
proxy-portrange-min:10000
ipsec-key-file:
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
dnsproxy-lock-timeout:500ms
envoy-config-retry-interval:15s
max-internal-timer-delay:0s
wireguard-persistent-keepalive:0s
cluster-pool-ipv4-cidr:10.88.0.0/16
derive-masq-ip-addr-from-device:
enable-mke:false
enable-xdp-prefilter:false
hubble-redact-kafka-apikey:false
k8s-namespace:kube-system
node-port-acceleration:disabled
bpf-lb-maglev-table-size:16381
enable-k8s-terminating-endpoint:true
enable-recorder:false
enable-ipip-termination:false
cni-log-file:/var/run/cilium/cilium-cni.log
ipv6-service-range:auto
debug-verbose:
enable-ipv6-masquerade:true
bpf-lb-service-map-max:0
enable-ipv4-big-tcp:false
procfs:/host/proc
proxy-max-connection-duration-seconds:0
label-prefix-file:
enable-l7-proxy:true
hubble-export-denylist:
cni-exclusive:true
enable-health-check-loadbalancer-ip:false
envoy-base-id:0
identity-restore-grace-period:30s
cni-chaining-target:
mtu:0
encryption-strict-mode-cidr:
state-dir:/var/run/cilium
enable-tracing:false
k8s-client-connection-timeout:30s
socket-path:/var/run/cilium/cilium.sock
monitor-queue-size:0
iptables-lock-timeout:5s
bpf-lb-dsr-dispatch:opt
bpf-events-trace-enabled:true
mesh-auth-mutual-listener-port:0
proxy-portrange-max:20000
hubble-drop-events:false
bgp-announce-lb-ip:false
enable-k8s:true
ipv6-mcast-device:
mesh-auth-spire-admin-socket:
l2-announcements-retry-period:2s
enable-unreachable-routes:false
ipv4-native-routing-cidr:
arping-refresh-period:30s
bpf-root:/sys/fs/bpf
k8s-heartbeat-timeout:30s
node-port-range:
ipv6-native-routing-cidr:
egress-masquerade-interfaces:ens+
enable-local-redirect-policy:false
fixed-identity-mapping:
tofqdns-idle-connection-grace-period:0s
vtep-cidr:
enable-identity-mark:true
enable-host-firewall:false
policy-accounting:true
ingress-secrets-namespace:
direct-routing-skip-unreachable:false
envoy-keep-cap-netbindservice:false
hubble-event-buffer-capacity:4095
enable-host-legacy-routing:false
enable-nat46x64-gateway:false
clustermesh-enable-endpoint-sync:false
encrypt-interface:
tunnel-port:0
operator-api-serve-addr:127.0.0.1:9234
enable-ipv6:false
local-router-ipv6:
proxy-max-requests-per-connection:0
cilium-endpoint-gc-interval:5m0s
bpf-policy-map-full-reconciliation-interval:15m0s
enable-metrics:true
enable-high-scale-ipcache:false
l2-pod-announcements-interface:
dnsproxy-concurrency-processing-grace-period:0s
bpf-neigh-global-max:524288
log-opt:
tofqdns-dns-reject-response-code:refused
identity-change-grace-period:5s
bpf-lb-dsr-l4-xlate:frontend
http-request-timeout:3600
enable-svc-source-range-check:true
enable-local-node-route:true
enable-l2-neigh-discovery:true
egress-multi-home-ip-rule-compat:false
dnsproxy-lock-count:131
bpf-map-event-buffers:
mesh-auth-spiffe-trust-domain:spiffe.cilium
l2-announcements-renew-deadline:5s
proxy-xff-num-trusted-hops-ingress:0
ipv4-pod-subnets:
ipv6-pod-subnets:
gops-port:9890
bpf-lb-map-max:65536
endpoint-gc-interval:5m0s
k8s-client-qps:10
ipam:cluster-pool
enable-auto-protect-node-port-range:true
proxy-prometheus-port:0
enable-ipv4-egress-gateway:false
hubble-export-file-max-backups:5
clustermesh-ip-identities-sync-timeout:1m0s
kvstore-periodic-sync:5m0s
disable-iptables-feeder-rules:
enable-sctp:false
synchronize-k8s-nodes:true
api-rate-limit:
dnsproxy-insecure-skip-transparent-mode-check:false
enable-tcx:true
disable-envoy-version-check:false
enable-ipv4-fragment-tracking:true
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
http-retry-count:3
bpf-nat-global-max:524288
use-cilium-internal-ip-for-ipsec:false
cluster-id:89
enable-encryption-strict-mode:false
tunnel-protocol:vxlan
auto-direct-node-routes:false
k8s-service-proxy-name:
policy-cidr-match-mode:
k8s-require-ipv4-pod-cidr:false
bpf-lb-source-range-map-max:0
proxy-gid:1337
bpf-lb-maglev-map-max:0
enable-runtime-device-detection:true
cgroup-root:/run/cilium/cgroupv2
hubble-monitor-events:
ipam-cilium-node-update-rate:15s
local-router-ipv4:
hubble-metrics-server:
vtep-endpoint:
enable-bpf-masquerade:false
k8s-kubeconfig-path:
set-cilium-node-taints:true
enable-ingress-controller:false
cluster-name:cmesh89
bpf-sock-rev-map-max:262144
enable-k8s-endpoint-slice:true
enable-bandwidth-manager:false
policy-trigger-interval:1s
trace-payloadlen:128
allow-icmp-frag-needed:true
ipv4-range:auto
egress-gateway-policy-map-max:16384
bpf-lb-sock-hostns-only:false
bypass-ip-availability-upon-restore:false
bpf-fragments-map-max:8192
bpf-filter-priority:1
enable-endpoint-health-checking:true
enable-custom-calls:false
srv6-encap-mode:reduced
bpf-lb-acceleration:disabled
bpf-policy-map-max:16384
hubble-drop-events-reasons:auth_required,policy_denied
install-no-conntrack-iptables-rules:false
mesh-auth-queue-size:1024
set-cilium-is-up-condition:true
k8s-service-cache-size:128
hubble-socket-path:/var/run/cilium/hubble.sock
enable-host-port:false
kvstore-opt:
hubble-flowlogs-config-path:
metrics:
monitor-aggregation:medium
http-max-grpc-timeout:0
hubble-redact-enabled:false
datapath-mode:veth
agent-labels:
enable-node-port:false
policy-audit-mode:false
bpf-lb-sock-terminate-pod-connections:false
iptables-random-fully:false
install-iptables-rules:true
```


#### Cilium encryption



#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
207        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                
                                                           reserved:host                                                                                             
220        Disabled           Disabled          4          reserved:health                                                                     10.88.0.151   ready   
697        Disabled           Disabled          5885380    k8s:eks.amazonaws.com/component=coredns                                             10.88.0.198   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh89                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
912        Disabled           Disabled          5869258    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.88.0.171   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh89                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
2045       Disabled           Disabled          5885380    k8s:eks.amazonaws.com/component=coredns                                             10.88.0.201   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh89                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
```

#### BPF Policy Get 207

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 207

```
Invalid argument: unknown type 207
```


#### Endpoint Get 207

```
[
  {
    "id": 207,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-207-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d50771d5-852d-4ad7-893d-be08aab0a5c4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-207",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:51.805Z",
            "success-count": 3
          },
          "uuid": "e33fa0ff-c1ba-4a90-9bd6-b3f718a2e0ef"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-207",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:52.918Z",
            "success-count": 1
          },
          "uuid": "479fe12b-245c-4d35-81de-90212e3222bc"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:03Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "12:66:d2:b2:e1:89",
        "interface-name": "cilium_host",
        "mac": "12:66:d2:b2:e1:89"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 207

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 207

```
Timestamp              Status   State                   Message
2024-10-25T10:22:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:03Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:55Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:15:52Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:51Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:51Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:51Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 220

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    448796   5736      0        
Allow    Ingress     1          ANY          NONE         disabled    11530    135       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 220

```
Invalid argument: unknown type 220
```


#### Endpoint Get 220

```
[
  {
    "id": 220,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-220-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "aa1af4ea-79f8-4115-a973-68f9e32914e0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-220",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:52.879Z",
            "success-count": 3
          },
          "uuid": "5af74402-1ecf-4d89-876c-38bd1f1c440c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-220",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:58.077Z",
            "success-count": 1
          },
          "uuid": "ccdabce1-90c1-4773-88b5-ff1a8b60b2be"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:03Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.88.0.151",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "7a:4f:7b:bd:e8:23",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "ae:ac:3c:a8:33:28"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 220

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 220

```
Timestamp              Status   State                   Message
2024-10-25T10:22:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:03Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:15:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:58Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:15:58Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:15:54Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:15:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:52Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:51Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 697

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    77118   889       0        
Allow    Egress      0          ANY          NONE         disabled    12794   132       0        

```


#### BPF CT List 697

```
Invalid argument: unknown type 697
```


#### Endpoint Get 697

```
[
  {
    "id": 697,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-697-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b8be6945-4300-46aa-b61b-b092c0b1e801"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-697",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:52.559Z",
            "success-count": 3
          },
          "uuid": "2d15c4c2-02f1-4991-9563-495c0d17de08"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-st56c",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:52.556Z",
            "success-count": 1
          },
          "uuid": "8732244a-1021-461a-896d-29f4e4596a96"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-697",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:54.907Z",
            "success-count": 1
          },
          "uuid": "3b0e8076-3bc4-49f2-9604-ea9153c8f809"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (697)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:22.640Z",
            "success-count": 83
          },
          "uuid": "153ef011-9085-4a0e-9bd0-f19b182ec7c5"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "e00b44348f463a520d9fb9b605e9390a637b108e79aff87d48e971d5729196f7:eth0",
        "container-id": "e00b44348f463a520d9fb9b605e9390a637b108e79aff87d48e971d5729196f7",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-st56c",
        "pod-name": "kube-system/coredns-cc6ccd49c-st56c"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5885380,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh89",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh89",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:03Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.88.0.198",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "3a:76:38:3e:a4:d2",
        "interface-index": 12,
        "interface-name": "lxc4d24cf3607ee",
        "mac": "6a:44:05:cb:17:57"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5885380,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5885380,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 697

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 697

```
Timestamp              Status    State                   Message
2024-10-25T10:22:03Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:03Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:03Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:22:03Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:02Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:33Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:33Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:33Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:33Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:32Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:32Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:32Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:32Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:55Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:54Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:52Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:52Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:15:52Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:52Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 5885380

```
ID        LABELS
5885380   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh89
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 912

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3821214   36403     0        
Allow    Ingress     1          ANY          NONE         disabled    3420181   34864     0        
Allow    Egress      0          ANY          NONE         disabled    5253709   48454     0        

```


#### BPF CT List 912

```
Invalid argument: unknown type 912
```


#### Endpoint Get 912

```
[
  {
    "id": 912,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-912-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f9921bc8-725a-4055-91e1-a17fdf7d413a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-912",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:27.816Z",
            "success-count": 2
          },
          "uuid": "ff3b50dd-2c44-4127-998d-e4b9d956f6ce"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-6cb6c6c7b4-jzrjx",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:27.813Z",
            "success-count": 1
          },
          "uuid": "7dc28ca2-8808-4b85-9f1a-f3eec599b19c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-912",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:27.845Z",
            "success-count": 1
          },
          "uuid": "fd35c8df-4b79-402f-95b2-3b8c5ddfa84b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (912)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:17.876Z",
            "success-count": 49
          },
          "uuid": "b612beb0-8395-4b79-82ab-42f83aea7629"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "b1c02ed7e59deebf79f5431010f3ce7283f7a9120cc4d6a9b91d5a4a9e4a895b:eth0",
        "container-id": "b1c02ed7e59deebf79f5431010f3ce7283f7a9120cc4d6a9b91d5a4a9e4a895b",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-6cb6c6c7b4-jzrjx",
        "pod-name": "kube-system/clustermesh-apiserver-6cb6c6c7b4-jzrjx"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5869258,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh89",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6cb6c6c7b4"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh89",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:03Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.88.0.171",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "22:42:4a:3b:4c:a8",
        "interface-index": 18,
        "interface-name": "lxc546cd1a262cb",
        "mac": "9a:f2:d6:bb:d4:e2"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5869258,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5869258,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 912

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 912

```
Timestamp              Status   State                   Message
2024-10-25T10:22:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:03Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:27Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:27Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:27Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 5869258

```
ID        LABELS
5869258   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh89
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 2045

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    77118   889       0        
Allow    Egress      0          ANY          NONE         disabled    13322   137       0        

```


#### BPF CT List 2045

```
Invalid argument: unknown type 2045
```


#### Endpoint Get 2045

```
[
  {
    "id": 2045,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2045-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b455467a-6eb6-4bc9-a415-0cc2b0932003"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2045",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:52.642Z",
            "success-count": 3
          },
          "uuid": "85a155d4-aff0-460b-a8a7-dcefd73bf31f"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-gwnwm",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:52.641Z",
            "success-count": 1
          },
          "uuid": "3b882d99-4c1a-4078-8267-b7409bf3b538"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2045",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:15:58.097Z",
            "success-count": 1
          },
          "uuid": "c841343c-2046-41a7-92db-6472de63b6a1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2045)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:22.713Z",
            "success-count": 83
          },
          "uuid": "1543f6c1-713f-46d7-84c9-bd4512077bbd"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "e5898e5b5cce8754ca6947d3396e5bf2e52503d4ed0cd6c2a302f2e59531d50d:eth0",
        "container-id": "e5898e5b5cce8754ca6947d3396e5bf2e52503d4ed0cd6c2a302f2e59531d50d",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-gwnwm",
        "pod-name": "kube-system/coredns-cc6ccd49c-gwnwm"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5885380,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh89",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh89",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:03Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.88.0.201",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "86:cd:39:3d:b4:df",
        "interface-index": 14,
        "interface-name": "lxc15c822b734d5",
        "mac": "86:20:32:13:87:7b"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5885380,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5885380,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2045

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2045

```
Timestamp              Status   State                   Message
2024-10-25T10:22:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:03Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:58Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:15:55Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:15:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:52Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:15:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:15:52Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:15:52Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 5885380

```
ID        LABELS
5885380   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh89
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.88.0.198": (string) (len=35) "kube-system/coredns-cc6ccd49c-st56c",
  (string) (len=11) "10.88.0.201": (string) (len=35) "kube-system/coredns-cc6ccd49c-gwnwm",
  (string) (len=11) "10.88.0.171": (string) (len=50) "kube-system/clustermesh-apiserver-6cb6c6c7b4-jzrjx",
  (string) (len=11) "10.88.0.157": (string) (len=6) "router",
  (string) (len=11) "10.88.0.151": (string) (len=6) "health"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.167.92": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001c60630)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001792540,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001792540,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x400267be40)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4001c604d0)(frontends:[10.100.141.45]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4001c606e0)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x400272d760)(frontends:[]/ports=[kvmesh-metrics etcd-metrics apiserv-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x400304ba20)(frontends:[10.100.240.229]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x40006588c8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-hlbdh": (*k8s.Endpoints)(0x40010ef5f0)(172.31.167.92:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x40006588d0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-shcm6": (*k8s.Endpoints)(0x4000ef11e0)(10.88.0.198:53/TCP[eu-west-3a],10.88.0.198:53/UDP[eu-west-3a],10.88.0.198:9153/TCP[eu-west-3a],10.88.0.201:53/TCP[eu-west-3a],10.88.0.201:53/UDP[eu-west-3a],10.88.0.201:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001313230)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-v2mkl": (*k8s.Endpoints)(0x40036e5c70)(10.88.0.171:2379/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x40006588c0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4000cc0000)(172.31.129.235:443/TCP,172.31.236.179:443/TCP)
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x40025da0e0)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4002806910)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400995e930
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4002816120,
  gcExited: (chan struct {}) 0x4002816180,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4002585a80)({
     ObserverVec: (*prometheus.HistogramVec)(0x40006590a0)({
      MetricVec: (*prometheus.MetricVec)(0x4000c701e0)({
       metricMap: (*prometheus.metricMap)(0x4000c70210)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002529c80)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4002585b00)({
     ObserverVec: (*prometheus.HistogramVec)(0x40006590a8)({
      MetricVec: (*prometheus.MetricVec)(0x4000c70270)({
       metricMap: (*prometheus.metricMap)(0x4000c702a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002529ce0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4002585b80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40006590b0)({
      MetricVec: (*prometheus.MetricVec)(0x4000c70300)({
       metricMap: (*prometheus.metricMap)(0x4000c70330)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002529d40)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4002585c00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40006590b8)({
      MetricVec: (*prometheus.MetricVec)(0x4000c70390)({
       metricMap: (*prometheus.metricMap)(0x4000c703f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002529da0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4002585c80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40006590c0)({
      MetricVec: (*prometheus.MetricVec)(0x4000c70450)({
       metricMap: (*prometheus.metricMap)(0x4000c70480)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002529e00)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4002585d00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40006590c8)({
      MetricVec: (*prometheus.MetricVec)(0x4000c70510)({
       metricMap: (*prometheus.metricMap)(0x4000c70540)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002529e60)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4002585d80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40006590d0)({
      MetricVec: (*prometheus.MetricVec)(0x4000c705a0)({
       metricMap: (*prometheus.metricMap)(0x4000c705d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002529ec0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4002585e00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40006590d8)({
      MetricVec: (*prometheus.MetricVec)(0x4000c70660)({
       metricMap: (*prometheus.metricMap)(0x4000c70690)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4002529f20)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4002585e80)({
     ObserverVec: (*prometheus.HistogramVec)(0x40006590e0)({
      MetricVec: (*prometheus.MetricVec)(0x4000c70750)({
       metricMap: (*prometheus.metricMap)(0x4000c70780)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400232a000)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x40025da0e0)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40025db260)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001b67938)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 369ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   },
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations

