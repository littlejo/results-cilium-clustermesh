[
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd69f16e6_e7cd_4900_bb1e_83e519cad19d.slice/cri-containerd-de2c592fe1911db22fb634d7e987fe82600b85d5dcc675529752744e87102b9b.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd69f16e6_e7cd_4900_bb1e_83e519cad19d.slice/cri-containerd-a9ec14de632108c132f094943d42b95f5c21e1b08df42782561fa4a824485c63.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd69f16e6_e7cd_4900_bb1e_83e519cad19d.slice/cri-containerd-0af1acc729107b29d88d6992005e09d88f129f60cc9dcd0052f2614d5425df75.scope"
      }
    ],
    "ips": [
      "10.88.0.171"
    ],
    "name": "clustermesh-apiserver-6cb6c6c7b4-jzrjx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7619,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddda5ed53_2d13_4c24_baaa_1fa1b5f3b4fb.slice/cri-containerd-3bed43de57dbb81d2898c964d9cbd37297818f7885d3d9aa3f0c73c3d2a1d039.scope"
      }
    ],
    "ips": [
      "10.88.0.198"
    ],
    "name": "coredns-cc6ccd49c-st56c",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8219adb9_bfa3_4a3c_8f74_d01286483db4.slice/cri-containerd-54b31eeacee3d6d10d4fdd6ab4a242cec1428b55d972110c0b8cebba68ef1839.scope"
      }
    ],
    "ips": [
      "10.88.0.201"
    ],
    "name": "coredns-cc6ccd49c-gwnwm",
    "namespace": "kube-system"
  }
]

