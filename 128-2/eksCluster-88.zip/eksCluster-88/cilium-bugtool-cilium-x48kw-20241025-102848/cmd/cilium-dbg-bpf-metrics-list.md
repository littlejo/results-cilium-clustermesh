REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10370     810915     677    bpf_overlay.c
Interface                 INGRESS     225746    85972684   1132   bpf_host.c
Success                   EGRESS      10569     824978     53     encap.h
Success                   EGRESS      5156      396627     1694   bpf_host.c
Success                   EGRESS      96904     12633497   1308   bpf_lxc.c
Success                   INGRESS     107867    13298951   86     l3.h
Success                   INGRESS     113603    13747747   235    trace.h
Unsupported L3 protocol   EGRESS      37        2742       1492   bpf_lxc.c
