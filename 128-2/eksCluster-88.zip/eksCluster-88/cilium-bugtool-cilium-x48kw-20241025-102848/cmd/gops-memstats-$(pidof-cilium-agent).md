alloc: 137.60MB (144281880 bytes)
total-alloc: 1.38GB (1480458160 bytes)
sys: 222.38MB (233186644 bytes)
lookups: 0
mallocs: 48449842
frees: 47145305
heap-alloc: 137.60MB (144281880 bytes)
heap-sys: 177.48MB (186105856 bytes)
heap-idle: 22.05MB (23126016 bytes)
heap-in-use: 155.43MB (162979840 bytes)
heap-released: 5.53MB (5799936 bytes)
heap-objects: 1304537
stack-in-use: 34.47MB (36143104 bytes)
stack-sys: 34.47MB (36143104 bytes)
stack-mspan-inuse: 2.30MB (2410400 bytes)
stack-mspan-sys: 2.49MB (2611200 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 912.81KB (934713 bytes)
gc-sys: 5.15MB (5402784 bytes)
next-gc: when heap-alloc >= 144.50MB (151523096 bytes)
last-gc: 2024-10-25 10:28:50.532498465 +0000 UTC
gc-pause-total: 11.391574ms
gc-pause: 109973
gc-pause-end: 1729852130532498465
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0003725147252948888
enable-gc: true
debug-gc: false
