key: dc 00 00 00  value: 23 02 00 00
key: b9 02 00 00  value: 12 02 00 00
key: 90 03 00 00  value: 7d 02 00 00
key: fd 07 00 00  value: 2f 02 00 00
Found 4 elements
