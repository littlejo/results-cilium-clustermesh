Node 0, zone      DMA     54     52     26      0    149    150     51     20      7      4    151 
Node 0, zone   Normal    320     21     21      3     13      8      5      6      2      0      8 
