ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.129.235:443 (active)   
                                          2 => 172.31.236.179:443 (active)   
2    10.100.141.45:443     ClusterIP      1 => 172.31.167.92:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.88.0.198:53 (active)       
                                          2 => 10.88.0.201:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.88.0.198:9153 (active)     
                                          2 => 10.88.0.201:9153 (active)     
5    10.100.240.229:2379   ClusterIP      1 => 10.88.0.171:2379 (active)     
