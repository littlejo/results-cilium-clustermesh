REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     212124    84199790   1132   bpf_host.c
Interface                 INGRESS     9521      743685     677    bpf_overlay.c
Success                   EGRESS      4518      344709     1694   bpf_host.c
Success                   EGRESS      87104     11998580   1308   bpf_lxc.c
Success                   EGRESS      9377      732424     53     encap.h
Success                   EGRESS      9422      1489291    86     l3.h
Success                   INGRESS     114008    13954650   235    trace.h
Success                   INGRESS     99061     12031875   86     l3.h
Unsupported L3 protocol   EGRESS      42        3188       1492   bpf_lxc.c
