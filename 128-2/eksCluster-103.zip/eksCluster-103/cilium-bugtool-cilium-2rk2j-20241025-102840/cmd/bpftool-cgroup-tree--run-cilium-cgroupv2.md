CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8c2871ac_607d_4212_9dde_7b9f1c63fc9c.slice/cri-containerd-0e24a739d51bcdc9cd6f06fabdfbfeaf6f790915c1eef15c35ad025ac8fe08b1.scope
    586      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8c2871ac_607d_4212_9dde_7b9f1c63fc9c.slice/cri-containerd-71a88637c0f34fd8676b3379b83da93e2672a478b140260c114a3624c44495db.scope
    582      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2229f6c9_ee27_40fd_ad9e_8f33532d3a7b.slice/cri-containerd-2995753c94a80e75e274d6ef2870d387e2c3b8a459424370142c52bc404c1a70.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2229f6c9_ee27_40fd_ad9e_8f33532d3a7b.slice/cri-containerd-f36cdf3cb7d78f002a13ec2efabd30e122fa820287353ce4a58744f626c31a26.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda90abe01_0f6f_4f70_a77f_c2a5bd14cf71.slice/cri-containerd-5b25033172c4fa5aa6f1c0691b2ce04ce5f28266ae4010608b1ff15d75e3c116.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda90abe01_0f6f_4f70_a77f_c2a5bd14cf71.slice/cri-containerd-cd97855297a039be0dc9a5269a4c1bb9be22ef0801c8b1cf465289a6b8f1fe67.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod805bcaae_12cc_4ea0_8b3b_70105df99148.slice/cri-containerd-4fe51d3e9526547c28dfda107a59fb6c001e7d54b454471b3220818a7821ec36.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod805bcaae_12cc_4ea0_8b3b_70105df99148.slice/cri-containerd-597d2d92a5b45a88a05cf446a2d8d7826750c1e8b5f663833defd347afc28390.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2fd8bdf6_1287_439f_bf43_d3bf5b2ce210.slice/cri-containerd-fc979a3577f97c728b770afac13ecf22e02e9bde0b2de9949f08f7b42b8322ad.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2fd8bdf6_1287_439f_bf43_d3bf5b2ce210.slice/cri-containerd-e085edf193d79c4c5e0468c4752609b004a8cdd1ac88de967da295a0bb5f8193.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86d81b9c_0969_449c_8d49_064c32c15595.slice/cri-containerd-b95c6aa48ee3873097d1cde2b40a2b52a28dfeb1c367e8905a3abdac92d42756.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86d81b9c_0969_449c_8d49_064c32c15595.slice/cri-containerd-b781aec5f2364bf97f23a3fd117a1a090b698c8e5942e49237f704d0a610cbb0.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86d81b9c_0969_449c_8d49_064c32c15595.slice/cri-containerd-c6b4b52180a09e0f3ad3b79808faf4b032bf7b3035e00d284fbb3533a34262ac.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86d81b9c_0969_449c_8d49_064c32c15595.slice/cri-containerd-854767224fd277196e5240135d581052416721d1d5e4f75e9d97dd1ac5313499.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod28d1b45d_bf5b_4054_8544_c05fbf5a1f9a.slice/cri-containerd-d7f1f3dacb75fc02ddf19e85be436acd408801230186f5247cd651d18b11f4d9.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod28d1b45d_bf5b_4054_8544_c05fbf5a1f9a.slice/cri-containerd-241ba4add49b229d266f682f23791fa745dab04a2b9956cbb27d3eb615ea5384.scope
    101      cgroup_device   multi                                          
