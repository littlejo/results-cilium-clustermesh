Node 0, zone      DMA     51     20      2      2      2      5      4      3      0      4    165 
Node 0, zone   Normal    487     59      9     18     14      8      2      3      3      2      7 
