Endpoint ID: 460
Path: /sys/fs/bpf/tc/globals/cilium_policy_00460

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    434606   5539      0        
Allow    Ingress     1          ANY          NONE         disabled    11812    139       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 588
Path: /sys/fs/bpf/tc/globals/cilium_policy_00588

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    265221   2394      0        
Allow    Ingress     1          ANY          NONE         disabled    78343    898       0        
Allow    Egress      0          ANY          NONE         disabled    62404    599       0        


Endpoint ID: 690
Path: /sys/fs/bpf/tc/globals/cilium_policy_00690

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3850020   35249     0        
Allow    Ingress     1          ANY          NONE         disabled    2902569   29246     0        
Allow    Egress      0          ANY          NONE         disabled    3555617   33287     0        


Endpoint ID: 939
Path: /sys/fs/bpf/tc/globals/cilium_policy_00939

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2826
Path: /sys/fs/bpf/tc/globals/cilium_policy_02826

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    257533   2317      0        
Allow    Ingress     1          ANY          NONE         disabled    76654    876       0        
Allow    Egress      0          ANY          NONE         disabled    61821    593       0        


