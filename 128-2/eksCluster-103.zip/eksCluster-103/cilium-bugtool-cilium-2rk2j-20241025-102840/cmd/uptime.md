 10:28:41 up 14 min,  0 users,  load average: 0.00, 0.06, 0.09
