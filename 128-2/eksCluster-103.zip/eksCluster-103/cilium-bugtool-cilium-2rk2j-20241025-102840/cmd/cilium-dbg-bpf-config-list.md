KEY             VALUE
AgentLiveness   906032273197
UTimeOffset     3378615714843750
