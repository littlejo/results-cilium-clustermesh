ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.252.244:443 (active)   
                                          2 => 172.31.154.168:443 (active)   
2    10.100.56.164:443     ClusterIP      1 => 172.31.216.37:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.103.0.191:9153 (active)    
                                          2 => 10.103.0.247:9153 (active)    
4    10.100.0.10:53        ClusterIP      1 => 10.103.0.191:53 (active)      
                                          2 => 10.103.0.247:53 (active)      
5    10.100.111.235:2379   ClusterIP      1 => 10.103.0.234:2379 (active)    
