alloc: 77.93MB (81710632 bytes)
total-alloc: 1.35GB (1449029184 bytes)
sys: 206.38MB (216409428 bytes)
lookups: 0
mallocs: 48133690
frees: 47544661
heap-alloc: 77.93MB (81710632 bytes)
heap-sys: 161.45MB (169295872 bytes)
heap-idle: 45.98MB (48209920 bytes)
heap-in-use: 115.48MB (121085952 bytes)
heap-released: 3.45MB (3612672 bytes)
heap-objects: 589029
stack-in-use: 34.50MB (36175872 bytes)
stack-sys: 34.50MB (36175872 bytes)
stack-mspan-inuse: 1.88MB (1976320 bytes)
stack-mspan-sys: 2.44MB (2562240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 938.96KB (961497 bytes)
gc-sys: 5.16MB (5406904 bytes)
next-gc: when heap-alloc >= 148.14MB (155336264 bytes)
last-gc: 2024-10-25 10:29:05.850664936 +0000 UTC
gc-pause-total: 7.511613ms
gc-pause: 59611
gc-pause-end: 1729852145850664936
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.00036770060442091164
enable-gc: true
debug-gc: false
