key: 08 00 00 00  value: 0a 67 00 bf 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 67 00 bf 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f 9a a8 01 bb 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 67 00 f7 23 c1 00 00  00 00 00 00
key: 0d 00 00 00  value: 0a 67 00 ea 09 4b 00 00  00 00 00 00
key: 0a 00 00 00  value: 0a 67 00 f7 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: ac 1f d8 25 10 94 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f fc f4 01 bb 00 00  00 00 00 00
Found 8 elements
