1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:ce:b6:3b:ea:75 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.216.37/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2738sec preferred_lft 2738sec
    inet6 fe80::8ce:b6ff:fe3b:ea75/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:32:40:71:5d:97 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.220.111/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::832:40ff:fe71:5d97/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:f7:f1:ce:e8:f4 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::34f7:f1ff:fece:e8f4/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:2a:4f:8c:00:d4 brd ff:ff:ff:ff:ff:ff
    inet 10.103.0.65/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::302a:4fff:fe8c:d4/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 72:9c:dd:1e:a3:d0 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::709c:ddff:fe1e:a3d0/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:0b:f4:bc:9b:45 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::680b:f4ff:febc:9b45/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcc3f1aaaed38c@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:e8:31:e6:66:54 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::1ce8:31ff:fee6:6654/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc901ee7932a0d@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:74:cc:66:fa:87 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::e474:ccff:fe66:fa87/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc34dcd3b870a8@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:28:fc:39:04:76 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::a828:fcff:fe39:476/64 scope link 
       valid_lft forever preferred_lft forever
