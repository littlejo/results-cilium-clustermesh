xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 554
ens6(5) clsact/ingress cil_from_netdev-ens6 id 565
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 547
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 541
cilium_host(7) clsact/egress cil_from_host-cilium_host id 543
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 531
lxcc3f1aaaed38c(12) clsact/ingress cil_from_container-lxcc3f1aaaed38c id 516
lxc901ee7932a0d(14) clsact/ingress cil_from_container-lxc901ee7932a0d id 571
lxc34dcd3b870a8(18) clsact/ingress cil_from_container-lxc34dcd3b870a8 id 635

flow_dissector:

netfilter:

