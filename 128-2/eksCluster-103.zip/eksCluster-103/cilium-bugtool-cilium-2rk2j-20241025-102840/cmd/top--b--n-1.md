top - 10:28:41 up 14 min,  0 users,  load average: 0.00, 0.06, 0.09
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 21.2 us, 21.2 sy,  0.0 ni, 57.6 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    794.0 free,    899.8 used,   2142.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2767.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    669 root      20   0 1240432  16576  11356 S   6.2   0.4   0:00.02 cilium-+
      1 root      20   0 1538100 274872  77816 S   0.0   7.0   0:24.08 cilium-+
    396 root      20   0 1228848   5808   2928 S   0.0   0.1   0:00.26 cilium-+
    649 root      20   0 1228744   3716   3040 S   0.0   0.1   0:00.00 gops
    659 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    696 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    714 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
