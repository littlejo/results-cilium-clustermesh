Total: 560
TCP:   1093 (estab 310, closed 764, orphaned 0, timewait 292)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  329       320       9        
INET	  339       326       13       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                            127.0.0.1:41621      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:23487 sk:1 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.216.37%ens5:68         0.0.0.0:*    uid:192 ino:16415 sk:2 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:24648 sk:3 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:13159 sk:4 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:24647 sk:1001 cgroup:/ v6only:1 <->                                      
UNCONN 0      0                                [::1]:323           [::]:*    ino:13160 sk:1002 cgroup:unreachable:f0c v6only:1 <->                        
UNCONN 0      0      [fe80::8ce:b6ff:fe3b:ea75]%ens5:546           [::]:*    uid:192 ino:16413 sk:1003 cgroup:unreachable:c4e v6only:1 <->                
