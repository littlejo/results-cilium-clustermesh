key: cc 01 00 00  value: 10 02 00 00
key: 4c 02 00 00  value: 03 02 00 00
key: b2 02 00 00  value: 72 02 00 00
key: 0a 0b 00 00  value: 39 02 00 00
Found 4 elements
