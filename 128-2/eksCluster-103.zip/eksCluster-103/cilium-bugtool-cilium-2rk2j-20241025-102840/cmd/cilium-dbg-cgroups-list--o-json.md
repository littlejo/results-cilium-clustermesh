[
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8c2871ac_607d_4212_9dde_7b9f1c63fc9c.slice/cri-containerd-0e24a739d51bcdc9cd6f06fabdfbfeaf6f790915c1eef15c35ad025ac8fe08b1.scope"
      }
    ],
    "ips": [
      "10.103.0.247"
    ],
    "name": "coredns-cc6ccd49c-9sgb2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9220,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86d81b9c_0969_449c_8d49_064c32c15595.slice/cri-containerd-854767224fd277196e5240135d581052416721d1d5e4f75e9d97dd1ac5313499.scope"
      },
      {
        "cgroup-id": 9136,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86d81b9c_0969_449c_8d49_064c32c15595.slice/cri-containerd-c6b4b52180a09e0f3ad3b79808faf4b032bf7b3035e00d284fbb3533a34262ac.scope"
      },
      {
        "cgroup-id": 9304,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod86d81b9c_0969_449c_8d49_064c32c15595.slice/cri-containerd-b781aec5f2364bf97f23a3fd117a1a090b698c8e5942e49237f704d0a610cbb0.scope"
      }
    ],
    "ips": [
      "10.103.0.234"
    ],
    "name": "clustermesh-apiserver-6774c89bd-rz5s6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7540,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2229f6c9_ee27_40fd_ad9e_8f33532d3a7b.slice/cri-containerd-f36cdf3cb7d78f002a13ec2efabd30e122fa820287353ce4a58744f626c31a26.scope"
      }
    ],
    "ips": [
      "10.103.0.191"
    ],
    "name": "coredns-cc6ccd49c-twbn8",
    "namespace": "kube-system"
  }
]

