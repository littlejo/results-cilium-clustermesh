USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         669  0.0  0.4 1240432 16576 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         685  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         659  0.0  0.1 1228744 4040 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         649  0.0  0.0 1228744 3716 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  2.9  6.9 1538100 274872 ?      Ssl  10:15   0:24 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.0  0.1 1228848 5808 ?        Sl   10:15   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
