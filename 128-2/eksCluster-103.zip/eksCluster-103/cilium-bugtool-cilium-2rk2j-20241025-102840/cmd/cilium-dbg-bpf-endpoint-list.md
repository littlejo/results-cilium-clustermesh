IP ADDRESS         LOCAL ENDPOINT INFO
10.103.0.247:0     id=2826  sec_id=6871442 flags=0x0000 ifindex=14  mac=B6:AB:DF:71:41:99 nodemac=E6:74:CC:66:FA:87   
172.31.216.37:0    (localhost)                                                                                        
10.103.0.234:0     id=690   sec_id=6820238 flags=0x0000 ifindex=18  mac=22:76:1E:17:BE:2A nodemac=AA:28:FC:39:04:76   
10.103.0.191:0     id=588   sec_id=6871442 flags=0x0000 ifindex=12  mac=B6:91:DD:57:56:35 nodemac=1E:E8:31:E6:66:54   
172.31.220.111:0   (localhost)                                                                                        
10.103.0.65:0      (localhost)                                                                                        
10.103.0.166:0     id=460   sec_id=4     flags=0x0000 ifindex=10  mac=36:45:6D:FB:36:FA nodemac=6A:0B:F4:BC:9B:45     
