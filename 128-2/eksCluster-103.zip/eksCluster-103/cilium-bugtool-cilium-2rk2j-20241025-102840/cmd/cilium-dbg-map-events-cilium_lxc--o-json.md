{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:21.474Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.216.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:21.474Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.220.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:21.474Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:25.988Z",
  "value": "id=588   sec_id=6871442 flags=0x0000 ifindex=12  mac=B6:91:DD:57:56:35 nodemac=1E:E8:31:E6:66:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:25.995Z",
  "value": "id=460   sec_id=4     flags=0x0000 ifindex=10  mac=36:45:6D:FB:36:FA nodemac=6A:0B:F4:BC:9B:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:26.038Z",
  "value": "id=588   sec_id=6871442 flags=0x0000 ifindex=12  mac=B6:91:DD:57:56:35 nodemac=1E:E8:31:E6:66:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:26.078Z",
  "value": "id=460   sec_id=4     flags=0x0000 ifindex=10  mac=36:45:6D:FB:36:FA nodemac=6A:0B:F4:BC:9B:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:33.090Z",
  "value": "id=2826  sec_id=6871442 flags=0x0000 ifindex=14  mac=B6:AB:DF:71:41:99 nodemac=E6:74:CC:66:FA:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:10.189Z",
  "value": "id=2826  sec_id=6871442 flags=0x0000 ifindex=14  mac=B6:AB:DF:71:41:99 nodemac=E6:74:CC:66:FA:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:10.190Z",
  "value": "id=588   sec_id=6871442 flags=0x0000 ifindex=12  mac=B6:91:DD:57:56:35 nodemac=1E:E8:31:E6:66:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:10.190Z",
  "value": "id=460   sec_id=4     flags=0x0000 ifindex=10  mac=36:45:6D:FB:36:FA nodemac=6A:0B:F4:BC:9B:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:10.221Z",
  "value": "id=387   sec_id=6820238 flags=0x0000 ifindex=16  mac=B6:CE:0C:E4:D1:53 nodemac=C2:94:A7:89:A0:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.190Z",
  "value": "id=460   sec_id=4     flags=0x0000 ifindex=10  mac=36:45:6D:FB:36:FA nodemac=6A:0B:F4:BC:9B:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.190Z",
  "value": "id=387   sec_id=6820238 flags=0x0000 ifindex=16  mac=B6:CE:0C:E4:D1:53 nodemac=C2:94:A7:89:A0:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.190Z",
  "value": "id=588   sec_id=6871442 flags=0x0000 ifindex=12  mac=B6:91:DD:57:56:35 nodemac=1E:E8:31:E6:66:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.191Z",
  "value": "id=2826  sec_id=6871442 flags=0x0000 ifindex=14  mac=B6:AB:DF:71:41:99 nodemac=E6:74:CC:66:FA:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:08.334Z",
  "value": "id=690   sec_id=6820238 flags=0x0000 ifindex=18  mac=22:76:1E:17:BE:2A nodemac=AA:28:FC:39:04:76"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.103.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:18.838Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:21.194Z",
  "value": "id=588   sec_id=6871442 flags=0x0000 ifindex=12  mac=B6:91:DD:57:56:35 nodemac=1E:E8:31:E6:66:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:21.194Z",
  "value": "id=460   sec_id=4     flags=0x0000 ifindex=10  mac=36:45:6D:FB:36:FA nodemac=6A:0B:F4:BC:9B:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:21.196Z",
  "value": "id=2826  sec_id=6871442 flags=0x0000 ifindex=14  mac=B6:AB:DF:71:41:99 nodemac=E6:74:CC:66:FA:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:21.196Z",
  "value": "id=690   sec_id=6820238 flags=0x0000 ifindex=18  mac=22:76:1E:17:BE:2A nodemac=AA:28:FC:39:04:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.194Z",
  "value": "id=690   sec_id=6820238 flags=0x0000 ifindex=18  mac=22:76:1E:17:BE:2A nodemac=AA:28:FC:39:04:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.195Z",
  "value": "id=460   sec_id=4     flags=0x0000 ifindex=10  mac=36:45:6D:FB:36:FA nodemac=6A:0B:F4:BC:9B:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.195Z",
  "value": "id=588   sec_id=6871442 flags=0x0000 ifindex=12  mac=B6:91:DD:57:56:35 nodemac=1E:E8:31:E6:66:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.196Z",
  "value": "id=2826  sec_id=6871442 flags=0x0000 ifindex=14  mac=B6:AB:DF:71:41:99 nodemac=E6:74:CC:66:FA:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:23.195Z",
  "value": "id=2826  sec_id=6871442 flags=0x0000 ifindex=14  mac=B6:AB:DF:71:41:99 nodemac=E6:74:CC:66:FA:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:23.195Z",
  "value": "id=460   sec_id=4     flags=0x0000 ifindex=10  mac=36:45:6D:FB:36:FA nodemac=6A:0B:F4:BC:9B:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:23.195Z",
  "value": "id=588   sec_id=6871442 flags=0x0000 ifindex=12  mac=B6:91:DD:57:56:35 nodemac=1E:E8:31:E6:66:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:23.195Z",
  "value": "id=690   sec_id=6820238 flags=0x0000 ifindex=18  mac=22:76:1E:17:BE:2A nodemac=AA:28:FC:39:04:76"
}

