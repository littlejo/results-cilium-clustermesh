fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxc40e382469b26 proto kernel metric 256 pref medium
fe80::/64 dev lxcbfbc347a5d69 proto kernel metric 256 pref medium
fe80::/64 dev lxcfb1e5e2ecd10 proto kernel metric 256 pref medium
