alloc: 133.33MB (139809528 bytes)
total-alloc: 1.32GB (1417450512 bytes)
sys: 198.32MB (207952196 bytes)
lookups: 0
mallocs: 47641191
frees: 46166594
heap-alloc: 133.33MB (139809528 bytes)
heap-sys: 153.11MB (160546816 bytes)
heap-idle: 6.40MB (6709248 bytes)
heap-in-use: 146.71MB (153837568 bytes)
heap-released: 1.88MB (1966080 bytes)
heap-objects: 1474597
stack-in-use: 34.84MB (36536320 bytes)
stack-sys: 34.84MB (36536320 bytes)
stack-mspan-inuse: 2.39MB (2503680 bytes)
stack-mspan-sys: 2.40MB (2513280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 988.13KB (1011849 bytes)
gc-sys: 5.11MB (5356784 bytes)
next-gc: when heap-alloc >= 142.77MB (149700104 bytes)
last-gc: 2024-10-25 10:28:32.773353236 +0000 UTC
gc-pause-total: 7.921885ms
gc-pause: 97196
gc-pause-end: 1729852112773353236
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00032176395552641854
enable-gc: true
debug-gc: false
