key: d9 00 00 00  value: f9 01 00 00
key: ea 00 00 00  value: 48 02 00 00
key: 08 05 00 00  value: f4 01 00 00
key: e9 0e 00 00  value: 05 02 00 00
Found 4 elements
