29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:02+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:19+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
61: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
64: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
73: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
76: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
80: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
83: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
111: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
114: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
455: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:55+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 114
456: sched_cls  name tail_handle_ipv4  tag d83afa75df81433e  gpl
	loaded_at 2024-10-25T10:13:55+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 71,70,77,72,93
	btf_id 115
457: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:55+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 72,93
	btf_id 116
458: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:55+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 117
459: sched_cls  name tail_handle_ipv4_from_host  tag 8d24c995ba1a1366  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,96
	btf_id 119
460: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 72,71,96
	btf_id 120
462: sched_cls  name __send_drop_notify  tag 2c46434d4c423ae4  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 122
463: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,96
	btf_id 123
465: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 125
467: sched_cls  name __send_drop_notify  tag 2c46434d4c423ae4  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 128
468: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,98
	btf_id 129
470: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 131
471: sched_cls  name tail_handle_ipv4_from_host  tag 8d24c995ba1a1366  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,98
	btf_id 132
473: sched_cls  name __send_drop_notify  tag 2c46434d4c423ae4  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 135
474: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,100
	btf_id 136
475: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 72,100,71
	btf_id 137
477: sched_cls  name tail_handle_ipv4_from_host  tag 8d24c995ba1a1366  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,100
	btf_id 139
491: sched_cls  name tail_handle_ipv4  tag dfc07805ef2addeb  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,104
	btf_id 155
492: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 72,104,78,79,103,80
	btf_id 156
493: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,104
	btf_id 157
494: sched_cls  name tail_ipv4_to_endpoint  tag 73558486b6e5d3a7  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 71,72,103,37,78,79,76,94,35,104,36,33,34
	btf_id 158
495: sched_cls  name tail_ipv4_ct_ingress  tag e755eaeed8c3c45e  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 72,104,78,79,103,80
	btf_id 159
497: sched_cls  name tail_handle_ipv4_cont  tag 1fb16321863cd06a  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 71,103,37,94,78,79,35,72,70,73,104,36,33,34,77
	btf_id 161
498: sched_cls  name tail_handle_arp  tag d770ea44c8a58c79  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,104
	btf_id 162
499: sched_cls  name cil_from_container  tag 2b66cabcfd10b873  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 104,72
	btf_id 163
500: sched_cls  name handle_policy  tag 3a3cd2eff56c9e46  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 72,104,78,79,103,37,76,94,35,80,71,36,33,34
	btf_id 164
501: sched_cls  name __send_drop_notify  tag c214a28f9a0ff3ef  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 165
503: sched_cls  name tail_ipv4_ct_egress  tag 724a84c8862712c4  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,106,78,79,107,80
	btf_id 168
504: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,106
	btf_id 169
505: sched_cls  name handle_policy  tag ff12e767773231a4  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,106,78,79,107,37,76,105,35,80,71,36,33,34
	btf_id 170
506: sched_cls  name tail_ipv4_ct_ingress  tag f10575fec0ad12b6  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,106,78,79,107,80
	btf_id 171
507: sched_cls  name tail_handle_ipv4  tag 2c543ba62c11174c  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,106
	btf_id 172
508: sched_cls  name tail_handle_arp  tag aa21b25ea70c78d4  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,106
	btf_id 173
509: sched_cls  name __send_drop_notify  tag 6751c17f8b950e1e  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 174
510: sched_cls  name tail_handle_ipv4_cont  tag 4fdb373ff3a087f6  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,107,37,105,78,79,35,72,70,73,106,36,33,34,77
	btf_id 175
511: sched_cls  name cil_from_container  tag 0a35726775c94063  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 106,72
	btf_id 176
512: sched_cls  name tail_ipv4_to_endpoint  tag 7115e4f1a1eeacb2  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,107,37,78,79,76,105,35,106,36,33,34
	btf_id 177
513: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
516: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
517: sched_cls  name handle_policy  tag ea36f72c48722e45  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,111,78,79,110,37,76,109,35,80,71,36,33,34
	btf_id 179
518: sched_cls  name cil_from_container  tag c33cf486775c13e9  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,72
	btf_id 180
520: sched_cls  name tail_handle_ipv4_cont  tag f6c380dbc2c4ebea  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,110,37,109,78,79,35,72,70,73,111,36,33,34,77
	btf_id 182
521: sched_cls  name tail_ipv4_ct_ingress  tag 8bbbf42370d7cc37  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,111,78,79,110,80
	btf_id 183
522: sched_cls  name tail_handle_ipv4  tag 51061c826f5c564d  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,111
	btf_id 184
523: sched_cls  name tail_ipv4_ct_egress  tag 724a84c8862712c4  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,111,78,79,110,80
	btf_id 185
524: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,111
	btf_id 186
525: sched_cls  name __send_drop_notify  tag 76d8336d093141cb  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 187
526: sched_cls  name tail_handle_arp  tag 01bbed01b2042e99  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,111
	btf_id 188
527: sched_cls  name tail_ipv4_to_endpoint  tag 0d86cd771edc0d68  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,110,37,78,79,76,109,35,111,36,33,34
	btf_id 189
528: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
531: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
532: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
535: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
536: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
539: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
579: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:23:01+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,127
	btf_id 205
580: sched_cls  name tail_handle_arp  tag 8083cb4693fde293  gpl
	loaded_at 2024-10-25T10:23:01+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,127
	btf_id 206
582: sched_cls  name tail_ipv4_to_endpoint  tag f84849a49a8d7c8f  gpl
	loaded_at 2024-10-25T10:23:01+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,126,37,78,79,76,125,35,127,36,33,34
	btf_id 208
583: sched_cls  name __send_drop_notify  tag cd768d883269ba38  gpl
	loaded_at 2024-10-25T10:23:01+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 209
584: sched_cls  name handle_policy  tag 17d657d96b778bda  gpl
	loaded_at 2024-10-25T10:23:01+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,127,78,79,126,37,76,125,35,80,71,36,33,34
	btf_id 210
585: sched_cls  name tail_handle_ipv4_cont  tag f61f6c51009d131f  gpl
	loaded_at 2024-10-25T10:23:01+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,126,37,125,78,79,35,72,70,73,127,36,33,34,77
	btf_id 211
586: sched_cls  name cil_from_container  tag 15943349285b0db5  gpl
	loaded_at 2024-10-25T10:23:01+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 127,72
	btf_id 212
587: sched_cls  name tail_ipv4_ct_egress  tag d46a6efcaf12e153  gpl
	loaded_at 2024-10-25T10:23:01+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,127,78,79,126,80
	btf_id 213
588: sched_cls  name tail_ipv4_ct_ingress  tag eef8f047610047ab  gpl
	loaded_at 2024-10-25T10:23:01+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,127,78,79,126,80
	btf_id 214
589: sched_cls  name tail_handle_ipv4  tag ce672ef9876a1688  gpl
	loaded_at 2024-10-25T10:23:01+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,127
	btf_id 215
590: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
593: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
606: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
609: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
610: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
613: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
614: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
617: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
