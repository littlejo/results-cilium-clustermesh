filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcbfbc347a5d69 direct-action not_in_hw id 518 tag c33cf486775c13e9 jited 
