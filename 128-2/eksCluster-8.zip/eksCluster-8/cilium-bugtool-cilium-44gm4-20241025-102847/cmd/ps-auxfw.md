USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         670  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         660  0.0  0.0 1228744 3596 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root         659  0.0  0.4 1240432 16504 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         691  0.0  0.0   6408  1644 ?        R    10:28   0:00  \_ ps auxfw
root         693  0.0  0.0      4     4 ?        R    10:28   0:00  \_ [bash]
root           1  2.5  6.7 1472240 266088 ?      Ssl  10:13   0:22 cilium-agent --config-dir=/tmp/cilium/config-map
root         419  0.0  0.1 1228848 6916 ?        Sl   10:13   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
