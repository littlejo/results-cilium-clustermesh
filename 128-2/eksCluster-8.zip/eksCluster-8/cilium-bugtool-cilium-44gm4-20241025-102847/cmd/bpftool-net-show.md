xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 475
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 470
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 465
cilium_host(4) clsact/egress cil_from_host-cilium_host id 460
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 457
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 458
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 499
lxc40e382469b26(9) clsact/ingress cil_from_container-lxc40e382469b26 id 511
lxcbfbc347a5d69(11) clsact/ingress cil_from_container-lxcbfbc347a5d69 id 518
lxcfb1e5e2ecd10(15) clsact/ingress cil_from_container-lxcfb1e5e2ecd10 id 586

flow_dissector:

netfilter:

