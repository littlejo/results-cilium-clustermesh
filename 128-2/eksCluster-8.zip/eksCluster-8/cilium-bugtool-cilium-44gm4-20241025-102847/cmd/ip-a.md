1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:0a:14:fc:10:3d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.191.155/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2661sec preferred_lft 2661sec
    inet6 fe80::40a:14ff:fefc:103d/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:2b:b4:5a:f1:b0 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c42b:b4ff:fe5a:f1b0/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:7b:9e:cd:a0:84 brd ff:ff:ff:ff:ff:ff
    inet 10.8.0.129/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::987b:9eff:fecd:a084/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ba:87:55:e1:25:cf brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b887:55ff:fee1:25cf/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:fe:1a:b0:5f:4f brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::acfe:1aff:feb0:5f4f/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc40e382469b26@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:4f:0e:f3:c2:7e brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::4c4f:eff:fef3:c27e/64 scope link 
       valid_lft forever preferred_lft forever
11: lxcbfbc347a5d69@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:7b:79:92:a8:6c brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::147b:79ff:fe92:a86c/64 scope link 
       valid_lft forever preferred_lft forever
15: lxcfb1e5e2ecd10@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:5d:45:b4:aa:c0 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::bc5d:45ff:feb4:aac0/64 scope link 
       valid_lft forever preferred_lft forever
