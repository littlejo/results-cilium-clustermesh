IP ADDRESS         LOCAL ENDPOINT INFO
172.31.191.155:0   (localhost)                                                                                       
10.8.0.145:0       id=217   sec_id=620887 flags=0x0000 ifindex=9   mac=BE:80:5E:D9:49:72 nodemac=4E:4F:0E:F3:C2:7E   
10.8.0.209:0       id=234   sec_id=594581 flags=0x0000 ifindex=15  mac=BA:62:F5:52:5C:2E nodemac=BE:5D:45:B4:AA:C0   
10.8.0.247:0       id=1288  sec_id=4     flags=0x0000 ifindex=7   mac=56:EF:D9:A6:64:FD nodemac=AE:FE:1A:B0:5F:4F    
10.8.0.136:0       id=3817  sec_id=620887 flags=0x0000 ifindex=11  mac=B6:26:3D:1B:6B:17 nodemac=16:7B:79:92:A8:6C   
10.8.0.129:0       (localhost)                                                                                       
