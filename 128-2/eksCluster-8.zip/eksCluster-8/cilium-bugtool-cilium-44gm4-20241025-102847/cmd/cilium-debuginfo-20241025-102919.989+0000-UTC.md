# Cilium debug information

#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.8.0.0/24, 
Allocated addresses:
  10.8.0.129 (router)
  10.8.0.136 (kube-system/coredns-cc6ccd49c-f96m6)
  10.8.0.145 (kube-system/coredns-cc6ccd49c-65v59)
  10.8.0.209 (kube-system/clustermesh-apiserver-68f6bb4cb5-6j4d8)
  10.8.0.247 (health)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5b34825e90bedfd9
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    24s ago        never        0       no error   
  ct-map-pressure                                                     26s ago        never        0       no error   
  daemon-validate-config                                              11s ago        never        0       no error   
  dns-garbage-collector-job                                           29s ago        never        0       no error   
  endpoint-1288-regeneration-recovery                                 never          never        0       no error   
  endpoint-217-regeneration-recovery                                  never          never        0       no error   
  endpoint-234-regeneration-recovery                                  never          never        0       no error   
  endpoint-3317-regeneration-recovery                                 never          never        0       no error   
  endpoint-3817-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                         29s ago        never        0       no error   
  ep-bpf-prog-watchdog                                                26s ago        never        0       no error   
  ipcache-inject-labels                                               27s ago        never        0       no error   
  k8s-heartbeat                                                       29s ago        never        0       no error   
  link-cache                                                          11s ago        never        0       no error   
  local-identity-checkpoint                                           15m13s ago     never        0       no error   
  node-neighbor-link-updater                                          6s ago         never        0       no error   
  remote-etcd-cmesh1                                                  5m49s ago      never        0       no error   
  remote-etcd-cmesh10                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh100                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh101                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh102                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh103                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh104                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh105                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh106                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh107                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh108                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh109                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh11                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh110                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh111                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh112                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh113                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh114                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh115                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh116                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh117                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh118                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh119                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh12                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh120                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh121                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh122                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh123                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh124                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh125                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh126                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh127                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh128                                                5m49s ago      never        0       no error   
  remote-etcd-cmesh13                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh14                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh15                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh16                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh17                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh18                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh19                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh2                                                  5m49s ago      never        0       no error   
  remote-etcd-cmesh20                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh21                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh22                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh23                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh24                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh25                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh26                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh27                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh28                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh29                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh3                                                  5m49s ago      never        0       no error   
  remote-etcd-cmesh30                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh31                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh32                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh33                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh34                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh35                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh36                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh37                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh38                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh39                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh4                                                  5m49s ago      never        0       no error   
  remote-etcd-cmesh40                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh41                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh42                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh43                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh44                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh45                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh46                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh47                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh48                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh49                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh5                                                  5m49s ago      never        0       no error   
  remote-etcd-cmesh50                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh51                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh52                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh53                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh54                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh55                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh56                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh57                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh58                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh59                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh6                                                  5m49s ago      never        0       no error   
  remote-etcd-cmesh60                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh61                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh62                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh63                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh64                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh65                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh66                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh67                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh68                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh69                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh7                                                  5m49s ago      never        0       no error   
  remote-etcd-cmesh70                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh71                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh72                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh73                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh74                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh75                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh76                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh77                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh78                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh79                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh8                                                  5m49s ago      never        0       no error   
  remote-etcd-cmesh80                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh81                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh82                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh83                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh84                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh85                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh86                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh87                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh88                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh89                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh90                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh91                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh92                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh93                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh94                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh95                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh96                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh97                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh98                                                 5m49s ago      never        0       no error   
  remote-etcd-cmesh99                                                 5m49s ago      never        0       no error   
  resolve-identity-1288                                               25s ago        never        0       no error   
  resolve-identity-217                                                19s ago        never        0       no error   
  resolve-identity-234                                                1m18s ago      never        0       no error   
  resolve-identity-3317                                               26s ago        never        0       no error   
  resolve-identity-3817                                               18s ago        never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-68f6bb4cb5-6j4d8   6m18s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-65v59                  15m19s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-f96m6                  15m18s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      15m26s ago     never        0       no error   
  sync-policymap-1288                                                 22s ago        never        0       no error   
  sync-policymap-217                                                  19s ago        never        0       no error   
  sync-policymap-234                                                  6m18s ago      never        0       no error   
  sync-policymap-3317                                                 25s ago        never        0       no error   
  sync-policymap-3817                                                 18s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (217)                                    9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (234)                                    8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3817)                                   8s ago         never        0       no error   
  sync-utime                                                          27s ago        never        0       no error   
  write-cni-file                                                      15m29s ago     never        0       no error   
Proxy Status:            OK, ip 10.8.0.129, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 589824, max 655359
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 65.69   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 23080856                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 23080856                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 23080856                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400c800000 rw-p 00000000 00:00 0 
400c800000-4010000000 ---p 00000000 00:00 0 
ffff4bc81000-ffff4beb7000 rw-p 00000000 00:00 0 
ffff4bebf000-ffff4bfe0000 rw-p 00000000 00:00 0 
ffff4bfe0000-ffff4c021000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff4c021000-ffff4c062000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff4c062000-ffff4c064000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff4c064000-ffff4c066000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff4c066000-ffff4c5fd000 rw-p 00000000 00:00 0 
ffff4c5fd000-ffff4c6fd000 rw-p 00000000 00:00 0 
ffff4c6fd000-ffff4c70e000 rw-p 00000000 00:00 0 
ffff4c70e000-ffff4e70e000 rw-p 00000000 00:00 0 
ffff4e70e000-ffff4e78e000 ---p 00000000 00:00 0 
ffff4e78e000-ffff4e78f000 rw-p 00000000 00:00 0 
ffff4e78f000-ffff6e78e000 ---p 00000000 00:00 0 
ffff6e78e000-ffff6e78f000 rw-p 00000000 00:00 0 
ffff6e78f000-ffff8e71e000 ---p 00000000 00:00 0 
ffff8e71e000-ffff8e71f000 rw-p 00000000 00:00 0 
ffff8e71f000-ffff92710000 ---p 00000000 00:00 0 
ffff92710000-ffff92711000 rw-p 00000000 00:00 0 
ffff92711000-ffff92f0e000 ---p 00000000 00:00 0 
ffff92f0e000-ffff92f0f000 rw-p 00000000 00:00 0 
ffff92f0f000-ffff9300e000 ---p 00000000 00:00 0 
ffff9300e000-ffff9306e000 rw-p 00000000 00:00 0 
ffff9306e000-ffff93070000 r--p 00000000 00:00 0                          [vvar]
ffff93070000-ffff93071000 r-xp 00000000 00:00 0                          [vdso]
ffffc8b7d000-ffffc8b9e000 rw-p 00000000 00:00 0                          [stack]

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001e78160)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001fdaea0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001fdaea0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x400274eb00)(frontends:[10.100.75.49]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4001e78a50)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4001e78b00)(frontends:[10.100.134.0]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4001e78bb0)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4002650d10)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4001142ec0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-zgd68": (*k8s.Endpoints)(0x4002b1bc70)(172.31.191.155:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4001142ec8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-9th8f": (*k8s.Endpoints)(0x4003140000)(10.8.0.136:53/TCP[eu-west-3a],10.8.0.136:53/UDP[eu-west-3a],10.8.0.136:9153/TCP[eu-west-3a],10.8.0.145:53/TCP[eu-west-3a],10.8.0.145:53/UDP[eu-west-3a],10.8.0.145:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40019895a8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-dmhwz": (*k8s.Endpoints)(0x400261ac30)(10.8.0.209:2379/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4001142eb8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4003140f70)(172.31.167.74:443/TCP,172.31.217.84:443/TCP)
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001b22850)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4002070000)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400b4ed0e0
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4001cb94a0,
  gcExited: (chan struct {}) 0x4001cb9500,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001c20780)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001061ac8)({
      MetricVec: (*prometheus.MetricVec)(0x4001ca55f0)({
       metricMap: (*prometheus.metricMap)(0x4001ca5620)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a61d40)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001c20800)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001061ad0)({
      MetricVec: (*prometheus.MetricVec)(0x4001ca5680)({
       metricMap: (*prometheus.metricMap)(0x4001ca56b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a61da0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001c20880)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001061ad8)({
      MetricVec: (*prometheus.MetricVec)(0x4001ca5710)({
       metricMap: (*prometheus.metricMap)(0x4001ca5740)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a61e00)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001c20900)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001061ae0)({
      MetricVec: (*prometheus.MetricVec)(0x4001ca57a0)({
       metricMap: (*prometheus.metricMap)(0x4001ca57d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a61e60)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001c20980)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001061ae8)({
      MetricVec: (*prometheus.MetricVec)(0x4001ca5830)({
       metricMap: (*prometheus.metricMap)(0x4001ca5860)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a61ec0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001c20a00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001061af0)({
      MetricVec: (*prometheus.MetricVec)(0x4001ca58c0)({
       metricMap: (*prometheus.metricMap)(0x4001ca58f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a61f20)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001c20a80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001061af8)({
      MetricVec: (*prometheus.MetricVec)(0x4001ca5950)({
       metricMap: (*prometheus.metricMap)(0x4001ca5980)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001cb2000)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001c20b00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001061b00)({
      MetricVec: (*prometheus.MetricVec)(0x4001ca59e0)({
       metricMap: (*prometheus.metricMap)(0x4001ca5a10)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001cb2060)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001c20b80)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001061b08)({
      MetricVec: (*prometheus.MetricVec)(0x4001ca5a70)({
       metricMap: (*prometheus.metricMap)(0x4001ca5aa0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001cb20c0)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001b22850)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001ff4310)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001ff2858)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 394ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.8.0.129": (string) (len=6) "router",
  (string) (len=10) "10.8.0.247": (string) (len=6) "health",
  (string) (len=10) "10.8.0.145": (string) (len=35) "kube-system/coredns-cc6ccd49c-65v59",
  (string) (len=10) "10.8.0.136": (string) (len=35) "kube-system/coredns-cc6ccd49c-f96m6",
  (string) (len=10) "10.8.0.209": (string) (len=50) "kube-system/clustermesh-apiserver-68f6bb4cb5-6j4d8"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.191.155": (string) (len=7) "node-ip"
}

```


#### Cilium encryption



#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium environment keys

```
enable-ipv6-masquerade:true
enable-bgp-control-plane:false
enable-host-legacy-routing:false
kvstore:
ipam-default-ip-pool:default
kube-proxy-replacement-healthz-bind-address:
devices:
envoy-base-id:0
egress-gateway-policy-map-max:16384
force-device-detection:false
bpf-ct-timeout-regular-tcp-syn:1m0s
hubble-redact-http-headers-deny:
enable-l2-announcements:false
prepend-iptables-chains:true
encryption-strict-mode-allow-remote-node-identities:false
hubble-redact-enabled:false
kvstore-opt:
hubble-drop-events-reasons:auth_required,policy_denied
bpf-lb-dsr-dispatch:opt
dns-max-ips-per-restored-rule:1000
node-labels:
annotate-k8s-node:false
bpf-lb-service-backend-map-max:0
preallocate-bpf-maps:false
cni-log-file:/var/run/cilium/cilium-cni.log
kube-proxy-replacement:false
encrypt-node:false
proxy-xff-num-trusted-hops-egress:0
mesh-auth-gc-interval:5m0s
exclude-node-label-patterns:
enable-nat46x64-gateway:false
route-metric:0
enable-cilium-api-server-access:
bpf-lb-external-clusterip:false
bpf-ct-timeout-service-tcp:2h13m20s
enable-host-firewall:false
trace-payloadlen:128
k8s-namespace:kube-system
fixed-identity-mapping:
enable-node-selector-labels:false
remove-cilium-node-taints:true
bpf-events-trace-enabled:true
tofqdns-enable-dns-compression:true
identity-change-grace-period:5s
cluster-pool-ipv4-cidr:10.8.0.0/16
hubble-redact-kafka-apikey:false
ipv6-pod-subnets:
clustermesh-enable-mcs-api:false
synchronize-k8s-nodes:true
custom-cni-conf:false
bpf-root:/sys/fs/bpf
enable-bbr:false
bpf-ct-timeout-service-any:1m0s
enable-vtep:false
srv6-encap-mode:reduced
bpf-auth-map-max:524288
monitor-queue-size:0
http-idle-timeout:0
bpf-lb-sock:false
cni-external-routing:false
mesh-auth-enabled:true
procfs:/host/proc
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
ipsec-key-rotation-duration:5m0s
dnsproxy-concurrency-processing-grace-period:0s
auto-direct-node-routes:false
nat-map-stats-interval:30s
node-port-range:
tofqdns-max-deferred-connection-deletes:10000
egress-gateway-reconciliation-trigger-interval:1s
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
cni-exclusive:true
enable-recorder:false
cilium-endpoint-gc-interval:5m0s
bpf-lb-maglev-map-max:0
tofqdns-endpoint-max-ip-per-hostname:50
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
allocator-list-timeout:3m0s
clustermesh-config:/var/lib/cilium/clustermesh/
bpf-nat-global-max:524288
iptables-lock-timeout:5s
monitor-aggregation:medium
disable-external-ip-mitigation:false
enable-xt-socket-fallback:true
vtep-cidr:
enable-unreachable-routes:false
enable-local-node-route:true
bpf-ct-timeout-regular-tcp:2h13m20s
enable-srv6:false
bpf-ct-global-any-max:262144
enable-pmtu-discovery:false
ipv4-service-range:auto
nodes-gc-interval:5m0s
controller-group-metrics:
enable-l2-pod-announcements:false
tunnel-port:0
cluster-health-port:4240
hubble-skip-unknown-cgroup-ids:true
disable-iptables-feeder-rules:
bypass-ip-availability-upon-restore:false
enable-policy:default
egress-masquerade-interfaces:ens+
pprof-address:localhost
policy-queue-size:100
k8s-api-server:
enable-ipv4-fragment-tracking:true
fqdn-regex-compile-lru-size:1024
hubble-event-queue-size:0
cni-chaining-mode:none
ipv6-cluster-alloc-cidr:f00d::/64
enable-k8s-networkpolicy:true
clustermesh-sync-timeout:1m0s
iptables-random-fully:false
tunnel-protocol:vxlan
http-normalize-path:true
pprof:false
enable-health-check-nodeport:true
enable-external-ips:false
enable-hubble:true
mesh-auth-queue-size:1024
bpf-sock-rev-map-max:262144
enable-cilium-endpoint-slice:false
enable-ip-masq-agent:false
disable-endpoint-crd:false
enable-endpoint-health-checking:true
ipv6-range:auto
bpf-lb-affinity-map-max:0
bpf-lb-map-max:65536
conntrack-gc-interval:0s
cni-chaining-target:
mesh-auth-spiffe-trust-domain:spiffe.cilium
proxy-idle-timeout-seconds:60
bpf-ct-timeout-service-tcp-grace:1m0s
labels:
k8s-require-ipv6-pod-cidr:false
enable-svc-source-range-check:true
direct-routing-device:
hubble-redact-http-userinfo:true
operator-prometheus-serve-addr::9963
ipam-multi-pool-pre-allocation:
hubble-listen-address::4244
enable-sctp:false
proxy-prometheus-port:0
kvstore-connectivity-timeout:2m0s
enable-cilium-health-api-server-access:
bgp-announce-pod-cidr:false
log-opt:
trace-sock:true
l2-announcements-renew-deadline:5s
gateway-api-secrets-namespace:
ip-masq-agent-config-path:/etc/config/ip-masq-agent
gops-port:9890
enable-session-affinity:false
dnsproxy-insecure-skip-transparent-mode-check:false
external-envoy-proxy:true
hubble-drop-events:false
restore:true
proxy-admin-port:0
bpf-lb-source-range-map-max:0
node-port-mode:snat
envoy-config-retry-interval:15s
hubble-metrics-server:
conntrack-gc-max-interval:0s
policy-accounting:true
hubble-export-allowlist:
install-iptables-rules:true
hubble-redact-http-urlquery:false
identity-allocation-mode:crd
set-cilium-is-up-condition:true
socket-path:/var/run/cilium/cilium.sock
node-port-acceleration:disabled
hubble-export-file-max-size-mb:10
hubble-monitor-events:
use-cilium-internal-ip-for-ipsec:false
k8s-service-cache-size:128
enable-bpf-masquerade:false
api-rate-limit:
allow-icmp-frag-needed:true
hubble-prefer-ipv6:false
bpf-lb-sock-hostns-only:false
enable-l7-proxy:true
identity-heartbeat-timeout:30m0s
ipv4-service-loopback-address:169.254.42.1
hubble-metrics:
enable-bandwidth-manager:false
k8s-service-proxy-name:
hubble-recorder-storage-path:/var/run/cilium/pcaps
ipv4-pod-subnets:
l2-announcements-retry-period:2s
hubble-export-fieldmask:
enable-high-scale-ipcache:false
bpf-policy-map-full-reconciliation-interval:15m0s
tofqdns-min-ttl:0
enable-ingress-controller:false
enable-wireguard-userspace-fallback:false
enable-monitor:true
enable-k8s-endpoint-slice:true
hubble-drop-events-interval:2m0s
clustermesh-enable-endpoint-sync:false
config:
hubble-export-denylist:
log-driver:
ipv4-native-routing-cidr:
enable-auto-protect-node-port-range:true
bpf-ct-timeout-regular-tcp-fin:10s
dnsproxy-socket-linger-timeout:10
certificates-directory:/var/run/cilium/certs
agent-liveness-update-interval:1s
enable-runtime-device-detection:true
tofqdns-idle-connection-grace-period:0s
bpf-policy-map-max:16384
nat-map-stats-entries:32
bgp-announce-lb-ip:false
unmanaged-pod-watcher-interval:15
crd-wait-timeout:5m0s
egress-multi-home-ip-rule-compat:false
bpf-events-policy-verdict-enabled:true
enable-service-topology:false
enable-l2-neigh-discovery:true
dnsproxy-enable-transparent-mode:true
enable-stale-cilium-endpoint-cleanup:true
proxy-gid:1337
enable-tcx:true
hubble-redact-http-headers-allow:
bpf-lb-service-map-max:0
kvstore-lease-ttl:15m0s
vtep-mask:
http-retry-timeout:0
cgroup-root:/run/cilium/cgroupv2
ipv6-service-range:auto
enable-ipip-termination:false
config-sources:config-map:kube-system/cilium-config
enable-local-redirect-policy:false
enable-hubble-recorder-api:true
cflags:
disable-envoy-version-check:false
enable-ipsec-encrypted-overlay:false
metrics:
enable-bpf-clock-probe:false
derive-masq-ip-addr-from-device:
envoy-secrets-namespace:
local-router-ipv4:
bpf-lb-maglev-table-size:16381
l2-pod-announcements-interface:
tofqdns-proxy-port:0
ipv6-native-routing-cidr:
enable-well-known-identities:false
monitor-aggregation-flags:all
encrypt-interface:
vtep-endpoint:
use-full-tls-context:false
tofqdns-dns-reject-response-code:refused
endpoint-bpf-prog-watchdog-interval:30s
join-cluster:false
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
max-internal-timer-delay:0s
enable-custom-calls:false
identity-restore-grace-period:30s
container-ip-local-reserved-ports:auto
hubble-flowlogs-config-path:
bpf-ct-timeout-regular-any:1m0s
monitor-aggregation-interval:5s
clustermesh-ip-identities-sync-timeout:1m0s
proxy-xff-num-trusted-hops-ingress:0
enable-host-port:false
mesh-auth-mutual-listener-port:0
operator-api-serve-addr:127.0.0.1:9234
direct-routing-skip-unreachable:false
enable-icmp-rules:true
bpf-events-drop-enabled:true
enable-tracing:false
endpoint-gc-interval:5m0s
dnsproxy-lock-count:131
envoy-log:
mke-cgroup-mount:
exclude-local-address:
enable-ipv6:false
k8s-heartbeat-timeout:30s
mtu:0
log-system-load:false
ipsec-key-file:
vtep-mac:
enable-ipv4-masquerade:true
enable-ipsec-xfrm-state-caching:true
enable-endpoint-routes:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
enable-k8s-terminating-endpoint:true
proxy-connect-timeout:2
enable-xdp-prefilter:false
cluster-pool-ipv4-mask-size:24
l2-announcements-lease-duration:15s
bpf-fragments-map-max:8192
dnsproxy-concurrency-limit:0
http-max-grpc-timeout:0
ipv4-node:auto
envoy-config-timeout:2m0s
tofqdns-proxy-response-max-delay:100ms
bpf-lb-sock-terminate-pod-connections:false
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
envoy-keep-cap-netbindservice:false
proxy-max-requests-per-connection:0
bpf-filter-priority:1
bpf-lb-rss-ipv6-src-cidr:
enable-route-mtu-for-cni-chaining:false
hubble-recorder-sink-queue-size:1024
ingress-secrets-namespace:
enable-bpf-tproxy:false
hubble-disable-tls:false
proxy-max-connection-duration-seconds:0
label-prefix-file:
prometheus-serve-addr:
mesh-auth-spire-admin-socket:
k8s-sync-timeout:3m0s
mesh-auth-mutual-connect-timeout:5s
k8s-client-qps:10
set-cilium-node-taints:true
read-cni-conf:
enable-mke:false
enable-ipv4:true
config-dir:/tmp/cilium/config-map
ipv6-node:auto
encryption-strict-mode-cidr:
debug:false
bpf-lb-rss-ipv4-src-cidr:
proxy-portrange-min:10000
k8s-kubeconfig-path:
agent-health-port:9879
bpf-node-map-max:16384
k8s-require-ipv4-pod-cidr:false
bpf-map-event-buffers:
enable-wireguard:false
k8s-client-connection-keep-alive:30s
hubble-export-file-compress:false
vlan-bpf-bypass:
hubble-event-buffer-capacity:4095
identity-gc-interval:15m0s
kvstore-max-consecutive-quorum-errors:2
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
wireguard-persistent-keepalive:0s
cluster-name:cmesh9
version:false
mesh-auth-rotated-identities-queue-size:1024
dnsproxy-lock-timeout:500ms
enable-health-checking:true
enable-ipv4-big-tcp:false
enable-ipv4-egress-gateway:false
ipv6-mcast-device:
cluster-id:9
ipam-cilium-node-update-rate:15s
bpf-map-dynamic-size-ratio:0.0025
install-no-conntrack-iptables-rules:false
arping-refresh-period:30s
kvstore-periodic-sync:5m0s
max-connected-clusters:255
cmdref:
tofqdns-pre-cache:
hubble-export-file-path:
agent-labels:
bpf-lb-algorithm:random
enable-encryption-strict-mode:false
node-port-algorithm:random
enable-active-connection-tracking:false
policy-trigger-interval:1s
enable-envoy-config:false
service-no-backend-response:reject
enable-health-check-loadbalancer-ip:false
hubble-socket-path:/var/run/cilium/hubble.sock
local-router-ipv6:
enable-gateway-api:false
policy-cidr-match-mode:
local-max-addr-scope:252
bpf-lb-mode:snat
routing-mode:tunnel
auto-create-cilium-node-resource:true
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
enable-metrics:true
bpf-lb-rev-nat-map-max:0
pprof-port:6060
datapath-mode:veth
state-dir:/var/run/cilium
ipv4-range:auto
enable-ipv6-big-tcp:false
enable-identity-mark:true
http-retry-count:3
enable-ipv6-ndp:false
node-port-bind-protection:true
bgp-config-path:/var/lib/cilium/bgp/config.yaml
nodeport-addresses:
http-request-timeout:3600
enable-k8s-api-discovery:false
enable-ipsec:false
debug-verbose:
ipam:cluster-pool
lib-dir:/var/lib/cilium
enable-node-port:false
k8s-client-connection-timeout:30s
hubble-export-file-max-backups:5
k8s-client-burst:20
keep-config:false
static-cnp-path:
proxy-portrange-max:20000
bpf-neigh-global-max:524288
enable-masquerade-to-route-source:false
bpf-ct-global-tcp-max:524288
dns-policy-unload-on-shutdown:false
enable-k8s:true
bpf-lb-dsr-l4-xlate:frontend
mesh-auth-signal-backoff-duration:1s
multicast-enabled:false
allow-localhost:auto
bpf-lb-acceleration:disabled
endpoint-queue-size:25
max-controller-interval:0
enable-ipsec-key-watcher:true
policy-audit-mode:false
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4         STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                   
217        Disabled           Disabled          620887     k8s:eks.amazonaws.com/component=coredns                                             10.8.0.145   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh9                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                          
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                              
                                                           k8s:k8s-app=kube-dns                                                                                     
234        Disabled           Disabled          594581     k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.8.0.209   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh9                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                              
                                                           k8s:k8s-app=clustermesh-apiserver                                                                        
1288       Disabled           Disabled          4          reserved:health                                                                     10.8.0.247   ready   
3317       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                  ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                    
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                              
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                               
                                                           reserved:host                                                                                            
3817       Disabled           Disabled          620887     k8s:eks.amazonaws.com/component=coredns                                             10.8.0.136   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh9                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                          
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                              
                                                           k8s:k8s-app=kube-dns                                                                                     
```

#### BPF Policy Get 217

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    88104   1019      0        
Allow    Egress      0          ANY          NONE         disabled    14956   158       0        

```


#### BPF CT List 217

```
Invalid argument: unknown type 217
```


#### Endpoint Get 217

```
[
  {
    "id": 217,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-217-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "18b9d5e1-0d33-4f2c-9851-5f9e3bdb6f85"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-217",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:00.789Z",
            "success-count": 4
          },
          "uuid": "fc7d4e17-b1d0-4bc6-a775-3b6fd3c8e5ce"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-65v59",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:00.786Z",
            "success-count": 1
          },
          "uuid": "0e11f2f8-71c8-432a-ab38-b196bfed42c7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-217",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:00.818Z",
            "success-count": 2
          },
          "uuid": "f53926cb-f48a-4463-aae1-73ce3e177f38"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (217)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:10.872Z",
            "success-count": 93
          },
          "uuid": "61131145-0e13-406d-b323-54b1827f8f50"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "06184c7c7cb19c34fd63a44c3f8f2ceaf39b1965ea94a0d7f9721fda068c6476:eth0",
        "container-id": "06184c7c7cb19c34fd63a44c3f8f2ceaf39b1965ea94a0d7f9721fda068c6476",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-65v59",
        "pod-name": "kube-system/coredns-cc6ccd49c-65v59"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 620887,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh9",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh9",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:32Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.8.0.145",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "4e:4f:0e:f3:c2:7e",
        "interface-index": 9,
        "interface-name": "lxc40e382469b26",
        "mac": "be:80:5e:d9:49:72"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 620887,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 620887,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 217

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 217

```
Timestamp              Status    State                   Message
2024-10-25T10:23:32Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:32Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:32Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:23:32Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:31Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:31Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:31Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:31Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:30Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:30Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:30Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:30Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:27Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:27Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:27Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:27Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:26Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:26Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:26Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:26Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:00Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:00Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:14:00Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:00Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 620887

```
ID       LABELS
620887   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh9
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 234

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3898734   35925     0        
Allow    Ingress     1          ANY          NONE         disabled    2842214   28471     0        
Allow    Egress      0          ANY          NONE         disabled    3717050   34806     0        

```


#### BPF CT List 234

```
Invalid argument: unknown type 234
```


#### Endpoint Get 234

```
[
  {
    "id": 234,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-234-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "923e31df-5c14-415b-9496-4ec136ce01f3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-234",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:01.799Z",
            "success-count": 2
          },
          "uuid": "67bf6d53-f4b1-4654-96e3-b8980d1a4575"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-68f6bb4cb5-6j4d8",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:01.798Z",
            "success-count": 1
          },
          "uuid": "e043ac1c-c250-42a0-8087-745025396bfb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-234",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:23:01.834Z",
            "success-count": 1
          },
          "uuid": "c08d3980-53ca-4ebe-a639-712b34ebccda"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (234)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:11.836Z",
            "success-count": 39
          },
          "uuid": "e154fb22-1d73-4f5a-918b-cc7c4cabb31a"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "b6de9451fb7a517c862719b64f46bd56ea062d56418597bdb39888848cabb026:eth0",
        "container-id": "b6de9451fb7a517c862719b64f46bd56ea062d56418597bdb39888848cabb026",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-68f6bb4cb5-6j4d8",
        "pod-name": "kube-system/clustermesh-apiserver-68f6bb4cb5-6j4d8"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 594581,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh9",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=68f6bb4cb5"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh9",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:32Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.8.0.209",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "be:5d:45:b4:aa:c0",
        "interface-index": 15,
        "interface-name": "lxcfb1e5e2ecd10",
        "mac": "ba:62:f5:52:5c:2e"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 594581,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 594581,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 234

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 234

```
Timestamp              Status   State                   Message
2024-10-25T10:23:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:32Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:23:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:01Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:23:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:23:01Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:23:01Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 594581

```
ID       LABELS
594581   k8s:app.kubernetes.io/name=clustermesh-apiserver
         k8s:app.kubernetes.io/part-of=cilium
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh9
         k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1288

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    444007   5680      0        
Allow    Ingress     1          ANY          NONE         disabled    12660    147       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 1288

```
Invalid argument: unknown type 1288
```


#### Endpoint Get 1288

```
[
  {
    "id": 1288,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1288-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f1941076-88e4-48d5-a862-ba6f24f438c3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1288",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:54.105Z",
            "success-count": 4
          },
          "uuid": "f9c52cc2-a2b3-42a9-ae45-c25a38595723"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1288",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:57.705Z",
            "success-count": 2
          },
          "uuid": "4513d701-638c-436b-b92d-001590b6a51c"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:32Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.8.0.247",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "ae:fe:1a:b0:5f:4f",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "56:ef:d9:a6:64:fd"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1288

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1288

```
Timestamp              Status   State                   Message
2024-10-25T10:23:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:32Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:13:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:57Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:13:57Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:13:54Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:54Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:53Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 3317

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 3317

```
Invalid argument: unknown type 3317
```


#### Endpoint Get 3317

```
[
  {
    "id": 3317,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3317-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "8c04bc9e-14b3-4ad7-bc04-8272c05b0a48"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3317",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:53.044Z",
            "success-count": 4
          },
          "uuid": "60aa6418-c7df-4afd-945e-673c36b6adde"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3317",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:54.372Z",
            "success-count": 2
          },
          "uuid": "5815e760-2790-4463-aa8c-6b87122bd5c9"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:32Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "9a:7b:9e:cd:a0:84",
        "interface-name": "cilium_host",
        "mac": "9a:7b:9e:cd:a0:84"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3317

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3317

```
Timestamp              Status   State                   Message
2024-10-25T10:23:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:32Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:13:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:55Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:13:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:13:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:53Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:53Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:53Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 3817

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    86652   997       0        
Allow    Egress      0          ANY          NONE         disabled    14079   147       0        

```


#### BPF CT List 3817

```
Invalid argument: unknown type 3817
```


#### Endpoint Get 3817

```
[
  {
    "id": 3817,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3817-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "8556a100-c709-4600-9b26-92961e182a24"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3817",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:01.840Z",
            "success-count": 4
          },
          "uuid": "16e42551-6882-47f3-96ee-4ba2dda5a8e8"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-f96m6",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:01.838Z",
            "success-count": 1
          },
          "uuid": "2a1b8367-37ff-4d79-bb85-835e1f7cddd6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3817",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:01.881Z",
            "success-count": 2
          },
          "uuid": "44903035-d67d-4e24-ae25-bc7b1f0e4137"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3817)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:11.923Z",
            "success-count": 93
          },
          "uuid": "93ab538a-1494-42c9-abf7-fbdd1dbe12c2"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "3eefa0598749e48f88d00dcb4c9fe94faf51145b1654f7264f29c288385d4c68:eth0",
        "container-id": "3eefa0598749e48f88d00dcb4c9fe94faf51145b1654f7264f29c288385d4c68",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-f96m6",
        "pod-name": "kube-system/coredns-cc6ccd49c-f96m6"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 620887,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh9",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh9",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:32Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.8.0.136",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "16:7b:79:92:a8:6c",
        "interface-index": 11,
        "interface-name": "lxcbfbc347a5d69",
        "mac": "b6:26:3d:1b:6b:17"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 620887,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 620887,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3817

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3817

```
Timestamp              Status   State                   Message
2024-10-25T10:23:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:32Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:01Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:01Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:01Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 620887

```
ID       LABELS
620887   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh9
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### Service list

```
ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.217.84:443 (active)     
                                        2 => 172.31.167.74:443 (active)     
2    10.100.134.0:443    ClusterIP      1 => 172.31.191.155:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.8.0.136:53 (active)         
                                        2 => 10.8.0.145:53 (active)         
4    10.100.0.10:9153    ClusterIP      1 => 10.8.0.136:9153 (active)       
                                        2 => 10.8.0.145:9153 (active)       
5    10.100.75.49:2379   ClusterIP      1 => 10.8.0.209:2379 (active)       
```

#### Policy get

```
:
 []
Revision: 1

```

