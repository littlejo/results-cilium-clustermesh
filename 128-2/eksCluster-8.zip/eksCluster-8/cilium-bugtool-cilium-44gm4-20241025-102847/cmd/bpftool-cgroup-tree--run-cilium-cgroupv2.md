CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod662f6fab_552f_47e4_8424_152b485794b4.slice/cri-containerd-a2a01a84a7699195205029fbf6dd345c88681c7b8bf3d366d7a717c61c48b18d.scope
    114      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod662f6fab_552f_47e4_8424_152b485794b4.slice/cri-containerd-b630cfed9f795d3d23b61008400555dc2e0bbdf5eb3079f602509137a49761f1.scope
    64       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfbffd25b_76a6_4259_a008_69538de0cba5.slice/cri-containerd-b5267b2454fb78281d7cf12997d9e524941ed730e53b0f21f8a6ad8403bb415f.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfbffd25b_76a6_4259_a008_69538de0cba5.slice/cri-containerd-3eefa0598749e48f88d00dcb4c9fe94faf51145b1654f7264f29c288385d4c68.scope
    531      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddf9c155d_f43d_4b70_9973_66040fe0dc05.slice/cri-containerd-a5e1fc42bdb2d4c6a7b10537fca49845ca5cc743772d646a953f7c03b2b2401c.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddf9c155d_f43d_4b70_9973_66040fe0dc05.slice/cri-containerd-06184c7c7cb19c34fd63a44c3f8f2ceaf39b1965ea94a0d7f9721fda068c6476.scope
    516      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod35d8a778_a905_490d_9576_034746f0af5d.slice/cri-containerd-d244b16ea0c1d313f32a5db8550315dd9efe734d85fccbe975956ac64b89231a.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod35d8a778_a905_490d_9576_034746f0af5d.slice/cri-containerd-42e55b772e01374ec2d416e95afa28ae90da51b58715bacaa80ea53017b29e54.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5e9b0f8f_7540_4540_aec3_9f45946daac5.slice/cri-containerd-6cbf982786ee5004e4412b6221defa283c305b54cdd337af467b3b7418eaa241.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5e9b0f8f_7540_4540_aec3_9f45946daac5.slice/cri-containerd-36a531057fea247aa971a8ae7a7066f79bd48a0bff5e874f87d2dc3d04348eb1.scope
    76       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9036ab7b_0226_4c3f_ae2b_6cc1e25e3f16.slice/cri-containerd-6039df7bd975fb2ef9f1be2db9d37bea2e775e805bfd5b46f5d6707158ecd1f6.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9036ab7b_0226_4c3f_ae2b_6cc1e25e3f16.slice/cri-containerd-801dd9f53c13aa59f09a08040f15b70d7a483f2d28a43e4111f312eb39b8109f.scope
    83       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaf1fe645_0018_48a3_8515_33a260df461e.slice/cri-containerd-3c040c11d160120c74f793d3e874b77ba9cec072dcbedff53b9f710d71344c7a.scope
    617      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaf1fe645_0018_48a3_8515_33a260df461e.slice/cri-containerd-4ef61e8a242c52ba0c446ad274cd99fb20064c3d3d66083e112d4fb8274bbe66.scope
    613      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaf1fe645_0018_48a3_8515_33a260df461e.slice/cri-containerd-01cc140780cf2e97b59e4db35037b57379de1caca48b48e4390560166f1ed7ca.scope
    609      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaf1fe645_0018_48a3_8515_33a260df461e.slice/cri-containerd-b6de9451fb7a517c862719b64f46bd56ea062d56418597bdb39888848cabb026.scope
    593      cgroup_device   multi                                          
