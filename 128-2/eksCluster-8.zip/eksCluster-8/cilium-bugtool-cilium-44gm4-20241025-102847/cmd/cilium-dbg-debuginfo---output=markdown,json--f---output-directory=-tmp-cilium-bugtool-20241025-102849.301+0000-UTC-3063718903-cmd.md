markdown output at /tmp/cilium-bugtool-20241025-102849.301+0000-UTC-3063718903/cmd/cilium-debuginfo-20241025-102919.989+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102849.301+0000-UTC-3063718903/cmd/cilium-debuginfo-20241025-102919.989+0000-UTC.json
