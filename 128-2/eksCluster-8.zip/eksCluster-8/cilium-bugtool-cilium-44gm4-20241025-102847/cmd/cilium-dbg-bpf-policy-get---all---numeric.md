Endpoint ID: 217
Path: /sys/fs/bpf/tc/globals/cilium_policy_00217

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    88104   1019      0        
Allow    Egress      0          ANY          NONE         disabled    14956   158       0        


Endpoint ID: 234
Path: /sys/fs/bpf/tc/globals/cilium_policy_00234

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3898734   35925     0        
Allow    Ingress     1          ANY          NONE         disabled    2842214   28471     0        
Allow    Egress      0          ANY          NONE         disabled    3757284   35252     0        


Endpoint ID: 1288
Path: /sys/fs/bpf/tc/globals/cilium_policy_01288

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    445778   5702      0        
Allow    Ingress     1          ANY          NONE         disabled    12660    147       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3317
Path: /sys/fs/bpf/tc/globals/cilium_policy_03317

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3817
Path: /sys/fs/bpf/tc/globals/cilium_policy_03817

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    86652   997       0        
Allow    Egress      0          ANY          NONE         disabled    14079   147       0        


