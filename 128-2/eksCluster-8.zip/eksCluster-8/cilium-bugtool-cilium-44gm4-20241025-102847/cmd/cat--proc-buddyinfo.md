Node 0, zone      DMA      9     48     38     35     17      7      4      1      2      2    171 
Node 0, zone   Normal    201     88      2     17     22      4      6      5      2      2      7 
