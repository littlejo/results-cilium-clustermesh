[
  {
    "containers": [
      {
        "cgroup-id": 8706,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaf1fe645_0018_48a3_8515_33a260df461e.slice/cri-containerd-4ef61e8a242c52ba0c446ad274cd99fb20064c3d3d66083e112d4fb8274bbe66.scope"
      },
      {
        "cgroup-id": 8622,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaf1fe645_0018_48a3_8515_33a260df461e.slice/cri-containerd-01cc140780cf2e97b59e4db35037b57379de1caca48b48e4390560166f1ed7ca.scope"
      },
      {
        "cgroup-id": 8790,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaf1fe645_0018_48a3_8515_33a260df461e.slice/cri-containerd-3c040c11d160120c74f793d3e874b77ba9cec072dcbedff53b9f710d71344c7a.scope"
      }
    ],
    "ips": [
      "10.8.0.209"
    ],
    "name": "clustermesh-apiserver-68f6bb4cb5-6j4d8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7194,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddf9c155d_f43d_4b70_9973_66040fe0dc05.slice/cri-containerd-a5e1fc42bdb2d4c6a7b10537fca49845ca5cc743772d646a953f7c03b2b2401c.scope"
      }
    ],
    "ips": [
      "10.8.0.145"
    ],
    "name": "coredns-cc6ccd49c-65v59",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7278,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfbffd25b_76a6_4259_a008_69538de0cba5.slice/cri-containerd-b5267b2454fb78281d7cf12997d9e524941ed730e53b0f21f8a6ad8403bb415f.scope"
      }
    ],
    "ips": [
      "10.8.0.136"
    ],
    "name": "coredns-cc6ccd49c-f96m6",
    "namespace": "kube-system"
  }
]

