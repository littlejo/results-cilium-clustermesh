{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.869Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.191.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.869Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:57.703Z",
  "value": "id=1288  sec_id=4     flags=0x0000 ifindex=7   mac=56:EF:D9:A6:64:FD nodemac=AE:FE:1A:B0:5F:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:57.740Z",
  "value": "id=1288  sec_id=4     flags=0x0000 ifindex=7   mac=56:EF:D9:A6:64:FD nodemac=AE:FE:1A:B0:5F:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:00.786Z",
  "value": "id=1288  sec_id=4     flags=0x0000 ifindex=7   mac=56:EF:D9:A6:64:FD nodemac=AE:FE:1A:B0:5F:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:00.818Z",
  "value": "id=217   sec_id=620887 flags=0x0000 ifindex=9   mac=BE:80:5E:D9:49:72 nodemac=4E:4F:0E:F3:C2:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:01.786Z",
  "value": "id=1288  sec_id=4     flags=0x0000 ifindex=7   mac=56:EF:D9:A6:64:FD nodemac=AE:FE:1A:B0:5F:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:01.787Z",
  "value": "id=217   sec_id=620887 flags=0x0000 ifindex=9   mac=BE:80:5E:D9:49:72 nodemac=4E:4F:0E:F3:C2:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:01.881Z",
  "value": "id=3817  sec_id=620887 flags=0x0000 ifindex=11  mac=B6:26:3D:1B:6B:17 nodemac=16:7B:79:92:A8:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:26.717Z",
  "value": "id=3817  sec_id=620887 flags=0x0000 ifindex=11  mac=B6:26:3D:1B:6B:17 nodemac=16:7B:79:92:A8:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:26.718Z",
  "value": "id=1288  sec_id=4     flags=0x0000 ifindex=7   mac=56:EF:D9:A6:64:FD nodemac=AE:FE:1A:B0:5F:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:26.718Z",
  "value": "id=217   sec_id=620887 flags=0x0000 ifindex=9   mac=BE:80:5E:D9:49:72 nodemac=4E:4F:0E:F3:C2:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:26.752Z",
  "value": "id=2098  sec_id=594581 flags=0x0000 ifindex=13  mac=36:5C:D3:61:18:90 nodemac=66:74:2B:2D:6C:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:26.753Z",
  "value": "id=2098  sec_id=594581 flags=0x0000 ifindex=13  mac=36:5C:D3:61:18:90 nodemac=66:74:2B:2D:6C:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:27.717Z",
  "value": "id=217   sec_id=620887 flags=0x0000 ifindex=9   mac=BE:80:5E:D9:49:72 nodemac=4E:4F:0E:F3:C2:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:27.717Z",
  "value": "id=3817  sec_id=620887 flags=0x0000 ifindex=11  mac=B6:26:3D:1B:6B:17 nodemac=16:7B:79:92:A8:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:27.717Z",
  "value": "id=2098  sec_id=594581 flags=0x0000 ifindex=13  mac=36:5C:D3:61:18:90 nodemac=66:74:2B:2D:6C:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:27.717Z",
  "value": "id=1288  sec_id=4     flags=0x0000 ifindex=7   mac=56:EF:D9:A6:64:FD nodemac=AE:FE:1A:B0:5F:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:01.834Z",
  "value": "id=234   sec_id=594581 flags=0x0000 ifindex=15  mac=BA:62:F5:52:5C:2E nodemac=BE:5D:45:B4:AA:C0"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.8.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:08.594Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:30.290Z",
  "value": "id=3817  sec_id=620887 flags=0x0000 ifindex=11  mac=B6:26:3D:1B:6B:17 nodemac=16:7B:79:92:A8:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:30.290Z",
  "value": "id=234   sec_id=594581 flags=0x0000 ifindex=15  mac=BA:62:F5:52:5C:2E nodemac=BE:5D:45:B4:AA:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:30.291Z",
  "value": "id=1288  sec_id=4     flags=0x0000 ifindex=7   mac=56:EF:D9:A6:64:FD nodemac=AE:FE:1A:B0:5F:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:30.292Z",
  "value": "id=217   sec_id=620887 flags=0x0000 ifindex=9   mac=BE:80:5E:D9:49:72 nodemac=4E:4F:0E:F3:C2:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:31.290Z",
  "value": "id=234   sec_id=594581 flags=0x0000 ifindex=15  mac=BA:62:F5:52:5C:2E nodemac=BE:5D:45:B4:AA:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:31.290Z",
  "value": "id=1288  sec_id=4     flags=0x0000 ifindex=7   mac=56:EF:D9:A6:64:FD nodemac=AE:FE:1A:B0:5F:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:31.291Z",
  "value": "id=217   sec_id=620887 flags=0x0000 ifindex=9   mac=BE:80:5E:D9:49:72 nodemac=4E:4F:0E:F3:C2:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:31.291Z",
  "value": "id=3817  sec_id=620887 flags=0x0000 ifindex=11  mac=B6:26:3D:1B:6B:17 nodemac=16:7B:79:92:A8:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:32.291Z",
  "value": "id=1288  sec_id=4     flags=0x0000 ifindex=7   mac=56:EF:D9:A6:64:FD nodemac=AE:FE:1A:B0:5F:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:32.291Z",
  "value": "id=234   sec_id=594581 flags=0x0000 ifindex=15  mac=BA:62:F5:52:5C:2E nodemac=BE:5D:45:B4:AA:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:32.291Z",
  "value": "id=217   sec_id=620887 flags=0x0000 ifindex=9   mac=BE:80:5E:D9:49:72 nodemac=4E:4F:0E:F3:C2:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.8.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:32.291Z",
  "value": "id=3817  sec_id=620887 flags=0x0000 ifindex=11  mac=B6:26:3D:1B:6B:17 nodemac=16:7B:79:92:A8:6C"
}

