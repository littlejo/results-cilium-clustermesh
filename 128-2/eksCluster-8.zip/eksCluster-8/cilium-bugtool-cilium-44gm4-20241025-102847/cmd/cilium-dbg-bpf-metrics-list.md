REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     213758    99439352   1132   bpf_host.c
Interface                 INGRESS     9625      750690     677    bpf_overlay.c
Success                   EGRESS      4597      350779     1694   bpf_host.c
Success                   EGRESS      87866     12038282   1308   bpf_lxc.c
Success                   EGRESS      9421      736685     53     encap.h
Success                   INGRESS     104928    12468853   235    trace.h
Success                   INGRESS     99251     12025036   86     l3.h
Unsupported L3 protocol   EGRESS      46        3508       1492   bpf_lxc.c
