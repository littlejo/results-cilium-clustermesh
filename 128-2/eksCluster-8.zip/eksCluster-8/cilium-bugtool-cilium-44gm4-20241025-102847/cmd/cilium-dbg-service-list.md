ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.217.84:443 (active)     
                                        2 => 172.31.167.74:443 (active)     
2    10.100.134.0:443    ClusterIP      1 => 172.31.191.155:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.8.0.136:53 (active)         
                                        2 => 10.8.0.145:53 (active)         
4    10.100.0.10:9153    ClusterIP      1 => 10.8.0.136:9153 (active)       
                                        2 => 10.8.0.145:9153 (active)       
5    10.100.75.49:2379   ClusterIP      1 => 10.8.0.209:2379 (active)       
