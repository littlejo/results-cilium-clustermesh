REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     205599    98481542   1132   bpf_host.c
Interface                 INGRESS     9582      750192     677    bpf_overlay.c
Success                   EGRESS      5199      400742     1694   bpf_host.c
Success                   EGRESS      87786     11172307   1308   bpf_lxc.c
Success                   EGRESS      9920      1568128    86     l3.h
Success                   EGRESS      9986      780308     53     encap.h
Success                   INGRESS     112382    13755308   235    trace.h
Success                   INGRESS     97430     11793824   86     l3.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
