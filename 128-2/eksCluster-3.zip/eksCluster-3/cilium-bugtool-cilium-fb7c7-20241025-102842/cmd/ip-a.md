1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:33:1b:ca:33:c9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.250.86/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2646sec preferred_lft 2646sec
    inet6 fe80::833:1bff:feca:33c9/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:92:ec:f5:a4:85 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1492:ecff:fef5:a485/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:fc:26:2f:0b:8e brd ff:ff:ff:ff:ff:ff
    inet 10.3.0.60/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::e4fc:26ff:fe2f:b8e/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 8e:ab:19:90:b9:d7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8cab:19ff:fe90:b9d7/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:74:ce:f9:3b:80 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::9874:ceff:fef9:3b80/64 scope link 
       valid_lft forever preferred_lft forever
9: lxcd3945cdc51b1@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:37:92:ce:81:4f brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::f837:92ff:fece:814f/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc3686a18a2bd1@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:36:c5:35:8c:cb brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::4c36:c5ff:fe35:8ccb/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc6cdecabbcb25@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:f6:c0:77:50:5d brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::9cf6:c0ff:fe77:505d/64 scope link 
       valid_lft forever preferred_lft forever
