35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:41+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:41+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:41+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:12:42+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:12:43+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:12:43+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:12:43+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:43+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:12:47+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
61: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
64: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
69: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
72: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
75: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
79: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
82: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
83: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
86: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
110: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
113: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
454: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 70,91
	btf_id 112
455: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 113
456: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 114
457: sched_cls  name tail_handle_ipv4  tag b55e6d782963661f  gpl
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 69,68,75,70,91
	btf_id 115
480: sched_cls  name tail_handle_ipv4_cont  tag c16a28911fe1792e  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,103,35,99,76,77,33,70,68,71,102,34,31,32,75
	btf_id 143
484: sched_cls  name tail_handle_ipv4  tag 7cf3c348b50fc469  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,102
	btf_id 145
487: sched_cls  name cil_from_container  tag ccf308d45d96cdd8  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 102,70
	btf_id 151
491: sched_cls  name handle_policy  tag 4b844c53ec44ac46  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,102,76,77,103,35,74,99,33,78,69,34,31,32
	btf_id 152
492: sched_cls  name tail_ipv4_ct_egress  tag e1d292a1f979117f  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,102,76,77,103,78
	btf_id 156
493: sched_cls  name __send_drop_notify  tag 7e7357c88b0cd2b2  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 157
496: sched_cls  name tail_ipv4_to_endpoint  tag b86d9b7847388d30  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,103,35,76,77,74,99,33,102,34,31,32
	btf_id 158
497: sched_cls  name tail_handle_arp  tag 0321cb26562366a2  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,102
	btf_id 161
498: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,102
	btf_id 162
500: sched_cls  name tail_handle_arp  tag 18baf638ef7aabbc  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,106
	btf_id 165
501: sched_cls  name __send_drop_notify  tag c11d54bcb2b80155  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 166
502: sched_cls  name cil_from_container  tag 5c1650bf8669ae23  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 106,70
	btf_id 167
503: sched_cls  name tail_ipv4_ct_ingress  tag 0a9d9a258ef327d7  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,102,76,77,103,78
	btf_id 163
504: sched_cls  name __send_drop_notify  tag 96965be46913a14a  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 170
506: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 70,69,108
	btf_id 172
507: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 173
508: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,108
	btf_id 174
509: sched_cls  name tail_handle_ipv4  tag 44454b5c7053280d  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,106
	btf_id 168
511: sched_cls  name tail_handle_ipv4_from_host  tag e3848cca8a21269b  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,108
	btf_id 176
514: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 180
515: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,109
	btf_id 181
517: sched_cls  name tail_handle_ipv4_from_host  tag e3848cca8a21269b  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,109
	btf_id 183
518: sched_cls  name __send_drop_notify  tag 96965be46913a14a  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 184
519: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,111
	btf_id 186
520: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 70,111,69
	btf_id 187
521: sched_cls  name tail_handle_ipv4_from_host  tag e3848cca8a21269b  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,111
	btf_id 189
522: sched_cls  name __send_drop_notify  tag 96965be46913a14a  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 190
526: sched_cls  name tail_handle_arp  tag a6ac70b893d1277f  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,114
	btf_id 195
527: sched_cls  name tail_ipv4_ct_ingress  tag 76efb9cd5a134ca9  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 70,114,76,77,113,78
	btf_id 196
529: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,114
	btf_id 198
530: sched_cls  name __send_drop_notify  tag 45274c4e510d88b3  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 199
531: sched_cls  name handle_policy  tag 3e19eeb327b3c917  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,106,76,77,105,35,74,104,33,78,69,34,31,32
	btf_id 188
532: sched_cls  name tail_ipv4_to_endpoint  tag e844a8110afcdd31  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 69,70,113,35,76,77,74,92,33,114,34,31,32
	btf_id 200
533: sched_cls  name cil_from_container  tag 2003d16a2c2b6c31  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 114,70
	btf_id 202
534: sched_cls  name tail_handle_ipv4_cont  tag 1de9093af00a1755  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,105,35,104,76,77,33,70,68,71,106,34,31,32,75
	btf_id 201
535: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,106
	btf_id 204
537: sched_cls  name handle_policy  tag 301a3e6921f524b3  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 70,114,76,77,113,35,74,92,33,78,69,34,31,32
	btf_id 203
538: sched_cls  name tail_handle_ipv4_cont  tag 50ea26f7004e559a  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 69,113,35,92,76,77,33,70,68,71,114,34,31,32,75
	btf_id 207
539: sched_cls  name tail_ipv4_to_endpoint  tag f35bec9912a7a2ea  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,105,35,76,77,74,104,33,106,34,31,32
	btf_id 206
540: sched_cls  name tail_handle_ipv4  tag 10f38cf9792074c7  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,114
	btf_id 208
541: sched_cls  name tail_ipv4_ct_egress  tag e1d292a1f979117f  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,106,76,77,105,78
	btf_id 209
542: sched_cls  name tail_ipv4_ct_ingress  tag 0f7b90c49901d943  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,106,76,77,105,78
	btf_id 210
543: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 70,114,76,77,113,78
	btf_id 211
544: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
547: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
548: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
551: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
552: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
555: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
556: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
559: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
599: sched_cls  name handle_policy  tag 1c66f0fdc0f23993  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,131,76,77,130,35,74,129,33,78,69,34,31,32
	btf_id 227
600: sched_cls  name tail_ipv4_ct_egress  tag 18c9e2b4e0d0cee0  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,131,76,77,130,78
	btf_id 228
601: sched_cls  name tail_handle_arp  tag 4e3cd009202d5df8  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,131
	btf_id 229
602: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,131
	btf_id 230
603: sched_cls  name cil_from_container  tag e7ca3a3974db3e61  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 131,70
	btf_id 231
604: sched_cls  name tail_ipv4_to_endpoint  tag 54d8f7fc40710b00  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,130,35,76,77,74,129,33,131,34,31,32
	btf_id 232
606: sched_cls  name tail_ipv4_ct_ingress  tag a43d40a29f76a437  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,131,76,77,130,78
	btf_id 234
607: sched_cls  name __send_drop_notify  tag 3e650b089fcc5e0c  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 235
608: sched_cls  name tail_handle_ipv4_cont  tag 143635472c668439  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,130,35,129,76,77,33,70,68,71,131,34,31,32,75
	btf_id 236
609: sched_cls  name tail_handle_ipv4  tag ac37af90ce47405d  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,131
	btf_id 237
610: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
613: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
626: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
629: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
630: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
633: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
634: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
637: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
