Endpoint ID: 800
Path: /sys/fs/bpf/tc/globals/cilium_policy_00800

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    274021   2468      0        
Allow    Ingress     1          ANY          NONE         disabled    87246    1006      0        
Allow    Egress      0          ANY          NONE         disabled    64373    619       0        


Endpoint ID: 1151
Path: /sys/fs/bpf/tc/globals/cilium_policy_01151

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1465
Path: /sys/fs/bpf/tc/globals/cilium_policy_01465

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    276427   2492      0        
Allow    Ingress     1          ANY          NONE         disabled    86586    996       0        
Allow    Egress      0          ANY          NONE         disabled    66023    637       0        


Endpoint ID: 2028
Path: /sys/fs/bpf/tc/globals/cilium_policy_02028

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3172104   31693     0        
Allow    Ingress     1          ANY          NONE         disabled    3186305   32240     0        
Allow    Egress      0          ANY          NONE         disabled    4684942   43845     0        


Endpoint ID: 2641
Path: /sys/fs/bpf/tc/globals/cilium_policy_02641

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    394746   5050      0        
Allow    Ingress     1          ANY          NONE         disabled    13212    155       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


