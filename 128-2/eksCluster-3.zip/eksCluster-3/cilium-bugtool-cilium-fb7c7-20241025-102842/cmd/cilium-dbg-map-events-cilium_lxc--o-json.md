{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:24.727Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.250.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:24.727Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:28.925Z",
  "value": "id=2641  sec_id=4     flags=0x0000 ifindex=7   mac=DE:A8:43:AE:5D:65 nodemac=9A:74:CE:F9:3B:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:28.929Z",
  "value": "id=1465  sec_id=319189 flags=0x0000 ifindex=9   mac=BE:A9:11:6B:6F:B3 nodemac=FA:37:92:CE:81:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:28.988Z",
  "value": "id=800   sec_id=319189 flags=0x0000 ifindex=11  mac=D2:50:20:28:2A:39 nodemac=4E:36:C5:35:8C:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:28.989Z",
  "value": "id=2641  sec_id=4     flags=0x0000 ifindex=7   mac=DE:A8:43:AE:5D:65 nodemac=9A:74:CE:F9:3B:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:50.498Z",
  "value": "id=1465  sec_id=319189 flags=0x0000 ifindex=9   mac=BE:A9:11:6B:6F:B3 nodemac=FA:37:92:CE:81:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:50.498Z",
  "value": "id=800   sec_id=319189 flags=0x0000 ifindex=11  mac=D2:50:20:28:2A:39 nodemac=4E:36:C5:35:8C:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:50.498Z",
  "value": "id=2641  sec_id=4     flags=0x0000 ifindex=7   mac=DE:A8:43:AE:5D:65 nodemac=9A:74:CE:F9:3B:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:50.531Z",
  "value": "id=517   sec_id=273182 flags=0x0000 ifindex=13  mac=72:14:95:73:DE:FD nodemac=6A:D0:81:08:FE:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:51.498Z",
  "value": "id=1465  sec_id=319189 flags=0x0000 ifindex=9   mac=BE:A9:11:6B:6F:B3 nodemac=FA:37:92:CE:81:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:51.498Z",
  "value": "id=517   sec_id=273182 flags=0x0000 ifindex=13  mac=72:14:95:73:DE:FD nodemac=6A:D0:81:08:FE:04"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:51.498Z",
  "value": "id=2641  sec_id=4     flags=0x0000 ifindex=7   mac=DE:A8:43:AE:5D:65 nodemac=9A:74:CE:F9:3B:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:51.499Z",
  "value": "id=800   sec_id=319189 flags=0x0000 ifindex=11  mac=D2:50:20:28:2A:39 nodemac=4E:36:C5:35:8C:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:27.862Z",
  "value": "id=2028  sec_id=273182 flags=0x0000 ifindex=15  mac=3A:90:46:AC:58:9D nodemac=9E:F6:C0:77:50:5D"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.3.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:32.994Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.020Z",
  "value": "id=2028  sec_id=273182 flags=0x0000 ifindex=15  mac=3A:90:46:AC:58:9D nodemac=9E:F6:C0:77:50:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.021Z",
  "value": "id=1465  sec_id=319189 flags=0x0000 ifindex=9   mac=BE:A9:11:6B:6F:B3 nodemac=FA:37:92:CE:81:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.021Z",
  "value": "id=2641  sec_id=4     flags=0x0000 ifindex=7   mac=DE:A8:43:AE:5D:65 nodemac=9A:74:CE:F9:3B:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.021Z",
  "value": "id=800   sec_id=319189 flags=0x0000 ifindex=11  mac=D2:50:20:28:2A:39 nodemac=4E:36:C5:35:8C:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:08.020Z",
  "value": "id=2641  sec_id=4     flags=0x0000 ifindex=7   mac=DE:A8:43:AE:5D:65 nodemac=9A:74:CE:F9:3B:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:08.020Z",
  "value": "id=2028  sec_id=273182 flags=0x0000 ifindex=15  mac=3A:90:46:AC:58:9D nodemac=9E:F6:C0:77:50:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:08.021Z",
  "value": "id=800   sec_id=319189 flags=0x0000 ifindex=11  mac=D2:50:20:28:2A:39 nodemac=4E:36:C5:35:8C:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:08.021Z",
  "value": "id=1465  sec_id=319189 flags=0x0000 ifindex=9   mac=BE:A9:11:6B:6F:B3 nodemac=FA:37:92:CE:81:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:09.021Z",
  "value": "id=800   sec_id=319189 flags=0x0000 ifindex=11  mac=D2:50:20:28:2A:39 nodemac=4E:36:C5:35:8C:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:09.022Z",
  "value": "id=1465  sec_id=319189 flags=0x0000 ifindex=9   mac=BE:A9:11:6B:6F:B3 nodemac=FA:37:92:CE:81:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:09.022Z",
  "value": "id=2028  sec_id=273182 flags=0x0000 ifindex=15  mac=3A:90:46:AC:58:9D nodemac=9E:F6:C0:77:50:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:09.022Z",
  "value": "id=2641  sec_id=4     flags=0x0000 ifindex=7   mac=DE:A8:43:AE:5D:65 nodemac=9A:74:CE:F9:3B:80"
}

