Node 0, zone      DMA     68     49     34     29     32     28     20     21     16     13    211 
Node 0, zone   Normal    672    166     66     37     25     16     10      4      5      3     13 
