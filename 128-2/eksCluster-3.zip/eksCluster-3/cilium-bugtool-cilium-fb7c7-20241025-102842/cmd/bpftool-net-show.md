xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 520
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 514
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 507
cilium_host(4) clsact/egress cil_from_host-cilium_host id 506
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 454
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 455
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 533
lxcd3945cdc51b1(9) clsact/ingress cil_from_container-lxcd3945cdc51b1 id 487
lxc3686a18a2bd1(11) clsact/ingress cil_from_container-lxc3686a18a2bd1 id 502
lxc6cdecabbcb25(15) clsact/ingress cil_from_container-lxc6cdecabbcb25 id 603

flow_dissector:

netfilter:

