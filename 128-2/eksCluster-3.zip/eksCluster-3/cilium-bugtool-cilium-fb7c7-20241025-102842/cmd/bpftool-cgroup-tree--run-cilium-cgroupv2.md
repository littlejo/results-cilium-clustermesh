CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6feb3e5_0729_48f4_94f6_f197a429df91.slice/cri-containerd-9eb90de7c5ed7088e8bf15b8178129823bc9cc4553bfed854cf8ae70be680225.scope
    113      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6feb3e5_0729_48f4_94f6_f197a429df91.slice/cri-containerd-9465bdbda18ad3011ccff642369d8ca83d972645c22a258d7883cec42b8d3877.scope
    64       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2a305320_aca2_4273_94a2_d32dfa2a18a6.slice/cri-containerd-02a1d1bfb93ff458eeb8314f1fb245ca365c7767aed5c30dac2a5b7d79abd8a9.scope
    559      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2a305320_aca2_4273_94a2_d32dfa2a18a6.slice/cri-containerd-6318b9eee47212171985ef8b162e8cda512361213045dd5d986bef02976b7b74.scope
    547      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5e0bc497_d1fc_43bd_9d4c_98eeac0be7f4.slice/cri-containerd-6f9c1a9b1892f9332b0c43aa3c92e04e21cbae66579ad3e25a0b0e4dfc889379.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5e0bc497_d1fc_43bd_9d4c_98eeac0be7f4.slice/cri-containerd-6866e0a51904e0e4a21f125461565994d86d2cd01803a7482315eefcd00155b6.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda2ae510f_528b_49df_ae6d_5a69581c644a.slice/cri-containerd-658762f0749d4ec16635036ec8610f9f01a9da0a4c7a47fd367f3cf4fe8d692b.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda2ae510f_528b_49df_ae6d_5a69581c644a.slice/cri-containerd-ef979ef3fa46b694ce5ccf35e1af0c37169eb11370868f8ed91e927c507f361c.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb7601de6_263c_4e71_91de_0ce771b051ef.slice/cri-containerd-0d10a2e72b59fcc8a8c117f92da82ec73bbd01a6728fdc6a301ce22a4d2fd3f7.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb7601de6_263c_4e71_91de_0ce771b051ef.slice/cri-containerd-d5efdb01376254f817edfe85e7982163696eaece087109f2115e8f0e41b3734c.scope
    82       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd144d022_66f8_43cf_ad77_549bd6e751c5.slice/cri-containerd-f4945f9d68f42890edf59b3de88f78fa2c4b5b927fcc529f353660bf9dbaa1f6.scope
    86       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd144d022_66f8_43cf_ad77_549bd6e751c5.slice/cri-containerd-25701589a7d8dad5027781785cf5b74f26f21b94a4f003e6add69e51bebd3e3a.scope
    72       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec927d4c_81f9_4e55_a773_c757c56632b0.slice/cri-containerd-0d5c82639efcff891da09e24477819c424fb03eb4accb1a25c51f7e487554b2b.scope
    613      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec927d4c_81f9_4e55_a773_c757c56632b0.slice/cri-containerd-8c74a81df595f6afd826e5d6b9d8b35dac1e164ec1a0175ac956a9fb1c8ea167.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec927d4c_81f9_4e55_a773_c757c56632b0.slice/cri-containerd-b320102d382e8b8a36c4fe01b80b5a1ee13ef191a8e6672f8705e9c4be90ac8a.scope
    633      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec927d4c_81f9_4e55_a773_c757c56632b0.slice/cri-containerd-b65d18db98d1d96af9c84dc7260c44d8efd5da756a277cd66f30b6376b61bca9.scope
    629      cgroup_device   multi                                          
