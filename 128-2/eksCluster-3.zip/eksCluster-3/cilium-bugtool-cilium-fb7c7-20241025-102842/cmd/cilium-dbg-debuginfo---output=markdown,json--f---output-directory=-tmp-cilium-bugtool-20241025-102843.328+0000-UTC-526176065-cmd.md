markdown output at /tmp/cilium-bugtool-20241025-102843.328+0000-UTC-526176065/cmd/cilium-debuginfo-20241025-102844.613+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102843.328+0000-UTC-526176065/cmd/cilium-debuginfo-20241025-102844.613+0000-UTC.json
