[
  {
    "containers": [
      {
        "cgroup-id": 8543,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec927d4c_81f9_4e55_a773_c757c56632b0.slice/cri-containerd-b320102d382e8b8a36c4fe01b80b5a1ee13ef191a8e6672f8705e9c4be90ac8a.scope"
      },
      {
        "cgroup-id": 8459,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec927d4c_81f9_4e55_a773_c757c56632b0.slice/cri-containerd-b65d18db98d1d96af9c84dc7260c44d8efd5da756a277cd66f30b6376b61bca9.scope"
      },
      {
        "cgroup-id": 8627,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec927d4c_81f9_4e55_a773_c757c56632b0.slice/cri-containerd-8c74a81df595f6afd826e5d6b9d8b35dac1e164ec1a0175ac956a9fb1c8ea167.scope"
      }
    ],
    "ips": [
      "10.3.0.141"
    ],
    "name": "clustermesh-apiserver-6f8f5797cc-nrjng",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7031,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2a305320_aca2_4273_94a2_d32dfa2a18a6.slice/cri-containerd-02a1d1bfb93ff458eeb8314f1fb245ca365c7767aed5c30dac2a5b7d79abd8a9.scope"
      }
    ],
    "ips": [
      "10.3.0.224"
    ],
    "name": "coredns-cc6ccd49c-89bs4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7115,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda2ae510f_528b_49df_ae6d_5a69581c644a.slice/cri-containerd-ef979ef3fa46b694ce5ccf35e1af0c37169eb11370868f8ed91e927c507f361c.scope"
      }
    ],
    "ips": [
      "10.3.0.230"
    ],
    "name": "coredns-cc6ccd49c-g79vj",
    "namespace": "kube-system"
  }
]

