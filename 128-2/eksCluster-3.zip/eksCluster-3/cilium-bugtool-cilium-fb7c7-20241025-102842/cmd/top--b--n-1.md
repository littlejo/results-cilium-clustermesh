top - 10:28:43 up 16 min,  0 users,  load average: 0.04, 0.13, 0.12
Tasks:   7 total,   2 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 39.3 us, 50.0 sy,  0.0 ni, 10.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1023.0 free,    894.6 used,   1918.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2773.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1472496 276412  79108 R  50.0   7.0   0:21.38 cilium-+
    402 root      20   0 1228848   5912   3060 S   0.0   0.2   0:00.24 cilium-+
    641 root      20   0 1240432  16608  11292 S   0.0   0.4   0:00.02 cilium-+
    686 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    687 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    730 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    736 root      20   0 1616264   8772   6264 S   0.0   0.2   0:00.00 runc:[2+
