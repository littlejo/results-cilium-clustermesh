key: 20 03 00 00  value: 13 02 00 00
key: b9 05 00 00  value: eb 01 00 00
key: ec 07 00 00  value: 57 02 00 00
key: 51 0a 00 00  value: 19 02 00 00
Found 4 elements
