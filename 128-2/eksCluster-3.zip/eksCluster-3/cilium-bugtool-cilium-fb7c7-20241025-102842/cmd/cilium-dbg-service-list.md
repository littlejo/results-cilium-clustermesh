ID   Frontend            Service Type   Backend                            
1    10.100.0.1:443      ClusterIP      1 => 172.31.156.219:443 (active)   
                                        2 => 172.31.235.4:443 (active)     
2    10.100.249.2:443    ClusterIP      1 => 172.31.250.86:4244 (active)   
3    10.100.0.10:9153    ClusterIP      1 => 10.3.0.224:9153 (active)      
                                        2 => 10.3.0.230:9153 (active)      
4    10.100.0.10:53      ClusterIP      1 => 10.3.0.224:53 (active)        
                                        2 => 10.3.0.230:53 (active)        
5    10.100.58.82:2379   ClusterIP      1 => 10.3.0.141:2379 (active)      
