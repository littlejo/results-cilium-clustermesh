KEY             VALUE
AgentLiveness   967283339531
UTimeOffset     3378615544921875
