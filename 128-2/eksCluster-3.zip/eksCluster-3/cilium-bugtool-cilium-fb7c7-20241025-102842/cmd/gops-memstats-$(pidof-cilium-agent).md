alloc: 75.55MB (79217392 bytes)
total-alloc: 1.36GB (1460836328 bytes)
sys: 206.38MB (216409428 bytes)
lookups: 0
mallocs: 48335679
frees: 47854606
heap-alloc: 75.55MB (79217392 bytes)
heap-sys: 163.82MB (171778048 bytes)
heap-idle: 42.68MB (44752896 bytes)
heap-in-use: 121.14MB (127025152 bytes)
heap-released: 3.21MB (3366912 bytes)
heap-objects: 481073
stack-in-use: 32.16MB (33718272 bytes)
stack-sys: 32.16MB (33718272 bytes)
stack-mspan-inuse: 1.92MB (2012960 bytes)
stack-mspan-sys: 2.41MB (2529600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1007.55KB (1031729 bytes)
gc-sys: 5.11MB (5355584 bytes)
next-gc: when heap-alloc >= 142.23MB (149133816 bytes)
last-gc: 2024-10-25 10:28:43.117892656 +0000 UTC
gc-pause-total: 9.064327ms
gc-pause: 2070902
gc-pause-end: 1729852123117892656
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.00032226461342557396
enable-gc: true
debug-gc: false
