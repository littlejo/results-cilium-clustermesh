IP ADDRESS        LOCAL ENDPOINT INFO
10.3.0.230:0      id=800   sec_id=319189 flags=0x0000 ifindex=11  mac=D2:50:20:28:2A:39 nodemac=4E:36:C5:35:8C:CB   
10.3.0.60:0       (localhost)                                                                                       
10.3.0.141:0      id=2028  sec_id=273182 flags=0x0000 ifindex=15  mac=3A:90:46:AC:58:9D nodemac=9E:F6:C0:77:50:5D   
10.3.0.224:0      id=1465  sec_id=319189 flags=0x0000 ifindex=9   mac=BE:A9:11:6B:6F:B3 nodemac=FA:37:92:CE:81:4F   
10.3.0.169:0      id=2641  sec_id=4     flags=0x0000 ifindex=7   mac=DE:A8:43:AE:5D:65 nodemac=9A:74:CE:F9:3B:80    
172.31.250.86:0   (localhost)                                                                                       
