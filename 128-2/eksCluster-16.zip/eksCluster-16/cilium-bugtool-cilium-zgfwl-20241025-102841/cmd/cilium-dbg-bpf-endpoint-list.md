IP ADDRESS         LOCAL ENDPOINT INFO
10.16.0.81:0       id=4028  sec_id=4     flags=0x0000 ifindex=7   mac=4E:8F:FC:A6:AD:FB nodemac=EE:8F:95:0C:47:D9     
10.16.0.96:0       id=258   sec_id=1150457 flags=0x0000 ifindex=9   mac=5E:A4:28:93:9A:22 nodemac=8E:F8:FE:42:EF:BD   
172.31.154.239:0   (localhost)                                                                                        
10.16.0.226:0      (localhost)                                                                                        
10.16.0.140:0      id=351   sec_id=1150457 flags=0x0000 ifindex=11  mac=C6:E9:E2:83:0D:F8 nodemac=0A:29:B1:2D:01:82   
10.16.0.76:0       id=2640  sec_id=1169229 flags=0x0000 ifindex=15  mac=86:7C:9A:92:15:2D nodemac=D6:D9:9D:97:E1:38   
