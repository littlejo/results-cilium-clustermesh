35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:04+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:04+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:04+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:04+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:04+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:04+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
74: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
77: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
78: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
81: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
82: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
85: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
86: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
89: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
117: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
120: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
461: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 114
462: sched_cls  name tail_handle_ipv4  tag 791eda9f8250db26  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 71,70,77,72,93
	btf_id 115
463: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 72,93
	btf_id 116
464: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 117
465: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 72,71,95
	btf_id 119
467: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 121
468: sched_cls  name __send_drop_notify  tag 5ccb332d9b7d2368  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 122
469: sched_cls  name tail_handle_ipv4_from_host  tag e1edd909f01bfa69  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,95
	btf_id 123
471: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,95
	btf_id 125
472: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 127
473: sched_cls  name __send_drop_notify  tag 5ccb332d9b7d2368  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 128
474: sched_cls  name tail_handle_ipv4_from_host  tag e1edd909f01bfa69  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,97
	btf_id 129
476: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,97
	btf_id 131
481: sched_cls  name __send_drop_notify  tag 5ccb332d9b7d2368  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 137
482: sched_cls  name tail_handle_ipv4_from_host  tag e1edd909f01bfa69  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,99
	btf_id 138
483: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 72,99,71
	btf_id 139
484: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,99
	btf_id 140
487: sched_cls  name tail_ipv4_to_endpoint  tag 38f9f6f8ca13fd46  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,104,37,78,79,76,101,35,105,36,33,34
	btf_id 145
490: sched_cls  name tail_ipv4_ct_ingress  tag 8e05015bde6913ed  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,105,78,79,104,80
	btf_id 148
492: sched_cls  name __send_drop_notify  tag 789fe372529d5af3  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 150
493: sched_cls  name tail_handle_ipv4  tag 747d2910c9ea5956  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,105
	btf_id 152
494: sched_cls  name tail_ipv4_ct_egress  tag 2e35d331abc62a9b  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,105,78,79,104,80
	btf_id 153
499: sched_cls  name tail_handle_ipv4_cont  tag ce9e0b2f6e449582  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,104,37,101,78,79,35,72,70,73,105,36,33,34,77
	btf_id 157
503: sched_cls  name handle_policy  tag 16560f58f0b9e680  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,105,78,79,104,37,76,101,35,80,71,36,33,34
	btf_id 159
504: sched_cls  name __send_drop_notify  tag d94d0caaa83097f1  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 164
505: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,105
	btf_id 162
506: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,106
	btf_id 165
507: sched_cls  name cil_from_container  tag 17b0b26854b36c3a  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 105,72
	btf_id 166
509: sched_cls  name tail_handle_arp  tag 69647a4cfa5cefeb  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,105
	btf_id 168
511: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 72,106,78,79,107,80
	btf_id 169
512: sched_cls  name tail_handle_arp  tag 0bfdcc80dbe7f082  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,106
	btf_id 171
513: sched_cls  name tail_ipv4_to_endpoint  tag a5b01e0778613c31  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 71,72,107,37,78,79,76,94,35,106,36,33,34
	btf_id 172
514: sched_cls  name tail_ipv4_ct_ingress  tag b4f9bf5c5266cf43  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 72,106,78,79,107,80
	btf_id 173
515: sched_cls  name tail_handle_ipv4  tag 7dcdad0bc50a269f  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,106
	btf_id 174
516: sched_cls  name tail_handle_ipv4_cont  tag a1d5d8c41a422892  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 71,107,37,94,78,79,35,72,70,73,106,36,33,34,77
	btf_id 175
517: sched_cls  name cil_from_container  tag 93279cd2227704f2  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 106,72
	btf_id 176
518: sched_cls  name handle_policy  tag 9fd4dbb1e9f63ad4  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 72,106,78,79,107,37,76,94,35,80,71,36,33,34
	btf_id 177
519: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
522: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
523: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
526: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
527: sched_cls  name __send_drop_notify  tag 82acac4a716611e8  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 180
528: sched_cls  name tail_ipv4_ct_ingress  tag 8dffeee5988a5f10  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,112,78,79,111,80
	btf_id 181
529: sched_cls  name cil_from_container  tag 993248ae7a4d3866  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,72
	btf_id 182
530: sched_cls  name tail_handle_ipv4_cont  tag 0e24ba362de627cb  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,111,37,110,78,79,35,72,70,73,112,36,33,34,77
	btf_id 183
531: sched_cls  name tail_ipv4_ct_egress  tag 2e35d331abc62a9b  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,112,78,79,111,80
	btf_id 184
533: sched_cls  name tail_ipv4_to_endpoint  tag f18a48baefb6fd16  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,111,37,78,79,76,110,35,112,36,33,34
	btf_id 186
534: sched_cls  name tail_handle_arp  tag 993bcd2199e7037f  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,112
	btf_id 187
535: sched_cls  name tail_handle_ipv4  tag 8243145b2c57aa2c  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,112
	btf_id 188
536: sched_cls  name handle_policy  tag 6f0f00136094b0a5  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,112,78,79,111,37,76,110,35,80,71,36,33,34
	btf_id 189
537: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,112
	btf_id 190
538: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
541: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
542: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
545: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
586: sched_cls  name tail_handle_ipv4  tag fc6a361334edebaf  gpl
	loaded_at 2024-10-25T10:22:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,126
	btf_id 206
587: sched_cls  name handle_policy  tag 9ff0ae9a5bbf5cbe  gpl
	loaded_at 2024-10-25T10:22:10+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,126,78,79,127,37,76,125,35,80,71,36,33,34
	btf_id 207
588: sched_cls  name tail_ipv4_to_endpoint  tag a60ef4dd5ee0d006  gpl
	loaded_at 2024-10-25T10:22:10+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,127,37,78,79,76,125,35,126,36,33,34
	btf_id 208
589: sched_cls  name tail_handle_ipv4_cont  tag ab3892377c1017d9  gpl
	loaded_at 2024-10-25T10:22:10+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,127,37,125,78,79,35,72,70,73,126,36,33,34,77
	btf_id 209
590: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,126
	btf_id 210
591: sched_cls  name tail_handle_arp  tag 7e6f019706fd657b  gpl
	loaded_at 2024-10-25T10:22:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,126
	btf_id 211
592: sched_cls  name tail_ipv4_ct_egress  tag 2ba3d54770cf11d9  gpl
	loaded_at 2024-10-25T10:22:10+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,126,78,79,127,80
	btf_id 212
593: sched_cls  name cil_from_container  tag e89a8df63f9f7623  gpl
	loaded_at 2024-10-25T10:22:10+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 126,72
	btf_id 213
594: sched_cls  name tail_ipv4_ct_ingress  tag 4723fe4eea1b42b6  gpl
	loaded_at 2024-10-25T10:22:10+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,126,78,79,127,80
	btf_id 214
595: sched_cls  name __send_drop_notify  tag ddd3b8a5d7972ff9  gpl
	loaded_at 2024-10-25T10:22:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 215
596: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
599: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
612: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
615: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
616: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
619: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
620: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
623: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
