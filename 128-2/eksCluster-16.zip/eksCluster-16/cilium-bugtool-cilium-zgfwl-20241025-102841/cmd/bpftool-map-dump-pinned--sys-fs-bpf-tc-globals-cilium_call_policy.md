key: 02 01 00 00  value: f7 01 00 00
key: 5f 01 00 00  value: 18 02 00 00
key: 50 0a 00 00  value: 4b 02 00 00
key: bc 0f 00 00  value: 06 02 00 00
Found 4 elements
