alloc: 74.17MB (77768232 bytes)
total-alloc: 1.34GB (1437660768 bytes)
sys: 206.38MB (216409428 bytes)
lookups: 0
mallocs: 47865756
frees: 47384168
heap-alloc: 74.17MB (77768232 bytes)
heap-sys: 163.04MB (170958848 bytes)
heap-idle: 43.10MB (45195264 bytes)
heap-in-use: 119.94MB (125763584 bytes)
heap-released: 24.00KB (24576 bytes)
heap-objects: 481588
stack-in-use: 32.94MB (34537472 bytes)
stack-sys: 32.94MB (34537472 bytes)
stack-mspan-inuse: 1.93MB (2021440 bytes)
stack-mspan-sys: 2.52MB (2643840 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 887.38KB (908673 bytes)
gc-sys: 5.12MB (5370016 bytes)
next-gc: when heap-alloc >= 145.22MB (152272328 bytes)
last-gc: 2024-10-25 10:29:11.495235822 +0000 UTC
gc-pause-total: 8.041897ms
gc-pause: 86975
gc-pause-end: 1729852151495235822
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.0003197103562792701
enable-gc: true
debug-gc: false
