markdown output at /tmp/cilium-bugtool-20241025-102842.443+0000-UTC-2822607083/cmd/cilium-debuginfo-20241025-102912.959+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102842.443+0000-UTC-2822607083/cmd/cilium-debuginfo-20241025-102912.959+0000-UTC.json
