Endpoint ID: 258
Path: /sys/fs/bpf/tc/globals/cilium_policy_00258

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    87246   1006      0        
Allow    Egress      0          ANY          NONE         disabled    13353   140       0        


Endpoint ID: 351
Path: /sys/fs/bpf/tc/globals/cilium_policy_00351

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    86648   996       0        
Allow    Egress      0          ANY          NONE         disabled    14106   148       0        


Endpoint ID: 1152
Path: /sys/fs/bpf/tc/globals/cilium_policy_01152

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2640
Path: /sys/fs/bpf/tc/globals/cilium_policy_02640

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3903998   36726     0        
Allow    Ingress     1          ANY          NONE         disabled    3047761   30746     0        
Allow    Egress      0          ANY          NONE         disabled    4493914   41568     0        


Endpoint ID: 4028
Path: /sys/fs/bpf/tc/globals/cilium_policy_04028

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    433024   5533      0        
Allow    Ingress     1          ANY          NONE         disabled    12652    147       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


