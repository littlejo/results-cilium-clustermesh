CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podea9252fb_c0dd_4f68_b99b_cd5184f9ec0f.slice/cri-containerd-43296191a442ceb574579bdaba4a1714a0b27c4c7e60ea93a97cdd0503f22116.scope
    522      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podea9252fb_c0dd_4f68_b99b_cd5184f9ec0f.slice/cri-containerd-075c81bb11450d252c93c09c47f5e3bf5d7347e3bf323f8c7d26ac3aef630889.scope
    526      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36732d70_bd0a_4ae4_b129_d9b1cc71a47f.slice/cri-containerd-a1c6919db63b8811cbd0a091080096342be6c073877b23adcc0c30923f32f9ce.scope
    120      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36732d70_bd0a_4ae4_b129_d9b1cc71a47f.slice/cri-containerd-110e6be52ed0730209fb2ee947d16ea957c8c210dca98591ffb39360b837dd75.scope
    77       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e9a8242_0c6d_4b9f_96e2_05b78f39dd94.slice/cri-containerd-ce9e75991b12b35454b939011227f8d34d59e8d80113851587aadfee4aa366a8.scope
    545      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e9a8242_0c6d_4b9f_96e2_05b78f39dd94.slice/cri-containerd-6280b82daa5229e74a1f4fa0f432a951f15fc829b1b8d1594e85ac8b4a3f794b.scope
    541      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod463b8c6e_1d8f_4ba8_8e16_f9f958f85bc2.slice/cri-containerd-511a3d2cdf1647d2b52902be9839be73b63d2f056106e67982d54fcf4f3376a3.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod463b8c6e_1d8f_4ba8_8e16_f9f958f85bc2.slice/cri-containerd-5348bc4126f07aa057fce57104db446b9634415413fa661225073931b1069ac8.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6ec072d9_d78e_447c_ba8b_0d5b67a17e8a.slice/cri-containerd-88d2a745e2bafc94004f981635db1dc606d38ae531af3d795014dc689f4be566.scope
    85       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6ec072d9_d78e_447c_ba8b_0d5b67a17e8a.slice/cri-containerd-b53c4dbdc9747c6a3dbd904805757f66e3a94a86a027098a259beff051959dd5.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc84f56a2_5dfe_4e55_9d9c_6f78326003fd.slice/cri-containerd-5c6cd08c3f46c07ed2293d51d5b0ba75726d0d70d31d2f29da00601510d4b0c4.scope
    89       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc84f56a2_5dfe_4e55_9d9c_6f78326003fd.slice/cri-containerd-ed6d6b4ddac7a3f3ab60dee88cb1ea7570abc5ef59451f112149cc6a32b4f256.scope
    81       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod108b90e3_10cb_4f6b_ad98_25d000a304d1.slice/cri-containerd-725cba50b3d7be5292859b341f8323374a20c0b7404e488ebd6ec6592c4fb01b.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod108b90e3_10cb_4f6b_ad98_25d000a304d1.slice/cri-containerd-0e5e06a6b9c9d923f9291dd8347b753b5fbe3cf91935f48d361e4f4fc91b04b4.scope
    615      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod108b90e3_10cb_4f6b_ad98_25d000a304d1.slice/cri-containerd-0fbc01e7f98e1318b22ae519bc0c1e1fc06fba27bf85d6facfb2c74fbe7965b0.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod108b90e3_10cb_4f6b_ad98_25d000a304d1.slice/cri-containerd-6938d4c1f5b47094309071bab932531c0c26e6ff10cbee9f28526c85e205f90d.scope
    619      cgroup_device   multi                                          
