xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 483
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 472
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 467
cilium_host(4) clsact/egress cil_from_host-cilium_host id 465
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 463
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 464
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 517
lxc0300afa87aa8(9) clsact/ingress cil_from_container-lxc0300afa87aa8 id 507
lxc40315b568f07(11) clsact/ingress cil_from_container-lxc40315b568f07 id 529
lxca08d467d9a28(15) clsact/ingress cil_from_container-lxca08d467d9a28 id 593

flow_dissector:

netfilter:

