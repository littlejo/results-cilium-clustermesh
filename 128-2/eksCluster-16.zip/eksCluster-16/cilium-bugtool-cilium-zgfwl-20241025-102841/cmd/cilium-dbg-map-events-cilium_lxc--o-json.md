{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:50.319Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.154.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:50.319Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:54.884Z",
  "value": "id=4028  sec_id=4     flags=0x0000 ifindex=7   mac=4E:8F:FC:A6:AD:FB nodemac=EE:8F:95:0C:47:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:54.889Z",
  "value": "id=258   sec_id=1150457 flags=0x0000 ifindex=9   mac=5E:A4:28:93:9A:22 nodemac=8E:F8:FE:42:EF:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:54.932Z",
  "value": "id=4028  sec_id=4     flags=0x0000 ifindex=7   mac=4E:8F:FC:A6:AD:FB nodemac=EE:8F:95:0C:47:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:58.633Z",
  "value": "id=351   sec_id=1150457 flags=0x0000 ifindex=11  mac=C6:E9:E2:83:0D:F8 nodemac=0A:29:B1:2D:01:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:24.871Z",
  "value": "id=258   sec_id=1150457 flags=0x0000 ifindex=9   mac=5E:A4:28:93:9A:22 nodemac=8E:F8:FE:42:EF:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:24.872Z",
  "value": "id=4028  sec_id=4     flags=0x0000 ifindex=7   mac=4E:8F:FC:A6:AD:FB nodemac=EE:8F:95:0C:47:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:24.872Z",
  "value": "id=351   sec_id=1150457 flags=0x0000 ifindex=11  mac=C6:E9:E2:83:0D:F8 nodemac=0A:29:B1:2D:01:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:24.900Z",
  "value": "id=1225  sec_id=1169229 flags=0x0000 ifindex=13  mac=46:F6:E3:A1:CF:0B nodemac=F2:D2:09:C6:7B:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:24.901Z",
  "value": "id=1225  sec_id=1169229 flags=0x0000 ifindex=13  mac=46:F6:E3:A1:CF:0B nodemac=F2:D2:09:C6:7B:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:25.869Z",
  "value": "id=351   sec_id=1150457 flags=0x0000 ifindex=11  mac=C6:E9:E2:83:0D:F8 nodemac=0A:29:B1:2D:01:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:25.870Z",
  "value": "id=1225  sec_id=1169229 flags=0x0000 ifindex=13  mac=46:F6:E3:A1:CF:0B nodemac=F2:D2:09:C6:7B:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:25.870Z",
  "value": "id=4028  sec_id=4     flags=0x0000 ifindex=7   mac=4E:8F:FC:A6:AD:FB nodemac=EE:8F:95:0C:47:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:25.870Z",
  "value": "id=258   sec_id=1150457 flags=0x0000 ifindex=9   mac=5E:A4:28:93:9A:22 nodemac=8E:F8:FE:42:EF:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:10.622Z",
  "value": "id=2640  sec_id=1169229 flags=0x0000 ifindex=15  mac=86:7C:9A:92:15:2D nodemac=D6:D9:9D:97:E1:38"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.16.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:16.032Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:56.894Z",
  "value": "id=4028  sec_id=4     flags=0x0000 ifindex=7   mac=4E:8F:FC:A6:AD:FB nodemac=EE:8F:95:0C:47:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:56.897Z",
  "value": "id=258   sec_id=1150457 flags=0x0000 ifindex=9   mac=5E:A4:28:93:9A:22 nodemac=8E:F8:FE:42:EF:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:56.897Z",
  "value": "id=351   sec_id=1150457 flags=0x0000 ifindex=11  mac=C6:E9:E2:83:0D:F8 nodemac=0A:29:B1:2D:01:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:56.898Z",
  "value": "id=2640  sec_id=1169229 flags=0x0000 ifindex=15  mac=86:7C:9A:92:15:2D nodemac=D6:D9:9D:97:E1:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.887Z",
  "value": "id=2640  sec_id=1169229 flags=0x0000 ifindex=15  mac=86:7C:9A:92:15:2D nodemac=D6:D9:9D:97:E1:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.887Z",
  "value": "id=258   sec_id=1150457 flags=0x0000 ifindex=9   mac=5E:A4:28:93:9A:22 nodemac=8E:F8:FE:42:EF:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.888Z",
  "value": "id=4028  sec_id=4     flags=0x0000 ifindex=7   mac=4E:8F:FC:A6:AD:FB nodemac=EE:8F:95:0C:47:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.888Z",
  "value": "id=351   sec_id=1150457 flags=0x0000 ifindex=11  mac=C6:E9:E2:83:0D:F8 nodemac=0A:29:B1:2D:01:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:58.887Z",
  "value": "id=258   sec_id=1150457 flags=0x0000 ifindex=9   mac=5E:A4:28:93:9A:22 nodemac=8E:F8:FE:42:EF:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:58.888Z",
  "value": "id=351   sec_id=1150457 flags=0x0000 ifindex=11  mac=C6:E9:E2:83:0D:F8 nodemac=0A:29:B1:2D:01:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:58.888Z",
  "value": "id=2640  sec_id=1169229 flags=0x0000 ifindex=15  mac=86:7C:9A:92:15:2D nodemac=D6:D9:9D:97:E1:38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:58.888Z",
  "value": "id=4028  sec_id=4     flags=0x0000 ifindex=7   mac=4E:8F:FC:A6:AD:FB nodemac=EE:8F:95:0C:47:D9"
}

