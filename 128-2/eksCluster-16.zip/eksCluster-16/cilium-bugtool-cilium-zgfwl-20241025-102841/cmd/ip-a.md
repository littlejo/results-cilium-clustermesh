1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:2b:69:5c:fc:65 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.154.239/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2668sec preferred_lft 2668sec
    inet6 fe80::42b:69ff:fe5c:fc65/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:54:7e:fa:41:c8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2854:7eff:fefa:41c8/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:b8:c9:dc:b1:c6 brd ff:ff:ff:ff:ff:ff
    inet 10.16.0.226/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::34b8:c9ff:fedc:b1c6/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 52:12:7f:73:cc:44 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5012:7fff:fe73:cc44/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:8f:95:0c:47:d9 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::ec8f:95ff:fe0c:47d9/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc0300afa87aa8@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:f8:fe:42:ef:bd brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::8cf8:feff:fe42:efbd/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc40315b568f07@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:29:b1:2d:01:82 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::829:b1ff:fe2d:182/64 scope link 
       valid_lft forever preferred_lft forever
15: lxca08d467d9a28@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:d9:9d:97:e1:38 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::d4d9:9dff:fe97:e138/64 scope link 
       valid_lft forever preferred_lft forever
