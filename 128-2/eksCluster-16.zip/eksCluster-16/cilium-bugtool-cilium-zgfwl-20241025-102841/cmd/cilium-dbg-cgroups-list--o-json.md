[
  {
    "containers": [
      {
        "cgroup-id": 8622,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod108b90e3_10cb_4f6b_ad98_25d000a304d1.slice/cri-containerd-0e5e06a6b9c9d923f9291dd8347b753b5fbe3cf91935f48d361e4f4fc91b04b4.scope"
      },
      {
        "cgroup-id": 8790,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod108b90e3_10cb_4f6b_ad98_25d000a304d1.slice/cri-containerd-725cba50b3d7be5292859b341f8323374a20c0b7404e488ebd6ec6592c4fb01b.scope"
      },
      {
        "cgroup-id": 8706,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod108b90e3_10cb_4f6b_ad98_25d000a304d1.slice/cri-containerd-6938d4c1f5b47094309071bab932531c0c26e6ff10cbee9f28526c85e205f90d.scope"
      }
    ],
    "ips": [
      "10.16.0.76"
    ],
    "name": "clustermesh-apiserver-66d978f94d-fjbr4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7110,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podea9252fb_c0dd_4f68_b99b_cd5184f9ec0f.slice/cri-containerd-075c81bb11450d252c93c09c47f5e3bf5d7347e3bf323f8c7d26ac3aef630889.scope"
      }
    ],
    "ips": [
      "10.16.0.96"
    ],
    "name": "coredns-cc6ccd49c-dm4lx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7278,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e9a8242_0c6d_4b9f_96e2_05b78f39dd94.slice/cri-containerd-ce9e75991b12b35454b939011227f8d34d59e8d80113851587aadfee4aa366a8.scope"
      }
    ],
    "ips": [
      "10.16.0.140"
    ],
    "name": "coredns-cc6ccd49c-zrkbh",
    "namespace": "kube-system"
  }
]

