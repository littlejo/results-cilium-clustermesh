Node 0, zone      DMA      1      3      2      2      1      1      4      1      1      3    167 
Node 0, zone   Normal    170     64     30     29     28     23      9      3      3      2      6 
