fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxc0300afa87aa8 proto kernel metric 256 pref medium
fe80::/64 dev lxc40315b568f07 proto kernel metric 256 pref medium
fe80::/64 dev lxca08d467d9a28 proto kernel metric 256 pref medium
