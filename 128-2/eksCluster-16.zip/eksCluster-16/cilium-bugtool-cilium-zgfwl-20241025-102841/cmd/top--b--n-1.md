top - 10:28:42 up 15 min,  0 users,  load average: 0.62, 0.43, 0.26
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 10.7 us, 28.6 sy,  0.0 ni, 60.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    798.4 free,    896.3 used,   2141.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2771.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    667 root      20   0 1240432  16476  11484 S   6.7   0.4   0:00.03 cilium-+
      1 root      20   0 1472240 271216  77500 S   0.0   6.9   0:23.44 cilium-+
    394 root      20   0 1228848   5796   2796 S   0.0   0.1   0:00.27 cilium-+
    623 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    656 root      20   0 1228744   3604   2912 S   0.0   0.1   0:00.00 gops
    704 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    728 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
