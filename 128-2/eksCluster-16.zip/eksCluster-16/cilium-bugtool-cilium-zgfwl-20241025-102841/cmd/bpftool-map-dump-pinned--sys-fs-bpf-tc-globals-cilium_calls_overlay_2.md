key: 01 00 00 00  value: cd 01 00 00
key: 07 00 00 00  value: ce 01 00 00
Found 2 elements
