{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:36.331Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.225.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:36.331Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:40.823Z",
  "value": "id=795   sec_id=4     flags=0x0000 ifindex=8   mac=FE:95:86:09:96:A8 nodemac=9E:37:4B:98:C9:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:40.829Z",
  "value": "id=194   sec_id=6051532 flags=0x0000 ifindex=10  mac=CE:DB:3E:82:75:FC nodemac=DA:C1:AD:8E:1A:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:40.898Z",
  "value": "id=795   sec_id=4     flags=0x0000 ifindex=8   mac=FE:95:86:09:96:A8 nodemac=9E:37:4B:98:C9:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:41.013Z",
  "value": "id=194   sec_id=6051532 flags=0x0000 ifindex=10  mac=CE:DB:3E:82:75:FC nodemac=DA:C1:AD:8E:1A:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:50.931Z",
  "value": "id=411   sec_id=6051532 flags=0x0000 ifindex=12  mac=26:43:34:D4:58:5E nodemac=EA:86:30:D9:EA:05"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:34.359Z",
  "value": "id=194   sec_id=6051532 flags=0x0000 ifindex=10  mac=CE:DB:3E:82:75:FC nodemac=DA:C1:AD:8E:1A:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:34.359Z",
  "value": "id=795   sec_id=4     flags=0x0000 ifindex=8   mac=FE:95:86:09:96:A8 nodemac=9E:37:4B:98:C9:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:34.360Z",
  "value": "id=411   sec_id=6051532 flags=0x0000 ifindex=12  mac=26:43:34:D4:58:5E nodemac=EA:86:30:D9:EA:05"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:34.392Z",
  "value": "id=2088  sec_id=6042107 flags=0x0000 ifindex=14  mac=8A:11:0B:49:93:65 nodemac=4A:87:63:9F:86:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:35.359Z",
  "value": "id=2088  sec_id=6042107 flags=0x0000 ifindex=14  mac=8A:11:0B:49:93:65 nodemac=4A:87:63:9F:86:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:35.360Z",
  "value": "id=194   sec_id=6051532 flags=0x0000 ifindex=10  mac=CE:DB:3E:82:75:FC nodemac=DA:C1:AD:8E:1A:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:35.360Z",
  "value": "id=411   sec_id=6051532 flags=0x0000 ifindex=12  mac=26:43:34:D4:58:5E nodemac=EA:86:30:D9:EA:05"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:35.360Z",
  "value": "id=795   sec_id=4     flags=0x0000 ifindex=8   mac=FE:95:86:09:96:A8 nodemac=9E:37:4B:98:C9:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:12.070Z",
  "value": "id=948   sec_id=6042107 flags=0x0000 ifindex=16  mac=1A:B9:B5:1E:93:27 nodemac=FA:10:EA:1C:EF:57"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.91.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:18.772Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:21.939Z",
  "value": "id=948   sec_id=6042107 flags=0x0000 ifindex=16  mac=1A:B9:B5:1E:93:27 nodemac=FA:10:EA:1C:EF:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:21.940Z",
  "value": "id=194   sec_id=6051532 flags=0x0000 ifindex=10  mac=CE:DB:3E:82:75:FC nodemac=DA:C1:AD:8E:1A:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:21.941Z",
  "value": "id=795   sec_id=4     flags=0x0000 ifindex=8   mac=FE:95:86:09:96:A8 nodemac=9E:37:4B:98:C9:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:21.941Z",
  "value": "id=411   sec_id=6051532 flags=0x0000 ifindex=12  mac=26:43:34:D4:58:5E nodemac=EA:86:30:D9:EA:05"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:22.940Z",
  "value": "id=795   sec_id=4     flags=0x0000 ifindex=8   mac=FE:95:86:09:96:A8 nodemac=9E:37:4B:98:C9:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:22.940Z",
  "value": "id=194   sec_id=6051532 flags=0x0000 ifindex=10  mac=CE:DB:3E:82:75:FC nodemac=DA:C1:AD:8E:1A:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:22.940Z",
  "value": "id=411   sec_id=6051532 flags=0x0000 ifindex=12  mac=26:43:34:D4:58:5E nodemac=EA:86:30:D9:EA:05"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:22.941Z",
  "value": "id=948   sec_id=6042107 flags=0x0000 ifindex=16  mac=1A:B9:B5:1E:93:27 nodemac=FA:10:EA:1C:EF:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:23.940Z",
  "value": "id=411   sec_id=6051532 flags=0x0000 ifindex=12  mac=26:43:34:D4:58:5E nodemac=EA:86:30:D9:EA:05"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:23.940Z",
  "value": "id=194   sec_id=6051532 flags=0x0000 ifindex=10  mac=CE:DB:3E:82:75:FC nodemac=DA:C1:AD:8E:1A:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:23.940Z",
  "value": "id=948   sec_id=6042107 flags=0x0000 ifindex=16  mac=1A:B9:B5:1E:93:27 nodemac=FA:10:EA:1C:EF:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:23.941Z",
  "value": "id=795   sec_id=4     flags=0x0000 ifindex=8   mac=FE:95:86:09:96:A8 nodemac=9E:37:4B:98:C9:C7"
}

