[
  {
    "containers": [
      {
        "cgroup-id": 8968,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2af62822_32af_45f1_b682_628f1e09d110.slice/cri-containerd-6081059998dcd10c09b5b40de5cccd15a2916d5d5b68a49810f847da89e2e8b9.scope"
      },
      {
        "cgroup-id": 8884,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2af62822_32af_45f1_b682_628f1e09d110.slice/cri-containerd-9168fa874b03a07c35ec0f8cd3233b09756ce7170972aea0a27ca37b14403364.scope"
      },
      {
        "cgroup-id": 9052,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2af62822_32af_45f1_b682_628f1e09d110.slice/cri-containerd-2419c38b920a87e2eb8361c48c348cef63d51035e1d035c495aca379dc4845aa.scope"
      }
    ],
    "ips": [
      "10.91.0.11"
    ],
    "name": "clustermesh-apiserver-6c444cbbc9-knqth",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7288,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5bf3ea71_58e0_4c45_a3a4_97e826da1993.slice/cri-containerd-aced74fc3dd0a2da6082ce821382db5e695a9ee01f80e1eda7e41f2fe10a460f.scope"
      }
    ],
    "ips": [
      "10.91.0.47"
    ],
    "name": "coredns-cc6ccd49c-hcncb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7540,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6585cd91_d8a0_4eac_8fc5_7f049ced266f.slice/cri-containerd-1fd1001d9379dbdb6c4972a7e6acfd457ea7ec1d2f8b7fa58d0c8cbcdfd6a71e.scope"
      }
    ],
    "ips": [
      "10.91.0.234"
    ],
    "name": "coredns-cc6ccd49c-fhjl5",
    "namespace": "kube-system"
  }
]

