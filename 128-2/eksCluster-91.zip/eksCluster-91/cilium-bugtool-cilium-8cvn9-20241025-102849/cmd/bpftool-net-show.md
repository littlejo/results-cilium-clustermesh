xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 540
cilium_net(4) clsact/ingress cil_to_host-cilium_net id 535
cilium_host(5) clsact/ingress cil_to_host-cilium_host id 526
cilium_host(5) clsact/egress cil_from_host-cilium_host id 529
cilium_vxlan(6) clsact/ingress cil_from_overlay-cilium_vxlan id 470
cilium_vxlan(6) clsact/egress cil_to_overlay-cilium_vxlan id 471
lxc_health(8) clsact/ingress cil_from_container-lxc_health id 495
lxc177232b5b33c(10) clsact/ingress cil_from_container-lxc177232b5b33c id 520
lxc3b7e6686968c(12) clsact/ingress cil_from_container-lxc3b7e6686968c id 552
lxc7175ac43d0a2(16) clsact/ingress cil_from_container-lxc7175ac43d0a2 id 610

flow_dissector:

netfilter:

