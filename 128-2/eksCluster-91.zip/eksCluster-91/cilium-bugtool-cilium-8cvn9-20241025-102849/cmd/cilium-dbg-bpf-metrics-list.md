REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10727     843897     677    bpf_overlay.c
Interface                 INGRESS     235687    87147345   1132   bpf_host.c
Success                   EGRESS      101123    13096913   1308   bpf_lxc.c
Success                   EGRESS      11307     886090     53     encap.h
Success                   EGRESS      5708      444370     1694   bpf_host.c
Success                   INGRESS     112921    13837021   86     l3.h
Success                   INGRESS     118589    14280454   235    trace.h
Unsupported L3 protocol   EGRESS      42        3168       1492   bpf_lxc.c
