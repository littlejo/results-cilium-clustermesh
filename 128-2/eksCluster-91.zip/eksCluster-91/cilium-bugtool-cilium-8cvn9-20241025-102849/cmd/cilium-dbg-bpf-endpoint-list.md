IP ADDRESS         LOCAL ENDPOINT INFO
10.91.0.11:0       id=948   sec_id=6042107 flags=0x0000 ifindex=16  mac=1A:B9:B5:1E:93:27 nodemac=FA:10:EA:1C:EF:57   
10.91.0.47:0       id=194   sec_id=6051532 flags=0x0000 ifindex=10  mac=CE:DB:3E:82:75:FC nodemac=DA:C1:AD:8E:1A:9C   
10.91.0.234:0      id=411   sec_id=6051532 flags=0x0000 ifindex=12  mac=26:43:34:D4:58:5E nodemac=EA:86:30:D9:EA:05   
10.91.0.78:0       id=795   sec_id=4     flags=0x0000 ifindex=8   mac=FE:95:86:09:96:A8 nodemac=9E:37:4B:98:C9:C7     
10.91.0.194:0      (localhost)                                                                                        
172.31.225.137:0   (localhost)                                                                                        
