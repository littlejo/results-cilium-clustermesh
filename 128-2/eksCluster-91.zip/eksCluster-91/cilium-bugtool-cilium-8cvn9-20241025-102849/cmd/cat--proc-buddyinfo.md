Node 0, zone      DMA      2     31     16      2      7     10      5      1      2      2    163 
Node 0, zone   Normal    312     46      1      9      3      2      2      2      0      3      8 
