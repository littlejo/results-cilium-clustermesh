35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:42+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:42+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:42+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:42+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
82: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
85: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
86: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
89: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
125: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
128: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
469: sched_cls  name tail_handle_ipv4  tag cc2536e23a60e78b  gpl
	loaded_at 2024-10-25T10:14:38+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 73,72,79,74,95
	btf_id 115
470: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:14:38+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 74,95
	btf_id 116
471: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:14:38+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 117
472: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:14:38+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 39
	btf_id 118
495: sched_cls  name cil_from_container  tag 651d75285185cb88  gpl
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 103,74
	btf_id 144
496: sched_cls  name handle_policy  tag e6eb7167705898df  gpl
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 74,103,80,81,102,39,78,97,37,82,73,38,35,36
	btf_id 145
497: sched_cls  name tail_handle_ipv4  tag f9a472ce8ea4963d  gpl
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 82,74,76,80,81,77,37,103
	btf_id 146
498: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 74,103
	btf_id 147
499: sched_cls  name __send_drop_notify  tag 63c485bde7b1a64c  gpl
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 39
	btf_id 148
500: sched_cls  name tail_handle_ipv4_cont  tag 154b369890d4e019  gpl
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 73,102,39,97,80,81,37,74,72,75,103,38,35,36,79
	btf_id 149
501: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 74,103,80,81,102,82
	btf_id 150
502: sched_cls  name tail_ipv4_ct_ingress  tag ad9c556f00e4932b  gpl
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 74,103,80,81,102,82
	btf_id 151
503: sched_cls  name tail_ipv4_to_endpoint  tag 7b6ac476ce1597a0  gpl
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 73,74,102,39,80,81,78,97,37,103,38,35,36
	btf_id 152
505: sched_cls  name tail_handle_arp  tag f7c61647980ca9e8  gpl
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 74,103
	btf_id 154
506: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
509: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
510: sched_cls  name tail_ipv4_to_endpoint  tag c5550515d1bb4094  gpl
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 73,74,104,39,80,81,78,96,37,105,38,35,36
	btf_id 156
511: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 74,105
	btf_id 157
512: sched_cls  name tail_ipv4_ct_ingress  tag b3298cac4855922d  gpl
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 74,105,80,81,104,82
	btf_id 158
513: sched_cls  name __send_drop_notify  tag 7b278670e8743129  gpl
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 39
	btf_id 159
514: sched_cls  name tail_ipv4_ct_egress  tag f1cc641577e594fb  gpl
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 74,105,80,81,104,82
	btf_id 160
516: sched_cls  name tail_handle_arp  tag 2cf67cdb5ef48583  gpl
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 74,105
	btf_id 162
517: sched_cls  name tail_handle_ipv4_cont  tag 1c8ae4f697fece45  gpl
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 73,104,39,96,80,81,37,74,72,75,105,38,35,36,79
	btf_id 163
518: sched_cls  name handle_policy  tag a7a9a422c879b6f8  gpl
	loaded_at 2024-10-25T10:14:40+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 74,105,80,81,104,39,78,96,37,82,73,38,35,36
	btf_id 164
519: sched_cls  name tail_handle_ipv4  tag 0b01ebbad860a803  gpl
	loaded_at 2024-10-25T10:14:41+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 82,74,76,80,81,77,37,105
	btf_id 165
520: sched_cls  name cil_from_container  tag 0385277a0f4fe7b9  gpl
	loaded_at 2024-10-25T10:14:41+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 105,74
	btf_id 166
521: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
524: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
525: sched_cls  name tail_handle_ipv4_from_host  tag 5e3dfdc3eea27f07  gpl
	loaded_at 2024-10-25T10:14:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 72,73,74,75,39,79,108
	btf_id 169
526: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:42+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 74
	btf_id 170
528: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:42+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 74,108
	btf_id 172
529: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:14:42+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 74,73,108
	btf_id 173
531: sched_cls  name __send_drop_notify  tag 1080a2da84431310  gpl
	loaded_at 2024-10-25T10:14:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 39
	btf_id 175
533: sched_cls  name __send_drop_notify  tag 1080a2da84431310  gpl
	loaded_at 2024-10-25T10:14:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 39
	btf_id 178
534: sched_cls  name tail_handle_ipv4_from_host  tag 5e3dfdc3eea27f07  gpl
	loaded_at 2024-10-25T10:14:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 72,73,74,75,39,79,111
	btf_id 179
535: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:42+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 74
	btf_id 180
537: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:42+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 74,111
	btf_id 182
540: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:42+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 74,112,73
	btf_id 186
541: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:42+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 74,112
	btf_id 187
544: sched_cls  name __send_drop_notify  tag 1080a2da84431310  gpl
	loaded_at 2024-10-25T10:14:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 39
	btf_id 190
545: sched_cls  name tail_handle_ipv4_from_host  tag 5e3dfdc3eea27f07  gpl
	loaded_at 2024-10-25T10:14:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 72,73,74,75,39,79,112
	btf_id 191
546: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 74,116
	btf_id 193
548: sched_cls  name tail_handle_ipv4_cont  tag 111da694ce4a952d  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 73,115,39,114,80,81,37,74,72,75,116,38,35,36,79
	btf_id 195
549: sched_cls  name tail_handle_arp  tag 1564466941e9f073  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 74,116
	btf_id 196
550: sched_cls  name __send_drop_notify  tag ed545d2170504bdc  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 39
	btf_id 197
551: sched_cls  name tail_ipv4_ct_ingress  tag 32e3040ada3115fb  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 74,116,80,81,115,82
	btf_id 198
552: sched_cls  name cil_from_container  tag d273123fb09ec25e  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,74
	btf_id 199
553: sched_cls  name handle_policy  tag f4ea1224ea295c6b  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 74,116,80,81,115,39,78,114,37,82,73,38,35,36
	btf_id 200
554: sched_cls  name tail_ipv4_ct_egress  tag f1cc641577e594fb  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 74,116,80,81,115,82
	btf_id 201
555: sched_cls  name tail_handle_ipv4  tag 22e70412f65a1199  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 82,74,76,80,81,77,37,116
	btf_id 202
556: sched_cls  name tail_ipv4_to_endpoint  tag 85dc941b88302516  gpl
	loaded_at 2024-10-25T10:14:50+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 73,74,115,39,80,81,78,114,37,116,38,35,36
	btf_id 203
557: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
560: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
561: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
564: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
604: sched_cls  name handle_policy  tag e767488792a8e16a  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 74,131,80,81,130,39,78,129,37,82,73,38,35,36
	btf_id 217
605: sched_cls  name tail_handle_arp  tag 817aa602c8f37ce9  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 74,131
	btf_id 218
606: sched_cls  name tail_handle_ipv4_cont  tag 54a0e2d138342b4f  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 73,130,39,129,80,81,37,74,72,75,131,38,35,36,79
	btf_id 219
608: sched_cls  name tail_ipv4_ct_ingress  tag 8b65bf0aa513b540  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 74,131,80,81,130,82
	btf_id 221
609: sched_cls  name tail_ipv4_to_endpoint  tag 625198e3896301b6  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 73,74,130,39,80,81,78,129,37,131,38,35,36
	btf_id 222
610: sched_cls  name cil_from_container  tag 5eb7058af0a13a94  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 131,74
	btf_id 223
611: sched_cls  name tail_ipv4_ct_egress  tag 37bc35fedec8e094  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 74,131,80,81,130,82
	btf_id 224
612: sched_cls  name tail_handle_ipv4  tag 35391dfae1b71a30  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 82,74,76,80,81,77,37,131
	btf_id 225
613: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 74,131
	btf_id 226
614: sched_cls  name __send_drop_notify  tag 546a151af2d98e97  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 39
	btf_id 227
615: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
618: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
631: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
634: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
635: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
638: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
639: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
642: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
