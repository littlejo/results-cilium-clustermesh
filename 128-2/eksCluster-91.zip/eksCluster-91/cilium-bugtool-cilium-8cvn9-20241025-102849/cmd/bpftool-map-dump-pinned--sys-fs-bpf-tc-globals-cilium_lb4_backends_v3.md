key: 07 00 00 00  value: ac 1f c0 e0 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 5b 00 ea 00 35 00 00  00 00 00 00
key: 04 00 00 00  value: ac 1f e1 89 10 94 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 89 32 01 bb 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 5b 00 0b 09 4b 00 00  00 00 00 00
key: 05 00 00 00  value: 0a 5b 00 2f 23 c1 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 5b 00 ea 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 5b 00 2f 00 35 00 00  00 00 00 00
Found 8 elements
