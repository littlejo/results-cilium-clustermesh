ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.137.50:443 (active)     
                                         2 => 172.31.192.224:443 (active)    
2    10.100.97.40:443     ClusterIP      1 => 172.31.225.137:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.91.0.47:9153 (active)       
                                         2 => 10.91.0.234:9153 (active)      
4    10.100.0.10:53       ClusterIP      1 => 10.91.0.47:53 (active)         
                                         2 => 10.91.0.234:53 (active)        
5    10.100.14.163:2379   ClusterIP      1 => 10.91.0.11:2379 (active)       
