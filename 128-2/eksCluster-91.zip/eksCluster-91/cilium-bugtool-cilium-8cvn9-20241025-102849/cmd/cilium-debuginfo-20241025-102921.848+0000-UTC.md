# Cilium debug information

#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
194        Disabled           Disabled          6051532    k8s:eks.amazonaws.com/component=coredns                                             10.91.0.47    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh92                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
411        Disabled           Disabled          6051532    k8s:eks.amazonaws.com/component=coredns                                             10.91.0.234   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh92                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
795        Disabled           Disabled          4          reserved:health                                                                     10.91.0.78    ready   
948        Disabled           Disabled          6042107    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.91.0.11    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh92                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
1068       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                
                                                           reserved:host                                                                                             
```

#### BPF Policy Get 194

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83872   969       0        
Allow    Egress      0          ANY          NONE         disabled    14410   151       0        

```


#### BPF CT List 194

```
Invalid argument: unknown type 194
```


#### Endpoint Get 194

```
[
  {
    "id": 194,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-194-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "2952539f-b27b-4a44-8f49-5d65e17ef795"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-194",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:37.460Z",
            "success-count": 3
          },
          "uuid": "64aead06-b0fe-4eff-b16a-e1c2bf947df2"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-hcncb",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:37.458Z",
            "success-count": 1
          },
          "uuid": "5950e47a-0746-4dd6-b5d7-2c98c664582b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-194",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:40.832Z",
            "success-count": 1
          },
          "uuid": "0be354fa-eba9-4d37-a779-233344a550c3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (194)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:17.535Z",
            "success-count": 90
          },
          "uuid": "b77b9827-8e67-4c7a-9f1e-cb631dda91e1"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "922201513e016ff371f342bc7b760e3462e3060440524afe8871f7b21a53bd41:eth0",
        "container-id": "922201513e016ff371f342bc7b760e3462e3060440524afe8871f7b21a53bd41",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-hcncb",
        "pod-name": "kube-system/coredns-cc6ccd49c-hcncb"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6051532,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh92",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh92",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:23Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.91.0.47",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "da:c1:ad:8e:1a:9c",
        "interface-index": 10,
        "interface-name": "lxc177232b5b33c",
        "mac": "ce:db:3e:82:75:fc"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6051532,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6051532,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 194

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 194

```
Timestamp              Status    State                   Message
2024-10-25T10:21:23Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:23Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:23Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:21:23Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:22Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:22Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:22Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:22Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:21Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:21Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:21Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:21Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:35Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:35Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:35Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:35Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:34Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:34Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:34Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:34Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:41Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:41Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:40Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:40Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:38Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:38Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:37Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:37Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:37Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:14:37Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:37Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 6051532

```
ID        LABELS
6051532   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh92
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 411

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    80772   923       0        
Allow    Egress      0          ANY          NONE         disabled    12982   135       0        

```


#### BPF CT List 411

```
Invalid argument: unknown type 411
```


#### Endpoint Get 411

```
[
  {
    "id": 411,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-411-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b0dc0374-11bb-4001-8e30-ae8928710996"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-411",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:50.899Z",
            "success-count": 3
          },
          "uuid": "92a6b51c-d575-4d90-941a-7fe68270cc97"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-fhjl5",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:50.897Z",
            "success-count": 1
          },
          "uuid": "e53fe209-4dad-46bd-8c40-0c346671f062"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-411",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:50.932Z",
            "success-count": 1
          },
          "uuid": "69d11b84-4720-4c91-889e-36b11559260c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (411)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:20.973Z",
            "success-count": 89
          },
          "uuid": "2f58734c-7b42-44b0-b298-8da3a589711e"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "e11cbfe6071c9a158aafba284d86dd8d2bf0631d9ac954b263b91f77d5a8f136:eth0",
        "container-id": "e11cbfe6071c9a158aafba284d86dd8d2bf0631d9ac954b263b91f77d5a8f136",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-fhjl5",
        "pod-name": "kube-system/coredns-cc6ccd49c-fhjl5"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6051532,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh92",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh92",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:23Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.91.0.234",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ea:86:30:d9:ea:05",
        "interface-index": 12,
        "interface-name": "lxc3b7e6686968c",
        "mac": "26:43:34:d4:58:5e"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6051532,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6051532,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 411

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 411

```
Timestamp              Status   State                   Message
2024-10-25T10:21:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:23Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:50Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:50Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:50Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 6051532

```
ID        LABELS
6051532   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh92
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 795

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    443499   5669      0        
Allow    Ingress     1          ANY          NONE         disabled    12696    150       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 795

```
Invalid argument: unknown type 795
```


#### Endpoint Get 795

```
[
  {
    "id": 795,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-795-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "22c039f6-8fa2-4d86-a4a2-746e24c1ad7f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-795",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:37.519Z",
            "success-count": 3
          },
          "uuid": "3e335a6f-1f5f-4dff-bd1d-f0dd75c93d2e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-795",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:40.824Z",
            "success-count": 1
          },
          "uuid": "5546a779-4428-4140-b13e-a3055c12a8f4"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:23Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.91.0.78",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "9e:37:4b:98:c9:c7",
        "interface-index": 8,
        "interface-name": "lxc_health",
        "mac": "fe:95:86:09:96:a8"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 795

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 795

```
Timestamp              Status   State                   Message
2024-10-25T10:21:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:23Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:40Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:38Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:37Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:37Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:36Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 948

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3836236   36669     0        
Allow    Ingress     1          ANY          NONE         disabled    3708799   38247     0        
Allow    Egress      0          ANY          NONE         disabled    5495772   50711     0        

```


#### BPF CT List 948

```
Invalid argument: unknown type 948
```


#### Endpoint Get 948

```
[
  {
    "id": 948,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-948-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "cdce714b-4b60-49fe-8fb5-731c57216fd5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-948",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:12.038Z",
            "success-count": 2
          },
          "uuid": "9a144ea0-f3cf-4ffd-989c-ceda97108758"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-6c444cbbc9-knqth",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:12.037Z",
            "success-count": 1
          },
          "uuid": "675821db-342d-42ae-ab37-ca4e30e40225"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-948",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:12.071Z",
            "success-count": 1
          },
          "uuid": "4417908a-f929-44a2-90c1-d61ad8f365f2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (948)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:22.095Z",
            "success-count": 51
          },
          "uuid": "8d850f84-fb8f-4bcd-9cf3-88ade7a0f772"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "55aaf526b0ada97decb0f6c22efb06b58e705fc9547e68bc3564789fb51f3334:eth0",
        "container-id": "55aaf526b0ada97decb0f6c22efb06b58e705fc9547e68bc3564789fb51f3334",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-6c444cbbc9-knqth",
        "pod-name": "kube-system/clustermesh-apiserver-6c444cbbc9-knqth"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6042107,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh92",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6c444cbbc9"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh92",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:23Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.91.0.11",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "fa:10:ea:1c:ef:57",
        "interface-index": 16,
        "interface-name": "lxc7175ac43d0a2",
        "mac": "1a:b9:b5:1e:93:27"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6042107,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6042107,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 948

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 948

```
Timestamp              Status   State                   Message
2024-10-25T10:21:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:23Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:12Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:12Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:12Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 6042107

```
ID        LABELS
6042107   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh92
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1068

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1068

```
Invalid argument: unknown type 1068
```


#### Endpoint Get 1068

```
[
  {
    "id": 1068,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1068-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "4e306000-40f3-407f-b232-5325f515b1d4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1068",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:36.514Z",
            "success-count": 3
          },
          "uuid": "1ab97b50-3ccf-476c-99f5-ee2ef97745a3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1068",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:37.629Z",
            "success-count": 1
          },
          "uuid": "ecd57db8-9f3e-49cc-bead-0db94d6403fb"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:23Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "72:b1:f1:b0:56:be",
        "interface-name": "cilium_host",
        "mac": "72:b1:f1:b0:56:be"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1068

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1068

```
Timestamp              Status   State                   Message
2024-10-25T10:21:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:23Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:38Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:38Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:14:37Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:36Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:36Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:36Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### Policy get

```
:
 []
Revision: 1

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.91.0.194": (string) (len=6) "router",
  (string) (len=10) "10.91.0.78": (string) (len=6) "health",
  (string) (len=10) "10.91.0.47": (string) (len=35) "kube-system/coredns-cc6ccd49c-hcncb",
  (string) (len=11) "10.91.0.234": (string) (len=35) "kube-system/coredns-cc6ccd49c-fhjl5",
  (string) (len=10) "10.91.0.11": (string) (len=50) "kube-system/clustermesh-apiserver-6c444cbbc9-knqth"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.225.137": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40018d8160)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4002435a40,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4002435a40,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4002570bb0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4002570c60)(frontends:[10.100.97.40]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4002570d10)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4002cf80b0)(frontends:[]/ports=[etcd-metrics apiserv-metrics kvmesh-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x400285e630)(frontends:[10.100.14.163]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x400174b810)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-jj2gw": (*k8s.Endpoints)(0x40013b4c30)(172.31.225.137:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x400174b820)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-br8rc": (*k8s.Endpoints)(0x4001feed00)(10.91.0.234:53/TCP[eu-west-3b],10.91.0.234:53/UDP[eu-west-3b],10.91.0.234:9153/TCP[eu-west-3b],10.91.0.47:53/TCP[eu-west-3b],10.91.0.47:53/UDP[eu-west-3b],10.91.0.47:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x400152b1e0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-bn68t": (*k8s.Endpoints)(0x4001cc1d40)(10.91.0.11:2379/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x400174b800)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x400220a9c0)(172.31.137.50:443/TCP,172.31.192.224:443/TCP)
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001b34e00)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4002321770)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400afa00c0
  },
  gcTrigger: (chan struct {}) (cap=1) 0x400232e7e0,
  gcExited: (chan struct {}) 0x400232e840,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001b3f180)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001580720)({
      MetricVec: (*prometheus.MetricVec)(0x400240f8f0)({
       metricMap: (*prometheus.metricMap)(0x400240f920)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b5d2c0)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001b3f200)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001580728)({
      MetricVec: (*prometheus.MetricVec)(0x400240f980)({
       metricMap: (*prometheus.metricMap)(0x400240f9b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b5d320)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001b3f280)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001580730)({
      MetricVec: (*prometheus.MetricVec)(0x400240fa10)({
       metricMap: (*prometheus.metricMap)(0x400240fa40)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b5d380)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001b3f300)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001580738)({
      MetricVec: (*prometheus.MetricVec)(0x400240faa0)({
       metricMap: (*prometheus.metricMap)(0x400240fad0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b5d3e0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001b3f380)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001580740)({
      MetricVec: (*prometheus.MetricVec)(0x400240fb30)({
       metricMap: (*prometheus.metricMap)(0x400240fb60)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b5d440)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001b3f400)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001580748)({
      MetricVec: (*prometheus.MetricVec)(0x400240fbc0)({
       metricMap: (*prometheus.metricMap)(0x400240fbf0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b5d4a0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001b3f480)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001580750)({
      MetricVec: (*prometheus.MetricVec)(0x400240fc50)({
       metricMap: (*prometheus.metricMap)(0x400240fc80)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b5d500)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001b3f500)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001580758)({
      MetricVec: (*prometheus.MetricVec)(0x400240fce0)({
       metricMap: (*prometheus.metricMap)(0x400240fd10)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b5d560)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001b3f580)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001580760)({
      MetricVec: (*prometheus.MetricVec)(0x400240fd70)({
       metricMap: (*prometheus.metricMap)(0x400240fda0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b5d5c0)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001b34e00)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001b343f0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x400240d278)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 394ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium environment keys

```
enable-cilium-endpoint-slice:false
ipv4-range:auto
vtep-mac:
node-port-acceleration:disabled
policy-cidr-match-mode:
arping-refresh-period:30s
hubble-export-allowlist:
dns-max-ips-per-restored-rule:1000
k8s-service-proxy-name:
enable-ipv4:true
disable-endpoint-crd:false
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
vtep-mask:
enable-k8s-endpoint-slice:true
enable-ipv6-big-tcp:false
install-no-conntrack-iptables-rules:false
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
mesh-auth-gc-interval:5m0s
datapath-mode:veth
container-ip-local-reserved-ports:auto
set-cilium-is-up-condition:true
tofqdns-min-ttl:0
enable-ip-masq-agent:false
bgp-config-path:/var/lib/cilium/bgp/config.yaml
k8s-heartbeat-timeout:30s
hubble-disable-tls:false
enable-local-redirect-policy:false
enable-bpf-clock-probe:false
enable-ipv4-fragment-tracking:true
enable-ipsec-encrypted-overlay:false
dnsproxy-concurrency-limit:0
enable-unreachable-routes:false
ipam-multi-pool-pre-allocation:
custom-cni-conf:false
iptables-random-fully:false
l2-announcements-retry-period:2s
hubble-event-buffer-capacity:4095
clustermesh-ip-identities-sync-timeout:1m0s
k8s-sync-timeout:3m0s
egress-masquerade-interfaces:ens+
bpf-lb-mode:snat
proxy-idle-timeout-seconds:60
exclude-local-address:
ipam:cluster-pool
hubble-listen-address::4244
dns-policy-unload-on-shutdown:false
enable-k8s-api-discovery:false
enable-wireguard:false
hubble-drop-events:false
crd-wait-timeout:5m0s
hubble-export-denylist:
labels:
direct-routing-device:
cgroup-root:/run/cilium/cgroupv2
pprof-address:localhost
bpf-ct-timeout-regular-tcp-syn:1m0s
cluster-name:cmesh92
bpf-lb-maglev-table-size:16381
cilium-endpoint-gc-interval:5m0s
cluster-pool-ipv4-mask-size:24
mke-cgroup-mount:
enable-masquerade-to-route-source:false
mesh-auth-rotated-identities-queue-size:1024
bpf-ct-timeout-service-tcp:2h13m20s
enable-l2-pod-announcements:false
ipv4-pod-subnets:
bpf-ct-global-tcp-max:524288
kvstore-connectivity-timeout:2m0s
bpf-lb-external-clusterip:false
enable-recorder:false
cni-chaining-target:
enable-ingress-controller:false
enable-nat46x64-gateway:false
bpf-lb-map-max:65536
max-internal-timer-delay:0s
egress-multi-home-ip-rule-compat:false
proxy-max-connection-duration-seconds:0
local-router-ipv6:
enable-wireguard-userspace-fallback:false
version:false
hubble-recorder-sink-queue-size:1024
enable-ipip-termination:false
max-connected-clusters:255
enable-ipv6-masquerade:true
disable-iptables-feeder-rules:
enable-active-connection-tracking:false
preallocate-bpf-maps:false
hubble-export-file-max-size-mb:10
operator-prometheus-serve-addr::9963
node-port-mode:snat
dnsproxy-socket-linger-timeout:10
prometheus-serve-addr:
ipam-cilium-node-update-rate:15s
vtep-cidr:
enable-ipv4-egress-gateway:false
mesh-auth-spiffe-trust-domain:spiffe.cilium
enable-xt-socket-fallback:true
bpf-lb-acceleration:disabled
identity-restore-grace-period:30s
vtep-endpoint:
ipv4-native-routing-cidr:
api-rate-limit:
disable-external-ip-mitigation:false
enable-encryption-strict-mode:false
l2-pod-announcements-interface:
cluster-pool-ipv4-cidr:10.91.0.0/16
enable-ipv6:false
dnsproxy-lock-count:131
pprof:false
hubble-drop-events-interval:2m0s
nat-map-stats-interval:30s
fixed-identity-mapping:
mesh-auth-enabled:true
ipv6-pod-subnets:
envoy-config-retry-interval:15s
envoy-keep-cap-netbindservice:false
nat-map-stats-entries:32
hubble-socket-path:/var/run/cilium/hubble.sock
hubble-redact-http-headers-allow:
enable-ipsec-xfrm-state-caching:true
policy-queue-size:100
policy-trigger-interval:1s
kvstore:
kube-proxy-replacement-healthz-bind-address:
metrics:
enable-ipv6-ndp:false
enable-runtime-device-detection:true
agent-health-port:9879
ipv6-range:auto
tunnel-protocol:vxlan
iptables-lock-timeout:5s
enable-k8s-networkpolicy:true
egress-gateway-reconciliation-trigger-interval:1s
enable-srv6:false
k8s-kubeconfig-path:
clustermesh-sync-timeout:1m0s
ingress-secrets-namespace:
enable-bbr:false
kube-proxy-replacement:false
identity-change-grace-period:5s
hubble-monitor-events:
node-port-algorithm:random
bpf-lb-rev-nat-map-max:0
tofqdns-pre-cache:
srv6-encap-mode:reduced
use-cilium-internal-ip-for-ipsec:false
cluster-id:92
certificates-directory:/var/run/cilium/certs
hubble-redact-http-headers-deny:
cluster-health-port:4240
cni-chaining-mode:none
config-dir:/tmp/cilium/config-map
l2-announcements-lease-duration:15s
hubble-export-file-path:
bpf-lb-service-backend-map-max:0
enable-ipsec:false
clustermesh-enable-endpoint-sync:false
hubble-drop-events-reasons:auth_required,policy_denied
hubble-export-file-max-backups:5
bpf-policy-map-full-reconciliation-interval:15m0s
trace-payloadlen:128
bpf-policy-map-max:16384
local-max-addr-scope:252
enable-monitor:true
proxy-portrange-max:20000
tofqdns-enable-dns-compression:true
enable-health-check-nodeport:true
trace-sock:true
operator-api-serve-addr:127.0.0.1:9234
config:
enable-host-legacy-routing:false
monitor-aggregation:medium
hubble-export-file-compress:false
pprof-port:6060
ipv6-node:auto
bpf-ct-timeout-regular-any:1m0s
hubble-event-queue-size:0
l2-announcements-renew-deadline:5s
nodes-gc-interval:5m0s
exclude-node-label-patterns:
max-controller-interval:0
k8s-service-cache-size:128
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
read-cni-conf:
enable-policy:default
k8s-require-ipv6-pod-cidr:false
bgp-announce-pod-cidr:false
bpf-lb-sock-hostns-only:false
enable-node-port:false
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
k8s-client-burst:20
bypass-ip-availability-upon-restore:false
enable-hubble-recorder-api:true
hubble-metrics-server:
enable-l7-proxy:true
restore:true
enable-custom-calls:false
enable-tracing:false
enable-ipv4-masquerade:true
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
gops-port:9890
enable-cilium-api-server-access:
enable-high-scale-ipcache:false
enable-stale-cilium-endpoint-cleanup:true
dnsproxy-concurrency-processing-grace-period:0s
enable-health-checking:true
bpf-fragments-map-max:8192
bpf-lb-service-map-max:0
mesh-auth-mutual-listener-port:0
proxy-max-requests-per-connection:0
lib-dir:/var/lib/cilium
proxy-portrange-min:10000
bpf-events-policy-verdict-enabled:true
enable-ipv4-big-tcp:false
hubble-flowlogs-config-path:
hubble-skip-unknown-cgroup-ids:true
enable-session-affinity:false
enable-external-ips:false
http-retry-count:3
enable-hubble:true
monitor-queue-size:0
bpf-nat-global-max:524288
enable-icmp-rules:true
enable-host-firewall:false
bpf-lb-dsr-l4-xlate:frontend
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
enable-xdp-prefilter:false
cni-external-routing:false
clustermesh-enable-mcs-api:false
ipsec-key-rotation-duration:5m0s
http-retry-timeout:0
log-system-load:false
enable-route-mtu-for-cni-chaining:false
disable-envoy-version-check:false
tofqdns-dns-reject-response-code:refused
encryption-strict-mode-allow-remote-node-identities:false
envoy-base-id:0
envoy-secrets-namespace:
unmanaged-pod-watcher-interval:15
mesh-auth-spire-admin-socket:
bgp-announce-lb-ip:false
enable-bpf-tproxy:false
routing-mode:tunnel
tofqdns-idle-connection-grace-period:0s
enable-metrics:true
allow-localhost:auto
http-max-grpc-timeout:0
bpf-root:/sys/fs/bpf
remove-cilium-node-taints:true
cni-exclusive:true
mesh-auth-queue-size:1024
agent-liveness-update-interval:1s
k8s-client-connection-timeout:30s
bpf-auth-map-max:524288
socket-path:/var/run/cilium/cilium.sock
gateway-api-secrets-namespace:
encrypt-node:false
enable-pmtu-discovery:false
enable-cilium-health-api-server-access:
kvstore-lease-ttl:15m0s
route-metric:0
controller-group-metrics:
mtu:0
enable-endpoint-health-checking:true
bpf-ct-timeout-service-tcp-grace:1m0s
http-idle-timeout:0
ipv6-service-range:auto
conntrack-gc-interval:0s
allow-icmp-frag-needed:true
k8s-client-qps:10
conntrack-gc-max-interval:0s
bpf-sock-rev-map-max:262144
enable-identity-mark:true
derive-masq-ip-addr-from-device:
node-port-bind-protection:true
hubble-redact-kafka-apikey:false
multicast-enabled:false
egress-gateway-policy-map-max:16384
join-cluster:false
bpf-ct-timeout-service-any:1m0s
procfs:/host/proc
hubble-metrics:
install-iptables-rules:true
enable-mke:false
bpf-ct-timeout-regular-tcp-fin:10s
cmdref:
bpf-lb-dsr-dispatch:opt
tofqdns-proxy-port:0
annotate-k8s-node:false
bpf-lb-source-range-map-max:0
bpf-lb-rss-ipv4-src-cidr:
bpf-lb-rss-ipv6-src-cidr:
monitor-aggregation-interval:5s
clustermesh-config:/var/lib/cilium/clustermesh/
policy-accounting:true
ipam-default-ip-pool:default
enable-tcx:true
dnsproxy-insecure-skip-transparent-mode-check:false
ipsec-key-file:
bpf-ct-global-any-max:262144
enable-bpf-masquerade:false
proxy-prometheus-port:0
external-envoy-proxy:true
encrypt-interface:
ipv4-service-range:auto
monitor-aggregation-flags:all
enable-auto-protect-node-port-range:true
enable-host-port:false
bpf-node-map-max:16384
k8s-namespace:kube-system
keep-config:false
prepend-iptables-chains:true
fqdn-regex-compile-lru-size:1024
auto-direct-node-routes:false
bpf-map-event-buffers:
enable-envoy-config:false
kvstore-max-consecutive-quorum-errors:2
tunnel-port:0
bpf-lb-algorithm:random
k8s-api-server:
bpf-lb-sock-terminate-pod-connections:false
log-driver:
use-full-tls-context:false
enable-endpoint-routes:false
envoy-config-timeout:2m0s
identity-heartbeat-timeout:30m0s
service-no-backend-response:reject
bpf-map-dynamic-size-ratio:0.0025
bpf-lb-maglev-map-max:0
k8s-require-ipv4-pod-cidr:false
ip-masq-agent-config-path:/etc/config/ip-masq-agent
enable-health-check-loadbalancer-ip:false
nodeport-addresses:
dnsproxy-enable-transparent-mode:true
hubble-recorder-storage-path:/var/run/cilium/pcaps
identity-gc-interval:15m0s
vlan-bpf-bypass:
debug-verbose:
cflags:
ipv4-node:auto
enable-ipsec-key-watcher:true
hubble-export-fieldmask:
ipv6-native-routing-cidr:
tofqdns-max-deferred-connection-deletes:10000
bpf-filter-priority:1
kvstore-periodic-sync:5m0s
http-request-timeout:3600
config-sources:config-map:kube-system/cilium-config
local-router-ipv4:
force-device-detection:false
wireguard-persistent-keepalive:0s
mesh-auth-mutual-connect-timeout:5s
enable-local-node-route:true
enable-bgp-control-plane:false
endpoint-gc-interval:5m0s
hubble-redact-enabled:false
bpf-lb-affinity-map-max:0
bpf-events-drop-enabled:true
proxy-admin-port:0
label-prefix-file:
tofqdns-proxy-response-max-delay:100ms
envoy-log:
log-opt:
debug:false
enable-k8s-terminating-endpoint:true
agent-labels:
set-cilium-node-taints:true
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
ipv4-service-loopback-address:169.254.42.1
allocator-list-timeout:3m0s
mesh-auth-signal-backoff-duration:1s
direct-routing-skip-unreachable:false
proxy-xff-num-trusted-hops-egress:0
enable-svc-source-range-check:true
enable-gateway-api:false
enable-well-known-identities:false
http-normalize-path:true
hubble-prefer-ipv6:false
dnsproxy-lock-timeout:500ms
ipv6-cluster-alloc-cidr:f00d::/64
encryption-strict-mode-cidr:
bpf-ct-timeout-regular-tcp:2h13m20s
enable-bandwidth-manager:false
bpf-lb-sock:false
endpoint-bpf-prog-watchdog-interval:30s
hubble-redact-http-urlquery:false
enable-node-selector-labels:false
kvstore-opt:
cni-log-file:/var/run/cilium/cilium-cni.log
proxy-connect-timeout:2
bpf-events-trace-enabled:true
ipv6-mcast-device:
enable-service-topology:false
enable-l2-neigh-discovery:true
enable-k8s:true
proxy-xff-num-trusted-hops-ingress:0
node-labels:
tofqdns-endpoint-max-ip-per-hostname:50
policy-audit-mode:false
static-cnp-path:
enable-sctp:false
k8s-client-connection-keep-alive:30s
synchronize-k8s-nodes:true
node-port-range:
identity-allocation-mode:crd
state-dir:/var/run/cilium
enable-l2-announcements:false
auto-create-cilium-node-resource:true
proxy-gid:1337
bpf-neigh-global-max:524288
endpoint-queue-size:25
enable-vtep:false
hubble-redact-http-userinfo:true
devices:
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.91.0.0/24, 
Allocated addresses:
  10.91.0.11 (kube-system/clustermesh-apiserver-6c444cbbc9-knqth)
  10.91.0.194 (router)
  10.91.0.234 (kube-system/coredns-cc6ccd49c-fhjl5)
  10.91.0.47 (kube-system/coredns-cc6ccd49c-hcncb)
  10.91.0.78 (health)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 4de986cb68207c27
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    45s ago        never        0       no error   
  ct-map-pressure                                                     17s ago        never        0       no error   
  daemon-validate-config                                              33s ago        never        0       no error   
  dns-garbage-collector-job                                           49s ago        never        0       no error   
  endpoint-1068-regeneration-recovery                                 never          never        0       no error   
  endpoint-194-regeneration-recovery                                  never          never        0       no error   
  endpoint-411-regeneration-recovery                                  never          never        0       no error   
  endpoint-795-regeneration-recovery                                  never          never        0       no error   
  endpoint-948-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         4m49s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                17s ago        never        0       no error   
  ipcache-inject-labels                                               47s ago        never        0       no error   
  k8s-heartbeat                                                       19s ago        never        0       no error   
  link-cache                                                          2s ago         never        0       no error   
  local-identity-checkpoint                                           14m33s ago     never        0       no error   
  node-neighbor-link-updater                                          7s ago         never        0       no error   
  remote-etcd-cmesh1                                                  8m1s ago       never        0       no error   
  remote-etcd-cmesh10                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh100                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh101                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh102                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh103                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh104                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh105                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh106                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh107                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh108                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh109                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh11                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh110                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh111                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh112                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh113                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh114                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh115                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh116                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh117                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh118                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh119                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh12                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh120                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh121                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh122                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh123                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh124                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh125                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh126                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh127                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh128                                                8m1s ago       never        0       no error   
  remote-etcd-cmesh13                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh14                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh15                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh16                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh17                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh18                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh19                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh2                                                  8m1s ago       never        0       no error   
  remote-etcd-cmesh20                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh21                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh22                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh23                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh24                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh25                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh26                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh27                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh28                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh29                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh3                                                  8m1s ago       never        0       no error   
  remote-etcd-cmesh30                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh31                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh32                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh33                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh34                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh35                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh36                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh37                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh38                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh39                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh4                                                  8m1s ago       never        0       no error   
  remote-etcd-cmesh40                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh41                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh42                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh43                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh44                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh45                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh46                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh47                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh48                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh49                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh5                                                  8m1s ago       never        0       no error   
  remote-etcd-cmesh50                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh51                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh52                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh53                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh54                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh55                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh56                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh57                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh58                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh59                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh6                                                  8m1s ago       never        0       no error   
  remote-etcd-cmesh60                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh61                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh62                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh63                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh64                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh65                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh66                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh67                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh68                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh69                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh7                                                  8m1s ago       never        0       no error   
  remote-etcd-cmesh70                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh71                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh72                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh73                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh74                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh75                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh76                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh77                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh78                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh79                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh8                                                  8m1s ago       never        0       no error   
  remote-etcd-cmesh80                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh81                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh82                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh83                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh84                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh85                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh86                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh87                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh88                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh89                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh9                                                  8m1s ago       never        0       no error   
  remote-etcd-cmesh90                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh91                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh93                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh94                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh95                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh96                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh97                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh98                                                 8m1s ago       never        0       no error   
  remote-etcd-cmesh99                                                 8m1s ago       never        0       no error   
  resolve-identity-1068                                               4m47s ago      never        0       no error   
  resolve-identity-194                                                4m46s ago      never        0       no error   
  resolve-identity-411                                                4m32s ago      never        0       no error   
  resolve-identity-795                                                4m46s ago      never        0       no error   
  resolve-identity-948                                                3m11s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-6c444cbbc9-knqth   8m11s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-fhjl5                  14m32s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-hcncb                  14m46s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      14m47s ago     never        0       no error   
  sync-policymap-1068                                                 14m46s ago     never        0       no error   
  sync-policymap-194                                                  14m42s ago     never        0       no error   
  sync-policymap-411                                                  14m32s ago     never        0       no error   
  sync-policymap-795                                                  14m42s ago     never        0       no error   
  sync-policymap-948                                                  8m11s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (194)                                    6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (411)                                    2s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (948)                                    11s ago        never        0       no error   
  sync-utime                                                          47s ago        never        0       no error   
  write-cni-file                                                      14m49s ago     never        0       no error   
Proxy Status:            OK, ip 10.91.0.194, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 6029312, max 6094847
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 79.18   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Service list

```
ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.137.50:443 (active)     
                                         2 => 172.31.192.224:443 (active)    
2    10.100.97.40:443     ClusterIP      1 => 172.31.225.137:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.91.0.47:9153 (active)       
                                         2 => 10.91.0.234:9153 (active)      
4    10.100.0.10:53       ClusterIP      1 => 10.91.0.47:53 (active)         
                                         2 => 10.91.0.234:53 (active)        
5    10.100.14.163:2379   ClusterIP      1 => 10.91.0.11:2379 (active)       
```

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 29371412                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 29371412                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 29371412                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d000000 rw-p 00000000 00:00 0 
400d000000-4010000000 ---p 00000000 00:00 0 
ffff42453000-ffff42658000 rw-p 00000000 00:00 0 
ffff4265f000-ffff42741000 rw-p 00000000 00:00 0 
ffff42741000-ffff42782000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff42782000-ffff427c3000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff427c3000-ffff42803000 rw-p 00000000 00:00 0 
ffff42803000-ffff42805000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff42805000-ffff42807000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff42807000-ffff42dce000 rw-p 00000000 00:00 0 
ffff42dce000-ffff42ece000 rw-p 00000000 00:00 0 
ffff42ece000-ffff42edf000 rw-p 00000000 00:00 0 
ffff42edf000-ffff44edf000 rw-p 00000000 00:00 0 
ffff44edf000-ffff44f5f000 ---p 00000000 00:00 0 
ffff44f5f000-ffff44f60000 rw-p 00000000 00:00 0 
ffff44f60000-ffff64f5f000 ---p 00000000 00:00 0 
ffff64f5f000-ffff64f60000 rw-p 00000000 00:00 0 
ffff64f60000-ffff84eef000 ---p 00000000 00:00 0 
ffff84eef000-ffff84ef0000 rw-p 00000000 00:00 0 
ffff84ef0000-ffff88ee1000 ---p 00000000 00:00 0 
ffff88ee1000-ffff88ee2000 rw-p 00000000 00:00 0 
ffff88ee2000-ffff896df000 ---p 00000000 00:00 0 
ffff896df000-ffff896e0000 rw-p 00000000 00:00 0 
ffff896e0000-ffff897df000 ---p 00000000 00:00 0 
ffff897df000-ffff8983f000 rw-p 00000000 00:00 0 
ffff8983f000-ffff89841000 r--p 00000000 00:00 0                          [vvar]
ffff89841000-ffff89842000 r-xp 00000000 00:00 0                          [vdso]
ffffcfc81000-ffffcfca2000 rw-p 00000000 00:00 0                          [stack]

```

