CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1087b4b6_6716_4c54_8776_8c1cb0a0b1e6.slice/cri-containerd-267af023c09057fdfe76040599ee774d48dff82db99f0e79bb88a9614dec06de.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1087b4b6_6716_4c54_8776_8c1cb0a0b1e6.slice/cri-containerd-5aae4a71638607ff9a51202249136a0edc44309f220ec9b78e63186b768f4583.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1fda1075_9938_489a_bc59_9e9f9256aba2.slice/cri-containerd-16dc803e41615c49150baff2f6c7377c8b2962ac2a9440d018b27e326c69a379.scope
    128      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1fda1075_9938_489a_bc59_9e9f9256aba2.slice/cri-containerd-ca000d5bd392f0e7a6464466c021bf5f9375e111b341ec693ab19fc51bd8123e.scope
    85       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6585cd91_d8a0_4eac_8fc5_7f049ced266f.slice/cri-containerd-e11cbfe6071c9a158aafba284d86dd8d2bf0631d9ac954b263b91f77d5a8f136.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6585cd91_d8a0_4eac_8fc5_7f049ced266f.slice/cri-containerd-1fd1001d9379dbdb6c4972a7e6acfd457ea7ec1d2f8b7fa58d0c8cbcdfd6a71e.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5bf3ea71_58e0_4c45_a3a4_97e826da1993.slice/cri-containerd-922201513e016ff371f342bc7b760e3462e3060440524afe8871f7b21a53bd41.scope
    509      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5bf3ea71_58e0_4c45_a3a4_97e826da1993.slice/cri-containerd-aced74fc3dd0a2da6082ce821382db5e695a9ee01f80e1eda7e41f2fe10a460f.scope
    524      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod451b4995_1388_4576_a7fb_c4fb96b52fa5.slice/cri-containerd-655d21431c0988e5b2d3e7764a020253e4348cee8599cdbf954ed9476607697c.scope
    89       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod451b4995_1388_4576_a7fb_c4fb96b52fa5.slice/cri-containerd-79d2196b0845f443e1cf16434be5c6d17c8c200196a70107ebc0637a0187735a.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2bafd10f_9617_4720_835a_808d589dc6f8.slice/cri-containerd-fd8b9310389c5da80ce020fd5d07cf1105bc7bfc1930b1547e10c566e77b2144.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2bafd10f_9617_4720_835a_808d589dc6f8.slice/cri-containerd-37ccc6e42388a3101c0be853969be56e13d2b7a81b65011574ee37b2138763f7.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2af62822_32af_45f1_b682_628f1e09d110.slice/cri-containerd-9168fa874b03a07c35ec0f8cd3233b09756ce7170972aea0a27ca37b14403364.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2af62822_32af_45f1_b682_628f1e09d110.slice/cri-containerd-55aaf526b0ada97decb0f6c22efb06b58e705fc9547e68bc3564789fb51f3334.scope
    618      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2af62822_32af_45f1_b682_628f1e09d110.slice/cri-containerd-6081059998dcd10c09b5b40de5cccd15a2916d5d5b68a49810f847da89e2e8b9.scope
    638      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2af62822_32af_45f1_b682_628f1e09d110.slice/cri-containerd-2419c38b920a87e2eb8361c48c348cef63d51035e1d035c495aca379dc4845aa.scope
    642      cgroup_device   multi                                          
