Endpoint ID: 194
Path: /sys/fs/bpf/tc/globals/cilium_policy_00194

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83872   969       0        
Allow    Egress      0          ANY          NONE         disabled    14410   151       0        


Endpoint ID: 411
Path: /sys/fs/bpf/tc/globals/cilium_policy_00411

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    80772   923       0        
Allow    Egress      0          ANY          NONE         disabled    12982   135       0        


Endpoint ID: 795
Path: /sys/fs/bpf/tc/globals/cilium_policy_00795

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    444559   5682      0        
Allow    Ingress     1          ANY          NONE         disabled    12696    150       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 948
Path: /sys/fs/bpf/tc/globals/cilium_policy_00948

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3839158   36702     0        
Allow    Ingress     1          ANY          NONE         disabled    3708799   38247     0        
Allow    Egress      0          ANY          NONE         disabled    5497766   50733     0        


Endpoint ID: 1068
Path: /sys/fs/bpf/tc/globals/cilium_policy_01068

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


