key: c2 00 00 00  value: 06 02 00 00
key: 9b 01 00 00  value: 29 02 00 00
key: 1b 03 00 00  value: f0 01 00 00
key: b4 03 00 00  value: 5c 02 00 00
Found 4 elements
