alloc: 112.24MB (117696240 bytes)
total-alloc: 1.40GB (1501960848 bytes)
sys: 214.38MB (224798036 bytes)
lookups: 0
mallocs: 48884044
frees: 47706185
heap-alloc: 112.24MB (117696240 bytes)
heap-sys: 169.58MB (177815552 bytes)
heap-idle: 35.30MB (37011456 bytes)
heap-in-use: 134.28MB (140804096 bytes)
heap-released: 2.12MB (2228224 bytes)
heap-objects: 1177859
stack-in-use: 34.38MB (36044800 bytes)
stack-sys: 34.38MB (36044800 bytes)
stack-mspan-inuse: 2.20MB (2304000 bytes)
stack-mspan-sys: 2.47MB (2594880 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 866.23KB (887017 bytes)
gc-sys: 5.18MB (5431624 bytes)
next-gc: when heap-alloc >= 147.80MB (154977512 bytes)
last-gc: 2024-10-25 10:28:52.490179676 +0000 UTC
gc-pause-total: 10.397303ms
gc-pause: 99020
gc-pause-end: 1729852132490179676
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0003782294279881621
enable-gc: true
debug-gc: false
