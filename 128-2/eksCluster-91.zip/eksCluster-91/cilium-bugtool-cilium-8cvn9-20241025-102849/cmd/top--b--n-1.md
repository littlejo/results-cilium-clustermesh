top - 10:28:51 up 15 min,  0 users,  load average: 0.84, 0.35, 0.22
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 43.3 us, 40.0 sy,  0.0 ni, 13.3 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   3836.2 total,    782.6 free,    911.7 used,   2141.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2755.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 285836  78336 S  53.3   7.3   0:26.97 cilium-+
    635 root      20   0 1240432  16240  11420 S  13.3   0.4   0:00.03 cilium-+
    404 root      20   0 1228848   6904   3844 S   0.0   0.2   0:00.28 cilium-+
    687 root      20   0    6576   2424   2100 R   0.0   0.1   0:00.00 top
    688 root      20   0 1228744   3660   2976 S   0.0   0.1   0:00.00 gops
    701 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    702 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    735 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
