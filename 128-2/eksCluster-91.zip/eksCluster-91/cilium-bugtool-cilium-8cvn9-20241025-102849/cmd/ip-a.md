1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:d0:86:b7:36:c5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.225.137/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2698sec preferred_lft 2698sec
    inet6 fe80::8d0:86ff:feb7:36c5/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:fe:90:82:7d:e4 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5cfe:90ff:fe82:7de4/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:b1:f1:b0:56:be brd ff:ff:ff:ff:ff:ff
    inet 10.91.0.194/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::70b1:f1ff:feb0:56be/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 72:98:10:82:60:42 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::7098:10ff:fe82:6042/64 scope link 
       valid_lft forever preferred_lft forever
8: lxc_health@if7: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:37:4b:98:c9:c7 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::9c37:4bff:fe98:c9c7/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc177232b5b33c@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:c1:ad:8e:1a:9c brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d8c1:adff:fe8e:1a9c/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc3b7e6686968c@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:86:30:d9:ea:05 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::e886:30ff:fed9:ea05/64 scope link 
       valid_lft forever preferred_lft forever
16: lxc7175ac43d0a2@if15: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:10:ea:1c:ef:57 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::f810:eaff:fe1c:ef57/64 scope link 
       valid_lft forever preferred_lft forever
