xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 543
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 538
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 532
cilium_host(4) clsact/egress cil_from_host-cilium_host id 530
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 457
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 458
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 504
lxcba260a2c7bba(9) clsact/ingress cil_from_container-lxcba260a2c7bba id 496
lxc631ff6461c5e(11) clsact/ingress cil_from_container-lxc631ff6461c5e id 515
lxc681dcbf098d0(15) clsact/ingress cil_from_container-lxc681dcbf098d0 id 592

flow_dissector:

netfilter:

