REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     10554     830329      677    bpf_overlay.c
Interface                 INGRESS     232312    102106791   1132   bpf_host.c
Success                   EGRESS      11176     875953      53     encap.h
Success                   EGRESS      5748      446997      1694   bpf_host.c
Success                   EGRESS      99814     12858661    1308   bpf_lxc.c
Success                   INGRESS     110590    13589614    86     l3.h
Success                   INGRESS     116045    14016852    235    trace.h
Unsupported L3 protocol   EGRESS      35        2602        1492   bpf_lxc.c
