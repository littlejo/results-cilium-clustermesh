alloc: 115.25MB (120847960 bytes)
total-alloc: 1.40GB (1501603288 bytes)
sys: 210.70MB (220931412 bytes)
lookups: 0
mallocs: 48843569
frees: 47697379
heap-alloc: 115.25MB (120847960 bytes)
heap-sys: 165.13MB (173154304 bytes)
heap-idle: 28.28MB (29655040 bytes)
heap-in-use: 136.85MB (143499264 bytes)
heap-released: 3.00MB (3145728 bytes)
heap-objects: 1146190
stack-in-use: 34.84MB (36536320 bytes)
stack-sys: 34.84MB (36536320 bytes)
stack-mspan-inuse: 2.16MB (2263040 bytes)
stack-mspan-sys: 2.54MB (2660160 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.04MB (1093521 bytes)
gc-sys: 5.21MB (5464344 bytes)
next-gc: when heap-alloc >= 150.68MB (158002904 bytes)
last-gc: 2024-10-25 10:28:43.391245038 +0000 UTC
gc-pause-total: 8.009425ms
gc-pause: 95153
gc-pause-end: 1729852123391245038
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.000386058713250266
enable-gc: true
debug-gc: false
