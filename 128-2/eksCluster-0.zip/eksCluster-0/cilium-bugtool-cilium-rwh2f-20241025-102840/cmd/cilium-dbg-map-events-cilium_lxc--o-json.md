{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.592Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.188.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.592Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:41.540Z",
  "value": "id=2876  sec_id=111677 flags=0x0000 ifindex=9   mac=1E:D2:A8:2A:66:3A nodemac=8A:5F:60:16:84:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:45.295Z",
  "value": "id=776   sec_id=4     flags=0x0000 ifindex=7   mac=BE:C9:84:F5:BA:A7 nodemac=2A:5C:F9:29:CE:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:45.295Z",
  "value": "id=3572  sec_id=111677 flags=0x0000 ifindex=11  mac=C6:2F:E1:E9:71:12 nodemac=36:39:A8:C6:16:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:45.427Z",
  "value": "id=2876  sec_id=111677 flags=0x0000 ifindex=9   mac=1E:D2:A8:2A:66:3A nodemac=8A:5F:60:16:84:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:45.465Z",
  "value": "id=776   sec_id=4     flags=0x0000 ifindex=7   mac=BE:C9:84:F5:BA:A7 nodemac=2A:5C:F9:29:CE:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:45.538Z",
  "value": "id=3572  sec_id=111677 flags=0x0000 ifindex=11  mac=C6:2F:E1:E9:71:12 nodemac=36:39:A8:C6:16:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:10.374Z",
  "value": "id=3572  sec_id=111677 flags=0x0000 ifindex=11  mac=C6:2F:E1:E9:71:12 nodemac=36:39:A8:C6:16:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:10.374Z",
  "value": "id=776   sec_id=4     flags=0x0000 ifindex=7   mac=BE:C9:84:F5:BA:A7 nodemac=2A:5C:F9:29:CE:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:10.374Z",
  "value": "id=2876  sec_id=111677 flags=0x0000 ifindex=9   mac=1E:D2:A8:2A:66:3A nodemac=8A:5F:60:16:84:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:10.407Z",
  "value": "id=1286  sec_id=74789 flags=0x0000 ifindex=13  mac=66:EA:0E:E2:BD:DF nodemac=42:B6:71:C0:9A:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:11.374Z",
  "value": "id=1286  sec_id=74789 flags=0x0000 ifindex=13  mac=66:EA:0E:E2:BD:DF nodemac=42:B6:71:C0:9A:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:11.374Z",
  "value": "id=2876  sec_id=111677 flags=0x0000 ifindex=9   mac=1E:D2:A8:2A:66:3A nodemac=8A:5F:60:16:84:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:11.374Z",
  "value": "id=3572  sec_id=111677 flags=0x0000 ifindex=11  mac=C6:2F:E1:E9:71:12 nodemac=36:39:A8:C6:16:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:11.375Z",
  "value": "id=776   sec_id=4     flags=0x0000 ifindex=7   mac=BE:C9:84:F5:BA:A7 nodemac=2A:5C:F9:29:CE:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:20:55.227Z",
  "value": "id=786   sec_id=74789 flags=0x0000 ifindex=15  mac=5E:C6:EA:16:CF:34 nodemac=9A:58:BF:FC:61:61"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.0.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:05.471Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:28.557Z",
  "value": "id=776   sec_id=4     flags=0x0000 ifindex=7   mac=BE:C9:84:F5:BA:A7 nodemac=2A:5C:F9:29:CE:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:28.558Z",
  "value": "id=786   sec_id=74789 flags=0x0000 ifindex=15  mac=5E:C6:EA:16:CF:34 nodemac=9A:58:BF:FC:61:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:28.559Z",
  "value": "id=2876  sec_id=111677 flags=0x0000 ifindex=9   mac=1E:D2:A8:2A:66:3A nodemac=8A:5F:60:16:84:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:28.559Z",
  "value": "id=3572  sec_id=111677 flags=0x0000 ifindex=11  mac=C6:2F:E1:E9:71:12 nodemac=36:39:A8:C6:16:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:29.558Z",
  "value": "id=776   sec_id=4     flags=0x0000 ifindex=7   mac=BE:C9:84:F5:BA:A7 nodemac=2A:5C:F9:29:CE:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:29.559Z",
  "value": "id=2876  sec_id=111677 flags=0x0000 ifindex=9   mac=1E:D2:A8:2A:66:3A nodemac=8A:5F:60:16:84:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:29.559Z",
  "value": "id=786   sec_id=74789 flags=0x0000 ifindex=15  mac=5E:C6:EA:16:CF:34 nodemac=9A:58:BF:FC:61:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:29.559Z",
  "value": "id=3572  sec_id=111677 flags=0x0000 ifindex=11  mac=C6:2F:E1:E9:71:12 nodemac=36:39:A8:C6:16:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:30.559Z",
  "value": "id=2876  sec_id=111677 flags=0x0000 ifindex=9   mac=1E:D2:A8:2A:66:3A nodemac=8A:5F:60:16:84:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:30.559Z",
  "value": "id=786   sec_id=74789 flags=0x0000 ifindex=15  mac=5E:C6:EA:16:CF:34 nodemac=9A:58:BF:FC:61:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:30.559Z",
  "value": "id=776   sec_id=4     flags=0x0000 ifindex=7   mac=BE:C9:84:F5:BA:A7 nodemac=2A:5C:F9:29:CE:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:30.559Z",
  "value": "id=3572  sec_id=111677 flags=0x0000 ifindex=11  mac=C6:2F:E1:E9:71:12 nodemac=36:39:A8:C6:16:48"
}

