markdown output at /tmp/cilium-bugtool-20241025-102842.245+0000-UTC-191522643/cmd/cilium-debuginfo-20241025-102912.632+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102842.245+0000-UTC-191522643/cmd/cilium-debuginfo-20241025-102912.632+0000-UTC.json
