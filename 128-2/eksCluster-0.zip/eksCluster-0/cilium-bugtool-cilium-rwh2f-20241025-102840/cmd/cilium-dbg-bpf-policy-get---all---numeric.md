Endpoint ID: 776
Path: /sys/fs/bpf/tc/globals/cilium_policy_00776

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    428298   5468      0        
Allow    Ingress     1          ANY          NONE         disabled    13138    154       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 786
Path: /sys/fs/bpf/tc/globals/cilium_policy_00786

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3763662   36187     0        
Allow    Ingress     1          ANY          NONE         disabled    3603412   36927     0        
Allow    Egress      0          ANY          NONE         disabled    5531271   50932     0        


Endpoint ID: 1707
Path: /sys/fs/bpf/tc/globals/cilium_policy_01707

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2876
Path: /sys/fs/bpf/tc/globals/cilium_policy_02876

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    87281   1003      0        
Allow    Egress      0          ANY          NONE         disabled    13766   144       0        


Endpoint ID: 3572
Path: /sys/fs/bpf/tc/globals/cilium_policy_03572

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    86769   997       0        
Allow    Egress      0          ANY          NONE         disabled    13729   144       0        


