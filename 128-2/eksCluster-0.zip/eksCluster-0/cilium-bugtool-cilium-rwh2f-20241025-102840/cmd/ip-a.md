1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:62:46:7c:5c:d1 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.188.219/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2647sec preferred_lft 2647sec
    inet6 fe80::462:46ff:fe7c:5cd1/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:97:7e:14:59:4a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9497:7eff:fe14:594a/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:95:67:88:f5:ac brd ff:ff:ff:ff:ff:ff
    inet 10.0.0.5/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::1895:67ff:fe88:f5ac/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 8e:03:65:9f:ff:ca brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8c03:65ff:fe9f:ffca/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:5c:f9:29:ce:e3 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::285c:f9ff:fe29:cee3/64 scope link 
       valid_lft forever preferred_lft forever
9: lxcba260a2c7bba@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:5f:60:16:84:c9 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::885f:60ff:fe16:84c9/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc631ff6461c5e@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:39:a8:c6:16:48 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::3439:a8ff:fec6:1648/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc681dcbf098d0@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:58:bf:fc:61:61 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::9858:bfff:fefc:6161/64 scope link 
       valid_lft forever preferred_lft forever
