[
  {
    "containers": [
      {
        "cgroup-id": 8291,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddced54da_b11b_4823_abcb_4231076c97cf.slice/cri-containerd-6fc36c215d3422b708433b0d3ad2426fedf69d70fb315907b632c1b58b78e90b.scope"
      },
      {
        "cgroup-id": 8207,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddced54da_b11b_4823_abcb_4231076c97cf.slice/cri-containerd-af87522ee0d9ae7ada1ad55aa5683ec617bf04aa3cec99395647682a20a69d3a.scope"
      },
      {
        "cgroup-id": 8375,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddced54da_b11b_4823_abcb_4231076c97cf.slice/cri-containerd-5d54c5b937ef98dcfd476b5f16b2c28daf52f0b71ca0251ffe701eb96796ba00.scope"
      }
    ],
    "ips": [
      "10.0.0.254"
    ],
    "name": "clustermesh-apiserver-84bc65c54-kmw2v",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6695,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1dd7c004_7b96_47f4_b229_654011442546.slice/cri-containerd-e36dcb6161412b7db317e150dd21db4a60a4586b740f1fb8e2b019f687e5592f.scope"
      }
    ],
    "ips": [
      "10.0.0.134"
    ],
    "name": "coredns-cc6ccd49c-5c2kl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6863,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcb54a1ec_5bca_441d_a51b_3036c9e803ec.slice/cri-containerd-cfa57b697eba0e95e9d89d6883bd2e468c5e2161daf108526fb9c375a6725b6f.scope"
      }
    ],
    "ips": [
      "10.0.0.110"
    ],
    "name": "coredns-cc6ccd49c-p8kfz",
    "namespace": "kube-system"
  }
]

