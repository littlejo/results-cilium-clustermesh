key: 08 03 00 00  value: f5 01 00 00
key: 12 03 00 00  value: 4f 02 00 00
key: 3c 0b 00 00  value: ee 01 00 00
key: f4 0d 00 00  value: 05 02 00 00
Found 4 elements
