{
  "action": "update",
  "desired-action": "sync",
  "key": "1",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:35.077Z",
  "value": "ANY://172.31.189.233"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "2",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:39.154Z",
  "value": "ANY://172.31.188.219"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:43.315Z",
  "value": "ANY://10.0.0.134"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:43.315Z",
  "value": "ANY://10.0.0.134"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "5",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:46.337Z",
  "value": "ANY://10.0.0.110"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "6",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:46.337Z",
  "value": "ANY://10.0.0.110"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "7",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:46.913Z",
  "value": "ANY://172.31.192.87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:19.390Z",
  "value": "ANY://10.0.0.35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "9",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:05.162Z",
  "value": "ANY://10.0.0.254"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:05.224Z",
  "value": "ANY://10.0.0.35"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:05.548Z",
  "value": "\u003cnil\u003e"
}

