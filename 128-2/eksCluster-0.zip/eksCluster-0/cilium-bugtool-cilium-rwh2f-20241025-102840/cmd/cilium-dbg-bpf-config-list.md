KEY             VALUE
AgentLiveness   994166073367
UTimeOffset     3378615542968750
