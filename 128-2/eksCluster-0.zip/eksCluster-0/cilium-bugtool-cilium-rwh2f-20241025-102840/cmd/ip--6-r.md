fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxcba260a2c7bba proto kernel metric 256 pref medium
fe80::/64 dev lxc631ff6461c5e proto kernel metric 256 pref medium
fe80::/64 dev lxc681dcbf098d0 proto kernel metric 256 pref medium
