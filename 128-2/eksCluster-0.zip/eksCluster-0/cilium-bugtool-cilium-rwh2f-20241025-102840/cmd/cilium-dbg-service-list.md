ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.189.233:443 (active)    
                                          2 => 172.31.192.87:443 (active)     
2    10.100.153.210:443    ClusterIP      1 => 172.31.188.219:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.0.0.134:9153 (active)       
                                          2 => 10.0.0.110:9153 (active)       
4    10.100.0.10:53        ClusterIP      1 => 10.0.0.134:53 (active)         
                                          2 => 10.0.0.110:53 (active)         
5    10.100.110.196:2379   ClusterIP      1 => 10.0.0.254:2379 (active)       
