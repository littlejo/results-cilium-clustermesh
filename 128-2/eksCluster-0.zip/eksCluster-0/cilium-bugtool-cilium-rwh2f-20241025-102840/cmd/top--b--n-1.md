top - 10:28:42 up 16 min,  0 users,  load average: 0.37, 0.28, 0.20
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 48.4 us, 25.8 sy,  0.0 ni, 25.8 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1174.0 free,    905.3 used,   1756.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2762.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1472816 276188  78072 S   6.7   7.0   0:27.40 cilium-+
    532 root      20   0 1228848   5528   2868 S   0.0   0.1   0:00.26 cilium-+
    802 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    808 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
    816 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    842 root      20   0 1240176  15880  11164 S   0.0   0.4   0:00.03 cilium-+
    881 root      20   0    6576   2396   2068 R   0.0   0.1   0:00.00 top
    900 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
