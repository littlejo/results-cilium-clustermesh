IP ADDRESS         LOCAL ENDPOINT INFO
10.0.0.254:0       id=786   sec_id=74789 flags=0x0000 ifindex=15  mac=5E:C6:EA:16:CF:34 nodemac=9A:58:BF:FC:61:61    
10.0.0.110:0       id=3572  sec_id=111677 flags=0x0000 ifindex=11  mac=C6:2F:E1:E9:71:12 nodemac=36:39:A8:C6:16:48   
172.31.188.219:0   (localhost)                                                                                       
10.0.0.126:0       id=776   sec_id=4     flags=0x0000 ifindex=7   mac=BE:C9:84:F5:BA:A7 nodemac=2A:5C:F9:29:CE:E3    
10.0.0.5:0         (localhost)                                                                                       
10.0.0.134:0       id=2876  sec_id=111677 flags=0x0000 ifindex=9   mac=1E:D2:A8:2A:66:3A nodemac=8A:5F:60:16:84:C9   
