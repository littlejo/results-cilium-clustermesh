CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6d7373f9_504d_4ef1_9e98_4f737b6e8005.slice/cri-containerd-726d41e82dd10e737b2201b33e78cd87cd459dba93fc7a828b6de861b4fc78cd.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6d7373f9_504d_4ef1_9e98_4f737b6e8005.slice/cri-containerd-391bbb33055570d1d103bd68e096fb6e744248040fee61824c3b9908d4cae01b.scope
    69       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1dd7c004_7b96_47f4_b229_654011442546.slice/cri-containerd-e36dcb6161412b7db317e150dd21db4a60a4586b740f1fb8e2b019f687e5592f.scope
    463      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1dd7c004_7b96_47f4_b229_654011442546.slice/cri-containerd-a6f715f49fa26a232d6998d782f831072a7ec0127b985ef456cee993079a4199.scope
    455      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcb54a1ec_5bca_441d_a51b_3036c9e803ec.slice/cri-containerd-47b135300f065364667471dc335be847c263e4b6fc4955f55a880f382811b409.scope
    500      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcb54a1ec_5bca_441d_a51b_3036c9e803ec.slice/cri-containerd-cfa57b697eba0e95e9d89d6883bd2e468c5e2161daf108526fb9c375a6725b6f.scope
    526      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb33eccfe_0f20_48be_bcac_829d425f4be9.slice/cri-containerd-f45f71114c6b8e0b7bcba585547c21b59c19c711c69652002cb34a0562f41e8c.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb33eccfe_0f20_48be_bcac_829d425f4be9.slice/cri-containerd-57380c81ed105495c85009efca9236afc037f5e0fed72cc57ff3e36f7dfdd0c6.scope
    100      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddced54da_b11b_4823_abcb_4231076c97cf.slice/cri-containerd-ec6209cf316b1b7d1f9bc0cf69a1fd3214bf3fab1d58cbcb39189dfc09ee6358.scope
    601      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddced54da_b11b_4823_abcb_4231076c97cf.slice/cri-containerd-5d54c5b937ef98dcfd476b5f16b2c28daf52f0b71ca0251ffe701eb96796ba00.scope
    625      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddced54da_b11b_4823_abcb_4231076c97cf.slice/cri-containerd-af87522ee0d9ae7ada1ad55aa5683ec617bf04aa3cec99395647682a20a69d3a.scope
    617      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddced54da_b11b_4823_abcb_4231076c97cf.slice/cri-containerd-6fc36c215d3422b708433b0d3ad2426fedf69d70fb315907b632c1b58b78e90b.scope
    621      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod580948bd_6153_459e_b7b2_c95aef863fe9.slice/cri-containerd-dd599ec7dbaa2e9d5fb891b6e73997d67a5a11f217e4e40566613369bdab92e3.scope
    73       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod580948bd_6153_459e_b7b2_c95aef863fe9.slice/cri-containerd-7af1adc970de97f7805d4c1f094abe691fbb6e6c69498ab3bdbca06d84cbeed4.scope
    62       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddc5eaba4_59c0_49c6_a997_4dc706872081.slice/cri-containerd-04733379f2442f63df3795cbf2793a9ac8663bbebe3b3d04683bfda55e67db15.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddc5eaba4_59c0_49c6_a997_4dc706872081.slice/cri-containerd-1aface6331721d504b75d56e5a3b9748f52fa8cb3054e23ca5279eb0bc27a733.scope
    58       cgroup_device   multi                                          
