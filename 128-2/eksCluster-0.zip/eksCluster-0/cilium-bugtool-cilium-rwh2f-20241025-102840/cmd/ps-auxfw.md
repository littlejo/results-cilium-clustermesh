USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         842  0.0  0.4 1240176 15880 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         865  0.0  0.0   6408  1636 ?        R    10:28   0:00  \_ ps auxfw
root         816  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops stack 1
root         808  0.0  0.0 1228744 3780 ?        Ssl  10:28   0:00 /bin/gops memstats 1
root         802  0.0  0.1 1229000 4052 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  2.9  7.0 1472816 276188 ?      Ssl  10:13   0:27 cilium-agent --config-dir=/tmp/cilium/config-map
root         532  0.0  0.1 1228848 5528 ?        Sl   10:13   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
