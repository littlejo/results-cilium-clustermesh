filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc681dcbf098d0 direct-action not_in_hw id 592 tag c45856f8dc6cd7ed jited 
