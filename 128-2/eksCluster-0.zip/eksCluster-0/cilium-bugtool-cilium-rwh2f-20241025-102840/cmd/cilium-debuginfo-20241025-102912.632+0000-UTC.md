# Cilium debug information

#### Cilium environment keys

```
http-idle-timeout:0
endpoint-queue-size:25
enable-hubble-recorder-api:true
enable-ipv6-masquerade:true
debug:false
debug-verbose:
iptables-random-fully:false
state-dir:/var/run/cilium
enable-stale-cilium-endpoint-cleanup:true
enable-monitor:true
bpf-map-dynamic-size-ratio:0.0025
vtep-cidr:
kvstore-opt:
bpf-lb-rss-ipv4-src-cidr:
hubble-export-file-max-size-mb:10
enable-tcx:true
custom-cni-conf:false
enable-custom-calls:false
pprof-port:6060
mke-cgroup-mount:
ipsec-key-rotation-duration:5m0s
ipv6-pod-subnets:
hubble-redact-http-headers-allow:
direct-routing-skip-unreachable:false
ipv4-service-range:auto
hubble-skip-unknown-cgroup-ids:true
enable-node-port:false
hubble-recorder-sink-queue-size:1024
enable-mke:false
gops-port:9890
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
enable-nat46x64-gateway:false
bpf-map-event-buffers:
enable-auto-protect-node-port-range:true
prepend-iptables-chains:true
cni-external-routing:false
enable-bpf-tproxy:false
bpf-lb-dsr-dispatch:opt
ipv4-pod-subnets:
enable-service-topology:false
bpf-fragments-map-max:8192
labels:
enable-cilium-api-server-access:
proxy-portrange-min:10000
max-internal-timer-delay:0s
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
encryption-strict-mode-cidr:
enable-xt-socket-fallback:true
monitor-aggregation-interval:5s
ipv4-node:auto
local-router-ipv6:
procfs:/host/proc
log-driver:
enable-bpf-masquerade:false
identity-heartbeat-timeout:30m0s
service-no-backend-response:reject
tunnel-protocol:vxlan
node-port-mode:snat
enable-l2-pod-announcements:false
kube-proxy-replacement:false
mesh-auth-spiffe-trust-domain:spiffe.cilium
hubble-flowlogs-config-path:
enable-health-check-nodeport:true
max-connected-clusters:255
preallocate-bpf-maps:false
vtep-mask:
ipv6-range:auto
crd-wait-timeout:5m0s
bpf-lb-sock:false
devices:
k8s-service-proxy-name:
nat-map-stats-interval:30s
operator-prometheus-serve-addr::9963
ipv4-range:auto
ipv6-cluster-alloc-cidr:f00d::/64
proxy-max-connection-duration-seconds:0
use-cilium-internal-ip-for-ipsec:false
allocator-list-timeout:3m0s
enable-external-ips:false
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
cgroup-root:/run/cilium/cgroupv2
proxy-prometheus-port:0
enable-ip-masq-agent:false
dnsproxy-concurrency-limit:0
k8s-require-ipv4-pod-cidr:false
direct-routing-device:
ipv4-service-loopback-address:169.254.42.1
trace-sock:true
derive-masq-ip-addr-from-device:
policy-trigger-interval:1s
hubble-redact-enabled:false
agent-labels:
bpf-lb-sock-terminate-pod-connections:false
hubble-redact-kafka-apikey:false
k8s-client-burst:20
enable-host-legacy-routing:false
hubble-recorder-storage-path:/var/run/cilium/pcaps
mesh-auth-gc-interval:5m0s
bpf-policy-map-full-reconciliation-interval:15m0s
cmdref:
enable-ipv6-big-tcp:false
annotate-k8s-node:false
nat-map-stats-entries:32
ipv6-native-routing-cidr:
config:
identity-allocation-mode:crd
cflags:
log-system-load:false
http-request-timeout:3600
bgp-config-path:/var/lib/cilium/bgp/config.yaml
policy-accounting:true
envoy-config-timeout:2m0s
envoy-keep-cap-netbindservice:false
tofqdns-min-ttl:0
tofqdns-proxy-port:0
enable-high-scale-ipcache:false
bpf-lb-maglev-map-max:0
conntrack-gc-interval:0s
enable-local-node-route:true
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
bpf-lb-service-backend-map-max:0
bpf-lb-rev-nat-map-max:0
ipv6-node:auto
tofqdns-proxy-response-max-delay:100ms
enable-session-affinity:false
tofqdns-idle-connection-grace-period:0s
unmanaged-pod-watcher-interval:15
policy-audit-mode:false
bpf-policy-map-max:16384
bpf-ct-timeout-regular-tcp:2h13m20s
nodes-gc-interval:5m0s
bpf-root:/sys/fs/bpf
bpf-ct-global-any-max:262144
egress-multi-home-ip-rule-compat:false
enable-bandwidth-manager:false
controller-group-metrics:
ipv4-native-routing-cidr:
bpf-lb-sock-hostns-only:false
mesh-auth-mutual-listener-port:0
enable-k8s-networkpolicy:true
encrypt-node:false
api-rate-limit:
pprof-address:localhost
enable-k8s-terminating-endpoint:true
enable-bpf-clock-probe:false
http-retry-count:3
hubble-drop-events:false
mesh-auth-spire-admin-socket:
enable-ipv6-ndp:false
ipv6-service-range:auto
fixed-identity-mapping:
hubble-listen-address::4244
enable-ipsec-encrypted-overlay:false
hubble-redact-http-urlquery:false
ipam-cilium-node-update-rate:15s
k8s-client-connection-timeout:30s
ipv6-mcast-device:
route-metric:0
ipam-multi-pool-pre-allocation:
enable-local-redirect-policy:false
enable-identity-mark:true
enable-xdp-prefilter:false
enable-ipsec:false
local-max-addr-scope:252
mesh-auth-rotated-identities-queue-size:1024
nodeport-addresses:
clustermesh-enable-mcs-api:false
dnsproxy-concurrency-processing-grace-period:0s
prometheus-serve-addr:
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
enable-host-port:false
tofqdns-enable-dns-compression:true
vlan-bpf-bypass:
allow-localhost:auto
proxy-max-requests-per-connection:0
enable-route-mtu-for-cni-chaining:false
socket-path:/var/run/cilium/cilium.sock
install-no-conntrack-iptables-rules:false
arping-refresh-period:30s
http-normalize-path:true
tunnel-port:0
bpf-filter-priority:1
enable-l2-neigh-discovery:true
l2-announcements-renew-deadline:5s
hubble-event-buffer-capacity:4095
enable-tracing:false
enable-policy:default
l2-announcements-retry-period:2s
proxy-idle-timeout-seconds:60
enable-ipv4:true
enable-k8s:true
enable-envoy-config:false
kvstore-periodic-sync:5m0s
mesh-auth-enabled:true
egress-gateway-policy-map-max:16384
enable-ipv4-egress-gateway:false
ipam:cluster-pool
cni-exclusive:true
proxy-connect-timeout:2
bpf-node-map-max:16384
enable-l7-proxy:true
cluster-pool-ipv4-mask-size:24
proxy-gid:1337
cni-chaining-target:
k8s-kubeconfig-path:
restore:true
bpf-ct-timeout-service-tcp-grace:1m0s
bpf-ct-timeout-regular-tcp-syn:1m0s
tofqdns-pre-cache:
metrics:
enable-ingress-controller:false
enable-pmtu-discovery:false
datapath-mode:veth
remove-cilium-node-taints:true
bgp-announce-pod-cidr:false
ipam-default-ip-pool:default
auto-create-cilium-node-resource:true
label-prefix-file:
hubble-metrics:
k8s-sync-timeout:3m0s
bpf-events-trace-enabled:true
enable-health-check-loadbalancer-ip:false
k8s-require-ipv6-pod-cidr:false
cluster-health-port:4240
hubble-export-fieldmask:
enable-ipip-termination:false
container-ip-local-reserved-ports:auto
enable-ipv6:false
enable-gateway-api:false
hubble-redact-http-headers-deny:
hubble-redact-http-userinfo:true
cluster-pool-ipv4-cidr:10.0.0.0/16
enable-host-firewall:false
hubble-event-queue-size:0
wireguard-persistent-keepalive:0s
enable-node-selector-labels:false
enable-masquerade-to-route-source:false
bpf-lb-affinity-map-max:0
read-cni-conf:
clustermesh-config:/var/lib/cilium/clustermesh/
proxy-xff-num-trusted-hops-ingress:0
enable-cilium-health-api-server-access:
egress-gateway-reconciliation-trigger-interval:1s
mesh-auth-signal-backoff-duration:1s
ingress-secrets-namespace:
dnsproxy-socket-linger-timeout:10
force-device-detection:false
enable-active-connection-tracking:false
bpf-lb-map-max:65536
l2-announcements-lease-duration:15s
hubble-export-denylist:
vtep-endpoint:
enable-bgp-control-plane:false
operator-api-serve-addr:127.0.0.1:9234
join-cluster:false
enable-cilium-endpoint-slice:false
envoy-config-retry-interval:15s
bpf-lb-algorithm:random
tofqdns-endpoint-max-ip-per-hostname:50
kvstore-max-consecutive-quorum-errors:2
hubble-socket-path:/var/run/cilium/hubble.sock
enable-ipv4-big-tcp:false
max-controller-interval:0
bpf-auth-map-max:524288
proxy-portrange-max:20000
bpf-lb-mode:snat
encryption-strict-mode-allow-remote-node-identities:false
log-opt:
bypass-ip-availability-upon-restore:false
use-full-tls-context:false
pprof:false
bpf-events-policy-verdict-enabled:true
trace-payloadlen:128
cni-log-file:/var/run/cilium/cilium-cni.log
egress-masquerade-interfaces:ens+
monitor-aggregation:medium
dnsproxy-enable-transparent-mode:true
bpf-ct-global-tcp-max:524288
bpf-sock-rev-map-max:262144
bgp-announce-lb-ip:false
proxy-xff-num-trusted-hops-egress:0
bpf-lb-external-clusterip:false
exclude-local-address:
ip-masq-agent-config-path:/etc/config/ip-masq-agent
iptables-lock-timeout:5s
set-cilium-node-taints:true
disable-iptables-feeder-rules:
version:false
bpf-events-drop-enabled:true
node-port-acceleration:disabled
enable-well-known-identities:false
enable-sctp:false
kvstore:
disable-external-ip-mitigation:false
kvstore-connectivity-timeout:2m0s
dnsproxy-insecure-skip-transparent-mode-check:false
hubble-export-file-path:
bpf-nat-global-max:524288
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
disable-endpoint-crd:false
enable-wireguard-userspace-fallback:false
monitor-aggregation-flags:all
bpf-lb-acceleration:disabled
hubble-export-file-compress:false
mesh-auth-mutual-connect-timeout:5s
envoy-secrets-namespace:
envoy-base-id:0
clustermesh-ip-identities-sync-timeout:1m0s
srv6-encap-mode:reduced
gateway-api-secrets-namespace:
bpf-ct-timeout-service-tcp:2h13m20s
k8s-client-qps:10
http-retry-timeout:0
bpf-ct-timeout-regular-tcp-fin:10s
k8s-client-connection-keep-alive:30s
hubble-prefer-ipv6:false
proxy-admin-port:0
dns-policy-unload-on-shutdown:false
config-sources:config-map:kube-system/cilium-config
hubble-metrics-server:
identity-change-grace-period:5s
multicast-enabled:false
exclude-node-label-patterns:
http-max-grpc-timeout:0
enable-vtep:false
bpf-lb-rss-ipv6-src-cidr:
enable-endpoint-health-checking:true
k8s-namespace:kube-system
hubble-monitor-events:
enable-metrics:true
identity-restore-grace-period:30s
endpoint-bpf-prog-watchdog-interval:30s
bpf-ct-timeout-regular-any:1m0s
encrypt-interface:
certificates-directory:/var/run/cilium/certs
enable-unreachable-routes:false
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
node-labels:
static-cnp-path:
fqdn-regex-compile-lru-size:1024
config-dir:/tmp/cilium/config-map
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
set-cilium-is-up-condition:true
keep-config:false
enable-bbr:false
hubble-export-allowlist:
bpf-lb-source-range-map-max:0
ipsec-key-file:
enable-hubble:true
enable-recorder:false
cilium-endpoint-gc-interval:5m0s
enable-ipv4-fragment-tracking:true
agent-health-port:9879
kvstore-lease-ttl:15m0s
hubble-export-file-max-backups:5
dnsproxy-lock-timeout:500ms
install-iptables-rules:true
kube-proxy-replacement-healthz-bind-address:
enable-wireguard:false
auto-direct-node-routes:false
bpf-lb-maglev-table-size:16381
dns-max-ips-per-restored-rule:1000
synchronize-k8s-nodes:true
node-port-range:
enable-ipv4-masquerade:true
hubble-drop-events-interval:2m0s
cluster-name:cmesh1
monitor-queue-size:0
enable-srv6:false
hubble-drop-events-reasons:auth_required,policy_denied
node-port-bind-protection:true
bpf-ct-timeout-service-any:1m0s
node-port-algorithm:random
bpf-neigh-global-max:524288
enable-health-checking:true
cluster-id:1
endpoint-gc-interval:5m0s
l2-pod-announcements-interface:
allow-icmp-frag-needed:true
external-envoy-proxy:true
envoy-log:
policy-queue-size:100
mtu:0
disable-envoy-version-check:false
bpf-lb-service-map-max:0
local-router-ipv4:
agent-liveness-update-interval:1s
k8s-service-cache-size:128
hubble-disable-tls:false
enable-runtime-device-detection:true
tofqdns-max-deferred-connection-deletes:10000
enable-k8s-api-discovery:false
enable-l2-announcements:false
enable-icmp-rules:true
enable-svc-source-range-check:true
enable-k8s-endpoint-slice:true
clustermesh-sync-timeout:1m0s
clustermesh-enable-endpoint-sync:false
tofqdns-dns-reject-response-code:refused
cni-chaining-mode:none
enable-endpoint-routes:false
identity-gc-interval:15m0s
vtep-mac:
enable-ipsec-key-watcher:true
conntrack-gc-max-interval:0s
routing-mode:tunnel
dnsproxy-lock-count:131
policy-cidr-match-mode:
lib-dir:/var/lib/cilium
bpf-lb-dsr-l4-xlate:frontend
mesh-auth-queue-size:1024
k8s-heartbeat-timeout:30s
enable-encryption-strict-mode:false
enable-ipsec-xfrm-state-caching:true
k8s-api-server:
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4         STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                   
776        Disabled           Disabled          4          reserved:health                                                                     10.0.0.126   ready   
786        Disabled           Disabled          74789      k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.0.0.254   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh1                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                              
                                                           k8s:k8s-app=clustermesh-apiserver                                                                        
1707       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                  ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                    
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                              
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                               
                                                           reserved:host                                                                                            
2876       Disabled           Disabled          111677     k8s:eks.amazonaws.com/component=coredns                                             10.0.0.134   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh1                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                          
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                              
                                                           k8s:k8s-app=kube-dns                                                                                     
3572       Disabled           Disabled          111677     k8s:eks.amazonaws.com/component=coredns                                             10.0.0.110   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh1                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                          
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                              
                                                           k8s:k8s-app=kube-dns                                                                                     
```

#### BPF Policy Get 776

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    427106   5453      0        
Allow    Ingress     1          ANY          NONE         disabled    13138    154       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 776

```
Invalid argument: unknown type 776
```


#### Endpoint Get 776

```
[
  {
    "id": 776,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-776-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "ba94d978-57a4-435a-9657-5baf2dc01359"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-776",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:39.865Z",
            "success-count": 4
          },
          "uuid": "4cee38e7-2dc4-41b2-b1c5-f279bc2b5ee2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-776",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:45.297Z",
            "success-count": 2
          },
          "uuid": "3b420b10-6235-4e5a-a90c-6e18805584c0"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:30Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.0.0.126",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "2a:5c:f9:29:ce:e3",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "be:c9:84:f5:ba:a7"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 776

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 776

```
Timestamp              Status   State                   Message
2024-10-25T10:21:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:30Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:13:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:45Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:13:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:13:41Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:40Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:13:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:39Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:38Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 786

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3758890   36134     0        
Allow    Ingress     1          ANY          NONE         disabled    3603412   36927     0        
Allow    Egress      0          ANY          NONE         disabled    5523893   50850     0        

```


#### BPF CT List 786

```
Invalid argument: unknown type 786
```


#### Endpoint Get 786

```
[
  {
    "id": 786,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-786-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "77a1ecec-c1d6-48fe-9659-2e210abc98ca"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-786",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:25:55.195Z",
            "success-count": 2
          },
          "uuid": "bfe3f8d2-c08f-464e-ac4f-8f023371f0f0"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-84bc65c54-kmw2v",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:20:55.193Z",
            "success-count": 1
          },
          "uuid": "73bd8bbe-c3e9-4ab1-b4d3-7efdc6350b36"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-786",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:20:55.227Z",
            "success-count": 1
          },
          "uuid": "6bffe720-e3db-4536-b383-8cce95fcc7e5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (786)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:05.244Z",
            "success-count": 51
          },
          "uuid": "df4bf54d-45d8-40bc-830b-07ae2d701174"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "ec6209cf316b1b7d1f9bc0cf69a1fd3214bf3fab1d58cbcb39189dfc09ee6358:eth0",
        "container-id": "ec6209cf316b1b7d1f9bc0cf69a1fd3214bf3fab1d58cbcb39189dfc09ee6358",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-84bc65c54-kmw2v",
        "pod-name": "kube-system/clustermesh-apiserver-84bc65c54-kmw2v"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 74789,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh1",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=84bc65c54"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh1",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:30Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.0.0.254",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "9a:58:bf:fc:61:61",
        "interface-index": 15,
        "interface-name": "lxc681dcbf098d0",
        "mac": "5e:c6:ea:16:cf:34"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 74789,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 74789,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 786

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 786

```
Timestamp              Status   State                   Message
2024-10-25T10:21:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:30Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:20:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:20:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:20:55Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:20:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:20:55Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:20:55Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 74789

```
ID      LABELS
74789   k8s:app.kubernetes.io/name=clustermesh-apiserver
        k8s:app.kubernetes.io/part-of=cilium
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=cmesh1
        k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1707

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1707

```
Invalid argument: unknown type 1707
```


#### Endpoint Get 1707

```
[
  {
    "id": 1707,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1707-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "9b7fed8b-6413-4d46-8220-b599f2ae6679"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1707",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:38.799Z",
            "success-count": 4
          },
          "uuid": "d51b9cac-b7b4-48c2-8777-2f3ed01ed6e7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1707",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:39.937Z",
            "success-count": 2
          },
          "uuid": "5939c4dd-2dae-4684-aec3-302d0ef9c111"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:30Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "1a:95:67:88:f5:ac",
        "interface-name": "cilium_host",
        "mac": "1a:95:67:88:f5:ac"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1707

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1707

```
Timestamp              Status   State                   Message
2024-10-25T10:21:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:30Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:45Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:13:40Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:13:39Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:38Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:38Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:38Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 2876

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    87281   1003      0        
Allow    Egress      0          ANY          NONE         disabled    13766   144       0        

```


#### BPF CT List 2876

```
Invalid argument: unknown type 2876
```


#### Endpoint Get 2876

```
[
  {
    "id": 2876,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2876-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "a60f166a-945f-4879-8079-2b1edafbc969"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2876",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:39.149Z",
            "success-count": 4
          },
          "uuid": "bad15253-abc7-48a8-9c93-782a0540cae0"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-5c2kl",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:13:39.146Z",
            "success-count": 1
          },
          "uuid": "1dac7293-7e8a-4ddf-9292-c71d6fcac022"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2876",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:41.541Z",
            "success-count": 2
          },
          "uuid": "9683a173-44d7-4cb2-8796-9e1582f453db"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2876)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:09.225Z",
            "success-count": 95
          },
          "uuid": "872b4be3-702e-493c-a868-fe272922f782"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "a6f715f49fa26a232d6998d782f831072a7ec0127b985ef456cee993079a4199:eth0",
        "container-id": "a6f715f49fa26a232d6998d782f831072a7ec0127b985ef456cee993079a4199",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-5c2kl",
        "pod-name": "kube-system/coredns-cc6ccd49c-5c2kl"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 111677,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh1",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh1",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:30Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.0.0.134",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "8a:5f:60:16:84:c9",
        "interface-index": 9,
        "interface-name": "lxcba260a2c7bba",
        "mac": "1e:d2:a8:2a:66:3a"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 111677,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 111677,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2876

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2876

```
Timestamp              Status    State                   Message
2024-10-25T10:21:30Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:30Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:30Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:21:30Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:29Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:29Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:29Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:29Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:28Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:28Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:28Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:28Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:11Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:11Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:11Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:11Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:10Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:10Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:10Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:10Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:45Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:45Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:45Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:42Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:13:41Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:40Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:39Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:39Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:39Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:13:39Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:39Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 111677

```
ID       LABELS
111677   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh1
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 3572

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    86769   997       0        
Allow    Egress      0          ANY          NONE         disabled    13729   144       0        

```


#### BPF CT List 3572

```
Invalid argument: unknown type 3572
```


#### Endpoint Get 3572

```
[
  {
    "id": 3572,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3572-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c8f56b01-bd80-4cd4-8bb2-1cdad2200cb4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3572",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:39.211Z",
            "success-count": 4
          },
          "uuid": "c58f0903-727c-4eba-b751-f2ded37c8565"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-p8kfz",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:13:39.209Z",
            "success-count": 1
          },
          "uuid": "1db7de49-8084-4072-9bd3-5516c7dc84fc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3572",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:45.304Z",
            "success-count": 2
          },
          "uuid": "2491caac-338b-46ea-9052-7ba5d46399f5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3572)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:09.289Z",
            "success-count": 95
          },
          "uuid": "924d4bda-d945-4893-b1e7-d62950a359e7"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "47b135300f065364667471dc335be847c263e4b6fc4955f55a880f382811b409:eth0",
        "container-id": "47b135300f065364667471dc335be847c263e4b6fc4955f55a880f382811b409",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-p8kfz",
        "pod-name": "kube-system/coredns-cc6ccd49c-p8kfz"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 111677,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh1",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh1",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:30Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.0.0.110",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "36:39:a8:c6:16:48",
        "interface-index": 11,
        "interface-name": "lxc631ff6461c5e",
        "mac": "c6:2f:e1:e9:71:12"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 111677,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 111677,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3572

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3572

```
Timestamp              Status   State                   Message
2024-10-25T10:21:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:30Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:13:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:13:45Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:13:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:13:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:13:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:13:39Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:13:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:13:39Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:13:39Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 111677

```
ID       LABELS
111677   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh1
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.0.0.126": (string) (len=6) "health",
  (string) (len=10) "10.0.0.134": (string) (len=35) "kube-system/coredns-cc6ccd49c-5c2kl",
  (string) (len=10) "10.0.0.110": (string) (len=35) "kube-system/coredns-cc6ccd49c-p8kfz",
  (string) (len=10) "10.0.0.254": (string) (len=49) "kube-system/clustermesh-apiserver-84bc65c54-kmw2v",
  (string) (len=8) "10.0.0.5": (string) (len=6) "router"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.188.219": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001c233f0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001c19aa0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001c19aa0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x40018a78c0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x40018a7970)(frontends:[10.100.153.210]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x40018a7ad0)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x40039fa840)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40039fa8f0)(frontends:[10.100.110.196]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x400159bc80)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4002ca7040)(172.31.189.233:443/TCP,172.31.192.87:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x400159bc90)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-dnj48": (*k8s.Endpoints)(0x4001e59ba0)(172.31.188.219:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x400159bc98)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-rcmpw": (*k8s.Endpoints)(0x4003146750)(10.0.0.110:53/TCP[eu-west-3a],10.0.0.110:53/UDP[eu-west-3a],10.0.0.110:9153/TCP[eu-west-3a],10.0.0.134:53/TCP[eu-west-3a],10.0.0.134:53/UDP[eu-west-3a],10.0.0.134:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40014f6878)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-9jmkj": (*k8s.Endpoints)(0x40033a55f0)(10.0.0.254:2379/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x40000c5110)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40006a5c70)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4009308c00
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4000d360c0,
  gcExited: (chan struct {}) 0x4000d36120,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x400030d580)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000c45980)({
      MetricVec: (*prometheus.MetricVec)(0x4001284db0)({
       metricMap: (*prometheus.metricMap)(0x4001284de0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001090de0)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x400030d600)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000c45988)({
      MetricVec: (*prometheus.MetricVec)(0x4001284e40)({
       metricMap: (*prometheus.metricMap)(0x4001284ea0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001090e40)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x400030d680)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000c45990)({
      MetricVec: (*prometheus.MetricVec)(0x4001284f00)({
       metricMap: (*prometheus.metricMap)(0x4001284f30)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001090ea0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x400030d700)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000c45998)({
      MetricVec: (*prometheus.MetricVec)(0x4001284f90)({
       metricMap: (*prometheus.metricMap)(0x4001284fc0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001090f00)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x400030d780)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000c459a0)({
      MetricVec: (*prometheus.MetricVec)(0x4001285020)({
       metricMap: (*prometheus.metricMap)(0x4001285080)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001090f60)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x400030d800)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000c459a8)({
      MetricVec: (*prometheus.MetricVec)(0x40012850e0)({
       metricMap: (*prometheus.metricMap)(0x4001285110)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001090fc0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x400030d880)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000c459b0)({
      MetricVec: (*prometheus.MetricVec)(0x4001285170)({
       metricMap: (*prometheus.metricMap)(0x40012851a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001091020)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x400030d900)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000c459b8)({
      MetricVec: (*prometheus.MetricVec)(0x4001285230)({
       metricMap: (*prometheus.metricMap)(0x4001285260)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001091080)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x400030d980)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000c459c0)({
      MetricVec: (*prometheus.MetricVec)(0x40012852c0)({
       metricMap: (*prometheus.metricMap)(0x40012852f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40010910e0)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x40000c5110)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x400041c310)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001610ea0)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 426ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption



#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.0.0.0/24, 
Allocated addresses:
  10.0.0.110 (kube-system/coredns-cc6ccd49c-p8kfz)
  10.0.0.126 (health)
  10.0.0.134 (kube-system/coredns-cc6ccd49c-5c2kl)
  10.0.0.254 (kube-system/clustermesh-apiserver-84bc65c54-kmw2v)
  10.0.0.5 (router)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe98a5a3055bdf8a
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                               Last success   Last error   Count   Message
  cilium-health-ep                                                   33s ago        never        0       no error   
  ct-map-pressure                                                    5s ago         never        0       no error   
  daemon-validate-config                                             20s ago        never        0       no error   
  dns-garbage-collector-job                                          39s ago        never        0       no error   
  endpoint-1707-regeneration-recovery                                never          never        0       no error   
  endpoint-2876-regeneration-recovery                                never          never        0       no error   
  endpoint-3572-regeneration-recovery                                never          never        0       no error   
  endpoint-776-regeneration-recovery                                 never          never        0       no error   
  endpoint-786-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                        40s ago        never        0       no error   
  ep-bpf-prog-watchdog                                               5s ago         never        0       no error   
  ipcache-inject-labels                                              35s ago        never        0       no error   
  k8s-heartbeat                                                      21s ago        never        0       no error   
  link-cache                                                         5s ago         never        0       no error   
  local-identity-checkpoint                                          15m25s ago     never        0       no error   
  node-neighbor-link-updater                                         5s ago         never        0       no error   
  remote-etcd-cmesh10                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh100                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh101                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh102                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh103                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh104                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh105                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh106                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh107                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh108                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh109                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh11                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh110                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh111                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh112                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh113                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh114                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh115                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh116                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh117                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh118                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh119                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh12                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh120                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh121                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh122                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh123                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh124                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh125                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh126                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh127                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh128                                               7m45s ago      never        0       no error   
  remote-etcd-cmesh13                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh14                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh15                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh16                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh17                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh18                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh19                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh2                                                 7m45s ago      never        0       no error   
  remote-etcd-cmesh20                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh21                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh22                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh23                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh24                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh25                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh26                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh27                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh28                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh29                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh3                                                 7m45s ago      never        0       no error   
  remote-etcd-cmesh30                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh31                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh32                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh33                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh34                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh35                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh36                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh37                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh38                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh39                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh4                                                 7m45s ago      never        0       no error   
  remote-etcd-cmesh40                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh41                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh42                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh43                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh44                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh45                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh46                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh47                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh48                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh49                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh5                                                 7m45s ago      never        0       no error   
  remote-etcd-cmesh50                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh51                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh52                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh53                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh54                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh55                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh56                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh57                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh58                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh59                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh6                                                 7m45s ago      never        0       no error   
  remote-etcd-cmesh60                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh61                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh62                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh63                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh64                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh65                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh66                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh67                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh68                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh69                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh7                                                 7m45s ago      never        0       no error   
  remote-etcd-cmesh70                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh71                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh72                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh73                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh74                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh75                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh76                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh77                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh78                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh79                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh8                                                 7m45s ago      never        0       no error   
  remote-etcd-cmesh80                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh81                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh82                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh83                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh84                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh85                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh86                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh87                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh88                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh89                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh9                                                 7m45s ago      never        0       no error   
  remote-etcd-cmesh90                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh91                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh92                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh93                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh94                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh95                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh96                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh97                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh98                                                7m45s ago      never        0       no error   
  remote-etcd-cmesh99                                                7m45s ago      never        0       no error   
  resolve-identity-1707                                              35s ago        never        0       no error   
  resolve-identity-2876                                              35s ago        never        0       no error   
  resolve-identity-3572                                              34s ago        never        0       no error   
  resolve-identity-776                                               34s ago        never        0       no error   
  resolve-identity-786                                               3m18s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-84bc65c54-kmw2v   8m18s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-5c2kl                 15m35s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-p8kfz                 15m34s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                     15m35s ago     never        0       no error   
  sync-policymap-1707                                                34s ago        never        0       no error   
  sync-policymap-2876                                                32s ago        never        0       no error   
  sync-policymap-3572                                                28s ago        never        0       no error   
  sync-policymap-776                                                 28s ago        never        0       no error   
  sync-policymap-786                                                 8m18s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (2876)                                  14s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (3572)                                  14s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (786)                                   8s ago         never        0       no error   
  sync-utime                                                         35s ago        never        0       no error   
  write-cni-file                                                     15m40s ago     never        0       no error   
Proxy Status:            OK, ip 10.0.0.5, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 65536, max 131071
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 73.91   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.189.233:443 (active)    
                                          2 => 172.31.192.87:443 (active)     
2    10.100.153.210:443    ClusterIP      1 => 172.31.188.219:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.0.0.134:9153 (active)       
                                          2 => 10.0.0.110:9153 (active)       
4    10.100.0.10:53        ClusterIP      1 => 10.0.0.134:53 (active)         
                                          2 => 10.0.0.110:53 (active)         
5    10.100.110.196:2379   ClusterIP      1 => 10.0.0.254:2379 (active)       
```

#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 37774565                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 37774565                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 37774565                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400cc00000 rw-p 00000000 00:00 0 
400cc00000-4010000000 ---p 00000000 00:00 0 
ffff69f82000-ffff6a198000 rw-p 00000000 00:00 0 
ffff6a1a0000-ffff6a2c1000 rw-p 00000000 00:00 0 
ffff6a2c1000-ffff6a302000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff6a302000-ffff6a343000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff6a343000-ffff6a383000 rw-p 00000000 00:00 0 
ffff6a383000-ffff6a385000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff6a385000-ffff6a387000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff6a387000-ffff6a94e000 rw-p 00000000 00:00 0 
ffff6a94e000-ffff6aa4e000 rw-p 00000000 00:00 0 
ffff6aa4e000-ffff6aa5f000 rw-p 00000000 00:00 0 
ffff6aa5f000-ffff6ca5f000 rw-p 00000000 00:00 0 
ffff6ca5f000-ffff6cadf000 ---p 00000000 00:00 0 
ffff6cadf000-ffff6cae0000 rw-p 00000000 00:00 0 
ffff6cae0000-ffff8cadf000 ---p 00000000 00:00 0 
ffff8cadf000-ffff8cae0000 rw-p 00000000 00:00 0 
ffff8cae0000-ffffaca6f000 ---p 00000000 00:00 0 
ffffaca6f000-ffffaca70000 rw-p 00000000 00:00 0 
ffffaca70000-ffffb0a61000 ---p 00000000 00:00 0 
ffffb0a61000-ffffb0a62000 rw-p 00000000 00:00 0 
ffffb0a62000-ffffb125f000 ---p 00000000 00:00 0 
ffffb125f000-ffffb1260000 rw-p 00000000 00:00 0 
ffffb1260000-ffffb135f000 ---p 00000000 00:00 0 
ffffb135f000-ffffb13bf000 rw-p 00000000 00:00 0 
ffffb13bf000-ffffb13c1000 r--p 00000000 00:00 0                          [vvar]
ffffb13c1000-ffffb13c2000 r-xp 00000000 00:00 0                          [vdso]
ffffc0cbf000-ffffc0ce0000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```

