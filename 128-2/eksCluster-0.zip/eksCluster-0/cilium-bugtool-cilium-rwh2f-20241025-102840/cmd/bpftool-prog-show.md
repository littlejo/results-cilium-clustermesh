29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:41+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:41+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:41+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:41+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:41+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:12:41+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:12:42+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:12:42+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:12:42+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:42+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:12:46+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
55: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
58: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
59: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
62: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
66: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
69: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
70: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
73: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
97: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
100: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
452: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
455: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
456: sched_cls  name tail_handle_ipv4  tag f9d960ce627caa60  gpl
	loaded_at 2024-10-25T10:13:42+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,93
	btf_id 124
457: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:42+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,93
	btf_id 125
458: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:42+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
459: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 127
460: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
463: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
486: sched_cls  name __send_drop_notify  tag 03f926fdbcc8c3eb  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 154
487: sched_cls  name tail_ipv4_to_endpoint  tag 1f9189f9946d425d  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,102,33,74,75,72,83,31,101,32,29,30
	btf_id 155
488: sched_cls  name tail_ipv4_ct_ingress  tag 0ca365f643199988  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,101,74,75,102,76
	btf_id 156
489: sched_cls  name tail_ipv4_ct_egress  tag ba8baeea3f0bd782  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,101,74,75,102,76
	btf_id 157
490: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,101
	btf_id 158
491: sched_cls  name tail_handle_ipv4  tag d2613d66623bd451  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,101
	btf_id 159
492: sched_cls  name tail_handle_ipv4_cont  tag 8c816d71930586af  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,102,33,83,74,75,31,68,66,69,101,32,29,30,73
	btf_id 160
494: sched_cls  name handle_policy  tag 470131bbd293652b  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,101,74,75,102,33,72,83,31,76,67,32,29,30
	btf_id 162
495: sched_cls  name tail_handle_arp  tag 1ff877d08b29c31b  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,101
	btf_id 163
496: sched_cls  name cil_from_container  tag 979ee5d9c379e867  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 101,68
	btf_id 164
497: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
500: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
501: sched_cls  name handle_policy  tag 343e501f931c023a  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,104,74,75,103,33,72,95,31,76,67,32,29,30
	btf_id 166
503: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 168
504: sched_cls  name cil_from_container  tag 037ad76ce6be97f2  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 104,68
	btf_id 169
505: sched_cls  name tail_ipv4_ct_ingress  tag df98537cb6699c8b  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 170
506: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,104
	btf_id 171
507: sched_cls  name tail_ipv4_to_endpoint  tag 124936aa73b9d080  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,103,33,74,75,72,95,31,104,32,29,30
	btf_id 172
508: sched_cls  name tail_handle_ipv4_cont  tag 3c23a67d2ba21d15  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,103,33,95,74,75,31,68,66,69,104,32,29,30,73
	btf_id 173
509: sched_cls  name tail_handle_ipv4  tag e9b7ac0f05ef82e8  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,104
	btf_id 174
510: sched_cls  name tail_handle_arp  tag 5e69debf4a238e94  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,104
	btf_id 175
511: sched_cls  name __send_drop_notify  tag ee2105519ac84161  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 176
512: sched_cls  name tail_ipv4_ct_egress  tag ba8baeea3f0bd782  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,106,74,75,107,76
	btf_id 178
513: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,106
	btf_id 179
514: sched_cls  name __send_drop_notify  tag dfc2f9093e7efd67  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 180
515: sched_cls  name cil_from_container  tag 1ace36193cc65ec3  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 106,68
	btf_id 181
516: sched_cls  name tail_handle_ipv4  tag 56b48d822d8fb895  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,106
	btf_id 182
517: sched_cls  name handle_policy  tag 5a487c66c87dea17  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,106,74,75,107,33,72,94,31,76,67,32,29,30
	btf_id 183
518: sched_cls  name tail_handle_ipv4_cont  tag 1b41fbe2fb342eee  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,107,33,94,74,75,31,68,66,69,106,32,29,30,73
	btf_id 184
519: sched_cls  name tail_ipv4_ct_ingress  tag f7326fde455db559  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,106,74,75,107,76
	btf_id 185
520: sched_cls  name tail_ipv4_to_endpoint  tag f09390556f0167ab  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,107,33,74,75,72,94,31,106,32,29,30
	btf_id 186
521: sched_cls  name tail_handle_arp  tag 15c9906cf460a6b3  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,106
	btf_id 187
523: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
526: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
527: sched_cls  name tail_handle_ipv4_from_host  tag 16f67390e554f1bb  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,109
	btf_id 191
528: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,109
	btf_id 192
530: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,109
	btf_id 194
531: sched_cls  name __send_drop_notify  tag 0c6605123a8f4575  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 195
532: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 196
534: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,112
	btf_id 199
537: sched_cls  name __send_drop_notify  tag 0c6605123a8f4575  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 202
538: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 203
540: sched_cls  name tail_handle_ipv4_from_host  tag 16f67390e554f1bb  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,112
	btf_id 205
541: sched_cls  name __send_drop_notify  tag 0c6605123a8f4575  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 207
543: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,114,67
	btf_id 209
544: sched_cls  name tail_handle_ipv4_from_host  tag 16f67390e554f1bb  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,114
	btf_id 210
545: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:46+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,114
	btf_id 211
587: sched_cls  name tail_ipv4_ct_egress  tag c18cb400d3636e15  gpl
	loaded_at 2024-10-25T10:20:55+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,127,74,75,126,76
	btf_id 227
588: sched_cls  name __send_drop_notify  tag 3c9ab831c5101071  gpl
	loaded_at 2024-10-25T10:20:55+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 228
589: sched_cls  name tail_ipv4_to_endpoint  tag 5e6f49356db37b66  gpl
	loaded_at 2024-10-25T10:20:55+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,126,33,74,75,72,125,31,127,32,29,30
	btf_id 229
590: sched_cls  name tail_handle_ipv4  tag 8784fe401ae3b28c  gpl
	loaded_at 2024-10-25T10:20:55+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,127
	btf_id 230
591: sched_cls  name handle_policy  tag ef646eb10bc9c596  gpl
	loaded_at 2024-10-25T10:20:55+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,127,74,75,126,33,72,125,31,76,67,32,29,30
	btf_id 231
592: sched_cls  name cil_from_container  tag c45856f8dc6cd7ed  gpl
	loaded_at 2024-10-25T10:20:55+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 127,68
	btf_id 232
593: sched_cls  name tail_handle_ipv4_cont  tag 9e13d2a6041fa7c1  gpl
	loaded_at 2024-10-25T10:20:55+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,126,33,125,74,75,31,68,66,69,127,32,29,30,73
	btf_id 233
594: sched_cls  name tail_ipv4_ct_ingress  tag 591e89eb667074c8  gpl
	loaded_at 2024-10-25T10:20:55+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,127,74,75,126,76
	btf_id 234
595: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:20:55+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,127
	btf_id 235
596: sched_cls  name tail_handle_arp  tag 7dafd24147ebc93d  gpl
	loaded_at 2024-10-25T10:20:55+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,127
	btf_id 236
598: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:20:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
601: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:20:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
614: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:20:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
617: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:20:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
618: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:20:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
621: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:20:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
622: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:20:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
625: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:20:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
