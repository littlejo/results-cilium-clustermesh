Total: 552
TCP:   1302 (estab 302, closed 981, orphaned 0, timewait 525)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  321       310       11       
INET	  331       316       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.188.219%ens5:68         0.0.0.0:*    uid:192 ino:15757 sk:344 cgroup:unreachable:c4e <->                            
UNCONN 0      0                            127.0.0.1:39187      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:22745 sk:345 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:23900 sk:346 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15174 sk:347 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:23899 sk:348 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15175 sk:349 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::462:46ff:fe7c:5cd1]%ens5:546           [::]:*    uid:192 ino:15746 sk:34a cgroup:unreachable:c4e v6only:1 <->                   
