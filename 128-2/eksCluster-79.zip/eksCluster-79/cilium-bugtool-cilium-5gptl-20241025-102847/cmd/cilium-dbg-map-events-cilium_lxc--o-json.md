{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:06.704Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.210.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:06.704Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.217.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:06.704Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.688Z",
  "value": "id=391   sec_id=5268971 flags=0x0000 ifindex=14  mac=02:9B:46:4C:FB:FD nodemac=C6:85:D9:92:B6:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.693Z",
  "value": "id=1997  sec_id=5268971 flags=0x0000 ifindex=12  mac=46:7A:C5:46:8D:4F nodemac=12:CE:42:9B:82:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.764Z",
  "value": "id=1757  sec_id=4     flags=0x0000 ifindex=10  mac=32:04:F2:86:F9:5C nodemac=66:A8:AE:A1:6B:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.803Z",
  "value": "id=391   sec_id=5268971 flags=0x0000 ifindex=14  mac=02:9B:46:4C:FB:FD nodemac=C6:85:D9:92:B6:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.895Z",
  "value": "id=1997  sec_id=5268971 flags=0x0000 ifindex=12  mac=46:7A:C5:46:8D:4F nodemac=12:CE:42:9B:82:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:43.978Z",
  "value": "id=1997  sec_id=5268971 flags=0x0000 ifindex=12  mac=46:7A:C5:46:8D:4F nodemac=12:CE:42:9B:82:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:43.978Z",
  "value": "id=391   sec_id=5268971 flags=0x0000 ifindex=14  mac=02:9B:46:4C:FB:FD nodemac=C6:85:D9:92:B6:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:43.978Z",
  "value": "id=1757  sec_id=4     flags=0x0000 ifindex=10  mac=32:04:F2:86:F9:5C nodemac=66:A8:AE:A1:6B:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:44.012Z",
  "value": "id=2216  sec_id=5246949 flags=0x0000 ifindex=16  mac=3E:9A:2D:55:16:66 nodemac=3A:6E:68:15:47:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:44.012Z",
  "value": "id=2216  sec_id=5246949 flags=0x0000 ifindex=16  mac=3E:9A:2D:55:16:66 nodemac=3A:6E:68:15:47:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:44.978Z",
  "value": "id=1997  sec_id=5268971 flags=0x0000 ifindex=12  mac=46:7A:C5:46:8D:4F nodemac=12:CE:42:9B:82:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:44.978Z",
  "value": "id=2216  sec_id=5246949 flags=0x0000 ifindex=16  mac=3E:9A:2D:55:16:66 nodemac=3A:6E:68:15:47:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:44.978Z",
  "value": "id=1757  sec_id=4     flags=0x0000 ifindex=10  mac=32:04:F2:86:F9:5C nodemac=66:A8:AE:A1:6B:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:44.978Z",
  "value": "id=391   sec_id=5268971 flags=0x0000 ifindex=14  mac=02:9B:46:4C:FB:FD nodemac=C6:85:D9:92:B6:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:45.306Z",
  "value": "id=347   sec_id=5246949 flags=0x0000 ifindex=18  mac=1A:AB:04:CB:86:BC nodemac=CA:C8:92:20:55:CD"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.79.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:55.760Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.982Z",
  "value": "id=1757  sec_id=4     flags=0x0000 ifindex=10  mac=32:04:F2:86:F9:5C nodemac=66:A8:AE:A1:6B:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.983Z",
  "value": "id=347   sec_id=5246949 flags=0x0000 ifindex=18  mac=1A:AB:04:CB:86:BC nodemac=CA:C8:92:20:55:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.984Z",
  "value": "id=1997  sec_id=5268971 flags=0x0000 ifindex=12  mac=46:7A:C5:46:8D:4F nodemac=12:CE:42:9B:82:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.984Z",
  "value": "id=391   sec_id=5268971 flags=0x0000 ifindex=14  mac=02:9B:46:4C:FB:FD nodemac=C6:85:D9:92:B6:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:23.983Z",
  "value": "id=391   sec_id=5268971 flags=0x0000 ifindex=14  mac=02:9B:46:4C:FB:FD nodemac=C6:85:D9:92:B6:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:23.983Z",
  "value": "id=1997  sec_id=5268971 flags=0x0000 ifindex=12  mac=46:7A:C5:46:8D:4F nodemac=12:CE:42:9B:82:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:23.984Z",
  "value": "id=1757  sec_id=4     flags=0x0000 ifindex=10  mac=32:04:F2:86:F9:5C nodemac=66:A8:AE:A1:6B:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:23.984Z",
  "value": "id=347   sec_id=5246949 flags=0x0000 ifindex=18  mac=1A:AB:04:CB:86:BC nodemac=CA:C8:92:20:55:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:24.984Z",
  "value": "id=1757  sec_id=4     flags=0x0000 ifindex=10  mac=32:04:F2:86:F9:5C nodemac=66:A8:AE:A1:6B:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:24.985Z",
  "value": "id=1997  sec_id=5268971 flags=0x0000 ifindex=12  mac=46:7A:C5:46:8D:4F nodemac=12:CE:42:9B:82:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:24.985Z",
  "value": "id=347   sec_id=5246949 flags=0x0000 ifindex=18  mac=1A:AB:04:CB:86:BC nodemac=CA:C8:92:20:55:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.79.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:24.985Z",
  "value": "id=391   sec_id=5268971 flags=0x0000 ifindex=14  mac=02:9B:46:4C:FB:FD nodemac=C6:85:D9:92:B6:13"
}

