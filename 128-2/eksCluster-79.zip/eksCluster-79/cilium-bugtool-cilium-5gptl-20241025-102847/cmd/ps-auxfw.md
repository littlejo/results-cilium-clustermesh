USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         686  0.0  0.4 1240432 16064 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         708  0.0  0.0   6408  1640 ?        R    10:28   0:00  \_ ps auxfw
root         677  0.0  0.1 1228744 4040 ?        Ssl  10:28   0:00 /bin/gops stats 1
root         659  0.0  0.0 1228744 3596 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  2.9  7.0 1472496 275956 ?      Ssl  10:15   0:22 cilium-agent --config-dir=/tmp/cilium/config-map
root         412  0.0  0.1 1228848 5568 ?        Sl   10:16   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
