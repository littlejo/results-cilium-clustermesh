REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     212952    83969306   1132   bpf_host.c
Interface                 INGRESS     9510      743791     677    bpf_overlay.c
Success                   EGRESS      4405      337019     1694   bpf_host.c
Success                   EGRESS      88871     12093848   1308   bpf_lxc.c
Success                   EGRESS      9301      728696     53     encap.h
Success                   INGRESS     105622    12635084   235    trace.h
Success                   INGRESS     99995     12193804   86     l3.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
