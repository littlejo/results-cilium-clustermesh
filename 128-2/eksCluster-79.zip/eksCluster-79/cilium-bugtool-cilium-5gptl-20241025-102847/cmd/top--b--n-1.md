top - 10:28:49 up 14 min,  0 users,  load average: 0.11, 0.19, 0.17
Tasks:   9 total,   2 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 60.0 us, 26.7 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi, 13.3 si,  0.0 st
MiB Mem :   3836.2 total,    775.6 free,    917.9 used,   2142.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2749.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    731 root      20   0 1244340  21612  13888 S  46.7   0.6   0:00.10 hubble
      1 root      20   0 1472496 275956  77436 S   6.7   7.0   0:22.84 cilium-+
    686 root      20   0 1240432  16376  11292 S   6.7   0.4   0:00.03 cilium-+
    412 root      20   0 1228848   5568   2928 S   0.0   0.1   0:00.28 cilium-+
    659 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    677 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    724 root      20   0    2208    788    708 S   0.0   0.0   0:00.00 timeout
    741 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    764 root      20   0    3728    472    420 R   0.0   0.0   0:00.00 bash
