markdown output at /tmp/cilium-bugtool-20241025-102849.592+0000-UTC-2202584255/cmd/cilium-debuginfo-20241025-102919.813+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102849.592+0000-UTC-2202584255/cmd/cilium-debuginfo-20241025-102919.813+0000-UTC.json
