IP ADDRESS         LOCAL ENDPOINT INFO
172.31.210.205:0   (localhost)                                                                                        
10.79.0.164:0      (localhost)                                                                                        
10.79.0.57:0       id=391   sec_id=5268971 flags=0x0000 ifindex=14  mac=02:9B:46:4C:FB:FD nodemac=C6:85:D9:92:B6:13   
10.79.0.183:0      id=1757  sec_id=4     flags=0x0000 ifindex=10  mac=32:04:F2:86:F9:5C nodemac=66:A8:AE:A1:6B:5F     
10.79.0.102:0      id=347   sec_id=5246949 flags=0x0000 ifindex=18  mac=1A:AB:04:CB:86:BC nodemac=CA:C8:92:20:55:CD   
10.79.0.222:0      id=1997  sec_id=5268971 flags=0x0000 ifindex=12  mac=46:7A:C5:46:8D:4F nodemac=12:CE:42:9B:82:F2   
172.31.217.236:0   (localhost)                                                                                        
