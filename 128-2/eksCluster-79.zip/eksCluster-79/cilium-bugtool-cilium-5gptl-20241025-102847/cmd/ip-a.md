1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:e1:34:00:e9:9d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.217.236/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2749sec preferred_lft 2749sec
    inet6 fe80::8e1:34ff:fe00:e99d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:5d:9d:2f:c4:e9 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.210.205/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::85d:9dff:fe2f:c4e9/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:e4:68:db:40:d0 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4ce4:68ff:fedb:40d0/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:2c:a7:f1:22:37 brd ff:ff:ff:ff:ff:ff
    inet 10.79.0.164/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::542c:a7ff:fef1:2237/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 6a:80:0e:7a:37:c0 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6880:eff:fe7a:37c0/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:a8:ae:a1:6b:5f brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::64a8:aeff:fea1:6b5f/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc40c8532abcc6@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:ce:42:9b:82:f2 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::10ce:42ff:fe9b:82f2/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc3e4e9eb5ccf1@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:85:d9:92:b6:13 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::c485:d9ff:fe92:b613/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc6beb035680e8@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:c8:92:20:55:cd brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c8c8:92ff:fe20:55cd/64 scope link 
       valid_lft forever preferred_lft forever
