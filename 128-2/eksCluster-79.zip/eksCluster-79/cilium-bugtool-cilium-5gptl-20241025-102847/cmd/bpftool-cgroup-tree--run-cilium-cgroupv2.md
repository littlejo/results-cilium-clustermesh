CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podae77c20a_9ea6_4542_9272_57f7fbcc8d09.slice/cri-containerd-b57c1bdac1a81ccd07f57777515d2ce12549f6fc2f40d921ab37929cd6bc5085.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podae77c20a_9ea6_4542_9272_57f7fbcc8d09.slice/cri-containerd-7e30f05f6847e39dc7e22e8f1813d22137c6829e108ce1af60564615ea61c84a.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03863163_929f_4b35_ba08_21fe90161954.slice/cri-containerd-cdd658530212b9df16bf04bb848fe2cc0b4e8a29325a5ab800958c8221a55bfe.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03863163_929f_4b35_ba08_21fe90161954.slice/cri-containerd-f5f3743ee18266aa60443e7a50a6a04fdb99d6d78e5ef9df6bc6544bb28a423e.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podab577c88_5090_4ec2_9203_195dc87a3634.slice/cri-containerd-745e988769bdade7b817cd63722c1d419711b7615b022c9530a7684e06394af2.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podab577c88_5090_4ec2_9203_195dc87a3634.slice/cri-containerd-ba4a03273ea95b2ed1f1dcf9405f590aa9bbfccfe4187713dfccf22d2fd8fd42.scope
    540      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ba74517_9ebd_46f0_b9ef_134e4e5e5076.slice/cri-containerd-0fd07b23b91ae168e0c2dc8429cad2cafbd1fe717b87410442434b9bbb57fcd4.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ba74517_9ebd_46f0_b9ef_134e4e5e5076.slice/cri-containerd-480b61d689b92c66801750b43aecdb4ecf515f6e7b1f278f51e2970459105784.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95e0cc1d_4e73_4f47_8239_a53c52107a28.slice/cri-containerd-887230fd319bc3fdbb894a80330e9411288bb62e188ca0764dda2771038b82f7.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95e0cc1d_4e73_4f47_8239_a53c52107a28.slice/cri-containerd-933b33e4cf1d78aed17ef69dcd64d3dfd70a4492af4e9236f4fac2e58eb71238.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8f165be8_bc4f_4376_a3cb_38ddc1a5066d.slice/cri-containerd-94caee8857c612f3e531f2badbc5a1f81ce493bbc4626c3413b29772fce27c92.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8f165be8_bc4f_4376_a3cb_38ddc1a5066d.slice/cri-containerd-fee04846d2a150be4ac191259ff903110378a8e52d61dd927f23cd5647d5000e.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc2ed03a_287b_417c_9fe3_1e187c360a6f.slice/cri-containerd-dec84b9dd9de3536d2dd11655c58bb2a0c9ec86cc613973f306f1f997c5daa49.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc2ed03a_287b_417c_9fe3_1e187c360a6f.slice/cri-containerd-bb5776a4c32425c8bd032cec805763bad6b3e4e5599db9d5f2a7a5549481496c.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc2ed03a_287b_417c_9fe3_1e187c360a6f.slice/cri-containerd-6f2454fbc21e2ea74e83ed4db8695138351c3d667b7645f73cc56198e02974be.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc2ed03a_287b_417c_9fe3_1e187c360a6f.slice/cri-containerd-a9ec3e204c65445a5abb6954a13f97b6f633ebcbf9b0316cea471a747fd2fcb9.scope
    657      cgroup_device   multi                                          
