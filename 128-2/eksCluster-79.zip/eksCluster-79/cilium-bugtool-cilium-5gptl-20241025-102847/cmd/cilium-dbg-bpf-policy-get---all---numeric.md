Endpoint ID: 287
Path: /sys/fs/bpf/tc/globals/cilium_policy_00287

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 347
Path: /sys/fs/bpf/tc/globals/cilium_policy_00347

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3923027   36344     0        
Allow    Ingress     1          ANY          NONE         disabled    2933914   29459     0        
Allow    Egress      0          ANY          NONE         disabled    4006258   37401     0        


Endpoint ID: 391
Path: /sys/fs/bpf/tc/globals/cilium_policy_00391

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    74185   854       0        
Allow    Egress      0          ANY          NONE         disabled    12645   130       0        


Endpoint ID: 1757
Path: /sys/fs/bpf/tc/globals/cilium_policy_01757

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    442890   5647      0        
Allow    Ingress     1          ANY          NONE         disabled    11118    129       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1997
Path: /sys/fs/bpf/tc/globals/cilium_policy_01997

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    74668   859       0        
Allow    Egress      0          ANY          NONE         disabled    13453   140       0        


