key: 5b 01 00 00  value: 73 02 00 00
key: 87 01 00 00  value: 0d 02 00 00
key: dd 06 00 00  value: 03 02 00 00
key: cd 07 00 00  value: 1e 02 00 00
Found 4 elements
