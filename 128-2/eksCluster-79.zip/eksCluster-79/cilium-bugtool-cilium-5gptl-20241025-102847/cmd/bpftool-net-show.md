xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 574
ens6(5) clsact/ingress cil_from_netdev-ens6 id 579
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 568
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 560
cilium_host(7) clsact/egress cil_from_host-cilium_host id 558
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 482
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 483
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 517
lxc40c8532abcc6(12) clsact/ingress cil_from_container-lxc40c8532abcc6 id 530
lxc3e4e9eb5ccf1(14) clsact/ingress cil_from_container-lxc3e4e9eb5ccf1 id 527
lxc6beb035680e8(18) clsact/ingress cil_from_container-lxc6beb035680e8 id 628

flow_dissector:

netfilter:

