[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podab577c88_5090_4ec2_9203_195dc87a3634.slice/cri-containerd-745e988769bdade7b817cd63722c1d419711b7615b022c9530a7684e06394af2.scope"
      }
    ],
    "ips": [
      "10.79.0.57"
    ],
    "name": "coredns-cc6ccd49c-chhqn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ba74517_9ebd_46f0_b9ef_134e4e5e5076.slice/cri-containerd-480b61d689b92c66801750b43aecdb4ecf515f6e7b1f278f51e2970459105784.scope"
      }
    ],
    "ips": [
      "10.79.0.222"
    ],
    "name": "coredns-cc6ccd49c-dss99",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc2ed03a_287b_417c_9fe3_1e187c360a6f.slice/cri-containerd-a9ec3e204c65445a5abb6954a13f97b6f633ebcbf9b0316cea471a747fd2fcb9.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc2ed03a_287b_417c_9fe3_1e187c360a6f.slice/cri-containerd-6f2454fbc21e2ea74e83ed4db8695138351c3d667b7645f73cc56198e02974be.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc2ed03a_287b_417c_9fe3_1e187c360a6f.slice/cri-containerd-bb5776a4c32425c8bd032cec805763bad6b3e4e5599db9d5f2a7a5549481496c.scope"
      }
    ],
    "ips": [
      "10.79.0.102"
    ],
    "name": "clustermesh-apiserver-7596bf47f9-z8kvz",
    "namespace": "kube-system"
  }
]

