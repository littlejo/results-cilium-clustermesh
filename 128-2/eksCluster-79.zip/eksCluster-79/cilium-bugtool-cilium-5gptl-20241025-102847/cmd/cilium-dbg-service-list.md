ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.222.10:443 (active)     
                                         2 => 172.31.147.16:443 (active)     
2    10.100.169.138:443   ClusterIP      1 => 172.31.217.236:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.79.0.57:53 (active)         
                                         2 => 10.79.0.222:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.79.0.57:9153 (active)       
                                         2 => 10.79.0.222:9153 (active)      
5    10.100.117.67:2379   ClusterIP      1 => 10.79.0.102:2379 (active)      
