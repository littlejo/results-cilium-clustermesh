alloc: 78.00MB (81791568 bytes)
total-alloc: 1.33GB (1422894056 bytes)
sys: 202.32MB (212146500 bytes)
lookups: 0
mallocs: 47558133
frees: 47019159
heap-alloc: 78.00MB (81791568 bytes)
heap-sys: 158.98MB (166699008 bytes)
heap-idle: 39.87MB (41803776 bytes)
heap-in-use: 119.11MB (124895232 bytes)
heap-released: 1.94MB (2031616 bytes)
heap-objects: 538974
stack-in-use: 33.00MB (34603008 bytes)
stack-sys: 33.00MB (34603008 bytes)
stack-mspan-inuse: 1.90MB (1987520 bytes)
stack-mspan-sys: 2.44MB (2562240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 970.26KB (993545 bytes)
gc-sys: 5.03MB (5276672 bytes)
next-gc: when heap-alloc >= 145.64MB (152715752 bytes)
last-gc: 2024-10-25 10:29:12.333562407 +0000 UTC
gc-pause-total: 7.526152ms
gc-pause: 62212
gc-pause-end: 1729852152333562407
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.00033596390732845623
enable-gc: true
debug-gc: false
