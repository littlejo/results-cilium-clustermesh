Node 0, zone      DMA      1     24      3      1      2      0      5      3      6      2    166 
Node 0, zone   Normal    149     22      1     24     21      8      2      3      2      5      6 
