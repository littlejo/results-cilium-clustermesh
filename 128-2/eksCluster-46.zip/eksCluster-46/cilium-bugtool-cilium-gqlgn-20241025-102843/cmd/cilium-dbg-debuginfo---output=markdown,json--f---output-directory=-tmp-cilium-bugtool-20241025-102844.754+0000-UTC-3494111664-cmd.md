markdown output at /tmp/cilium-bugtool-20241025-102844.754+0000-UTC-3494111664/cmd/cilium-debuginfo-20241025-102915.285+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102844.754+0000-UTC-3494111664/cmd/cilium-debuginfo-20241025-102915.285+0000-UTC.json
