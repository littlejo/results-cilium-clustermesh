[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod83202a13_dc2b_4b3f_9cbc_9a7be3a28e3a.slice/cri-containerd-34240947921801877b22f1c39ae2e36fcb721ef9ac298bbf9f8d3d503e1100f4.scope"
      }
    ],
    "ips": [
      "10.46.0.114"
    ],
    "name": "coredns-cc6ccd49c-4h98l",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb179dea1_4b36_41fb_9e3f_c67a62436640.slice/cri-containerd-4d23a799be01cf0a5919fdcf5e9cf3344028a674712b047182777fcfa7ef2553.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb179dea1_4b36_41fb_9e3f_c67a62436640.slice/cri-containerd-5ba9f918bfc27bcd90298cf0e8d69bb42f8e857f7828e929c0957a332be73ce1.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb179dea1_4b36_41fb_9e3f_c67a62436640.slice/cri-containerd-5d6e3cec986131fca34e9088fa92a79d14ae26ef2e1c3e9e50d41773ca47300b.scope"
      }
    ],
    "ips": [
      "10.46.0.37"
    ],
    "name": "clustermesh-apiserver-56b8f55d54-kl5zp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod959dedae_55e8_4ba0_8abe_3c7dc21a0df0.slice/cri-containerd-e333226653b9b44b550265adad9284ed36562211aee54b2cb4f6e3876c7ebe51.scope"
      }
    ],
    "ips": [
      "10.46.0.78"
    ],
    "name": "coredns-cc6ccd49c-2dgkz",
    "namespace": "kube-system"
  }
]

