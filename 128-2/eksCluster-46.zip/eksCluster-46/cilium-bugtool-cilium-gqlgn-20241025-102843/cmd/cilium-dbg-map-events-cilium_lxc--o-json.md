{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:42.056Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.188.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:42.056Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.190.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:42.056Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.761Z",
  "value": "id=3404  sec_id=3082991 flags=0x0000 ifindex=12  mac=B6:28:32:87:49:60 nodemac=0A:EC:AE:42:5C:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.761Z",
  "value": "id=406   sec_id=4     flags=0x0000 ifindex=10  mac=86:42:EB:71:DE:02 nodemac=66:86:E8:0B:92:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.809Z",
  "value": "id=2815  sec_id=3082991 flags=0x0000 ifindex=14  mac=4A:AC:96:17:6E:48 nodemac=BA:C1:38:8B:7B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.850Z",
  "value": "id=406   sec_id=4     flags=0x0000 ifindex=10  mac=86:42:EB:71:DE:02 nodemac=66:86:E8:0B:92:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:58.085Z",
  "value": "id=406   sec_id=4     flags=0x0000 ifindex=10  mac=86:42:EB:71:DE:02 nodemac=66:86:E8:0B:92:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:58.086Z",
  "value": "id=3404  sec_id=3082991 flags=0x0000 ifindex=12  mac=B6:28:32:87:49:60 nodemac=0A:EC:AE:42:5C:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:58.086Z",
  "value": "id=2815  sec_id=3082991 flags=0x0000 ifindex=14  mac=4A:AC:96:17:6E:48 nodemac=BA:C1:38:8B:7B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:58.117Z",
  "value": "id=866   sec_id=3083710 flags=0x0000 ifindex=16  mac=2E:7F:A4:EC:8E:B2 nodemac=3A:3F:14:8D:4C:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:59.086Z",
  "value": "id=406   sec_id=4     flags=0x0000 ifindex=10  mac=86:42:EB:71:DE:02 nodemac=66:86:E8:0B:92:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:59.086Z",
  "value": "id=866   sec_id=3083710 flags=0x0000 ifindex=16  mac=2E:7F:A4:EC:8E:B2 nodemac=3A:3F:14:8D:4C:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:59.086Z",
  "value": "id=3404  sec_id=3082991 flags=0x0000 ifindex=12  mac=B6:28:32:87:49:60 nodemac=0A:EC:AE:42:5C:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:59.087Z",
  "value": "id=2815  sec_id=3082991 flags=0x0000 ifindex=14  mac=4A:AC:96:17:6E:48 nodemac=BA:C1:38:8B:7B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:58.421Z",
  "value": "id=1084  sec_id=3083710 flags=0x0000 ifindex=18  mac=EA:38:31:51:99:63 nodemac=0E:50:A5:FB:90:28"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.46.0.82:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:04.720Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:05.248Z",
  "value": "id=2815  sec_id=3082991 flags=0x0000 ifindex=14  mac=4A:AC:96:17:6E:48 nodemac=BA:C1:38:8B:7B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:05.248Z",
  "value": "id=1084  sec_id=3083710 flags=0x0000 ifindex=18  mac=EA:38:31:51:99:63 nodemac=0E:50:A5:FB:90:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:05.249Z",
  "value": "id=406   sec_id=4     flags=0x0000 ifindex=10  mac=86:42:EB:71:DE:02 nodemac=66:86:E8:0B:92:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:05.250Z",
  "value": "id=3404  sec_id=3082991 flags=0x0000 ifindex=12  mac=B6:28:32:87:49:60 nodemac=0A:EC:AE:42:5C:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:06.247Z",
  "value": "id=2815  sec_id=3082991 flags=0x0000 ifindex=14  mac=4A:AC:96:17:6E:48 nodemac=BA:C1:38:8B:7B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:06.248Z",
  "value": "id=1084  sec_id=3083710 flags=0x0000 ifindex=18  mac=EA:38:31:51:99:63 nodemac=0E:50:A5:FB:90:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:06.248Z",
  "value": "id=406   sec_id=4     flags=0x0000 ifindex=10  mac=86:42:EB:71:DE:02 nodemac=66:86:E8:0B:92:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:06.249Z",
  "value": "id=3404  sec_id=3082991 flags=0x0000 ifindex=12  mac=B6:28:32:87:49:60 nodemac=0A:EC:AE:42:5C:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.247Z",
  "value": "id=406   sec_id=4     flags=0x0000 ifindex=10  mac=86:42:EB:71:DE:02 nodemac=66:86:E8:0B:92:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.247Z",
  "value": "id=1084  sec_id=3083710 flags=0x0000 ifindex=18  mac=EA:38:31:51:99:63 nodemac=0E:50:A5:FB:90:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.247Z",
  "value": "id=3404  sec_id=3082991 flags=0x0000 ifindex=12  mac=B6:28:32:87:49:60 nodemac=0A:EC:AE:42:5C:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.248Z",
  "value": "id=2815  sec_id=3082991 flags=0x0000 ifindex=14  mac=4A:AC:96:17:6E:48 nodemac=BA:C1:38:8B:7B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:08.248Z",
  "value": "id=2815  sec_id=3082991 flags=0x0000 ifindex=14  mac=4A:AC:96:17:6E:48 nodemac=BA:C1:38:8B:7B:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:08.248Z",
  "value": "id=1084  sec_id=3083710 flags=0x0000 ifindex=18  mac=EA:38:31:51:99:63 nodemac=0E:50:A5:FB:90:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:08.248Z",
  "value": "id=406   sec_id=4     flags=0x0000 ifindex=10  mac=86:42:EB:71:DE:02 nodemac=66:86:E8:0B:92:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:08.248Z",
  "value": "id=3404  sec_id=3082991 flags=0x0000 ifindex=12  mac=B6:28:32:87:49:60 nodemac=0A:EC:AE:42:5C:64"
}

