key: 96 01 00 00  value: 44 02 00 00
key: 3c 04 00 00  value: 80 02 00 00
key: ff 0a 00 00  value: 32 02 00 00
key: 4c 0d 00 00  value: 06 02 00 00
Found 4 elements
