REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10098     791685     677    bpf_overlay.c
Interface                 INGRESS     227730    86023302   1132   bpf_host.c
Success                   EGRESS      100495    13405767   1308   bpf_lxc.c
Success                   EGRESS      10337     808633     53     encap.h
Success                   EGRESS      5242      403407     1694   bpf_host.c
Success                   INGRESS     111954    13821158   86     l3.h
Success                   INGRESS     117459    14253342   235    trace.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
