USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         693  0.0  0.1 1229000 4052 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         683  0.0  0.3 1240432 15244 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         708  0.0  0.0   6408  1636 ?        R    10:28   0:00  \_ ps auxfw
root         710  0.0  0.0   2020   400 ?        R    10:28   0:00  \_ bash -c ip a
root         666  0.0  0.1 1228744 4040 ?        Ssl  10:28   0:00 /bin/gops stats 1
root         655  0.0  0.1 1228744 4044 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  3.5  7.3 1538356 288584 ?      Ssl  10:16   0:25 cilium-agent --config-dir=/tmp/cilium/config-map
root         400  0.0  0.1 1228848 5776 ?        Sl   10:16   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
