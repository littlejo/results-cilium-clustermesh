Endpoint ID: 406
Path: /sys/fs/bpf/tc/globals/cilium_policy_00406

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    433400   5522      0        
Allow    Ingress     1          ANY          NONE         disabled    10600    124       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1084
Path: /sys/fs/bpf/tc/globals/cilium_policy_01084

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3893676   36814     0        
Allow    Ingress     1          ANY          NONE         disabled    3743889   36533     0        
Allow    Egress      0          ANY          NONE         disabled    4727040   43668     0        


Endpoint ID: 1580
Path: /sys/fs/bpf/tc/globals/cilium_policy_01580

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2815
Path: /sys/fs/bpf/tc/globals/cilium_policy_02815

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    70560   811       0        
Allow    Egress      0          ANY          NONE         disabled    13191   135       0        


Endpoint ID: 3404
Path: /sys/fs/bpf/tc/globals/cilium_policy_03404

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    71009   820       0        
Allow    Egress      0          ANY          NONE         disabled    12854   131       0        


