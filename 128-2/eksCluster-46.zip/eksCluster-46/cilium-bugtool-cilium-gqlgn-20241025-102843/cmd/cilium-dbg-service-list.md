ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.244.109:443 (active)    
                                         2 => 172.31.139.253:443 (active)    
2    10.100.157.118:443   ClusterIP      1 => 172.31.190.180:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.46.0.78:53 (active)         
                                         2 => 10.46.0.114:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.46.0.78:9153 (active)       
                                         2 => 10.46.0.114:9153 (active)      
5    10.100.44.207:2379   ClusterIP      1 => 10.46.0.37:2379 (active)       
