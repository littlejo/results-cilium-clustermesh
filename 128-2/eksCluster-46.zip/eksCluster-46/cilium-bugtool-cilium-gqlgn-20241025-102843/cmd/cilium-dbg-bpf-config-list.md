KEY             VALUE
AgentLiveness   850619667283
UTimeOffset     3378615830078125
