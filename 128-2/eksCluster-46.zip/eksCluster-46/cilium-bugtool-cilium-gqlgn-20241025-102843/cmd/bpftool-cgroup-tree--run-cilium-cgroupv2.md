CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb22905ff_0ff0_4feb_bfb3_09db509664b2.slice/cri-containerd-afa98bc17148666743bfb7e4ed68455509b76d4757dc2c5bbd238ec9b3de6757.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb22905ff_0ff0_4feb_bfb3_09db509664b2.slice/cri-containerd-9c93b50f5bc2926b95de544016692b09ed05c89f00368882505ad08d19fd6de8.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod959dedae_55e8_4ba0_8abe_3c7dc21a0df0.slice/cri-containerd-486f6c961a6b7fd811256ca2177d7ff6f0c8b4cd513dce11be4c6dca4f67d245.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod959dedae_55e8_4ba0_8abe_3c7dc21a0df0.slice/cri-containerd-e333226653b9b44b550265adad9284ed36562211aee54b2cb4f6e3876c7ebe51.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6f8b6594_0f06_45e3_aec3_4d77f988d2b8.slice/cri-containerd-3a75727b986cb6f66e8094a4f5d36aa6b3f84d5955722b4a0ba09c55b626ee7f.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6f8b6594_0f06_45e3_aec3_4d77f988d2b8.slice/cri-containerd-78f0f0a7b756fb95d67c2c6213db4a12bde0eab408ab72057e9f2180aa9c09d0.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod83202a13_dc2b_4b3f_9cbc_9a7be3a28e3a.slice/cri-containerd-ed2a48d3098eb96bc54572ebffd8d46d2fc8036040a827b43e167a627d1968a9.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod83202a13_dc2b_4b3f_9cbc_9a7be3a28e3a.slice/cri-containerd-34240947921801877b22f1c39ae2e36fcb721ef9ac298bbf9f8d3d503e1100f4.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod68fb4268_a72d_4af9_a3df_0f419551aa92.slice/cri-containerd-e6d8233cbb7e5eb3bc5701de7300ca91468028a14fc98ffb8eaceb3ed7265e74.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod68fb4268_a72d_4af9_a3df_0f419551aa92.slice/cri-containerd-273a3e60b6675d2201792f4c5a3a35790236e5fdbd78b8be9301f722c9f4cc68.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb179dea1_4b36_41fb_9e3f_c67a62436640.slice/cri-containerd-5d6e3cec986131fca34e9088fa92a79d14ae26ef2e1c3e9e50d41773ca47300b.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb179dea1_4b36_41fb_9e3f_c67a62436640.slice/cri-containerd-eefa83b25eade44a479670a7823b97f3f20f916743369c724d7e71576876a8c5.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb179dea1_4b36_41fb_9e3f_c67a62436640.slice/cri-containerd-5ba9f918bfc27bcd90298cf0e8d69bb42f8e857f7828e929c0957a332be73ce1.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb179dea1_4b36_41fb_9e3f_c67a62436640.slice/cri-containerd-4d23a799be01cf0a5919fdcf5e9cf3344028a674712b047182777fcfa7ef2553.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcf0fa4cf_00d6_49b6_b653_7ac95a1157d3.slice/cri-containerd-63c9fb6aecbf1a5fae10805cd0705672fbf41e604313564994438882243166fe.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcf0fa4cf_00d6_49b6_b653_7ac95a1157d3.slice/cri-containerd-85f9292986c7aeda6d4b9f86e75d352d427c1f54c7e08960279f776886f2f3ed.scope
    94       cgroup_device   multi                                          
