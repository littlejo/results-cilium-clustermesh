alloc: 111.79MB (117218408 bytes)
total-alloc: 1.42GB (1521941400 bytes)
sys: 210.63MB (220865876 bytes)
lookups: 0
mallocs: 48946316
frees: 47773460
heap-alloc: 111.79MB (117218408 bytes)
heap-sys: 163.67MB (171622400 bytes)
heap-idle: 28.47MB (29851648 bytes)
heap-in-use: 135.20MB (141770752 bytes)
heap-released: 1.56MB (1638400 bytes)
heap-objects: 1172856
stack-in-use: 36.28MB (38043648 bytes)
stack-sys: 36.28MB (38043648 bytes)
stack-mspan-inuse: 2.21MB (2320320 bytes)
stack-mspan-sys: 2.58MB (2709120 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1007.34KB (1031513 bytes)
gc-sys: 5.17MB (5421312 bytes)
next-gc: when heap-alloc >= 147.29MB (154443048 bytes)
last-gc: 2024-10-25 10:28:46.041420219 +0000 UTC
gc-pause-total: 20.355233ms
gc-pause: 130627
gc-pause-end: 1729852126041420219
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.00041002275458378577
enable-gc: true
debug-gc: false
