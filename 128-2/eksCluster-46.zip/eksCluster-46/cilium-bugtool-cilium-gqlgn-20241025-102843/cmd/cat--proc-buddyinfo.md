Node 0, zone      DMA     23      2      2      2     12     11      5      2      3      3    163 
Node 0, zone   Normal    252      5     32     15     15      4      2      2      1      0      9 
