IP ADDRESS         LOCAL ENDPOINT INFO
10.46.0.246:0      id=406   sec_id=4     flags=0x0000 ifindex=10  mac=86:42:EB:71:DE:02 nodemac=66:86:E8:0B:92:1E     
10.46.0.170:0      (localhost)                                                                                        
172.31.190.180:0   (localhost)                                                                                        
10.46.0.37:0       id=1084  sec_id=3083710 flags=0x0000 ifindex=18  mac=EA:38:31:51:99:63 nodemac=0E:50:A5:FB:90:28   
172.31.188.25:0    (localhost)                                                                                        
10.46.0.114:0      id=2815  sec_id=3082991 flags=0x0000 ifindex=14  mac=4A:AC:96:17:6E:48 nodemac=BA:C1:38:8B:7B:76   
10.46.0.78:0       id=3404  sec_id=3082991 flags=0x0000 ifindex=12  mac=B6:28:32:87:49:60 nodemac=0A:EC:AE:42:5C:64   
