top - 10:28:44 up 13 min,  0 users,  load average: 0.21, 0.18, 0.15
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 13.8 us, 20.7 sy,  0.0 ni, 62.1 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   3836.2 total,    779.3 free,    914.9 used,   2142.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2752.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538356 288584  78576 S  13.3   7.3   0:25.81 cilium-+
    400 root      20   0 1228848   5776   2868 S   0.0   0.1   0:00.26 cilium-+
    655 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
    666 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    683 root      20   0 1240432  15244  10448 S   0.0   0.4   0:00.03 cilium-+
    693 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    719 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    738 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
