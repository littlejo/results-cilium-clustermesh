1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:71:1f:b7:6b:11 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.190.180/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2790sec preferred_lft 2790sec
    inet6 fe80::471:1fff:feb7:6b11/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d0:90:2a:11:2f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.188.25/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4d0:90ff:fe2a:112f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:0c:d4:1a:5c:66 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::800c:d4ff:fe1a:5c66/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:1d:ec:3a:30:da brd ff:ff:ff:ff:ff:ff
    inet 10.46.0.170/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::c01d:ecff:fe3a:30da/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 46:0c:7d:8c:69:0e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::440c:7dff:fe8c:690e/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:86:e8:0b:92:1e brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::6486:e8ff:fe0b:921e/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc65e9211480e0@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:ec:ae:42:5c:64 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::8ec:aeff:fe42:5c64/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc25a3cc2df23f@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:c1:38:8b:7b:76 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::b8c1:38ff:fe8b:7b76/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc68ab1860b6b0@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:50:a5:fb:90:28 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c50:a5ff:fefb:9028/64 scope link 
       valid_lft forever preferred_lft forever
