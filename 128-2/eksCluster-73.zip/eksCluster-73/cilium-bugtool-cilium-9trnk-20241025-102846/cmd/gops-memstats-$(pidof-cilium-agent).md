alloc: 128.60MB (134848880 bytes)
total-alloc: 1.35GB (1445342104 bytes)
sys: 218.38MB (228992340 bytes)
lookups: 0
mallocs: 48040098
frees: 46761017
heap-alloc: 128.60MB (134848880 bytes)
heap-sys: 173.20MB (181616640 bytes)
heap-idle: 25.82MB (27074560 bytes)
heap-in-use: 147.38MB (154542080 bytes)
heap-released: 3.88MB (4063232 bytes)
heap-objects: 1279081
stack-in-use: 34.75MB (36438016 bytes)
stack-sys: 34.75MB (36438016 bytes)
stack-mspan-inuse: 2.29MB (2403360 bytes)
stack-mspan-sys: 2.47MB (2594880 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 903.59KB (925281 bytes)
gc-sys: 5.15MB (5402808 bytes)
next-gc: when heap-alloc >= 152.89MB (160314600 bytes)
last-gc: 2024-10-25 10:28:48.862296311 +0000 UTC
gc-pause-total: 13.236144ms
gc-pause: 78491
gc-pause-end: 1729852128862296311
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.00035852611312691947
enable-gc: true
debug-gc: false
