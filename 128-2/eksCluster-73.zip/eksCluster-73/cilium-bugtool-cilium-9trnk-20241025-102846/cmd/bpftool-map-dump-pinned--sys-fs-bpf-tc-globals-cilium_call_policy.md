key: 1f 00 00 00  value: 15 02 00 00
key: 62 01 00 00  value: 34 02 00 00
key: 0a 02 00 00  value: 36 02 00 00
key: 74 0b 00 00  value: 86 02 00 00
Found 4 elements
