CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9da0470e_b2b1_4af1_94d3_01bff083715d.slice/cri-containerd-a44e6cc6b9884d5858080d8cffdec2899a29ddeebf0a9b667d09be1c732c9d5e.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9da0470e_b2b1_4af1_94d3_01bff083715d.slice/cri-containerd-8198b3c7cd75e2be869ba923d83bd1dc3fc162c70c23defb7202310c40658b1b.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeee519a2_5a5d_4e97_a674_d5203a632123.slice/cri-containerd-43ebbe31cd07076d0e4f561548ed69189deca25fa005ebb049e4980101549895.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeee519a2_5a5d_4e97_a674_d5203a632123.slice/cri-containerd-6e262b685faf412fdab67de4455dfd9eeb1cb8fb92b87cc5613fee37b0cb7511.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod86134e12_446c_46cc_b095_1d138465da33.slice/cri-containerd-efc675564d798d53caabf3bc5db5e5243b2448df1d4821ffe752001e051ffc08.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod86134e12_446c_46cc_b095_1d138465da33.slice/cri-containerd-6c036856aa6ec34bdf3b60bffcf6a82a7b43ec526ee1265a96b7eea47bcd45a7.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod28ef16fe_ee12_4e4b_94a6_1269d463cb26.slice/cri-containerd-4f47ad26cb53a39f80bbe53802ca7896a09921bb6160fb9e5f44e6d662f7f101.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod28ef16fe_ee12_4e4b_94a6_1269d463cb26.slice/cri-containerd-f184b12993881d21e90873d9d3b4263425a077f5959cc007b495d7824ae321ef.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod484da75b_207c_4e43_995b_f126d173956c.slice/cri-containerd-223b36e11877615f15918b46dbf5fd9aa5372ad65d0916bb175ba8efaffec416.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod484da75b_207c_4e43_995b_f126d173956c.slice/cri-containerd-d9e32492571d808acea65b964038827e8f8bff54a82d3d8b3a91ba8d1e95ede7.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod484da75b_207c_4e43_995b_f126d173956c.slice/cri-containerd-7f866fcd86d8513a565d5ff98e9d0883b59875e14afa42a98be2e939d27e7d7e.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod484da75b_207c_4e43_995b_f126d173956c.slice/cri-containerd-689d478f78a1ddb06a3b931aa8758f79d04c8af674346b67a07c86edfde2de18.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5d483e6_16ec_4d76_a236_280c5f701563.slice/cri-containerd-9acf119ea2266c640690b525aa6c5debb6fe83812446525f30faa4077346a8f0.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5d483e6_16ec_4d76_a236_280c5f701563.slice/cri-containerd-cce48424900f0ca0c8404ffd8147c5d1883b49908bd9e89b58ba87d93f9b26f8.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod475bddb5_783b_4ed8_8f06_bfaee8fe8b35.slice/cri-containerd-86211b11ed0300103fe45097066e59675499f4aab11d6dbad97db1bdc7771af3.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod475bddb5_783b_4ed8_8f06_bfaee8fe8b35.slice/cri-containerd-f7e4c4edb76d3479a7716dfb8005170b3004d86f44ced0b2630e111cb15f80e1.scope
    98       cgroup_device   multi                                          
