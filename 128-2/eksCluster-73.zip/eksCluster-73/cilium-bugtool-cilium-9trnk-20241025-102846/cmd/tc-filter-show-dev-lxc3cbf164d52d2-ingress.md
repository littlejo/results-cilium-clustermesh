filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc3cbf164d52d2 direct-action not_in_hw id 579 tag e354d45b096556fe jited 
