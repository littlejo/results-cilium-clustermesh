REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10062     789725     677    bpf_overlay.c
Interface                 INGRESS     221259    85335987   1132   bpf_host.c
Success                   EGRESS      10217     801273     53     encap.h
Success                   EGRESS      5132      395795     1694   bpf_host.c
Success                   EGRESS      94420     12446016   1308   bpf_lxc.c
Success                   INGRESS     104820    12942593   86     l3.h
Success                   INGRESS     110399    13380429   235    trace.h
Unsupported L3 protocol   EGRESS      37        2742       1492   bpf_lxc.c
