IP ADDRESS         LOCAL ENDPOINT INFO
10.73.0.60:0       id=2932  sec_id=4903555 flags=0x0000 ifindex=18  mac=3A:17:55:F2:B2:FC nodemac=AA:05:90:9E:E6:F4   
172.31.224.126:0   (localhost)                                                                                        
10.73.0.193:0      id=522   sec_id=4     flags=0x0000 ifindex=10  mac=12:46:27:18:8A:44 nodemac=0E:53:CE:EB:D0:96     
10.73.0.203:0      id=31    sec_id=4888610 flags=0x0000 ifindex=12  mac=2E:B1:DA:AE:B1:8F nodemac=7E:D8:E7:24:82:49   
10.73.0.59:0       id=354   sec_id=4888610 flags=0x0000 ifindex=14  mac=8A:CF:8F:7E:96:99 nodemac=C2:60:F7:0A:E4:BF   
172.31.213.46:0    (localhost)                                                                                        
10.73.0.43:0       (localhost)                                                                                        
