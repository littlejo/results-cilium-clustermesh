Endpoint ID: 31
Path: /sys/fs/bpf/tc/globals/cilium_policy_00031

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    74734   860       0        
Allow    Egress      0          ANY          NONE         disabled    13150   134       0        


Endpoint ID: 354
Path: /sys/fs/bpf/tc/globals/cilium_policy_00354

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    75175   869       0        
Allow    Egress      0          ANY          NONE         disabled    13571   139       0        


Endpoint ID: 522
Path: /sys/fs/bpf/tc/globals/cilium_policy_00522

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    439982   5607      0        
Allow    Ingress     1          ANY          NONE         disabled    11110    129       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2242
Path: /sys/fs/bpf/tc/globals/cilium_policy_02242

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2932
Path: /sys/fs/bpf/tc/globals/cilium_policy_02932

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3877025   36729     0        
Allow    Ingress     1          ANY          NONE         disabled    3181041   32185     0        
Allow    Egress      0          ANY          NONE         disabled    4959989   45797     0        


