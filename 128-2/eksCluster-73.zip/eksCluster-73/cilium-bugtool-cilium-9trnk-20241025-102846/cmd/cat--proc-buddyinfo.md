Node 0, zone      DMA      3      2      2      2     19      9     11      0      2      2    172 
Node 0, zone   Normal    470    100      2      8     26      9      3      1      1      3      7 
