ID   Frontend            Service Type   Backend                            
1    10.100.0.1:443      ClusterIP      1 => 172.31.192.82:443 (active)    
                                        2 => 172.31.161.197:443 (active)   
2    10.100.66.117:443   ClusterIP      1 => 172.31.213.46:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.73.0.203:53 (active)       
                                        2 => 10.73.0.59:53 (active)        
4    10.100.0.10:9153    ClusterIP      1 => 10.73.0.203:9153 (active)     
                                        2 => 10.73.0.59:9153 (active)      
5    10.100.197.9:2379   ClusterIP      1 => 10.73.0.60:2379 (active)      
