1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:a4:71:4f:a4:df brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.213.46/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2744sec preferred_lft 2744sec
    inet6 fe80::8a4:71ff:fe4f:a4df/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:75:f3:3c:b4:7b brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.224.126/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::875:f3ff:fe3c:b47b/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:8e:12:cf:71:36 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b48e:12ff:fecf:7136/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:f6:74:d6:fd:65 brd ff:ff:ff:ff:ff:ff
    inet 10.73.0.43/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::8cf6:74ff:fed6:fd65/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 42:02:46:e0:23:b7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4002:46ff:fee0:23b7/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:53:ce:eb:d0:96 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c53:ceff:feeb:d096/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcb8563455e4b7@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:d8:e7:24:82:49 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::7cd8:e7ff:fe24:8249/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc3cbf164d52d2@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:60:f7:0a:e4:bf brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::c060:f7ff:fe0a:e4bf/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf18b372b01a9@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:05:90:9e:e6:f4 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::a805:90ff:fe9e:e6f4/64 scope link 
       valid_lft forever preferred_lft forever
