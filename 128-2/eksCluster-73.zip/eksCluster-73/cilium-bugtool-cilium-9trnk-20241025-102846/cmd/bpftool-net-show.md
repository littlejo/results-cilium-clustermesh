xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 554
ens6(5) clsact/ingress cil_from_netdev-ens6 id 558
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 546
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 537
cilium_host(7) clsact/egress cil_from_host-cilium_host id 535
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 482
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 563
lxcb8563455e4b7(12) clsact/ingress cil_from_container-lxcb8563455e4b7 id 515
lxc3cbf164d52d2(14) clsact/ingress cil_from_container-lxc3cbf164d52d2 id 579
lxcf18b372b01a9(18) clsact/ingress cil_from_container-lxcf18b372b01a9 id 641

flow_dissector:

netfilter:

