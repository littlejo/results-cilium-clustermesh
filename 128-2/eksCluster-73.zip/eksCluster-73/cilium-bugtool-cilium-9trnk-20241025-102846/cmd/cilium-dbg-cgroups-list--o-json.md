[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeee519a2_5a5d_4e97_a674_d5203a632123.slice/cri-containerd-43ebbe31cd07076d0e4f561548ed69189deca25fa005ebb049e4980101549895.scope"
      }
    ],
    "ips": [
      "10.73.0.59"
    ],
    "name": "coredns-cc6ccd49c-8vfwr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod484da75b_207c_4e43_995b_f126d173956c.slice/cri-containerd-689d478f78a1ddb06a3b931aa8758f79d04c8af674346b67a07c86edfde2de18.scope"
      },
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod484da75b_207c_4e43_995b_f126d173956c.slice/cri-containerd-7f866fcd86d8513a565d5ff98e9d0883b59875e14afa42a98be2e939d27e7d7e.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod484da75b_207c_4e43_995b_f126d173956c.slice/cri-containerd-223b36e11877615f15918b46dbf5fd9aa5372ad65d0916bb175ba8efaffec416.scope"
      }
    ],
    "ips": [
      "10.73.0.60"
    ],
    "name": "clustermesh-apiserver-d8c4fdbdc-fgrjg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod28ef16fe_ee12_4e4b_94a6_1269d463cb26.slice/cri-containerd-4f47ad26cb53a39f80bbe53802ca7896a09921bb6160fb9e5f44e6d662f7f101.scope"
      }
    ],
    "ips": [
      "10.73.0.203"
    ],
    "name": "coredns-cc6ccd49c-6q2zn",
    "namespace": "kube-system"
  }
]

