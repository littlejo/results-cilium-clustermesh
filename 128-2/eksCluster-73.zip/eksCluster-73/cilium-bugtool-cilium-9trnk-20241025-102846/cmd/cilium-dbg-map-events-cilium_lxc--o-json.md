{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:07.146Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.213.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:07.146Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.224.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:07.146Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.572Z",
  "value": "id=522   sec_id=4     flags=0x0000 ifindex=10  mac=12:46:27:18:8A:44 nodemac=0E:53:CE:EB:D0:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.575Z",
  "value": "id=31    sec_id=4888610 flags=0x0000 ifindex=12  mac=2E:B1:DA:AE:B1:8F nodemac=7E:D8:E7:24:82:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.628Z",
  "value": "id=354   sec_id=4888610 flags=0x0000 ifindex=14  mac=8A:CF:8F:7E:96:99 nodemac=C2:60:F7:0A:E4:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:11.645Z",
  "value": "id=522   sec_id=4     flags=0x0000 ifindex=10  mac=12:46:27:18:8A:44 nodemac=0E:53:CE:EB:D0:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:45.205Z",
  "value": "id=522   sec_id=4     flags=0x0000 ifindex=10  mac=12:46:27:18:8A:44 nodemac=0E:53:CE:EB:D0:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:45.206Z",
  "value": "id=31    sec_id=4888610 flags=0x0000 ifindex=12  mac=2E:B1:DA:AE:B1:8F nodemac=7E:D8:E7:24:82:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:45.206Z",
  "value": "id=354   sec_id=4888610 flags=0x0000 ifindex=14  mac=8A:CF:8F:7E:96:99 nodemac=C2:60:F7:0A:E4:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:45.237Z",
  "value": "id=3730  sec_id=4903555 flags=0x0000 ifindex=16  mac=26:FE:7F:F5:A6:DE nodemac=A2:E0:88:E2:B0:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.205Z",
  "value": "id=3730  sec_id=4903555 flags=0x0000 ifindex=16  mac=26:FE:7F:F5:A6:DE nodemac=A2:E0:88:E2:B0:3E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.206Z",
  "value": "id=354   sec_id=4888610 flags=0x0000 ifindex=14  mac=8A:CF:8F:7E:96:99 nodemac=C2:60:F7:0A:E4:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.206Z",
  "value": "id=522   sec_id=4     flags=0x0000 ifindex=10  mac=12:46:27:18:8A:44 nodemac=0E:53:CE:EB:D0:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.206Z",
  "value": "id=31    sec_id=4888610 flags=0x0000 ifindex=12  mac=2E:B1:DA:AE:B1:8F nodemac=7E:D8:E7:24:82:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:45.086Z",
  "value": "id=2932  sec_id=4903555 flags=0x0000 ifindex=18  mac=3A:17:55:F2:B2:FC nodemac=AA:05:90:9E:E6:F4"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.73.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:50.702Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:43.107Z",
  "value": "id=31    sec_id=4888610 flags=0x0000 ifindex=12  mac=2E:B1:DA:AE:B1:8F nodemac=7E:D8:E7:24:82:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:43.108Z",
  "value": "id=354   sec_id=4888610 flags=0x0000 ifindex=14  mac=8A:CF:8F:7E:96:99 nodemac=C2:60:F7:0A:E4:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:43.108Z",
  "value": "id=2932  sec_id=4903555 flags=0x0000 ifindex=18  mac=3A:17:55:F2:B2:FC nodemac=AA:05:90:9E:E6:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:43.109Z",
  "value": "id=522   sec_id=4     flags=0x0000 ifindex=10  mac=12:46:27:18:8A:44 nodemac=0E:53:CE:EB:D0:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:44.099Z",
  "value": "id=31    sec_id=4888610 flags=0x0000 ifindex=12  mac=2E:B1:DA:AE:B1:8F nodemac=7E:D8:E7:24:82:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:44.099Z",
  "value": "id=2932  sec_id=4903555 flags=0x0000 ifindex=18  mac=3A:17:55:F2:B2:FC nodemac=AA:05:90:9E:E6:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:44.099Z",
  "value": "id=354   sec_id=4888610 flags=0x0000 ifindex=14  mac=8A:CF:8F:7E:96:99 nodemac=C2:60:F7:0A:E4:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:44.099Z",
  "value": "id=522   sec_id=4     flags=0x0000 ifindex=10  mac=12:46:27:18:8A:44 nodemac=0E:53:CE:EB:D0:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:45.100Z",
  "value": "id=2932  sec_id=4903555 flags=0x0000 ifindex=18  mac=3A:17:55:F2:B2:FC nodemac=AA:05:90:9E:E6:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:45.100Z",
  "value": "id=522   sec_id=4     flags=0x0000 ifindex=10  mac=12:46:27:18:8A:44 nodemac=0E:53:CE:EB:D0:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:45.100Z",
  "value": "id=31    sec_id=4888610 flags=0x0000 ifindex=12  mac=2E:B1:DA:AE:B1:8F nodemac=7E:D8:E7:24:82:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:45.101Z",
  "value": "id=354   sec_id=4888610 flags=0x0000 ifindex=14  mac=8A:CF:8F:7E:96:99 nodemac=C2:60:F7:0A:E4:BF"
}

