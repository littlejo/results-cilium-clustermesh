markdown output at /tmp/cilium-bugtool-20241025-102843.147+0000-UTC-84779248/cmd/cilium-debuginfo-20241025-102913.874+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102843.147+0000-UTC-84779248/cmd/cilium-debuginfo-20241025-102913.874+0000-UTC.json
