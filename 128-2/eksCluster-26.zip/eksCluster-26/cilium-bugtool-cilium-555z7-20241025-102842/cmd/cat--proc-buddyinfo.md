Node 0, zone      DMA     98     54     22     24     17     16      5      2      6      7    157 
Node 0, zone   Normal    464     30      9      0      3      2      1      2      0      3      8 
