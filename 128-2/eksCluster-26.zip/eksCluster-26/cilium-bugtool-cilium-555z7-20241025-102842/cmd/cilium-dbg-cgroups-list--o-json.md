[
  {
    "containers": [
      {
        "cgroup-id": 8706,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb66e904b_fedc_4448_a010_7ad1be4b5bda.slice/cri-containerd-31aec5e4d8c121e236821221f146ec3dd29c2de8dde66f14dc4113241a693668.scope"
      },
      {
        "cgroup-id": 8622,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb66e904b_fedc_4448_a010_7ad1be4b5bda.slice/cri-containerd-e0eb3ca97f2839a15708b9b7a9c5aabe13e2d783cc6c3ba3e9c931b2849d5a31.scope"
      },
      {
        "cgroup-id": 8790,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb66e904b_fedc_4448_a010_7ad1be4b5bda.slice/cri-containerd-5b3ff7a1732e973449485f3c710987936074379f134254f068b1041466c3c680.scope"
      }
    ],
    "ips": [
      "10.26.0.188"
    ],
    "name": "clustermesh-apiserver-599b667977-wzcx9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7194,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod45a287a5_8b62_4aa4_9e65_85a34737ccec.slice/cri-containerd-5c7987fe119109c17d17d1879f07dc16ece1c1abdcb6621aa18d1879f2254ba0.scope"
      }
    ],
    "ips": [
      "10.26.0.2"
    ],
    "name": "coredns-cc6ccd49c-5cnnv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7278,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode006aa73_b1df_4e52_8cdb_10fc27df9e88.slice/cri-containerd-eaabf7abc7bc0ff37eb8a6ea71000e55141c2ad3b9fc54516177aac017e7fc87.scope"
      }
    ],
    "ips": [
      "10.26.0.29"
    ],
    "name": "coredns-cc6ccd49c-85ljd",
    "namespace": "kube-system"
  }
]

