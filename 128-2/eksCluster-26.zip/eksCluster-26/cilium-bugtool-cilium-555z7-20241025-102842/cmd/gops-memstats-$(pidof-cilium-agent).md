alloc: 90.68MB (95081904 bytes)
total-alloc: 1.37GB (1467186696 bytes)
sys: 214.82MB (225256788 bytes)
lookups: 0
mallocs: 48356101
frees: 47470524
heap-alloc: 90.68MB (95081904 bytes)
heap-sys: 169.26MB (177479680 bytes)
heap-idle: 50.01MB (52436992 bytes)
heap-in-use: 119.25MB (125042688 bytes)
heap-released: 3.38MB (3538944 bytes)
heap-objects: 885577
stack-in-use: 34.72MB (36405248 bytes)
stack-sys: 34.72MB (36405248 bytes)
stack-mspan-inuse: 1.98MB (2080960 bytes)
stack-mspan-sys: 2.63MB (2758080 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 982.01KB (1005577 bytes)
gc-sys: 5.34MB (5595392 bytes)
next-gc: when heap-alloc >= 146.71MB (153837368 bytes)
last-gc: 2024-10-25 10:28:51.104350933 +0000 UTC
gc-pause-total: 11.714099ms
gc-pause: 214796
gc-pause-end: 1729852131104350933
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.0002682776817731512
enable-gc: true
debug-gc: false
