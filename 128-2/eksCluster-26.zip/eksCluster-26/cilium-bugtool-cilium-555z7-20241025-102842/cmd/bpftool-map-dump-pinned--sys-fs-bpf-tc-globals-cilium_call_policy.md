key: 60 06 00 00  value: 51 02 00 00
key: 75 06 00 00  value: 00 02 00 00
key: 48 09 00 00  value: e2 01 00 00
key: 24 0a 00 00  value: f3 01 00 00
Found 4 elements
