IP ADDRESS         LOCAL ENDPOINT INFO
172.31.147.228:0   (localhost)                                                                                        
10.26.0.2:0        id=1653  sec_id=1774281 flags=0x0000 ifindex=11  mac=6A:F8:E8:E4:C4:D3 nodemac=D2:67:37:42:79:33   
10.26.0.188:0      id=1632  sec_id=1804115 flags=0x0000 ifindex=15  mac=C6:D7:D4:54:4E:E0 nodemac=BE:8F:30:18:E7:F2   
10.26.0.29:0       id=2596  sec_id=1774281 flags=0x0000 ifindex=9   mac=DA:6E:89:67:C1:88 nodemac=82:00:C4:FF:67:7A   
10.26.0.233:0      id=2376  sec_id=4     flags=0x0000 ifindex=7   mac=6A:3A:CC:5E:59:D0 nodemac=EE:10:E2:9A:9C:01     
10.26.0.72:0       (localhost)                                                                                        
