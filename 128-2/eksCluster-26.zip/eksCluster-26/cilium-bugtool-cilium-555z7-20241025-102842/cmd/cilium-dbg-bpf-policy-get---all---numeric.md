Endpoint ID: 1632
Path: /sys/fs/bpf/tc/globals/cilium_policy_01632

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3806128   36473     0        
Allow    Ingress     1          ANY          NONE         disabled    3311954   33682     0        
Allow    Egress      0          ANY          NONE         disabled    5423556   49813     0        


Endpoint ID: 1653
Path: /sys/fs/bpf/tc/globals/cilium_policy_01653

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83536   963       0        
Allow    Egress      0          ANY          NONE         disabled    13669   142       0        


Endpoint ID: 2376
Path: /sys/fs/bpf/tc/globals/cilium_policy_02376

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    429484   5466      0        
Allow    Ingress     1          ANY          NONE         disabled    12172    142       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2596
Path: /sys/fs/bpf/tc/globals/cilium_policy_02596

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83511   960       0        
Allow    Egress      0          ANY          NONE         disabled    12826   133       0        


Endpoint ID: 3819
Path: /sys/fs/bpf/tc/globals/cilium_policy_03819

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


