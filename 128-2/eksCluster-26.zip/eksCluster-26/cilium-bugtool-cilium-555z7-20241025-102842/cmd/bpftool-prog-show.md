29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:36+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
68: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
71: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
72: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
75: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
80: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
83: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
111: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
114: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
455: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 72,93
	btf_id 115
456: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 116
457: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 117
458: sched_cls  name tail_handle_ipv4  tag 9951a19633253155  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 71,70,77,72,93
	btf_id 118
480: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 72,101,78,79,102,80
	btf_id 143
482: sched_cls  name handle_policy  tag 1d2906b0ed31f89c  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 72,101,78,79,102,37,76,100,35,80,71,36,33,34
	btf_id 144
484: sched_cls  name __send_drop_notify  tag 3383096cc0fc3599  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 147
485: sched_cls  name tail_handle_ipv4  tag ede23bcffb4ff3c1  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,101
	btf_id 148
486: sched_cls  name tail_ipv4_ct_ingress  tag d065235344c133c3  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 72,101,78,79,102,80
	btf_id 149
487: sched_cls  name cil_from_container  tag a9130babccc9c5c6  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 101,72
	btf_id 150
488: sched_cls  name tail_ipv4_to_endpoint  tag c329e9c8bb7e1b18  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 71,72,102,37,78,79,76,100,35,101,36,33,34
	btf_id 151
489: sched_cls  name tail_handle_ipv4_cont  tag da3f67e3b5f45f84  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 71,102,37,100,78,79,35,72,70,73,101,36,33,34,77
	btf_id 152
490: sched_cls  name tail_handle_arp  tag 5c154d1496064e2c  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,101
	btf_id 153
491: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,101
	btf_id 154
492: sched_cls  name __send_drop_notify  tag 7a8fc6a3f3d3e815  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 156
493: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,104
	btf_id 157
494: sched_cls  name cil_from_container  tag de5217216488419e  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 104,72
	btf_id 158
495: sched_cls  name tail_ipv4_to_endpoint  tag b1ec2edb982ff0f7  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,103,37,78,79,76,95,35,104,36,33,34
	btf_id 159
497: sched_cls  name tail_ipv4_ct_egress  tag bf56ca50e4993302  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,104,78,79,103,80
	btf_id 161
498: sched_cls  name tail_handle_arp  tag b7e6d5d9b58ac948  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,104
	btf_id 162
499: sched_cls  name handle_policy  tag 5e8b7215816b156b  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,104,78,79,103,37,76,95,35,80,71,36,33,34
	btf_id 163
500: sched_cls  name tail_ipv4_ct_ingress  tag a74735313725492d  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,104,78,79,103,80
	btf_id 164
501: sched_cls  name tail_handle_ipv4  tag 5fac2e90deb72b00  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,104
	btf_id 165
502: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
505: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
506: sched_cls  name tail_handle_ipv4_cont  tag 2016ac3e4581dc47  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,103,37,95,78,79,35,72,70,73,104,36,33,34,77
	btf_id 166
507: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
510: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
511: sched_cls  name tail_handle_arp  tag 9d5059dd7fa49896  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,108
	btf_id 168
512: sched_cls  name handle_policy  tag 6c768317ec75bc80  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,108,78,79,107,37,76,94,35,80,71,36,33,34
	btf_id 169
513: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,108
	btf_id 170
515: sched_cls  name tail_handle_ipv4  tag a765f53ecec2d12f  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,108
	btf_id 172
516: sched_cls  name cil_from_container  tag 276706f8f65ce5b6  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 108,72
	btf_id 173
517: sched_cls  name tail_ipv4_to_endpoint  tag 4cc4b6ebfc7b403c  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,107,37,78,79,76,94,35,108,36,33,34
	btf_id 174
518: sched_cls  name tail_handle_ipv4_cont  tag b43942c08ead7975  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,107,37,94,78,79,35,72,70,73,108,36,33,34,77
	btf_id 175
519: sched_cls  name tail_ipv4_ct_ingress  tag e7265d792eb0c77b  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,108,78,79,107,80
	btf_id 176
520: sched_cls  name tail_ipv4_ct_egress  tag bf56ca50e4993302  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,108,78,79,107,80
	btf_id 177
521: sched_cls  name __send_drop_notify  tag 2363e9b3f8bce145  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 178
522: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 72,71,109
	btf_id 180
523: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 181
524: sched_cls  name tail_handle_ipv4_from_host  tag ec4f4f8f21fe77cc  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,109
	btf_id 182
525: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,109
	btf_id 183
528: sched_cls  name __send_drop_notify  tag 65d9603e7d168992  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 186
529: sched_cls  name tail_handle_ipv4_from_host  tag ec4f4f8f21fe77cc  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,111
	btf_id 188
530: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,111
	btf_id 189
533: sched_cls  name __send_drop_notify  tag 65d9603e7d168992  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 192
535: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 194
537: sched_cls  name tail_handle_ipv4_from_host  tag ec4f4f8f21fe77cc  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,113
	btf_id 197
538: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,113
	btf_id 198
539: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 72,113,71
	btf_id 199
541: sched_cls  name __send_drop_notify  tag 65d9603e7d168992  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 201
543: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
546: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
547: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
550: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
590: sched_cls  name __send_drop_notify  tag 00faa47fa6b8ce86  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 217
591: sched_cls  name tail_handle_ipv4  tag da9485fa63ce02bf  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,129
	btf_id 218
592: sched_cls  name cil_from_container  tag 3221296457b9a569  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 129,72
	btf_id 219
593: sched_cls  name handle_policy  tag 5e48c11ffa226ffd  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,129,78,79,128,37,76,127,35,80,71,36,33,34
	btf_id 220
594: sched_cls  name tail_ipv4_ct_egress  tag ecbb7a18a46ae6ba  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,129,78,79,128,80
	btf_id 221
595: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,129
	btf_id 222
596: sched_cls  name tail_handle_ipv4_cont  tag 88ccc2faba98830a  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,128,37,127,78,79,35,72,70,73,129,36,33,34,77
	btf_id 223
597: sched_cls  name tail_handle_arp  tag e0613f58c3a31cfb  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,129
	btf_id 224
598: sched_cls  name tail_ipv4_to_endpoint  tag f9c72c4b6980d098  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,128,37,78,79,76,127,35,129,36,33,34
	btf_id 225
599: sched_cls  name tail_ipv4_ct_ingress  tag 286ec1761737a0f3  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,129,78,79,128,80
	btf_id 226
601: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
604: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
617: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
620: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
621: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
624: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
625: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
628: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
