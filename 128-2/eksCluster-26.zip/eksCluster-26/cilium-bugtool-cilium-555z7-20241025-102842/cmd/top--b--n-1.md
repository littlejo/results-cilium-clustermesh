top - 10:28:43 up 15 min,  0 users,  load average: 0.04, 0.16, 0.15
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 34.5 us, 37.9 sy,  0.0 ni, 27.6 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    783.3 free,    910.8 used,   2142.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2756.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538548 290064  80360 S  37.5   7.4   0:25.35 cilium-+
    405 root      20   0 1228848   6668   3844 S   0.0   0.2   0:00.26 cilium-+
    678 root      20   0 1240432  16640  11484 S   0.0   0.4   0:00.02 cilium-+
    708 root      20   0    6576   2420   2096 R   0.0   0.1   0:00.00 top
    709 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    743 root      20   0 1228744   3660   2976 S   0.0   0.1   0:00.00 gops
