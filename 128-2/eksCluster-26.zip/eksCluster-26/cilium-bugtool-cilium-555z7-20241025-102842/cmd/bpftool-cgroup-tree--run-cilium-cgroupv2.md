CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod45a287a5_8b62_4aa4_9e65_85a34737ccec.slice/cri-containerd-5c7987fe119109c17d17d1879f07dc16ece1c1abdcb6621aa18d1879f2254ba0.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod45a287a5_8b62_4aa4_9e65_85a34737ccec.slice/cri-containerd-70c4b96aa70f9290dc6744a3209be5d34640a29ec884943c934242efe84e1aab.scope
    510      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode006aa73_b1df_4e52_8cdb_10fc27df9e88.slice/cri-containerd-eaabf7abc7bc0ff37eb8a6ea71000e55141c2ad3b9fc54516177aac017e7fc87.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode006aa73_b1df_4e52_8cdb_10fc27df9e88.slice/cri-containerd-a645232c06f436c382db0d12990d6aa86523a4e3a79a790eeff70c98f7af3fb9.scope
    505      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf6663ec3_cc48_4237_97c1_c52aeb1aa1ff.slice/cri-containerd-24ee9271fec9725dbaa0ebd4065a85591cb0a2a09842a9d74ed16683706ae483.scope
    114      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf6663ec3_cc48_4237_97c1_c52aeb1aa1ff.slice/cri-containerd-626c3b508c3caafd6de9ab317a698b4d3967b0493368b270d3591d373a956190.scope
    71       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod99a2c330_4b43_442f_b00c_951d46b46d84.slice/cri-containerd-ecbb28cee243684ba22e8dbd95f7fb383fd883091fa8b651b7d87f5b8a37e984.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod99a2c330_4b43_442f_b00c_951d46b46d84.slice/cri-containerd-e0628102f08c708e57e8490e3fc35a0a91cf5f608e76882f4243a11d0a102449.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4786cc4f_e1bd_42a6_8d09_5d1de9d19a48.slice/cri-containerd-3a76e5ff7e0a89cf81da826061d2e87c59165231d58b86391be989ea1da39b3b.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4786cc4f_e1bd_42a6_8d09_5d1de9d19a48.slice/cri-containerd-43acdd7886211b2a934970016565b2e09b8ff7560741a86a9f2dfdcf08c044b0.scope
    83       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb66e904b_fedc_4448_a010_7ad1be4b5bda.slice/cri-containerd-31aec5e4d8c121e236821221f146ec3dd29c2de8dde66f14dc4113241a693668.scope
    624      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb66e904b_fedc_4448_a010_7ad1be4b5bda.slice/cri-containerd-5b3ff7a1732e973449485f3c710987936074379f134254f068b1041466c3c680.scope
    628      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb66e904b_fedc_4448_a010_7ad1be4b5bda.slice/cri-containerd-e0eb3ca97f2839a15708b9b7a9c5aabe13e2d783cc6c3ba3e9c931b2849d5a31.scope
    620      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb66e904b_fedc_4448_a010_7ad1be4b5bda.slice/cri-containerd-1ee7a202541aa688881772eb4a53668bd7bdd26a8e765f30bba420a7e646a60c.scope
    604      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9febee81_ade0_478c_9a78_a9a811d359bb.slice/cri-containerd-cefa00af2d0f255b202080f361b4ca4d8c2a819fc037884da70a6e93429a6ada.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9febee81_ade0_478c_9a78_a9a811d359bb.slice/cri-containerd-8aadc7255e72f3d4858355c8ce82c750585244da27e0531888f730503cfac3a7.scope
    87       cgroup_device   multi                                          
