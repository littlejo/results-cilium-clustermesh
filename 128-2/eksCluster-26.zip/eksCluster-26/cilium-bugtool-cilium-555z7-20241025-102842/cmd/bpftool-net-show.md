xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 539
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 535
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 523
cilium_host(4) clsact/egress cil_from_host-cilium_host id 522
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 455
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 456
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 487
lxc8546aa16a4d6(9) clsact/ingress cil_from_container-lxc8546aa16a4d6 id 494
lxcdf3439c574bf(11) clsact/ingress cil_from_container-lxcdf3439c574bf id 516
lxcc48373ff1208(15) clsact/ingress cil_from_container-lxcc48373ff1208 id 592

flow_dissector:

netfilter:

