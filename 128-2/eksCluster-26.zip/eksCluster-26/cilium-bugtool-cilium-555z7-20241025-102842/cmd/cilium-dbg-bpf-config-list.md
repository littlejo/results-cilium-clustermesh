KEY             VALUE
AgentLiveness   946185831957
UTimeOffset     3378615640625000
