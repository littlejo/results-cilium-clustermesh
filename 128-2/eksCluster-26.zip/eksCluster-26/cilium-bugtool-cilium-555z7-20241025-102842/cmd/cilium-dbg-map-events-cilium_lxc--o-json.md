{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:21.625Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.147.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:21.625Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:26.235Z",
  "value": "id=2596  sec_id=1774281 flags=0x0000 ifindex=9   mac=DA:6E:89:67:C1:88 nodemac=82:00:C4:FF:67:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:26.245Z",
  "value": "id=1653  sec_id=1774281 flags=0x0000 ifindex=11  mac=6A:F8:E8:E4:C4:D3 nodemac=D2:67:37:42:79:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:26.298Z",
  "value": "id=2376  sec_id=4     flags=0x0000 ifindex=7   mac=6A:3A:CC:5E:59:D0 nodemac=EE:10:E2:9A:9C:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:26.360Z",
  "value": "id=2596  sec_id=1774281 flags=0x0000 ifindex=9   mac=DA:6E:89:67:C1:88 nodemac=82:00:C4:FF:67:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:26.404Z",
  "value": "id=1653  sec_id=1774281 flags=0x0000 ifindex=11  mac=6A:F8:E8:E4:C4:D3 nodemac=D2:67:37:42:79:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:59.717Z",
  "value": "id=2376  sec_id=4     flags=0x0000 ifindex=7   mac=6A:3A:CC:5E:59:D0 nodemac=EE:10:E2:9A:9C:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:59.717Z",
  "value": "id=2596  sec_id=1774281 flags=0x0000 ifindex=9   mac=DA:6E:89:67:C1:88 nodemac=82:00:C4:FF:67:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:59.717Z",
  "value": "id=1653  sec_id=1774281 flags=0x0000 ifindex=11  mac=6A:F8:E8:E4:C4:D3 nodemac=D2:67:37:42:79:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:59.748Z",
  "value": "id=907   sec_id=1804115 flags=0x0000 ifindex=13  mac=52:69:F3:00:AA:D0 nodemac=BA:65:1F:95:7A:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:00.717Z",
  "value": "id=1653  sec_id=1774281 flags=0x0000 ifindex=11  mac=6A:F8:E8:E4:C4:D3 nodemac=D2:67:37:42:79:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:00.717Z",
  "value": "id=907   sec_id=1804115 flags=0x0000 ifindex=13  mac=52:69:F3:00:AA:D0 nodemac=BA:65:1F:95:7A:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:00.718Z",
  "value": "id=2376  sec_id=4     flags=0x0000 ifindex=7   mac=6A:3A:CC:5E:59:D0 nodemac=EE:10:E2:9A:9C:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:00.718Z",
  "value": "id=2596  sec_id=1774281 flags=0x0000 ifindex=9   mac=DA:6E:89:67:C1:88 nodemac=82:00:C4:FF:67:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:11.592Z",
  "value": "id=1632  sec_id=1804115 flags=0x0000 ifindex=15  mac=C6:D7:D4:54:4E:E0 nodemac=BE:8F:30:18:E7:F2"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.26.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:16.946Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:11.045Z",
  "value": "id=1632  sec_id=1804115 flags=0x0000 ifindex=15  mac=C6:D7:D4:54:4E:E0 nodemac=BE:8F:30:18:E7:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:11.046Z",
  "value": "id=2596  sec_id=1774281 flags=0x0000 ifindex=9   mac=DA:6E:89:67:C1:88 nodemac=82:00:C4:FF:67:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:11.046Z",
  "value": "id=1653  sec_id=1774281 flags=0x0000 ifindex=11  mac=6A:F8:E8:E4:C4:D3 nodemac=D2:67:37:42:79:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:11.046Z",
  "value": "id=2376  sec_id=4     flags=0x0000 ifindex=7   mac=6A:3A:CC:5E:59:D0 nodemac=EE:10:E2:9A:9C:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:12.046Z",
  "value": "id=2376  sec_id=4     flags=0x0000 ifindex=7   mac=6A:3A:CC:5E:59:D0 nodemac=EE:10:E2:9A:9C:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:12.046Z",
  "value": "id=1632  sec_id=1804115 flags=0x0000 ifindex=15  mac=C6:D7:D4:54:4E:E0 nodemac=BE:8F:30:18:E7:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:12.046Z",
  "value": "id=2596  sec_id=1774281 flags=0x0000 ifindex=9   mac=DA:6E:89:67:C1:88 nodemac=82:00:C4:FF:67:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:12.046Z",
  "value": "id=1653  sec_id=1774281 flags=0x0000 ifindex=11  mac=6A:F8:E8:E4:C4:D3 nodemac=D2:67:37:42:79:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:13.046Z",
  "value": "id=1653  sec_id=1774281 flags=0x0000 ifindex=11  mac=6A:F8:E8:E4:C4:D3 nodemac=D2:67:37:42:79:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:13.047Z",
  "value": "id=2596  sec_id=1774281 flags=0x0000 ifindex=9   mac=DA:6E:89:67:C1:88 nodemac=82:00:C4:FF:67:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:13.047Z",
  "value": "id=2376  sec_id=4     flags=0x0000 ifindex=7   mac=6A:3A:CC:5E:59:D0 nodemac=EE:10:E2:9A:9C:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.26.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:13.047Z",
  "value": "id=1632  sec_id=1804115 flags=0x0000 ifindex=15  mac=C6:D7:D4:54:4E:E0 nodemac=BE:8F:30:18:E7:F2"
}

