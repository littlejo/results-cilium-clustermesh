fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxc8546aa16a4d6 proto kernel metric 256 pref medium
fe80::/64 dev lxcdf3439c574bf proto kernel metric 256 pref medium
fe80::/64 dev lxcc48373ff1208 proto kernel metric 256 pref medium
