REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     226908    101674181   1132   bpf_host.c
Interface                 INGRESS     9995      784411      677    bpf_overlay.c
Success                   EGRESS      10270     803725      53     encap.h
Success                   EGRESS      5220      402115      1694   bpf_host.c
Success                   EGRESS      96676     12555160    1308   bpf_lxc.c
Success                   INGRESS     106873    13274863    86     l3.h
Success                   INGRESS     112297    13701065    235    trace.h
Unsupported L3 protocol   EGRESS      36        2672        1492   bpf_lxc.c
