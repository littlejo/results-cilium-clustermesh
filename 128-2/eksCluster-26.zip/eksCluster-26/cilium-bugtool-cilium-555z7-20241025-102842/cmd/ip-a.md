1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:cb:a4:ad:b3:51 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.147.228/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2695sec preferred_lft 2695sec
    inet6 fe80::4cb:a4ff:fead:b351/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:c5:99:ba:9a:4d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c8c5:99ff:feba:9a4d/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:57:de:a2:08:5e brd ff:ff:ff:ff:ff:ff
    inet 10.26.0.72/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::e457:deff:fea2:85e/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether b6:62:d0:d3:bb:53 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b462:d0ff:fed3:bb53/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:10:e2:9a:9c:01 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::ec10:e2ff:fe9a:9c01/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc8546aa16a4d6@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:00:c4:ff:67:7a brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::8000:c4ff:feff:677a/64 scope link 
       valid_lft forever preferred_lft forever
11: lxcdf3439c574bf@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:67:37:42:79:33 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d067:37ff:fe42:7933/64 scope link 
       valid_lft forever preferred_lft forever
15: lxcc48373ff1208@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:8f:30:18:e7:f2 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::bc8f:30ff:fe18:e7f2/64 scope link 
       valid_lft forever preferred_lft forever
