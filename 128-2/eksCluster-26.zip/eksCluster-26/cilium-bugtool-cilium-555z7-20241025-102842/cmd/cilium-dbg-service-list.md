ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.194.157:443 (active)    
                                         2 => 172.31.176.97:443 (active)     
2    10.100.220.123:443   ClusterIP      1 => 172.31.147.228:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.26.0.29:53 (active)         
                                         2 => 10.26.0.2:53 (active)          
4    10.100.0.10:9153     ClusterIP      1 => 10.26.0.29:9153 (active)       
                                         2 => 10.26.0.2:9153 (active)        
5    10.100.5.201:2379    ClusterIP      1 => 10.26.0.188:2379 (active)      
