1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:57:5f:b7:2d:bb brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.175.121/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2767sec preferred_lft 2767sec
    inet6 fe80::457:5fff:feb7:2dbb/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:a7:39:61:65:63 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.174.159/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4a7:39ff:fe61:6563/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:d4:cf:17:50:9b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::80d4:cfff:fe17:509b/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:a5:2f:28:d5:08 brd ff:ff:ff:ff:ff:ff
    inet 10.40.0.144/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::14a5:2fff:fe28:d508/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether be:bf:08:c3:4b:45 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::bcbf:8ff:fec3:4b45/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:06:be:74:14:77 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::806:beff:fe74:1477/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf43d5a00fcef@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:33:07:41:b5:fd brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::f033:7ff:fe41:b5fd/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc86bae63f6ff0@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:1b:93:e7:c6:a4 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::941b:93ff:fee7:c6a4/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcc9a0ddf5d799@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:dd:ca:d9:d2:cd brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c4dd:caff:fed9:d2cd/64 scope link 
       valid_lft forever preferred_lft forever
