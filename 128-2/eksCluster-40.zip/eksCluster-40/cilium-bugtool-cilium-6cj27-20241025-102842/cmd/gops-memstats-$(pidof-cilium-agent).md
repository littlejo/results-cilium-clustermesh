alloc: 128.20MB (134428640 bytes)
total-alloc: 1.32GB (1416529568 bytes)
sys: 206.38MB (216409428 bytes)
lookups: 0
mallocs: 47582587
frees: 46301400
heap-alloc: 128.20MB (134428640 bytes)
heap-sys: 161.48MB (169328640 bytes)
heap-idle: 16.67MB (17481728 bytes)
heap-in-use: 144.81MB (151846912 bytes)
heap-released: 920.00KB (942080 bytes)
heap-objects: 1281187
stack-in-use: 34.47MB (36143104 bytes)
stack-sys: 34.47MB (36143104 bytes)
stack-mspan-inuse: 2.22MB (2329120 bytes)
stack-mspan-sys: 2.41MB (2529600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 985.86KB (1009521 bytes)
gc-sys: 5.14MB (5388352 bytes)
next-gc: when heap-alloc >= 145.58MB (152653672 bytes)
last-gc: 2024-10-25 10:28:38.299902014 +0000 UTC
gc-pause-total: 6.46353ms
gc-pause: 89543
gc-pause-end: 1729852118299902014
num-gc: 71
num-forced-gc: 0
gc-cpu-fraction: 0.0003278587891264728
enable-gc: true
debug-gc: false
