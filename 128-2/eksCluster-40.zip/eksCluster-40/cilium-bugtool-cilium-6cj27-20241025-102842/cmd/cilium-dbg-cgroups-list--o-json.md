[
  {
    "containers": [
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6f506d34_1a00_4cef_9c34_39c99c22a939.slice/cri-containerd-1f1d40d6eb37cfbf6f3369a50965c1766fab172bc493f8962d174ffab606755d.scope"
      },
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6f506d34_1a00_4cef_9c34_39c99c22a939.slice/cri-containerd-15e19d4ee2a8e6da33361bd6fd419681d012f80794984045f26e59559199db27.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6f506d34_1a00_4cef_9c34_39c99c22a939.slice/cri-containerd-95aac38109369f9e034629497bca49ee202fe77412dc47bdaf2782b1acca8e88.scope"
      }
    ],
    "ips": [
      "10.40.0.179"
    ],
    "name": "clustermesh-apiserver-76cb65fbbd-7m6gw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod94094e65_778d_4552_977d_0e947aca99a5.slice/cri-containerd-24687b8a719e1b868b0dc29240198b907054e93417e951d14e31fb5bdfe6baa5.scope"
      }
    ],
    "ips": [
      "10.40.0.62"
    ],
    "name": "coredns-cc6ccd49c-2wp86",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1165a0c0_62d6_4fad_b22b_064c02ec14d9.slice/cri-containerd-676ec04ca557d1d2bd4de56371b2bacd9d557d3f1fa504cedcb8eaea69da6bfb.scope"
      }
    ],
    "ips": [
      "10.40.0.67"
    ],
    "name": "coredns-cc6ccd49c-cnjg8",
    "namespace": "kube-system"
  }
]

