filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcc9a0ddf5d799 direct-action not_in_hw id 651 tag 4598cfdaf5e1bf1b jited 
