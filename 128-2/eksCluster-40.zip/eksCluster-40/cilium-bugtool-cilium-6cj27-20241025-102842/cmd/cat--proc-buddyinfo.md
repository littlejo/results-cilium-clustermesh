Node 0, zone      DMA     73     62     13     19      5      2      3      4      4      3    166 
Node 0, zone   Normal    481     64      8      1      4      9      2      3      4      2      7 
