{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:28.966Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.174.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:28.966Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.175.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:28.966Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:33.618Z",
  "value": "id=2474  sec_id=2718645 flags=0x0000 ifindex=14  mac=F6:5C:C0:B2:E7:CA nodemac=96:1B:93:E7:C6:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:33.629Z",
  "value": "id=2798  sec_id=4     flags=0x0000 ifindex=10  mac=CE:09:57:8B:CC:6C nodemac=0A:06:BE:74:14:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:33.679Z",
  "value": "id=406   sec_id=2718645 flags=0x0000 ifindex=12  mac=96:2F:E6:CC:F0:58 nodemac=F2:33:07:41:B5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:33.710Z",
  "value": "id=2798  sec_id=4     flags=0x0000 ifindex=10  mac=CE:09:57:8B:CC:6C nodemac=0A:06:BE:74:14:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.168Z",
  "value": "id=2798  sec_id=4     flags=0x0000 ifindex=10  mac=CE:09:57:8B:CC:6C nodemac=0A:06:BE:74:14:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.169Z",
  "value": "id=406   sec_id=2718645 flags=0x0000 ifindex=12  mac=96:2F:E6:CC:F0:58 nodemac=F2:33:07:41:B5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.169Z",
  "value": "id=2474  sec_id=2718645 flags=0x0000 ifindex=14  mac=F6:5C:C0:B2:E7:CA nodemac=96:1B:93:E7:C6:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.199Z",
  "value": "id=126   sec_id=2718529 flags=0x0000 ifindex=16  mac=86:EB:63:3C:2E:F0 nodemac=BE:CC:D9:57:27:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.168Z",
  "value": "id=2798  sec_id=4     flags=0x0000 ifindex=10  mac=CE:09:57:8B:CC:6C nodemac=0A:06:BE:74:14:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.168Z",
  "value": "id=2474  sec_id=2718645 flags=0x0000 ifindex=14  mac=F6:5C:C0:B2:E7:CA nodemac=96:1B:93:E7:C6:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.169Z",
  "value": "id=126   sec_id=2718529 flags=0x0000 ifindex=16  mac=86:EB:63:3C:2E:F0 nodemac=BE:CC:D9:57:27:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.169Z",
  "value": "id=406   sec_id=2718645 flags=0x0000 ifindex=12  mac=96:2F:E6:CC:F0:58 nodemac=F2:33:07:41:B5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:31.992Z",
  "value": "id=1987  sec_id=2718529 flags=0x0000 ifindex=18  mac=66:53:3A:26:D9:2F nodemac=C6:DD:CA:D9:D2:CD"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.40.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:37.439Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:14.527Z",
  "value": "id=2474  sec_id=2718645 flags=0x0000 ifindex=14  mac=F6:5C:C0:B2:E7:CA nodemac=96:1B:93:E7:C6:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:14.528Z",
  "value": "id=1987  sec_id=2718529 flags=0x0000 ifindex=18  mac=66:53:3A:26:D9:2F nodemac=C6:DD:CA:D9:D2:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:14.528Z",
  "value": "id=2798  sec_id=4     flags=0x0000 ifindex=10  mac=CE:09:57:8B:CC:6C nodemac=0A:06:BE:74:14:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:14.529Z",
  "value": "id=406   sec_id=2718645 flags=0x0000 ifindex=12  mac=96:2F:E6:CC:F0:58 nodemac=F2:33:07:41:B5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:15.528Z",
  "value": "id=2798  sec_id=4     flags=0x0000 ifindex=10  mac=CE:09:57:8B:CC:6C nodemac=0A:06:BE:74:14:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:15.529Z",
  "value": "id=406   sec_id=2718645 flags=0x0000 ifindex=12  mac=96:2F:E6:CC:F0:58 nodemac=F2:33:07:41:B5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:15.529Z",
  "value": "id=2474  sec_id=2718645 flags=0x0000 ifindex=14  mac=F6:5C:C0:B2:E7:CA nodemac=96:1B:93:E7:C6:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:15.529Z",
  "value": "id=1987  sec_id=2718529 flags=0x0000 ifindex=18  mac=66:53:3A:26:D9:2F nodemac=C6:DD:CA:D9:D2:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:16.529Z",
  "value": "id=2798  sec_id=4     flags=0x0000 ifindex=10  mac=CE:09:57:8B:CC:6C nodemac=0A:06:BE:74:14:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:16.529Z",
  "value": "id=1987  sec_id=2718529 flags=0x0000 ifindex=18  mac=66:53:3A:26:D9:2F nodemac=C6:DD:CA:D9:D2:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:16.529Z",
  "value": "id=406   sec_id=2718645 flags=0x0000 ifindex=12  mac=96:2F:E6:CC:F0:58 nodemac=F2:33:07:41:B5:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:16.529Z",
  "value": "id=2474  sec_id=2718645 flags=0x0000 ifindex=14  mac=F6:5C:C0:B2:E7:CA nodemac=96:1B:93:E7:C6:A4"
}

