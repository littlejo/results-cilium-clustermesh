Endpoint ID: 406
Path: /sys/fs/bpf/tc/globals/cilium_policy_00406

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    71440   823       0        
Allow    Egress      0          ANY          NONE         disabled    12926   133       0        


Endpoint ID: 1043
Path: /sys/fs/bpf/tc/globals/cilium_policy_01043

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1987
Path: /sys/fs/bpf/tc/globals/cilium_policy_01987

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3890160   36245     0        
Allow    Ingress     1          ANY          NONE         disabled    2916989   29371     0        
Allow    Egress      0          ANY          NONE         disabled    4201905   38930     0        


Endpoint ID: 2474
Path: /sys/fs/bpf/tc/globals/cilium_policy_02474

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    71638   826       0        
Allow    Egress      0          ANY          NONE         disabled    12348   126       0        


Endpoint ID: 2798
Path: /sys/fs/bpf/tc/globals/cilium_policy_02798

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    434532   5549      0        
Allow    Ingress     1          ANY          NONE         disabled    10832    128       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


