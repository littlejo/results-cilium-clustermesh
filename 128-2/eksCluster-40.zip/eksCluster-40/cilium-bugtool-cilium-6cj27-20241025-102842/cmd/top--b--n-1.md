top - 10:28:44 up 14 min,  0 users,  load average: 0.89, 0.35, 0.19
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 16.1 us, 16.1 sy,  0.0 ni, 58.1 id,  0.0 wa,  0.0 hi,  9.7 si,  0.0 st
MiB Mem :   3836.2 total,    799.7 free,    893.8 used,   2142.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2773.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1472496 269748  77316 S   6.7   6.9   0:20.98 cilium-+
    394 root      20   0 1228848   6880   3840 S   0.0   0.2   0:00.25 cilium-+
    641 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    647 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    652 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
    653 root      20   0 1240432  16048  11228 S   0.0   0.4   0:00.02 cilium-+
    695 root      20   0    6576   2420   2096 R   0.0   0.1   0:00.00 top
    713 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
