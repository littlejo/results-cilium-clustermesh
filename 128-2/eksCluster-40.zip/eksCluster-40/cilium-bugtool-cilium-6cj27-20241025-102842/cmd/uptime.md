 10:28:44 up 14 min,  0 users,  load average: 0.89, 0.35, 0.19
