CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf506b76e_8ed6_4f42_a588_ebd8565ad1b9.slice/cri-containerd-c39deac2f23953bd82c0d0a448ec2802dec1d7170fa412af5e2cd2d1fc609253.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf506b76e_8ed6_4f42_a588_ebd8565ad1b9.slice/cri-containerd-497cd21e7bd239c69898571295c39cbcdc26c1d6e1eae4343ca24f97363925e3.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7bb84e3a_097a_42f5_a98f_59f1d3bc3655.slice/cri-containerd-2fb046388bfbdc9fbb5d4b71636386df3006b504ac7acd8224f5c441b913fa97.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7bb84e3a_097a_42f5_a98f_59f1d3bc3655.slice/cri-containerd-4884d8bfabb4e53756028cf3b5f2360f5f875edb05eb0c781e78d2edc59aa2e6.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1165a0c0_62d6_4fad_b22b_064c02ec14d9.slice/cri-containerd-676ec04ca557d1d2bd4de56371b2bacd9d557d3f1fa504cedcb8eaea69da6bfb.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1165a0c0_62d6_4fad_b22b_064c02ec14d9.slice/cri-containerd-082210f5f9fdda9189ec925fe76bc03b876e7626986c5b8281db471756c94db5.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod94094e65_778d_4552_977d_0e947aca99a5.slice/cri-containerd-24687b8a719e1b868b0dc29240198b907054e93417e951d14e31fb5bdfe6baa5.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod94094e65_778d_4552_977d_0e947aca99a5.slice/cri-containerd-4ec8257ac236b1a27fd509ac73e0fb167ccda09fd6b5b3cf59de283970a4b44b.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6f506d34_1a00_4cef_9c34_39c99c22a939.slice/cri-containerd-1f1d40d6eb37cfbf6f3369a50965c1766fab172bc493f8962d174ffab606755d.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6f506d34_1a00_4cef_9c34_39c99c22a939.slice/cri-containerd-0fe987c13a9d5d52100a5ed54ad5dd5c7dbbd52a67c1fb29611a64fcda2de1f2.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6f506d34_1a00_4cef_9c34_39c99c22a939.slice/cri-containerd-15e19d4ee2a8e6da33361bd6fd419681d012f80794984045f26e59559199db27.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6f506d34_1a00_4cef_9c34_39c99c22a939.slice/cri-containerd-95aac38109369f9e034629497bca49ee202fe77412dc47bdaf2782b1acca8e88.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ab13de8_daac_41b7_aca3_e20ea67a4fb3.slice/cri-containerd-08432d147659b30d0003dc215b3eead86a75f67bda625cb1c18235d32a6d031f.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ab13de8_daac_41b7_aca3_e20ea67a4fb3.slice/cri-containerd-9173cae2dcf941b3a97fa4660f6d32f05265ca99856d7fc27cd00341b7cb4775.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2f95b1a0_a2c2_483e_ba33_84d3baf03e57.slice/cri-containerd-6f7cb73d060f020697be6bf7044a2baa661a6df3b53d4cbeafbe419dfc5f4821.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2f95b1a0_a2c2_483e_ba33_84d3baf03e57.slice/cri-containerd-aea5322a743cdd524c3965cc0233fca717eb373d71a1ef9b9fcddcc5b51ccb46.scope
    101      cgroup_device   multi                                          
