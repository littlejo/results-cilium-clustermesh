KEY             VALUE
AgentLiveness   873525309627
UTimeOffset     3378615783203125
