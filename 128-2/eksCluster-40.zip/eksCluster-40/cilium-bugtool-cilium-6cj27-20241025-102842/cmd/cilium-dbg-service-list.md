ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.175.235:443 (active)    
                                          2 => 172.31.236.140:443 (active)    
2    10.100.110.61:443     ClusterIP      1 => 172.31.175.121:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.40.0.62:53 (active)         
                                          2 => 10.40.0.67:53 (active)         
4    10.100.0.10:9153      ClusterIP      1 => 10.40.0.62:9153 (active)       
                                          2 => 10.40.0.67:9153 (active)       
5    10.100.212.217:2379   ClusterIP      1 => 10.40.0.179:2379 (active)      
