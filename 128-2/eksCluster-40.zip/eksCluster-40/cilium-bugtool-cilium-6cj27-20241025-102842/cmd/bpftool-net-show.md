xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 560
ens6(5) clsact/ingress cil_from_netdev-ens6 id 569
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 557
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 551
cilium_host(7) clsact/egress cil_from_host-cilium_host id 543
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 581
lxcf43d5a00fcef(12) clsact/ingress cil_from_container-lxcf43d5a00fcef id 554
lxc86bae63f6ff0(14) clsact/ingress cil_from_container-lxc86bae63f6ff0 id 527
lxcc9a0ddf5d799(18) clsact/ingress cil_from_container-lxcc9a0ddf5d799 id 651

flow_dissector:

netfilter:

