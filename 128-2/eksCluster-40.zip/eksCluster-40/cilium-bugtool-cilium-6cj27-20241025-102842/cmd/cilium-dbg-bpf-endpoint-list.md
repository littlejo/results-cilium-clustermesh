IP ADDRESS         LOCAL ENDPOINT INFO
172.31.174.159:0   (localhost)                                                                                        
10.40.0.179:0      id=1987  sec_id=2718529 flags=0x0000 ifindex=18  mac=66:53:3A:26:D9:2F nodemac=C6:DD:CA:D9:D2:CD   
10.40.0.37:0       id=2798  sec_id=4     flags=0x0000 ifindex=10  mac=CE:09:57:8B:CC:6C nodemac=0A:06:BE:74:14:77     
172.31.175.121:0   (localhost)                                                                                        
10.40.0.62:0       id=406   sec_id=2718645 flags=0x0000 ifindex=12  mac=96:2F:E6:CC:F0:58 nodemac=F2:33:07:41:B5:FD   
10.40.0.67:0       id=2474  sec_id=2718645 flags=0x0000 ifindex=14  mac=F6:5C:C0:B2:E7:CA nodemac=96:1B:93:E7:C6:A4   
10.40.0.144:0      (localhost)                                                                                        
