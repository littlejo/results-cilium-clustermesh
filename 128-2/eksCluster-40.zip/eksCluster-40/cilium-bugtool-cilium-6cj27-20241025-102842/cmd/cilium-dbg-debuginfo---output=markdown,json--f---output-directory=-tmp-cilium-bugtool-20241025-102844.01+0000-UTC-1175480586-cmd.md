markdown output at /tmp/cilium-bugtool-20241025-102844.01+0000-UTC-1175480586/cmd/cilium-debuginfo-20241025-102914.691+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102844.01+0000-UTC-1175480586/cmd/cilium-debuginfo-20241025-102914.691+0000-UTC.json
