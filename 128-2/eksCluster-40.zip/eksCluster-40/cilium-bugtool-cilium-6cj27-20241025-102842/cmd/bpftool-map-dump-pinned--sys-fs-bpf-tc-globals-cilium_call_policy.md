key: 96 01 00 00  value: 40 02 00 00
key: c3 07 00 00  value: 87 02 00 00
key: aa 09 00 00  value: 0c 02 00 00
key: ee 0a 00 00  value: 4b 02 00 00
Found 4 elements
