[
  {
    "containers": [
      {
        "cgroup-id": 8538,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb14f9323_5a87_41ae_9f0e_81c012c9b50c.slice/cri-containerd-7b7218e3f736ba8fef1cfb7b926bfc2e221a6a730ed47a3c2578151a01ce89ff.scope"
      },
      {
        "cgroup-id": 8454,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb14f9323_5a87_41ae_9f0e_81c012c9b50c.slice/cri-containerd-63fca6c1379098469aac2666bad4bdf685f258867a015fdfa8bf2984b214329a.scope"
      },
      {
        "cgroup-id": 8622,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb14f9323_5a87_41ae_9f0e_81c012c9b50c.slice/cri-containerd-a3ed6a99c7297c3b2d27226c3750fdbe39adf1ef4e8fb330a4858d7c609ae72e.scope"
      }
    ],
    "ips": [
      "10.115.0.160"
    ],
    "name": "clustermesh-apiserver-84c4b75b4d-79d9v",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7026,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod573f687d_70e2_4aa7_815b_49cb850a3b86.slice/cri-containerd-7f7fd63f50e27d5cbc4b8109a1e8dceaa5942dbf58c137b338afc1f80c3c8abb.scope"
      }
    ],
    "ips": [
      "10.115.0.50"
    ],
    "name": "coredns-cc6ccd49c-wdxdk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7110,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4953bcb9_d496_4976_8cf0_a89db9ad88fc.slice/cri-containerd-a9d7ab180c38bba234687b946829ac60a4d90f215f59e75c1378e8908f72b964.scope"
      }
    ],
    "ips": [
      "10.115.0.20"
    ],
    "name": "coredns-cc6ccd49c-rj7c4",
    "namespace": "kube-system"
  }
]

