key: 5d 01 00 00  value: 02 02 00 00
key: 7b 01 00 00  value: f3 01 00 00
key: c7 03 00 00  value: 4e 02 00 00
key: 91 05 00 00  value: e3 01 00 00
Found 4 elements
