markdown output at /tmp/cilium-bugtool-20241025-102842.211+0000-UTC-3581673394/cmd/cilium-debuginfo-20241025-102912.604+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102842.211+0000-UTC-3581673394/cmd/cilium-debuginfo-20241025-102912.604+0000-UTC.json
