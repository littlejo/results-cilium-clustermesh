{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:01.046Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.197.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:01.046Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:05.704Z",
  "value": "id=379   sec_id=4     flags=0x0000 ifindex=7   mac=22:5E:04:4A:52:7D nodemac=3A:40:11:24:33:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:05.709Z",
  "value": "id=349   sec_id=7610734 flags=0x0000 ifindex=9   mac=AA:B5:F9:18:EC:6B nodemac=86:DD:5B:5D:2D:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:05.781Z",
  "value": "id=1425  sec_id=7610734 flags=0x0000 ifindex=11  mac=B6:19:D0:BD:BD:A4 nodemac=4A:5A:DE:FA:03:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:05.867Z",
  "value": "id=379   sec_id=4     flags=0x0000 ifindex=7   mac=22:5E:04:4A:52:7D nodemac=3A:40:11:24:33:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:05.928Z",
  "value": "id=349   sec_id=7610734 flags=0x0000 ifindex=9   mac=AA:B5:F9:18:EC:6B nodemac=86:DD:5B:5D:2D:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:35.065Z",
  "value": "id=379   sec_id=4     flags=0x0000 ifindex=7   mac=22:5E:04:4A:52:7D nodemac=3A:40:11:24:33:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:35.066Z",
  "value": "id=349   sec_id=7610734 flags=0x0000 ifindex=9   mac=AA:B5:F9:18:EC:6B nodemac=86:DD:5B:5D:2D:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:35.067Z",
  "value": "id=1425  sec_id=7610734 flags=0x0000 ifindex=11  mac=B6:19:D0:BD:BD:A4 nodemac=4A:5A:DE:FA:03:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:35.103Z",
  "value": "id=283   sec_id=7610633 flags=0x0000 ifindex=13  mac=8E:C2:62:8E:CE:55 nodemac=52:61:7A:AF:26:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:36.064Z",
  "value": "id=283   sec_id=7610633 flags=0x0000 ifindex=13  mac=8E:C2:62:8E:CE:55 nodemac=52:61:7A:AF:26:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:36.065Z",
  "value": "id=1425  sec_id=7610734 flags=0x0000 ifindex=11  mac=B6:19:D0:BD:BD:A4 nodemac=4A:5A:DE:FA:03:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:36.065Z",
  "value": "id=379   sec_id=4     flags=0x0000 ifindex=7   mac=22:5E:04:4A:52:7D nodemac=3A:40:11:24:33:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:36.065Z",
  "value": "id=349   sec_id=7610734 flags=0x0000 ifindex=9   mac=AA:B5:F9:18:EC:6B nodemac=86:DD:5B:5D:2D:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:31.949Z",
  "value": "id=967   sec_id=7610633 flags=0x0000 ifindex=15  mac=AA:9B:A7:F8:0D:3B nodemac=72:52:44:3A:62:73"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.115.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:37.647Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:07.513Z",
  "value": "id=1425  sec_id=7610734 flags=0x0000 ifindex=11  mac=B6:19:D0:BD:BD:A4 nodemac=4A:5A:DE:FA:03:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:07.514Z",
  "value": "id=967   sec_id=7610633 flags=0x0000 ifindex=15  mac=AA:9B:A7:F8:0D:3B nodemac=72:52:44:3A:62:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:07.514Z",
  "value": "id=379   sec_id=4     flags=0x0000 ifindex=7   mac=22:5E:04:4A:52:7D nodemac=3A:40:11:24:33:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:07.514Z",
  "value": "id=349   sec_id=7610734 flags=0x0000 ifindex=9   mac=AA:B5:F9:18:EC:6B nodemac=86:DD:5B:5D:2D:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:08.513Z",
  "value": "id=967   sec_id=7610633 flags=0x0000 ifindex=15  mac=AA:9B:A7:F8:0D:3B nodemac=72:52:44:3A:62:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:08.513Z",
  "value": "id=349   sec_id=7610734 flags=0x0000 ifindex=9   mac=AA:B5:F9:18:EC:6B nodemac=86:DD:5B:5D:2D:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:08.513Z",
  "value": "id=379   sec_id=4     flags=0x0000 ifindex=7   mac=22:5E:04:4A:52:7D nodemac=3A:40:11:24:33:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:08.514Z",
  "value": "id=1425  sec_id=7610734 flags=0x0000 ifindex=11  mac=B6:19:D0:BD:BD:A4 nodemac=4A:5A:DE:FA:03:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.513Z",
  "value": "id=379   sec_id=4     flags=0x0000 ifindex=7   mac=22:5E:04:4A:52:7D nodemac=3A:40:11:24:33:2D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.513Z",
  "value": "id=1425  sec_id=7610734 flags=0x0000 ifindex=11  mac=B6:19:D0:BD:BD:A4 nodemac=4A:5A:DE:FA:03:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.514Z",
  "value": "id=349   sec_id=7610734 flags=0x0000 ifindex=9   mac=AA:B5:F9:18:EC:6B nodemac=86:DD:5B:5D:2D:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.115.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.514Z",
  "value": "id=967   sec_id=7610633 flags=0x0000 ifindex=15  mac=AA:9B:A7:F8:0D:3B nodemac=72:52:44:3A:62:73"
}

