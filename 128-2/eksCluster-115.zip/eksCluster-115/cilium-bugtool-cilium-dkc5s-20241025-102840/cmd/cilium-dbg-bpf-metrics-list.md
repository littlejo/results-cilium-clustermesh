REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     213269    99641720   1132   bpf_host.c
Interface                 INGRESS     9432      737742     677    bpf_overlay.c
Success                   EGRESS      4546      347397     1694   bpf_host.c
Success                   EGRESS      89290     12081183   1308   bpf_lxc.c
Success                   EGRESS      9284      726289     53     encap.h
Success                   INGRESS     100506    12304210   86     l3.h
Success                   INGRESS     106041    12738461   235    trace.h
Unsupported L3 protocol   EGRESS      37        2746       1492   bpf_lxc.c
