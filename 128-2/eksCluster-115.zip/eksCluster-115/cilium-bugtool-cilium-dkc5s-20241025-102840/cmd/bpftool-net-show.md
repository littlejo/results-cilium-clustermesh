xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 537
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 531
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 526
cilium_host(4) clsact/egress cil_from_host-cilium_host id 525
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 457
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 454
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 504
lxc1ab238018414(9) clsact/ingress cil_from_container-lxc1ab238018414 id 512
lxc135223c003ec(11) clsact/ingress cil_from_container-lxc135223c003ec id 485
lxc6c060c7a85a6(15) clsact/ingress cil_from_container-lxc6c060c7a85a6 id 594

flow_dissector:

netfilter:

