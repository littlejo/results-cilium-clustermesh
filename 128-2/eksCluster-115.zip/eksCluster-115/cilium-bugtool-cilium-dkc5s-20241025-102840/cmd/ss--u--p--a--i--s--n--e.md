Total: 536
TCP:   1090 (estab 305, closed 766, orphaned 0, timewait 302)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  324       314       10       
INET	  334       320       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                  172.31.197.216%ens5:68         0.0.0.0:*    uid:192 ino:15682 sk:1001 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:22155 sk:1002 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:33051      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=43)) ino:22098 sk:1003 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15131 sk:1004 cgroup:unreachable:f0c <->                                    
UNCONN 0      0      [fe80::8bf:39ff:fe07:6175]%ens5:546           [::]:*    uid:192 ino:15674 sk:100f cgroup:unreachable:c4e v6only:1 <->                   
UNCONN 0      0                                 [::]:8472          [::]:*    ino:22154 sk:1010 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15132 sk:1011 cgroup:unreachable:f0c v6only:1 <->                           
