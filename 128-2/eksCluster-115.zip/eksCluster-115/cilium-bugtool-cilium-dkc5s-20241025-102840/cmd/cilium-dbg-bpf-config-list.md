KEY             VALUE
AgentLiveness   960605977658
UTimeOffset     3378615609375000
