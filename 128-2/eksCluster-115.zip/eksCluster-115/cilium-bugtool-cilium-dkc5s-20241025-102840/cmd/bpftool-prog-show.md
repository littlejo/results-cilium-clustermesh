35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:15+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:15+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:20+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
64: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
67: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
68: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
71: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
75: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
78: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
79: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
82: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
83: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
86: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
110: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
113: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
454: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 112
455: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 113
456: sched_cls  name tail_handle_ipv4  tag 52eb56b687b447b8  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 69,68,75,70,91
	btf_id 114
457: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:14:03+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 70,91
	btf_id 115
480: sched_cls  name tail_handle_ipv4  tag 972e4fc60c7aa8ba  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,100
	btf_id 141
481: sched_cls  name tail_ipv4_ct_egress  tag 1567aff8665b3e45  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,100,76,77,99,78
	btf_id 142
482: sched_cls  name tail_handle_ipv4_cont  tag 9ef1db451465825f  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,99,35,98,76,77,33,70,68,71,100,34,31,32,75
	btf_id 143
483: sched_cls  name handle_policy  tag 0300519eee4070b8  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,100,76,77,99,35,74,98,33,78,69,34,31,32
	btf_id 144
484: sched_cls  name __send_drop_notify  tag 1c8f342d6e7183a7  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 145
485: sched_cls  name cil_from_container  tag b9760b32744d4cfb  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 100,70
	btf_id 146
486: sched_cls  name tail_ipv4_ct_ingress  tag 96eacc974654ce5a  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,100,76,77,99,78
	btf_id 147
487: sched_cls  name tail_handle_arp  tag ceb773d0fc160f1d  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,100
	btf_id 148
488: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,100
	btf_id 149
490: sched_cls  name tail_ipv4_to_endpoint  tag f5f2b061f9333873  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,99,35,76,77,74,98,33,100,34,31,32
	btf_id 151
491: sched_cls  name tail_handle_ipv4_cont  tag cc4b5d0c11348e9b  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 69,101,35,92,76,77,33,70,68,71,102,34,31,32,75
	btf_id 153
492: sched_cls  name tail_handle_ipv4  tag d12ac6df4372d4ff  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,102
	btf_id 154
494: sched_cls  name __send_drop_notify  tag 17c4a5e5ae7311a3  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 156
495: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
498: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
499: sched_cls  name handle_policy  tag 91d82a93287c4ddb  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 70,102,76,77,101,35,74,92,33,78,69,34,31,32
	btf_id 157
500: sched_cls  name tail_ipv4_to_endpoint  tag da3c0e42016f0327  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 69,70,101,35,76,77,74,92,33,102,34,31,32
	btf_id 158
501: sched_cls  name tail_handle_arp  tag 13e3e8d3ffbe91fc  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,102
	btf_id 159
502: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,102
	btf_id 160
503: sched_cls  name tail_ipv4_ct_ingress  tag add268e3bff36003  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 70,102,76,77,101,78
	btf_id 161
504: sched_cls  name cil_from_container  tag 4860ff3034825016  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 102,70
	btf_id 162
505: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 70,102,76,77,101,78
	btf_id 163
506: sched_cls  name tail_handle_arp  tag 07a4ca31e35f9b1e  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,104
	btf_id 165
507: sched_cls  name tail_handle_ipv4_cont  tag 1cc5f29a09c7398c  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,105,35,93,76,77,33,70,68,71,104,34,31,32,75
	btf_id 166
508: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
511: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
512: sched_cls  name cil_from_container  tag a2ad2532721c6532  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 104,70
	btf_id 167
513: sched_cls  name tail_ipv4_ct_ingress  tag 308e533273961488  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,104,76,77,105,78
	btf_id 168
514: sched_cls  name handle_policy  tag ff30d3c601259770  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,104,76,77,105,35,74,93,33,78,69,34,31,32
	btf_id 169
515: sched_cls  name tail_ipv4_to_endpoint  tag 3f8e6b122302a4f8  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,105,35,76,77,74,93,33,104,34,31,32
	btf_id 170
517: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,104
	btf_id 172
518: sched_cls  name __send_drop_notify  tag 89a020995388ce04  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 173
519: sched_cls  name tail_handle_ipv4  tag 4d88abe9d59befd0  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,104
	btf_id 174
520: sched_cls  name tail_ipv4_ct_egress  tag 1567aff8665b3e45  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,104,76,77,105,78
	btf_id 175
523: sched_cls  name __send_drop_notify  tag 71be8627c6a16aca  gpl
	loaded_at 2024-10-25T10:14:07+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 179
524: sched_cls  name tail_handle_ipv4_from_host  tag 3cbb1b91141eb124  gpl
	loaded_at 2024-10-25T10:14:07+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,108
	btf_id 180
525: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:14:07+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 70,69,108
	btf_id 181
526: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:07+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 182
527: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:07+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,108
	btf_id 183
528: sched_cls  name __send_drop_notify  tag 71be8627c6a16aca  gpl
	loaded_at 2024-10-25T10:14:07+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 185
529: sched_cls  name tail_handle_ipv4_from_host  tag 3cbb1b91141eb124  gpl
	loaded_at 2024-10-25T10:14:07+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,110
	btf_id 186
531: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:07+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 188
532: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:07+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,110
	btf_id 189
535: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:07+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,112
	btf_id 193
537: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:07+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 70,112,69
	btf_id 195
538: sched_cls  name __send_drop_notify  tag 71be8627c6a16aca  gpl
	loaded_at 2024-10-25T10:14:07+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 196
539: sched_cls  name tail_handle_ipv4_from_host  tag 3cbb1b91141eb124  gpl
	loaded_at 2024-10-25T10:14:07+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,112
	btf_id 197
542: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
545: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
546: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
549: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
589: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,127
	btf_id 215
590: sched_cls  name handle_policy  tag 2acc1c47579e8007  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,127,76,77,126,35,74,125,33,78,69,34,31,32
	btf_id 216
591: sched_cls  name tail_handle_ipv4  tag e755c714337c0d18  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,127
	btf_id 217
592: sched_cls  name __send_drop_notify  tag 80bf7b38419a7f3b  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 218
593: sched_cls  name tail_ipv4_ct_ingress  tag 4d0e2d1c314ad75b  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,127,76,77,126,78
	btf_id 219
594: sched_cls  name cil_from_container  tag 65ce938c38d5fa5b  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 127,70
	btf_id 220
596: sched_cls  name tail_ipv4_ct_egress  tag 6d076636837bc68f  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,127,76,77,126,78
	btf_id 222
597: sched_cls  name tail_ipv4_to_endpoint  tag b0bdce8c3b01b482  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,126,35,76,77,74,125,33,127,34,31,32
	btf_id 223
598: sched_cls  name tail_handle_arp  tag b67e77c378df1e1a  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,127
	btf_id 224
599: sched_cls  name tail_handle_ipv4_cont  tag 77cc7232b68be1ff  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,126,35,125,76,77,33,70,68,71,127,34,31,32,75
	btf_id 225
600: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
603: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
616: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
619: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
620: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
623: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
624: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
627: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
