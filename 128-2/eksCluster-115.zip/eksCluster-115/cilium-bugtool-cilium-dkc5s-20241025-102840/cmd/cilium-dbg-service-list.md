ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.255.225:443 (active)    
                                          2 => 172.31.157.187:443 (active)    
2    10.100.90.11:443      ClusterIP      1 => 172.31.197.216:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.115.0.50:53 (active)        
                                          2 => 10.115.0.20:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.115.0.50:9153 (active)      
                                          2 => 10.115.0.20:9153 (active)      
5    10.100.205.204:2379   ClusterIP      1 => 10.115.0.160:2379 (active)     
