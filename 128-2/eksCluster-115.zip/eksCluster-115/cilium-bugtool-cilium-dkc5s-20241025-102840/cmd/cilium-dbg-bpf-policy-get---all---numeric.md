Endpoint ID: 349
Path: /sys/fs/bpf/tc/globals/cilium_policy_00349

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    85210   976       0        
Allow    Egress      0          ANY          NONE         disabled    14347   151       0        


Endpoint ID: 379
Path: /sys/fs/bpf/tc/globals/cilium_policy_00379

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    435513   5551      0        
Allow    Ingress     1          ANY          NONE         disabled    12852    149       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 967
Path: /sys/fs/bpf/tc/globals/cilium_policy_00967

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3889043   36207     0        
Allow    Ingress     1          ANY          NONE         disabled    2962251   29706     0        
Allow    Egress      0          ANY          NONE         disabled    4171209   38603     0        


Endpoint ID: 1286
Path: /sys/fs/bpf/tc/globals/cilium_policy_01286

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1425
Path: /sys/fs/bpf/tc/globals/cilium_policy_01425

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    84616   967       0        
Allow    Egress      0          ANY          NONE         disabled    14531   153       0        


