USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         692  0.0  0.0   2208   796 ?        Ss   10:28   0:00 timeout --signal SIGINT --preserve-status 5 bash -c hubble observe --last 10000 --debug -o jsonpb
root         697  0.0  0.2 1242676 10404 ?       Rl   10:28   0:00  \_ hubble observe --last 10000 --debug -o jsonpb
root         674  0.0  0.0 1228744 3596 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         668  0.0  0.4 1240432 16184 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         699  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         704  0.0  0.4 1240432 16184 ?       R    10:28   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         658  0.0  0.1 1229000 4048 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  3.0  7.1 1538164 282064 ?      Ssl  10:13   0:27 cilium-agent --config-dir=/tmp/cilium/config-map
root         389  0.0  0.1 1228848 5768 ?        Sl   10:14   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
