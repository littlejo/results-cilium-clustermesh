alloc: 97.61MB (102348280 bytes)
total-alloc: 1.33GB (1432105064 bytes)
sys: 210.45MB (220669268 bytes)
lookups: 0
mallocs: 47750240
frees: 46842897
heap-alloc: 97.61MB (102348280 bytes)
heap-sys: 165.11MB (173129728 bytes)
heap-idle: 44.44MB (46596096 bytes)
heap-in-use: 120.67MB (126533632 bytes)
heap-released: 2.80MB (2932736 bytes)
heap-objects: 907343
stack-in-use: 34.84MB (36536320 bytes)
stack-sys: 34.84MB (36536320 bytes)
stack-mspan-inuse: 1.96MB (2056480 bytes)
stack-mspan-sys: 2.46MB (2578560 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 889.42KB (910769 bytes)
gc-sys: 5.23MB (5480680 bytes)
next-gc: when heap-alloc >= 146.24MB (153340328 bytes)
last-gc: 2024-10-25 10:28:51.936660635 +0000 UTC
gc-pause-total: 6.50557ms
gc-pause: 96506
gc-pause-end: 1729852131936660635
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0003379295155439642
enable-gc: true
debug-gc: false
