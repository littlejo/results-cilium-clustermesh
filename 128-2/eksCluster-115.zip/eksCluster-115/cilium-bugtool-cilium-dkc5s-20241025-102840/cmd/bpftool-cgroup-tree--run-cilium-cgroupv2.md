CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod573f687d_70e2_4aa7_815b_49cb850a3b86.slice/cri-containerd-6415b6fabf206eb7f7f740e483ab046f2af72201c2b2dbc1c904a0dc3d0b2197.scope
    511      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod573f687d_70e2_4aa7_815b_49cb850a3b86.slice/cri-containerd-7f7fd63f50e27d5cbc4b8109a1e8dceaa5942dbf58c137b338afc1f80c3c8abb.scope
    545      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4953bcb9_d496_4976_8cf0_a89db9ad88fc.slice/cri-containerd-a9d7ab180c38bba234687b946829ac60a4d90f215f59e75c1378e8908f72b964.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4953bcb9_d496_4976_8cf0_a89db9ad88fc.slice/cri-containerd-e987306e45d8b3d0db6816875c5d60c1bef8ee73d84d6a47d0e825cf92c4cd75.scope
    498      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2d7120dd_6b62_4d92_80d7_b00817b5d4e9.slice/cri-containerd-80449d309f99c811223551beb2d24bf3f13f8ae95fbb8efa104658829c9886cd.scope
    113      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2d7120dd_6b62_4d92_80d7_b00817b5d4e9.slice/cri-containerd-53726bf228520bba3e7fbda87fdfaef2413c7d4c588866823b0c88dd43620d6d.scope
    71       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbbd1270b_c7b9_4452_8ec8_1f341f56a7bd.slice/cri-containerd-3ad7f4baedb4176f447dfd59688c40a4b15527f147a3a171b65c5ee25cd3f4cd.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbbd1270b_c7b9_4452_8ec8_1f341f56a7bd.slice/cri-containerd-37505774af1ccae7352335f834dd83d3be6f37bd656226a37b20f5bff77b3ae9.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7697d870_9cb6_4280_91f4_f0ec58bc77c9.slice/cri-containerd-074f550a62f5e0f89ef9d93bea3beecd916ae99c37f19818922321e64a9d4006.scope
    86       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7697d870_9cb6_4280_91f4_f0ec58bc77c9.slice/cri-containerd-fc4edaff111e37353dfff525a8af6f4b9e6d84e80e6610224fd10784f238b00a.scope
    78       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb14f9323_5a87_41ae_9f0e_81c012c9b50c.slice/cri-containerd-0cdc32777b64e72dc12b0dbb85b0e5a77be0a8547e014be947bfec2f2927d55d.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb14f9323_5a87_41ae_9f0e_81c012c9b50c.slice/cri-containerd-7b7218e3f736ba8fef1cfb7b926bfc2e221a6a730ed47a3c2578151a01ce89ff.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb14f9323_5a87_41ae_9f0e_81c012c9b50c.slice/cri-containerd-63fca6c1379098469aac2666bad4bdf685f258867a015fdfa8bf2984b214329a.scope
    619      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb14f9323_5a87_41ae_9f0e_81c012c9b50c.slice/cri-containerd-a3ed6a99c7297c3b2d27226c3750fdbe39adf1ef4e8fb330a4858d7c609ae72e.scope
    627      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddeb99d73_efae_4cef_a728_32f47b3a0529.slice/cri-containerd-49073aed3eb2ff14e5f9acfec35ca83d408ae4c2790723d05788a105138cd378.scope
    82       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddeb99d73_efae_4cef_a728_32f47b3a0529.slice/cri-containerd-91dc0db6a4cf6d116692e212cd3ba95c45d74cb21bf1f5d2c4c6882502d34892.scope
    67       cgroup_device   multi                                          
