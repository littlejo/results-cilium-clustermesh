IP ADDRESS         LOCAL ENDPOINT INFO
172.31.197.216:0   (localhost)                                                                                        
10.115.0.160:0     id=967   sec_id=7610633 flags=0x0000 ifindex=15  mac=AA:9B:A7:F8:0D:3B nodemac=72:52:44:3A:62:73   
10.115.0.50:0      id=1425  sec_id=7610734 flags=0x0000 ifindex=11  mac=B6:19:D0:BD:BD:A4 nodemac=4A:5A:DE:FA:03:24   
10.115.0.20:0      id=349   sec_id=7610734 flags=0x0000 ifindex=9   mac=AA:B5:F9:18:EC:6B nodemac=86:DD:5B:5D:2D:33   
10.115.0.166:0     (localhost)                                                                                        
10.115.0.242:0     id=379   sec_id=4     flags=0x0000 ifindex=7   mac=22:5E:04:4A:52:7D nodemac=3A:40:11:24:33:2D     
