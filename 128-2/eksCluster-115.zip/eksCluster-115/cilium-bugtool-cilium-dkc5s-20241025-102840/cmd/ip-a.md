1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:bf:39:07:61:75 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.197.216/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2681sec preferred_lft 2681sec
    inet6 fe80::8bf:39ff:fe07:6175/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:c9:fe:27:b9:63 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::dcc9:feff:fe27:b963/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:34:93:66:12:5f brd ff:ff:ff:ff:ff:ff
    inet 10.115.0.166/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d034:93ff:fe66:125f/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ba:48:e6:58:92:55 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b848:e6ff:fe58:9255/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:40:11:24:33:2d brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::3840:11ff:fe24:332d/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc1ab238018414@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:dd:5b:5d:2d:33 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::84dd:5bff:fe5d:2d33/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc135223c003ec@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:5a:de:fa:03:24 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::485a:deff:fefa:324/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc6c060c7a85a6@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:52:44:3a:62:73 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::7052:44ff:fe3a:6273/64 scope link 
       valid_lft forever preferred_lft forever
