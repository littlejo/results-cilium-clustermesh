top - 10:28:42 up 15 min,  0 users,  load average: 0.18, 0.22, 0.18
Tasks:   9 total,   3 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 44.8 us, 41.4 sy,  0.0 ni,  6.9 id,  0.0 wa,  0.0 hi,  6.9 si,  0.0 st
MiB Mem :   3836.2 total,   1025.9 free,    892.2 used,   1918.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2775.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    697 root      20   0 1244596  23056  14588 S  66.7   0.6   0:00.17 hubble
      1 root      20   0 1538164 282064  78464 R   6.7   7.2   0:27.30 cilium-+
    389 root      20   0 1228848   5768   2872 S   0.0   0.1   0:00.27 cilium-+
    658 root      20   0 1229000   4048   3392 S   0.0   0.1   0:00.00 gops
    668 root      20   0 1240432  16888  11356 S   0.0   0.4   0:00.03 cilium-+
    674 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    692 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    717 root      20   0    6576   2432   2104 R   0.0   0.1   0:00.00 top
    723 root      20   0       4      4      0 R   0.0   0.0   0:00.00 bash
