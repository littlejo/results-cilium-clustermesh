fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxc1ab238018414 proto kernel metric 256 pref medium
fe80::/64 dev lxc135223c003ec proto kernel metric 256 pref medium
fe80::/64 dev lxc6c060c7a85a6 proto kernel metric 256 pref medium
