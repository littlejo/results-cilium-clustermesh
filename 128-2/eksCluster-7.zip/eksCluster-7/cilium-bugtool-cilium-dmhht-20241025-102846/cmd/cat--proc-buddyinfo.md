Node 0, zone      DMA     67     43      2      2      7      8     55     28     10      3    163 
Node 0, zone   Normal      4      0      1      1      2      1      2      4      3      2      8 
