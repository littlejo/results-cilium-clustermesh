IP ADDRESS        LOCAL ENDPOINT INFO
10.7.0.112:0      id=2897  sec_id=553023 flags=0x0000 ifindex=11  mac=56:A4:83:A7:F6:FA nodemac=6E:93:8A:FE:F0:B3   
10.7.0.57:0       id=369   sec_id=528033 flags=0x0000 ifindex=15  mac=9E:75:55:FC:AD:C4 nodemac=A2:85:A6:60:8B:97   
10.7.0.135:0      id=1596  sec_id=4     flags=0x0000 ifindex=7   mac=EE:9A:42:F9:3E:7A nodemac=F6:08:2C:50:3A:74    
172.31.194.36:0   (localhost)                                                                                       
10.7.0.150:0      (localhost)                                                                                       
10.7.0.193:0      id=656   sec_id=553023 flags=0x0000 ifindex=9   mac=22:BE:B2:0C:FB:06 nodemac=76:4E:80:90:2B:4B   
