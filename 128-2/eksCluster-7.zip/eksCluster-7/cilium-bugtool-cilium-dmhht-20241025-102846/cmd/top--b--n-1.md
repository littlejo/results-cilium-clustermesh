top - 10:28:48 up 15 min,  0 users,  load average: 1.21, 0.50, 0.28
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 72.4 us, 20.7 sy,  0.0 ni,  3.4 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   3836.2 total,    800.2 free,    893.8 used,   2142.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2773.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538292 283256  79040 S  60.0   7.2   0:24.26 cilium-+
    645 root      20   0 1240432  16024  11292 S   6.7   0.4   0:00.03 cilium-+
    394 root      20   0 1228848   6056   2928 S   0.0   0.2   0:00.28 cilium-+
    706 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    713 root      20   0    6576   2416   2092 R   0.0   0.1   0:00.00 top
    740 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
