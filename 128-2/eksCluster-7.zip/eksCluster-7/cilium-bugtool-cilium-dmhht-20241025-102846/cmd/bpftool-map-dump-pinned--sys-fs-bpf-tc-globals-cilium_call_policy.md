key: 71 01 00 00  value: 54 02 00 00
key: 90 02 00 00  value: e5 01 00 00
key: 3c 06 00 00  value: f6 01 00 00
key: 51 0b 00 00  value: 04 02 00 00
Found 4 elements
