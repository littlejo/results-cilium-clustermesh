 10:28:48 up 15 min,  0 users,  load average: 1.21, 0.50, 0.28
