xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 541
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 532
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 522
cilium_host(4) clsact/egress cil_from_host-cilium_host id 524
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 456
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 457
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 501
lxc12bd326d4ea0(9) clsact/ingress cil_from_container-lxc12bd326d4ea0 id 481
lxca52d2551286b(11) clsact/ingress cil_from_container-lxca52d2551286b id 513
lxc96d5df1aaed3(15) clsact/ingress cil_from_container-lxc96d5df1aaed3 id 600

flow_dissector:

netfilter:

