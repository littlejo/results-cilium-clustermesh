1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:53:ee:68:72:df brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.194.36/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2660sec preferred_lft 2660sec
    inet6 fe80::853:eeff:fe68:72df/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:e3:2b:a4:cc:05 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::70e3:2bff:fea4:cc05/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:a2:f6:f4:30:b9 brd ff:ff:ff:ff:ff:ff
    inet 10.7.0.150/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::98a2:f6ff:fef4:30b9/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ce:e2:c9:23:09:2a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::cce2:c9ff:fe23:92a/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:08:2c:50:3a:74 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f408:2cff:fe50:3a74/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc12bd326d4ea0@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:4e:80:90:2b:4b brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::744e:80ff:fe90:2b4b/64 scope link 
       valid_lft forever preferred_lft forever
11: lxca52d2551286b@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:93:8a:fe:f0:b3 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::6c93:8aff:fefe:f0b3/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc96d5df1aaed3@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:85:a6:60:8b:97 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::a085:a6ff:fe60:8b97/64 scope link 
       valid_lft forever preferred_lft forever
