CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47ff4120_51ef_47c4_a075_c1b6b8279a7c.slice/cri-containerd-f96b4ab6039910748d6a8e0b45807cd559e5ee5f50421db4929769feaa75b626.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47ff4120_51ef_47c4_a075_c1b6b8279a7c.slice/cri-containerd-5b6220853088dc1118ca2a4682290aae531f4b5d08fad2a95f13007778cd4b09.scope
    521      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod32d6e806_cb5e_4c51_882a_8bf82dd244fb.slice/cri-containerd-79b868c693a5ee0f282361d93a6b7b0dc736d20dd163fb0b1a44f8d6bade9d17.scope
    64       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod32d6e806_cb5e_4c51_882a_8bf82dd244fb.slice/cri-containerd-f32bc2572769a5ad151f3c36a297882e73301b289477b1599d9a30045c03556a.scope
    114      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod19110f55_64ee_4483_9dc7_e3ffe9f10f78.slice/cri-containerd-d928a32771bb34508d22320b7ddabc63eb6553c544c09f0e91d24061a3cc4774.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod19110f55_64ee_4483_9dc7_e3ffe9f10f78.slice/cri-containerd-ffd5869d1d62d490338784ccb024ee8964587eb9341b89a82c06c5b184118105.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod056c202a_7fdc_4c52_a1e9_8cacbdaa722a.slice/cri-containerd-5bd6fe82178d2b4890b3a22476c7490e41272ebea72869d1d8bdf174f669e838.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod056c202a_7fdc_4c52_a1e9_8cacbdaa722a.slice/cri-containerd-4d61793ac4ddb6d854f4926e647eaa1663d26b397636d062f6917859a329ab27.scope
    499      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc60ee3f0_c992_45da_b95f_8186f16a918b.slice/cri-containerd-5e0d084e960025810d25bf821803b24764e5943f7eeb1f4311d7e8e64296e4c3.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc60ee3f0_c992_45da_b95f_8186f16a918b.slice/cri-containerd-a6bfb158356b6d20d127138de749aca5917ab62576e1e42b5093f4851e2dcf12.scope
    83       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod14607512_1cd4_4f41_bb6c_4871507ea56a.slice/cri-containerd-01a0876d7b818d4ef5293a567af9a3004e16ad8b55985eb30cc743391864cc0a.scope
    628      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod14607512_1cd4_4f41_bb6c_4871507ea56a.slice/cri-containerd-7cefe7ed7c22f3cba780b33077fb7f0049d01c93dbda43ce2cccfba2b0bd1bca.scope
    604      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod14607512_1cd4_4f41_bb6c_4871507ea56a.slice/cri-containerd-1d877acb7afd2b5975df94f75d6a41e394b53dfc05fc5aa08a8221c42a4f7a7b.scope
    620      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod14607512_1cd4_4f41_bb6c_4871507ea56a.slice/cri-containerd-c178cc84c0d4c5086488f7947699ada007ce2d6d9e78c64229e10c771c11e1ab.scope
    624      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1c391b3a_6bce_4078_8bd7_49cf08473363.slice/cri-containerd-72df5506533a5e4c2370794161cb382cfce7fb597274a657dc7a3c87f9426d62.scope
    76       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1c391b3a_6bce_4078_8bd7_49cf08473363.slice/cri-containerd-774d3e5a88b2ec4701f08f4da3209c6d31120a0aeda7bd25edf4168b5289859c.scope
    87       cgroup_device   multi                                          
