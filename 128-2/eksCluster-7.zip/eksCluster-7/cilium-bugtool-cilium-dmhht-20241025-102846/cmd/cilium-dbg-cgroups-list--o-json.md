[
  {
    "containers": [
      {
        "cgroup-id": 7278,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod056c202a_7fdc_4c52_a1e9_8cacbdaa722a.slice/cri-containerd-5bd6fe82178d2b4890b3a22476c7490e41272ebea72869d1d8bdf174f669e838.scope"
      }
    ],
    "ips": [
      "10.7.0.193"
    ],
    "name": "coredns-cc6ccd49c-2tfkx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7194,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47ff4120_51ef_47c4_a075_c1b6b8279a7c.slice/cri-containerd-f96b4ab6039910748d6a8e0b45807cd559e5ee5f50421db4929769feaa75b626.scope"
      }
    ],
    "ips": [
      "10.7.0.112"
    ],
    "name": "coredns-cc6ccd49c-c9tq6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8706,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod14607512_1cd4_4f41_bb6c_4871507ea56a.slice/cri-containerd-c178cc84c0d4c5086488f7947699ada007ce2d6d9e78c64229e10c771c11e1ab.scope"
      },
      {
        "cgroup-id": 8622,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod14607512_1cd4_4f41_bb6c_4871507ea56a.slice/cri-containerd-1d877acb7afd2b5975df94f75d6a41e394b53dfc05fc5aa08a8221c42a4f7a7b.scope"
      },
      {
        "cgroup-id": 8790,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod14607512_1cd4_4f41_bb6c_4871507ea56a.slice/cri-containerd-01a0876d7b818d4ef5293a567af9a3004e16ad8b55985eb30cc743391864cc0a.scope"
      }
    ],
    "ips": [
      "10.7.0.57"
    ],
    "name": "clustermesh-apiserver-6dfbb8d56f-hztz6",
    "namespace": "kube-system"
  }
]

