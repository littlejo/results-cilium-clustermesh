ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.175.193:443 (active)   
                                          2 => 172.31.225.16:443 (active)    
2    10.100.235.36:443     ClusterIP      1 => 172.31.194.36:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.7.0.112:53 (active)        
                                          2 => 10.7.0.193:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.7.0.112:9153 (active)      
                                          2 => 10.7.0.193:9153 (active)      
5    10.100.164.102:2379   ClusterIP      1 => 10.7.0.57:2379 (active)       
