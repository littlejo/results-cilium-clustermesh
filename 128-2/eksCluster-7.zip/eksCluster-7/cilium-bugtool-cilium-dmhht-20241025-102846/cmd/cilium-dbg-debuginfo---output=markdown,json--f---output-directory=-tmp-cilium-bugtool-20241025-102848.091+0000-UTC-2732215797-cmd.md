markdown output at /tmp/cilium-bugtool-20241025-102848.091+0000-UTC-2732215797/cmd/cilium-debuginfo-20241025-102918.881+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102848.091+0000-UTC-2732215797/cmd/cilium-debuginfo-20241025-102918.881+0000-UTC.json
