29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:01+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:01+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:01+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:01+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:01+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:01+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:02+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:02+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:02+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:02+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:05+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
61: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
64: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
73: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
76: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
80: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
83: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
111: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
114: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
455: sched_cls  name tail_handle_ipv4  tag 28f67a55c332ea97  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 71,70,77,72,93
	btf_id 114
456: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 72,93
	btf_id 115
457: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 116
458: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 117
481: sched_cls  name cil_from_container  tag b4a99257cb8dc8db  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 101,72
	btf_id 143
483: sched_cls  name tail_handle_ipv4_cont  tag f2cc2de346685a22  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,100,37,95,78,79,35,72,70,73,101,36,33,34,77
	btf_id 145
484: sched_cls  name tail_handle_ipv4  tag c4a10c907e2411a0  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,101
	btf_id 146
485: sched_cls  name handle_policy  tag 1ce7a8031fc45826  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,101,78,79,100,37,76,95,35,80,71,36,33,34
	btf_id 147
486: sched_cls  name tail_ipv4_ct_egress  tag af7fb3ab2b969ed3  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,101,78,79,100,80
	btf_id 148
487: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,101
	btf_id 149
488: sched_cls  name tail_ipv4_to_endpoint  tag 76c7ed8ce67a1036  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,100,37,78,79,76,95,35,101,36,33,34
	btf_id 150
489: sched_cls  name __send_drop_notify  tag 2cc45bb7fc361813  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 151
490: sched_cls  name tail_handle_arp  tag cceb5529c40b7c5a  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,101
	btf_id 152
491: sched_cls  name tail_ipv4_ct_ingress  tag 4373eb91e17568e4  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,101,78,79,100,80
	btf_id 153
492: sched_cls  name tail_handle_ipv4  tag 5f6be4b463b9ac3a  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,102
	btf_id 155
494: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 72,102,78,79,103,80
	btf_id 157
495: sched_cls  name tail_handle_arp  tag 5fd8a275548d2a25  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,102
	btf_id 158
496: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
499: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
500: sched_cls  name tail_ipv4_to_endpoint  tag fc80b8ebd4b042ad  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 71,72,103,37,78,79,76,94,35,102,36,33,34
	btf_id 159
501: sched_cls  name cil_from_container  tag 2dec1eb7e8cb82ed  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 102,72
	btf_id 160
502: sched_cls  name handle_policy  tag b173b3b151bc913f  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 72,102,78,79,103,37,76,94,35,80,71,36,33,34
	btf_id 161
503: sched_cls  name tail_handle_ipv4_cont  tag 9ab25c542af3145b  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 71,103,37,94,78,79,35,72,70,73,102,36,33,34,77
	btf_id 162
504: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,102
	btf_id 163
505: sched_cls  name __send_drop_notify  tag 370de80db04f6744  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 164
506: sched_cls  name tail_ipv4_ct_ingress  tag 8415c5bf0535df3c  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 72,102,78,79,103,80
	btf_id 165
507: sched_cls  name tail_ipv4_to_endpoint  tag c8902d1510708cc4  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,106,37,78,79,76,105,35,107,36,33,34
	btf_id 167
508: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,107
	btf_id 168
509: sched_cls  name tail_handle_ipv4  tag 00dafcbafa95fde9  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,107
	btf_id 169
510: sched_cls  name tail_ipv4_ct_ingress  tag 4150b3cfa4a2b9cd  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,107,78,79,106,80
	btf_id 170
512: sched_cls  name __send_drop_notify  tag 97c89bf444e0453e  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 172
513: sched_cls  name cil_from_container  tag 582f43253d7a90fe  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 107,72
	btf_id 173
514: sched_cls  name tail_handle_ipv4_cont  tag 6d90cc7df1fec044  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,106,37,105,78,79,35,72,70,73,107,36,33,34,77
	btf_id 174
515: sched_cls  name tail_ipv4_ct_egress  tag af7fb3ab2b969ed3  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,107,78,79,106,80
	btf_id 175
516: sched_cls  name handle_policy  tag ecec9da1d75f053c  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,107,78,79,106,37,76,105,35,80,71,36,33,34
	btf_id 176
517: sched_cls  name tail_handle_arp  tag a4176331908d01c5  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,107
	btf_id 177
518: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
521: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
522: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 179
524: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 72,71,109
	btf_id 181
526: sched_cls  name tail_handle_ipv4_from_host  tag e943f7fb11919573  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,109
	btf_id 183
527: sched_cls  name __send_drop_notify  tag 9ad2f8fd9b2053bd  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 184
528: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,109
	btf_id 185
529: sched_cls  name tail_handle_ipv4_from_host  tag e943f7fb11919573  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,112
	btf_id 187
530: sched_cls  name __send_drop_notify  tag 9ad2f8fd9b2053bd  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 188
531: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,112
	btf_id 189
532: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 190
537: sched_cls  name tail_handle_ipv4_from_host  tag e943f7fb11919573  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,113
	btf_id 196
538: sched_cls  name __send_drop_notify  tag 9ad2f8fd9b2053bd  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 197
539: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,113
	btf_id 198
541: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 72,113,71
	btf_id 200
543: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
546: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
547: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
550: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
590: sched_cls  name tail_ipv4_ct_ingress  tag 6ae4c0e62fb096ae  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,128,78,79,129,80
	btf_id 217
591: sched_cls  name tail_handle_ipv4_cont  tag eca1f383a1c660d0  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,129,37,127,78,79,35,72,70,73,128,36,33,34,77
	btf_id 218
593: sched_cls  name tail_handle_arp  tag debc210a77f4ccc4  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,128
	btf_id 220
594: sched_cls  name tail_ipv4_ct_egress  tag 1b550ce0c921782f  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,128,78,79,129,80
	btf_id 221
595: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,128
	btf_id 222
596: sched_cls  name handle_policy  tag b11fe7730c719b43  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,128,78,79,129,37,76,127,35,80,71,36,33,34
	btf_id 223
597: sched_cls  name __send_drop_notify  tag 20398a4879c94a6a  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 224
598: sched_cls  name tail_handle_ipv4  tag bdddb5a1111e83cf  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,128
	btf_id 225
599: sched_cls  name tail_ipv4_to_endpoint  tag 18395c57e3859bea  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,129,37,78,79,76,127,35,128,36,33,34
	btf_id 226
600: sched_cls  name cil_from_container  tag 1bc3ce3f28f1d002  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 128,72
	btf_id 227
601: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
604: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
617: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
620: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
621: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
624: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
625: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
628: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
