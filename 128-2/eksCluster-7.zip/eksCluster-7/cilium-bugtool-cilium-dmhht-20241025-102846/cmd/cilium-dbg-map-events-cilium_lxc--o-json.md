{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:48.346Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.194.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:48.346Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.771Z",
  "value": "id=656   sec_id=553023 flags=0x0000 ifindex=9   mac=22:BE:B2:0C:FB:06 nodemac=76:4E:80:90:2B:4B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.778Z",
  "value": "id=1596  sec_id=4     flags=0x0000 ifindex=7   mac=EE:9A:42:F9:3E:7A nodemac=F6:08:2C:50:3A:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.840Z",
  "value": "id=656   sec_id=553023 flags=0x0000 ifindex=9   mac=22:BE:B2:0C:FB:06 nodemac=76:4E:80:90:2B:4B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.920Z",
  "value": "id=1596  sec_id=4     flags=0x0000 ifindex=7   mac=EE:9A:42:F9:3E:7A nodemac=F6:08:2C:50:3A:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:53.508Z",
  "value": "id=2897  sec_id=553023 flags=0x0000 ifindex=11  mac=56:A4:83:A7:F6:FA nodemac=6E:93:8A:FE:F0:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:21.017Z",
  "value": "id=1596  sec_id=4     flags=0x0000 ifindex=7   mac=EE:9A:42:F9:3E:7A nodemac=F6:08:2C:50:3A:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:21.017Z",
  "value": "id=656   sec_id=553023 flags=0x0000 ifindex=9   mac=22:BE:B2:0C:FB:06 nodemac=76:4E:80:90:2B:4B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:21.018Z",
  "value": "id=2897  sec_id=553023 flags=0x0000 ifindex=11  mac=56:A4:83:A7:F6:FA nodemac=6E:93:8A:FE:F0:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:21.047Z",
  "value": "id=3796  sec_id=528033 flags=0x0000 ifindex=13  mac=52:73:58:85:BE:12 nodemac=52:83:10:88:40:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:22.016Z",
  "value": "id=656   sec_id=553023 flags=0x0000 ifindex=9   mac=22:BE:B2:0C:FB:06 nodemac=76:4E:80:90:2B:4B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:22.016Z",
  "value": "id=1596  sec_id=4     flags=0x0000 ifindex=7   mac=EE:9A:42:F9:3E:7A nodemac=F6:08:2C:50:3A:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:22.016Z",
  "value": "id=2897  sec_id=553023 flags=0x0000 ifindex=11  mac=56:A4:83:A7:F6:FA nodemac=6E:93:8A:FE:F0:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:22.017Z",
  "value": "id=3796  sec_id=528033 flags=0x0000 ifindex=13  mac=52:73:58:85:BE:12 nodemac=52:83:10:88:40:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:31.919Z",
  "value": "id=369   sec_id=528033 flags=0x0000 ifindex=15  mac=9E:75:55:FC:AD:C4 nodemac=A2:85:A6:60:8B:97"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.7.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:38.066Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.644Z",
  "value": "id=1596  sec_id=4     flags=0x0000 ifindex=7   mac=EE:9A:42:F9:3E:7A nodemac=F6:08:2C:50:3A:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.644Z",
  "value": "id=656   sec_id=553023 flags=0x0000 ifindex=9   mac=22:BE:B2:0C:FB:06 nodemac=76:4E:80:90:2B:4B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.645Z",
  "value": "id=2897  sec_id=553023 flags=0x0000 ifindex=11  mac=56:A4:83:A7:F6:FA nodemac=6E:93:8A:FE:F0:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.645Z",
  "value": "id=369   sec_id=528033 flags=0x0000 ifindex=15  mac=9E:75:55:FC:AD:C4 nodemac=A2:85:A6:60:8B:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:10.644Z",
  "value": "id=656   sec_id=553023 flags=0x0000 ifindex=9   mac=22:BE:B2:0C:FB:06 nodemac=76:4E:80:90:2B:4B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:10.645Z",
  "value": "id=2897  sec_id=553023 flags=0x0000 ifindex=11  mac=56:A4:83:A7:F6:FA nodemac=6E:93:8A:FE:F0:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:10.645Z",
  "value": "id=1596  sec_id=4     flags=0x0000 ifindex=7   mac=EE:9A:42:F9:3E:7A nodemac=F6:08:2C:50:3A:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:10.645Z",
  "value": "id=369   sec_id=528033 flags=0x0000 ifindex=15  mac=9E:75:55:FC:AD:C4 nodemac=A2:85:A6:60:8B:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:11.645Z",
  "value": "id=2897  sec_id=553023 flags=0x0000 ifindex=11  mac=56:A4:83:A7:F6:FA nodemac=6E:93:8A:FE:F0:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:11.645Z",
  "value": "id=1596  sec_id=4     flags=0x0000 ifindex=7   mac=EE:9A:42:F9:3E:7A nodemac=F6:08:2C:50:3A:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:11.646Z",
  "value": "id=369   sec_id=528033 flags=0x0000 ifindex=15  mac=9E:75:55:FC:AD:C4 nodemac=A2:85:A6:60:8B:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.7.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:11.646Z",
  "value": "id=656   sec_id=553023 flags=0x0000 ifindex=9   mac=22:BE:B2:0C:FB:06 nodemac=76:4E:80:90:2B:4B"
}

