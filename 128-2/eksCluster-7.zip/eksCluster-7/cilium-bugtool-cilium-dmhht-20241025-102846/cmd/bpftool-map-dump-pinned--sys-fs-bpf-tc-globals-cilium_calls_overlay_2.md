key: 01 00 00 00  value: ca 01 00 00
key: 07 00 00 00  value: c7 01 00 00
Found 2 elements
