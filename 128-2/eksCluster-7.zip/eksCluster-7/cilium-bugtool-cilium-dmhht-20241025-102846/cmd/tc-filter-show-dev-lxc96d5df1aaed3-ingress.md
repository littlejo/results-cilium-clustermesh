filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc96d5df1aaed3 direct-action not_in_hw id 600 tag 1bc3ce3f28f1d002 jited 
