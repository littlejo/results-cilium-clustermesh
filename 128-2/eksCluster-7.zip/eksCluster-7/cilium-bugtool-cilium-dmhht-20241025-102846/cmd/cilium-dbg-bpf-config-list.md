KEY             VALUE
AgentLiveness   980903387352
UTimeOffset     3378615582031250
