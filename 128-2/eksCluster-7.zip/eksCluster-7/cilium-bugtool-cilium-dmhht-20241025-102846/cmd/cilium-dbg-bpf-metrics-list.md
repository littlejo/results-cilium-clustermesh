REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     217863    100169174   1132   bpf_host.c
Interface                 INGRESS     9549      745273      677    bpf_overlay.c
Success                   EGRESS      4613      351899      1694   bpf_host.c
Success                   EGRESS      90717     12206080    1308   bpf_lxc.c
Success                   EGRESS      9388      734028      53     encap.h
Success                   INGRESS     101584    12421842    86     l3.h
Success                   INGRESS     107169    12859122    235    trace.h
Unsupported L3 protocol   EGRESS      43        3258        1492   bpf_lxc.c
