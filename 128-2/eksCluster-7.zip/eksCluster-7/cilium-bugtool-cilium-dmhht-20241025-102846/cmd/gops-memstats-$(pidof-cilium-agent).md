alloc: 137.51MB (144185848 bytes)
total-alloc: 1.34GB (1437100024 bytes)
sys: 206.57MB (216606036 bytes)
lookups: 0
mallocs: 47847575
frees: 46425414
heap-alloc: 137.51MB (144185848 bytes)
heap-sys: 161.08MB (168902656 bytes)
heap-idle: 6.03MB (6324224 bytes)
heap-in-use: 155.05MB (162578432 bytes)
heap-released: 920.00KB (942080 bytes)
heap-objects: 1422161
stack-in-use: 34.88MB (36569088 bytes)
stack-sys: 34.88MB (36569088 bytes)
stack-mspan-inuse: 2.42MB (2532640 bytes)
stack-mspan-sys: 2.52MB (2643840 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 873.66KB (894625 bytes)
gc-sys: 5.34MB (5595272 bytes)
next-gc: when heap-alloc >= 145.26MB (152316440 bytes)
last-gc: 2024-10-25 10:28:37.760341545 +0000 UTC
gc-pause-total: 7.467398ms
gc-pause: 95680
gc-pause-end: 1729852117760341545
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0002644377854404281
enable-gc: true
debug-gc: false
