Endpoint ID: 369
Path: /sys/fs/bpf/tc/globals/cilium_policy_00369

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3913441   36501     0        
Allow    Ingress     1          ANY          NONE         disabled    2966376   29830     0        
Allow    Egress      0          ANY          NONE         disabled    4236180   39353     0        


Endpoint ID: 656
Path: /sys/fs/bpf/tc/globals/cilium_policy_00656

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    87215   1002      0        
Allow    Egress      0          ANY          NONE         disabled    14124   148       0        


Endpoint ID: 1596
Path: /sys/fs/bpf/tc/globals/cilium_policy_01596

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    440382   5626      0        
Allow    Ingress     1          ANY          NONE         disabled    12396    143       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2897
Path: /sys/fs/bpf/tc/globals/cilium_policy_02897

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    85763   980       0        
Allow    Egress      0          ANY          NONE         disabled    14232   150       0        


Endpoint ID: 3173
Path: /sys/fs/bpf/tc/globals/cilium_policy_03173

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


