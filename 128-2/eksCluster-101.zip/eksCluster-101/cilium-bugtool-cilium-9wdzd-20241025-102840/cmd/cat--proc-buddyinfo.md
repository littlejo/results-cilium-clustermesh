Node 0, zone      DMA     85     36      2      2      8     10      4      1      4      3    163 
Node 0, zone   Normal    390     56     11     38     23      3      1      1      2      1      8 
