KEY             VALUE
AgentLiveness   841558187197
UTimeOffset     3378615841796875
