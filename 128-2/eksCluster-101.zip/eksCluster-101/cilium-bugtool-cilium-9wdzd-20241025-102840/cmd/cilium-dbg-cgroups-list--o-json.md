[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95d72bef_863c_4fe7_bb6f_9f8a98736c0e.slice/cri-containerd-1f4354aec39da744160072d4842e687f4f8690ab600f46bce69be08ecabee651.scope"
      }
    ],
    "ips": [
      "10.101.0.228"
    ],
    "name": "coredns-cc6ccd49c-48lj6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod75471e5f_09a9_4356_979a_82a80fffb03e.slice/cri-containerd-65b7e09b245aa4a6e62b2e1e0cb0b40a88078c20c3bc601fc7f96d3463e6dae0.scope"
      }
    ],
    "ips": [
      "10.101.0.128"
    ],
    "name": "coredns-cc6ccd49c-f4p48",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71bbe8f2_0eeb_400d_8ffc_5d4cf4eff256.slice/cri-containerd-d0b46050e98da48079328cbb2fd21edcdd5c6ad66a6518ea26e88e2def50b420.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71bbe8f2_0eeb_400d_8ffc_5d4cf4eff256.slice/cri-containerd-2abf5f5cb3391ae7d4561961f3af5ca08fc47623fac209fafaf886e0d6ececfe.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71bbe8f2_0eeb_400d_8ffc_5d4cf4eff256.slice/cri-containerd-e0899dba929e9c8c3f13d7e56a2cd2dc4f6f04978b0981ae9538bc7fbe05b8d0.scope"
      }
    ],
    "ips": [
      "10.101.0.119"
    ],
    "name": "clustermesh-apiserver-765c658dd5-5hlbs",
    "namespace": "kube-system"
  }
]

