REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     214766    84199940   1132   bpf_host.c
Interface                 INGRESS     9471      740436     677    bpf_overlay.c
Success                   EGRESS      4608      351577     1694   bpf_host.c
Success                   EGRESS      90192     12110985   1308   bpf_lxc.c
Success                   EGRESS      9324      728953     53     encap.h
Success                   INGRESS     101185    12451390   86     l3.h
Success                   INGRESS     106697    12884155   235    trace.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
