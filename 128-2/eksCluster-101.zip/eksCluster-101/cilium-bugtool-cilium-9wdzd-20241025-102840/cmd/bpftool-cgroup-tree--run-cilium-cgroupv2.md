CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95d72bef_863c_4fe7_bb6f_9f8a98736c0e.slice/cri-containerd-1f4354aec39da744160072d4842e687f4f8690ab600f46bce69be08ecabee651.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95d72bef_863c_4fe7_bb6f_9f8a98736c0e.slice/cri-containerd-a3327370142e4d8cc435253685415522e04646923010c15925fc8e06fbeaac5c.scope
    537      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd1550349_27ae_41ba_9aa1_763730217200.slice/cri-containerd-ea96c71cdd342c82b4fc32bdfe60eac2721586997df300fcf22b52af5e21ff1e.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd1550349_27ae_41ba_9aa1_763730217200.slice/cri-containerd-9924b4476dfc3ba9d4d202f3a36fb14b629a28398054fa3c96e95174125402cb.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod75471e5f_09a9_4356_979a_82a80fffb03e.slice/cri-containerd-521961bc4a893419b4fe13fd81523c83692723b009a47dc023b7b3e6c14a5546.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod75471e5f_09a9_4356_979a_82a80fffb03e.slice/cri-containerd-65b7e09b245aa4a6e62b2e1e0cb0b40a88078c20c3bc601fc7f96d3463e6dae0.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod55003bfe_6a90_4842_aa64_d6f9d1b5edfe.slice/cri-containerd-afdc376b161d577aef4832e6c5d1ad5286a2eba07849784707e6b0080bc33851.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod55003bfe_6a90_4842_aa64_d6f9d1b5edfe.slice/cri-containerd-ff9eadc8650e8243151d4917bd5981a0d1e462fc97d4d6d3e31ab3ee03e43c3d.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62aa37c3_bcf6_42d7_8a17_e6545386d8ae.slice/cri-containerd-05f04698d2accebc379752d3ab2d858a6fc311224547fcdde8ab8bb2fd8ac408.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62aa37c3_bcf6_42d7_8a17_e6545386d8ae.slice/cri-containerd-e54cb9118dbfb490746d380690ce4fe9670d6662d6bd458898f95e7d31ce0424.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71bbe8f2_0eeb_400d_8ffc_5d4cf4eff256.slice/cri-containerd-e9378ca1ecdd59ec9d08d6db92cadbd07aa5c2dd452e9ccb69bf5509d6e101cb.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71bbe8f2_0eeb_400d_8ffc_5d4cf4eff256.slice/cri-containerd-2abf5f5cb3391ae7d4561961f3af5ca08fc47623fac209fafaf886e0d6ececfe.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71bbe8f2_0eeb_400d_8ffc_5d4cf4eff256.slice/cri-containerd-d0b46050e98da48079328cbb2fd21edcdd5c6ad66a6518ea26e88e2def50b420.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod71bbe8f2_0eeb_400d_8ffc_5d4cf4eff256.slice/cri-containerd-e0899dba929e9c8c3f13d7e56a2cd2dc4f6f04978b0981ae9538bc7fbe05b8d0.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0e226ce5_9ac2_46ba_bb8a_778f109de72f.slice/cri-containerd-379d1da34d2e4a20548cd1f0ba95b774e6d2ff736b7940fdf55ec153a146197d.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0e226ce5_9ac2_46ba_bb8a_778f109de72f.slice/cri-containerd-36ed9b5318a3afe310b1046007a6e3d511d009454769db29737b9401e8d7664e.scope
    97       cgroup_device   multi                                          
