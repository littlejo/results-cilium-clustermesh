alloc: 137.98MB (144687536 bytes)
total-alloc: 1.32GB (1416549288 bytes)
sys: 210.45MB (220669268 bytes)
lookups: 0
mallocs: 47606889
frees: 46161866
heap-alloc: 137.98MB (144687536 bytes)
heap-sys: 162.95MB (170868736 bytes)
heap-idle: 6.94MB (7274496 bytes)
heap-in-use: 156.02MB (163594240 bytes)
heap-released: 2.47MB (2588672 bytes)
heap-objects: 1445023
stack-in-use: 36.78MB (38567936 bytes)
stack-sys: 36.78MB (38567936 bytes)
stack-mspan-inuse: 2.45MB (2569440 bytes)
stack-mspan-sys: 2.57MB (2692800 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 808.82KB (828233 bytes)
gc-sys: 5.46MB (5728584 bytes)
next-gc: when heap-alloc >= 142.87MB (149806232 bytes)
last-gc: 2024-10-25 10:28:28.415676692 +0000 UTC
gc-pause-total: 10.202127ms
gc-pause: 71450
gc-pause-end: 1729852108415676692
num-gc: 70
num-forced-gc: 0
gc-cpu-fraction: 0.00034496560876196773
enable-gc: true
debug-gc: false
