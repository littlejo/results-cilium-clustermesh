IP ADDRESS         LOCAL ENDPOINT INFO
172.31.195.223:0   (localhost)                                                                                        
172.31.244.190:0   (localhost)                                                                                        
10.101.0.128:0     id=2084  sec_id=6707244 flags=0x0000 ifindex=14  mac=42:2B:C3:B5:BA:33 nodemac=72:0C:C6:BC:FA:2E   
10.101.0.168:0     id=832   sec_id=4     flags=0x0000 ifindex=10  mac=7A:A0:9A:E0:EE:10 nodemac=EA:AB:92:35:9A:FB     
10.101.0.119:0     id=3123  sec_id=6699851 flags=0x0000 ifindex=18  mac=E6:44:17:A2:9D:BC nodemac=C2:85:DF:FA:60:60   
10.101.0.8:0       (localhost)                                                                                        
10.101.0.228:0     id=1869  sec_id=6707244 flags=0x0000 ifindex=12  mac=DE:1C:18:1B:C2:31 nodemac=5E:57:81:EF:8C:8A   
