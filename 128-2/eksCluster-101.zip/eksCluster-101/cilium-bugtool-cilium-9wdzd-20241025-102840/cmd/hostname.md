ip-172-31-195-223.eu-west-3.compute.internal
