Endpoint ID: 39
Path: /sys/fs/bpf/tc/globals/cilium_policy_00039

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 832
Path: /sys/fs/bpf/tc/globals/cilium_policy_00832

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    433314   5519      0        
Allow    Ingress     1          ANY          NONE         disabled    10616    124       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1869
Path: /sys/fs/bpf/tc/globals/cilium_policy_01869

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69346   794       0        
Allow    Egress      0          ANY          NONE         disabled    12090   123       0        


Endpoint ID: 2084
Path: /sys/fs/bpf/tc/globals/cilium_policy_02084

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69874   802       0        
Allow    Egress      0          ANY          NONE         disabled    12195   124       0        


Endpoint ID: 3123
Path: /sys/fs/bpf/tc/globals/cilium_policy_03123

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3865169   36143     0        
Allow    Ingress     1          ANY          NONE         disabled    2992812   30026     0        
Allow    Egress      0          ANY          NONE         disabled    4408052   40702     0        


