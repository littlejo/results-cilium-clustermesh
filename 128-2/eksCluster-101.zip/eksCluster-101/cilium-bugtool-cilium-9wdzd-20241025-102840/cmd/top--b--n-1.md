top - 10:28:42 up 13 min,  0 users,  load average: 0.02, 0.09, 0.11
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 17.2 us, 58.6 sy,  0.0 ni, 24.1 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    765.2 free,    928.9 used,   2142.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2738.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    697 root      20   0 1240432  15160  10576 S   6.7   0.4   0:00.03 cilium-+
    774 root      20   0 1244084  19684  14144 S   6.7   0.5   0:00.01 hubble
      1 root      20   0 1538164 285060  77696 S   0.0   7.3   0:18.93 cilium-+
    415 root      20   0 1228848   5540   2872 S   0.0   0.1   0:00.24 cilium-+
    686 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    737 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    744 root      20   0    2208    792    712 S   0.0   0.0   0:00.00 timeout
    762 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
