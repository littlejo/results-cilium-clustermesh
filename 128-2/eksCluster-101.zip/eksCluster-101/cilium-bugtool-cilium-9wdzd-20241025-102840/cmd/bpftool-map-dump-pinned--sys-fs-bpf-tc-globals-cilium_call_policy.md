key: 40 03 00 00  value: 1b 02 00 00
key: 4d 07 00 00  value: 0d 02 00 00
key: 24 08 00 00  value: 08 02 00 00
key: 33 0c 00 00  value: 7b 02 00 00
Found 4 elements
