markdown output at /tmp/cilium-bugtool-20241025-102841.936+0000-UTC-2271891680/cmd/cilium-debuginfo-20241025-102912.347+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102841.936+0000-UTC-2271891680/cmd/cilium-debuginfo-20241025-102912.347+0000-UTC.json
