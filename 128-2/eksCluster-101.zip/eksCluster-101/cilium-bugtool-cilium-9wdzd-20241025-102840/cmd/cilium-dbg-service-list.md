ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.193.98:443 (active)     
                                         2 => 172.31.151.238:443 (active)    
2    10.100.103.237:443   ClusterIP      1 => 172.31.195.223:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.101.0.228:53 (active)       
                                         2 => 10.101.0.128:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.101.0.228:9153 (active)     
                                         2 => 10.101.0.128:9153 (active)     
5    10.100.243.85:2379   ClusterIP      1 => 10.101.0.119:2379 (active)     
