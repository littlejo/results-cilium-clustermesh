35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:15:14+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:15:14+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:15:15+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:15:15+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:15:15+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:15:15+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:15:19+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:15:30+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:16:49+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
485: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:16:49+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 125
486: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:16:49+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
487: sched_cls  name tail_handle_ipv4  tag b2404344221bb25f  gpl
	loaded_at 2024-10-25T10:16:49+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
510: sched_cls  name tail_handle_ipv4  tag d5f949b0361c95f5  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,108
	btf_id 153
511: sched_cls  name cil_from_container  tag e4026c06fdbbad10  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 108,76
	btf_id 154
512: sched_cls  name tail_handle_ipv4_cont  tag 52353ccb3670495e  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,107,41,106,82,83,39,76,74,77,108,40,37,38,81
	btf_id 155
513: sched_cls  name tail_handle_arp  tag 9273d5d46942de7a  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,108
	btf_id 156
514: sched_cls  name tail_ipv4_to_endpoint  tag 6d9450c7207b6e3c  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,107,41,82,83,80,106,39,108,40,37,38
	btf_id 157
515: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,108
	btf_id 158
517: sched_cls  name tail_ipv4_ct_egress  tag 7b425c245def87bd  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 160
518: sched_cls  name tail_ipv4_ct_ingress  tag c50a3023eb496c55  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 161
519: sched_cls  name __send_drop_notify  tag 9b0df32fd67ed65c  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 162
520: sched_cls  name handle_policy  tag dfb3aed208ea9991  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,108,82,83,107,41,80,106,39,84,75,40,37,38
	btf_id 163
521: sched_cls  name tail_handle_ipv4  tag ea4725c19c711ae9  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,109
	btf_id 165
522: sched_cls  name cil_from_container  tag 565be754ecf8de0a  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 109,76
	btf_id 166
523: sched_cls  name tail_ipv4_to_endpoint  tag c0c1ca3c4d6bfd77  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,110,41,82,83,80,100,39,109,40,37,38
	btf_id 167
525: sched_cls  name handle_policy  tag 272861828ba76eeb  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,109,82,83,110,41,80,100,39,84,75,40,37,38
	btf_id 169
526: sched_cls  name tail_handle_arp  tag 5618223fdb3116ea  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,109
	btf_id 170
527: sched_cls  name tail_handle_ipv4_cont  tag 08ae5e08724e97df  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,110,41,100,82,83,39,76,74,77,109,40,37,38,81
	btf_id 171
528: sched_cls  name tail_ipv4_ct_ingress  tag 1a740b5fb4d65905  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 172
529: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,109
	btf_id 173
530: sched_cls  name __send_drop_notify  tag bcc4134f55a93be3  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 174
531: sched_cls  name tail_ipv4_ct_egress  tag 7b425c245def87bd  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 175
533: sched_cls  name cil_from_container  tag f3bd877bc682c206  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 111,76
	btf_id 178
534: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
537: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
538: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 179
539: sched_cls  name handle_policy  tag 11afcce0af9862bd  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,111,82,83,112,41,80,101,39,84,75,40,37,38
	btf_id 180
540: sched_cls  name tail_handle_arp  tag a4a16bb3c60eacf3  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 181
541: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 182
542: sched_cls  name tail_handle_ipv4  tag 50402420550c4287  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 183
543: sched_cls  name tail_ipv4_to_endpoint  tag 493131459e7acc5a  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,112,41,82,83,80,101,39,111,40,37,38
	btf_id 184
544: sched_cls  name tail_ipv4_ct_ingress  tag 8f7123f03c9ffb09  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 185
545: sched_cls  name __send_drop_notify  tag d564e973f25741b8  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 186
546: sched_cls  name tail_handle_ipv4_cont  tag 705a2b69319c0ac9  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,112,41,101,82,83,39,76,74,77,111,40,37,38,81
	btf_id 187
547: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
550: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
551: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
554: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
555: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
558: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
560: sched_cls  name tail_handle_ipv4_from_host  tag 5c5c962813528e69  gpl
	loaded_at 2024-10-25T10:16:52+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 190
561: sched_cls  name __send_drop_notify  tag 2983939dd8e8e84c  gpl
	loaded_at 2024-10-25T10:16:52+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 191
562: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:16:52+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 192
564: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:16:52+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 194
565: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:16:52+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,118
	btf_id 195
568: sched_cls  name tail_handle_ipv4_from_host  tag 5c5c962813528e69  gpl
	loaded_at 2024-10-25T10:16:52+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 199
569: sched_cls  name __send_drop_notify  tag 2983939dd8e8e84c  gpl
	loaded_at 2024-10-25T10:16:52+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 200
570: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:16:52+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 201
572: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:16:52+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 203
575: sched_cls  name tail_handle_ipv4_from_host  tag 5c5c962813528e69  gpl
	loaded_at 2024-10-25T10:16:52+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 207
576: sched_cls  name __send_drop_notify  tag 2983939dd8e8e84c  gpl
	loaded_at 2024-10-25T10:16:52+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 208
578: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:16:52+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 210
579: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:16:52+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 211
580: sched_cls  name tail_handle_ipv4_from_host  tag 5c5c962813528e69  gpl
	loaded_at 2024-10-25T10:16:52+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 213
581: sched_cls  name __send_drop_notify  tag 2983939dd8e8e84c  gpl
	loaded_at 2024-10-25T10:16:52+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 214
583: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:16:52+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 216
584: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:16:52+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 217
626: sched_cls  name tail_ipv4_ct_ingress  tag de9df5460d8d6a1d  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 233
627: sched_cls  name tail_ipv4_to_endpoint  tag 149618dc37a0fad5  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 234
628: sched_cls  name __send_drop_notify  tag 2157a0bb8316959e  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 235
629: sched_cls  name tail_ipv4_ct_egress  tag 790012133a5dd83e  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 236
630: sched_cls  name tail_handle_ipv4  tag e7c003641ca88e71  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 237
631: sched_cls  name tail_handle_ipv4_cont  tag 91bb5b5ed6af7d19  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 238
633: sched_cls  name cil_from_container  tag 9763e719e0c6665b  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 240
634: sched_cls  name tail_handle_arp  tag 2097c4bd63f1fb1b  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 241
635: sched_cls  name handle_policy  tag 500d03a799385940  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 242
636: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 243
637: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
640: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
653: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
656: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
657: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
660: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
