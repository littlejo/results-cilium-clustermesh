# Cilium debug information

#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Service list

```
ID   Frontend            Service Type   Backend                            
1    10.100.0.1:443      ClusterIP      1 => 172.31.245.198:443 (active)   
                                        2 => 172.31.176.101:443 (active)   
2    10.100.84.60:443    ClusterIP      1 => 172.31.231.66:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.83.0.78:53 (active)        
                                        2 => 10.83.0.237:53 (active)       
4    10.100.0.10:9153    ClusterIP      1 => 10.83.0.78:9153 (active)      
                                        2 => 10.83.0.237:9153 (active)     
5    10.100.153.8:2379   ClusterIP      1 => 10.83.0.150:2379 (active)     
```

#### Policy get

```
:
 []
Revision: 1

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.83.0.78": (string) (len=35) "kube-system/coredns-cc6ccd49c-cwnc6",
  (string) (len=11) "10.83.0.150": (string) (len=50) "kube-system/clustermesh-apiserver-7dbf7fb7b6-gq6mz",
  (string) (len=11) "10.83.0.221": (string) (len=6) "router",
  (string) (len=10) "10.83.0.53": (string) (len=6) "health",
  (string) (len=11) "10.83.0.237": (string) (len=35) "kube-system/coredns-cc6ccd49c-j7457"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.231.66": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4000edda20)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x40010b6fc0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x40010b6fc0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x40015bf3f0)(frontends:[10.100.84.60]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x40015bf550)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4003148d10)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4003148e70)(frontends:[10.100.153.8]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x40015bf340)(frontends:[10.100.0.1]/ports=[https]/selector=map[])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x400097d8d8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4001c001a0)(172.31.176.101:443/TCP,172.31.245.198:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x400097d8e0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-bbcqs": (*k8s.Endpoints)(0x4001d77520)(172.31.231.66:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x400097d8e8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-2m8nh": (*k8s.Endpoints)(0x400380c9c0)(10.83.0.237:53/TCP[eu-west-3b],10.83.0.237:53/UDP[eu-west-3b],10.83.0.237:9153/TCP[eu-west-3b],10.83.0.78:53/TCP[eu-west-3b],10.83.0.78:53/UDP[eu-west-3b],10.83.0.78:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x400125e268)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-s6ghj": (*k8s.Endpoints)(0x400148f6c0)(10.83.0.150:2379/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001b3ae00)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40022592c0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400adb5320
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4002262ea0,
  gcExited: (chan struct {}) 0x4002262f00,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001a87c00)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000e89eb8)({
      MetricVec: (*prometheus.MetricVec)(0x4001edc3f0)({
       metricMap: (*prometheus.metricMap)(0x4001edc420)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b6ab40)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001a87c80)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000e89ec0)({
      MetricVec: (*prometheus.MetricVec)(0x4001edc480)({
       metricMap: (*prometheus.metricMap)(0x4001edc4b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b6aba0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001a87d00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000e89ec8)({
      MetricVec: (*prometheus.MetricVec)(0x4001edc510)({
       metricMap: (*prometheus.metricMap)(0x4001edc540)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b6ac00)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001a87d80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000e89ed0)({
      MetricVec: (*prometheus.MetricVec)(0x4001edc5a0)({
       metricMap: (*prometheus.metricMap)(0x4001edc5d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b6ac60)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001a87e00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000e89ed8)({
      MetricVec: (*prometheus.MetricVec)(0x4001edc630)({
       metricMap: (*prometheus.metricMap)(0x4001edc660)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b6acc0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001a87e80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000e89ee0)({
      MetricVec: (*prometheus.MetricVec)(0x4001edc6c0)({
       metricMap: (*prometheus.metricMap)(0x4001edc6f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b6ad20)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001a87f00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000e89ee8)({
      MetricVec: (*prometheus.MetricVec)(0x4001edc750)({
       metricMap: (*prometheus.metricMap)(0x4001edc780)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b6ad80)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001ee6000)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000e89ef0)({
      MetricVec: (*prometheus.MetricVec)(0x4001edc7e0)({
       metricMap: (*prometheus.metricMap)(0x4001edc810)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b6ade0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001ee6080)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000e89ef8)({
      MetricVec: (*prometheus.MetricVec)(0x4001edc870)({
       metricMap: (*prometheus.metricMap)(0x4001edc8a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b6ae40)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001b3ae00)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4002432380)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001112de0)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 361ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5
  }
 })
})

```


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.83.0.0/24, 
Allocated addresses:
  10.83.0.150 (kube-system/clustermesh-apiserver-7dbf7fb7b6-gq6mz)
  10.83.0.221 (router)
  10.83.0.237 (kube-system/coredns-cc6ccd49c-j7457)
  10.83.0.53 (health)
  10.83.0.78 (kube-system/coredns-cc6ccd49c-cwnc6)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 836c0d8175bd7599
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    12s ago        never        0       no error   
  ct-map-pressure                                                     13s ago        never        0       no error   
  daemon-validate-config                                              1m2s ago       never        0       no error   
  dns-garbage-collector-job                                           16s ago        never        0       no error   
  endpoint-1193-regeneration-recovery                                 never          never        0       no error   
  endpoint-205-regeneration-recovery                                  never          never        0       no error   
  endpoint-2320-regeneration-recovery                                 never          never        0       no error   
  endpoint-2344-regeneration-recovery                                 never          never        0       no error   
  endpoint-3159-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                         2m16s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                13s ago        never        0       no error   
  ipcache-inject-labels                                               14s ago        never        0       no error   
  k8s-heartbeat                                                       16s ago        never        0       no error   
  link-cache                                                          13s ago        never        0       no error   
  local-identity-checkpoint                                           12m13s ago     never        0       no error   
  node-neighbor-link-updater                                          3s ago         never        0       no error   
  remote-etcd-cmesh1                                                  5m58s ago      never        0       no error   
  remote-etcd-cmesh10                                                 5m57s ago      never        0       no error   
  remote-etcd-cmesh100                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh101                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh102                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh103                                                5m57s ago      never        0       no error   
  remote-etcd-cmesh104                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh105                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh106                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh107                                                5m57s ago      never        0       no error   
  remote-etcd-cmesh108                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh109                                                5m57s ago      never        0       no error   
  remote-etcd-cmesh11                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh110                                                5m57s ago      never        0       no error   
  remote-etcd-cmesh111                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh112                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh113                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh114                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh115                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh116                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh117                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh118                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh119                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh12                                                 5m57s ago      never        0       no error   
  remote-etcd-cmesh120                                                5m57s ago      never        0       no error   
  remote-etcd-cmesh121                                                5m57s ago      never        0       no error   
  remote-etcd-cmesh122                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh123                                                5m57s ago      never        0       no error   
  remote-etcd-cmesh124                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh125                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh126                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh127                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh128                                                5m58s ago      never        0       no error   
  remote-etcd-cmesh13                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh14                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh15                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh16                                                 5m57s ago      never        0       no error   
  remote-etcd-cmesh17                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh18                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh19                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh2                                                  5m58s ago      never        0       no error   
  remote-etcd-cmesh20                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh21                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh22                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh23                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh24                                                 5m57s ago      never        0       no error   
  remote-etcd-cmesh25                                                 5m57s ago      never        0       no error   
  remote-etcd-cmesh26                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh27                                                 5m57s ago      never        0       no error   
  remote-etcd-cmesh28                                                 5m57s ago      never        0       no error   
  remote-etcd-cmesh29                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh3                                                  5m58s ago      never        0       no error   
  remote-etcd-cmesh30                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh31                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh32                                                 5m57s ago      never        0       no error   
  remote-etcd-cmesh33                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh34                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh35                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh36                                                 5m57s ago      never        0       no error   
  remote-etcd-cmesh37                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh38                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh39                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh4                                                  5m57s ago      never        0       no error   
  remote-etcd-cmesh40                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh41                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh42                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh43                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh44                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh45                                                 5m57s ago      never        0       no error   
  remote-etcd-cmesh46                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh47                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh48                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh49                                                 5m57s ago      never        0       no error   
  remote-etcd-cmesh5                                                  5m58s ago      never        0       no error   
  remote-etcd-cmesh50                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh51                                                 5m57s ago      never        0       no error   
  remote-etcd-cmesh52                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh53                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh54                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh55                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh56                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh57                                                 5m57s ago      never        0       no error   
  remote-etcd-cmesh58                                                 5m57s ago      never        0       no error   
  remote-etcd-cmesh59                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh6                                                  5m58s ago      never        0       no error   
  remote-etcd-cmesh60                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh61                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh62                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh63                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh64                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh65                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh66                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh67                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh68                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh69                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh7                                                  5m58s ago      never        0       no error   
  remote-etcd-cmesh70                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh71                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh72                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh73                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh74                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh75                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh76                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh77                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh78                                                 5m57s ago      never        0       no error   
  remote-etcd-cmesh79                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh8                                                  5m58s ago      never        0       no error   
  remote-etcd-cmesh80                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh81                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh82                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh83                                                 5m57s ago      never        0       no error   
  remote-etcd-cmesh85                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh86                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh87                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh88                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh89                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh9                                                  5m58s ago      never        0       no error   
  remote-etcd-cmesh90                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh91                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh92                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh93                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh94                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh95                                                 5m57s ago      never        0       no error   
  remote-etcd-cmesh96                                                 5m57s ago      never        0       no error   
  remote-etcd-cmesh97                                                 5m58s ago      never        0       no error   
  remote-etcd-cmesh98                                                 5m57s ago      never        0       no error   
  remote-etcd-cmesh99                                                 5m57s ago      never        0       no error   
  resolve-identity-1193                                               2m12s ago      never        0       no error   
  resolve-identity-205                                                2m13s ago      never        0       no error   
  resolve-identity-2320                                               2m12s ago      never        0       no error   
  resolve-identity-2344                                               2m4s ago       never        0       no error   
  resolve-identity-3159                                               2m12s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-7dbf7fb7b6-gq6mz   7m4s ago       never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-cwnc6                  12m12s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-j7457                  12m12s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      12m13s ago     never        0       no error   
  sync-policymap-1193                                                 12m9s ago      never        0       no error   
  sync-policymap-205                                                  12m12s ago     never        0       no error   
  sync-policymap-2320                                                 12m9s ago      never        0       no error   
  sync-policymap-2344                                                 7m4s ago       never        0       no error   
  sync-policymap-3159                                                 12m9s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (2320)                                   12s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2344)                                   4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3159)                                   12s ago        never        0       no error   
  sync-utime                                                          14s ago        never        0       no error   
  write-cni-file                                                      12m16s ago     never        0       no error   
Proxy Status:            OK, ip 10.83.0.221, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 5505024, max 5570559
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 83.91   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
bpf-lb-external-clusterip:false
wireguard-persistent-keepalive:0s
dnsproxy-insecure-skip-transparent-mode-check:false
enable-health-checking:true
prepend-iptables-chains:true
container-ip-local-reserved-ports:auto
bpf-ct-timeout-regular-any:1m0s
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
iptables-lock-timeout:5s
encrypt-interface:
trace-payloadlen:128
enable-xt-socket-fallback:true
ip-masq-agent-config-path:/etc/config/ip-masq-agent
enable-ipv4-big-tcp:false
policy-cidr-match-mode:
routing-mode:tunnel
bpf-lb-algorithm:random
labels:
k8s-require-ipv6-pod-cidr:false
service-no-backend-response:reject
hubble-metrics-server:
datapath-mode:veth
ipam-multi-pool-pre-allocation:
kvstore-connectivity-timeout:2m0s
hubble-export-file-max-backups:5
identity-restore-grace-period:30s
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
enable-l7-proxy:true
enable-host-legacy-routing:false
node-port-algorithm:random
enable-session-affinity:false
auto-direct-node-routes:false
bpf-auth-map-max:524288
vtep-mac:
debug:false
enable-bpf-masquerade:false
ipv4-service-range:auto
dnsproxy-lock-count:131
enable-node-port:false
k8s-kubeconfig-path:
cluster-health-port:4240
enable-encryption-strict-mode:false
max-internal-timer-delay:0s
enable-wireguard:false
arping-refresh-period:30s
config:
envoy-config-timeout:2m0s
hubble-skip-unknown-cgroup-ids:true
enable-k8s-networkpolicy:true
enable-svc-source-range-check:true
bpf-events-trace-enabled:true
policy-trigger-interval:1s
enable-tcx:true
bpf-lb-acceleration:disabled
custom-cni-conf:false
certificates-directory:/var/run/cilium/certs
proxy-max-requests-per-connection:0
envoy-log:
ipv6-service-range:auto
allow-localhost:auto
route-metric:0
preallocate-bpf-maps:false
gops-port:9890
enable-bpf-tproxy:false
bpf-lb-sock-hostns-only:false
pprof-port:6060
enable-external-ips:false
enable-ipv4:true
ipv6-mcast-device:
external-envoy-proxy:true
local-max-addr-scope:252
disable-iptables-feeder-rules:
proxy-xff-num-trusted-hops-ingress:0
enable-bpf-clock-probe:false
hubble-export-denylist:
bpf-lb-sock:false
cni-exclusive:true
controller-group-metrics:
max-connected-clusters:255
enable-ipv4-egress-gateway:false
hubble-event-buffer-capacity:4095
k8s-sync-timeout:3m0s
tofqdns-pre-cache:
hubble-listen-address::4244
identity-heartbeat-timeout:30m0s
enable-k8s-endpoint-slice:true
bpf-policy-map-max:16384
enable-unreachable-routes:false
enable-k8s-terminating-endpoint:true
ipv4-range:auto
bpf-filter-priority:1
clustermesh-enable-endpoint-sync:false
hubble-recorder-sink-queue-size:1024
http-request-timeout:3600
bpf-lb-sock-terminate-pod-connections:false
node-labels:
node-port-acceleration:disabled
bpf-neigh-global-max:524288
bpf-lb-mode:snat
ipam-default-ip-pool:default
bpf-events-policy-verdict-enabled:true
enable-bbr:false
bpf-map-event-buffers:
version:false
hubble-redact-http-userinfo:true
cni-chaining-target:
clustermesh-config:/var/lib/cilium/clustermesh/
mesh-auth-spire-admin-socket:
tofqdns-max-deferred-connection-deletes:10000
enable-health-check-nodeport:true
disable-external-ip-mitigation:false
k8s-service-proxy-name:
enable-ipsec-encrypted-overlay:false
encrypt-node:false
hubble-flowlogs-config-path:
bpf-map-dynamic-size-ratio:0.0025
k8s-api-server:
kvstore:
l2-pod-announcements-interface:
debug-verbose:
log-opt:
enable-k8s:true
log-driver:
bgp-config-path:/var/lib/cilium/bgp/config.yaml
mke-cgroup-mount:
enable-health-check-loadbalancer-ip:false
enable-policy:default
http-retry-count:3
multicast-enabled:false
mesh-auth-queue-size:1024
keep-config:false
node-port-range:
hubble-socket-path:/var/run/cilium/hubble.sock
cilium-endpoint-gc-interval:5m0s
fqdn-regex-compile-lru-size:1024
force-device-detection:false
install-no-conntrack-iptables-rules:false
set-cilium-is-up-condition:true
vtep-cidr:
tofqdns-min-ttl:0
monitor-aggregation-flags:all
envoy-base-id:0
proxy-admin-port:0
annotate-k8s-node:false
mesh-auth-enabled:true
enable-high-scale-ipcache:false
log-system-load:false
enable-endpoint-health-checking:true
ingress-secrets-namespace:
pprof-address:localhost
hubble-redact-http-headers-allow:
conntrack-gc-max-interval:0s
tofqdns-idle-connection-grace-period:0s
enable-ipv6-big-tcp:false
tofqdns-endpoint-max-ip-per-hostname:50
envoy-config-retry-interval:15s
mtu:0
bpf-lb-map-max:65536
iptables-random-fully:false
dnsproxy-concurrency-limit:0
enable-metrics:true
enable-cilium-endpoint-slice:false
clustermesh-ip-identities-sync-timeout:1m0s
enable-ipip-termination:false
direct-routing-device:
vtep-mask:
agent-labels:
enable-wireguard-userspace-fallback:false
mesh-auth-mutual-connect-timeout:5s
egress-gateway-policy-map-max:16384
hubble-drop-events:false
dnsproxy-concurrency-processing-grace-period:0s
k8s-namespace:kube-system
bpf-lb-source-range-map-max:0
enable-ipsec-xfrm-state-caching:true
enable-identity-mark:true
hubble-redact-enabled:false
hubble-export-allowlist:
bpf-lb-service-map-max:0
nat-map-stats-interval:30s
enable-masquerade-to-route-source:false
bpf-ct-timeout-regular-tcp-syn:1m0s
k8s-service-cache-size:128
hubble-prefer-ipv6:false
enable-runtime-device-detection:true
cluster-pool-ipv4-cidr:10.83.0.0/16
bpf-ct-timeout-service-tcp-grace:1m0s
identity-gc-interval:15m0s
bpf-lb-rev-nat-map-max:0
conntrack-gc-interval:0s
state-dir:/var/run/cilium
unmanaged-pod-watcher-interval:15
kube-proxy-replacement:false
bpf-policy-map-full-reconciliation-interval:15m0s
bpf-events-drop-enabled:true
install-iptables-rules:true
tunnel-protocol:vxlan
proxy-gid:1337
k8s-client-connection-keep-alive:30s
restore:true
label-prefix-file:
envoy-secrets-namespace:
hubble-drop-events-reasons:auth_required,policy_denied
cluster-name:cmesh84
config-dir:/tmp/cilium/config-map
enable-sctp:false
enable-ipsec:false
enable-pmtu-discovery:false
enable-vtep:false
egress-masquerade-interfaces:ens+
clustermesh-enable-mcs-api:false
tunnel-port:0
derive-masq-ip-addr-from-device:
bpf-ct-timeout-regular-tcp-fin:10s
cluster-id:84
hubble-disable-tls:false
hubble-redact-http-headers-deny:
allocator-list-timeout:3m0s
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
ipv6-range:auto
enable-host-port:false
enable-mke:false
enable-auto-protect-node-port-range:true
kube-proxy-replacement-healthz-bind-address:
tofqdns-dns-reject-response-code:refused
srv6-encap-mode:reduced
bpf-nat-global-max:524288
bpf-node-map-max:16384
policy-queue-size:100
http-max-grpc-timeout:0
l2-announcements-retry-period:2s
identity-allocation-mode:crd
bpf-lb-rss-ipv6-src-cidr:
bpf-lb-maglev-table-size:16381
enable-ipv6-masquerade:true
enable-bgp-control-plane:false
proxy-portrange-min:10000
operator-api-serve-addr:127.0.0.1:9234
policy-accounting:true
vtep-endpoint:
l2-announcements-lease-duration:15s
proxy-prometheus-port:0
enable-envoy-config:false
gateway-api-secrets-namespace:
bpf-lb-dsr-dispatch:opt
vlan-bpf-bypass:
cluster-pool-ipv4-mask-size:24
local-router-ipv6:
encryption-strict-mode-cidr:
envoy-keep-cap-netbindservice:false
enable-hubble-recorder-api:true
bpf-lb-rss-ipv4-src-cidr:
enable-srv6:false
l2-announcements-renew-deadline:5s
hubble-export-file-max-size-mb:10
exclude-local-address:
api-rate-limit:
mesh-auth-signal-backoff-duration:1s
identity-change-grace-period:5s
ipv6-native-routing-cidr:
http-idle-timeout:0
proxy-xff-num-trusted-hops-egress:0
hubble-export-file-path:
enable-cilium-health-api-server-access:
hubble-recorder-storage-path:/var/run/cilium/pcaps
enable-node-selector-labels:false
egress-multi-home-ip-rule-compat:false
ipv4-node:auto
bpf-sock-rev-map-max:262144
join-cluster:false
k8s-require-ipv4-pod-cidr:false
ipam:cluster-pool
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
lib-dir:/var/lib/cilium
enable-endpoint-routes:false
proxy-portrange-max:20000
tofqdns-enable-dns-compression:true
bpf-ct-timeout-service-any:1m0s
devices:
hubble-redact-kafka-apikey:false
bgp-announce-pod-cidr:false
k8s-heartbeat-timeout:30s
nodeport-addresses:
egress-gateway-reconciliation-trigger-interval:1s
enable-bandwidth-manager:false
monitor-aggregation-interval:5s
enable-xdp-prefilter:false
proxy-connect-timeout:2
hubble-export-file-compress:false
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
enable-k8s-api-discovery:false
bpf-lb-maglev-map-max:0
enable-ingress-controller:false
mesh-auth-spiffe-trust-domain:spiffe.cilium
enable-l2-pod-announcements:false
enable-monitor:true
enable-icmp-rules:true
bpf-ct-timeout-service-tcp:2h13m20s
bpf-root:/sys/fs/bpf
hubble-metrics:
enable-l2-announcements:false
enable-ip-masq-agent:false
enable-hubble:true
static-cnp-path:
ipv4-native-routing-cidr:
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
bpf-lb-affinity-map-max:0
bgp-announce-lb-ip:false
hubble-event-queue-size:0
nat-map-stats-entries:32
encryption-strict-mode-allow-remote-node-identities:false
disable-endpoint-crd:false
enable-l2-neigh-discovery:true
nodes-gc-interval:5m0s
endpoint-bpf-prog-watchdog-interval:30s
enable-local-redirect-policy:false
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
enable-tracing:false
k8s-client-qps:10
ipv4-pod-subnets:
k8s-client-burst:20
enable-ipsec-key-watcher:true
enable-recorder:false
kvstore-lease-ttl:15m0s
proxy-idle-timeout-seconds:60
use-full-tls-context:false
monitor-queue-size:0
cflags:
endpoint-gc-interval:5m0s
direct-routing-skip-unreachable:false
clustermesh-sync-timeout:1m0s
node-port-mode:snat
use-cilium-internal-ip-for-ipsec:false
exclude-node-label-patterns:
max-controller-interval:0
http-retry-timeout:0
k8s-client-connection-timeout:30s
cgroup-root:/run/cilium/cgroupv2
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
config-sources:config-map:kube-system/cilium-config
endpoint-queue-size:25
cni-chaining-mode:none
bpf-ct-global-tcp-max:524288
hubble-redact-http-urlquery:false
mesh-auth-rotated-identities-queue-size:1024
ipsec-key-file:
proxy-max-connection-duration-seconds:0
disable-envoy-version-check:false
remove-cilium-node-taints:true
operator-prometheus-serve-addr::9963
mesh-auth-mutual-listener-port:0
ipam-cilium-node-update-rate:15s
ipv6-cluster-alloc-cidr:f00d::/64
synchronize-k8s-nodes:true
enable-custom-calls:false
enable-gateway-api:false
set-cilium-node-taints:true
ipv6-node:auto
agent-health-port:9879
enable-host-firewall:false
ipv6-pod-subnets:
local-router-ipv4:
procfs:/host/proc
allow-icmp-frag-needed:true
bpf-ct-global-any-max:262144
tofqdns-proxy-port:0
tofqdns-proxy-response-max-delay:100ms
kvstore-opt:
ipv4-service-loopback-address:169.254.42.1
dns-policy-unload-on-shutdown:false
enable-well-known-identities:false
socket-path:/var/run/cilium/cilium.sock
dns-max-ips-per-restored-rule:1000
bpf-ct-timeout-regular-tcp:2h13m20s
dnsproxy-socket-linger-timeout:10
cni-log-file:/var/run/cilium/cilium-cni.log
node-port-bind-protection:true
enable-cilium-api-server-access:
bpf-lb-dsr-l4-xlate:frontend
enable-ipv4-masquerade:true
metrics:
ipsec-key-rotation-duration:5m0s
enable-route-mtu-for-cni-chaining:false
enable-ipv4-fragment-tracking:true
hubble-monitor-events:
prometheus-serve-addr:
enable-nat46x64-gateway:false
http-normalize-path:true
auto-create-cilium-node-resource:true
enable-local-node-route:true
pprof:false
bypass-ip-availability-upon-restore:false
dnsproxy-lock-timeout:500ms
enable-ipv6-ndp:false
kvstore-max-consecutive-quorum-errors:2
agent-liveness-update-interval:1s
trace-sock:true
read-cni-conf:
cmdref:
enable-stale-cilium-endpoint-cleanup:true
dnsproxy-enable-transparent-mode:true
monitor-aggregation:medium
kvstore-periodic-sync:5m0s
cni-external-routing:false
hubble-drop-events-interval:2m0s
fixed-identity-mapping:
enable-ipv6:false
enable-service-topology:false
hubble-export-fieldmask:
crd-wait-timeout:5m0s
policy-audit-mode:false
bpf-lb-service-backend-map-max:0
mesh-auth-gc-interval:5m0s
bpf-fragments-map-max:8192
enable-active-connection-tracking:false
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
205        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                
                                                           reserved:host                                                                                             
1193       Disabled           Disabled          4          reserved:health                                                                     10.83.0.53    ready   
2320       Disabled           Disabled          5540605    k8s:eks.amazonaws.com/component=coredns                                             10.83.0.78    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh84                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
2344       Disabled           Disabled          5510743    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.83.0.150   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh84                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
3159       Disabled           Disabled          5540605    k8s:eks.amazonaws.com/component=coredns                                             10.83.0.237   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh84                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
```

#### BPF Policy Get 205

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 205

```
Invalid argument: unknown type 205
```


#### Endpoint Get 205

```
[
  {
    "id": 205,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-205-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "1589a53e-4b67-4346-b61b-ce465214412a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-205",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:06.570Z",
            "success-count": 3
          },
          "uuid": "e10c7926-b233-4695-944e-b467d85c46d6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-205",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:07.732Z",
            "success-count": 1
          },
          "uuid": "f44ba020-10a1-4275-99ab-6285470f9a3b"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:24Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "1a:fe:1b:ab:19:af",
        "interface-name": "cilium_host",
        "mac": "1a:fe:1b:ab:19:af"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 205

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 205

```
Timestamp              Status   State                   Message
2024-10-25T10:23:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:24Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:08Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:17:08Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:17:07Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:17:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:06Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:17:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:17:06Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:17:06Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 1193

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    441314   5634      0        
Allow    Ingress     1          ANY          NONE         disabled    10692    126       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 1193

```
Invalid argument: unknown type 1193
```


#### Endpoint Get 1193

```
[
  {
    "id": 1193,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1193-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c8225b94-7551-4b69-8984-085437f05758"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1193",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:07.695Z",
            "success-count": 3
          },
          "uuid": "1b32febd-59d6-41c4-b191-0f1088ef1e98"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1193",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:10.734Z",
            "success-count": 1
          },
          "uuid": "37985b48-60a9-46b9-833f-6ac712967701"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:24Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.83.0.53",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "8a:25:d6:62:c4:06",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "76:32:d3:7e:c9:70"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1193

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1193

```
Timestamp              Status   State                   Message
2024-10-25T10:23:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:24Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:17:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:10Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:17:08Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:17:08Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:17:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:17:07Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:17:06Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 2320

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    68563   790       0        
Allow    Egress      0          ANY          NONE         disabled    12474   127       0        

```


#### BPF CT List 2320

```
Invalid argument: unknown type 2320
```


#### Endpoint Get 2320

```
[
  {
    "id": 2320,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2320-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f8d4a2ab-9e60-4dea-885a-87075f4baf06"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2320",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:07.693Z",
            "success-count": 3
          },
          "uuid": "ebca0eca-c738-4b17-8df5-09ffa90775bc"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-cwnc6",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:07.691Z",
            "success-count": 1
          },
          "uuid": "d9964c55-690f-4d2c-83bc-6d945f356654"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2320",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:10.663Z",
            "success-count": 1
          },
          "uuid": "7bbf37e7-99b5-46a8-9629-7be0eaef6230"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2320)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:17.752Z",
            "success-count": 75
          },
          "uuid": "f8daf2d8-9a68-4d50-a11e-f4d2aa218cee"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "65c7af8f6dc8564d27cbabd2ae3df57eef463f43ec22fdde33f6b960f5e102f7:eth0",
        "container-id": "65c7af8f6dc8564d27cbabd2ae3df57eef463f43ec22fdde33f6b960f5e102f7",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-cwnc6",
        "pod-name": "kube-system/coredns-cc6ccd49c-cwnc6"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5540605,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh84",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh84",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:24Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.83.0.78",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "66:5f:20:6d:72:6a",
        "interface-index": 14,
        "interface-name": "lxcde8e7955845c",
        "mac": "ea:d5:31:ea:e2:a2"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5540605,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5540605,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2320

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2320

```
Timestamp              Status   State                   Message
2024-10-25T10:23:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:24Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:17:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:10Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:17:10Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:17:08Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:17:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:17:07Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:17:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:17:07Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:17:07Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 5540605

```
ID        LABELS
5540605   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh84
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 2344

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3937997   37015     0        
Allow    Ingress     1          ANY          NONE         disabled    2909798   29114     0        
Allow    Egress      0          ANY          NONE         disabled    4472615   41516     0        

```


#### BPF CT List 2344

```
Invalid argument: unknown type 2344
```


#### Endpoint Get 2344

```
[
  {
    "id": 2344,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2344-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d2dfdae3-1b54-4f9e-905d-94ac5ed47551"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2344",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:16.383Z",
            "success-count": 2
          },
          "uuid": "fe83daf8-849c-4bc2-be9e-57ee857274e4"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-7dbf7fb7b6-gq6mz",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:16.382Z",
            "success-count": 1
          },
          "uuid": "27da7fd8-7843-48b2-9bce-2bd99572d47e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2344",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:16.425Z",
            "success-count": 1
          },
          "uuid": "cc53c4c3-b900-4c89-839a-ee43eeea12b8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2344)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:16.434Z",
            "success-count": 44
          },
          "uuid": "6c089121-67cb-4d0b-a5b2-53520e53f5fa"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "2ab3de611d3d9383a803b4fdce2e559ed020c72819ec3d4204e660997e35d867:eth0",
        "container-id": "2ab3de611d3d9383a803b4fdce2e559ed020c72819ec3d4204e660997e35d867",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-7dbf7fb7b6-gq6mz",
        "pod-name": "kube-system/clustermesh-apiserver-7dbf7fb7b6-gq6mz"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5510743,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh84",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7dbf7fb7b6"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh84",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:24Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.83.0.150",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ba:c1:79:ba:07:27",
        "interface-index": 18,
        "interface-name": "lxcb2eb02bc50a0",
        "mac": "1e:98:60:a7:9e:14"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5510743,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5510743,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2344

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2344

```
Timestamp              Status   State                   Message
2024-10-25T10:23:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:24Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:22:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:16Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:22:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:22:16Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:22:16Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 5510743

```
ID        LABELS
5510743   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh84
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 3159

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    68506   787       0        
Allow    Egress      0          ANY          NONE         disabled    12251   123       0        

```


#### BPF CT List 3159

```
Invalid argument: unknown type 3159
```


#### Endpoint Get 3159

```
[
  {
    "id": 3159,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3159-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "8e78e605-5396-429d-8bf7-6af7b1acac0d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3159",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:07.616Z",
            "success-count": 3
          },
          "uuid": "50d20792-0288-4fd2-a176-a106235d2e48"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-j7457",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:07.615Z",
            "success-count": 1
          },
          "uuid": "206fdc42-a871-4db8-9cca-1ee7273183cf"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3159",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:10.674Z",
            "success-count": 1
          },
          "uuid": "1ce1203a-78e8-4e72-b3f7-699a1eacbbb6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3159)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:17.681Z",
            "success-count": 75
          },
          "uuid": "ba916231-1270-4dd3-b60d-c98b40f7c5d2"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "ad8286bd6fa84e1e45ecc0df75fff4caf8f847ac47d70c9822d1bea1302420f7:eth0",
        "container-id": "ad8286bd6fa84e1e45ecc0df75fff4caf8f847ac47d70c9822d1bea1302420f7",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-j7457",
        "pod-name": "kube-system/coredns-cc6ccd49c-j7457"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5540605,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh84",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh84",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:24Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.83.0.237",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "aa:b8:4c:cd:d3:63",
        "interface-index": 12,
        "interface-name": "lxc8d57ad28011d",
        "mac": "0e:4c:10:87:5f:a0"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5540605,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5540605,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3159

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3159

```
Timestamp              Status    State                   Message
2024-10-25T10:23:24Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:24Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:24Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:23:24Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:23Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:23Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:23Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:23Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:22Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:22Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:22Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:22Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:28Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:28Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:28Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:28Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:27Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:27Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:27Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:27Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:10Z   OK        ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:17:10Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:10Z   OK        regenerating            Regenerating endpoint: devices changed
2024-10-25T10:17:10Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:17:08Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:17:08Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:17:07Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:17:07Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:17:07Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:17:07Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:07Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 5540605

```
ID        LABELS
5540605   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh84
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 21010356                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 21010356                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 21010356                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d000000 rw-p 00000000 00:00 0 
400d000000-4010000000 ---p 00000000 00:00 0 
ffff56eb3000-ffff570b9000 rw-p 00000000 00:00 0 
ffff570c1000-ffff571e2000 rw-p 00000000 00:00 0 
ffff571e2000-ffff57223000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff57223000-ffff57264000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff57264000-ffff57266000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff57266000-ffff57268000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff57268000-ffff5782f000 rw-p 00000000 00:00 0 
ffff5782f000-ffff5792f000 rw-p 00000000 00:00 0 
ffff5792f000-ffff57940000 rw-p 00000000 00:00 0 
ffff57940000-ffff59940000 rw-p 00000000 00:00 0 
ffff59940000-ffff599c0000 ---p 00000000 00:00 0 
ffff599c0000-ffff599c1000 rw-p 00000000 00:00 0 
ffff599c1000-ffff799c0000 ---p 00000000 00:00 0 
ffff799c0000-ffff799c1000 rw-p 00000000 00:00 0 
ffff799c1000-ffff99950000 ---p 00000000 00:00 0 
ffff99950000-ffff99951000 rw-p 00000000 00:00 0 
ffff99951000-ffff9d942000 ---p 00000000 00:00 0 
ffff9d942000-ffff9d943000 rw-p 00000000 00:00 0 
ffff9d943000-ffff9e140000 ---p 00000000 00:00 0 
ffff9e140000-ffff9e141000 rw-p 00000000 00:00 0 
ffff9e141000-ffff9e240000 ---p 00000000 00:00 0 
ffff9e240000-ffff9e2a0000 rw-p 00000000 00:00 0 
ffff9e2a0000-ffff9e2a2000 r--p 00000000 00:00 0                          [vvar]
ffff9e2a2000-ffff9e2a3000 r-xp 00000000 00:00 0                          [vdso]
fffffe7e2000-fffffe803000 rw-p 00000000 00:00 0                          [stack]

```

