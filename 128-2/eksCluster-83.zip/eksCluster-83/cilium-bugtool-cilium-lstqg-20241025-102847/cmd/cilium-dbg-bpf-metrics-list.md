REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     217478    84445383   1132   bpf_host.c
Interface                 INGRESS     9527      744541     677    bpf_overlay.c
Success                   EGRESS      4542      347133     1694   bpf_host.c
Success                   EGRESS      91131     12216251   1308   bpf_lxc.c
Success                   EGRESS      9329      730798     53     encap.h
Success                   INGRESS     101232    12456076   86     l3.h
Success                   INGRESS     106866    12897390   235    trace.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
