alloc: 117.95MB (123680128 bytes)
total-alloc: 1.32GB (1412078368 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 47544097
frees: 46364473
heap-alloc: 117.95MB (123680128 bytes)
heap-sys: 165.30MB (173326336 bytes)
heap-idle: 30.68MB (32169984 bytes)
heap-in-use: 134.62MB (141156352 bytes)
heap-released: 1.84MB (1925120 bytes)
heap-objects: 1179624
stack-in-use: 34.66MB (36339712 bytes)
stack-sys: 34.66MB (36339712 bytes)
stack-mspan-inuse: 2.09MB (2193440 bytes)
stack-mspan-sys: 2.38MB (2496960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.00MB (1052409 bytes)
gc-sys: 5.16MB (5409024 bytes)
next-gc: when heap-alloc >= 145.87MB (152958968 bytes)
last-gc: 2024-10-25 10:28:52.422953868 +0000 UTC
gc-pause-total: 8.262814ms
gc-pause: 63056
gc-pause-end: 1729852132422953868
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.0003696049173492451
enable-gc: true
debug-gc: false
