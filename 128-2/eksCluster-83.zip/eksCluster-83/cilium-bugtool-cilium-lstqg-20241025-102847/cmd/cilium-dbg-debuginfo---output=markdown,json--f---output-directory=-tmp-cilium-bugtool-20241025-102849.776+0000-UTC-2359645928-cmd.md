markdown output at /tmp/cilium-bugtool-20241025-102849.776+0000-UTC-2359645928/cmd/cilium-debuginfo-20241025-102920.457+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102849.776+0000-UTC-2359645928/cmd/cilium-debuginfo-20241025-102920.457+0000-UTC.json
