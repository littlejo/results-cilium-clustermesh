Total: 565
TCP:   1092 (estab 314, closed 759, orphaned 0, timewait 293)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  333       322       11       
INET	  343       328       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                            127.0.0.1:36195      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:24846 sk:1001 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.231.66%ens5:68         0.0.0.0:*    uid:192 ino:15248 sk:1002 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:25822 sk:1003 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15712 sk:1004 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:25821 sk:1005 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15713 sk:1006 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::828:d4ff:feea:a6b3]%ens5:546           [::]:*    uid:192 ino:15244 sk:1007 cgroup:unreachable:c4e v6only:1 <->                   
