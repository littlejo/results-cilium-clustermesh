USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         677  0.0  0.4 1240176 16452 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         709  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         710  0.0  0.0      0     0 ?        Z    10:28   0:00  \_ [hostname] <defunct>
root         667  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         661  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops stack 1
root         657  0.0  0.1 1229000 4052 ?        Ssl  10:28   0:00 /bin/gops stats 1
root         654  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  2.5  6.9 1472496 271084 ?      Ssl  10:16   0:18 cilium-agent --config-dir=/tmp/cilium/config-map
root         406  0.0  0.1 1228848 5636 ?        Sl   10:17   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
