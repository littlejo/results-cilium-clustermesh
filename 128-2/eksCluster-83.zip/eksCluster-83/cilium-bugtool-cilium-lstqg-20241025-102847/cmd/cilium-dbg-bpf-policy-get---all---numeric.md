Endpoint ID: 205
Path: /sys/fs/bpf/tc/globals/cilium_policy_00205

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1193
Path: /sys/fs/bpf/tc/globals/cilium_policy_01193

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    442331   5648      0        
Allow    Ingress     1          ANY          NONE         disabled    10692    126       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2320
Path: /sys/fs/bpf/tc/globals/cilium_policy_02320

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    68563   790       0        
Allow    Egress      0          ANY          NONE         disabled    12474   127       0        


Endpoint ID: 2344
Path: /sys/fs/bpf/tc/globals/cilium_policy_02344

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3939149   37028     0        
Allow    Ingress     1          ANY          NONE         disabled    2909798   29114     0        
Allow    Egress      0          ANY          NONE         disabled    4473701   41528     0        


Endpoint ID: 3159
Path: /sys/fs/bpf/tc/globals/cilium_policy_03159

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    68506   787       0        
Allow    Egress      0          ANY          NONE         disabled    12251   123       0        


