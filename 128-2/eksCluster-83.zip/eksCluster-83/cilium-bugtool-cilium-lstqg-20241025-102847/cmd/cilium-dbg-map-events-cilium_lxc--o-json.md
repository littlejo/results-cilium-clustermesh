{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:06.440Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.205.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:06.440Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.231.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:06.440Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.663Z",
  "value": "id=2320  sec_id=5540605 flags=0x0000 ifindex=14  mac=EA:D5:31:EA:E2:A2 nodemac=66:5F:20:6D:72:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.671Z",
  "value": "id=3159  sec_id=5540605 flags=0x0000 ifindex=12  mac=0E:4C:10:87:5F:A0 nodemac=AA:B8:4C:CD:D3:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.732Z",
  "value": "id=1193  sec_id=4     flags=0x0000 ifindex=10  mac=76:32:D3:7E:C9:70 nodemac=8A:25:D6:62:C4:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.795Z",
  "value": "id=2320  sec_id=5540605 flags=0x0000 ifindex=14  mac=EA:D5:31:EA:E2:A2 nodemac=66:5F:20:6D:72:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.876Z",
  "value": "id=3159  sec_id=5540605 flags=0x0000 ifindex=12  mac=0E:4C:10:87:5F:A0 nodemac=AA:B8:4C:CD:D3:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:27.212Z",
  "value": "id=2320  sec_id=5540605 flags=0x0000 ifindex=14  mac=EA:D5:31:EA:E2:A2 nodemac=66:5F:20:6D:72:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:27.213Z",
  "value": "id=1193  sec_id=4     flags=0x0000 ifindex=10  mac=76:32:D3:7E:C9:70 nodemac=8A:25:D6:62:C4:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:27.214Z",
  "value": "id=3159  sec_id=5540605 flags=0x0000 ifindex=12  mac=0E:4C:10:87:5F:A0 nodemac=AA:B8:4C:CD:D3:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:27.242Z",
  "value": "id=1030  sec_id=5510743 flags=0x0000 ifindex=16  mac=82:EB:9E:1D:D5:F3 nodemac=DA:88:BE:2E:47:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:28.213Z",
  "value": "id=2320  sec_id=5540605 flags=0x0000 ifindex=14  mac=EA:D5:31:EA:E2:A2 nodemac=66:5F:20:6D:72:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:28.213Z",
  "value": "id=1193  sec_id=4     flags=0x0000 ifindex=10  mac=76:32:D3:7E:C9:70 nodemac=8A:25:D6:62:C4:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:28.214Z",
  "value": "id=1030  sec_id=5510743 flags=0x0000 ifindex=16  mac=82:EB:9E:1D:D5:F3 nodemac=DA:88:BE:2E:47:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:28.214Z",
  "value": "id=3159  sec_id=5540605 flags=0x0000 ifindex=12  mac=0E:4C:10:87:5F:A0 nodemac=AA:B8:4C:CD:D3:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:16.424Z",
  "value": "id=2344  sec_id=5510743 flags=0x0000 ifindex=18  mac=1E:98:60:A7:9E:14 nodemac=BA:C1:79:BA:07:27"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.83.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:26.767Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.091Z",
  "value": "id=1193  sec_id=4     flags=0x0000 ifindex=10  mac=76:32:D3:7E:C9:70 nodemac=8A:25:D6:62:C4:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.092Z",
  "value": "id=3159  sec_id=5540605 flags=0x0000 ifindex=12  mac=0E:4C:10:87:5F:A0 nodemac=AA:B8:4C:CD:D3:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.092Z",
  "value": "id=2320  sec_id=5540605 flags=0x0000 ifindex=14  mac=EA:D5:31:EA:E2:A2 nodemac=66:5F:20:6D:72:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.092Z",
  "value": "id=2344  sec_id=5510743 flags=0x0000 ifindex=18  mac=1E:98:60:A7:9E:14 nodemac=BA:C1:79:BA:07:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:23.092Z",
  "value": "id=1193  sec_id=4     flags=0x0000 ifindex=10  mac=76:32:D3:7E:C9:70 nodemac=8A:25:D6:62:C4:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:23.093Z",
  "value": "id=3159  sec_id=5540605 flags=0x0000 ifindex=12  mac=0E:4C:10:87:5F:A0 nodemac=AA:B8:4C:CD:D3:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:23.093Z",
  "value": "id=2344  sec_id=5510743 flags=0x0000 ifindex=18  mac=1E:98:60:A7:9E:14 nodemac=BA:C1:79:BA:07:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:23.093Z",
  "value": "id=2320  sec_id=5540605 flags=0x0000 ifindex=14  mac=EA:D5:31:EA:E2:A2 nodemac=66:5F:20:6D:72:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:24.092Z",
  "value": "id=1193  sec_id=4     flags=0x0000 ifindex=10  mac=76:32:D3:7E:C9:70 nodemac=8A:25:D6:62:C4:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:24.093Z",
  "value": "id=3159  sec_id=5540605 flags=0x0000 ifindex=12  mac=0E:4C:10:87:5F:A0 nodemac=AA:B8:4C:CD:D3:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:24.093Z",
  "value": "id=2344  sec_id=5510743 flags=0x0000 ifindex=18  mac=1E:98:60:A7:9E:14 nodemac=BA:C1:79:BA:07:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.83.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:24.093Z",
  "value": "id=2320  sec_id=5540605 flags=0x0000 ifindex=14  mac=EA:D5:31:EA:E2:A2 nodemac=66:5F:20:6D:72:6A"
}

