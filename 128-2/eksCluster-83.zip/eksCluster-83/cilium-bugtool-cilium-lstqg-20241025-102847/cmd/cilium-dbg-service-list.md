ID   Frontend            Service Type   Backend                            
1    10.100.0.1:443      ClusterIP      1 => 172.31.245.198:443 (active)   
                                        2 => 172.31.176.101:443 (active)   
2    10.100.84.60:443    ClusterIP      1 => 172.31.231.66:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.83.0.78:53 (active)        
                                        2 => 10.83.0.237:53 (active)       
4    10.100.0.10:9153    ClusterIP      1 => 10.83.0.78:9153 (active)      
                                        2 => 10.83.0.237:9153 (active)     
5    10.100.153.8:2379   ClusterIP      1 => 10.83.0.150:2379 (active)     
