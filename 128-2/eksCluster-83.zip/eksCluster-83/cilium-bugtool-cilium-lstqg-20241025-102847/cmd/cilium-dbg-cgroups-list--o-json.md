[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod45329a82_f63e_49b7_9764_7e4cabef9bad.slice/cri-containerd-296f2432f0e5d2210cb8b5bf2c1cb9a8ce1e416deb074e32aab63f298972228a.scope"
      }
    ],
    "ips": [
      "10.83.0.78"
    ],
    "name": "coredns-cc6ccd49c-cwnc6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode1eb06d9_b682_4f4c_a48f_a02a6cd1df79.slice/cri-containerd-ef9d13528e7c46d0cee8f895b0334d1e0587cd6839cf660a3fa21cc644a37255.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode1eb06d9_b682_4f4c_a48f_a02a6cd1df79.slice/cri-containerd-4e5003c0dc128fa11885099dad63714d66299bd2f8cb5dad00120106ae91cd31.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode1eb06d9_b682_4f4c_a48f_a02a6cd1df79.slice/cri-containerd-ad5d0c86ba95c5ef56b28bc004d21e11e669caea99e336958115e6a9a7cd6e92.scope"
      }
    ],
    "ips": [
      "10.83.0.150"
    ],
    "name": "clustermesh-apiserver-7dbf7fb7b6-gq6mz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod694fc9c4_7e76_4ea1_85ee_f02449a9cdf5.slice/cri-containerd-eaf008f8cebec61939bf9e2b7b02e08ba63e36f6d90d77d3c9e76f1ea75fedd0.scope"
      }
    ],
    "ips": [
      "10.83.0.237"
    ],
    "name": "coredns-cc6ccd49c-j7457",
    "namespace": "kube-system"
  }
]

