key: a9 04 00 00  value: ff 01 00 00
key: 10 09 00 00  value: 0c 02 00 00
key: 28 09 00 00  value: 73 02 00 00
key: 57 0c 00 00  value: 19 02 00 00
Found 4 elements
