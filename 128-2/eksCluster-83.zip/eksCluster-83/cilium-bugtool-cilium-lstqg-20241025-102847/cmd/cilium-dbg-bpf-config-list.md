KEY             VALUE
AgentLiveness   828000148549
UTimeOffset     3378615882812500
