Node 0, zone      DMA      2      4      4      3      7      2      5      3      3      4    165 
Node 0, zone   Normal    320     27      7      3     23      1     13      7      2      1      7 
