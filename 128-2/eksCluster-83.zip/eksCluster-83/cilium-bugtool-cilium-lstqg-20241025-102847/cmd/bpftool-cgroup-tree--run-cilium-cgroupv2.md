CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod45329a82_f63e_49b7_9764_7e4cabef9bad.slice/cri-containerd-296f2432f0e5d2210cb8b5bf2c1cb9a8ce1e416deb074e32aab63f298972228a.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod45329a82_f63e_49b7_9764_7e4cabef9bad.slice/cri-containerd-65c7af8f6dc8564d27cbabd2ae3df57eef463f43ec22fdde33f6b960f5e102f7.scope
    530      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod33efda03_be31_4288_851c_39595a42ca1d.slice/cri-containerd-b05157ad6a995270b48da75555bc961773db786cbb05c74ae5633c61e803ed5e.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod33efda03_be31_4288_851c_39595a42ca1d.slice/cri-containerd-7b9334816c7b95feb3242a5308cdc482e26f70bd819901ba758777e46d011b33.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbea1b898_2241_4fb4_ae08_8835def31aa3.slice/cri-containerd-87de9ed5f687226557dda4e342a6bc4cde077383712122c65bb254a56918a4ff.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbea1b898_2241_4fb4_ae08_8835def31aa3.slice/cri-containerd-851a13ccccecd1aede1293e82e6e3bf082c8c657f924e272a453f1453377256f.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod694fc9c4_7e76_4ea1_85ee_f02449a9cdf5.slice/cri-containerd-ad8286bd6fa84e1e45ecc0df75fff4caf8f847ac47d70c9822d1bea1302420f7.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod694fc9c4_7e76_4ea1_85ee_f02449a9cdf5.slice/cri-containerd-eaf008f8cebec61939bf9e2b7b02e08ba63e36f6d90d77d3c9e76f1ea75fedd0.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod490438c9_7a3f_4f72_915a_f7a889fcfb68.slice/cri-containerd-258173f829b4b9133fbcc125d29da65d052862a726c3dc8cc957e3dd9a408103.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod490438c9_7a3f_4f72_915a_f7a889fcfb68.slice/cri-containerd-a55a6b01734b9cdce1be2d06aa1c017bf240edde5f5235c6fffc3b4a6e243920.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode1eb06d9_b682_4f4c_a48f_a02a6cd1df79.slice/cri-containerd-2ab3de611d3d9383a803b4fdce2e559ed020c72819ec3d4204e660997e35d867.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode1eb06d9_b682_4f4c_a48f_a02a6cd1df79.slice/cri-containerd-4e5003c0dc128fa11885099dad63714d66299bd2f8cb5dad00120106ae91cd31.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode1eb06d9_b682_4f4c_a48f_a02a6cd1df79.slice/cri-containerd-ad5d0c86ba95c5ef56b28bc004d21e11e669caea99e336958115e6a9a7cd6e92.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode1eb06d9_b682_4f4c_a48f_a02a6cd1df79.slice/cri-containerd-ef9d13528e7c46d0cee8f895b0334d1e0587cd6839cf660a3fa21cc644a37255.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6809e094_f814_4055_960b_766b439fbfc9.slice/cri-containerd-762453bc9e362ab77c25017115fccc03ed65f88b9e504391728e59bef81062b7.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6809e094_f814_4055_960b_766b439fbfc9.slice/cri-containerd-bb24d07b0f347daa436bf93b58dd1fae66fbe5bd888d3aaec683506c093bfdaf.scope
    90       cgroup_device   multi                                          
