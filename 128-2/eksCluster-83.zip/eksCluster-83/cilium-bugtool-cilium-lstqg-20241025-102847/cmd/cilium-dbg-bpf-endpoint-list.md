IP ADDRESS         LOCAL ENDPOINT INFO
172.31.231.66:0    (localhost)                                                                                        
10.83.0.78:0       id=2320  sec_id=5540605 flags=0x0000 ifindex=14  mac=EA:D5:31:EA:E2:A2 nodemac=66:5F:20:6D:72:6A   
10.83.0.237:0      id=3159  sec_id=5540605 flags=0x0000 ifindex=12  mac=0E:4C:10:87:5F:A0 nodemac=AA:B8:4C:CD:D3:63   
10.83.0.53:0       id=1193  sec_id=4     flags=0x0000 ifindex=10  mac=76:32:D3:7E:C9:70 nodemac=8A:25:D6:62:C4:06     
10.83.0.150:0      id=2344  sec_id=5510743 flags=0x0000 ifindex=18  mac=1E:98:60:A7:9E:14 nodemac=BA:C1:79:BA:07:27   
10.83.0.221:0      (localhost)                                                                                        
172.31.205.221:0   (localhost)                                                                                        
