IP ADDRESS        LOCAL ENDPOINT INFO
172.31.133.70:0   (localhost)                                                                                        
172.31.178.90:0   (localhost)                                                                                        
10.78.0.227:0     id=1845  sec_id=5181692 flags=0x0000 ifindex=12  mac=B6:B7:36:C9:B9:9D nodemac=3E:46:25:0A:12:64   
10.78.0.60:0      id=525   sec_id=4     flags=0x0000 ifindex=10  mac=5A:42:F3:F2:4E:7A nodemac=AA:03:67:F2:C6:D0     
10.78.0.235:0     (localhost)                                                                                        
10.78.0.239:0     id=1043  sec_id=5181692 flags=0x0000 ifindex=14  mac=C6:CB:2E:E0:B0:2A nodemac=A6:79:40:50:87:37   
10.78.0.154:0     id=156   sec_id=5234507 flags=0x0000 ifindex=18  mac=BE:93:40:ED:94:FB nodemac=C2:CD:4C:CC:36:34   
