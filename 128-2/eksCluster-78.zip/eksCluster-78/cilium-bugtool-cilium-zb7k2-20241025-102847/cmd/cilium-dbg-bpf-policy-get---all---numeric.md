Endpoint ID: 156
Path: /sys/fs/bpf/tc/globals/cilium_policy_00156

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3826490   36568     0        
Allow    Ingress     1          ANY          NONE         disabled    3532461   36171     0        
Allow    Egress      0          ANY          NONE         disabled    5452544   50029     0        


Endpoint ID: 525
Path: /sys/fs/bpf/tc/globals/cilium_policy_00525

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    438040   5585      0        
Allow    Ingress     1          ANY          NONE         disabled    11458    137       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1043
Path: /sys/fs/bpf/tc/globals/cilium_policy_01043

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69570   796       0        
Allow    Egress      0          ANY          NONE         disabled    12585   129       0        


Endpoint ID: 1845
Path: /sys/fs/bpf/tc/globals/cilium_policy_01845

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69372   793       0        
Allow    Egress      0          ANY          NONE         disabled    12278   125       0        


Endpoint ID: 3603
Path: /sys/fs/bpf/tc/globals/cilium_policy_03603

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


