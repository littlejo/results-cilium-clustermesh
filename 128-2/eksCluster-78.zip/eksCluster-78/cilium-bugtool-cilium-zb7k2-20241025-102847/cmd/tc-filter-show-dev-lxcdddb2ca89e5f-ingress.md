filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcdddb2ca89e5f direct-action not_in_hw id 520 tag 428a6d1d5006b680 jited 
