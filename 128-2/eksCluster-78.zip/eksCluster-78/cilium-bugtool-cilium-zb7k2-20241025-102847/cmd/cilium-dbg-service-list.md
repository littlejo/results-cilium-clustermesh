ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.198.154:443 (active)   
                                         2 => 172.31.132.212:443 (active)   
2    10.100.43.103:443    ClusterIP      1 => 172.31.133.70:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.78.0.227:53 (active)       
                                         2 => 10.78.0.239:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.78.0.227:9153 (active)     
                                         2 => 10.78.0.239:9153 (active)     
5    10.100.16.158:2379   ClusterIP      1 => 10.78.0.154:2379 (active)     
