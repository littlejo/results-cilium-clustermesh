KEY             VALUE
AgentLiveness   859142895298
UTimeOffset     3378615822265625
