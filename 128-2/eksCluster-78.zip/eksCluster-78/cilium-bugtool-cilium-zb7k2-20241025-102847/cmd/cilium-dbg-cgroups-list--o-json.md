[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod76b40ad7_c0ab_40aa_b653_0966a7623b26.slice/cri-containerd-25e48b5baa134227cef74d621b4b8b917db86a6e5b3d473cce5f0ad2e988eedd.scope"
      }
    ],
    "ips": [
      "10.78.0.227"
    ],
    "name": "coredns-cc6ccd49c-64276",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62fcae1e_f7ef_441d_b731_a2ea30b43566.slice/cri-containerd-c5caadd606278430c6c114e0ff8a823676a5b548c18d5c0c1b6f934a379e50ea.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62fcae1e_f7ef_441d_b731_a2ea30b43566.slice/cri-containerd-0ed1008059285a0d3c30064cb0cca4324344a029dc93aad9ccea32256ffca652.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62fcae1e_f7ef_441d_b731_a2ea30b43566.slice/cri-containerd-21c1d2723ee063940705097ef0450cc2d7c814eec8fd3d68e9ca2ca9583ab038.scope"
      }
    ],
    "ips": [
      "10.78.0.154"
    ],
    "name": "clustermesh-apiserver-556f68d94b-rgvfh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9d23418f_10b0_4b0a_b3fb_3d785f8e4788.slice/cri-containerd-eac58686e50e75821c7d5e106bc8ad936ab05204228ce3bbdf315cfa5262608a.scope"
      }
    ],
    "ips": [
      "10.78.0.239"
    ],
    "name": "coredns-cc6ccd49c-tbgrq",
    "namespace": "kube-system"
  }
]

