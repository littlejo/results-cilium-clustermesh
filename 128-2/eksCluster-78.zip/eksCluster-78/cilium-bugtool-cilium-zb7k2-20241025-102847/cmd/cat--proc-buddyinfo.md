Node 0, zone      DMA      1      1      3      3     12     11     21     13     10      4    162 
Node 0, zone   Normal    224    103      7      2     17     10      3      2      2      3      7 
