top - 10:28:49 up 13 min,  0 users,  load average: 0.36, 0.19, 0.12
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 59.4 us, 37.5 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  3.1 si,  0.0 st
MiB Mem :   3836.2 total,    775.0 free,    920.0 used,   2141.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2747.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 282328  78132 S  87.5   7.2   0:25.87 cilium-+
    621 root      20   0 1229640  16276   4004 S  12.5   0.4   0:00.02 gops
    647 root      20   0 1240432  16788  11484 S  12.5   0.4   0:00.03 cilium-+
    392 root      20   0 1228848   6016   2928 S   0.0   0.2   0:00.27 cilium-+
    641 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
    659 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    675 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    707 root      20   0    6576   2408   2084 R   0.0   0.1   0:00.00 top
    728 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
