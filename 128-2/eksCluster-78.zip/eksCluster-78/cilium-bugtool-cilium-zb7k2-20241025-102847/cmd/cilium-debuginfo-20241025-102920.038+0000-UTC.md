# Cilium debug information

#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.78.0.0/24, 
Allocated addresses:
  10.78.0.154 (kube-system/clustermesh-apiserver-556f68d94b-rgvfh)
  10.78.0.227 (kube-system/coredns-cc6ccd49c-64276)
  10.78.0.235 (router)
  10.78.0.239 (kube-system/coredns-cc6ccd49c-tbgrq)
  10.78.0.60 (health)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: cdebfe2e180d2e79
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    37s ago        never        0       no error   
  ct-map-pressure                                                     8s ago         never        0       no error   
  daemon-validate-config                                              26s ago        never        0       no error   
  dns-garbage-collector-job                                           40s ago        never        0       no error   
  endpoint-1043-regeneration-recovery                                 never          never        0       no error   
  endpoint-156-regeneration-recovery                                  never          never        0       no error   
  endpoint-1845-regeneration-recovery                                 never          never        0       no error   
  endpoint-3603-regeneration-recovery                                 never          never        0       no error   
  endpoint-525-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         2m41s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                8s ago         never        0       no error   
  ipcache-inject-labels                                               38s ago        never        0       no error   
  k8s-heartbeat                                                       11s ago        never        0       no error   
  link-cache                                                          8s ago         never        0       no error   
  local-identity-checkpoint                                           12m38s ago     never        0       no error   
  node-neighbor-link-updater                                          8s ago         never        0       no error   
  remote-etcd-cmesh1                                                  7m35s ago      never        0       no error   
  remote-etcd-cmesh10                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh100                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh101                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh102                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh103                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh104                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh105                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh106                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh107                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh108                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh109                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh11                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh110                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh111                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh112                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh113                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh114                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh115                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh116                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh117                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh118                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh119                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh12                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh120                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh121                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh122                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh123                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh124                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh125                                                7m36s ago      never        0       no error   
  remote-etcd-cmesh126                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh127                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh128                                                7m35s ago      never        0       no error   
  remote-etcd-cmesh13                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh14                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh15                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh16                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh17                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh18                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh19                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh2                                                  7m35s ago      never        0       no error   
  remote-etcd-cmesh20                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh21                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh22                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh23                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh24                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh25                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh26                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh27                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh28                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh29                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh3                                                  7m35s ago      never        0       no error   
  remote-etcd-cmesh30                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh31                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh32                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh33                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh34                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh35                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh36                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh37                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh38                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh39                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh4                                                  7m35s ago      never        0       no error   
  remote-etcd-cmesh40                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh41                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh42                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh43                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh44                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh45                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh46                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh47                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh48                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh49                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh5                                                  7m36s ago      never        0       no error   
  remote-etcd-cmesh50                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh51                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh52                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh53                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh54                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh55                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh56                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh57                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh58                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh59                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh6                                                  7m35s ago      never        0       no error   
  remote-etcd-cmesh60                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh61                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh62                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh63                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh64                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh65                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh66                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh67                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh68                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh69                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh7                                                  7m35s ago      never        0       no error   
  remote-etcd-cmesh70                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh71                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh72                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh73                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh74                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh75                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh76                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh77                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh78                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh8                                                  7m35s ago      never        0       no error   
  remote-etcd-cmesh80                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh81                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh82                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh83                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh84                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh85                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh86                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh87                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh88                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh89                                                 7m36s ago      never        0       no error   
  remote-etcd-cmesh9                                                  7m35s ago      never        0       no error   
  remote-etcd-cmesh90                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh91                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh92                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh93                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh94                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh95                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh96                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh97                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh98                                                 7m35s ago      never        0       no error   
  remote-etcd-cmesh99                                                 7m35s ago      never        0       no error   
  resolve-identity-1043                                               2m36s ago      never        0       no error   
  resolve-identity-156                                                3m7s ago       never        0       no error   
  resolve-identity-1845                                               2m36s ago      never        0       no error   
  resolve-identity-3603                                               2m38s ago      never        0       no error   
  resolve-identity-525                                                2m37s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-556f68d94b-rgvfh   8m7s ago       never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-64276                  12m36s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-tbgrq                  12m36s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      12m38s ago     never        0       no error   
  sync-policymap-1043                                                 12m33s ago     never        0       no error   
  sync-policymap-156                                                  8m7s ago       never        0       no error   
  sync-policymap-1845                                                 12m33s ago     never        0       no error   
  sync-policymap-3603                                                 12m37s ago     never        0       no error   
  sync-policymap-525                                                  12m34s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (1043)                                   6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (156)                                    7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1845)                                   6s ago         never        0       no error   
  sync-utime                                                          38s ago        never        0       no error   
  write-cni-file                                                      12m41s ago     never        0       no error   
Proxy Status:            OK, ip 10.78.0.235, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 5177344, max 5242879
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 89.33   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
procfs:/host/proc
kvstore-max-consecutive-quorum-errors:2
tofqdns-proxy-response-max-delay:100ms
k8s-require-ipv6-pod-cidr:false
bpf-events-trace-enabled:true
enable-ipv4-masquerade:true
enable-local-node-route:true
k8s-client-connection-timeout:30s
hubble-redact-http-headers-allow:
kvstore-periodic-sync:5m0s
enable-pmtu-discovery:false
ip-masq-agent-config-path:/etc/config/ip-masq-agent
config-dir:/tmp/cilium/config-map
ipv4-service-loopback-address:169.254.42.1
gateway-api-secrets-namespace:
ipam-multi-pool-pre-allocation:
hubble-export-denylist:
log-system-load:false
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
allocator-list-timeout:3m0s
certificates-directory:/var/run/cilium/certs
proxy-portrange-min:10000
derive-masq-ip-addr-from-device:
auto-create-cilium-node-resource:true
ipv4-node:auto
enable-auto-protect-node-port-range:true
bpf-ct-timeout-regular-tcp-fin:10s
cilium-endpoint-gc-interval:5m0s
bpf-lb-affinity-map-max:0
node-port-algorithm:random
enable-ip-masq-agent:false
bpf-ct-timeout-regular-any:1m0s
enable-bpf-clock-probe:false
disable-endpoint-crd:false
enable-srv6:false
service-no-backend-response:reject
enable-hubble:true
allow-localhost:auto
enable-tracing:false
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
exclude-node-label-patterns:
hubble-drop-events:false
restore:true
bpf-neigh-global-max:524288
enable-endpoint-health-checking:true
dnsproxy-concurrency-limit:0
enable-k8s-networkpolicy:true
enable-ipsec-key-watcher:true
encryption-strict-mode-allow-remote-node-identities:false
hubble-recorder-storage-path:/var/run/cilium/pcaps
enable-xt-socket-fallback:true
tofqdns-max-deferred-connection-deletes:10000
enable-session-affinity:false
hubble-redact-kafka-apikey:false
mesh-auth-spire-admin-socket:
direct-routing-device:
enable-l7-proxy:true
dnsproxy-concurrency-processing-grace-period:0s
k8s-api-server:
enable-high-scale-ipcache:false
identity-gc-interval:15m0s
enable-xdp-prefilter:false
clustermesh-ip-identities-sync-timeout:1m0s
enable-cilium-api-server-access:
hubble-export-file-compress:false
disable-envoy-version-check:false
hubble-export-fieldmask:
endpoint-bpf-prog-watchdog-interval:30s
install-iptables-rules:true
ipv6-node:auto
state-dir:/var/run/cilium
vtep-cidr:
hubble-socket-path:/var/run/cilium/hubble.sock
policy-queue-size:100
enable-bbr:false
ipv6-range:auto
ipv4-service-range:auto
kvstore-connectivity-timeout:2m0s
route-metric:0
enable-bpf-tproxy:false
enable-well-known-identities:false
datapath-mode:veth
ipam-cilium-node-update-rate:15s
enable-host-legacy-routing:false
dns-max-ips-per-restored-rule:1000
enable-bpf-masquerade:false
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
trace-sock:true
routing-mode:tunnel
enable-route-mtu-for-cni-chaining:false
enable-bgp-control-plane:false
hubble-redact-enabled:false
agent-health-port:9879
policy-audit-mode:false
arping-refresh-period:30s
disable-external-ip-mitigation:false
agent-labels:
node-port-range:
exclude-local-address:
enable-tcx:true
cluster-id:79
enable-endpoint-routes:false
bgp-announce-lb-ip:false
bpf-nat-global-max:524288
read-cni-conf:
enable-stale-cilium-endpoint-cleanup:true
enable-ipv6-ndp:false
tofqdns-endpoint-max-ip-per-hostname:50
vtep-mac:
hubble-skip-unknown-cgroup-ids:true
labels:
conntrack-gc-max-interval:0s
trace-payloadlen:128
mesh-auth-queue-size:1024
fqdn-regex-compile-lru-size:1024
label-prefix-file:
hubble-recorder-sink-queue-size:1024
identity-heartbeat-timeout:30m0s
k8s-service-proxy-name:
enable-recorder:false
enable-health-check-nodeport:true
bpf-lb-map-max:65536
egress-gateway-policy-map-max:16384
bpf-map-dynamic-size-ratio:0.0025
endpoint-queue-size:25
mesh-auth-rotated-identities-queue-size:1024
static-cnp-path:
allow-icmp-frag-needed:true
bpf-ct-timeout-service-any:1m0s
bpf-lb-sock-terminate-pod-connections:false
enable-identity-mark:true
log-opt:
proxy-xff-num-trusted-hops-egress:0
dnsproxy-insecure-skip-transparent-mode-check:false
bpf-lb-rss-ipv6-src-cidr:
ipsec-key-file:
bpf-lb-service-map-max:0
remove-cilium-node-taints:true
enable-ipsec-encrypted-overlay:false
ipv6-service-range:auto
bpf-ct-global-any-max:262144
enable-masquerade-to-route-source:false
enable-external-ips:false
envoy-secrets-namespace:
ipv6-native-routing-cidr:
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
enable-ipv6-masquerade:true
enable-node-port:false
enable-ipsec-xfrm-state-caching:true
multicast-enabled:false
enable-custom-calls:false
bpf-sock-rev-map-max:262144
identity-allocation-mode:crd
clustermesh-sync-timeout:1m0s
kube-proxy-replacement-healthz-bind-address:
container-ip-local-reserved-ports:auto
hubble-export-file-path:
max-controller-interval:0
cflags:
bpf-filter-priority:1
install-no-conntrack-iptables-rules:false
mesh-auth-mutual-listener-port:0
http-max-grpc-timeout:0
hubble-prefer-ipv6:false
unmanaged-pod-watcher-interval:15
force-device-detection:false
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
bpf-events-drop-enabled:true
vtep-mask:
cmdref:
enable-icmp-rules:true
tofqdns-min-ttl:0
hubble-redact-http-headers-deny:
api-rate-limit:
enable-health-check-loadbalancer-ip:false
enable-active-connection-tracking:false
tofqdns-idle-connection-grace-period:0s
k8s-sync-timeout:3m0s
clustermesh-enable-mcs-api:false
enable-l2-pod-announcements:false
egress-masquerade-interfaces:ens+
egress-gateway-reconciliation-trigger-interval:1s
nodeport-addresses:
enable-monitor:true
join-cluster:false
enable-l2-announcements:false
http-retry-timeout:0
fixed-identity-mapping:
bpf-lb-dsr-l4-xlate:frontend
encrypt-node:false
bpf-ct-global-tcp-max:524288
proxy-xff-num-trusted-hops-ingress:0
enable-wireguard:false
hubble-redact-http-userinfo:true
bpf-fragments-map-max:8192
bpf-lb-mode:snat
ingress-secrets-namespace:
synchronize-k8s-nodes:true
tofqdns-pre-cache:
vtep-endpoint:
k8s-require-ipv4-pod-cidr:false
bpf-lb-dsr-dispatch:opt
ipv6-cluster-alloc-cidr:f00d::/64
encrypt-interface:
proxy-idle-timeout-seconds:60
bpf-lb-acceleration:disabled
proxy-gid:1337
hubble-flowlogs-config-path:
bpf-lb-source-range-map-max:0
k8s-client-burst:20
mesh-auth-mutual-connect-timeout:5s
enable-gateway-api:false
enable-k8s-api-discovery:false
bpf-auth-map-max:524288
enable-cilium-endpoint-slice:false
kube-proxy-replacement:false
enable-ipv6:false
tofqdns-enable-dns-compression:true
envoy-log:
kvstore-lease-ttl:15m0s
l2-pod-announcements-interface:
policy-accounting:true
annotate-k8s-node:false
l2-announcements-renew-deadline:5s
nodes-gc-interval:5m0s
use-full-tls-context:false
ipv4-pod-subnets:
proxy-connect-timeout:2
http-idle-timeout:0
identity-change-grace-period:5s
hubble-metrics-server:
gops-port:9890
direct-routing-skip-unreachable:false
set-cilium-is-up-condition:true
config-sources:config-map:kube-system/cilium-config
bpf-lb-sock-hostns-only:false
enable-sctp:false
enable-health-checking:true
enable-runtime-device-detection:true
enable-vtep:false
enable-ipv6-big-tcp:false
enable-node-selector-labels:false
nat-map-stats-interval:30s
monitor-queue-size:0
tofqdns-proxy-port:0
bpf-root:/sys/fs/bpf
pprof:false
bpf-lb-maglev-map-max:0
cni-external-routing:false
bpf-lb-maglev-table-size:16381
external-envoy-proxy:true
monitor-aggregation:medium
clustermesh-enable-endpoint-sync:false
enable-k8s:true
bpf-lb-external-clusterip:false
mesh-auth-signal-backoff-duration:1s
ipsec-key-rotation-duration:5m0s
wireguard-persistent-keepalive:0s
debug:false
keep-config:false
cluster-pool-ipv4-mask-size:24
kvstore:
nat-map-stats-entries:32
ipam:cluster-pool
proxy-max-connection-duration-seconds:0
max-connected-clusters:255
enable-unreachable-routes:false
envoy-config-timeout:2m0s
hubble-redact-http-urlquery:false
disable-iptables-feeder-rules:
hubble-drop-events-interval:2m0s
k8s-client-connection-keep-alive:30s
encryption-strict-mode-cidr:
tofqdns-dns-reject-response-code:refused
l2-announcements-lease-duration:15s
ipv4-range:auto
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
enable-host-port:false
clustermesh-config:/var/lib/cilium/clustermesh/
bpf-ct-timeout-service-tcp:2h13m20s
metrics:
k8s-service-cache-size:128
cni-log-file:/var/run/cilium/cilium-cni.log
enable-bandwidth-manager:false
bpf-lb-service-backend-map-max:0
http-retry-count:3
bgp-announce-pod-cidr:false
proxy-max-requests-per-connection:0
node-labels:
cluster-health-port:4240
srv6-encap-mode:reduced
hubble-export-allowlist:
proxy-portrange-max:20000
enable-l2-neigh-discovery:true
node-port-mode:snat
enable-wireguard-userspace-fallback:false
envoy-keep-cap-netbindservice:false
cgroup-root:/run/cilium/cgroupv2
bpf-lb-rss-ipv4-src-cidr:
proxy-prometheus-port:0
k8s-client-qps:10
ipv4-native-routing-cidr:
http-request-timeout:3600
cni-exclusive:true
local-router-ipv4:
endpoint-gc-interval:5m0s
node-port-bind-protection:true
policy-trigger-interval:1s
operator-prometheus-serve-addr::9963
enable-ipv4-big-tcp:false
enable-mke:false
tunnel-port:0
dnsproxy-enable-transparent-mode:true
use-cilium-internal-ip-for-ipsec:false
l2-announcements-retry-period:2s
version:false
iptables-random-fully:false
enable-cilium-health-api-server-access:
mke-cgroup-mount:
cluster-pool-ipv4-cidr:10.78.0.0/16
debug-verbose:
log-driver:
bpf-policy-map-max:16384
monitor-aggregation-flags:all
bpf-node-map-max:16384
policy-cidr-match-mode:
bgp-config-path:/var/lib/cilium/bgp/config.yaml
k8s-kubeconfig-path:
bpf-ct-timeout-regular-tcp:2h13m20s
cni-chaining-mode:none
envoy-base-id:0
hubble-listen-address::4244
identity-restore-grace-period:30s
enable-service-topology:false
kvstore-opt:
pprof-port:6060
auto-direct-node-routes:false
agent-liveness-update-interval:1s
bpf-events-policy-verdict-enabled:true
vlan-bpf-bypass:
bpf-policy-map-full-reconciliation-interval:15m0s
dnsproxy-lock-count:131
enable-svc-source-range-check:true
bpf-map-event-buffers:
proxy-admin-port:0
bpf-lb-sock:false
mesh-auth-enabled:true
enable-k8s-endpoint-slice:true
bpf-ct-timeout-service-tcp-grace:1m0s
ipam-default-ip-pool:default
controller-group-metrics:
hubble-disable-tls:false
ipv6-pod-subnets:
envoy-config-retry-interval:15s
conntrack-gc-interval:0s
bpf-ct-timeout-regular-tcp-syn:1m0s
hubble-metrics:
egress-multi-home-ip-rule-compat:false
bypass-ip-availability-upon-restore:false
enable-hubble-recorder-api:true
max-internal-timer-delay:0s
bpf-lb-algorithm:random
ipv6-mcast-device:
enable-ipsec:false
local-router-ipv6:
mesh-auth-spiffe-trust-domain:spiffe.cilium
cni-chaining-target:
hubble-event-queue-size:0
mesh-auth-gc-interval:5m0s
http-normalize-path:true
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
local-max-addr-scope:252
crd-wait-timeout:5m0s
operator-api-serve-addr:127.0.0.1:9234
enable-ingress-controller:false
enable-ipip-termination:false
enable-metrics:true
lib-dir:/var/lib/cilium
enable-encryption-strict-mode:false
monitor-aggregation-interval:5s
enable-host-firewall:false
hubble-monitor-events:
enable-nat46x64-gateway:false
cluster-name:cmesh79
devices:
mtu:0
hubble-event-buffer-capacity:4095
iptables-lock-timeout:5s
enable-local-redirect-policy:false
hubble-export-file-max-backups:5
dnsproxy-lock-timeout:500ms
pprof-address:localhost
enable-ipv4:true
enable-envoy-config:false
prepend-iptables-chains:true
dns-policy-unload-on-shutdown:false
tunnel-protocol:vxlan
preallocate-bpf-maps:false
enable-ipv4-egress-gateway:false
hubble-export-file-max-size-mb:10
set-cilium-node-taints:true
k8s-heartbeat-timeout:30s
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
node-port-acceleration:disabled
socket-path:/var/run/cilium/cilium.sock
enable-policy:default
enable-k8s-terminating-endpoint:true
hubble-drop-events-reasons:auth_required,policy_denied
dnsproxy-socket-linger-timeout:10
prometheus-serve-addr:
k8s-namespace:kube-system
config:
enable-ipv4-fragment-tracking:true
bpf-lb-rev-nat-map-max:0
custom-cni-conf:false
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
156        Disabled           Disabled          5234507    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.78.0.154   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh79                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
525        Disabled           Disabled          4          reserved:health                                                                     10.78.0.60    ready   
1043       Disabled           Disabled          5181692    k8s:eks.amazonaws.com/component=coredns                                             10.78.0.239   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh79                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
1845       Disabled           Disabled          5181692    k8s:eks.amazonaws.com/component=coredns                                             10.78.0.227   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh79                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
3603       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                
                                                           reserved:host                                                                                             
```

#### BPF Policy Get 156

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3814656   36437     0        
Allow    Ingress     1          ANY          NONE         disabled    3531433   36159     0        
Allow    Egress      0          ANY          NONE         disabled    5439500   49883     0        

```


#### BPF CT List 156

```
Invalid argument: unknown type 156
```


#### Endpoint Get 156

```
[
  {
    "id": 156,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-156-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "75505370-8b10-44ac-8568-69cccfde7c67"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-156",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:12.150Z",
            "success-count": 2
          },
          "uuid": "915abb65-80ba-4437-8229-1f96374c2afb"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-556f68d94b-rgvfh",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:12.148Z",
            "success-count": 1
          },
          "uuid": "cd3c0638-4fd4-40db-8293-15a5de5132fe"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-156",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:12.178Z",
            "success-count": 1
          },
          "uuid": "037d7704-ed92-4449-8bf3-74957c6c2743"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (156)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:12.197Z",
            "success-count": 50
          },
          "uuid": "24b32874-5896-490b-9b51-3a987b501931"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "887da16e966bdfe2c98538787fb6b2da2306ec7fec06fc4a9343242a938d0e3a:eth0",
        "container-id": "887da16e966bdfe2c98538787fb6b2da2306ec7fec06fc4a9343242a938d0e3a",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-556f68d94b-rgvfh",
        "pod-name": "kube-system/clustermesh-apiserver-556f68d94b-rgvfh"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5234507,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh79",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=556f68d94b"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh79",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:45Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.78.0.154",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "c2:cd:4c:cc:36:34",
        "interface-index": 18,
        "interface-name": "lxc519068d175ce",
        "mac": "be:93:40:ed:94:fb"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5234507,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5234507,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 156

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 156

```
Timestamp              Status   State                   Message
2024-10-25T10:21:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:45Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:12Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:12Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:12Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 5234507

```
ID        LABELS
5234507   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh79
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 525

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    435897   5557      0        
Allow    Ingress     1          ANY          NONE         disabled    11458    137       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 525

```
Invalid argument: unknown type 525
```


#### Endpoint Get 525

```
[
  {
    "id": 525,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-525-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "efd51f22-0785-4059-bad8-d854665ec17b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-525",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:42.805Z",
            "success-count": 3
          },
          "uuid": "3a74b9f1-fb6d-4edd-8a1c-222785939cc3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-525",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:46.038Z",
            "success-count": 1
          },
          "uuid": "0da3853e-ca84-446c-a29e-cc8bb0e5a04d"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:45Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.78.0.60",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "aa:03:67:f2:c6:d0",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "5a:42:f3:f2:4e:7a"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 525

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 525

```
Timestamp              Status   State                   Message
2024-10-25T10:21:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:45Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:46Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:46Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:16:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:16:43Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:16:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:42Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:16:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:16:42Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:16:41Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 1043

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69570   796       0        
Allow    Egress      0          ANY          NONE         disabled    12585   129       0        

```


#### BPF CT List 1043

```
Invalid argument: unknown type 1043
```


#### Endpoint Get 1043

```
[
  {
    "id": 1043,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1043-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "e4a1f647-cffe-483e-83d3-1cc1d9356d94"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1043",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:43.419Z",
            "success-count": 3
          },
          "uuid": "3ac70044-9b69-415e-888d-c9733aa58ca0"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-tbgrq",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:43.418Z",
            "success-count": 1
          },
          "uuid": "c0d2e490-cc3f-4f85-ba86-5721837872a5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1043",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:46.118Z",
            "success-count": 1
          },
          "uuid": "0df4f154-dcf3-41d4-9ae9-6b42bb7f58e2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1043)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:13.483Z",
            "success-count": 77
          },
          "uuid": "8a420339-73db-4cf8-9c6a-1b11e1b704d4"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "2aded7a017c1e95d50d4879e7799d0e437229428188f857359ca785876442ae3:eth0",
        "container-id": "2aded7a017c1e95d50d4879e7799d0e437229428188f857359ca785876442ae3",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-tbgrq",
        "pod-name": "kube-system/coredns-cc6ccd49c-tbgrq"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5181692,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh79",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh79",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:45Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.78.0.239",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "a6:79:40:50:87:37",
        "interface-index": 14,
        "interface-name": "lxc1cd1fb6ccaf5",
        "mac": "c6:cb:2e:e0:b0:2a"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5181692,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5181692,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1043

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1043

```
Timestamp              Status   State                   Message
2024-10-25T10:21:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:45Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:16:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:46Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:16:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:16:43Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:16:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:16:43Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:16:43Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 5181692

```
ID        LABELS
5181692   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh79
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1845

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69372   793       0        
Allow    Egress      0          ANY          NONE         disabled    12278   125       0        

```


#### BPF CT List 1845

```
Invalid argument: unknown type 1845
```


#### Endpoint Get 1845

```
[
  {
    "id": 1845,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1845-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "630ffb70-2826-44a4-b6f8-62f196ed1307"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1845",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:43.319Z",
            "success-count": 3
          },
          "uuid": "5a7f2ab3-89a2-4c19-ac46-3cf8b54af473"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-64276",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:43.318Z",
            "success-count": 1
          },
          "uuid": "e205542f-da1b-4162-85a1-4ee20eff9f1a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1845",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:46.050Z",
            "success-count": 1
          },
          "uuid": "51e6b4ee-f06a-4dbe-92c9-5b1c81ec9424"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1845)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:13.393Z",
            "success-count": 77
          },
          "uuid": "98e38da5-4063-4b94-9119-fa053d5b7a41"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "83e8e6a1df4afb84f3615f9fc8cc4652bf6fe78797e3b0b168c304cb8fcd2c68:eth0",
        "container-id": "83e8e6a1df4afb84f3615f9fc8cc4652bf6fe78797e3b0b168c304cb8fcd2c68",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-64276",
        "pod-name": "kube-system/coredns-cc6ccd49c-64276"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5181692,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh79",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh79",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:45Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.78.0.227",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "3e:46:25:0a:12:64",
        "interface-index": 12,
        "interface-name": "lxcdddb2ca89e5f",
        "mac": "b6:b7:36:c9:b9:9d"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5181692,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5181692,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1845

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1845

```
Timestamp              Status    State                   Message
2024-10-25T10:21:45Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:45Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:45Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:21:45Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:44Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:44Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:44Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:44Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:43Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:02Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:46Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:16:46Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:44Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:16:44Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:16:43Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:16:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:16:43Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:16:43Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:43Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 5181692

```
ID        LABELS
5181692   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh79
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 3603

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 3603

```
Invalid argument: unknown type 3603
```


#### Endpoint Get 3603

```
[
  {
    "id": 3603,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3603-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d0e10c77-7b63-4a5f-a391-751e142d2bb7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3603",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:41.746Z",
            "success-count": 3
          },
          "uuid": "4e3eb213-5e87-49d3-b424-3467005b1677"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3603",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:42.856Z",
            "success-count": 1
          },
          "uuid": "c81a4992-6fb4-41e3-8a3f-10b85b96172b"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:21:45Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "8a:de:b5:95:ed:37",
        "interface-name": "cilium_host",
        "mac": "8a:de:b5:95:ed:37"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3603

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3603

```
Timestamp              Status   State                   Message
2024-10-25T10:21:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:21:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:45Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:21:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:21:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:21:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:21:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:16:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:46Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:16:44Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:16:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:16:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:16:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:41Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:16:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:16:41Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:16:41Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### Policy get

```
:
 []
Revision: 1

```


#### Cilium encryption



#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Service list

```
ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.198.154:443 (active)   
                                         2 => 172.31.132.212:443 (active)   
2    10.100.43.103:443    ClusterIP      1 => 172.31.133.70:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.78.0.227:53 (active)       
                                         2 => 10.78.0.239:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.78.0.227:9153 (active)     
                                         2 => 10.78.0.239:9153 (active)     
5    10.100.16.158:2379   ClusterIP      1 => 10.78.0.154:2379 (active)     
```

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 33637312                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 33637312                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 33637312                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d000000 rw-p 00000000 00:00 0 
400d000000-4010000000 ---p 00000000 00:00 0 
ffff68a42000-ffff68c07000 rw-p 00000000 00:00 0 
ffff68c0e000-ffff68d70000 rw-p 00000000 00:00 0 
ffff68d70000-ffff68db1000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff68db1000-ffff68df2000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff68df2000-ffff68df4000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff68df4000-ffff68df6000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff68df6000-ffff693bd000 rw-p 00000000 00:00 0 
ffff693bd000-ffff694bd000 rw-p 00000000 00:00 0 
ffff694bd000-ffff694ce000 rw-p 00000000 00:00 0 
ffff694ce000-ffff6b4ce000 rw-p 00000000 00:00 0 
ffff6b4ce000-ffff6b54e000 ---p 00000000 00:00 0 
ffff6b54e000-ffff6b54f000 rw-p 00000000 00:00 0 
ffff6b54f000-ffff8b54e000 ---p 00000000 00:00 0 
ffff8b54e000-ffff8b54f000 rw-p 00000000 00:00 0 
ffff8b54f000-ffffab4de000 ---p 00000000 00:00 0 
ffffab4de000-ffffab4df000 rw-p 00000000 00:00 0 
ffffab4df000-ffffaf4d0000 ---p 00000000 00:00 0 
ffffaf4d0000-ffffaf4d1000 rw-p 00000000 00:00 0 
ffffaf4d1000-ffffafcce000 ---p 00000000 00:00 0 
ffffafcce000-ffffafccf000 rw-p 00000000 00:00 0 
ffffafccf000-ffffafdce000 ---p 00000000 00:00 0 
ffffafdce000-ffffafe2e000 rw-p 00000000 00:00 0 
ffffafe2e000-ffffafe30000 r--p 00000000 00:00 0                          [vvar]
ffffafe30000-ffffafe31000 r-xp 00000000 00:00 0                          [vdso]
fffffb282000-fffffb2a3000 rw-p 00000000 00:00 0                          [stack]

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40022d7130)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001802c00,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001802c00,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4001cd5d90)(frontends:[10.100.16.158]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x40022d60b0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x40022d6160)(frontends:[10.100.43.103]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x40022d62c0)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4001cd5ce0)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x40017ffef8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-m87dz": (*k8s.Endpoints)(0x40013c7380)(172.31.133.70:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x40017fff00)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-qlpln": (*k8s.Endpoints)(0x40039dcdd0)(10.78.0.227:53/TCP[eu-west-3a],10.78.0.227:53/UDP[eu-west-3a],10.78.0.227:9153/TCP[eu-west-3a],10.78.0.239:53/TCP[eu-west-3a],10.78.0.239:53/UDP[eu-west-3a],10.78.0.239:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40019e44e0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-nt7cg": (*k8s.Endpoints)(0x40039dc750)(10.78.0.154:2379/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x40017ffef0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40023c5a00)(172.31.132.212:443/TCP,172.31.198.154:443/TCP)
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4000272cb0)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40028f70e0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400b2b02a0
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4002901020,
  gcExited: (chan struct {}) 0x4002901080,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x400232db80)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001b6d960)({
      MetricVec: (*prometheus.MetricVec)(0x4000de03c0)({
       metricMap: (*prometheus.metricMap)(0x4000de0450)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400067f4a0)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x400232dc00)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001b6d968)({
      MetricVec: (*prometheus.MetricVec)(0x4000de04b0)({
       metricMap: (*prometheus.metricMap)(0x4000de04e0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400067f500)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x400232dc80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001b6d970)({
      MetricVec: (*prometheus.MetricVec)(0x4000de05a0)({
       metricMap: (*prometheus.metricMap)(0x4000de0600)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400067f560)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x400232dd00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001b6d978)({
      MetricVec: (*prometheus.MetricVec)(0x4000de0690)({
       metricMap: (*prometheus.metricMap)(0x4000de06c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400067f5c0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x400232dd80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001b6d980)({
      MetricVec: (*prometheus.MetricVec)(0x4000de0780)({
       metricMap: (*prometheus.metricMap)(0x4000de07b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400067f620)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x400232de00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001b6d988)({
      MetricVec: (*prometheus.MetricVec)(0x4000de0840)({
       metricMap: (*prometheus.metricMap)(0x4000de0870)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400067f680)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x400232de80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001b6d990)({
      MetricVec: (*prometheus.MetricVec)(0x4000de0900)({
       metricMap: (*prometheus.metricMap)(0x4000de0930)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400067f6e0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x400232df00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001b6d998)({
      MetricVec: (*prometheus.MetricVec)(0x4000de09c0)({
       metricMap: (*prometheus.metricMap)(0x4000de09f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400067f740)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4000e64000)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001b6d9a0)({
      MetricVec: (*prometheus.MetricVec)(0x4000de0a50)({
       metricMap: (*prometheus.metricMap)(0x4000de0a80)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400067f7a0)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4000272cb0)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40002664d0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x40015463f0)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 402ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.78.0.60": (string) (len=6) "health",
  (string) (len=11) "10.78.0.227": (string) (len=35) "kube-system/coredns-cc6ccd49c-64276",
  (string) (len=11) "10.78.0.239": (string) (len=35) "kube-system/coredns-cc6ccd49c-tbgrq",
  (string) (len=11) "10.78.0.154": (string) (len=50) "kube-system/clustermesh-apiserver-556f68d94b-rgvfh",
  (string) (len=11) "10.78.0.235": (string) (len=6) "router"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.133.70": (string) (len=7) "node-ip"
}

```

