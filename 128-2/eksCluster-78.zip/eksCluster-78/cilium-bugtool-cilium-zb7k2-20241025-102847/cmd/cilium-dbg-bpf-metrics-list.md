REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10281     803948     677    bpf_overlay.c
Interface                 INGRESS     226616    85715803   1132   bpf_host.c
Success                   EGRESS      10497     819757     53     encap.h
Success                   EGRESS      5372      411899     1694   bpf_host.c
Success                   EGRESS      98935     12887878   1308   bpf_lxc.c
Success                   INGRESS     110149    13589843   86     l3.h
Success                   INGRESS     115707    14025798   235    trace.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
