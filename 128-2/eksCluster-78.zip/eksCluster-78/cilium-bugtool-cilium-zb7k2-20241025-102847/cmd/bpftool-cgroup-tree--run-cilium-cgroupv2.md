CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9d23418f_10b0_4b0a_b3fb_3d785f8e4788.slice/cri-containerd-eac58686e50e75821c7d5e106bc8ad936ab05204228ce3bbdf315cfa5262608a.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9d23418f_10b0_4b0a_b3fb_3d785f8e4788.slice/cri-containerd-2aded7a017c1e95d50d4879e7799d0e437229428188f857359ca785876442ae3.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6678253a_0dda_42fe_bbc3_450ff70ed4fb.slice/cri-containerd-d9953093d31ff7f506a1d6d05098636a909ef18b1a2ebff52cdc580746b6c627.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6678253a_0dda_42fe_bbc3_450ff70ed4fb.slice/cri-containerd-1f5a058b5c2680e59c56aa0e255549f3d3336884be42d0ee6a9cbfaa89a780c4.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0b52001b_e266_49da_b3d3_b1aa87556417.slice/cri-containerd-4a44545f5027f6dc34a00af376e70c4309e00bb4f46be463324f871932cdf44c.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0b52001b_e266_49da_b3d3_b1aa87556417.slice/cri-containerd-699ef9d14de3d0f568d8745a140c51cdf2a89abfc20c7daf7299475454fb780d.scope
    51       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod76b40ad7_c0ab_40aa_b653_0966a7623b26.slice/cri-containerd-25e48b5baa134227cef74d621b4b8b917db86a6e5b3d473cce5f0ad2e988eedd.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod76b40ad7_c0ab_40aa_b653_0966a7623b26.slice/cri-containerd-83e8e6a1df4afb84f3615f9fc8cc4652bf6fe78797e3b0b168c304cb8fcd2c68.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62fcae1e_f7ef_441d_b731_a2ea30b43566.slice/cri-containerd-21c1d2723ee063940705097ef0450cc2d7c814eec8fd3d68e9ca2ca9583ab038.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62fcae1e_f7ef_441d_b731_a2ea30b43566.slice/cri-containerd-0ed1008059285a0d3c30064cb0cca4324344a029dc93aad9ccea32256ffca652.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62fcae1e_f7ef_441d_b731_a2ea30b43566.slice/cri-containerd-c5caadd606278430c6c114e0ff8a823676a5b548c18d5c0c1b6f934a379e50ea.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62fcae1e_f7ef_441d_b731_a2ea30b43566.slice/cri-containerd-887da16e966bdfe2c98538787fb6b2da2306ec7fec06fc4a9343242a938d0e3a.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb28a5a3e_486f_4396_85a2_4688caf326d4.slice/cri-containerd-1afdcde8e320268dfdc3ebc22c45087781566a9e80250892c105f30158f8adf9.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb28a5a3e_486f_4396_85a2_4688caf326d4.slice/cri-containerd-062363a7ffd6b521ac4ff83eacc456dee1bf642ef71980ce02c945c3a5f2d9af.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod590e0498_2e08_4bbd_a3d0_d5b64b6c0ba6.slice/cri-containerd-eea35e69e09b7b7328897a427b18e829c641f0e779811cf0022bb54b52b82810.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod590e0498_2e08_4bbd_a3d0_d5b64b6c0ba6.slice/cri-containerd-f20c72501ebb06cc0bece2ded630878088ac5611ec80296a68f8d6c705b11fa5.scope
    87       cgroup_device   multi                                          
