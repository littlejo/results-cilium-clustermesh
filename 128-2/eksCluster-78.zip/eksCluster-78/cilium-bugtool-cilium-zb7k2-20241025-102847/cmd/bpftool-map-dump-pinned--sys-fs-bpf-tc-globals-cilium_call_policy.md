key: 9c 00 00 00  value: 85 02 00 00
key: 0d 02 00 00  value: 3c 02 00 00
key: 13 04 00 00  value: 28 02 00 00
key: 35 07 00 00  value: 11 02 00 00
Found 4 elements
