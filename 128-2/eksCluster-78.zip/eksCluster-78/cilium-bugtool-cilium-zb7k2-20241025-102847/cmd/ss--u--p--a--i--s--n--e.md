Total: 550
TCP:   1068 (estab 301, closed 748, orphaned 0, timewait 297)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  320       308       12       
INET	  330       314       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                   172.31.133.70%ens5:68         0.0.0.0:*    uid:192 ino:16473 sk:260 cgroup:unreachable:c4e <->                            
UNCONN 0      0                            127.0.0.1:41179      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:25051 sk:261 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:25107 sk:262 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15467 sk:263 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:25106 sk:264 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15468 sk:265 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::4c2:60ff:fee6:2c15]%ens5:546           [::]:*    uid:192 ino:16464 sk:266 cgroup:unreachable:c4e v6only:1 <->                   
