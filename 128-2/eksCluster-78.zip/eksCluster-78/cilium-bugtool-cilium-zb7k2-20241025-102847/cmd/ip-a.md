1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:c2:60:e6:2c:15 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.133.70/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2782sec preferred_lft 2782sec
    inet6 fe80::4c2:60ff:fee6:2c15/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:5a:16:60:d0:1d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.178.90/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::45a:16ff:fe60:d01d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:2b:ff:ce:13:00 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d82b:ffff:fece:1300/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:de:b5:95:ed:37 brd ff:ff:ff:ff:ff:ff
    inet 10.78.0.235/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::88de:b5ff:fe95:ed37/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 9a:ba:c2:e7:d0:8e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::98ba:c2ff:fee7:d08e/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:03:67:f2:c6:d0 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a803:67ff:fef2:c6d0/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcdddb2ca89e5f@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:46:25:0a:12:64 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::3c46:25ff:fe0a:1264/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc1cd1fb6ccaf5@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:79:40:50:87:37 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::a479:40ff:fe50:8737/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc519068d175ce@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:cd:4c:cc:36:34 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c0cd:4cff:fecc:3634/64 scope link 
       valid_lft forever preferred_lft forever
