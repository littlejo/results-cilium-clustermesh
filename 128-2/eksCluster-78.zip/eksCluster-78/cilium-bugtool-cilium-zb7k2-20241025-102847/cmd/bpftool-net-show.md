xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 551
ens6(5) clsact/ingress cil_from_netdev-ens6 id 563
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 545
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 539
cilium_host(7) clsact/egress cil_from_host-cilium_host id 534
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 581
lxcdddb2ca89e5f(12) clsact/ingress cil_from_container-lxcdddb2ca89e5f id 520
lxc1cd1fb6ccaf5(14) clsact/ingress cil_from_container-lxc1cd1fb6ccaf5 id 532
lxc519068d175ce(18) clsact/ingress cil_from_container-lxc519068d175ce id 642

flow_dissector:

netfilter:

