alloc: 117.29MB (122986776 bytes)
total-alloc: 1.37GB (1470159832 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 48466820
frees: 47266188
heap-alloc: 117.29MB (122986776 bytes)
heap-sys: 165.54MB (173580288 bytes)
heap-idle: 28.73MB (30130176 bytes)
heap-in-use: 136.80MB (143450112 bytes)
heap-released: 960.00KB (983040 bytes)
heap-objects: 1200632
stack-in-use: 34.44MB (36110336 bytes)
stack-sys: 34.44MB (36110336 bytes)
stack-mspan-inuse: 2.17MB (2280320 bytes)
stack-mspan-sys: 2.44MB (2562240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 910.49KB (932345 bytes)
gc-sys: 5.16MB (5409096 bytes)
next-gc: when heap-alloc >= 158.41MB (166108936 bytes)
last-gc: 2024-10-25 10:28:49.569236952 +0000 UTC
gc-pause-total: 13.220999ms
gc-pause: 3124142
gc-pause-end: 1729852129569236952
num-gc: 71
num-forced-gc: 0
gc-cpu-fraction: 0.0004918918632337796
enable-gc: true
debug-gc: false
