markdown output at /tmp/cilium-bugtool-20241025-102849.25+0000-UTC-2875403968/cmd/cilium-debuginfo-20241025-102920.038+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102849.25+0000-UTC-2875403968/cmd/cilium-debuginfo-20241025-102920.038+0000-UTC.json
