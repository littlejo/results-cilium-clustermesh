{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:41.584Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.133.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:41.584Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.178.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:41.584Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.037Z",
  "value": "id=525   sec_id=4     flags=0x0000 ifindex=10  mac=5A:42:F3:F2:4E:7A nodemac=AA:03:67:F2:C6:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.046Z",
  "value": "id=1845  sec_id=5181692 flags=0x0000 ifindex=12  mac=B6:B7:36:C9:B9:9D nodemac=3E:46:25:0A:12:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.118Z",
  "value": "id=1043  sec_id=5181692 flags=0x0000 ifindex=14  mac=C6:CB:2E:E0:B0:2A nodemac=A6:79:40:50:87:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.155Z",
  "value": "id=525   sec_id=4     flags=0x0000 ifindex=10  mac=5A:42:F3:F2:4E:7A nodemac=AA:03:67:F2:C6:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:01.442Z",
  "value": "id=525   sec_id=4     flags=0x0000 ifindex=10  mac=5A:42:F3:F2:4E:7A nodemac=AA:03:67:F2:C6:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:01.443Z",
  "value": "id=1845  sec_id=5181692 flags=0x0000 ifindex=12  mac=B6:B7:36:C9:B9:9D nodemac=3E:46:25:0A:12:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:01.444Z",
  "value": "id=1043  sec_id=5181692 flags=0x0000 ifindex=14  mac=C6:CB:2E:E0:B0:2A nodemac=A6:79:40:50:87:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:01.472Z",
  "value": "id=2778  sec_id=5234507 flags=0x0000 ifindex=16  mac=76:2B:5B:7D:2E:C8 nodemac=5A:70:7C:6B:99:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.442Z",
  "value": "id=1845  sec_id=5181692 flags=0x0000 ifindex=12  mac=B6:B7:36:C9:B9:9D nodemac=3E:46:25:0A:12:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.442Z",
  "value": "id=1043  sec_id=5181692 flags=0x0000 ifindex=14  mac=C6:CB:2E:E0:B0:2A nodemac=A6:79:40:50:87:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.442Z",
  "value": "id=525   sec_id=4     flags=0x0000 ifindex=10  mac=5A:42:F3:F2:4E:7A nodemac=AA:03:67:F2:C6:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.443Z",
  "value": "id=2778  sec_id=5234507 flags=0x0000 ifindex=16  mac=76:2B:5B:7D:2E:C8 nodemac=5A:70:7C:6B:99:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:12.178Z",
  "value": "id=156   sec_id=5234507 flags=0x0000 ifindex=18  mac=BE:93:40:ED:94:FB nodemac=C2:CD:4C:CC:36:34"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.78.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:17.688Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:43.883Z",
  "value": "id=1845  sec_id=5181692 flags=0x0000 ifindex=12  mac=B6:B7:36:C9:B9:9D nodemac=3E:46:25:0A:12:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:43.884Z",
  "value": "id=1043  sec_id=5181692 flags=0x0000 ifindex=14  mac=C6:CB:2E:E0:B0:2A nodemac=A6:79:40:50:87:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:43.884Z",
  "value": "id=156   sec_id=5234507 flags=0x0000 ifindex=18  mac=BE:93:40:ED:94:FB nodemac=C2:CD:4C:CC:36:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:43.885Z",
  "value": "id=525   sec_id=4     flags=0x0000 ifindex=10  mac=5A:42:F3:F2:4E:7A nodemac=AA:03:67:F2:C6:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:44.884Z",
  "value": "id=156   sec_id=5234507 flags=0x0000 ifindex=18  mac=BE:93:40:ED:94:FB nodemac=C2:CD:4C:CC:36:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:44.884Z",
  "value": "id=525   sec_id=4     flags=0x0000 ifindex=10  mac=5A:42:F3:F2:4E:7A nodemac=AA:03:67:F2:C6:D0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:44.884Z",
  "value": "id=1845  sec_id=5181692 flags=0x0000 ifindex=12  mac=B6:B7:36:C9:B9:9D nodemac=3E:46:25:0A:12:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:44.884Z",
  "value": "id=1043  sec_id=5181692 flags=0x0000 ifindex=14  mac=C6:CB:2E:E0:B0:2A nodemac=A6:79:40:50:87:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:45.884Z",
  "value": "id=1845  sec_id=5181692 flags=0x0000 ifindex=12  mac=B6:B7:36:C9:B9:9D nodemac=3E:46:25:0A:12:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:45.885Z",
  "value": "id=1043  sec_id=5181692 flags=0x0000 ifindex=14  mac=C6:CB:2E:E0:B0:2A nodemac=A6:79:40:50:87:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:45.885Z",
  "value": "id=156   sec_id=5234507 flags=0x0000 ifindex=18  mac=BE:93:40:ED:94:FB nodemac=C2:CD:4C:CC:36:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.78.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:45.885Z",
  "value": "id=525   sec_id=4     flags=0x0000 ifindex=10  mac=5A:42:F3:F2:4E:7A nodemac=AA:03:67:F2:C6:D0"
}

