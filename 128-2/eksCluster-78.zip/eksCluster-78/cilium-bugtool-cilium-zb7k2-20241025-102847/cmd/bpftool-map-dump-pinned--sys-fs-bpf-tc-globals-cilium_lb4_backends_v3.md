key: 09 00 00 00  value: 0a 4e 00 ef 23 c1 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 4e 00 ef 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 4e 00 e3 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f 84 d4 01 bb 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f c6 9a 01 bb 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 4e 00 9a 09 4b 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 4e 00 e3 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f 85 46 10 94 00 00  00 00 00 00
Found 8 elements
