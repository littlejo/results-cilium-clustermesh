IP ADDRESS         LOCAL ENDPOINT INFO
172.31.197.74:0    (localhost)                                                                                        
10.69.0.73:0       id=176   sec_id=4632448 flags=0x0000 ifindex=14  mac=4E:12:EB:D8:32:22 nodemac=92:10:53:C0:AA:CB   
10.69.0.94:0       id=1678  sec_id=4632448 flags=0x0000 ifindex=12  mac=86:D2:DC:6A:70:DA nodemac=FE:35:2A:83:44:69   
10.69.0.61:0       (localhost)                                                                                        
10.69.0.170:0      id=180   sec_id=4     flags=0x0000 ifindex=10  mac=EA:4D:A9:16:6F:09 nodemac=3E:DD:5D:09:3E:45     
172.31.228.221:0   (localhost)                                                                                        
10.69.0.132:0      id=3981  sec_id=4594071 flags=0x0000 ifindex=18  mac=02:0A:A0:D2:DB:A3 nodemac=62:71:F8:E3:DB:19   
