ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.179.97:443 (active)    
                                         2 => 172.31.202.75:443 (active)    
2    10.100.167.3:443     ClusterIP      1 => 172.31.197.74:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.69.0.94:53 (active)        
                                         2 => 10.69.0.73:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.69.0.94:9153 (active)      
                                         2 => 10.69.0.73:9153 (active)      
5    10.100.242.52:2379   ClusterIP      1 => 10.69.0.132:2379 (active)     
