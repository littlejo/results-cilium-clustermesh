{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:17.837Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.197.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:17.837Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.228.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:17.837Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:22.703Z",
  "value": "id=1678  sec_id=4632448 flags=0x0000 ifindex=12  mac=86:D2:DC:6A:70:DA nodemac=FE:35:2A:83:44:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:22.717Z",
  "value": "id=180   sec_id=4     flags=0x0000 ifindex=10  mac=EA:4D:A9:16:6F:09 nodemac=3E:DD:5D:09:3E:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:22.750Z",
  "value": "id=176   sec_id=4632448 flags=0x0000 ifindex=14  mac=4E:12:EB:D8:32:22 nodemac=92:10:53:C0:AA:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:22.771Z",
  "value": "id=180   sec_id=4     flags=0x0000 ifindex=10  mac=EA:4D:A9:16:6F:09 nodemac=3E:DD:5D:09:3E:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.742Z",
  "value": "id=1678  sec_id=4632448 flags=0x0000 ifindex=12  mac=86:D2:DC:6A:70:DA nodemac=FE:35:2A:83:44:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.743Z",
  "value": "id=176   sec_id=4632448 flags=0x0000 ifindex=14  mac=4E:12:EB:D8:32:22 nodemac=92:10:53:C0:AA:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.743Z",
  "value": "id=180   sec_id=4     flags=0x0000 ifindex=10  mac=EA:4D:A9:16:6F:09 nodemac=3E:DD:5D:09:3E:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:46.773Z",
  "value": "id=534   sec_id=4594071 flags=0x0000 ifindex=16  mac=4E:69:7F:F9:64:2C nodemac=66:DE:E5:A4:B3:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:47.742Z",
  "value": "id=180   sec_id=4     flags=0x0000 ifindex=10  mac=EA:4D:A9:16:6F:09 nodemac=3E:DD:5D:09:3E:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:47.743Z",
  "value": "id=1678  sec_id=4632448 flags=0x0000 ifindex=12  mac=86:D2:DC:6A:70:DA nodemac=FE:35:2A:83:44:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:47.743Z",
  "value": "id=176   sec_id=4632448 flags=0x0000 ifindex=14  mac=4E:12:EB:D8:32:22 nodemac=92:10:53:C0:AA:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:47.743Z",
  "value": "id=534   sec_id=4594071 flags=0x0000 ifindex=16  mac=4E:69:7F:F9:64:2C nodemac=66:DE:E5:A4:B3:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:00.741Z",
  "value": "id=3981  sec_id=4594071 flags=0x0000 ifindex=18  mac=02:0A:A0:D2:DB:A3 nodemac=62:71:F8:E3:DB:19"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.69.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.369Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:23.609Z",
  "value": "id=3981  sec_id=4594071 flags=0x0000 ifindex=18  mac=02:0A:A0:D2:DB:A3 nodemac=62:71:F8:E3:DB:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:23.610Z",
  "value": "id=180   sec_id=4     flags=0x0000 ifindex=10  mac=EA:4D:A9:16:6F:09 nodemac=3E:DD:5D:09:3E:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:23.611Z",
  "value": "id=1678  sec_id=4632448 flags=0x0000 ifindex=12  mac=86:D2:DC:6A:70:DA nodemac=FE:35:2A:83:44:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:23.611Z",
  "value": "id=176   sec_id=4632448 flags=0x0000 ifindex=14  mac=4E:12:EB:D8:32:22 nodemac=92:10:53:C0:AA:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.610Z",
  "value": "id=176   sec_id=4632448 flags=0x0000 ifindex=14  mac=4E:12:EB:D8:32:22 nodemac=92:10:53:C0:AA:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.610Z",
  "value": "id=180   sec_id=4     flags=0x0000 ifindex=10  mac=EA:4D:A9:16:6F:09 nodemac=3E:DD:5D:09:3E:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.611Z",
  "value": "id=1678  sec_id=4632448 flags=0x0000 ifindex=12  mac=86:D2:DC:6A:70:DA nodemac=FE:35:2A:83:44:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.611Z",
  "value": "id=3981  sec_id=4594071 flags=0x0000 ifindex=18  mac=02:0A:A0:D2:DB:A3 nodemac=62:71:F8:E3:DB:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:25.610Z",
  "value": "id=3981  sec_id=4594071 flags=0x0000 ifindex=18  mac=02:0A:A0:D2:DB:A3 nodemac=62:71:F8:E3:DB:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:25.610Z",
  "value": "id=180   sec_id=4     flags=0x0000 ifindex=10  mac=EA:4D:A9:16:6F:09 nodemac=3E:DD:5D:09:3E:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:25.611Z",
  "value": "id=1678  sec_id=4632448 flags=0x0000 ifindex=12  mac=86:D2:DC:6A:70:DA nodemac=FE:35:2A:83:44:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.69.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:25.611Z",
  "value": "id=176   sec_id=4632448 flags=0x0000 ifindex=14  mac=4E:12:EB:D8:32:22 nodemac=92:10:53:C0:AA:CB"
}

