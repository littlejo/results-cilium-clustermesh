key: b0 00 00 00  value: 1b 02 00 00
key: b4 00 00 00  value: 2a 02 00 00
key: 8e 06 00 00  value: 12 02 00 00
key: 8d 0f 00 00  value: 6e 02 00 00
Found 4 elements
