markdown output at /tmp/cilium-bugtool-20241025-102848.272+0000-UTC-1686888130/cmd/cilium-debuginfo-20241025-102918.827+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102848.272+0000-UTC-1686888130/cmd/cilium-debuginfo-20241025-102918.827+0000-UTC.json
