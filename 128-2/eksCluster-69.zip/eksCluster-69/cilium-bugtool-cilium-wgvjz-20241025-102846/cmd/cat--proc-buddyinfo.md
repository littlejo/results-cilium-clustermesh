Node 0, zone      DMA      3     32      9      2      3     66     43     24      7      5    158 
Node 0, zone   Normal     84      2      2      1      4      1      1      0      1      2      9 
