[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1c5d2d5e_cc6d_497d_92a9_65f2c4a893a0.slice/cri-containerd-87ceed5f9b6e7db2a5aacecc8eb46e81404aae69475daf435e04df3223b95044.scope"
      }
    ],
    "ips": [
      "10.69.0.94"
    ],
    "name": "coredns-cc6ccd49c-kmwsv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod425e06e4_9d6c_489e_96fc_b567c82876d2.slice/cri-containerd-cb6ca2b275fcdcb11adf04f94d87722d7ce617901c2048cc0552d248b2fe5a72.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod425e06e4_9d6c_489e_96fc_b567c82876d2.slice/cri-containerd-b8e24f551fa313d6307a7f0fa3c8a6ed0ceff3674598755e256b5ab664d75309.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod425e06e4_9d6c_489e_96fc_b567c82876d2.slice/cri-containerd-d241d3331777b3ba7b562d30fbff44fccafa834bbc81cbb020d20f268555d7ac.scope"
      }
    ],
    "ips": [
      "10.69.0.132"
    ],
    "name": "clustermesh-apiserver-8c746c559-nc64s",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2ac15b31_1211_4c78_a433_d75fb0eda789.slice/cri-containerd-11417ce4cc96fed21a90a880effb8807ed1c7316128337ad24b4dce39c655209.scope"
      }
    ],
    "ips": [
      "10.69.0.73"
    ],
    "name": "coredns-cc6ccd49c-xwpg2",
    "namespace": "kube-system"
  }
]

