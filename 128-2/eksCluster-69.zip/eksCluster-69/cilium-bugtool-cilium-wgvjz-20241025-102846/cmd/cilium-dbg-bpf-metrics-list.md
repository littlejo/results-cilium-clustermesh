REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     220735    85394313   1132   bpf_host.c
Interface                 INGRESS     9730      758215     677    bpf_overlay.c
Success                   EGRESS      4713      358715     1694   bpf_host.c
Success                   EGRESS      93637     12489233   1308   bpf_lxc.c
Success                   EGRESS      9652      751090     53     encap.h
Success                   INGRESS     105425    12900962   86     l3.h
Success                   INGRESS     111091    13344368   235    trace.h
Unsupported L3 protocol   EGRESS      36        2676       1492   bpf_lxc.c
