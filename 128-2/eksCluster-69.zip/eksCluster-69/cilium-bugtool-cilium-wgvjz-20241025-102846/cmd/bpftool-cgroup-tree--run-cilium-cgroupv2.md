CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1c5d2d5e_cc6d_497d_92a9_65f2c4a893a0.slice/cri-containerd-87ceed5f9b6e7db2a5aacecc8eb46e81404aae69475daf435e04df3223b95044.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1c5d2d5e_cc6d_497d_92a9_65f2c4a893a0.slice/cri-containerd-7446b16256b37863347fc4c1fe65e0aacfa644701841c4433ce646b1b794a180.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb660987f_e3ae_4ead_b5df_5fbd618d0cb8.slice/cri-containerd-11bcb092f7734f033f469e975ea63d7d9de05684b35ce10d199f2f7a88b586dc.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb660987f_e3ae_4ead_b5df_5fbd618d0cb8.slice/cri-containerd-72d8ec84e700f254d39d2af32803d7d211cb81967833edbd191c6cb7f5e1f2d7.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2ac15b31_1211_4c78_a433_d75fb0eda789.slice/cri-containerd-37741e17e6b92d45331f14542931ea3b6287feee4405033a47aed76ce6e9faae.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2ac15b31_1211_4c78_a433_d75fb0eda789.slice/cri-containerd-11417ce4cc96fed21a90a880effb8807ed1c7316128337ad24b4dce39c655209.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode79cfad7_0dbf_44dc_8ec5_b33b392317b4.slice/cri-containerd-b7e06fb790d22148cc05abf3e3c07352f5199a21d8736a51d15b8e46f485d516.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode79cfad7_0dbf_44dc_8ec5_b33b392317b4.slice/cri-containerd-37446658a8dc6cace32818d971ecec8a6395d9a0b1b73d7d326fb80687d9456b.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c9bf25d_5f64_4d6d_8efc_bce171889cbc.slice/cri-containerd-03b735db9d10fe39aee152580b7fb97422d9779fd4e8397e38054eea4a6c6266.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c9bf25d_5f64_4d6d_8efc_bce171889cbc.slice/cri-containerd-8b8eb17314dfaa0d16a4b273a117038687a0ba65bed376e0a2615add2c7c9778.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod425e06e4_9d6c_489e_96fc_b567c82876d2.slice/cri-containerd-d241d3331777b3ba7b562d30fbff44fccafa834bbc81cbb020d20f268555d7ac.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod425e06e4_9d6c_489e_96fc_b567c82876d2.slice/cri-containerd-8c42564b2ce7f00f4e2a05e0d5036e8206d3dacbeef38df4e0aafc6e78fe1a60.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod425e06e4_9d6c_489e_96fc_b567c82876d2.slice/cri-containerd-cb6ca2b275fcdcb11adf04f94d87722d7ce617901c2048cc0552d248b2fe5a72.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod425e06e4_9d6c_489e_96fc_b567c82876d2.slice/cri-containerd-b8e24f551fa313d6307a7f0fa3c8a6ed0ceff3674598755e256b5ab664d75309.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1dd4431c_907c_4711_abee_c73179d006fe.slice/cri-containerd-0067b5952ee07997f422b7dac49091ee8ce93646872fc9bd58adcd338047ecd5.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1dd4431c_907c_4711_abee_c73179d006fe.slice/cri-containerd-7810196fa3d1f0f54c08c7001681d4d5da32ceaba50557c5d28844bbbab42d62.scope
    90       cgroup_device   multi                                          
