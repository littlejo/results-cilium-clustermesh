xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 501
ens6(5) clsact/ingress cil_from_netdev-ens6 id 506
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 492
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 491
cilium_host(7) clsact/egress cil_from_host-cilium_host id 488
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 542
lxcde67b42b16e2(12) clsact/ingress cil_from_container-lxcde67b42b16e2 id 518
lxc4cf4b0fca2b7(14) clsact/ingress cil_from_container-lxc4cf4b0fca2b7 id 535
lxc17cf53f05e20(18) clsact/ingress cil_from_container-lxc17cf53f05e20 id 614

flow_dissector:

netfilter:

