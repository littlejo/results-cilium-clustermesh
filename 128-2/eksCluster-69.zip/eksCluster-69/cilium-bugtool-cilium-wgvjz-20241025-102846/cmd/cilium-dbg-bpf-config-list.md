KEY             VALUE
AgentLiveness   882396038830
UTimeOffset     3378615773437500
