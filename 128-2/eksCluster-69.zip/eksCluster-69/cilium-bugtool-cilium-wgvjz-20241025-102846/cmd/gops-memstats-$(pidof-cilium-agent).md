alloc: 67.43MB (70703760 bytes)
total-alloc: 1.34GB (1443039744 bytes)
sys: 202.32MB (212146500 bytes)
lookups: 0
mallocs: 48017248
frees: 47538345
heap-alloc: 67.43MB (70703760 bytes)
heap-sys: 159.82MB (167583744 bytes)
heap-idle: 45.16MB (47349760 bytes)
heap-in-use: 114.66MB (120233984 bytes)
heap-released: 1.16MB (1212416 bytes)
heap-objects: 478903
stack-in-use: 32.16MB (33718272 bytes)
stack-sys: 32.16MB (33718272 bytes)
stack-mspan-inuse: 1.95MB (2047200 bytes)
stack-mspan-sys: 2.46MB (2578560 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 901.81KB (923457 bytes)
gc-sys: 5.09MB (5334280 bytes)
next-gc: when heap-alloc >= 146.26MB (153359992 bytes)
last-gc: 2024-10-25 10:29:18.167657348 +0000 UTC
gc-pause-total: 15.297385ms
gc-pause: 84121
gc-pause-end: 1729852158167657348
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00036342021623250053
enable-gc: true
debug-gc: false
