Endpoint ID: 176
Path: /sys/fs/bpf/tc/globals/cilium_policy_00176

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    73292   844       0        
Allow    Egress      0          ANY          NONE         disabled    12823   131       0        


Endpoint ID: 180
Path: /sys/fs/bpf/tc/globals/cilium_policy_00180

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    446248   5703      0        
Allow    Ingress     1          ANY          NONE         disabled    11052    128       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1678
Path: /sys/fs/bpf/tc/globals/cilium_policy_01678

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    72962   839       0        
Allow    Egress      0          ANY          NONE         disabled    12341   126       0        


Endpoint ID: 2530
Path: /sys/fs/bpf/tc/globals/cilium_policy_02530

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3981
Path: /sys/fs/bpf/tc/globals/cilium_policy_03981

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3900392   36807     0        
Allow    Ingress     1          ANY          NONE         disabled    3282549   33458     0        
Allow    Egress      0          ANY          NONE         disabled    4715932   43689     0        


