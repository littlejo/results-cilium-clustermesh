xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 538
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 529
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 527
cilium_host(4) clsact/egress cil_from_host-cilium_host id 524
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 456
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 457
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 508
lxc6334dbfa0e7b(9) clsact/ingress cil_from_container-lxc6334dbfa0e7b id 499
lxc28e84edee560(11) clsact/ingress cil_from_container-lxc28e84edee560 id 489
lxcad2b3f335998(15) clsact/ingress cil_from_container-lxcad2b3f335998 id 599

flow_dissector:

netfilter:

