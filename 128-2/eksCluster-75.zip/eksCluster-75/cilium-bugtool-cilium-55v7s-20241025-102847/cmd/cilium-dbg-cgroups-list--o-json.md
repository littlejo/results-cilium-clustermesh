[
  {
    "containers": [
      {
        "cgroup-id": 8790,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd260cefc_eeb7_4586_8a47_918aa7e309f7.slice/cri-containerd-ede122688cdf65119c8169f71a40de4ab6959487fcb6e6418d0046eafaa93f32.scope"
      },
      {
        "cgroup-id": 8706,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd260cefc_eeb7_4586_8a47_918aa7e309f7.slice/cri-containerd-c0be7e3424ba21ae9a22d835cdd442fdf1a533bc499aee4efa08205c3ebe2c78.scope"
      },
      {
        "cgroup-id": 8622,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd260cefc_eeb7_4586_8a47_918aa7e309f7.slice/cri-containerd-54967e7ce55ca430f92a1bfbce0c9fc8179bdf748d86aca8a3ffa35e1e8ba117.scope"
      }
    ],
    "ips": [
      "10.75.0.46"
    ],
    "name": "clustermesh-apiserver-7644bfb4b-5rhhr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7278,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3082a46_aedd_4a07_a8c1_785ac135225c.slice/cri-containerd-3fc83a428a2812729e6fb034d6e48b8cc39efdc52fd2a2514813de07e7b24ea7.scope"
      }
    ],
    "ips": [
      "10.75.0.226"
    ],
    "name": "coredns-cc6ccd49c-nb7vc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7194,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf94f3f41_2231_473f_8e3b_440e25bc901a.slice/cri-containerd-c1106c4686dffaeb8e782b1ad905970170f8b0468d7c0b446f4ede770f569f47.scope"
      }
    ],
    "ips": [
      "10.75.0.103"
    ],
    "name": "coredns-cc6ccd49c-5g7f5",
    "namespace": "kube-system"
  }
]

