1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:10:19:9e:b9:eb brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.198.153/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2697sec preferred_lft 2697sec
    inet6 fe80::810:19ff:fe9e:b9eb/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:7a:bc:f9:9c:b9 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::7c7a:bcff:fef9:9cb9/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:5a:45:c9:3b:e5 brd ff:ff:ff:ff:ff:ff
    inet 10.75.0.67/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::445a:45ff:fec9:3be5/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ce:bc:7c:f6:90:ca brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ccbc:7cff:fef6:90ca/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:19:6a:59:1f:a3 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::5019:6aff:fe59:1fa3/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc6334dbfa0e7b@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:06:84:dd:05:aa brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::406:84ff:fedd:5aa/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc28e84edee560@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:0c:e3:85:62:24 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ec0c:e3ff:fe85:6224/64 scope link 
       valid_lft forever preferred_lft forever
15: lxcad2b3f335998@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:a5:3e:89:2e:96 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::eca5:3eff:fe89:2e96/64 scope link 
       valid_lft forever preferred_lft forever
