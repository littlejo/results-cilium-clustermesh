REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     10228     800663      677    bpf_overlay.c
Interface                 INGRESS     224073    101172888   1132   bpf_host.c
Success                   EGRESS      10446     816521      53     encap.h
Success                   EGRESS      5256      404400      1694   bpf_host.c
Success                   EGRESS      95829     12621274    1308   bpf_lxc.c
Success                   INGRESS     106526    13094438    86     l3.h
Success                   INGRESS     112147    13534607    235    trace.h
Unsupported L3 protocol   EGRESS      36        2672        1492   bpf_lxc.c
