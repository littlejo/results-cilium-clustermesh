{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:27.435Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.198.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:27.435Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:32.092Z",
  "value": "id=97    sec_id=5005442 flags=0x0000 ifindex=9   mac=7E:4D:C6:BE:0B:D9 nodemac=06:06:84:DD:05:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:32.097Z",
  "value": "id=1722  sec_id=4     flags=0x0000 ifindex=7   mac=52:2C:4B:C7:C2:EE nodemac=52:19:6A:59:1F:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:32.184Z",
  "value": "id=2469  sec_id=5005442 flags=0x0000 ifindex=11  mac=32:86:F5:30:07:A6 nodemac=EE:0C:E3:85:62:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:32.251Z",
  "value": "id=97    sec_id=5005442 flags=0x0000 ifindex=9   mac=7E:4D:C6:BE:0B:D9 nodemac=06:06:84:DD:05:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:32.308Z",
  "value": "id=1722  sec_id=4     flags=0x0000 ifindex=7   mac=52:2C:4B:C7:C2:EE nodemac=52:19:6A:59:1F:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:15.638Z",
  "value": "id=1722  sec_id=4     flags=0x0000 ifindex=7   mac=52:2C:4B:C7:C2:EE nodemac=52:19:6A:59:1F:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:15.639Z",
  "value": "id=97    sec_id=5005442 flags=0x0000 ifindex=9   mac=7E:4D:C6:BE:0B:D9 nodemac=06:06:84:DD:05:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:15.639Z",
  "value": "id=2469  sec_id=5005442 flags=0x0000 ifindex=11  mac=32:86:F5:30:07:A6 nodemac=EE:0C:E3:85:62:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:15.671Z",
  "value": "id=1546  sec_id=5031388 flags=0x0000 ifindex=13  mac=06:EE:EE:7C:DD:9C nodemac=FE:DE:82:5C:A2:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:16.639Z",
  "value": "id=97    sec_id=5005442 flags=0x0000 ifindex=9   mac=7E:4D:C6:BE:0B:D9 nodemac=06:06:84:DD:05:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:16.639Z",
  "value": "id=2469  sec_id=5005442 flags=0x0000 ifindex=11  mac=32:86:F5:30:07:A6 nodemac=EE:0C:E3:85:62:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:16.640Z",
  "value": "id=1546  sec_id=5031388 flags=0x0000 ifindex=13  mac=06:EE:EE:7C:DD:9C nodemac=FE:DE:82:5C:A2:6E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:16.640Z",
  "value": "id=1722  sec_id=4     flags=0x0000 ifindex=7   mac=52:2C:4B:C7:C2:EE nodemac=52:19:6A:59:1F:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:45.094Z",
  "value": "id=1420  sec_id=5031388 flags=0x0000 ifindex=15  mac=26:DF:4A:29:C2:BE nodemac=EE:A5:3E:89:2E:96"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.75.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:50.725Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:28.674Z",
  "value": "id=1722  sec_id=4     flags=0x0000 ifindex=7   mac=52:2C:4B:C7:C2:EE nodemac=52:19:6A:59:1F:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:28.675Z",
  "value": "id=97    sec_id=5005442 flags=0x0000 ifindex=9   mac=7E:4D:C6:BE:0B:D9 nodemac=06:06:84:DD:05:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:28.675Z",
  "value": "id=2469  sec_id=5005442 flags=0x0000 ifindex=11  mac=32:86:F5:30:07:A6 nodemac=EE:0C:E3:85:62:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:28.675Z",
  "value": "id=1420  sec_id=5031388 flags=0x0000 ifindex=15  mac=26:DF:4A:29:C2:BE nodemac=EE:A5:3E:89:2E:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:29.674Z",
  "value": "id=2469  sec_id=5005442 flags=0x0000 ifindex=11  mac=32:86:F5:30:07:A6 nodemac=EE:0C:E3:85:62:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:29.675Z",
  "value": "id=97    sec_id=5005442 flags=0x0000 ifindex=9   mac=7E:4D:C6:BE:0B:D9 nodemac=06:06:84:DD:05:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:29.675Z",
  "value": "id=1722  sec_id=4     flags=0x0000 ifindex=7   mac=52:2C:4B:C7:C2:EE nodemac=52:19:6A:59:1F:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:29.675Z",
  "value": "id=1420  sec_id=5031388 flags=0x0000 ifindex=15  mac=26:DF:4A:29:C2:BE nodemac=EE:A5:3E:89:2E:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:30.675Z",
  "value": "id=1420  sec_id=5031388 flags=0x0000 ifindex=15  mac=26:DF:4A:29:C2:BE nodemac=EE:A5:3E:89:2E:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:30.675Z",
  "value": "id=1722  sec_id=4     flags=0x0000 ifindex=7   mac=52:2C:4B:C7:C2:EE nodemac=52:19:6A:59:1F:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:30.676Z",
  "value": "id=97    sec_id=5005442 flags=0x0000 ifindex=9   mac=7E:4D:C6:BE:0B:D9 nodemac=06:06:84:DD:05:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:30.676Z",
  "value": "id=2469  sec_id=5005442 flags=0x0000 ifindex=11  mac=32:86:F5:30:07:A6 nodemac=EE:0C:E3:85:62:24"
}

