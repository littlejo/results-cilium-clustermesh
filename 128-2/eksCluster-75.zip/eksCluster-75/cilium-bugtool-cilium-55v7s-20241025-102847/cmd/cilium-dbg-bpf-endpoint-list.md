IP ADDRESS         LOCAL ENDPOINT INFO
10.75.0.103:0      id=97    sec_id=5005442 flags=0x0000 ifindex=9   mac=7E:4D:C6:BE:0B:D9 nodemac=06:06:84:DD:05:AA   
10.75.0.46:0       id=1420  sec_id=5031388 flags=0x0000 ifindex=15  mac=26:DF:4A:29:C2:BE nodemac=EE:A5:3E:89:2E:96   
10.75.0.226:0      id=2469  sec_id=5005442 flags=0x0000 ifindex=11  mac=32:86:F5:30:07:A6 nodemac=EE:0C:E3:85:62:24   
10.75.0.18:0       id=1722  sec_id=4     flags=0x0000 ifindex=7   mac=52:2C:4B:C7:C2:EE nodemac=52:19:6A:59:1F:A3     
172.31.198.153:0   (localhost)                                                                                        
10.75.0.67:0       (localhost)                                                                                        
