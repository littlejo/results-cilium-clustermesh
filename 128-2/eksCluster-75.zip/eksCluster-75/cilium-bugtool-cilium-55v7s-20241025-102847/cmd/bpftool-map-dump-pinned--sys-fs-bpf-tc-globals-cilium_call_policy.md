key: 61 00 00 00  value: ef 01 00 00
key: 8c 05 00 00  value: 50 02 00 00
key: ba 06 00 00  value: 04 02 00 00
key: a5 09 00 00  value: e2 01 00 00
Found 4 elements
