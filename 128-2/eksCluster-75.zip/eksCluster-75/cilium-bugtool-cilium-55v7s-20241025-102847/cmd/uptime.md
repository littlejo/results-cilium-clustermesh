 10:28:49 up 15 min,  0 users,  load average: 0.39, 0.25, 0.20
