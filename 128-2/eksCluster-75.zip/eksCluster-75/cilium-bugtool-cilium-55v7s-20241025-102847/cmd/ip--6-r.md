fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxc6334dbfa0e7b proto kernel metric 256 pref medium
fe80::/64 dev lxc28e84edee560 proto kernel metric 256 pref medium
fe80::/64 dev lxcad2b3f335998 proto kernel metric 256 pref medium
