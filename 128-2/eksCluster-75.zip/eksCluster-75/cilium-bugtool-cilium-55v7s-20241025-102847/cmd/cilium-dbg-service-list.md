ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.238.58:443 (active)     
                                         2 => 172.31.164.100:443 (active)    
2    10.100.132.196:443   ClusterIP      1 => 172.31.198.153:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.75.0.103:53 (active)        
                                         2 => 10.75.0.226:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.75.0.103:9153 (active)      
                                         2 => 10.75.0.226:9153 (active)      
5    10.100.214.36:2379   ClusterIP      1 => 10.75.0.46:2379 (active)       
