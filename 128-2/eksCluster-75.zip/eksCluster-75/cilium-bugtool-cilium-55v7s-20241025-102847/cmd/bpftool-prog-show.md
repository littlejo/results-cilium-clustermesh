29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
69: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
72: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
80: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
83: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
111: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
114: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
455: sched_cls  name tail_handle_ipv4  tag 4be141f9be392fec  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 71,70,77,72,93
	btf_id 115
456: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 72,93
	btf_id 116
457: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 117
458: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 118
482: sched_cls  name handle_policy  tag e4734c868c275c33  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,101,78,79,102,37,76,100,35,80,71,36,33,34
	btf_id 145
483: sched_cls  name __send_drop_notify  tag 1e7dd19486edad70  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 146
484: sched_cls  name tail_ipv4_ct_ingress  tag 6b35d20db602d37a  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,101,78,79,102,80
	btf_id 147
485: sched_cls  name tail_ipv4_to_endpoint  tag 46dcce430a73e461  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,102,37,78,79,76,100,35,101,36,33,34
	btf_id 148
486: sched_cls  name tail_ipv4_ct_egress  tag 5fe53a52b5074b7c  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,101,78,79,102,80
	btf_id 149
487: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,101
	btf_id 150
488: sched_cls  name tail_handle_arp  tag 4e4f9467ecd53a03  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,101
	btf_id 151
489: sched_cls  name cil_from_container  tag 2b3b7cde6e940554  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 101,72
	btf_id 152
490: sched_cls  name tail_handle_ipv4  tag 87a735b2fdcaab0c  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,101
	btf_id 153
491: sched_cls  name tail_handle_ipv4_cont  tag a60c140e0dd3e3ae  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,102,37,100,78,79,35,72,70,73,101,36,33,34,77
	btf_id 154
492: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
495: sched_cls  name handle_policy  tag 3a774c07d0504b2c  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,104,78,79,103,37,76,94,35,80,71,36,33,34
	btf_id 156
496: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
497: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,104
	btf_id 157
498: sched_cls  name tail_handle_ipv4_cont  tag d6f3c564264dae7c  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,103,37,94,78,79,35,72,70,73,104,36,33,34,77
	btf_id 158
499: sched_cls  name cil_from_container  tag 06e9ce18ba274af7  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 104,72
	btf_id 159
500: sched_cls  name tail_ipv4_to_endpoint  tag 97fc9ea48d313f59  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,103,37,78,79,76,94,35,104,36,33,34
	btf_id 160
501: sched_cls  name tail_handle_ipv4  tag 5e061f13e9411caa  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,104
	btf_id 161
502: sched_cls  name tail_ipv4_ct_egress  tag 5fe53a52b5074b7c  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,104,78,79,103,80
	btf_id 162
504: sched_cls  name tail_handle_arp  tag ac822a07a7df686c  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,104
	btf_id 164
505: sched_cls  name __send_drop_notify  tag fa4172d53d567b4f  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 165
506: sched_cls  name tail_ipv4_ct_ingress  tag 00f0dd7b56b88212  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,104,78,79,103,80
	btf_id 166
507: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,106
	btf_id 168
508: sched_cls  name cil_from_container  tag 4dfd08c5076ae219  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 106,72
	btf_id 169
509: sched_cls  name tail_handle_ipv4_cont  tag c31037269a67d7a9  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 71,107,37,95,78,79,35,72,70,73,106,36,33,34,77
	btf_id 170
510: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 72,106,78,79,107,80
	btf_id 171
511: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
514: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
515: sched_cls  name tail_ipv4_to_endpoint  tag bb174a1ccf67e225  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 71,72,107,37,78,79,76,95,35,106,36,33,34
	btf_id 172
516: sched_cls  name handle_policy  tag 2f96471870420e7a  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 72,106,78,79,107,37,76,95,35,80,71,36,33,34
	btf_id 173
517: sched_cls  name __send_drop_notify  tag 793910a393932f1d  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 174
518: sched_cls  name tail_handle_ipv4  tag f4cd9e267dfd9b6e  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,106
	btf_id 175
519: sched_cls  name tail_handle_arp  tag 1fca13d8ceed63ec  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,106
	btf_id 176
521: sched_cls  name tail_ipv4_ct_ingress  tag fa0685975a623939  gpl
	loaded_at 2024-10-25T10:14:32+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 72,106,78,79,107,80
	btf_id 178
522: sched_cls  name tail_handle_ipv4_from_host  tag 2be1ddffd4b6a292  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,110
	btf_id 180
523: sched_cls  name __send_drop_notify  tag 461a68f85a4df473  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 181
524: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 72,71,110
	btf_id 182
526: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,110
	btf_id 184
527: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 185
529: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 188
531: sched_cls  name tail_handle_ipv4_from_host  tag 2be1ddffd4b6a292  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,112
	btf_id 190
532: sched_cls  name __send_drop_notify  tag 461a68f85a4df473  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 191
535: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,112
	btf_id 194
536: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,114
	btf_id 196
538: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 72,114,71
	btf_id 198
539: sched_cls  name tail_handle_ipv4_from_host  tag 2be1ddffd4b6a292  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,114
	btf_id 199
540: sched_cls  name __send_drop_notify  tag 461a68f85a4df473  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 200
543: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
546: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
547: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
550: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
590: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,129
	btf_id 217
591: sched_cls  name tail_handle_ipv4  tag 471b11de740d72b6  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,129
	btf_id 218
592: sched_cls  name handle_policy  tag cc6f8a5b8ae5c428  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,129,78,79,128,37,76,127,35,80,71,36,33,34
	btf_id 219
593: sched_cls  name tail_ipv4_ct_ingress  tag 66ccefd335d50ef9  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,129,78,79,128,80
	btf_id 220
594: sched_cls  name __send_drop_notify  tag a5a84cfc50820096  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 221
595: sched_cls  name tail_ipv4_ct_egress  tag d9a73e0b3f2f5125  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,129,78,79,128,80
	btf_id 222
596: sched_cls  name tail_ipv4_to_endpoint  tag 3bb8e0d7ad495285  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,128,37,78,79,76,127,35,129,36,33,34
	btf_id 223
597: sched_cls  name tail_handle_arp  tag 5cb14921edc2bd87  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,129
	btf_id 224
598: sched_cls  name tail_handle_ipv4_cont  tag ea012b10f43a3590  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,128,37,127,78,79,35,72,70,73,129,36,33,34,77
	btf_id 225
599: sched_cls  name cil_from_container  tag b2e568f7080625b6  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 129,72
	btf_id 226
601: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
604: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
617: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
620: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
621: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
624: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
625: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
628: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
