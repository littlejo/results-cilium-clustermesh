Endpoint ID: 97
Path: /sys/fs/bpf/tc/globals/cilium_policy_00097

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    84212   968       0        
Allow    Egress      0          ANY          NONE         disabled    14306   149       0        


Endpoint ID: 1420
Path: /sys/fs/bpf/tc/globals/cilium_policy_01420

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3880310   36747     0        
Allow    Ingress     1          ANY          NONE         disabled    3275485   33362     0        
Allow    Egress      0          ANY          NONE         disabled    4990269   46137     0        


Endpoint ID: 1722
Path: /sys/fs/bpf/tc/globals/cilium_policy_01722

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    441823   5643      0        
Allow    Ingress     1          ANY          NONE         disabled    12416    146       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2469
Path: /sys/fs/bpf/tc/globals/cilium_policy_02469

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83948   964       0        
Allow    Egress      0          ANY          NONE         disabled    13828   145       0        


Endpoint ID: 3659
Path: /sys/fs/bpf/tc/globals/cilium_policy_03659

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


