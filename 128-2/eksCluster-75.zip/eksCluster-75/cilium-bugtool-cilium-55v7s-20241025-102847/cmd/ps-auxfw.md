USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         674  0.0  0.0 1228744 3596 ?        Ssl  10:28   0:00 /bin/gops stack 1
root         668  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops stats 1
root         658  0.0  0.4 1240432 16120 ?       Rsl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         705  0.0  0.0   6408  1644 ?        R    10:28   0:00  \_ ps auxfw
root         657  0.0  0.1 1229000 4052 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root         651  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root           1  3.0  7.0 1472240 277668 ?      Ssl  10:14   0:26 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.0  0.1 1228848 6908 ?        Sl   10:14   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
