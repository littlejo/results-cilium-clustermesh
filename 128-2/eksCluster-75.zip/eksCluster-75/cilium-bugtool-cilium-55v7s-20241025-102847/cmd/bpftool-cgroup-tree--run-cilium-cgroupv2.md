CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3082a46_aedd_4a07_a8c1_785ac135225c.slice/cri-containerd-3fc83a428a2812729e6fb034d6e48b8cc39efdc52fd2a2514813de07e7b24ea7.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3082a46_aedd_4a07_a8c1_785ac135225c.slice/cri-containerd-5b235766d6e20da7e551faf85f697ddf0cb7dad6dd7e1ec16b1c946ef1286723.scope
    514      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb74a7cb6_0d13_4bbd_9fb5_2ef256889f7b.slice/cri-containerd-a95e807ad75cd055294cc67311fff95c5cb9df58fb81f4e89f0559bee9fc5047.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb74a7cb6_0d13_4bbd_9fb5_2ef256889f7b.slice/cri-containerd-2ff5c77e3c108f48633e0627153e2abbb2ffeed655ba5a58ceaf61732be9276c.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf94f3f41_2231_473f_8e3b_440e25bc901a.slice/cri-containerd-5de607bb46f4d43cc316d089c22c055256151ec350384ac5d40f9a0e0889e342.scope
    496      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf94f3f41_2231_473f_8e3b_440e25bc901a.slice/cri-containerd-c1106c4686dffaeb8e782b1ad905970170f8b0468d7c0b446f4ede770f569f47.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc7e422a2_da0f_4201_a81a_88e9f7bb174d.slice/cri-containerd-19babd6381f8bb9261d835c3078a9bb2f1b2e27949d9b620145c32a96b057868.scope
    114      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc7e422a2_da0f_4201_a81a_88e9f7bb174d.slice/cri-containerd-48af827230d87f4882d66a52b9264940a00d4c79659c849508203a8a7db7694f.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca396e03_05ab_4026_bfd7_317696a893df.slice/cri-containerd-7f857543c4f92404cfc1377424847b72a4542816d3c529db75ee504d133e0a65.scope
    72       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podca396e03_05ab_4026_bfd7_317696a893df.slice/cri-containerd-49bcd9a1cf40f1fddf8527864756a2b5756d4bfc7fd2c0768f6a7b3aa083a3dc.scope
    83       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd260cefc_eeb7_4586_8a47_918aa7e309f7.slice/cri-containerd-ede122688cdf65119c8169f71a40de4ab6959487fcb6e6418d0046eafaa93f32.scope
    628      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd260cefc_eeb7_4586_8a47_918aa7e309f7.slice/cri-containerd-54967e7ce55ca430f92a1bfbce0c9fc8179bdf748d86aca8a3ffa35e1e8ba117.scope
    620      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd260cefc_eeb7_4586_8a47_918aa7e309f7.slice/cri-containerd-c0be7e3424ba21ae9a22d835cdd442fdf1a533bc499aee4efa08205c3ebe2c78.scope
    624      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd260cefc_eeb7_4586_8a47_918aa7e309f7.slice/cri-containerd-3456a43409ba44adf5f133952703cd665e147fe0a9d6297c45167c3bf3017056.scope
    604      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0bf354d4_7233_4937_8f73_4b08b0e28b29.slice/cri-containerd-959c1ed0f95dd615c69e71521414d7e13b724e2dbaa5c37de446b0644c09ee7c.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0bf354d4_7233_4937_8f73_4b08b0e28b29.slice/cri-containerd-031bea1966351fceaf72b61c0eae022904c8897d92797d0a6ba67fdd74f8987e.scope
    87       cgroup_device   multi                                          
