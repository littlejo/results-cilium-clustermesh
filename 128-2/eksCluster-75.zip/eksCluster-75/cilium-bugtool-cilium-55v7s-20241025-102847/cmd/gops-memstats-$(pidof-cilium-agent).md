alloc: 82.75MB (86771856 bytes)
total-alloc: 1.36GB (1460909256 bytes)
sys: 206.38MB (216409428 bytes)
lookups: 0
mallocs: 48261203
frees: 47581132
heap-alloc: 82.75MB (86771856 bytes)
heap-sys: 161.48MB (169328640 bytes)
heap-idle: 41.13MB (43130880 bytes)
heap-in-use: 120.35MB (126197760 bytes)
heap-released: 512.00KB (524288 bytes)
heap-objects: 680071
stack-in-use: 34.47MB (36143104 bytes)
stack-sys: 34.47MB (36143104 bytes)
stack-mspan-inuse: 1.99MB (2081600 bytes)
stack-mspan-sys: 2.44MB (2562240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 921.13KB (943233 bytes)
gc-sys: 5.18MB (5435720 bytes)
next-gc: when heap-alloc >= 146.05MB (153139800 bytes)
last-gc: 2024-10-25 10:29:04.942547797 +0000 UTC
gc-pause-total: 8.979293ms
gc-pause: 129937
gc-pause-end: 1729852144942547797
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.000353758969840053
enable-gc: true
debug-gc: false
