Node 0, zone      DMA    225     67      8      1      2     43     81     18      5      4    155 
Node 0, zone   Normal    591     92     45     24     13      9     14      0      0      2      7 
