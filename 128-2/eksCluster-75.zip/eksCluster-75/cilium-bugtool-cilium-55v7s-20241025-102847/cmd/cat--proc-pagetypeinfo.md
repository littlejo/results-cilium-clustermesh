Page block order: 9
Pages per block:  512

Free pages count per migrate type at order       0      1      2      3      4      5      6      7      8      9     10 
Node    0, zone      DMA, type    Unmovable    224     66      8      0      1      2      6      3      0      0      0 
Node    0, zone      DMA, type      Movable      0      1      0      0      0     21     73     15      4      2    140 
Node    0, zone      DMA, type  Reclaimable      0      1      0      0      0      0      0      0      1      1      0 
Node    0, zone      DMA, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone      DMA, type          CMA      0      1      0      0      0      1      1      0      0      1     15 
Node    0, zone      DMA, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type    Unmovable    585     86     44     23     13      7     13      0      0      1      0 
Node    0, zone   Normal, type      Movable      1      1      1      1      0      1      0      0      0      1      7 
Node    0, zone   Normal, type  Reclaimable      5      5      0      0      0      1      1      0      0      0      0 
Node    0, zone   Normal, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type          CMA      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 

Number of blocks type     Unmovable      Movable  Reclaimable   HighAtomic          CMA      Isolate 
Node 0, zone      DMA           10          466            4            0           32            0 
Node 0, zone   Normal          104         1366           30            0            0            0 
