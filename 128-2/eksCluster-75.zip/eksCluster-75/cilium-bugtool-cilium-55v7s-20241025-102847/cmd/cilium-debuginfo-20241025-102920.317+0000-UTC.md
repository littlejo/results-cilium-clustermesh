# Cilium debug information

#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
97         Disabled           Disabled          5005442    k8s:eks.amazonaws.com/component=coredns                                             10.75.0.103   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh76                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
1420       Disabled           Disabled          5031388    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.75.0.46    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh76                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
1722       Disabled           Disabled          4          reserved:health                                                                     10.75.0.18    ready   
2469       Disabled           Disabled          5005442    k8s:eks.amazonaws.com/component=coredns                                             10.75.0.226   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh76                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
3659       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                
                                                           reserved:host                                                                                             
```

#### BPF Policy Get 97

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    84212   968       0        
Allow    Egress      0          ANY          NONE         disabled    14306   149       0        

```


#### BPF CT List 97

```
Invalid argument: unknown type 97
```


#### Endpoint Get 97

```
[
  {
    "id": 97,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-97-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "af7f486f-9472-4d5e-ac95-9b6a29ce2a27"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-97",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:28.905Z",
            "success-count": 3
          },
          "uuid": "82d7b4f6-7fb3-45f5-93bf-6a9a019cdd9a"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-5g7f5",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:28.904Z",
            "success-count": 1
          },
          "uuid": "4c86120b-61eb-4435-90f5-a295e7a23e05"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-97",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:32.093Z",
            "success-count": 1
          },
          "uuid": "045165c6-cba9-4076-8a63-3eabe5e24907"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (97)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:18.984Z",
            "success-count": 91
          },
          "uuid": "22e38bbf-c090-4798-a510-f47d020a954b"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "5de607bb46f4d43cc316d089c22c055256151ec350384ac5d40f9a0e0889e342:eth0",
        "container-id": "5de607bb46f4d43cc316d089c22c055256151ec350384ac5d40f9a0e0889e342",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-5g7f5",
        "pod-name": "kube-system/coredns-cc6ccd49c-5g7f5"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5005442,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh76",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh76",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:30Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.75.0.103",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "06:06:84:dd:05:aa",
        "interface-index": 9,
        "interface-name": "lxc6334dbfa0e7b",
        "mac": "7e:4d:c6:be:0b:d9"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5005442,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5005442,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 97

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 97

```
Timestamp              Status    State                   Message
2024-10-25T10:22:30Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:30Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:30Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:22:30Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:29Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:29Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:29Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:29Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:28Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:28Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:28Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:28Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:16Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:16Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:16Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:16Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:15Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:15Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:15Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:15Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:32Z   OK        ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:14:32Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:32Z   OK        regenerating            Regenerating endpoint: devices changed
2024-10-25T10:14:32Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:29Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:14:29Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:14:28Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:28Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:28Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:14:28Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:28Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 5005442

```
ID        LABELS
5005442   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh76
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1420

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3868002   36611     0        
Allow    Ingress     1          ANY          NONE         disabled    3275485   33362     0        
Allow    Egress      0          ANY          NONE         disabled    4984405   46072     0        

```


#### BPF CT List 1420

```
Invalid argument: unknown type 1420
```


#### Endpoint Get 1420

```
[
  {
    "id": 1420,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1420-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "1c405dc5-8021-46d0-b0ba-65b48e8da10d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1420",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:45.046Z",
            "success-count": 2
          },
          "uuid": "9d076082-b15a-4d73-96be-760bb78f13d0"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-7644bfb4b-5rhhr",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:45.041Z",
            "success-count": 1
          },
          "uuid": "589ff8c0-7313-46f4-8867-80d0c2a590d1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1420",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:45.094Z",
            "success-count": 1
          },
          "uuid": "a6ffdbf1-ee33-47db-a4a8-ba187fde5e8e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1420)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:15.106Z",
            "success-count": 47
          },
          "uuid": "0ddf4ea9-ca23-4140-9d88-bfadca45ea68"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "3456a43409ba44adf5f133952703cd665e147fe0a9d6297c45167c3bf3017056:eth0",
        "container-id": "3456a43409ba44adf5f133952703cd665e147fe0a9d6297c45167c3bf3017056",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-7644bfb4b-5rhhr",
        "pod-name": "kube-system/clustermesh-apiserver-7644bfb4b-5rhhr"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5031388,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh76",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7644bfb4b"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh76",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:30Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.75.0.46",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ee:a5:3e:89:2e:96",
        "interface-index": 15,
        "interface-name": "lxcad2b3f335998",
        "mac": "26:df:4a:29:c2:be"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5031388,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5031388,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1420

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1420

```
Timestamp              Status   State                   Message
2024-10-25T10:22:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:30Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:45Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:45Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:45Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 5031388

```
ID        LABELS
5031388   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh76
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1722

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    440491   5626      0        
Allow    Ingress     1          ANY          NONE         disabled    12416    146       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 1722

```
Invalid argument: unknown type 1722
```


#### Endpoint Get 1722

```
[
  {
    "id": 1722,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1722-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f770304f-c66c-46d6-852c-a64fe5102da7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1722",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:28.672Z",
            "success-count": 3
          },
          "uuid": "e393213d-d142-49d7-ac98-7bdfa4bd16fa"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1722",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:32.098Z",
            "success-count": 1
          },
          "uuid": "22d6ec2f-5216-4bfd-9dc9-5e56a2e9f009"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:30Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.75.0.18",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "52:19:6a:59:1f:a3",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "52:2c:4b:c7:c2:ee"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1722

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1722

```
Timestamp              Status   State                   Message
2024-10-25T10:22:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:30Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:32Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:29Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:14:29Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:28Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:28Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:27Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 2469

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83948   964       0        
Allow    Egress      0          ANY          NONE         disabled    13828   145       0        

```


#### BPF CT List 2469

```
Invalid argument: unknown type 2469
```


#### Endpoint Get 2469

```
[
  {
    "id": 2469,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2469-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "db809a62-810c-4ecb-b1e9-4ed79ea1cca2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2469",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:28.978Z",
            "success-count": 3
          },
          "uuid": "c9dbab0e-2d22-4440-a7e5-09c87a8d1806"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-nb7vc",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:28.977Z",
            "success-count": 1
          },
          "uuid": "7dbf39d6-7253-414e-bb2a-41235fe37fb5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2469",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:32.187Z",
            "success-count": 1
          },
          "uuid": "978563c6-0efc-46d5-ac25-ca97799bcfe3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2469)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:19.052Z",
            "success-count": 91
          },
          "uuid": "ab959ffa-057f-4c3b-8393-32fdb9c0b074"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "5b235766d6e20da7e551faf85f697ddf0cb7dad6dd7e1ec16b1c946ef1286723:eth0",
        "container-id": "5b235766d6e20da7e551faf85f697ddf0cb7dad6dd7e1ec16b1c946ef1286723",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-nb7vc",
        "pod-name": "kube-system/coredns-cc6ccd49c-nb7vc"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5005442,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh76",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh76",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:30Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.75.0.226",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ee:0c:e3:85:62:24",
        "interface-index": 11,
        "interface-name": "lxc28e84edee560",
        "mac": "32:86:f5:30:07:a6"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5005442,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5005442,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2469

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2469

```
Timestamp              Status   State                   Message
2024-10-25T10:22:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:30Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:32Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:29Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:14:29Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:28Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:28Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 5005442

```
ID        LABELS
5005442   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh76
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 3659

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 3659

```
Invalid argument: unknown type 3659
```


#### Endpoint Get 3659

```
[
  {
    "id": 3659,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3659-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5a29415c-6ff4-471c-9ea4-1329ead49f5d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3659",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:27.617Z",
            "success-count": 3
          },
          "uuid": "10d894f4-de80-43cb-b70f-c5c10722c741"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3659",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:28.752Z",
            "success-count": 1
          },
          "uuid": "eb84c1c5-31b1-4bc6-b01d-baebea996d2f"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:30Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "46:5a:45:c9:3b:e5",
        "interface-name": "cilium_host",
        "mac": "46:5a:45:c9:3b:e5"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3659

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3659

```
Timestamp              Status   State                   Message
2024-10-25T10:22:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:30Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:29Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:14:29Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:27Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:27Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:27Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### Service list

```
ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.238.58:443 (active)     
                                         2 => 172.31.164.100:443 (active)    
2    10.100.132.196:443   ClusterIP      1 => 172.31.198.153:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.75.0.103:53 (active)        
                                         2 => 10.75.0.226:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.75.0.103:9153 (active)      
                                         2 => 10.75.0.226:9153 (active)      
5    10.100.214.36:2379   ClusterIP      1 => 10.75.0.46:2379 (active)       
```

#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.75.0.46": (string) (len=49) "kube-system/clustermesh-apiserver-7644bfb4b-5rhhr",
  (string) (len=10) "10.75.0.67": (string) (len=6) "router",
  (string) (len=10) "10.75.0.18": (string) (len=6) "health",
  (string) (len=11) "10.75.0.103": (string) (len=35) "kube-system/coredns-cc6ccd49c-5g7f5",
  (string) (len=11) "10.75.0.226": (string) (len=35) "kube-system/coredns-cc6ccd49c-nb7vc"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.198.153": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001ab68f0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x40023c37a0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x40023c37a0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4001ab7e40)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4000a3cc60)(frontends:[10.100.132.196]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4000a3d970)(frontends:[10.100.0.10]/ports=[metrics dns dns-tcp]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4002b00a50)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4002b00b00)(frontends:[10.100.214.36]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x40019afc78)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4002ede000)(172.31.164.100:443/TCP,172.31.238.58:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x40019afc80)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-wdqwl": (*k8s.Endpoints)(0x40015dc000)(172.31.198.153:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x40019afc88)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-prn26": (*k8s.Endpoints)(0x40008c5520)(10.75.0.103:53/TCP[eu-west-3b],10.75.0.103:53/UDP[eu-west-3b],10.75.0.103:9153/TCP[eu-west-3b],10.75.0.226:53/TCP[eu-west-3b],10.75.0.226:53/UDP[eu-west-3b],10.75.0.226:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40019af010)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-cg8h4": (*k8s.Endpoints)(0x4002867a00)(10.75.0.46:2379/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4002581ab0)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40020e1c70)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4001bd91d0
  },
  gcTrigger: (chan struct {}) (cap=1) 0x40020da5a0,
  gcExited: (chan struct {}) 0x40020da600,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x40025cd480)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000f65478)({
      MetricVec: (*prometheus.MetricVec)(0x400077efc0)({
       metricMap: (*prometheus.metricMap)(0x400077f1a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400261ad80)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x40025cd500)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000f65480)({
      MetricVec: (*prometheus.MetricVec)(0x400077f230)({
       metricMap: (*prometheus.metricMap)(0x400077f260)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400261ade0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x40025cd580)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000f65488)({
      MetricVec: (*prometheus.MetricVec)(0x400077f2c0)({
       metricMap: (*prometheus.metricMap)(0x400077f2f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400261ae40)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x40025cd600)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000f65490)({
      MetricVec: (*prometheus.MetricVec)(0x400077f380)({
       metricMap: (*prometheus.metricMap)(0x400077f3b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400261aea0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x40025cd680)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000f65498)({
      MetricVec: (*prometheus.MetricVec)(0x400077f410)({
       metricMap: (*prometheus.metricMap)(0x400077f440)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400261af00)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x40025cd700)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000f654a0)({
      MetricVec: (*prometheus.MetricVec)(0x400077f4d0)({
       metricMap: (*prometheus.metricMap)(0x400077f500)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400261af60)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x40025cd780)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000f654a8)({
      MetricVec: (*prometheus.MetricVec)(0x400077f560)({
       metricMap: (*prometheus.metricMap)(0x400077f590)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400261afc0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x40025cd800)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000f654b0)({
      MetricVec: (*prometheus.MetricVec)(0x400077f620)({
       metricMap: (*prometheus.metricMap)(0x400077f680)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400261b020)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x40025cd880)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000f654b8)({
      MetricVec: (*prometheus.MetricVec)(0x400077f6e0)({
       metricMap: (*prometheus.metricMap)(0x400077f710)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400261b080)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4002581ab0)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4002471c70)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x40009f99b0)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 304ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.75.0.0/24, 
Allocated addresses:
  10.75.0.103 (kube-system/coredns-cc6ccd49c-5g7f5)
  10.75.0.18 (health)
  10.75.0.226 (kube-system/coredns-cc6ccd49c-nb7vc)
  10.75.0.46 (kube-system/clustermesh-apiserver-7644bfb4b-5rhhr)
  10.75.0.67 (router)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bd60a8f927e18e7f
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                               Last success   Last error   Count   Message
  cilium-health-ep                                                   52s ago        never        0       no error   
  ct-map-pressure                                                    24s ago        never        0       no error   
  daemon-validate-config                                             40s ago        never        0       no error   
  dns-garbage-collector-job                                          56s ago        never        0       no error   
  endpoint-1420-regeneration-recovery                                never          never        0       no error   
  endpoint-1722-regeneration-recovery                                never          never        0       no error   
  endpoint-2469-regeneration-recovery                                never          never        0       no error   
  endpoint-3659-regeneration-recovery                                never          never        0       no error   
  endpoint-97-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                        4m57s ago      never        0       no error   
  ep-bpf-prog-watchdog                                               24s ago        never        0       no error   
  ipcache-inject-labels                                              54s ago        never        0       no error   
  k8s-heartbeat                                                      27s ago        never        0       no error   
  link-cache                                                         9s ago         never        0       no error   
  local-identity-checkpoint                                          14m54s ago     never        0       no error   
  node-neighbor-link-updater                                         4s ago         never        0       no error   
  remote-etcd-cmesh1                                                 6m53s ago      never        0       no error   
  remote-etcd-cmesh10                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh100                                               6m52s ago      never        0       no error   
  remote-etcd-cmesh101                                               6m52s ago      never        0       no error   
  remote-etcd-cmesh102                                               6m52s ago      never        0       no error   
  remote-etcd-cmesh103                                               6m52s ago      never        0       no error   
  remote-etcd-cmesh104                                               6m53s ago      never        0       no error   
  remote-etcd-cmesh105                                               6m53s ago      never        0       no error   
  remote-etcd-cmesh106                                               6m53s ago      never        0       no error   
  remote-etcd-cmesh107                                               6m53s ago      never        0       no error   
  remote-etcd-cmesh108                                               6m53s ago      never        0       no error   
  remote-etcd-cmesh109                                               6m53s ago      never        0       no error   
  remote-etcd-cmesh11                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh110                                               6m53s ago      never        0       no error   
  remote-etcd-cmesh111                                               6m52s ago      never        0       no error   
  remote-etcd-cmesh112                                               6m52s ago      never        0       no error   
  remote-etcd-cmesh113                                               6m53s ago      never        0       no error   
  remote-etcd-cmesh114                                               6m53s ago      never        0       no error   
  remote-etcd-cmesh115                                               6m52s ago      never        0       no error   
  remote-etcd-cmesh116                                               6m53s ago      never        0       no error   
  remote-etcd-cmesh117                                               6m53s ago      never        0       no error   
  remote-etcd-cmesh118                                               6m52s ago      never        0       no error   
  remote-etcd-cmesh119                                               6m52s ago      never        0       no error   
  remote-etcd-cmesh12                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh120                                               6m53s ago      never        0       no error   
  remote-etcd-cmesh121                                               6m53s ago      never        0       no error   
  remote-etcd-cmesh122                                               6m53s ago      never        0       no error   
  remote-etcd-cmesh123                                               6m52s ago      never        0       no error   
  remote-etcd-cmesh124                                               6m52s ago      never        0       no error   
  remote-etcd-cmesh125                                               6m53s ago      never        0       no error   
  remote-etcd-cmesh126                                               6m53s ago      never        0       no error   
  remote-etcd-cmesh127                                               6m52s ago      never        0       no error   
  remote-etcd-cmesh128                                               6m53s ago      never        0       no error   
  remote-etcd-cmesh13                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh14                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh15                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh16                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh17                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh18                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh19                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh2                                                 6m53s ago      never        0       no error   
  remote-etcd-cmesh20                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh21                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh22                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh23                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh24                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh25                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh26                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh27                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh28                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh29                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh3                                                 6m53s ago      never        0       no error   
  remote-etcd-cmesh30                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh31                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh32                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh33                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh34                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh35                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh36                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh37                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh38                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh39                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh4                                                 6m53s ago      never        0       no error   
  remote-etcd-cmesh40                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh41                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh42                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh43                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh44                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh45                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh46                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh47                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh48                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh49                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh5                                                 6m53s ago      never        0       no error   
  remote-etcd-cmesh50                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh51                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh52                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh53                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh54                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh55                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh56                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh57                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh58                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh59                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh6                                                 6m52s ago      never        0       no error   
  remote-etcd-cmesh60                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh61                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh62                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh63                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh64                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh65                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh66                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh67                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh68                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh69                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh7                                                 6m53s ago      never        0       no error   
  remote-etcd-cmesh70                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh71                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh72                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh73                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh74                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh75                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh77                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh78                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh79                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh8                                                 6m53s ago      never        0       no error   
  remote-etcd-cmesh80                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh81                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh82                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh83                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh84                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh85                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh86                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh87                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh88                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh89                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh9                                                 6m52s ago      never        0       no error   
  remote-etcd-cmesh90                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh91                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh92                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh93                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh94                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh95                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh96                                                6m52s ago      never        0       no error   
  remote-etcd-cmesh97                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh98                                                6m53s ago      never        0       no error   
  remote-etcd-cmesh99                                                6m53s ago      never        0       no error   
  resolve-identity-1420                                              2m36s ago      never        0       no error   
  resolve-identity-1722                                              4m53s ago      never        0       no error   
  resolve-identity-2469                                              4m52s ago      never        0       no error   
  resolve-identity-3659                                              4m54s ago      never        0       no error   
  resolve-identity-97                                                4m53s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-7644bfb4b-5rhhr   7m36s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-5g7f5                 14m53s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-nb7vc                 14m52s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                     14m54s ago     never        0       no error   
  sync-policymap-1420                                                7m36s ago      never        0       no error   
  sync-policymap-1722                                                14m49s ago     never        0       no error   
  sync-policymap-2469                                                14m49s ago     never        0       no error   
  sync-policymap-3659                                                14m53s ago     never        0       no error   
  sync-policymap-97                                                  14m49s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (1420)                                  6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2469)                                  12s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (97)                                    12s ago        never        0       no error   
  sync-utime                                                         54s ago        never        0       no error   
  write-cni-file                                                     14m57s ago     never        0       no error   
Proxy Status:            OK, ip 10.75.0.67, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 4980736, max 5046271
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 73.93   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
tofqdns-pre-cache:
http-max-grpc-timeout:0
route-metric:0
hubble-redact-http-headers-allow:
procfs:/host/proc
custom-cni-conf:false
bpf-lb-dsr-l4-xlate:frontend
devices:
disable-iptables-feeder-rules:
cilium-endpoint-gc-interval:5m0s
node-labels:
kvstore-opt:
bpf-ct-timeout-regular-tcp-fin:10s
enable-cilium-health-api-server-access:
tofqdns-proxy-port:0
fqdn-regex-compile-lru-size:1024
service-no-backend-response:reject
bpf-lb-map-max:65536
l2-pod-announcements-interface:
dns-max-ips-per-restored-rule:1000
bpf-lb-affinity-map-max:0
envoy-config-retry-interval:15s
bpf-auth-map-max:524288
read-cni-conf:
enable-l2-neigh-discovery:true
bypass-ip-availability-upon-restore:false
ip-masq-agent-config-path:/etc/config/ip-masq-agent
hubble-export-denylist:
enable-cilium-endpoint-slice:false
bpf-sock-rev-map-max:262144
k8s-client-connection-timeout:30s
bpf-lb-sock:false
auto-direct-node-routes:false
preallocate-bpf-maps:false
ipv6-node:auto
auto-create-cilium-node-resource:true
hubble-redact-http-urlquery:false
mesh-auth-spiffe-trust-domain:spiffe.cilium
enable-identity-mark:true
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
external-envoy-proxy:true
bpf-lb-maglev-table-size:16381
ipsec-key-rotation-duration:5m0s
hubble-flowlogs-config-path:
enable-bbr:false
synchronize-k8s-nodes:true
allow-icmp-frag-needed:true
enable-bgp-control-plane:false
k8s-client-connection-keep-alive:30s
enable-session-affinity:false
cgroup-root:/run/cilium/cgroupv2
identity-gc-interval:15m0s
enable-vtep:false
ipv6-pod-subnets:
crd-wait-timeout:5m0s
endpoint-gc-interval:5m0s
enable-ipsec-encrypted-overlay:false
enable-ipip-termination:false
max-connected-clusters:255
endpoint-bpf-prog-watchdog-interval:30s
enable-gateway-api:false
identity-change-grace-period:5s
nodeport-addresses:
bgp-config-path:/var/lib/cilium/bgp/config.yaml
ipam-default-ip-pool:default
enable-custom-calls:false
max-controller-interval:0
enable-health-checking:true
hubble-event-buffer-capacity:4095
exclude-node-label-patterns:
envoy-log:
enable-encryption-strict-mode:false
controller-group-metrics:
dnsproxy-concurrency-processing-grace-period:0s
enable-l2-announcements:false
datapath-mode:veth
enable-bandwidth-manager:false
k8s-kubeconfig-path:
enable-k8s-endpoint-slice:true
max-internal-timer-delay:0s
tofqdns-endpoint-max-ip-per-hostname:50
bpf-fragments-map-max:8192
tofqdns-dns-reject-response-code:refused
hubble-skip-unknown-cgroup-ids:true
hubble-socket-path:/var/run/cilium/hubble.sock
monitor-aggregation:medium
egress-gateway-policy-map-max:16384
enable-bpf-tproxy:false
ipv6-service-range:auto
enable-host-port:false
clustermesh-config:/var/lib/cilium/clustermesh/
enable-l2-pod-announcements:false
bpf-lb-maglev-map-max:0
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
api-rate-limit:
enable-local-node-route:true
mesh-auth-spire-admin-socket:
egress-gateway-reconciliation-trigger-interval:1s
vlan-bpf-bypass:
enable-tracing:false
keep-config:false
vtep-endpoint:
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
mesh-auth-signal-backoff-duration:1s
dnsproxy-socket-linger-timeout:10
tofqdns-max-deferred-connection-deletes:10000
enable-l7-proxy:true
bgp-announce-lb-ip:false
install-iptables-rules:true
nat-map-stats-interval:30s
bpf-lb-mode:snat
bpf-map-dynamic-size-ratio:0.0025
proxy-admin-port:0
enable-xdp-prefilter:false
enable-ipv4-masquerade:true
nodes-gc-interval:5m0s
bpf-root:/sys/fs/bpf
k8s-namespace:kube-system
hubble-export-file-path:
hubble-event-queue-size:0
ipv4-pod-subnets:
k8s-sync-timeout:3m0s
tofqdns-enable-dns-compression:true
enable-k8s-terminating-endpoint:true
enable-bpf-masquerade:false
node-port-acceleration:disabled
encryption-strict-mode-allow-remote-node-identities:false
enable-ipsec:false
encryption-strict-mode-cidr:
enable-xt-socket-fallback:true
enable-node-port:false
bpf-map-event-buffers:
config-sources:config-map:kube-system/cilium-config
cni-external-routing:false
bpf-ct-timeout-regular-tcp-syn:1m0s
enable-ipsec-key-watcher:true
tofqdns-idle-connection-grace-period:0s
bpf-nat-global-max:524288
container-ip-local-reserved-ports:auto
bgp-announce-pod-cidr:false
proxy-portrange-max:20000
iptables-random-fully:false
mesh-auth-mutual-listener-port:0
enable-policy:default
kvstore-connectivity-timeout:2m0s
cni-exclusive:true
set-cilium-node-taints:true
monitor-queue-size:0
cluster-pool-ipv4-cidr:10.75.0.0/16
egress-multi-home-ip-rule-compat:false
vtep-mask:
force-device-detection:false
k8s-require-ipv6-pod-cidr:false
identity-heartbeat-timeout:30m0s
unmanaged-pod-watcher-interval:15
hubble-drop-events-reasons:auth_required,policy_denied
cflags:
bpf-lb-rev-nat-map-max:0
policy-cidr-match-mode:
proxy-gid:1337
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
hubble-redact-http-headers-deny:
kvstore-periodic-sync:5m0s
http-normalize-path:true
enable-host-legacy-routing:false
enable-well-known-identities:false
prometheus-serve-addr:
version:false
enable-srv6:false
cni-chaining-target:
policy-audit-mode:false
mtu:0
k8s-service-proxy-name:
enable-mke:false
hubble-listen-address::4244
enable-health-check-loadbalancer-ip:false
vtep-cidr:
bpf-lb-rss-ipv6-src-cidr:
bpf-ct-global-any-max:262144
enable-masquerade-to-route-source:false
endpoint-queue-size:25
gateway-api-secrets-namespace:
http-idle-timeout:0
hubble-redact-enabled:false
enable-ip-masq-agent:false
ingress-secrets-namespace:
log-system-load:false
encrypt-interface:
envoy-secrets-namespace:
bpf-policy-map-full-reconciliation-interval:15m0s
iptables-lock-timeout:5s
enable-ipv4:true
kube-proxy-replacement-healthz-bind-address:
hubble-redact-kafka-apikey:false
bpf-events-trace-enabled:true
monitor-aggregation-interval:5s
bpf-lb-source-range-map-max:0
remove-cilium-node-taints:true
hubble-redact-http-userinfo:true
labels:
tunnel-protocol:vxlan
cmdref:
config-dir:/tmp/cilium/config-map
derive-masq-ip-addr-from-device:
k8s-service-cache-size:128
node-port-algorithm:random
kube-proxy-replacement:false
static-cnp-path:
enable-tcx:true
arping-refresh-period:30s
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
ipv4-node:auto
mesh-auth-mutual-connect-timeout:5s
enable-pmtu-discovery:false
bpf-ct-global-tcp-max:524288
restore:true
k8s-heartbeat-timeout:30s
wireguard-persistent-keepalive:0s
enable-wireguard:false
agent-liveness-update-interval:1s
enable-ipsec-xfrm-state-caching:true
routing-mode:tunnel
enable-sctp:false
mke-cgroup-mount:
bpf-node-map-max:16384
cni-chaining-mode:none
hubble-drop-events-interval:2m0s
hubble-metrics:
bpf-events-drop-enabled:true
http-retry-count:3
egress-masquerade-interfaces:ens+
kvstore:
enable-k8s-api-discovery:false
enable-service-topology:false
bpf-policy-map-max:16384
clustermesh-sync-timeout:1m0s
disable-external-ip-mitigation:false
proxy-max-requests-per-connection:0
ipsec-key-file:
k8s-client-burst:20
bpf-lb-acceleration:disabled
clustermesh-enable-mcs-api:false
enable-external-ips:false
bpf-lb-sock-terminate-pod-connections:false
envoy-base-id:0
bpf-lb-external-clusterip:false
proxy-idle-timeout-seconds:60
direct-routing-device:
annotate-k8s-node:false
enable-stale-cilium-endpoint-cleanup:true
ipv6-native-routing-cidr:
log-driver:
enable-icmp-rules:true
cluster-id:76
enable-ipv6-masquerade:true
enable-k8s-networkpolicy:true
enable-ingress-controller:false
use-cilium-internal-ip-for-ipsec:false
enable-hubble:true
join-cluster:false
enable-wireguard-userspace-fallback:false
bpf-ct-timeout-service-any:1m0s
bpf-lb-dsr-dispatch:opt
pprof:false
enable-metrics:true
pprof-address:localhost
config:
l2-announcements-lease-duration:15s
hubble-export-file-max-size-mb:10
hubble-disable-tls:false
bpf-ct-timeout-regular-any:1m0s
tunnel-port:0
bpf-lb-rss-ipv4-src-cidr:
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
l2-announcements-retry-period:2s
fixed-identity-mapping:
operator-api-serve-addr:127.0.0.1:9234
enable-ipv4-big-tcp:false
label-prefix-file:
dns-policy-unload-on-shutdown:false
vtep-mac:
dnsproxy-insecure-skip-transparent-mode-check:false
identity-restore-grace-period:30s
ipv4-native-routing-cidr:
trace-payloadlen:128
bpf-lb-service-backend-map-max:0
monitor-aggregation-flags:all
enable-route-mtu-for-cni-chaining:false
hubble-prefer-ipv6:false
socket-path:/var/run/cilium/cilium.sock
policy-trigger-interval:1s
k8s-require-ipv4-pod-cidr:false
clustermesh-enable-endpoint-sync:false
local-router-ipv4:
mesh-auth-gc-interval:5m0s
http-retry-timeout:0
hubble-export-allowlist:
encrypt-node:false
enable-active-connection-tracking:false
bpf-lb-algorithm:random
identity-allocation-mode:crd
enable-k8s:true
clustermesh-ip-identities-sync-timeout:1m0s
pprof-port:6060
conntrack-gc-interval:0s
ipv4-range:auto
log-opt:
enable-envoy-config:false
enable-node-selector-labels:false
kvstore-max-consecutive-quorum-errors:2
hubble-metrics-server:
nat-map-stats-entries:32
hubble-recorder-sink-queue-size:1024
policy-accounting:true
l2-announcements-renew-deadline:5s
dnsproxy-lock-count:131
ipv4-service-range:auto
envoy-keep-cap-netbindservice:false
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
enable-ipv6-big-tcp:false
enable-host-firewall:false
bpf-lb-service-map-max:0
enable-high-scale-ipcache:false
kvstore-lease-ttl:15m0s
hubble-monitor-events:
ipv6-mcast-device:
ipv6-cluster-alloc-cidr:f00d::/64
set-cilium-is-up-condition:true
enable-endpoint-health-checking:true
enable-ipv6:false
operator-prometheus-serve-addr::9963
ipam:cluster-pool
enable-ipv6-ndp:false
bpf-neigh-global-max:524288
local-router-ipv6:
prepend-iptables-chains:true
agent-health-port:9879
enable-ipv4-fragment-tracking:true
state-dir:/var/run/cilium
certificates-directory:/var/run/cilium/certs
cluster-pool-ipv4-mask-size:24
bpf-ct-timeout-regular-tcp:2h13m20s
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
enable-hubble-recorder-api:true
proxy-connect-timeout:2
enable-endpoint-routes:false
bpf-events-policy-verdict-enabled:true
tofqdns-proxy-response-max-delay:100ms
metrics:
k8s-api-server:
conntrack-gc-max-interval:0s
hubble-export-file-compress:false
hubble-drop-events:false
enable-auto-protect-node-port-range:true
debug:false
hubble-export-file-max-backups:5
enable-recorder:false
node-port-bind-protection:true
enable-svc-source-range-check:true
bpf-filter-priority:1
disable-envoy-version-check:false
enable-monitor:true
dnsproxy-concurrency-limit:0
http-request-timeout:3600
bpf-ct-timeout-service-tcp-grace:1m0s
proxy-portrange-min:10000
node-port-range:
enable-cilium-api-server-access:
multicast-enabled:false
allocator-list-timeout:3m0s
mesh-auth-queue-size:1024
enable-ipv4-egress-gateway:false
proxy-prometheus-port:0
ipam-multi-pool-pre-allocation:
cni-log-file:/var/run/cilium/cilium-cni.log
proxy-max-connection-duration-seconds:0
enable-unreachable-routes:false
exclude-local-address:
agent-labels:
proxy-xff-num-trusted-hops-egress:0
dnsproxy-lock-timeout:500ms
mesh-auth-enabled:true
ipv4-service-loopback-address:169.254.42.1
enable-runtime-device-detection:true
bpf-lb-sock-hostns-only:false
cluster-health-port:4240
dnsproxy-enable-transparent-mode:true
hubble-export-fieldmask:
bpf-ct-timeout-service-tcp:2h13m20s
tofqdns-min-ttl:0
disable-endpoint-crd:false
enable-health-check-nodeport:true
mesh-auth-rotated-identities-queue-size:1024
install-no-conntrack-iptables-rules:false
lib-dir:/var/lib/cilium
node-port-mode:snat
enable-local-redirect-policy:false
trace-sock:true
policy-queue-size:100
debug-verbose:
srv6-encap-mode:reduced
cluster-name:cmesh76
enable-nat46x64-gateway:false
use-full-tls-context:false
hubble-recorder-storage-path:/var/run/cilium/pcaps
enable-bpf-clock-probe:false
k8s-client-qps:10
local-max-addr-scope:252
ipv6-range:auto
ipam-cilium-node-update-rate:15s
gops-port:9890
proxy-xff-num-trusted-hops-ingress:0
envoy-config-timeout:2m0s
direct-routing-skip-unreachable:false
allow-localhost:auto
```


#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 826832                            /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 826832                            /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 826832                            /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400c800000 rw-p 00000000 00:00 0 
400c800000-4010000000 ---p 00000000 00:00 0 
ffff65065000-ffff6522b000 rw-p 00000000 00:00 0 
ffff65233000-ffff65394000 rw-p 00000000 00:00 0 
ffff65394000-ffff653d5000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff653d5000-ffff65416000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff65416000-ffff65418000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff65418000-ffff6541a000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff6541a000-ffff659e1000 rw-p 00000000 00:00 0 
ffff659e1000-ffff65ae1000 rw-p 00000000 00:00 0 
ffff65ae1000-ffff65af2000 rw-p 00000000 00:00 0 
ffff65af2000-ffff67af2000 rw-p 00000000 00:00 0 
ffff67af2000-ffff67b72000 ---p 00000000 00:00 0 
ffff67b72000-ffff67b73000 rw-p 00000000 00:00 0 
ffff67b73000-ffff87b72000 ---p 00000000 00:00 0 
ffff87b72000-ffff87b73000 rw-p 00000000 00:00 0 
ffff87b73000-ffffa7b02000 ---p 00000000 00:00 0 
ffffa7b02000-ffffa7b03000 rw-p 00000000 00:00 0 
ffffa7b03000-ffffabaf4000 ---p 00000000 00:00 0 
ffffabaf4000-ffffabaf5000 rw-p 00000000 00:00 0 
ffffabaf5000-ffffac2f2000 ---p 00000000 00:00 0 
ffffac2f2000-ffffac2f3000 rw-p 00000000 00:00 0 
ffffac2f3000-ffffac3f2000 ---p 00000000 00:00 0 
ffffac3f2000-ffffac452000 rw-p 00000000 00:00 0 
ffffac452000-ffffac454000 r--p 00000000 00:00 0                          [vvar]
ffffac454000-ffffac455000 r-xp 00000000 00:00 0                          [vdso]
fffff85af000-fffff85d0000 rw-p 00000000 00:00 0                          [stack]

```

