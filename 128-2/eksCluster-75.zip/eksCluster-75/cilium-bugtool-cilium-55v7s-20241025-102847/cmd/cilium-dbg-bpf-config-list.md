KEY             VALUE
AgentLiveness   945009648782
UTimeOffset     3378615654296875
