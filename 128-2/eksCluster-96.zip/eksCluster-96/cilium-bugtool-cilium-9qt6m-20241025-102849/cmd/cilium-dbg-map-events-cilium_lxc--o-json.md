{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:02.367Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.129.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:02.367Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.171.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:02.367Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:06.892Z",
  "value": "id=151   sec_id=4     flags=0x0000 ifindex=10  mac=B6:BD:14:C5:C3:76 nodemac=CE:03:61:BA:24:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:06.892Z",
  "value": "id=2978  sec_id=6365046 flags=0x0000 ifindex=12  mac=B6:42:6F:80:8D:75 nodemac=5A:00:92:E1:9E:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:06.935Z",
  "value": "id=2978  sec_id=6365046 flags=0x0000 ifindex=12  mac=B6:42:6F:80:8D:75 nodemac=5A:00:92:E1:9E:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:06.978Z",
  "value": "id=151   sec_id=4     flags=0x0000 ifindex=10  mac=B6:BD:14:C5:C3:76 nodemac=CE:03:61:BA:24:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:12.144Z",
  "value": "id=148   sec_id=6365046 flags=0x0000 ifindex=14  mac=96:14:62:C6:80:65 nodemac=96:6B:F3:E4:B5:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:52.755Z",
  "value": "id=2978  sec_id=6365046 flags=0x0000 ifindex=12  mac=B6:42:6F:80:8D:75 nodemac=5A:00:92:E1:9E:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:52.756Z",
  "value": "id=151   sec_id=4     flags=0x0000 ifindex=10  mac=B6:BD:14:C5:C3:76 nodemac=CE:03:61:BA:24:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:52.756Z",
  "value": "id=148   sec_id=6365046 flags=0x0000 ifindex=14  mac=96:14:62:C6:80:65 nodemac=96:6B:F3:E4:B5:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:52.786Z",
  "value": "id=337   sec_id=6361306 flags=0x0000 ifindex=16  mac=06:74:EA:7F:51:32 nodemac=62:A0:AD:89:D2:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:52.787Z",
  "value": "id=337   sec_id=6361306 flags=0x0000 ifindex=16  mac=06:74:EA:7F:51:32 nodemac=62:A0:AD:89:D2:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:53.754Z",
  "value": "id=337   sec_id=6361306 flags=0x0000 ifindex=16  mac=06:74:EA:7F:51:32 nodemac=62:A0:AD:89:D2:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:53.754Z",
  "value": "id=2978  sec_id=6365046 flags=0x0000 ifindex=12  mac=B6:42:6F:80:8D:75 nodemac=5A:00:92:E1:9E:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:53.754Z",
  "value": "id=151   sec_id=4     flags=0x0000 ifindex=10  mac=B6:BD:14:C5:C3:76 nodemac=CE:03:61:BA:24:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:53.755Z",
  "value": "id=148   sec_id=6365046 flags=0x0000 ifindex=14  mac=96:14:62:C6:80:65 nodemac=96:6B:F3:E4:B5:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:12.276Z",
  "value": "id=1113  sec_id=6361306 flags=0x0000 ifindex=18  mac=DA:F8:57:73:55:0D nodemac=1A:06:51:E8:17:29"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.96.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:22.628Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:26.922Z",
  "value": "id=148   sec_id=6365046 flags=0x0000 ifindex=14  mac=96:14:62:C6:80:65 nodemac=96:6B:F3:E4:B5:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:26.923Z",
  "value": "id=1113  sec_id=6361306 flags=0x0000 ifindex=18  mac=DA:F8:57:73:55:0D nodemac=1A:06:51:E8:17:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:26.923Z",
  "value": "id=151   sec_id=4     flags=0x0000 ifindex=10  mac=B6:BD:14:C5:C3:76 nodemac=CE:03:61:BA:24:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:26.923Z",
  "value": "id=2978  sec_id=6365046 flags=0x0000 ifindex=12  mac=B6:42:6F:80:8D:75 nodemac=5A:00:92:E1:9E:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:27.923Z",
  "value": "id=1113  sec_id=6361306 flags=0x0000 ifindex=18  mac=DA:F8:57:73:55:0D nodemac=1A:06:51:E8:17:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:27.923Z",
  "value": "id=2978  sec_id=6365046 flags=0x0000 ifindex=12  mac=B6:42:6F:80:8D:75 nodemac=5A:00:92:E1:9E:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:27.923Z",
  "value": "id=151   sec_id=4     flags=0x0000 ifindex=10  mac=B6:BD:14:C5:C3:76 nodemac=CE:03:61:BA:24:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:27.923Z",
  "value": "id=148   sec_id=6365046 flags=0x0000 ifindex=14  mac=96:14:62:C6:80:65 nodemac=96:6B:F3:E4:B5:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:28.923Z",
  "value": "id=148   sec_id=6365046 flags=0x0000 ifindex=14  mac=96:14:62:C6:80:65 nodemac=96:6B:F3:E4:B5:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:28.923Z",
  "value": "id=1113  sec_id=6361306 flags=0x0000 ifindex=18  mac=DA:F8:57:73:55:0D nodemac=1A:06:51:E8:17:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:28.924Z",
  "value": "id=2978  sec_id=6365046 flags=0x0000 ifindex=12  mac=B6:42:6F:80:8D:75 nodemac=5A:00:92:E1:9E:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:28.924Z",
  "value": "id=151   sec_id=4     flags=0x0000 ifindex=10  mac=B6:BD:14:C5:C3:76 nodemac=CE:03:61:BA:24:0D"
}

