ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.148.216:443 (active)    
                                          2 => 172.31.210.67:443 (active)     
2    10.100.210.111:443    ClusterIP      1 => 172.31.129.241:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.96.0.200:53 (active)        
                                          2 => 10.96.0.21:53 (active)         
4    10.100.0.10:9153      ClusterIP      1 => 10.96.0.200:9153 (active)      
                                          2 => 10.96.0.21:9153 (active)       
5    10.100.147.123:2379   ClusterIP      1 => 10.96.0.116:2379 (active)      
