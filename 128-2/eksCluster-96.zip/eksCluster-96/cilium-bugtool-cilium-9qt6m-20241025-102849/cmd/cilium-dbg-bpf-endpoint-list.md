IP ADDRESS         LOCAL ENDPOINT INFO
10.96.0.200:0      id=2978  sec_id=6365046 flags=0x0000 ifindex=12  mac=B6:42:6F:80:8D:75 nodemac=5A:00:92:E1:9E:F6   
10.96.0.231:0      id=151   sec_id=4     flags=0x0000 ifindex=10  mac=B6:BD:14:C5:C3:76 nodemac=CE:03:61:BA:24:0D     
172.31.129.241:0   (localhost)                                                                                        
10.96.0.21:0       id=148   sec_id=6365046 flags=0x0000 ifindex=14  mac=96:14:62:C6:80:65 nodemac=96:6B:F3:E4:B5:FC   
10.96.0.197:0      (localhost)                                                                                        
10.96.0.116:0      id=1113  sec_id=6361306 flags=0x0000 ifindex=18  mac=DA:F8:57:73:55:0D nodemac=1A:06:51:E8:17:29   
172.31.171.207:0   (localhost)                                                                                        
