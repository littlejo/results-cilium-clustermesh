Endpoint ID: 148
Path: /sys/fs/bpf/tc/globals/cilium_policy_00148

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    79081   907       0        
Allow    Egress      0          ANY          NONE         disabled    13304   137       0        


Endpoint ID: 151
Path: /sys/fs/bpf/tc/globals/cilium_policy_00151

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    444286   5669      0        
Allow    Ingress     1          ANY          NONE         disabled    12114    141       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 487
Path: /sys/fs/bpf/tc/globals/cilium_policy_00487

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1113
Path: /sys/fs/bpf/tc/globals/cilium_policy_01113

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3828811   36553     0        
Allow    Ingress     1          ANY          NONE         disabled    3650013   37444     0        
Allow    Egress      0          ANY          NONE         disabled    5484578   50598     0        


Endpoint ID: 2978
Path: /sys/fs/bpf/tc/globals/cilium_policy_02978

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    81395   936       0        
Allow    Egress      0          ANY          NONE         disabled    13779   143       0        


