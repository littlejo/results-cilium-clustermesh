key: 94 00 00 00  value: 34 02 00 00
key: 97 00 00 00  value: 08 02 00 00
key: 59 04 00 00  value: 6d 02 00 00
key: a2 0b 00 00  value: 01 02 00 00
Found 4 elements
