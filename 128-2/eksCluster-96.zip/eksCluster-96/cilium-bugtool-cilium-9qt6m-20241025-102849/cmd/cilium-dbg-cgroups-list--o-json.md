[
  {
    "containers": [
      {
        "cgroup-id": 7530,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1245289e_c989_4b63_98f9_79152aedbab3.slice/cri-containerd-5b072c6e69dfc8dd94bf231b1e7f4d8047688cf58f765dc1910412d80e9b6b2f.scope"
      }
    ],
    "ips": [
      "10.96.0.200"
    ],
    "name": "coredns-cc6ccd49c-4dz52",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod58291118_b1db_4965_938d_c27ea8bf2664.slice/cri-containerd-d8fb8a532ce9f7c0cc4b5429f8c6c263388b5a5fd4f32deebee2066fd9c037db.scope"
      }
    ],
    "ips": [
      "10.96.0.21"
    ],
    "name": "coredns-cc6ccd49c-j8cgw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab6702c7_99cb_482c_8220_dce98fdba24c.slice/cri-containerd-0b4d03ecace0eff46f30aeeef234e0f7b5460f029a878bd441f2230325dc877b.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab6702c7_99cb_482c_8220_dce98fdba24c.slice/cri-containerd-e65035651dc3a5aca761e12bd316df72cd6cb980383b4a7b39943ec01613ed12.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab6702c7_99cb_482c_8220_dce98fdba24c.slice/cri-containerd-e6a9dc5ae8452200fa71d153149b59b10afa386e7f09ae6f53b95e7ec1855276.scope"
      }
    ],
    "ips": [
      "10.96.0.116"
    ],
    "name": "clustermesh-apiserver-77669b494c-4r5xr",
    "namespace": "kube-system"
  }
]

