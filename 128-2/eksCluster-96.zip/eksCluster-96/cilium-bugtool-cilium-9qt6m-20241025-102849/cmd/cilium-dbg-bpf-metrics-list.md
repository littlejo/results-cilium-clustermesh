REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10810     849890     677    bpf_overlay.c
Interface                 INGRESS     232412    86839660   1132   bpf_host.c
Success                   EGRESS      100426    13019119   1308   bpf_lxc.c
Success                   EGRESS      11365     890126     53     encap.h
Success                   EGRESS      5804      450528     1694   bpf_host.c
Success                   INGRESS     111856    13748748   86     l3.h
Success                   INGRESS     117511    14192016   235    trace.h
Unsupported L3 protocol   EGRESS      40        3008       1492   bpf_lxc.c
