1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:44:aa:f8:08:67 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.129.241/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2719sec preferred_lft 2719sec
    inet6 fe80::444:aaff:fef8:867/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:85:db:8c:f5:b9 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.171.207/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::485:dbff:fe8c:f5b9/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:e4:b5:30:7e:9d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::58e4:b5ff:fe30:7e9d/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:b6:f7:3d:7d:0c brd ff:ff:ff:ff:ff:ff
    inet 10.96.0.197/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::98b6:f7ff:fe3d:7d0c/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 1e:ea:b8:1a:c9:1e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1cea:b8ff:fe1a:c91e/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:03:61:ba:24:0d brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::cc03:61ff:feba:240d/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc7d772e7b440f@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:00:92:e1:9e:f6 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::5800:92ff:fee1:9ef6/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc8841d6500bce@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:6b:f3:e4:b5:fc brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::946b:f3ff:fee4:b5fc/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcc0e0ddca01f7@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:06:51:e8:17:29 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::1806:51ff:fee8:1729/64 scope link 
       valid_lft forever preferred_lft forever
