KEY             VALUE
AgentLiveness   926930976920
UTimeOffset     3378615693359375
