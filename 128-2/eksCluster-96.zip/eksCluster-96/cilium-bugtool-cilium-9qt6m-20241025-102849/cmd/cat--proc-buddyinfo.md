Node 0, zone      DMA     85     19      4      1      2      0      2      1      3      5    165 
Node 0, zone   Normal    188      2      8      2      4     11      7     13      3      2      6 
