CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1245289e_c989_4b63_98f9_79152aedbab3.slice/cri-containerd-22fd745279bcc9dfea2f037dd8a4d3f5fb94e19de4579120b8c235c65403384b.scope
    529      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1245289e_c989_4b63_98f9_79152aedbab3.slice/cri-containerd-5b072c6e69dfc8dd94bf231b1e7f4d8047688cf58f765dc1910412d80e9b6b2f.scope
    533      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4273056d_c69b_409c_8f54_1fb39b17f8b8.slice/cri-containerd-1474502a9721778e81dfb54aeb1f300b36711a0b61d1bf4fff95db4e24026c71.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4273056d_c69b_409c_8f54_1fb39b17f8b8.slice/cri-containerd-94d0bf2a6c74bfd0dae0225ea16db2f8921aa4831a82bd5d824a12b1d5c7dae4.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod58291118_b1db_4965_938d_c27ea8bf2664.slice/cri-containerd-d8fb8a532ce9f7c0cc4b5429f8c6c263388b5a5fd4f32deebee2066fd9c037db.scope
    580      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod58291118_b1db_4965_938d_c27ea8bf2664.slice/cri-containerd-3372965324ded413884fe7f882a6fe26831ed35074a6dad0700223d8f40c138e.scope
    576      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod352db2f6_d687_4401_b634_82c1afabbba0.slice/cri-containerd-631afc91bdb14761c8e6c40ac8fcd3a50721434c5e85628043dc2e887656d87f.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod352db2f6_d687_4401_b634_82c1afabbba0.slice/cri-containerd-c1f519e2d07c642de215244f672ff7e3a0afc6900f019f0690ce64c8d3e65a3b.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4280129a_b318_4bc1_a356_09e68c7f6ae0.slice/cri-containerd-e28a1ddfcf9eda6e7c1d1484c4bf8e9e989d07f18b3b4f9a12e072f558b04cc3.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4280129a_b318_4bc1_a356_09e68c7f6ae0.slice/cri-containerd-82898d7338a96ef1dff888aabad8d2aef126f1b6f24fb0673fe3a8b4802de1a6.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf32a3fc1_ba5c_477b_ae97_030813a02d5d.slice/cri-containerd-bc3c8d2772b4bd8138065b81b3b2b7288a403b0eb36c00890365b4af99de2c0f.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf32a3fc1_ba5c_477b_ae97_030813a02d5d.slice/cri-containerd-912f5b72abe69ee796426a8c0b2e8df35b0a069b11d9982a3a1c5b5766ccea2c.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab6702c7_99cb_482c_8220_dce98fdba24c.slice/cri-containerd-2e13c0aac911e2a7a83e84380241357548d7e8240513e205f08759c4d7115092.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab6702c7_99cb_482c_8220_dce98fdba24c.slice/cri-containerd-0b4d03ecace0eff46f30aeeef234e0f7b5460f029a878bd441f2230325dc877b.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab6702c7_99cb_482c_8220_dce98fdba24c.slice/cri-containerd-e6a9dc5ae8452200fa71d153149b59b10afa386e7f09ae6f53b95e7ec1855276.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab6702c7_99cb_482c_8220_dce98fdba24c.slice/cri-containerd-e65035651dc3a5aca761e12bd316df72cd6cb980383b4a7b39943ec01613ed12.scope
    650      cgroup_device   multi                                          
