top - 10:28:51 up 14 min,  0 users,  load average: 0.16, 0.22, 0.18
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 38.7 us, 32.3 sy,  0.0 ni, 29.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    786.4 free,    906.2 used,   2143.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2761.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538420 284364  78652 S  12.5   7.2   0:25.77 cilium-+
    413 root      20   0 1228848   5348   2928 S   0.0   0.1   0:00.27 cilium-+
    646 root      20   0 1240432  16284  11292 S   0.0   0.4   0:00.03 cilium-+
    678 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
    685 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    711 root      20   0    6576   2416   2092 R   0.0   0.1   0:00.00 top
    731 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
