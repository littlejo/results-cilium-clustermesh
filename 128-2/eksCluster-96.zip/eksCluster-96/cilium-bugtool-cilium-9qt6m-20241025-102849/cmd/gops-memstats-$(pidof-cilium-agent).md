alloc: 89.86MB (94222592 bytes)
total-alloc: 1.39GB (1497518576 bytes)
sys: 210.70MB (220931412 bytes)
lookups: 0
mallocs: 48812522
frees: 48046865
heap-alloc: 89.86MB (94222592 bytes)
heap-sys: 165.33MB (173359104 bytes)
heap-idle: 44.34MB (46489600 bytes)
heap-in-use: 120.99MB (126869504 bytes)
heap-released: 3.00MB (3145728 bytes)
heap-objects: 765657
stack-in-use: 34.62MB (36306944 bytes)
stack-sys: 34.62MB (36306944 bytes)
stack-mspan-inuse: 1.99MB (2083040 bytes)
stack-mspan-sys: 2.57MB (2692800 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.05MB (1096289 bytes)
gc-sys: 5.21MB (5468296 bytes)
next-gc: when heap-alloc >= 148.53MB (155748840 bytes)
last-gc: 2024-10-25 10:29:04.929027132 +0000 UTC
gc-pause-total: 5.950347ms
gc-pause: 189171
gc-pause-end: 1729852144929027132
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.0003472490196409721
enable-gc: true
debug-gc: false
