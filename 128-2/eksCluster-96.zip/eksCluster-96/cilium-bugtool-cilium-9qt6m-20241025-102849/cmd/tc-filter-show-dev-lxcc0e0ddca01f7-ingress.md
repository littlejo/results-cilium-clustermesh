filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcc0e0ddca01f7 direct-action not_in_hw id 629 tag 63e246bd2085171e jited 
