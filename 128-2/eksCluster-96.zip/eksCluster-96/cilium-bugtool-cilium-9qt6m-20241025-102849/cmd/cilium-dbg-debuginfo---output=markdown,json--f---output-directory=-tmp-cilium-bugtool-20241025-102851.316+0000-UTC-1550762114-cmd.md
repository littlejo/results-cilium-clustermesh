markdown output at /tmp/cilium-bugtool-20241025-102851.316+0000-UTC-1550762114/cmd/cilium-debuginfo-20241025-102922.076+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102851.316+0000-UTC-1550762114/cmd/cilium-debuginfo-20241025-102922.076+0000-UTC.json
