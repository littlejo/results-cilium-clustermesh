CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6fe21e9_d313_49e6_8918_2a9189d33cdc.slice/cri-containerd-fcdebfc52323308d892df1c529471839dfab118a533afb36f91315c2cd942d25.scope
    553      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6fe21e9_d313_49e6_8918_2a9189d33cdc.slice/cri-containerd-bc9d25beded9b78720acdaf0b4d93075120fb2bec75fa6f8fbe2fe546bf7a8d0.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd5964421_890d_4b99_afa5_c9abbf73f9b4.slice/cri-containerd-608418ff142cf42a6a9fe05626168df1d35a84c92de1b6203a6c458c8be44df3.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd5964421_890d_4b99_afa5_c9abbf73f9b4.slice/cri-containerd-a0866256276e3fcb0872853864ad32c1e4f39b1c356529e5b2ca04681f58746b.scope
    509      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod51b10cff_bff1_44fa_8c7b_65f72572bace.slice/cri-containerd-92a13e047853c1f5017b313934af8335e43e2e4da5e089c142b583d6f002cff2.scope
    78       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod51b10cff_bff1_44fa_8c7b_65f72572bace.slice/cri-containerd-c9cb3bff72843018cd1f37ced3abef1bcd627fc6f9edf30fae9cee0f2cc2b92e.scope
    117      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod74da2026_66b8_4094_a30c_04c47973bf6d.slice/cri-containerd-7c95bdd6ec80a2f16a81c05d8f57687a706922da0232d5956b08885e83577466.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod74da2026_66b8_4094_a30c_04c47973bf6d.slice/cri-containerd-bf5bf731f79ba179b4d801a035bb23e1fdfe660ed8f09c9f820fa859d3356d27.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod72bb0021_809b_4858_a2cb_80446e5b74e1.slice/cri-containerd-df2019ef351ade66c48a046b1f0e79d14c8555033f27dcd7fc1d116af30e003d.scope
    631      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod72bb0021_809b_4858_a2cb_80446e5b74e1.slice/cri-containerd-54d8d76a1c95e201bc5acd9982a90da7e9dda3b3b7fef044c019857188c20445.scope
    607      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod72bb0021_809b_4858_a2cb_80446e5b74e1.slice/cri-containerd-5966134f807e23457f0cc90575ce8451d40d7df597e38d7ba2afa989150f72e7.scope
    627      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod72bb0021_809b_4858_a2cb_80446e5b74e1.slice/cri-containerd-973ffd924284aee9fd5d9d020a0fa652ff26e9559da525e026dfe4db815f1fd5.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc27ecadc_d658_4fe9_ac95_f1207ea3aa42.slice/cri-containerd-471014b0c2a0c377621a5765b731f6e9ca19bde7826abf0e4b3540d440b1b484.scope
    82       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc27ecadc_d658_4fe9_ac95_f1207ea3aa42.slice/cri-containerd-3af16e24f98caf474b6b4c67f63f5df941903200bdbe0a81254a23685bd0d498.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod854dda86_b24a_4829_a621_e8f2ce1981b6.slice/cri-containerd-fdf7affab7bb30a37a9045a808dfe11eed1e57a2eb6edaeaa2330414bcbcb7c3.scope
    74       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod854dda86_b24a_4829_a621_e8f2ce1981b6.slice/cri-containerd-3e901862f824f768eacf40f8698492eba986f5d71eed8865cb9a194811c325b0.scope
    86       cgroup_device   multi                                          
