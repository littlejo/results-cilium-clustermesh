32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:25+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:29+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:40+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
71: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
74: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
75: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
78: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
79: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
82: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
83: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
86: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
114: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
117: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
458: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 114
459: sched_cls  name tail_handle_ipv4  tag 3df6b68526b54402  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 71,70,77,72,93
	btf_id 115
460: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 116
461: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 72,93
	btf_id 117
485: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,101
	btf_id 145
486: sched_cls  name tail_handle_arp  tag 97f993b4cc6eb79a  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,101
	btf_id 146
487: sched_cls  name tail_handle_ipv4  tag 5309c68bb2ec7c00  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,101
	btf_id 147
488: sched_cls  name cil_from_container  tag 4a62015e82ad50eb  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 101,72
	btf_id 148
489: sched_cls  name __send_drop_notify  tag 4e1d085f2902a03e  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 149
490: sched_cls  name tail_ipv4_ct_egress  tag 6367f16cb2e1d019  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,101,78,79,100,80
	btf_id 150
491: sched_cls  name tail_ipv4_ct_ingress  tag 8b1add98c3499cfb  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,101,78,79,100,80
	btf_id 151
492: sched_cls  name handle_policy  tag 035ff24ed66c84d1  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,101,78,79,100,37,76,94,35,80,71,36,33,34
	btf_id 152
493: sched_cls  name tail_handle_ipv4_cont  tag 47ab0780efdee15a  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,100,37,94,78,79,35,72,70,73,101,36,33,34,77
	btf_id 153
494: sched_cls  name tail_ipv4_to_endpoint  tag c5a3a255cf41dbb2  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,100,37,78,79,76,94,35,101,36,33,34
	btf_id 154
496: sched_cls  name __send_drop_notify  tag ad0f2f2d2f9dd837  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 157
497: sched_cls  name tail_handle_ipv4_cont  tag 4bb4b55a66adb954  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 71,102,37,95,78,79,35,72,70,73,103,36,33,34,77
	btf_id 158
498: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 72,103,78,79,102,80
	btf_id 159
499: sched_cls  name tail_handle_ipv4  tag 5809a1b0dee0cf21  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,103
	btf_id 160
500: sched_cls  name cil_from_container  tag a4b4da213b8a82ff  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 103,72
	btf_id 161
501: sched_cls  name tail_handle_arp  tag e57915767115fe07  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,103
	btf_id 162
502: sched_cls  name handle_policy  tag cd1285813bc81747  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 72,103,78,79,102,37,76,95,35,80,71,36,33,34
	btf_id 163
503: sched_cls  name tail_ipv4_to_endpoint  tag b0124b7d5ccfbc8d  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 71,72,102,37,78,79,76,95,35,103,36,33,34
	btf_id 164
504: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,103
	btf_id 165
505: sched_cls  name tail_ipv4_ct_ingress  tag 62f4707968d6a521  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 72,103,78,79,102,80
	btf_id 166
506: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
509: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
511: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 169
512: sched_cls  name tail_handle_ipv4_from_host  tag 6147f695c6d38631  gpl
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,106
	btf_id 170
513: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 72,71,106
	btf_id 171
514: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,106
	btf_id 172
515: sched_cls  name __send_drop_notify  tag c9aa438b7d949bfe  gpl
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 173
517: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,108
	btf_id 176
518: sched_cls  name __send_drop_notify  tag c9aa438b7d949bfe  gpl
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 177
521: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 180
522: sched_cls  name tail_handle_ipv4_from_host  tag 6147f695c6d38631  gpl
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,108
	btf_id 181
524: sched_cls  name tail_handle_ipv4_from_host  tag 6147f695c6d38631  gpl
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,110
	btf_id 184
526: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,110
	btf_id 186
527: sched_cls  name __send_drop_notify  tag c9aa438b7d949bfe  gpl
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 187
528: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 72,110,71
	btf_id 188
531: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
534: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
535: sched_cls  name tail_handle_arp  tag 77e138689dddfdea  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,114
	btf_id 193
536: sched_cls  name handle_policy  tag 7664f3e19a8c45b9  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,114,78,79,113,37,76,112,35,80,71,36,33,34
	btf_id 194
537: sched_cls  name cil_from_container  tag adbab112e1e2df93  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 114,72
	btf_id 195
539: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,114
	btf_id 197
540: sched_cls  name tail_handle_ipv4_cont  tag 685d62fa3479ba22  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,113,37,112,78,79,35,72,70,73,114,36,33,34,77
	btf_id 198
541: sched_cls  name tail_handle_ipv4  tag 6b86e650ceb4487b  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,114
	btf_id 199
542: sched_cls  name __send_drop_notify  tag 9c4a16bcaa7b7558  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 200
543: sched_cls  name tail_ipv4_ct_egress  tag 6367f16cb2e1d019  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,114,78,79,113,80
	btf_id 201
544: sched_cls  name tail_ipv4_ct_ingress  tag f752bd3c3512eee3  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,114,78,79,113,80
	btf_id 202
545: sched_cls  name tail_ipv4_to_endpoint  tag 52cae4d23d1ca14a  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,113,37,78,79,76,112,35,114,36,33,34
	btf_id 203
546: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
549: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
550: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
553: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
593: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,129
	btf_id 217
594: sched_cls  name tail_handle_ipv4  tag 62ce34a85bea1339  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,129
	btf_id 218
595: sched_cls  name tail_ipv4_ct_ingress  tag 897adbed32f38be7  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,129,78,79,128,80
	btf_id 219
596: sched_cls  name tail_ipv4_ct_egress  tag 7afba2e38c18ca52  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,129,78,79,128,80
	btf_id 220
597: sched_cls  name tail_handle_arp  tag a145953fcbd73793  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,129
	btf_id 221
598: sched_cls  name __send_drop_notify  tag 8444817b41dec7eb  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 222
599: sched_cls  name tail_handle_ipv4_cont  tag 531ab14a24d49633  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,128,37,127,78,79,35,72,70,73,129,36,33,34,77
	btf_id 223
600: sched_cls  name cil_from_container  tag 376b6ca68df3d254  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 129,72
	btf_id 224
601: sched_cls  name handle_policy  tag c4c209e808dbbf96  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,129,78,79,128,37,76,127,35,80,71,36,33,34
	btf_id 225
603: sched_cls  name tail_ipv4_to_endpoint  tag 46cefaa915a60109  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,128,37,78,79,76,127,35,129,36,33,34
	btf_id 227
604: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
607: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
620: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
623: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
624: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
627: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
628: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
631: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
