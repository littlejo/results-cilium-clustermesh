REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     214420    99634104   1132   bpf_host.c
Interface                 INGRESS     9369      733813     677    bpf_overlay.c
Success                   EGRESS      4585      350043     1694   bpf_host.c
Success                   EGRESS      88839     12027796   1308   bpf_lxc.c
Success                   EGRESS      9177      720104     53     encap.h
Success                   INGRESS     104797    12548548   235    trace.h
Success                   INGRESS     99364     12120872   86     l3.h
Unsupported L3 protocol   EGRESS      41        3098       1492   bpf_lxc.c
