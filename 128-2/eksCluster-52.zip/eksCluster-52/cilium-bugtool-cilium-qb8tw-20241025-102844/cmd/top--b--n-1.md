top - 10:28:46 up 15 min,  0 users,  load average: 0.44, 0.29, 0.18
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 14.3 us, 14.3 sy,  0.0 ni, 71.4 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    801.4 free,    893.5 used,   2141.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2774.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 279592  77948 S   6.7   7.1   0:23.30 cilium-+
    402 root      20   0 1228848   5784   2924 S   0.0   0.1   0:00.27 cilium-+
    630 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    634 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    643 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    661 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    673 root      20   0 1240432  16048  11292 S   0.0   0.4   0:00.02 cilium-+
    713 root      20   0    6576   2432   2104 R   0.0   0.1   0:00.00 top
    731 root      20   0 1228744   3716   3040 S   0.0   0.1   0:00.00 gops
