key: dd 02 00 00  value: 59 02 00 00
key: 1f 03 00 00  value: 18 02 00 00
key: 47 04 00 00  value: ec 01 00 00
key: 3a 07 00 00  value: f6 01 00 00
Found 4 elements
