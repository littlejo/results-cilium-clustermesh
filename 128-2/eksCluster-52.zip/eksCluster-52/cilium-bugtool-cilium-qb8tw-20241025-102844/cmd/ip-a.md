1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:c8:09:4e:95:67 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.143.87/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2686sec preferred_lft 2686sec
    inet6 fe80::4c8:9ff:fe4e:9567/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:4e:b7:24:95:0b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::504e:b7ff:fe24:950b/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:cf:b7:55:8a:c1 brd ff:ff:ff:ff:ff:ff
    inet 10.52.0.154/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::10cf:b7ff:fe55:8ac1/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 76:9b:35:fa:fa:7d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::749b:35ff:fefa:fa7d/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:c9:10:ac:09:cb brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::2cc9:10ff:feac:9cb/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc97d17a66691f@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:f5:41:97:59:9c brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::8f5:41ff:fe97:599c/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc2ab7e1fa435a@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:c3:b2:fc:99:1c brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::7cc3:b2ff:fefc:991c/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc7997f1162f30@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:5e:c3:e6:5a:79 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::605e:c3ff:fee6:5a79/64 scope link 
       valid_lft forever preferred_lft forever
