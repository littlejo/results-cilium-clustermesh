IP ADDRESS        LOCAL ENDPOINT INFO
10.52.0.125:0     id=733   sec_id=3489880 flags=0x0000 ifindex=15  mac=C6:DC:CA:D5:9A:41 nodemac=62:5E:C3:E6:5A:79   
10.52.0.161:0     id=1850  sec_id=4     flags=0x0000 ifindex=7   mac=E2:33:AF:3B:6A:8D nodemac=2E:C9:10:AC:09:CB     
172.31.143.87:0   (localhost)                                                                                        
10.52.0.13:0      id=799   sec_id=3538278 flags=0x0000 ifindex=11  mac=52:74:C1:65:1E:1E nodemac=7E:C3:B2:FC:99:1C   
10.52.0.130:0     id=1095  sec_id=3538278 flags=0x0000 ifindex=9   mac=5E:E4:DC:E7:DE:57 nodemac=0A:F5:41:97:59:9C   
10.52.0.154:0     (localhost)                                                                                        
