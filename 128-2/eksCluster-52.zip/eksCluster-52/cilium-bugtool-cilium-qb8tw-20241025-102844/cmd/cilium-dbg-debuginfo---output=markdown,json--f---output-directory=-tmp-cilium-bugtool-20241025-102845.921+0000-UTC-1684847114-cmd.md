markdown output at /tmp/cilium-bugtool-20241025-102845.921+0000-UTC-1684847114/cmd/cilium-debuginfo-20241025-102916.777+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102845.921+0000-UTC-1684847114/cmd/cilium-debuginfo-20241025-102916.777+0000-UTC.json
