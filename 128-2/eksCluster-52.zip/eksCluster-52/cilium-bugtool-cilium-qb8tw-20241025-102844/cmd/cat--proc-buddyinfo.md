Node 0, zone      DMA     54     73      8      1      2      3      6      4      1      6    166 
Node 0, zone   Normal    701    115     60     35     52     20     10      0      2      1      6 
