[
  {
    "containers": [
      {
        "cgroup-id": 8711,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod72bb0021_809b_4858_a2cb_80446e5b74e1.slice/cri-containerd-5966134f807e23457f0cc90575ce8451d40d7df597e38d7ba2afa989150f72e7.scope"
      },
      {
        "cgroup-id": 8627,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod72bb0021_809b_4858_a2cb_80446e5b74e1.slice/cri-containerd-973ffd924284aee9fd5d9d020a0fa652ff26e9559da525e026dfe4db815f1fd5.scope"
      },
      {
        "cgroup-id": 8795,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod72bb0021_809b_4858_a2cb_80446e5b74e1.slice/cri-containerd-df2019ef351ade66c48a046b1f0e79d14c8555033f27dcd7fc1d116af30e003d.scope"
      }
    ],
    "ips": [
      "10.52.0.125"
    ],
    "name": "clustermesh-apiserver-7c7d7cb89f-4rjjm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7115,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd5964421_890d_4b99_afa5_c9abbf73f9b4.slice/cri-containerd-608418ff142cf42a6a9fe05626168df1d35a84c92de1b6203a6c458c8be44df3.scope"
      }
    ],
    "ips": [
      "10.52.0.130"
    ],
    "name": "coredns-cc6ccd49c-9ptpr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7283,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6fe21e9_d313_49e6_8918_2a9189d33cdc.slice/cri-containerd-fcdebfc52323308d892df1c529471839dfab118a533afb36f91315c2cd942d25.scope"
      }
    ],
    "ips": [
      "10.52.0.13"
    ],
    "name": "coredns-cc6ccd49c-8lp5m",
    "namespace": "kube-system"
  }
]

