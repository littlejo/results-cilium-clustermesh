alloc: 133.41MB (139892728 bytes)
total-alloc: 1.32GB (1419560936 bytes)
sys: 214.38MB (224798036 bytes)
lookups: 0
mallocs: 47571295
frees: 46204628
heap-alloc: 133.41MB (139892728 bytes)
heap-sys: 167.23MB (175357952 bytes)
heap-idle: 14.95MB (15679488 bytes)
heap-in-use: 152.28MB (159678464 bytes)
heap-released: 2.42MB (2539520 bytes)
heap-objects: 1366667
stack-in-use: 36.47MB (38240256 bytes)
stack-sys: 36.47MB (38240256 bytes)
stack-mspan-inuse: 2.37MB (2480000 bytes)
stack-mspan-sys: 2.51MB (2627520 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 866.45KB (887249 bytes)
gc-sys: 5.43MB (5695864 bytes)
next-gc: when heap-alloc >= 144.98MB (152027528 bytes)
last-gc: 2024-10-25 10:28:33.034754283 +0000 UTC
gc-pause-total: 13.846379ms
gc-pause: 81159
gc-pause-end: 1729852113034754283
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00034885146664609444
enable-gc: true
debug-gc: false
