xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 528
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 521
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 511
cilium_host(4) clsact/egress cil_from_host-cilium_host id 513
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 461
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 460
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 500
lxc97d17a66691f(9) clsact/ingress cil_from_container-lxc97d17a66691f id 488
lxc2ab7e1fa435a(11) clsact/ingress cil_from_container-lxc2ab7e1fa435a id 537
lxc7997f1162f30(15) clsact/ingress cil_from_container-lxc7997f1162f30 id 600

flow_dissector:

netfilter:

