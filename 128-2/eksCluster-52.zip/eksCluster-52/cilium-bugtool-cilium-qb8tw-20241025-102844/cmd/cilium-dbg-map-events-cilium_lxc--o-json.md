{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:13.619Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.143.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:13.619Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:18.191Z",
  "value": "id=1095  sec_id=3538278 flags=0x0000 ifindex=9   mac=5E:E4:DC:E7:DE:57 nodemac=0A:F5:41:97:59:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:18.199Z",
  "value": "id=1850  sec_id=4     flags=0x0000 ifindex=7   mac=E2:33:AF:3B:6A:8D nodemac=2E:C9:10:AC:09:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:18.239Z",
  "value": "id=1095  sec_id=3538278 flags=0x0000 ifindex=9   mac=5E:E4:DC:E7:DE:57 nodemac=0A:F5:41:97:59:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:18.292Z",
  "value": "id=1850  sec_id=4     flags=0x0000 ifindex=7   mac=E2:33:AF:3B:6A:8D nodemac=2E:C9:10:AC:09:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:21.882Z",
  "value": "id=799   sec_id=3538278 flags=0x0000 ifindex=11  mac=52:74:C1:65:1E:1E nodemac=7E:C3:B2:FC:99:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:55.597Z",
  "value": "id=1850  sec_id=4     flags=0x0000 ifindex=7   mac=E2:33:AF:3B:6A:8D nodemac=2E:C9:10:AC:09:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:55.597Z",
  "value": "id=1095  sec_id=3538278 flags=0x0000 ifindex=9   mac=5E:E4:DC:E7:DE:57 nodemac=0A:F5:41:97:59:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:55.598Z",
  "value": "id=799   sec_id=3538278 flags=0x0000 ifindex=11  mac=52:74:C1:65:1E:1E nodemac=7E:C3:B2:FC:99:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:55.641Z",
  "value": "id=734   sec_id=3489880 flags=0x0000 ifindex=13  mac=76:25:87:78:BA:41 nodemac=66:E3:BF:EB:C0:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:56.597Z",
  "value": "id=1095  sec_id=3538278 flags=0x0000 ifindex=9   mac=5E:E4:DC:E7:DE:57 nodemac=0A:F5:41:97:59:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:56.598Z",
  "value": "id=1850  sec_id=4     flags=0x0000 ifindex=7   mac=E2:33:AF:3B:6A:8D nodemac=2E:C9:10:AC:09:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:56.598Z",
  "value": "id=799   sec_id=3538278 flags=0x0000 ifindex=11  mac=52:74:C1:65:1E:1E nodemac=7E:C3:B2:FC:99:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:56.598Z",
  "value": "id=734   sec_id=3489880 flags=0x0000 ifindex=13  mac=76:25:87:78:BA:41 nodemac=66:E3:BF:EB:C0:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:46.157Z",
  "value": "id=733   sec_id=3489880 flags=0x0000 ifindex=15  mac=C6:DC:CA:D5:9A:41 nodemac=62:5E:C3:E6:5A:79"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.52.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:51.424Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:24.148Z",
  "value": "id=733   sec_id=3489880 flags=0x0000 ifindex=15  mac=C6:DC:CA:D5:9A:41 nodemac=62:5E:C3:E6:5A:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:24.148Z",
  "value": "id=799   sec_id=3538278 flags=0x0000 ifindex=11  mac=52:74:C1:65:1E:1E nodemac=7E:C3:B2:FC:99:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:24.149Z",
  "value": "id=1850  sec_id=4     flags=0x0000 ifindex=7   mac=E2:33:AF:3B:6A:8D nodemac=2E:C9:10:AC:09:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:24.150Z",
  "value": "id=1095  sec_id=3538278 flags=0x0000 ifindex=9   mac=5E:E4:DC:E7:DE:57 nodemac=0A:F5:41:97:59:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:25.146Z",
  "value": "id=733   sec_id=3489880 flags=0x0000 ifindex=15  mac=C6:DC:CA:D5:9A:41 nodemac=62:5E:C3:E6:5A:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:25.146Z",
  "value": "id=1850  sec_id=4     flags=0x0000 ifindex=7   mac=E2:33:AF:3B:6A:8D nodemac=2E:C9:10:AC:09:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:25.146Z",
  "value": "id=1095  sec_id=3538278 flags=0x0000 ifindex=9   mac=5E:E4:DC:E7:DE:57 nodemac=0A:F5:41:97:59:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:25.147Z",
  "value": "id=799   sec_id=3538278 flags=0x0000 ifindex=11  mac=52:74:C1:65:1E:1E nodemac=7E:C3:B2:FC:99:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:26.146Z",
  "value": "id=1095  sec_id=3538278 flags=0x0000 ifindex=9   mac=5E:E4:DC:E7:DE:57 nodemac=0A:F5:41:97:59:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:26.146Z",
  "value": "id=799   sec_id=3538278 flags=0x0000 ifindex=11  mac=52:74:C1:65:1E:1E nodemac=7E:C3:B2:FC:99:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:26.146Z",
  "value": "id=733   sec_id=3489880 flags=0x0000 ifindex=15  mac=C6:DC:CA:D5:9A:41 nodemac=62:5E:C3:E6:5A:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:26.147Z",
  "value": "id=1850  sec_id=4     flags=0x0000 ifindex=7   mac=E2:33:AF:3B:6A:8D nodemac=2E:C9:10:AC:09:CB"
}

