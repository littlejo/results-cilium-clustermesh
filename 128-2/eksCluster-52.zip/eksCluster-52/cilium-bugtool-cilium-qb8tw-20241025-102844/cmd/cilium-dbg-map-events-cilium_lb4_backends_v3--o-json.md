{
  "action": "update",
  "desired-action": "sync",
  "key": "1",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:11.407Z",
  "value": "ANY://172.31.166.1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "2",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:14.191Z",
  "value": "ANY://172.31.143.87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:16.938Z",
  "value": "ANY://172.31.203.102"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:20.931Z",
  "value": "ANY://10.52.0.130"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "5",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:20.931Z",
  "value": "ANY://10.52.0.130"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "6",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:22.956Z",
  "value": "ANY://10.52.0.13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "7",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:22.956Z",
  "value": "ANY://10.52.0.13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:04.090Z",
  "value": "ANY://10.52.0.140"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "9",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:50.967Z",
  "value": "ANY://10.52.0.125"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:51.089Z",
  "value": "ANY://10.52.0.140"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:51.535Z",
  "value": "\u003cnil\u003e"
}

