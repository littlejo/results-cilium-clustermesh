Endpoint ID: 102
Path: /sys/fs/bpf/tc/globals/cilium_policy_00102

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 733
Path: /sys/fs/bpf/tc/globals/cilium_policy_00733

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3906358   36213     0        
Allow    Ingress     1          ANY          NONE         disabled    2847673   28476     0        
Allow    Egress      0          ANY          NONE         disabled    3974608   37067     0        


Endpoint ID: 799
Path: /sys/fs/bpf/tc/globals/cilium_policy_00799

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    82719   948       0        
Allow    Egress      0          ANY          NONE         disabled    13552   141       0        


Endpoint ID: 1095
Path: /sys/fs/bpf/tc/globals/cilium_policy_01095

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    86427   998       0        
Allow    Egress      0          ANY          NONE         disabled    14352   151       0        


Endpoint ID: 1850
Path: /sys/fs/bpf/tc/globals/cilium_policy_01850

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    428446   5443      0        
Allow    Ingress     1          ANY          NONE         disabled    12830    149       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


