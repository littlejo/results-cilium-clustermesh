KEY             VALUE
AgentLiveness   954179639928
UTimeOffset     3378615628906250
