key: 9c 01 00 00  value: 44 02 00 00
key: a4 02 00 00  value: d8 01 00 00
key: 08 05 00 00  value: e7 01 00 00
key: 73 0a 00 00  value: fa 01 00 00
Found 4 elements
