 10:28:42 up 15 min,  0 users,  load average: 0.14, 0.14, 0.13
