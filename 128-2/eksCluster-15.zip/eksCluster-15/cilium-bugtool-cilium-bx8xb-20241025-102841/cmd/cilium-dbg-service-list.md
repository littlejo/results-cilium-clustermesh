ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.154.14:443 (active)    
                                         2 => 172.31.238.122:443 (active)   
2    10.100.156.72:443    ClusterIP      1 => 172.31.234.25:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.15.0.60:53 (active)        
                                         2 => 10.15.0.122:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.15.0.60:9153 (active)      
                                         2 => 10.15.0.122:9153 (active)     
5    10.100.74.115:2379   ClusterIP      1 => 10.15.0.78:2379 (active)      
