32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:51+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:51+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:51+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:51+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:51+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:12:51+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:12:52+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:12:52+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:52+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:52+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:12:52+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:52+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:12:56+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
58: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
61: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
62: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
65: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
68: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
69: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
72: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
73: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
76: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
444: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:36+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 112
445: sched_cls  name tail_handle_ipv4  tag a8488fc2fb3db488  gpl
	loaded_at 2024-10-25T10:13:36+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 113
446: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:36+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 114
447: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:36+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 115
470: sched_cls  name tail_handle_ipv4  tag 0e6b3fe334b86f9a  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,98
	btf_id 141
471: sched_cls  name tail_ipv4_ct_ingress  tag 6b61f0fed6338026  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,98,74,75,97,76
	btf_id 142
472: sched_cls  name handle_policy  tag 88f3439f5aed0242  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,98,74,75,97,33,72,96,31,76,67,32,29,30
	btf_id 143
473: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,98
	btf_id 144
475: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,98,74,75,97,76
	btf_id 146
476: sched_cls  name __send_drop_notify  tag fbe49b01d1afd6b0  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 147
477: sched_cls  name tail_ipv4_to_endpoint  tag f636a13939707336  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,97,33,74,75,72,96,31,98,32,29,30
	btf_id 148
478: sched_cls  name tail_handle_ipv4_cont  tag 5882f50be69dc10f  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,97,33,96,74,75,31,68,66,69,98,32,29,30,73
	btf_id 149
479: sched_cls  name tail_handle_arp  tag 8862617e4520998d  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,98
	btf_id 150
480: sched_cls  name cil_from_container  tag 0e8d55dc403becfc  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 98,68
	btf_id 151
481: sched_cls  name tail_ipv4_to_endpoint  tag e26375bfb9574a87  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,100,33,74,75,72,90,31,99,32,29,30
	btf_id 153
482: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,99
	btf_id 154
484: sched_cls  name tail_handle_arp  tag 097ea92f068d2fe6  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,99
	btf_id 156
485: sched_cls  name tail_handle_ipv4_cont  tag 55040228555a92e8  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,100,33,90,74,75,31,68,66,69,99,32,29,30,73
	btf_id 157
486: sched_cls  name __send_drop_notify  tag c214a28f9a0ff3ef  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 158
487: sched_cls  name handle_policy  tag 5e194f69ee1b72f6  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,99,74,75,100,33,72,90,31,76,67,32,29,30
	btf_id 159
488: sched_cls  name tail_handle_ipv4  tag f94b0502f4750c7c  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,99
	btf_id 160
489: sched_cls  name tail_ipv4_ct_ingress  tag d92a66e680c9b3e6  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,99,74,75,100,76
	btf_id 161
490: sched_cls  name cil_from_container  tag 5b7e269aacad0e16  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 99,68
	btf_id 162
491: sched_cls  name tail_ipv4_ct_egress  tag 6dbe9b5e08f7edb0  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,99,74,75,100,76
	btf_id 163
492: sched_cls  name cil_from_container  tag a12cf489672fcc09  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 102,68
	btf_id 165
493: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,102
	btf_id 166
494: sched_cls  name tail_ipv4_to_endpoint  tag 93a5b7e1b985eb49  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,101,33,74,75,72,91,31,102,32,29,30
	btf_id 167
495: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
498: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
499: sched_cls  name tail_handle_ipv4_cont  tag aff565a1b6c548d5  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,101,33,91,74,75,31,68,66,69,102,32,29,30,73
	btf_id 168
500: sched_cls  name tail_handle_arp  tag 8f80782c132181bb  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,102
	btf_id 169
501: sched_cls  name tail_handle_ipv4  tag d8c258cac939dd38  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,102
	btf_id 170
502: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
505: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
506: sched_cls  name handle_policy  tag bac18f596b7ab6b5  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,102,74,75,101,33,72,91,31,76,67,32,29,30
	btf_id 171
507: sched_cls  name tail_ipv4_ct_egress  tag 6dbe9b5e08f7edb0  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,102,74,75,101,76
	btf_id 172
508: sched_cls  name tail_ipv4_ct_ingress  tag 944a44d21b089f9d  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,102,74,75,101,76
	btf_id 173
509: sched_cls  name __send_drop_notify  tag 2658686603ba9825  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 174
512: sched_cls  name __send_drop_notify  tag 12729558f384ac66  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 178
513: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,106
	btf_id 179
514: sched_cls  name tail_handle_ipv4_from_host  tag db5985399f7217f1  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,106
	btf_id 180
515: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,106
	btf_id 181
517: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 183
518: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,107
	btf_id 185
519: sched_cls  name tail_handle_ipv4_from_host  tag db5985399f7217f1  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,107
	btf_id 186
522: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 189
524: sched_cls  name __send_drop_notify  tag 12729558f384ac66  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 191
525: sched_cls  name tail_handle_ipv4_from_host  tag db5985399f7217f1  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,109
	btf_id 193
529: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,109,67
	btf_id 197
530: sched_cls  name __send_drop_notify  tag 12729558f384ac66  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 198
531: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,109
	btf_id 199
532: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
535: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
536: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
539: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
579: sched_cls  name tail_ipv4_ct_ingress  tag f1aad94a880c31f7  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,124,74,75,125,76
	btf_id 215
580: sched_cls  name handle_policy  tag 2fd5d2aaeb515fca  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,124,74,75,125,33,72,123,31,76,67,32,29,30
	btf_id 216
581: sched_cls  name cil_from_container  tag c0c3a6d186417449  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 124,68
	btf_id 217
583: sched_cls  name __send_drop_notify  tag 1d5754d05de69338  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 219
584: sched_cls  name tail_handle_arp  tag ad6845bf32806e86  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,124
	btf_id 220
585: sched_cls  name tail_handle_ipv4_cont  tag 081a71c79c50abc1  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,125,33,123,74,75,31,68,66,69,124,32,29,30,73
	btf_id 221
586: sched_cls  name tail_ipv4_ct_egress  tag d5fedad143f13399  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,124,74,75,125,76
	btf_id 222
587: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,124
	btf_id 223
588: sched_cls  name tail_handle_ipv4  tag 5ca203a422e775bf  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,124
	btf_id 224
589: sched_cls  name tail_ipv4_to_endpoint  tag f81a725e47a5afcf  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,125,33,74,75,72,123,31,124,32,29,30
	btf_id 225
590: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
593: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
606: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
609: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
610: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
613: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
614: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
617: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
