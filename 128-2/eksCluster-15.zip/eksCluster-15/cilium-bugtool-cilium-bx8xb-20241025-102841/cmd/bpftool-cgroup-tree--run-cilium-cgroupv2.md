CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddeeec9d3_e0e7_4f7e_8d50_6786744b09f3.slice/cri-containerd-18b70f4f8b32e8f588edbb55ed8e3a346c04243d6b7d9fe58d3895ef376858bb.scope
    498      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddeeec9d3_e0e7_4f7e_8d50_6786744b09f3.slice/cri-containerd-6351dabfbdb8f8ea641130dbbf5e9be35f0e0d018755e5b825ac66bda5252e1b.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podde38c1e5_9336_42ae_8484_76ceb4fd4149.slice/cri-containerd-2cdb3ff28cdc15fec7416e6ac26df47cb8228ef1bd77a25a8e846065157da0b9.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podde38c1e5_9336_42ae_8484_76ceb4fd4149.slice/cri-containerd-ba26ba1f941f8b86ad27d79979234dc0da4db2ce6403717abf0e24d877c87ae5.scope
    61       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb25d7454_d7f3_4875_b37f_de3d888d97a5.slice/cri-containerd-b3d44e1c787e8f7d641e56aa5f98d43e4e64aede3c9d1bbec61533d0d776c377.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb25d7454_d7f3_4875_b37f_de3d888d97a5.slice/cri-containerd-7f28affdc1be0598f384be30e4902fd851cc215d7513cc78d236b55ae9118560.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod99512e2b_3e55_4bbb_9885_cb87d67e12a2.slice/cri-containerd-f936c07a5ea0a68ecc3346290212a43c8930a4bc15e5542924873ffdc7e39002.scope
    505      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod99512e2b_3e55_4bbb_9885_cb87d67e12a2.slice/cri-containerd-baad7adf904422245be3da398350353e9b10423cb51f8837f612bcde6daceccb.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f8a7dee_1a4d_4a72_9e1c_ef8206fe34c1.slice/cri-containerd-c528c36bb3630a5bc8b259ad003119b629bb2cb4b403fcbcf9ce4687c0bef724.scope
    76       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f8a7dee_1a4d_4a72_9e1c_ef8206fe34c1.slice/cri-containerd-84a64463aaa25f28794b12dfca3df4984d8de67013bbc5d1b7b71ab0dec0d318.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda552183f_4468_4676_a957_bb167d75e66f.slice/cri-containerd-99636e96b2ba82ad0cf0dc4760378139f681d9ac4bfe975163c1d4ca0d44aa6a.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda552183f_4468_4676_a957_bb167d75e66f.slice/cri-containerd-9bf5f862ca41b79d4d268eef04258c9866b60adaf68ac0c4b3e90d2e28ef771c.scope
    72       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2febdea_ec19_4ff7_9789_7e57d7f71452.slice/cri-containerd-ceafb7b0ef16b0897bf388434ac9b7e7178c1cd3e4feac65302f2045536a5114.scope
    609      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2febdea_ec19_4ff7_9789_7e57d7f71452.slice/cri-containerd-eebcb2903f5ef2b7ef1e6a1616634f36db5d4fb152107ea08d8a6fd4645a6cd5.scope
    617      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2febdea_ec19_4ff7_9789_7e57d7f71452.slice/cri-containerd-6aa30726f63452b542164fe306da082440f7a55601c044376eb5b16878bb0037.scope
    613      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2febdea_ec19_4ff7_9789_7e57d7f71452.slice/cri-containerd-37dfe4b90e7692a2e292998fbe21302e3b7cd0016dc3a2bbdc3ebe7f82152b26.scope
    593      cgroup_device   multi                                          
