IP ADDRESS        LOCAL ENDPOINT INFO
10.15.0.60:0      id=1288  sec_id=1078774 flags=0x0000 ifindex=11  mac=86:83:51:4B:51:0B nodemac=02:76:B4:5F:0A:8F   
10.15.0.157:0     id=676   sec_id=4     flags=0x0000 ifindex=7   mac=92:5A:D0:79:A9:94 nodemac=C6:22:60:C5:EE:57     
10.15.0.116:0     (localhost)                                                                                        
10.15.0.122:0     id=2675  sec_id=1078774 flags=0x0000 ifindex=9   mac=82:F5:BA:22:0D:00 nodemac=02:95:06:68:56:8C   
10.15.0.78:0      id=412   sec_id=1061807 flags=0x0000 ifindex=15  mac=AA:06:5C:1F:F9:B5 nodemac=D6:5D:C8:9E:B7:4E   
172.31.234.25:0   (localhost)                                                                                        
