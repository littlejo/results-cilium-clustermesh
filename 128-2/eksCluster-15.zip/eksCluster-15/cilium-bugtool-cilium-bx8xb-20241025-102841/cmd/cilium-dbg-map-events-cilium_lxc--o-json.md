{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:34.600Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.234.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:34.601Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.814Z",
  "value": "id=1288  sec_id=1078774 flags=0x0000 ifindex=11  mac=86:83:51:4B:51:0B nodemac=02:76:B4:5F:0A:8F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.822Z",
  "value": "id=2675  sec_id=1078774 flags=0x0000 ifindex=9   mac=82:F5:BA:22:0D:00 nodemac=02:95:06:68:56:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.871Z",
  "value": "id=676   sec_id=4     flags=0x0000 ifindex=7   mac=92:5A:D0:79:A9:94 nodemac=C6:22:60:C5:EE:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.916Z",
  "value": "id=1288  sec_id=1078774 flags=0x0000 ifindex=11  mac=86:83:51:4B:51:0B nodemac=02:76:B4:5F:0A:8F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.968Z",
  "value": "id=2675  sec_id=1078774 flags=0x0000 ifindex=9   mac=82:F5:BA:22:0D:00 nodemac=02:95:06:68:56:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:58.243Z",
  "value": "id=1288  sec_id=1078774 flags=0x0000 ifindex=11  mac=86:83:51:4B:51:0B nodemac=02:76:B4:5F:0A:8F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:58.243Z",
  "value": "id=676   sec_id=4     flags=0x0000 ifindex=7   mac=92:5A:D0:79:A9:94 nodemac=C6:22:60:C5:EE:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:58.244Z",
  "value": "id=2675  sec_id=1078774 flags=0x0000 ifindex=9   mac=82:F5:BA:22:0D:00 nodemac=02:95:06:68:56:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:58.273Z",
  "value": "id=2447  sec_id=1061807 flags=0x0000 ifindex=13  mac=EA:B8:DB:8E:E5:9B nodemac=4A:FE:FF:E0:5C:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:59.243Z",
  "value": "id=676   sec_id=4     flags=0x0000 ifindex=7   mac=92:5A:D0:79:A9:94 nodemac=C6:22:60:C5:EE:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:59.244Z",
  "value": "id=2675  sec_id=1078774 flags=0x0000 ifindex=9   mac=82:F5:BA:22:0D:00 nodemac=02:95:06:68:56:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:59.244Z",
  "value": "id=2447  sec_id=1061807 flags=0x0000 ifindex=13  mac=EA:B8:DB:8E:E5:9B nodemac=4A:FE:FF:E0:5C:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:59.244Z",
  "value": "id=1288  sec_id=1078774 flags=0x0000 ifindex=11  mac=86:83:51:4B:51:0B nodemac=02:76:B4:5F:0A:8F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:11.892Z",
  "value": "id=412   sec_id=1061807 flags=0x0000 ifindex=15  mac=AA:06:5C:1F:F9:B5 nodemac=D6:5D:C8:9E:B7:4E"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.15.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:17.447Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:24.239Z",
  "value": "id=1288  sec_id=1078774 flags=0x0000 ifindex=11  mac=86:83:51:4B:51:0B nodemac=02:76:B4:5F:0A:8F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:24.240Z",
  "value": "id=676   sec_id=4     flags=0x0000 ifindex=7   mac=92:5A:D0:79:A9:94 nodemac=C6:22:60:C5:EE:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:24.240Z",
  "value": "id=412   sec_id=1061807 flags=0x0000 ifindex=15  mac=AA:06:5C:1F:F9:B5 nodemac=D6:5D:C8:9E:B7:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:24.241Z",
  "value": "id=2675  sec_id=1078774 flags=0x0000 ifindex=9   mac=82:F5:BA:22:0D:00 nodemac=02:95:06:68:56:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:25.240Z",
  "value": "id=412   sec_id=1061807 flags=0x0000 ifindex=15  mac=AA:06:5C:1F:F9:B5 nodemac=D6:5D:C8:9E:B7:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:25.240Z",
  "value": "id=2675  sec_id=1078774 flags=0x0000 ifindex=9   mac=82:F5:BA:22:0D:00 nodemac=02:95:06:68:56:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:25.240Z",
  "value": "id=1288  sec_id=1078774 flags=0x0000 ifindex=11  mac=86:83:51:4B:51:0B nodemac=02:76:B4:5F:0A:8F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:25.240Z",
  "value": "id=676   sec_id=4     flags=0x0000 ifindex=7   mac=92:5A:D0:79:A9:94 nodemac=C6:22:60:C5:EE:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:26.240Z",
  "value": "id=412   sec_id=1061807 flags=0x0000 ifindex=15  mac=AA:06:5C:1F:F9:B5 nodemac=D6:5D:C8:9E:B7:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:26.241Z",
  "value": "id=676   sec_id=4     flags=0x0000 ifindex=7   mac=92:5A:D0:79:A9:94 nodemac=C6:22:60:C5:EE:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:26.241Z",
  "value": "id=1288  sec_id=1078774 flags=0x0000 ifindex=11  mac=86:83:51:4B:51:0B nodemac=02:76:B4:5F:0A:8F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.122:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:26.241Z",
  "value": "id=2675  sec_id=1078774 flags=0x0000 ifindex=9   mac=82:F5:BA:22:0D:00 nodemac=02:95:06:68:56:8C"
}

