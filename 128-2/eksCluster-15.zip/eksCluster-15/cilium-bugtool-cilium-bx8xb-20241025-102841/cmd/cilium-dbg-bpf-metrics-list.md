REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     10099     790847      677    bpf_overlay.c
Interface                 INGRESS     232111    102072947   1132   bpf_host.c
Success                   EGRESS      10491     817022      53     encap.h
Success                   EGRESS      5288      406253      1694   bpf_host.c
Success                   EGRESS      99332     12927179    1308   bpf_lxc.c
Success                   INGRESS     111050    13655621    86     l3.h
Success                   INGRESS     116510    14084121    235    trace.h
Unsupported L3 protocol   EGRESS      36        2672        1492   bpf_lxc.c
