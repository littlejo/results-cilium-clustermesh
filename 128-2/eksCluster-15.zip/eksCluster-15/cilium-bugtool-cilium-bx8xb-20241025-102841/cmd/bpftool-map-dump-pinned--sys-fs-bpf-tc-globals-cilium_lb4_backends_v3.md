key: 02 00 00 00  value: ac 1f ea 19 10 94 00 00  00 00 00 00
key: 07 00 00 00  value: ac 1f ee 7a 01 bb 00 00  00 00 00 00
key: 03 00 00 00  value: 0a 0f 00 3c 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 0f 00 4e 09 4b 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 0f 00 7a 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: 0a 0f 00 7a 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 9a 0e 01 bb 00 00  00 00 00 00
key: 04 00 00 00  value: 0a 0f 00 3c 23 c1 00 00  00 00 00 00
Found 8 elements
