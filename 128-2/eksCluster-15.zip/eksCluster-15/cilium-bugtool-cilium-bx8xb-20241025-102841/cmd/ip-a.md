1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:bc:52:5c:62:63 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.234.25/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2656sec preferred_lft 2656sec
    inet6 fe80::8bc:52ff:fe5c:6263/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:5e:26:c9:fa:57 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::645e:26ff:fec9:fa57/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:1c:9b:f3:bb:d2 brd ff:ff:ff:ff:ff:ff
    inet 10.15.0.116/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::f81c:9bff:fef3:bbd2/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 32:34:a9:5f:1a:d1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3034:a9ff:fe5f:1ad1/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:22:60:c5:ee:57 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c422:60ff:fec5:ee57/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc5759492f17b5@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:95:06:68:56:8c brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::95:6ff:fe68:568c/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc998b225c0461@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:76:b4:5f:0a:8f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::76:b4ff:fe5f:a8f/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc13a69a9fd585@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:5d:c8:9e:b7:4e brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::d45d:c8ff:fe9e:b74e/64 scope link 
       valid_lft forever preferred_lft forever
