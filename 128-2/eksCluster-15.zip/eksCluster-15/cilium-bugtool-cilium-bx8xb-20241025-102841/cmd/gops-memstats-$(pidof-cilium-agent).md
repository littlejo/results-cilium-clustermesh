alloc: 77.66MB (81428864 bytes)
total-alloc: 1.39GB (1494463064 bytes)
sys: 202.32MB (212146500 bytes)
lookups: 0
mallocs: 48738241
frees: 48162788
heap-alloc: 77.66MB (81428864 bytes)
heap-sys: 158.83MB (166543360 bytes)
heap-idle: 41.27MB (43278336 bytes)
heap-in-use: 117.55MB (123265024 bytes)
heap-released: 1.00MB (1048576 bytes)
heap-objects: 575453
stack-in-use: 33.12MB (34734080 bytes)
stack-sys: 33.12MB (34734080 bytes)
stack-mspan-inuse: 1.92MB (2016480 bytes)
stack-mspan-sys: 2.43MB (2545920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 926.41KB (948641 bytes)
gc-sys: 5.10MB (5346520 bytes)
next-gc: when heap-alloc >= 146.74MB (153867048 bytes)
last-gc: 2024-10-25 10:29:04.499534699 +0000 UTC
gc-pause-total: 7.308606ms
gc-pause: 111663
gc-pause-end: 1729852144499534699
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.00028558826204571404
enable-gc: true
debug-gc: false
