USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         674  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops stats 1
root         673  0.0  0.4 1240432 16676 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         702  0.0  0.4 1240432 16676 ?       R    10:28   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         703  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         667  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         638  0.0  0.1 1229000 3992 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root         636  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops stack 1
root         630  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops memstats 1
root           1  2.5  7.0 1472240 275108 ?      Ssl  10:13   0:22 cilium-agent --config-dir=/tmp/cilium/config-map
root         414  0.0  0.1 1228848 6884 ?        Sl   10:13   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
