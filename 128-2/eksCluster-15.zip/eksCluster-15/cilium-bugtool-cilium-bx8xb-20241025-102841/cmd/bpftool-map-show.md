26: hash  name cilium_node_map  flags 0x1
	key 20B  value 2B  max_entries 16384  memlock 393216B
29: hash  name cilium_auth_map  flags 0x1
	key 12B  value 8B  max_entries 524288  memlock 12582912B
30: array  name cilium_runtime_  flags 0x0
	key 4B  value 8B  max_entries 256  memlock 4096B
31: perf_event_array  name cilium_signals  flags 0x0
	key 4B  value 4B  max_entries 2  memlock 4096B
32: hash  name cilium_node_map  flags 0x1
	key 20B  value 4B  max_entries 16384  memlock 393216B
33: perf_event_array  name cilium_events  flags 0x0
	key 4B  value 4B  max_entries 2  memlock 4096B
66: hash  name cilium_lxc  flags 0x1
	key 20B  value 48B  max_entries 65535  memlock 4718592B
67: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 20480000B
68: percpu_hash  name cilium_metrics  flags 0x1
	key 8B  value 16B  max_entries 1024  memlock 40960B
69: hash  name cilium_tunnel_m  flags 0x1
	key 20B  value 20B  max_entries 65536  memlock 2621440B
70: hash  name cilium_lb4_serv  flags 0x1
	key 12B  value 12B  max_entries 65536  memlock 1572864B
71: hash  name cilium_lb4_back  flags 0x1
	key 4B  value 12B  max_entries 65536  memlock 1048576B
72: hash  name cilium_lb4_reve  flags 0x1
	key 2B  value 6B  max_entries 65536  memlock 524288B
73: prog_array  name cilium_call_pol  flags 0x0
	key 4B  value 4B  max_entries 65535  memlock 524288B
	owner_prog_type sched_cls  owner jited
74: lru_hash  name cilium_ct4_glob  flags 0x0
	key 14B  value 56B  max_entries 131072  memlock 9437184B
75: lru_hash  name cilium_ct_any4_  flags 0x0
	key 14B  value 56B  max_entries 65536  memlock 4718592B
76: lru_hash  name cilium_ipv4_fra  flags 0x0
	key 12B  value 4B  max_entries 8192  memlock 131072B
77: lpm_trie  name cilium_lb4_sour  flags 0x1
	key 12B  value 1B  max_entries 65536  memlock 1048576B
79: lru_hash  name cilium_ratelimi  flags 0x0
	key 4B  value 16B  max_entries 1024  memlock 24576B
	btf_id 77
80: hash  name cilium_l2_respo  flags 0x1
	key 8B  value 8B  max_entries 4096  memlock 65536B
	btf_id 78
82: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
89: prog_array  name cilium_calls_ov  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
90: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
91: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
96: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
97: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 140
98: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
99: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
100: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 152
101: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 164
102: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
106: prog_array  name cilium_calls_ho  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
107: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
109: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
123: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
124: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 50  memlock 4096B
	owner_prog_type sched_cls  owner jited
125: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 40B  max_entries 1  memlock 4096B
	btf_id 214
