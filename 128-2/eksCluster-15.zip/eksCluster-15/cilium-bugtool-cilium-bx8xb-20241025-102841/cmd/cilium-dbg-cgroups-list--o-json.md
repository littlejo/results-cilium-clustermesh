[
  {
    "containers": [
      {
        "cgroup-id": 8296,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2febdea_ec19_4ff7_9789_7e57d7f71452.slice/cri-containerd-6aa30726f63452b542164fe306da082440f7a55601c044376eb5b16878bb0037.scope"
      },
      {
        "cgroup-id": 8212,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2febdea_ec19_4ff7_9789_7e57d7f71452.slice/cri-containerd-ceafb7b0ef16b0897bf388434ac9b7e7178c1cd3e4feac65302f2045536a5114.scope"
      },
      {
        "cgroup-id": 8380,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2febdea_ec19_4ff7_9789_7e57d7f71452.slice/cri-containerd-eebcb2903f5ef2b7ef1e6a1616634f36db5d4fb152107ea08d8a6fd4645a6cd5.scope"
      }
    ],
    "ips": [
      "10.15.0.78"
    ],
    "name": "clustermesh-apiserver-5c7dc99697-smvgm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6868,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod99512e2b_3e55_4bbb_9885_cb87d67e12a2.slice/cri-containerd-baad7adf904422245be3da398350353e9b10423cb51f8837f612bcde6daceccb.scope"
      }
    ],
    "ips": [
      "10.15.0.122"
    ],
    "name": "coredns-cc6ccd49c-5jgkq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6784,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddeeec9d3_e0e7_4f7e_8d50_6786744b09f3.slice/cri-containerd-6351dabfbdb8f8ea641130dbbf5e9be35f0e0d018755e5b825ac66bda5252e1b.scope"
      }
    ],
    "ips": [
      "10.15.0.60"
    ],
    "name": "coredns-cc6ccd49c-qc4np",
    "namespace": "kube-system"
  }
]

