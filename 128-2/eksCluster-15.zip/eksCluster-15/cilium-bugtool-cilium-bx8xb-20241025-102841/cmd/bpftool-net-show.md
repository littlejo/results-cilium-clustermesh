xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 529
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 522
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 517
cilium_host(4) clsact/egress cil_from_host-cilium_host id 515
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 446
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 447
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 480
lxc5759492f17b5(9) clsact/ingress cil_from_container-lxc5759492f17b5 id 492
lxc998b225c0461(11) clsact/ingress cil_from_container-lxc998b225c0461 id 490
lxc13a69a9fd585(15) clsact/ingress cil_from_container-lxc13a69a9fd585 id 581

flow_dissector:

netfilter:

