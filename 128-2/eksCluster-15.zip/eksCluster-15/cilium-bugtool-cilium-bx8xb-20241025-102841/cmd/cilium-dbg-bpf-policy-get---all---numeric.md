Endpoint ID: 77
Path: /sys/fs/bpf/tc/globals/cilium_policy_00077

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 412
Path: /sys/fs/bpf/tc/globals/cilium_policy_00412

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3785317   36198     0        
Allow    Ingress     1          ANY          NONE         disabled    3594668   36750     0        
Allow    Egress      0          ANY          NONE         disabled    5435370   49866     0        


Endpoint ID: 676
Path: /sys/fs/bpf/tc/globals/cilium_policy_00676

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    429510   5474      0        
Allow    Ingress     1          ANY          NONE         disabled    12530    146       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1288
Path: /sys/fs/bpf/tc/globals/cilium_policy_01288

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    88403   1020      0        
Allow    Egress      0          ANY          NONE         disabled    14984   158       0        


Endpoint ID: 2675
Path: /sys/fs/bpf/tc/globals/cilium_policy_02675

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    89046   1027      0        
Allow    Egress      0          ANY          NONE         disabled    14310   151       0        


