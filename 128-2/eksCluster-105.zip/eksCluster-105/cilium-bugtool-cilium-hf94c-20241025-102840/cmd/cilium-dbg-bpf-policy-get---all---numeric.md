Endpoint ID: 595
Path: /sys/fs/bpf/tc/globals/cilium_policy_00595

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    77433   886       0        
Allow    Egress      0          ANY          NONE         disabled    13471   140       0        


Endpoint ID: 970
Path: /sys/fs/bpf/tc/globals/cilium_policy_00970

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3808185   36321     0        
Allow    Ingress     1          ANY          NONE         disabled    3485448   35580     0        
Allow    Egress      0          ANY          NONE         disabled    5201206   47850     0        


Endpoint ID: 980
Path: /sys/fs/bpf/tc/globals/cilium_policy_00980

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1892
Path: /sys/fs/bpf/tc/globals/cilium_policy_01892

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    429583   5465      0        
Allow    Ingress     1          ANY          NONE         disabled    11445    132       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2598
Path: /sys/fs/bpf/tc/globals/cilium_policy_02598

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    78409   899       0        
Allow    Egress      0          ANY          NONE         disabled    13413   139       0        


