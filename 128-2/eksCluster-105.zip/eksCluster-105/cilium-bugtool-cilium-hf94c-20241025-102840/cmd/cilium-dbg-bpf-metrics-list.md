REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10033     787604     677    bpf_overlay.c
Interface                 INGRESS     225253    86294329   1132   bpf_host.c
Success                   EGRESS      10344     808413     53     encap.h
Success                   EGRESS      5230      402991     1694   bpf_host.c
Success                   EGRESS      97030     12691864   1308   bpf_lxc.c
Success                   INGRESS     108207    13313210   86     l3.h
Success                   INGRESS     113659    13741729   235    trace.h
Unsupported L3 protocol   EGRESS      41        3098       1492   bpf_lxc.c
