top - 10:28:41 up 14 min,  0 users,  load average: 0.31, 0.23, 0.18
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 29.0 us, 41.9 sy,  0.0 ni, 29.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    782.1 free,    912.1 used,   2141.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2755.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 282800  77740 S   6.7   7.2   0:27.66 cilium-+
    649 root      20   0 1240432  16316  11356 S   6.7   0.4   0:00.03 cilium-+
    394 root      20   0 1228848   6036   2872 S   0.0   0.2   0:00.27 cilium-+
    683 root      20   0    6576   2420   2096 R   0.0   0.1   0:00.00 top
    691 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    717 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
