1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:2d:bf:ce:e0:e1 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.227.91/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2728sec preferred_lft 2728sec
    inet6 fe80::82d:bfff:fece:e0e1/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:25:2f:6a:a2:69 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.230.174/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::825:2fff:fe6a:a269/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:0b:74:50:ee:d5 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::280b:74ff:fe50:eed5/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:80:fc:cd:11:02 brd ff:ff:ff:ff:ff:ff
    inet 10.105.0.35/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::880:fcff:fecd:1102/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 0e:46:ea:20:a2:b3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c46:eaff:fe20:a2b3/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:0b:0a:61:6c:75 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ec0b:aff:fe61:6c75/64 scope link 
       valid_lft forever preferred_lft forever
12: lxce034d3818f09@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:63:1c:41:cc:25 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::9463:1cff:fe41:cc25/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc509c5c08a0d5@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:1f:dd:b8:ce:36 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::341f:ddff:feb8:ce36/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc29acc45dd9ef@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:fd:01:f2:0f:14 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::ccfd:1ff:fef2:f14/64 scope link 
       valid_lft forever preferred_lft forever
