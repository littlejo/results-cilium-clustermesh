Node 0, zone      DMA      2      1      2      1      1     11      5      2      3      3    167 
Node 0, zone   Normal    172     80     31     15     16      1      2      2      1      4      7 
