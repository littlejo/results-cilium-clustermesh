alloc: 95.70MB (100353048 bytes)
total-alloc: 1.37GB (1472566344 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 48450536
frees: 47452201
heap-alloc: 95.70MB (100353048 bytes)
heap-sys: 165.60MB (173645824 bytes)
heap-idle: 44.80MB (46981120 bytes)
heap-in-use: 120.80MB (126664704 bytes)
heap-released: 3.94MB (4128768 bytes)
heap-objects: 998335
stack-in-use: 34.38MB (36044800 bytes)
stack-sys: 34.38MB (36044800 bytes)
stack-mspan-inuse: 2.01MB (2112320 bytes)
stack-mspan-sys: 2.46MB (2578560 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 909.29KB (931113 bytes)
gc-sys: 5.14MB (5390616 bytes)
next-gc: when heap-alloc >= 146.49MB (153603816 bytes)
last-gc: 2024-10-25 10:28:45.903611294 +0000 UTC
gc-pause-total: 6.984468ms
gc-pause: 85317
gc-pause-end: 1729852125903611294
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.0003695768461864088
enable-gc: true
debug-gc: false
