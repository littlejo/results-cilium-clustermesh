filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc29acc45dd9ef direct-action not_in_hw id 615 tag 7bec9462f172c58c jited 
