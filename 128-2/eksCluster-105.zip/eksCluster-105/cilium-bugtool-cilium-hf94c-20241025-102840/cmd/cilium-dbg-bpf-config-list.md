KEY             VALUE
AgentLiveness   913053801616
UTimeOffset     3378615701171875
