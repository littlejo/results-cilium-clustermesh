ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.141.23:443 (active)    
                                         2 => 172.31.253.22:443 (active)    
2    10.100.157.120:443   ClusterIP      1 => 172.31.227.91:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.105.0.136:9153 (active)    
                                         2 => 10.105.0.247:9153 (active)    
4    10.100.0.10:53       ClusterIP      1 => 10.105.0.136:53 (active)      
                                         2 => 10.105.0.247:53 (active)      
5    10.100.88.140:2379   ClusterIP      1 => 10.105.0.59:2379 (active)     
