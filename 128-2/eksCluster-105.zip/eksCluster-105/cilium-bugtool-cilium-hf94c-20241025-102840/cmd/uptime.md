 10:28:41 up 14 min,  0 users,  load average: 0.31, 0.23, 0.18
