[
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd123c93d_943e_4761_9ae5_447c21e59575.slice/cri-containerd-d11d074215a218dea6c294d27100266ab5a6510349eeb48f88d8f69f9cc24587.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd123c93d_943e_4761_9ae5_447c21e59575.slice/cri-containerd-9627a398a33022b73cfd577a9fa6f583cfc5d367e703805998def25116d666c6.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd123c93d_943e_4761_9ae5_447c21e59575.slice/cri-containerd-a58dc5640427818ba0ff56b826dbf195a28fdf9d47d63cacf0087a000b980bca.scope"
      }
    ],
    "ips": [
      "10.105.0.59"
    ],
    "name": "clustermesh-apiserver-775b76db66-mgx9w",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7530,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd19dc0fb_9b2d_4c46_a7c7_500f1f433dae.slice/cri-containerd-025e78ab2c68e43219beb76d81291a98da4342fd527efc8c5b60b0919fcc566b.scope"
      }
    ],
    "ips": [
      "10.105.0.136"
    ],
    "name": "coredns-cc6ccd49c-hf7lf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf74b602d_c8e6_4b0f_b986_6bc8a193564c.slice/cri-containerd-59db8e84c1f87895d0211844dce7b4c32e9295ee1b6a26ae3a487dd4f2672dcb.scope"
      }
    ],
    "ips": [
      "10.105.0.247"
    ],
    "name": "coredns-cc6ccd49c-vmcl4",
    "namespace": "kube-system"
  }
]

