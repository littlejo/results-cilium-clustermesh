key: 53 02 00 00  value: 31 02 00 00
key: ca 03 00 00  value: 6b 02 00 00
key: 64 07 00 00  value: 18 02 00 00
key: 26 0a 00 00  value: 0c 02 00 00
Found 4 elements
