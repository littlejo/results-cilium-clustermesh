{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:12.494Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.227.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:12.494Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.230.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:12.494Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:17.119Z",
  "value": "id=2598  sec_id=6972169 flags=0x0000 ifindex=12  mac=D2:FA:71:0E:36:04 nodemac=96:63:1C:41:CC:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:17.119Z",
  "value": "id=1892  sec_id=4     flags=0x0000 ifindex=10  mac=DA:30:01:B6:FF:14 nodemac=EE:0B:0A:61:6C:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:17.120Z",
  "value": "id=2598  sec_id=6972169 flags=0x0000 ifindex=12  mac=D2:FA:71:0E:36:04 nodemac=96:63:1C:41:CC:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:17.153Z",
  "value": "id=1892  sec_id=4     flags=0x0000 ifindex=10  mac=DA:30:01:B6:FF:14 nodemac=EE:0B:0A:61:6C:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:25.471Z",
  "value": "id=595   sec_id=6972169 flags=0x0000 ifindex=14  mac=66:E5:B2:5A:1D:20 nodemac=36:1F:DD:B8:CE:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:59.040Z",
  "value": "id=1892  sec_id=4     flags=0x0000 ifindex=10  mac=DA:30:01:B6:FF:14 nodemac=EE:0B:0A:61:6C:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:59.040Z",
  "value": "id=2598  sec_id=6972169 flags=0x0000 ifindex=12  mac=D2:FA:71:0E:36:04 nodemac=96:63:1C:41:CC:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:59.040Z",
  "value": "id=595   sec_id=6972169 flags=0x0000 ifindex=14  mac=66:E5:B2:5A:1D:20 nodemac=36:1F:DD:B8:CE:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:59.073Z",
  "value": "id=2229  sec_id=6965962 flags=0x0000 ifindex=16  mac=22:5D:01:FA:9E:66 nodemac=0E:39:13:F9:21:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:00.040Z",
  "value": "id=2229  sec_id=6965962 flags=0x0000 ifindex=16  mac=22:5D:01:FA:9E:66 nodemac=0E:39:13:F9:21:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:00.040Z",
  "value": "id=1892  sec_id=4     flags=0x0000 ifindex=10  mac=DA:30:01:B6:FF:14 nodemac=EE:0B:0A:61:6C:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:00.041Z",
  "value": "id=595   sec_id=6972169 flags=0x0000 ifindex=14  mac=66:E5:B2:5A:1D:20 nodemac=36:1F:DD:B8:CE:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:00.041Z",
  "value": "id=2598  sec_id=6972169 flags=0x0000 ifindex=12  mac=D2:FA:71:0E:36:04 nodemac=96:63:1C:41:CC:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:28.760Z",
  "value": "id=970   sec_id=6965962 flags=0x0000 ifindex=18  mac=8A:59:3B:32:5A:2A nodemac=CE:FD:01:F2:0F:14"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.105.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:33.011Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:40.046Z",
  "value": "id=970   sec_id=6965962 flags=0x0000 ifindex=18  mac=8A:59:3B:32:5A:2A nodemac=CE:FD:01:F2:0F:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:40.047Z",
  "value": "id=1892  sec_id=4     flags=0x0000 ifindex=10  mac=DA:30:01:B6:FF:14 nodemac=EE:0B:0A:61:6C:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:40.048Z",
  "value": "id=2598  sec_id=6972169 flags=0x0000 ifindex=12  mac=D2:FA:71:0E:36:04 nodemac=96:63:1C:41:CC:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:40.048Z",
  "value": "id=595   sec_id=6972169 flags=0x0000 ifindex=14  mac=66:E5:B2:5A:1D:20 nodemac=36:1F:DD:B8:CE:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:41.047Z",
  "value": "id=2598  sec_id=6972169 flags=0x0000 ifindex=12  mac=D2:FA:71:0E:36:04 nodemac=96:63:1C:41:CC:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:41.047Z",
  "value": "id=970   sec_id=6965962 flags=0x0000 ifindex=18  mac=8A:59:3B:32:5A:2A nodemac=CE:FD:01:F2:0F:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:41.048Z",
  "value": "id=595   sec_id=6972169 flags=0x0000 ifindex=14  mac=66:E5:B2:5A:1D:20 nodemac=36:1F:DD:B8:CE:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:41.048Z",
  "value": "id=1892  sec_id=4     flags=0x0000 ifindex=10  mac=DA:30:01:B6:FF:14 nodemac=EE:0B:0A:61:6C:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:42.048Z",
  "value": "id=1892  sec_id=4     flags=0x0000 ifindex=10  mac=DA:30:01:B6:FF:14 nodemac=EE:0B:0A:61:6C:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:42.048Z",
  "value": "id=970   sec_id=6965962 flags=0x0000 ifindex=18  mac=8A:59:3B:32:5A:2A nodemac=CE:FD:01:F2:0F:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:42.048Z",
  "value": "id=595   sec_id=6972169 flags=0x0000 ifindex=14  mac=66:E5:B2:5A:1D:20 nodemac=36:1F:DD:B8:CE:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:42.048Z",
  "value": "id=2598  sec_id=6972169 flags=0x0000 ifindex=12  mac=D2:FA:71:0E:36:04 nodemac=96:63:1C:41:CC:25"
}

