CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf74b602d_c8e6_4b0f_b986_6bc8a193564c.slice/cri-containerd-59db8e84c1f87895d0211844dce7b4c32e9295ee1b6a26ae3a487dd4f2672dcb.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf74b602d_c8e6_4b0f_b986_6bc8a193564c.slice/cri-containerd-46c95c9ab3fb707828dbbbdcc1c7278b1432e133306aee313f3c5d986bbfd516.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd19dc0fb_9b2d_4c46_a7c7_500f1f433dae.slice/cri-containerd-abfa29abeda3dd8bddc4d377cfd0d8f59cc4f9b66c1e878c60b8e2fb142ad6b3.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd19dc0fb_9b2d_4c46_a7c7_500f1f433dae.slice/cri-containerd-025e78ab2c68e43219beb76d81291a98da4342fd527efc8c5b60b0919fcc566b.scope
    553      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podec916074_f118_45ca_97ff_55c2a5ea7a21.slice/cri-containerd-7deeec9cb78df15b955fd09480facb4884ef12d5af61b890b2119e4150728fed.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podec916074_f118_45ca_97ff_55c2a5ea7a21.slice/cri-containerd-118ec17dfed2a23a296263e66664c176c79791e31841ddcaf905549eeb9300a3.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod54d43f6a_b9a2_40c7_85a9_55f75a3e6f2b.slice/cri-containerd-3afbffb4f134039bf2bde595f3c2c866f227cc9b0ec05b1952600e24c960951f.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod54d43f6a_b9a2_40c7_85a9_55f75a3e6f2b.slice/cri-containerd-90e657084984bc89d1ea156de1a345be86579dd7e9e257f10004a5bc82d5eb87.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd123c93d_943e_4761_9ae5_447c21e59575.slice/cri-containerd-9627a398a33022b73cfd577a9fa6f583cfc5d367e703805998def25116d666c6.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd123c93d_943e_4761_9ae5_447c21e59575.slice/cri-containerd-4a33303e8f945ee0efe2ce016ee875bf8852cd7fd1719ab5ca4d5a54f71dd3a8.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd123c93d_943e_4761_9ae5_447c21e59575.slice/cri-containerd-a58dc5640427818ba0ff56b826dbf195a28fdf9d47d63cacf0087a000b980bca.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd123c93d_943e_4761_9ae5_447c21e59575.slice/cri-containerd-d11d074215a218dea6c294d27100266ab5a6510349eeb48f88d8f69f9cc24587.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf49b576b_a3ab_489f_a248_34f5b0b02edf.slice/cri-containerd-47fbdc4bf2efc32c2d29c5984d62fadbe586c753fb7340657e23cf7828b82eac.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf49b576b_a3ab_489f_a248_34f5b0b02edf.slice/cri-containerd-13ee8d4b4855e4eedc7a1eb0b3c5a046ef314b1c3e201b49ebb054d0d84d25d8.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6eb81df7_803b_4570_9acb_6bf5271ed2d1.slice/cri-containerd-22d8907d6f7ae69542a9a1b09cd88b152e7ea96eb7ac4981aa49122b76d92265.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6eb81df7_803b_4570_9acb_6bf5271ed2d1.slice/cri-containerd-1c7dbd535a46af05d6471d0ae916a8556efe8df0496239abd4648c67bd8a9330.scope
    106      cgroup_device   multi                                          
