IP ADDRESS         LOCAL ENDPOINT INFO
172.31.230.174:0   (localhost)                                                                                        
10.105.0.136:0     id=2598  sec_id=6972169 flags=0x0000 ifindex=12  mac=D2:FA:71:0E:36:04 nodemac=96:63:1C:41:CC:25   
10.105.0.247:0     id=595   sec_id=6972169 flags=0x0000 ifindex=14  mac=66:E5:B2:5A:1D:20 nodemac=36:1F:DD:B8:CE:36   
10.105.0.59:0      id=970   sec_id=6965962 flags=0x0000 ifindex=18  mac=8A:59:3B:32:5A:2A nodemac=CE:FD:01:F2:0F:14   
10.105.0.35:0      (localhost)                                                                                        
172.31.227.91:0    (localhost)                                                                                        
10.105.0.237:0     id=1892  sec_id=4     flags=0x0000 ifindex=10  mac=DA:30:01:B6:FF:14 nodemac=EE:0B:0A:61:6C:75     
