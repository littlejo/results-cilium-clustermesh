CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda8758a56_36e3_4d48_b325_805bbb09f8ec.slice/cri-containerd-a1ec629675661c5d69ca7383f322d5b94fd5185a1b42f646a9f26c09642a19fd.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda8758a56_36e3_4d48_b325_805bbb09f8ec.slice/cri-containerd-8cef6c562098050fe5db0122558442e046694d7a7af5c2a1259730553ab349aa.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda642ebbd_1695_41db_9bbe_ac92ab15e149.slice/cri-containerd-3849c17481df5bd8b98f92d63be51013f45c266da6c1f93259877d5a65e9c4b7.scope
    543      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda642ebbd_1695_41db_9bbe_ac92ab15e149.slice/cri-containerd-7bce8b19039257532d13e0aaa2cf021730e66ebfbb9bb154f54423e924fd5ef8.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3bc8b181_46cc_4ccc_a777_75c4034abb9f.slice/cri-containerd-2043934e06bd5f8e7a5cf56bde34ed1b88c331571c671bd906f6ec494038887d.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3bc8b181_46cc_4ccc_a777_75c4034abb9f.slice/cri-containerd-b8d688b67389b7f78d3a2e9f99a82cab2c007548b35d7764321b6cb4455abfab.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1f64d9fb_a1df_4fa1_8e7f_47402d5f474c.slice/cri-containerd-e776f518eefc386b56abb4a78f48813c715cd712ff59c7b60c1d03d49c129c29.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1f64d9fb_a1df_4fa1_8e7f_47402d5f474c.slice/cri-containerd-62d4bdf7931b799a1e001e1330018b494a8b219a54aea4bc0cf935c772321481.scope
    533      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod536afeda_a101_4446_981c_16eeb09663a2.slice/cri-containerd-13297c6047a15080b12e284209753d0f476b95ff5c07d54fe429e8452f1ea174.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod536afeda_a101_4446_981c_16eeb09663a2.slice/cri-containerd-d2132ab18279abe3256112599eb0c01c5632197f19b39b727bcf80e8890d82ea.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod649c0ca9_1463_4912_821d_ab9cbd34821b.slice/cri-containerd-879303dc891e5809468a2a1c9cddd532b52c08ce5a59af995d56f79620ac9aec.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod649c0ca9_1463_4912_821d_ab9cbd34821b.slice/cri-containerd-ed3c587028141fcf057070acaedcc75725d7d5fdf6ea395b1c5e1edfbfe7e90f.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8d9b2fd3_bfb8_4ff1_a5a3_ff60eb3dde57.slice/cri-containerd-ac3f3844bb4b656d7be8fd7084f51b50908ed79f46cdab34e180449b3cfb3257.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8d9b2fd3_bfb8_4ff1_a5a3_ff60eb3dde57.slice/cri-containerd-49c3d4408a913265fcde7ba1d2b5c56987a8e8c0b9908bae2c3257354a157377.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8d9b2fd3_bfb8_4ff1_a5a3_ff60eb3dde57.slice/cri-containerd-40764db3489464f0752bd53f5b1470b42f6f8706e15410a78ac319492309bb29.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8d9b2fd3_bfb8_4ff1_a5a3_ff60eb3dde57.slice/cri-containerd-59a5514b0149a342ab3bf5b9621fe895ced156f7661f5f4f2b8d94063990c683.scope
    661      cgroup_device   multi                                          
