KEY             VALUE
AgentLiveness   894823530157
UTimeOffset     3378615738281250
