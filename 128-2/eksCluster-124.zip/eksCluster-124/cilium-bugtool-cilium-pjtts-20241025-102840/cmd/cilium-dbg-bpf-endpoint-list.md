IP ADDRESS        LOCAL ENDPOINT INFO
10.124.0.160:0    id=339   sec_id=4     flags=0x0000 ifindex=10  mac=5A:2C:23:19:AC:C1 nodemac=2E:A1:2F:EF:AA:89     
10.124.0.89:0     id=3387  sec_id=8195318 flags=0x0000 ifindex=14  mac=BE:D0:D8:9C:D2:00 nodemac=AA:A0:1B:D0:B5:CA   
10.124.0.67:0     id=470   sec_id=8195318 flags=0x0000 ifindex=12  mac=82:EC:83:98:35:D0 nodemac=0E:4E:64:8E:E7:5B   
172.31.158.63:0   (localhost)                                                                                        
172.31.147.32:0   (localhost)                                                                                        
10.124.0.78:0     id=2987  sec_id=8215642 flags=0x0000 ifindex=18  mac=BA:D6:B9:0C:7F:F9 nodemac=D2:0D:43:94:21:FB   
10.124.0.136:0    (localhost)                                                                                        
