ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.143.144:443 (active)   
                                          2 => 172.31.212.188:443 (active)   
2    10.100.5.192:443      ClusterIP      1 => 172.31.147.32:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.124.0.67:53 (active)       
                                          2 => 10.124.0.89:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.124.0.67:9153 (active)     
                                          2 => 10.124.0.89:9153 (active)     
5    10.100.252.174:2379   ClusterIP      1 => 10.124.0.78:2379 (active)     
