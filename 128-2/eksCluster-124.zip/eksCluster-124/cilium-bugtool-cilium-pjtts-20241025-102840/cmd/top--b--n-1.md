top - 10:28:42 up 14 min,  0 users,  load average: 0.13, 0.20, 0.21
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 21.4 us, 42.9 sy,  0.0 ni, 35.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    797.4 free,    896.7 used,   2142.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2770.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    748 root      20   0 1240432  16168  11164 S   6.7   0.4   0:00.03 cilium-+
      1 root      20   0 1537844 276040  77636 S   0.0   7.0   0:21.30 cilium-+
    457 root      20   0 1228848   6636   3840 S   0.0   0.2   0:00.26 cilium-+
    800 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    807 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    808 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    809 root      20   0 1229000   4036   3392 S   0.0   0.1   0:00.00 gops
    826 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    861 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
