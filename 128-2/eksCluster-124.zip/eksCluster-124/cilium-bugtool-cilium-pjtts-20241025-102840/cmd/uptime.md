 10:28:41 up 14 min,  0 users,  load average: 0.13, 0.20, 0.21
