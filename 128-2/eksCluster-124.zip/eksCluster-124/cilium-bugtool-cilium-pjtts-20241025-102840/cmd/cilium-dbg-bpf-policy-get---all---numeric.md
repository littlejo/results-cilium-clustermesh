Endpoint ID: 339
Path: /sys/fs/bpf/tc/globals/cilium_policy_00339

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    435054   5545      0        
Allow    Ingress     1          ANY          NONE         disabled    11012    127       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 470
Path: /sys/fs/bpf/tc/globals/cilium_policy_00470

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    72226   829       0        
Allow    Egress      0          ANY          NONE         disabled    12518   127       0        


Endpoint ID: 1472
Path: /sys/fs/bpf/tc/globals/cilium_policy_01472

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2987
Path: /sys/fs/bpf/tc/globals/cilium_policy_02987

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3891020   35694     0        
Allow    Ingress     1          ANY          NONE         disabled    2702538   26891     0        
Allow    Egress      0          ANY          NONE         disabled    3673866   34315     0        


Endpoint ID: 3387
Path: /sys/fs/bpf/tc/globals/cilium_policy_03387

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    71632   820       0        
Allow    Egress      0          ANY          NONE         disabled    13267   136       0        


