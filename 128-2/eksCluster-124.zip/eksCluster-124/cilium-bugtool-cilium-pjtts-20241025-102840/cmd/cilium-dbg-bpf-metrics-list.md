REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     207631    83186252   1132   bpf_host.c
Interface                 INGRESS     9447      738709     677    bpf_overlay.c
Success                   EGRESS      4567      348815     1694   bpf_host.c
Success                   EGRESS      86847     11988597   1308   bpf_lxc.c
Success                   EGRESS      9252      724566     53     encap.h
Success                   INGRESS     102451    12250895   235    trace.h
Success                   INGRESS     96924     11817235   86     l3.h
Unsupported L3 protocol   EGRESS      34        2532       1492   bpf_lxc.c
