alloc: 79.39MB (83244672 bytes)
total-alloc: 1.30GB (1400655384 bytes)
sys: 210.13MB (220341588 bytes)
lookups: 0
mallocs: 47307908
frees: 46762566
heap-alloc: 79.39MB (83244672 bytes)
heap-sys: 167.73MB (175874048 bytes)
heap-idle: 48.30MB (50642944 bytes)
heap-in-use: 119.43MB (125231104 bytes)
heap-released: 1.56MB (1638400 bytes)
heap-objects: 545342
stack-in-use: 32.25MB (33816576 bytes)
stack-sys: 32.25MB (33816576 bytes)
stack-mspan-inuse: 1.89MB (1983360 bytes)
stack-mspan-sys: 2.43MB (2545920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 689.87KB (706425 bytes)
gc-sys: 5.16MB (5409096 bytes)
next-gc: when heap-alloc >= 146.73MB (153861560 bytes)
last-gc: 2024-10-25 10:29:09.328876655 +0000 UTC
gc-pause-total: 71.403563ms
gc-pause: 86113
gc-pause-end: 1729852149328876655
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.0007397524787239856
enable-gc: true
debug-gc: false
