filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc3a63c7a6f5a3 direct-action not_in_hw id 499 tag 046443b4f1e49bba jited 
