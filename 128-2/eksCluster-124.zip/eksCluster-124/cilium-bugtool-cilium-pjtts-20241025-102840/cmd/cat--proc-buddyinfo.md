Node 0, zone      DMA      1      0      2      1      1      7     10      2      3      3    168 
Node 0, zone   Normal    566     70     37     21     29      7      5      4      2      3      6 
