[
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda642ebbd_1695_41db_9bbe_ac92ab15e149.slice/cri-containerd-7bce8b19039257532d13e0aaa2cf021730e66ebfbb9bb154f54423e924fd5ef8.scope"
      }
    ],
    "ips": [
      "10.124.0.89"
    ],
    "name": "coredns-cc6ccd49c-2qds6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1f64d9fb_a1df_4fa1_8e7f_47402d5f474c.slice/cri-containerd-e776f518eefc386b56abb4a78f48813c715cd712ff59c7b60c1d03d49c129c29.scope"
      }
    ],
    "ips": [
      "10.124.0.67"
    ],
    "name": "coredns-cc6ccd49c-mbtcz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9220,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8d9b2fd3_bfb8_4ff1_a5a3_ff60eb3dde57.slice/cri-containerd-40764db3489464f0752bd53f5b1470b42f6f8706e15410a78ac319492309bb29.scope"
      },
      {
        "cgroup-id": 9136,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8d9b2fd3_bfb8_4ff1_a5a3_ff60eb3dde57.slice/cri-containerd-49c3d4408a913265fcde7ba1d2b5c56987a8e8c0b9908bae2c3257354a157377.scope"
      },
      {
        "cgroup-id": 9304,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8d9b2fd3_bfb8_4ff1_a5a3_ff60eb3dde57.slice/cri-containerd-59a5514b0149a342ab3bf5b9621fe895ced156f7661f5f4f2b8d94063990c683.scope"
      }
    ],
    "ips": [
      "10.124.0.78"
    ],
    "name": "clustermesh-apiserver-774c9cfb7-dpcxx",
    "namespace": "kube-system"
  }
]

