{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:04.252Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.147.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:04.252Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.158.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:04.252Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:18.676Z",
  "value": "id=339   sec_id=4     flags=0x0000 ifindex=10  mac=5A:2C:23:19:AC:C1 nodemac=2E:A1:2F:EF:AA:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:18.759Z",
  "value": "id=470   sec_id=8195318 flags=0x0000 ifindex=12  mac=82:EC:83:98:35:D0 nodemac=0E:4E:64:8E:E7:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:18.929Z",
  "value": "id=3387  sec_id=8195318 flags=0x0000 ifindex=14  mac=BE:D0:D8:9C:D2:00 nodemac=AA:A0:1B:D0:B5:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:19.318Z",
  "value": "id=339   sec_id=4     flags=0x0000 ifindex=10  mac=5A:2C:23:19:AC:C1 nodemac=2E:A1:2F:EF:AA:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:19.884Z",
  "value": "id=470   sec_id=8195318 flags=0x0000 ifindex=12  mac=82:EC:83:98:35:D0 nodemac=0E:4E:64:8E:E7:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:51.187Z",
  "value": "id=339   sec_id=4     flags=0x0000 ifindex=10  mac=5A:2C:23:19:AC:C1 nodemac=2E:A1:2F:EF:AA:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:51.187Z",
  "value": "id=470   sec_id=8195318 flags=0x0000 ifindex=12  mac=82:EC:83:98:35:D0 nodemac=0E:4E:64:8E:E7:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:51.188Z",
  "value": "id=3387  sec_id=8195318 flags=0x0000 ifindex=14  mac=BE:D0:D8:9C:D2:00 nodemac=AA:A0:1B:D0:B5:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:51.218Z",
  "value": "id=2582  sec_id=8215642 flags=0x0000 ifindex=16  mac=6E:BF:7D:01:68:2E nodemac=5E:AF:04:1D:62:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:52.188Z",
  "value": "id=2582  sec_id=8215642 flags=0x0000 ifindex=16  mac=6E:BF:7D:01:68:2E nodemac=5E:AF:04:1D:62:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:52.188Z",
  "value": "id=470   sec_id=8195318 flags=0x0000 ifindex=12  mac=82:EC:83:98:35:D0 nodemac=0E:4E:64:8E:E7:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:52.188Z",
  "value": "id=339   sec_id=4     flags=0x0000 ifindex=10  mac=5A:2C:23:19:AC:C1 nodemac=2E:A1:2F:EF:AA:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:52.189Z",
  "value": "id=3387  sec_id=8195318 flags=0x0000 ifindex=14  mac=BE:D0:D8:9C:D2:00 nodemac=AA:A0:1B:D0:B5:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:03.643Z",
  "value": "id=2987  sec_id=8215642 flags=0x0000 ifindex=18  mac=BA:D6:B9:0C:7F:F9 nodemac=D2:0D:43:94:21:FB"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.124.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.407Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:44.388Z",
  "value": "id=2987  sec_id=8215642 flags=0x0000 ifindex=18  mac=BA:D6:B9:0C:7F:F9 nodemac=D2:0D:43:94:21:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:44.391Z",
  "value": "id=339   sec_id=4     flags=0x0000 ifindex=10  mac=5A:2C:23:19:AC:C1 nodemac=2E:A1:2F:EF:AA:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:44.391Z",
  "value": "id=470   sec_id=8195318 flags=0x0000 ifindex=12  mac=82:EC:83:98:35:D0 nodemac=0E:4E:64:8E:E7:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:44.391Z",
  "value": "id=3387  sec_id=8195318 flags=0x0000 ifindex=14  mac=BE:D0:D8:9C:D2:00 nodemac=AA:A0:1B:D0:B5:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:45.378Z",
  "value": "id=2987  sec_id=8215642 flags=0x0000 ifindex=18  mac=BA:D6:B9:0C:7F:F9 nodemac=D2:0D:43:94:21:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:45.378Z",
  "value": "id=3387  sec_id=8195318 flags=0x0000 ifindex=14  mac=BE:D0:D8:9C:D2:00 nodemac=AA:A0:1B:D0:B5:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:45.379Z",
  "value": "id=339   sec_id=4     flags=0x0000 ifindex=10  mac=5A:2C:23:19:AC:C1 nodemac=2E:A1:2F:EF:AA:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:45.379Z",
  "value": "id=470   sec_id=8195318 flags=0x0000 ifindex=12  mac=82:EC:83:98:35:D0 nodemac=0E:4E:64:8E:E7:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:46.379Z",
  "value": "id=339   sec_id=4     flags=0x0000 ifindex=10  mac=5A:2C:23:19:AC:C1 nodemac=2E:A1:2F:EF:AA:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:46.379Z",
  "value": "id=3387  sec_id=8195318 flags=0x0000 ifindex=14  mac=BE:D0:D8:9C:D2:00 nodemac=AA:A0:1B:D0:B5:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:46.379Z",
  "value": "id=470   sec_id=8195318 flags=0x0000 ifindex=12  mac=82:EC:83:98:35:D0 nodemac=0E:4E:64:8E:E7:5B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.124.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:46.379Z",
  "value": "id=2987  sec_id=8215642 flags=0x0000 ifindex=18  mac=BA:D6:B9:0C:7F:F9 nodemac=D2:0D:43:94:21:FB"
}

