key: 53 01 00 00  value: 0d 02 00 00
key: d6 01 00 00  value: 19 02 00 00
key: ab 0b 00 00  value: 75 02 00 00
key: 3b 0d 00 00  value: 05 02 00 00
Found 4 elements
