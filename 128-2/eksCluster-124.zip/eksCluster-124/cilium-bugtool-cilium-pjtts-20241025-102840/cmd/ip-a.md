1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:8f:92:b9:62:e3 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.147.32/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2746sec preferred_lft 2746sec
    inet6 fe80::48f:92ff:feb9:62e3/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:c3:13:09:44:cb brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.158.63/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4c3:13ff:fe09:44cb/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:3b:d3:44:03:63 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::503b:d3ff:fe44:363/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:f4:61:92:6e:79 brd ff:ff:ff:ff:ff:ff
    inet 10.124.0.136/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::e8f4:61ff:fe92:6e79/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 7a:ec:b7:ec:80:a3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::78ec:b7ff:feec:80a3/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:a1:2f:ef:aa:89 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::2ca1:2fff:feef:aa89/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc8f6e9364cda2@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:4e:64:8e:e7:5b brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::c4e:64ff:fe8e:e75b/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc3a63c7a6f5a3@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:a0:1b:d0:b5:ca brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::a8a0:1bff:fed0:b5ca/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcb962e668555f@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:0d:43:94:21:fb brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::d00d:43ff:fe94:21fb/64 scope link 
       valid_lft forever preferred_lft forever
