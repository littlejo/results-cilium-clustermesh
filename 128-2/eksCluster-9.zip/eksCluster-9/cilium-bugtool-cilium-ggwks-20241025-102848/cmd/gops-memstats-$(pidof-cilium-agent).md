alloc: 90.27MB (94653312 bytes)
total-alloc: 1.32GB (1421932104 bytes)
sys: 206.13MB (216147284 bytes)
lookups: 0
mallocs: 47595743
frees: 46815277
heap-alloc: 90.27MB (94653312 bytes)
heap-sys: 161.36MB (169197568 bytes)
heap-idle: 40.04MB (41984000 bytes)
heap-in-use: 121.32MB (127213568 bytes)
heap-released: 576.00KB (589824 bytes)
heap-objects: 780466
stack-in-use: 34.59MB (36274176 bytes)
stack-sys: 34.59MB (36274176 bytes)
stack-mspan-inuse: 1.99MB (2088000 bytes)
stack-mspan-sys: 2.43MB (2545920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 675.49KB (691705 bytes)
gc-sys: 5.18MB (5435720 bytes)
next-gc: when heap-alloc >= 146.21MB (153312248 bytes)
last-gc: 2024-10-25 10:29:03.048231985 +0000 UTC
gc-pause-total: 17.421618ms
gc-pause: 82339
gc-pause-end: 1729852143048231985
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00035874087784434184
enable-gc: true
debug-gc: false
