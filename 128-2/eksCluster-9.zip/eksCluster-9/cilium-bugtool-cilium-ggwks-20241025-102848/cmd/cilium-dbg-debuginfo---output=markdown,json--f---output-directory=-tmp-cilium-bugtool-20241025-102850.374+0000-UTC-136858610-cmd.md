markdown output at /tmp/cilium-bugtool-20241025-102850.374+0000-UTC-136858610/cmd/cilium-debuginfo-20241025-102920.874+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102850.374+0000-UTC-136858610/cmd/cilium-debuginfo-20241025-102920.874+0000-UTC.json
