Total: 547
TCP:   1071 (estab 297, closed 755, orphaned 0, timewait 304)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  316       305       11       
INET	  326       311       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:42887      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:23889 sk:261 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.208.120%ens5:68         0.0.0.0:*    uid:192 ino:14247 sk:262 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:24027 sk:263 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15531 sk:264 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:24026 sk:265 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15532 sk:266 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::8f9:d0ff:fe3f:b76b]%ens5:546           [::]:*    uid:192 ino:15801 sk:267 cgroup:unreachable:c4e v6only:1 <->                   
