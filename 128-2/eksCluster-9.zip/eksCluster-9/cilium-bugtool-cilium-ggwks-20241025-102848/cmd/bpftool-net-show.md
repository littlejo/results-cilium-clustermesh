xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 541
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 539
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 533
cilium_host(4) clsact/egress cil_from_host-cilium_host id 532
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 459
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 458
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 505
lxcd52313923628(9) clsact/ingress cil_from_container-lxcd52313923628 id 493
lxcf476fed52d73(11) clsact/ingress cil_from_container-lxcf476fed52d73 id 520
lxcadbaa1b3a82f(15) clsact/ingress cil_from_container-lxcadbaa1b3a82f id 595

flow_dissector:

netfilter:

