REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     210776    98951247   1132   bpf_host.c
Interface                 INGRESS     9620      750714     677    bpf_overlay.c
Success                   EGRESS      4633      353219     1694   bpf_host.c
Success                   EGRESS      87492     11932748   1308   bpf_lxc.c
Success                   EGRESS      9414      736549     53     encap.h
Success                   INGRESS     104294    12422020   235    trace.h
Success                   INGRESS     98658     11980619   86     l3.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
