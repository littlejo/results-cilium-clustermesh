key: 14 01 00 00  value: 4e 02 00 00
key: ac 01 00 00  value: f7 01 00 00
key: c2 02 00 00  value: 00 02 00 00
key: fc 0f 00 00  value: ee 01 00 00
Found 4 elements
