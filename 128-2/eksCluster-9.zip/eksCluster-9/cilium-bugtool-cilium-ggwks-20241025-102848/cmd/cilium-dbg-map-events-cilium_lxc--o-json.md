{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:01.937Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.208.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:01.937Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:05.205Z",
  "value": "id=4092  sec_id=668279 flags=0x0000 ifindex=9   mac=06:55:58:22:10:02 nodemac=BE:19:97:C0:70:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:08.475Z",
  "value": "id=428   sec_id=4     flags=0x0000 ifindex=7   mac=F6:0C:8C:65:18:A6 nodemac=FA:D7:E4:4D:90:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:08.482Z",
  "value": "id=706   sec_id=668279 flags=0x0000 ifindex=11  mac=3A:56:B8:90:5E:15 nodemac=9E:62:01:2A:F1:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:08.555Z",
  "value": "id=4092  sec_id=668279 flags=0x0000 ifindex=9   mac=06:55:58:22:10:02 nodemac=BE:19:97:C0:70:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:08.591Z",
  "value": "id=428   sec_id=4     flags=0x0000 ifindex=7   mac=F6:0C:8C:65:18:A6 nodemac=FA:D7:E4:4D:90:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:08.635Z",
  "value": "id=706   sec_id=668279 flags=0x0000 ifindex=11  mac=3A:56:B8:90:5E:15 nodemac=9E:62:01:2A:F1:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:55.128Z",
  "value": "id=428   sec_id=4     flags=0x0000 ifindex=7   mac=F6:0C:8C:65:18:A6 nodemac=FA:D7:E4:4D:90:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:55.128Z",
  "value": "id=4092  sec_id=668279 flags=0x0000 ifindex=9   mac=06:55:58:22:10:02 nodemac=BE:19:97:C0:70:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:55.129Z",
  "value": "id=706   sec_id=668279 flags=0x0000 ifindex=11  mac=3A:56:B8:90:5E:15 nodemac=9E:62:01:2A:F1:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:55.162Z",
  "value": "id=154   sec_id=680340 flags=0x0000 ifindex=13  mac=F2:FD:B7:87:70:B6 nodemac=FA:28:47:82:48:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:56.127Z",
  "value": "id=4092  sec_id=668279 flags=0x0000 ifindex=9   mac=06:55:58:22:10:02 nodemac=BE:19:97:C0:70:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:56.128Z",
  "value": "id=706   sec_id=668279 flags=0x0000 ifindex=11  mac=3A:56:B8:90:5E:15 nodemac=9E:62:01:2A:F1:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:56.128Z",
  "value": "id=154   sec_id=680340 flags=0x0000 ifindex=13  mac=F2:FD:B7:87:70:B6 nodemac=FA:28:47:82:48:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:56.128Z",
  "value": "id=428   sec_id=4     flags=0x0000 ifindex=7   mac=F6:0C:8C:65:18:A6 nodemac=FA:D7:E4:4D:90:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:55.860Z",
  "value": "id=276   sec_id=680340 flags=0x0000 ifindex=15  mac=42:0D:21:7A:09:16 nodemac=12:66:78:6F:36:5C"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.9.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:00.490Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:32.215Z",
  "value": "id=4092  sec_id=668279 flags=0x0000 ifindex=9   mac=06:55:58:22:10:02 nodemac=BE:19:97:C0:70:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:32.218Z",
  "value": "id=706   sec_id=668279 flags=0x0000 ifindex=11  mac=3A:56:B8:90:5E:15 nodemac=9E:62:01:2A:F1:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:32.219Z",
  "value": "id=428   sec_id=4     flags=0x0000 ifindex=7   mac=F6:0C:8C:65:18:A6 nodemac=FA:D7:E4:4D:90:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:32.219Z",
  "value": "id=276   sec_id=680340 flags=0x0000 ifindex=15  mac=42:0D:21:7A:09:16 nodemac=12:66:78:6F:36:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:33.199Z",
  "value": "id=276   sec_id=680340 flags=0x0000 ifindex=15  mac=42:0D:21:7A:09:16 nodemac=12:66:78:6F:36:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:33.200Z",
  "value": "id=4092  sec_id=668279 flags=0x0000 ifindex=9   mac=06:55:58:22:10:02 nodemac=BE:19:97:C0:70:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:33.200Z",
  "value": "id=706   sec_id=668279 flags=0x0000 ifindex=11  mac=3A:56:B8:90:5E:15 nodemac=9E:62:01:2A:F1:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:33.200Z",
  "value": "id=428   sec_id=4     flags=0x0000 ifindex=7   mac=F6:0C:8C:65:18:A6 nodemac=FA:D7:E4:4D:90:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:34.200Z",
  "value": "id=276   sec_id=680340 flags=0x0000 ifindex=15  mac=42:0D:21:7A:09:16 nodemac=12:66:78:6F:36:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:34.200Z",
  "value": "id=4092  sec_id=668279 flags=0x0000 ifindex=9   mac=06:55:58:22:10:02 nodemac=BE:19:97:C0:70:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:34.200Z",
  "value": "id=706   sec_id=668279 flags=0x0000 ifindex=11  mac=3A:56:B8:90:5E:15 nodemac=9E:62:01:2A:F1:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.9.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:34.200Z",
  "value": "id=428   sec_id=4     flags=0x0000 ifindex=7   mac=F6:0C:8C:65:18:A6 nodemac=FA:D7:E4:4D:90:FC"
}

