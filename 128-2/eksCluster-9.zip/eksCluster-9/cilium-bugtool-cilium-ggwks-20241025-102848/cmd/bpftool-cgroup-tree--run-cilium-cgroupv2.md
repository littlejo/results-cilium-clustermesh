CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod80a12207_547e_4f5a_a307_c4a8b6c3d8a9.slice/cri-containerd-0dcded4fbf585698e656ef905c4db2f4ce826f7cb39e17b861c2fe8d99164817.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod80a12207_547e_4f5a_a307_c4a8b6c3d8a9.slice/cri-containerd-9d9be605fc024eacd0ca7f818a58d11c0b9326a314b9fe46fd8a14d27a17cae7.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod914f4941_38d2_4837_9e4b_053398741c61.slice/cri-containerd-b2d78fc2f5216a3000149b6e5487120ffcaf0b6ae605895c17019dbdb6839d53.scope
    455      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod914f4941_38d2_4837_9e4b_053398741c61.slice/cri-containerd-b83294a1a14b0234985cb23925a3c5d4c68e5195949cc1775809f08d2ee9666e.scope
    463      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4cff9f6a_82c7_4883_b929_175236816ab4.slice/cri-containerd-4dce5463aae584fd0d80c2cd4913cdf1e45791b717cfd400d34f20a50aa1b3ea.scope
    511      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4cff9f6a_82c7_4883_b929_175236816ab4.slice/cri-containerd-e20042903e2e5283224fb0151124dbeb31232f1ebd827055bc34a25f5f1d2b45.scope
    526      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1e61c2f9_e831_4cfe_b074_94b95b653e95.slice/cri-containerd-39aa691f3f2b8c007991e2a62f5cab67cb871bcce31c0de672e80d6465093d1d.scope
    100      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1e61c2f9_e831_4cfe_b074_94b95b653e95.slice/cri-containerd-a46b4c121b0ff7eef092f3c03b480db05a92f22fb591c5951e95407da3a429bd.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec109259_4ac3_4e5f_9df8_720d9d05e945.slice/cri-containerd-eb5ba8c372393c81f5c02f74612423ccada01fbbd9aa0b504a48cde1ce947f80.scope
    62       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec109259_4ac3_4e5f_9df8_720d9d05e945.slice/cri-containerd-1f7fa5aad86ef732b7e6dbf06021c5bb49761a38abcf748c427e47ce370852a2.scope
    69       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4a703a04_b13d_466a_ad02_d205f2f8563f.slice/cri-containerd-78099c260d2b7bb97e99730398de3b2aa89c288f30aa98b347e81b5b2cd39ae2.scope
    73       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4a703a04_b13d_466a_ad02_d205f2f8563f.slice/cri-containerd-8f2a56410dcff6781975a9bff2b540340b90fc1fb84094f2359a206a5cef87fb.scope
    58       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36bc6b11_abcc_4fa2_a547_011799d0b0f6.slice/cri-containerd-a43f35e1dad690965ccd9c7eb1de2b7e93f36e0b568010fc367d2385ede07717.scope
    625      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36bc6b11_abcc_4fa2_a547_011799d0b0f6.slice/cri-containerd-321fa3348d8ef96aaad5305aabdd018f58ef90957e2f485f6dc4fab63091bc11.scope
    617      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36bc6b11_abcc_4fa2_a547_011799d0b0f6.slice/cri-containerd-35078e172bc8ad76998ae2879af87a21e88a5d9fcd5a2d637a0afaac4a357567.scope
    621      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36bc6b11_abcc_4fa2_a547_011799d0b0f6.slice/cri-containerd-747922a5b2a0cc3b25d6427694f2397a5b5a2f1e432a7c1f01a3c694434c02c7.scope
    601      cgroup_device   multi                                          
