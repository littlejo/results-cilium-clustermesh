1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:f9:d0:3f:b7:6b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.208.120/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2666sec preferred_lft 2666sec
    inet6 fe80::8f9:d0ff:fe3f:b76b/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:7a:b0:c0:f0:5f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::fc7a:b0ff:fec0:f05f/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:e7:24:7d:28:75 brd ff:ff:ff:ff:ff:ff
    inet 10.9.0.186/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::dce7:24ff:fe7d:2875/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether d6:1d:f1:fd:88:49 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d41d:f1ff:fefd:8849/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:d7:e4:4d:90:fc brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f8d7:e4ff:fe4d:90fc/64 scope link 
       valid_lft forever preferred_lft forever
9: lxcd52313923628@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:19:97:c0:70:17 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::bc19:97ff:fec0:7017/64 scope link 
       valid_lft forever preferred_lft forever
11: lxcf476fed52d73@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:62:01:2a:f1:bc brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::9c62:1ff:fe2a:f1bc/64 scope link 
       valid_lft forever preferred_lft forever
15: lxcadbaa1b3a82f@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:66:78:6f:36:5c brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::1066:78ff:fe6f:365c/64 scope link 
       valid_lft forever preferred_lft forever
