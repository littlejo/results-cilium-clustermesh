IP ADDRESS         LOCAL ENDPOINT INFO
10.9.0.233:0       id=428   sec_id=4     flags=0x0000 ifindex=7   mac=F6:0C:8C:65:18:A6 nodemac=FA:D7:E4:4D:90:FC    
10.9.0.186:0       (localhost)                                                                                       
10.9.0.214:0       id=706   sec_id=668279 flags=0x0000 ifindex=11  mac=3A:56:B8:90:5E:15 nodemac=9E:62:01:2A:F1:BC   
10.9.0.100:0       id=276   sec_id=680340 flags=0x0000 ifindex=15  mac=42:0D:21:7A:09:16 nodemac=12:66:78:6F:36:5C   
10.9.0.64:0        id=4092  sec_id=668279 flags=0x0000 ifindex=9   mac=06:55:58:22:10:02 nodemac=BE:19:97:C0:70:17   
172.31.208.120:0   (localhost)                                                                                       
