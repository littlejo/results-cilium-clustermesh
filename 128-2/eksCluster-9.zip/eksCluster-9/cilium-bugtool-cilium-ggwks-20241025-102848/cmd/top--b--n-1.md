top - 10:28:50 up 15 min,  0 users,  load average: 0.10, 0.12, 0.14
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 17.9 us, 21.4 sy,  0.0 ni, 57.1 id,  0.0 wa,  0.0 hi,  3.6 si,  0.0 st
MiB Mem :   3836.2 total,   1187.4 free,    892.2 used,   1756.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2775.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1537844 282200  78656 S  13.3   7.2   0:24.39 cilium-+
    685 root      20   0 1240176  16524  11356 S   6.7   0.4   0:00.03 cilium-+
    391 root      20   0 1228848   5752   2864 S   0.0   0.1   0:00.28 cilium-+
    655 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    661 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    667 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    711 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    729 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
