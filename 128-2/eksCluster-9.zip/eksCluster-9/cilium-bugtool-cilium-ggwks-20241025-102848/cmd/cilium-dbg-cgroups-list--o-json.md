[
  {
    "containers": [
      {
        "cgroup-id": 6873,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4cff9f6a_82c7_4883_b929_175236816ab4.slice/cri-containerd-e20042903e2e5283224fb0151124dbeb31232f1ebd827055bc34a25f5f1d2b45.scope"
      }
    ],
    "ips": [
      "10.9.0.214"
    ],
    "name": "coredns-cc6ccd49c-5wrnq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8301,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36bc6b11_abcc_4fa2_a547_011799d0b0f6.slice/cri-containerd-35078e172bc8ad76998ae2879af87a21e88a5d9fcd5a2d637a0afaac4a357567.scope"
      },
      {
        "cgroup-id": 8217,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36bc6b11_abcc_4fa2_a547_011799d0b0f6.slice/cri-containerd-321fa3348d8ef96aaad5305aabdd018f58ef90957e2f485f6dc4fab63091bc11.scope"
      },
      {
        "cgroup-id": 8385,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36bc6b11_abcc_4fa2_a547_011799d0b0f6.slice/cri-containerd-a43f35e1dad690965ccd9c7eb1de2b7e93f36e0b568010fc367d2385ede07717.scope"
      }
    ],
    "ips": [
      "10.9.0.100"
    ],
    "name": "clustermesh-apiserver-5bb46d8484-bgjqh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6705,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod914f4941_38d2_4837_9e4b_053398741c61.slice/cri-containerd-b83294a1a14b0234985cb23925a3c5d4c68e5195949cc1775809f08d2ee9666e.scope"
      }
    ],
    "ips": [
      "10.9.0.64"
    ],
    "name": "coredns-cc6ccd49c-8fb42",
    "namespace": "kube-system"
  }
]

