ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.172.219:443 (active)    
                                        2 => 172.31.221.149:443 (active)    
2    10.100.60.8:443     ClusterIP      1 => 172.31.208.120:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.9.0.64:53 (active)          
                                        2 => 10.9.0.214:53 (active)         
4    10.100.0.10:9153    ClusterIP      1 => 10.9.0.64:9153 (active)        
                                        2 => 10.9.0.214:9153 (active)       
5    10.100.254.9:2379   ClusterIP      1 => 10.9.0.100:2379 (active)       
