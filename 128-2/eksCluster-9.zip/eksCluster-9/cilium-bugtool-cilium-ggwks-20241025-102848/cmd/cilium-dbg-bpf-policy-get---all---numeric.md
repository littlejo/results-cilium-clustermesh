Endpoint ID: 276
Path: /sys/fs/bpf/tc/globals/cilium_policy_00276

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3896745   36079     0        
Allow    Ingress     1          ANY          NONE         disabled    2851039   28580     0        
Allow    Egress      0          ANY          NONE         disabled    3862156   36151     0        


Endpoint ID: 428
Path: /sys/fs/bpf/tc/globals/cilium_policy_00428

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    442492   5651      0        
Allow    Ingress     1          ANY          NONE         disabled    11880    138       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 706
Path: /sys/fs/bpf/tc/globals/cilium_policy_00706

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    80665   931       0        
Allow    Egress      0          ANY          NONE         disabled    13381   139       0        


Endpoint ID: 1460
Path: /sys/fs/bpf/tc/globals/cilium_policy_01460

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 4092
Path: /sys/fs/bpf/tc/globals/cilium_policy_04092

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    79642   918       0        
Allow    Egress      0          ANY          NONE         disabled    13101   135       0        


