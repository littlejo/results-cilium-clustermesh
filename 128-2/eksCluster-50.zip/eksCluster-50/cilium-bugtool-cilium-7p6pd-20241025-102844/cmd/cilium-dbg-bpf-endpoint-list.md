IP ADDRESS        LOCAL ENDPOINT INFO
10.50.0.31:0      (localhost)                                                                                        
10.50.0.95:0      id=1373  sec_id=3368997 flags=0x0000 ifindex=15  mac=F2:59:3F:19:3D:F1 nodemac=AA:2E:08:F4:33:16   
172.31.144.60:0   (localhost)                                                                                        
10.50.0.78:0      id=2775  sec_id=3346695 flags=0x0000 ifindex=11  mac=5E:77:A3:FE:DC:13 nodemac=EA:8B:AD:D6:F0:9D   
10.50.0.227:0     id=2840  sec_id=4     flags=0x0000 ifindex=7   mac=4E:48:23:76:DA:9B nodemac=7A:B7:6F:8B:1E:CE     
10.50.0.183:0     id=1274  sec_id=3346695 flags=0x0000 ifindex=9   mac=D2:F5:C5:7A:D3:64 nodemac=26:17:8A:9B:87:45   
