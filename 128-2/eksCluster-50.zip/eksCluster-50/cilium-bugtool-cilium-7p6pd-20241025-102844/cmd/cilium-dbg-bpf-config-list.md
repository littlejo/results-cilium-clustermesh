KEY             VALUE
AgentLiveness   953369110052
UTimeOffset     3378615630859375
