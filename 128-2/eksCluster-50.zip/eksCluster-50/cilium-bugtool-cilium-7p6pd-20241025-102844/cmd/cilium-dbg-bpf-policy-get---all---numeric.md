Endpoint ID: 284
Path: /sys/fs/bpf/tc/globals/cilium_policy_00284

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1274
Path: /sys/fs/bpf/tc/globals/cilium_policy_01274

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83985   961       0        
Allow    Egress      0          ANY          NONE         disabled    13284   139       0        


Endpoint ID: 1373
Path: /sys/fs/bpf/tc/globals/cilium_policy_01373

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3887630   35967     0        
Allow    Ingress     1          ANY          NONE         disabled    2985553   29989     0        
Allow    Egress      0          ANY          NONE         disabled    3957120   36790     0        


Endpoint ID: 2775
Path: /sys/fs/bpf/tc/globals/cilium_policy_02775

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    84008   964       0        
Allow    Egress      0          ANY          NONE         disabled    13946   146       0        


Endpoint ID: 2840
Path: /sys/fs/bpf/tc/globals/cilium_policy_02840

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    444160   5683      0        
Allow    Ingress     1          ANY          NONE         disabled    11636    134       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


