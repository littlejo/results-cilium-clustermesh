filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxccfea460b77d2 direct-action not_in_hw id 529 tag 36dccaf377e56425 jited 
