# Cilium debug information

#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
284        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                
                                                           reserved:host                                                                                             
1274       Disabled           Disabled          3346695    k8s:eks.amazonaws.com/component=coredns                                             10.50.0.183   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh51                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
1373       Disabled           Disabled          3368997    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.50.0.95    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh51                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
2775       Disabled           Disabled          3346695    k8s:eks.amazonaws.com/component=coredns                                             10.50.0.78    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh51                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
2840       Disabled           Disabled          4          reserved:health                                                                     10.50.0.227   ready   
```

#### BPF Policy Get 284

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 284

```
Invalid argument: unknown type 284
```


#### Endpoint Get 284

```
[
  {
    "id": 284,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-284-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "66c5d28a-fa07-42c9-8299-13f217f84e3c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-284",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:17.025Z",
            "success-count": 3
          },
          "uuid": "535d87c3-accf-464c-b666-5d31d83f4595"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-284",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:18.138Z",
            "success-count": 1
          },
          "uuid": "e956c5be-b519-4606-aa22-8846cbff197c"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:10Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "96:1c:97:c7:34:80",
        "interface-name": "cilium_host",
        "mac": "96:1c:97:c7:34:80"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 284

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 284

```
Timestamp              Status   State                   Message
2024-10-25T10:23:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:10Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:14:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:14:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:19Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:14:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:14:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:17Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:17Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:17Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 1274

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83985   961       0        
Allow    Egress      0          ANY          NONE         disabled    13284   139       0        

```


#### BPF CT List 1274

```
Invalid argument: unknown type 1274
```


#### Endpoint Get 1274

```
[
  {
    "id": 1274,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1274-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7a0d155d-f610-41f7-9112-17f4482903d7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1274",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:19.923Z",
            "success-count": 3
          },
          "uuid": "6e5ee48f-5e3b-4caf-acc4-9e8016700e25"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-d4mtw",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:19.922Z",
            "success-count": 1
          },
          "uuid": "457a75ce-21bd-4740-9463-8fabc65c79a8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1274",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:21.527Z",
            "success-count": 1
          },
          "uuid": "061dce8f-7006-402e-a2a5-648b1a33408b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1274)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:10.013Z",
            "success-count": 91
          },
          "uuid": "cf69de99-bb8e-4f97-a552-276b2bf0dadf"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "e27c8b9de7ad8fdf321bdcb6efb67211c349571a65ee2861d50c141dec611519:eth0",
        "container-id": "e27c8b9de7ad8fdf321bdcb6efb67211c349571a65ee2861d50c141dec611519",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-d4mtw",
        "pod-name": "kube-system/coredns-cc6ccd49c-d4mtw"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3346695,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh51",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh51",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:10Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.50.0.183",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "26:17:8a:9b:87:45",
        "interface-index": 9,
        "interface-name": "lxc14374704f890",
        "mac": "d2:f5:c5:7a:d3:64"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3346695,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3346695,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1274

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1274

```
Timestamp              Status   State                   Message
2024-10-25T10:23:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:10Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:21Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:20Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:14:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:19Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:19Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3346695

```
ID        LABELS
3346695   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh51
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1373

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3875396   35835     0        
Allow    Ingress     1          ANY          NONE         disabled    2985553   29989     0        
Allow    Egress      0          ANY          NONE         disabled    3955534   36772     0        

```


#### BPF CT List 1373

```
Invalid argument: unknown type 1373
```


#### Endpoint Get 1373

```
[
  {
    "id": 1373,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1373-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "1f1c37d2-47b2-4cdc-8472-c6c21669c101"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1373",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:45.099Z",
            "success-count": 2
          },
          "uuid": "1b930c6f-ee1e-409a-b3e2-8a9238baa8d1"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-784f4468dc-ljjgm",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:45.097Z",
            "success-count": 1
          },
          "uuid": "7e7e6655-b209-4e3c-b3c8-54da345c8b81"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1373",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:45.138Z",
            "success-count": 1
          },
          "uuid": "1472bf52-eda2-49ba-ba10-aa008716186b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1373)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:15.141Z",
            "success-count": 41
          },
          "uuid": "d9443b94-21a0-4487-982a-e2e31184bda6"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "e24f875bd4759e21cbb12fa45fde476a37a083080d195babd0f44ccdc8a6bf12:eth0",
        "container-id": "e24f875bd4759e21cbb12fa45fde476a37a083080d195babd0f44ccdc8a6bf12",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-784f4468dc-ljjgm",
        "pod-name": "kube-system/clustermesh-apiserver-784f4468dc-ljjgm"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3368997,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh51",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=784f4468dc"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh51",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:10Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.50.0.95",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "aa:2e:08:f4:33:16",
        "interface-index": 15,
        "interface-name": "lxc047857984eb0",
        "mac": "f2:59:3f:19:3d:f1"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3368997,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3368997,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1373

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1373

```
Timestamp              Status   State                   Message
2024-10-25T10:23:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:10Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:22:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:45Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:22:45Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:22:45Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3368997

```
ID        LABELS
3368997   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh51
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 2775

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    84008   964       0        
Allow    Egress      0          ANY          NONE         disabled    13775   144       0        

```


#### BPF CT List 2775

```
Invalid argument: unknown type 2775
```


#### Endpoint Get 2775

```
[
  {
    "id": 2775,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2775-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "4253e2e8-37e9-4b6a-b727-a8ad854571b1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2775",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:22.857Z",
            "success-count": 3
          },
          "uuid": "a0bdd937-959f-421b-9322-c0373566d999"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-mp9cd",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:22.856Z",
            "success-count": 1
          },
          "uuid": "7e3c2f29-3cd8-41bc-a192-330f8be04b51"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2775",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:22.890Z",
            "success-count": 1
          },
          "uuid": "858f52d7-2c16-4561-b701-5e68c4659ff1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2775)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:12.931Z",
            "success-count": 91
          },
          "uuid": "9b895afe-1a11-4f44-9495-7b80d1754c00"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "0e49646ecda9d40a79ef781676b003407bf56cbcb54d1d9340eed0ae8671bbbe:eth0",
        "container-id": "0e49646ecda9d40a79ef781676b003407bf56cbcb54d1d9340eed0ae8671bbbe",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-mp9cd",
        "pod-name": "kube-system/coredns-cc6ccd49c-mp9cd"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3346695,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh51",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh51",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:10Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.50.0.78",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ea:8b:ad:d6:f0:9d",
        "interface-index": 11,
        "interface-name": "lxccfea460b77d2",
        "mac": "5e:77:a3:fe:dc:13"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3346695,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3346695,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2775

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2775

```
Timestamp              Status   State                   Message
2024-10-25T10:23:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:10Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:22Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:22Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:22Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3346695

```
ID        LABELS
3346695   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh51
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 2840

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    444102   5682      0        
Allow    Ingress     1          ANY          NONE         disabled    11636    134       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 2840

```
Invalid argument: unknown type 2840
```


#### Endpoint Get 2840

```
[
  {
    "id": 2840,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2840-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "15e290c3-5de8-43b7-aaa9-fb486a668e1a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2840",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:18.064Z",
            "success-count": 4
          },
          "uuid": "94058cee-f39f-4b37-8a9a-d93348f861c2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2840",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:21.533Z",
            "success-count": 1
          },
          "uuid": "74a83da4-fdf5-44b6-83c8-c01d710c6437"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:10Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.50.0.227",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "7a:b7:6f:8b:1e:ce",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "4e:48:23:76:da:9b"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2840

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2840

```
Timestamp              Status   State                   Message
2024-10-25T10:23:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:10Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:14:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:21Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:14:21Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:14:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:14:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:14:18Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:18Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:17Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 37768797                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 37768797                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 37768797                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400c000000 rw-p 00000000 00:00 0 
ffff3e504000-ffff3e6c9000 rw-p 00000000 00:00 0 
ffff3e6d1000-ffff3e7f2000 rw-p 00000000 00:00 0 
ffff3e7f2000-ffff3e833000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff3e833000-ffff3e874000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff3e874000-ffff3e8b4000 rw-p 00000000 00:00 0 
ffff3e8b4000-ffff3e8b6000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff3e8b6000-ffff3e8b8000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff3e8b8000-ffff3ee7f000 rw-p 00000000 00:00 0 
ffff3ee7f000-ffff3ef7f000 rw-p 00000000 00:00 0 
ffff3ef7f000-ffff3ef90000 rw-p 00000000 00:00 0 
ffff3ef90000-ffff40f90000 rw-p 00000000 00:00 0 
ffff40f90000-ffff41010000 ---p 00000000 00:00 0 
ffff41010000-ffff41011000 rw-p 00000000 00:00 0 
ffff41011000-ffff61010000 ---p 00000000 00:00 0 
ffff61010000-ffff61011000 rw-p 00000000 00:00 0 
ffff61011000-ffff80fa0000 ---p 00000000 00:00 0 
ffff80fa0000-ffff80fa1000 rw-p 00000000 00:00 0 
ffff80fa1000-ffff84f92000 ---p 00000000 00:00 0 
ffff84f92000-ffff84f93000 rw-p 00000000 00:00 0 
ffff84f93000-ffff85790000 ---p 00000000 00:00 0 
ffff85790000-ffff85791000 rw-p 00000000 00:00 0 
ffff85791000-ffff85890000 ---p 00000000 00:00 0 
ffff85890000-ffff858f0000 rw-p 00000000 00:00 0 
ffff858f0000-ffff858f2000 r--p 00000000 00:00 0                          [vvar]
ffff858f2000-ffff858f3000 r-xp 00000000 00:00 0                          [vdso]
ffffe5dc9000-ffffe5dea000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.50.0.0/24, 
Allocated addresses:
  10.50.0.183 (kube-system/coredns-cc6ccd49c-d4mtw)
  10.50.0.227 (health)
  10.50.0.31 (router)
  10.50.0.78 (kube-system/coredns-cc6ccd49c-mp9cd)
  10.50.0.95 (kube-system/clustermesh-apiserver-784f4468dc-ljjgm)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 9ccd1260ca33a3ae
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    59s ago        never        0       no error   
  ct-map-pressure                                                     31s ago        never        0       no error   
  daemon-validate-config                                              47s ago        never        0       no error   
  dns-garbage-collector-job                                           1m4s ago       never        0       no error   
  endpoint-1274-regeneration-recovery                                 never          never        0       no error   
  endpoint-1373-regeneration-recovery                                 never          never        0       no error   
  endpoint-2775-regeneration-recovery                                 never          never        0       no error   
  endpoint-284-regeneration-recovery                                  never          never        0       no error   
  endpoint-2840-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                         5m4s ago       never        0       no error   
  ep-bpf-prog-watchdog                                                31s ago        never        0       no error   
  ipcache-inject-labels                                               1m1s ago       never        0       no error   
  k8s-heartbeat                                                       34s ago        never        0       no error   
  link-cache                                                          16s ago        never        0       no error   
  local-identity-checkpoint                                           14m45s ago     never        0       no error   
  node-neighbor-link-updater                                          11s ago        never        0       no error   
  remote-etcd-cmesh1                                                  6m9s ago       never        0       no error   
  remote-etcd-cmesh10                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh100                                                6m9s ago       never        0       no error   
  remote-etcd-cmesh101                                                6m10s ago      never        0       no error   
  remote-etcd-cmesh102                                                6m10s ago      never        0       no error   
  remote-etcd-cmesh103                                                6m9s ago       never        0       no error   
  remote-etcd-cmesh104                                                6m9s ago       never        0       no error   
  remote-etcd-cmesh105                                                6m9s ago       never        0       no error   
  remote-etcd-cmesh106                                                6m9s ago       never        0       no error   
  remote-etcd-cmesh107                                                6m10s ago      never        0       no error   
  remote-etcd-cmesh108                                                6m10s ago      never        0       no error   
  remote-etcd-cmesh109                                                6m10s ago      never        0       no error   
  remote-etcd-cmesh11                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh110                                                6m10s ago      never        0       no error   
  remote-etcd-cmesh111                                                6m10s ago      never        0       no error   
  remote-etcd-cmesh112                                                6m9s ago       never        0       no error   
  remote-etcd-cmesh113                                                6m10s ago      never        0       no error   
  remote-etcd-cmesh114                                                6m9s ago       never        0       no error   
  remote-etcd-cmesh115                                                6m10s ago      never        0       no error   
  remote-etcd-cmesh116                                                6m9s ago       never        0       no error   
  remote-etcd-cmesh117                                                6m10s ago      never        0       no error   
  remote-etcd-cmesh118                                                6m9s ago       never        0       no error   
  remote-etcd-cmesh119                                                6m9s ago       never        0       no error   
  remote-etcd-cmesh12                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh120                                                6m9s ago       never        0       no error   
  remote-etcd-cmesh121                                                6m10s ago      never        0       no error   
  remote-etcd-cmesh122                                                6m10s ago      never        0       no error   
  remote-etcd-cmesh123                                                6m9s ago       never        0       no error   
  remote-etcd-cmesh124                                                6m9s ago       never        0       no error   
  remote-etcd-cmesh125                                                6m9s ago       never        0       no error   
  remote-etcd-cmesh126                                                6m9s ago       never        0       no error   
  remote-etcd-cmesh127                                                6m9s ago       never        0       no error   
  remote-etcd-cmesh128                                                6m10s ago      never        0       no error   
  remote-etcd-cmesh13                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh14                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh15                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh16                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh17                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh18                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh19                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh2                                                  6m9s ago       never        0       no error   
  remote-etcd-cmesh20                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh21                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh22                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh23                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh24                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh25                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh26                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh27                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh28                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh29                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh3                                                  6m9s ago       never        0       no error   
  remote-etcd-cmesh30                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh31                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh32                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh33                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh34                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh35                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh36                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh37                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh38                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh39                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh4                                                  6m9s ago       never        0       no error   
  remote-etcd-cmesh40                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh41                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh42                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh43                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh44                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh45                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh46                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh47                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh48                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh49                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh5                                                  6m10s ago      never        0       no error   
  remote-etcd-cmesh50                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh52                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh53                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh54                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh55                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh56                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh57                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh58                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh59                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh6                                                  6m9s ago       never        0       no error   
  remote-etcd-cmesh60                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh61                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh62                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh63                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh64                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh65                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh66                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh67                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh68                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh69                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh7                                                  6m10s ago      never        0       no error   
  remote-etcd-cmesh70                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh71                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh72                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh73                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh74                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh75                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh76                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh77                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh78                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh79                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh8                                                  6m10s ago      never        0       no error   
  remote-etcd-cmesh80                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh81                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh82                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh83                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh84                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh85                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh86                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh87                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh88                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh89                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh9                                                  6m9s ago       never        0       no error   
  remote-etcd-cmesh90                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh91                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh92                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh93                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh94                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh95                                                 6m9s ago       never        0       no error   
  remote-etcd-cmesh96                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh97                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh98                                                 6m10s ago      never        0       no error   
  remote-etcd-cmesh99                                                 6m9s ago       never        0       no error   
  resolve-identity-1274                                               4m58s ago      never        0       no error   
  resolve-identity-1373                                               1m33s ago      never        0       no error   
  resolve-identity-2775                                               4m55s ago      never        0       no error   
  resolve-identity-284                                                5m1s ago       never        0       no error   
  resolve-identity-2840                                               5m0s ago       never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-784f4468dc-ljjgm   6m33s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-d4mtw                  14m58s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-mp9cd                  14m55s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      15m1s ago      never        0       no error   
  sync-policymap-1274                                                 14m57s ago     never        0       no error   
  sync-policymap-1373                                                 6m33s ago      never        0       no error   
  sync-policymap-2775                                                 14m55s ago     never        0       no error   
  sync-policymap-284                                                  15m0s ago      never        0       no error   
  sync-policymap-2840                                                 14m57s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (1274)                                   8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1373)                                   13s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2775)                                   15s ago        never        0       no error   
  sync-utime                                                          1m1s ago       never        0       no error   
  write-cni-file                                                      15m4s ago      never        0       no error   
Proxy Status:            OK, ip 10.50.0.31, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 3342336, max 3407871
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 68.55   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
enable-custom-calls:false
hubble-skip-unknown-cgroup-ids:true
enable-srv6:false
lib-dir:/var/lib/cilium
tofqdns-proxy-port:0
enable-ipv6-big-tcp:false
l2-announcements-lease-duration:15s
bpf-nat-global-max:524288
ipam-cilium-node-update-rate:15s
unmanaged-pod-watcher-interval:15
enable-ipv6-ndp:false
ipv6-native-routing-cidr:
tofqdns-pre-cache:
node-labels:
bpf-root:/sys/fs/bpf
enable-cilium-health-api-server-access:
enable-endpoint-routes:false
enable-health-check-nodeport:true
dnsproxy-socket-linger-timeout:10
cluster-pool-ipv4-mask-size:24
enable-bpf-tproxy:false
node-port-acceleration:disabled
node-port-algorithm:random
bpf-lb-source-range-map-max:0
k8s-require-ipv6-pod-cidr:false
envoy-log:
gateway-api-secrets-namespace:
nodes-gc-interval:5m0s
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
clustermesh-enable-mcs-api:false
bpf-ct-timeout-service-tcp-grace:1m0s
cflags:
enable-ip-masq-agent:false
enable-ipv4-egress-gateway:false
config-sources:config-map:kube-system/cilium-config
ingress-secrets-namespace:
version:false
mesh-auth-queue-size:1024
enable-external-ips:false
enable-unreachable-routes:false
k8s-kubeconfig-path:
bpf-policy-map-full-reconciliation-interval:15m0s
l2-announcements-retry-period:2s
enable-stale-cilium-endpoint-cleanup:true
max-connected-clusters:255
bpf-lb-sock-terminate-pod-connections:false
hubble-export-allowlist:
node-port-bind-protection:true
kvstore-lease-ttl:15m0s
k8s-api-server:
static-cnp-path:
policy-queue-size:100
agent-labels:
hubble-listen-address::4244
metrics:
max-controller-interval:0
derive-masq-ip-addr-from-device:
bpf-map-dynamic-size-ratio:0.0025
ipv6-cluster-alloc-cidr:f00d::/64
enable-l2-announcements:false
encryption-strict-mode-cidr:
datapath-mode:veth
enable-l2-pod-announcements:false
cluster-health-port:4240
cni-exclusive:true
conntrack-gc-interval:0s
vtep-mask:
k8s-sync-timeout:3m0s
bgp-announce-pod-cidr:false
enable-bpf-masquerade:false
encrypt-node:false
bgp-announce-lb-ip:false
bpf-filter-priority:1
mesh-auth-signal-backoff-duration:1s
hubble-redact-http-headers-allow:
bpf-lb-dsr-dispatch:opt
bpf-lb-rev-nat-map-max:0
tofqdns-max-deferred-connection-deletes:10000
hubble-disable-tls:false
node-port-mode:snat
monitor-queue-size:0
enable-bbr:false
ipsec-key-file:
bgp-config-path:/var/lib/cilium/bgp/config.yaml
enable-icmp-rules:true
mesh-auth-gc-interval:5m0s
k8s-service-cache-size:128
prometheus-serve-addr:
hubble-export-file-path:
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
enable-local-node-route:true
bpf-lb-external-clusterip:false
policy-cidr-match-mode:
enable-xdp-prefilter:false
kube-proxy-replacement:false
enable-ipv6-masquerade:true
dnsproxy-lock-timeout:500ms
use-cilium-internal-ip-for-ipsec:false
enable-node-port:false
hubble-redact-enabled:false
pprof:false
custom-cni-conf:false
enable-ipv4-masquerade:true
mesh-auth-enabled:true
bpf-ct-timeout-service-tcp:2h13m20s
enable-ipsec-xfrm-state-caching:true
disable-envoy-version-check:false
bpf-ct-global-tcp-max:524288
enable-session-affinity:false
proxy-admin-port:0
l2-pod-announcements-interface:
envoy-config-timeout:2m0s
hubble-recorder-storage-path:/var/run/cilium/pcaps
bpf-map-event-buffers:
mesh-auth-mutual-listener-port:0
wireguard-persistent-keepalive:0s
trace-payloadlen:128
state-dir:/var/run/cilium
nodeport-addresses:
enable-hubble:true
bpf-ct-timeout-regular-any:1m0s
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
gops-port:9890
kvstore-connectivity-timeout:2m0s
bpf-events-trace-enabled:true
proxy-idle-timeout-seconds:60
enable-k8s-terminating-endpoint:true
enable-l7-proxy:true
disable-external-ip-mitigation:false
auto-direct-node-routes:false
bpf-lb-dsr-l4-xlate:frontend
bpf-lb-rss-ipv6-src-cidr:
bpf-lb-affinity-map-max:0
proxy-prometheus-port:0
envoy-config-retry-interval:15s
cluster-pool-ipv4-cidr:10.50.0.0/16
hubble-export-file-max-backups:5
enable-node-selector-labels:false
clustermesh-sync-timeout:1m0s
pprof-address:localhost
monitor-aggregation:medium
cilium-endpoint-gc-interval:5m0s
enable-k8s-api-discovery:false
prepend-iptables-chains:true
k8s-namespace:kube-system
external-envoy-proxy:true
k8s-client-qps:10
hubble-export-fieldmask:
endpoint-gc-interval:5m0s
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
config-dir:/tmp/cilium/config-map
disable-iptables-feeder-rules:
enable-health-check-loadbalancer-ip:false
pprof-port:6060
hubble-recorder-sink-queue-size:1024
bpf-ct-timeout-regular-tcp:2h13m20s
node-port-range:
enable-ipv4:true
bpf-lb-mode:snat
enable-host-port:false
proxy-connect-timeout:2
iptables-random-fully:false
nat-map-stats-entries:32
enable-ingress-controller:false
bpf-ct-timeout-regular-tcp-fin:10s
bpf-neigh-global-max:524288
ipv4-range:auto
arping-refresh-period:30s
enable-encryption-strict-mode:false
ipam-default-ip-pool:default
enable-service-topology:false
hubble-export-file-max-size-mb:10
mtu:0
set-cilium-node-taints:true
envoy-secrets-namespace:
force-device-detection:false
bpf-lb-service-backend-map-max:0
restore:true
policy-trigger-interval:1s
cmdref:
set-cilium-is-up-condition:true
kvstore-periodic-sync:5m0s
enable-ipv6:false
envoy-keep-cap-netbindservice:false
cgroup-root:/run/cilium/cgroupv2
keep-config:false
enable-tracing:false
bpf-events-policy-verdict-enabled:true
bpf-lb-sock:false
enable-vtep:false
bpf-lb-maglev-table-size:16381
bypass-ip-availability-upon-restore:false
ipam:cluster-pool
enable-ipv4-fragment-tracking:true
enable-host-firewall:false
enable-runtime-device-detection:true
synchronize-k8s-nodes:true
bpf-policy-map-max:16384
k8s-heartbeat-timeout:30s
socket-path:/var/run/cilium/cilium.sock
enable-policy:default
hubble-prefer-ipv6:false
tunnel-port:0
ipv4-service-loopback-address:169.254.42.1
egress-gateway-reconciliation-trigger-interval:1s
hubble-redact-http-urlquery:false
identity-gc-interval:15m0s
enable-ipsec:false
ipv6-node:auto
enable-l2-neigh-discovery:true
tofqdns-endpoint-max-ip-per-hostname:50
enable-auto-protect-node-port-range:true
tunnel-protocol:vxlan
identity-heartbeat-timeout:30m0s
http-request-timeout:3600
container-ip-local-reserved-ports:auto
bpf-auth-map-max:524288
dns-policy-unload-on-shutdown:false
devices:
clustermesh-enable-endpoint-sync:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
hubble-redact-http-headers-deny:
proxy-xff-num-trusted-hops-ingress:0
label-prefix-file:
enable-ipsec-encrypted-overlay:false
enable-local-redirect-policy:false
log-opt:
allow-localhost:auto
direct-routing-device:
nat-map-stats-interval:30s
certificates-directory:/var/run/cilium/certs
identity-restore-grace-period:30s
enable-route-mtu-for-cni-chaining:false
ipv4-native-routing-cidr:
l2-announcements-renew-deadline:5s
join-cluster:false
bpf-lb-service-map-max:0
k8s-client-connection-keep-alive:30s
endpoint-queue-size:25
srv6-encap-mode:reduced
ip-masq-agent-config-path:/etc/config/ip-masq-agent
ipsec-key-rotation-duration:5m0s
enable-sctp:false
enable-identity-mark:true
enable-envoy-config:false
enable-hubble-recorder-api:true
debug-verbose:
egress-gateway-policy-map-max:16384
mesh-auth-spire-admin-socket:
proxy-max-requests-per-connection:0
log-driver:
k8s-service-proxy-name:
ipv6-range:auto
mke-cgroup-mount:
k8s-require-ipv4-pod-cidr:false
conntrack-gc-max-interval:0s
hubble-metrics-server:
dnsproxy-enable-transparent-mode:true
hubble-flowlogs-config-path:
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
bpf-lb-algorithm:random
egress-multi-home-ip-rule-compat:false
ipv4-node:auto
local-router-ipv4:
read-cni-conf:
iptables-lock-timeout:5s
kube-proxy-replacement-healthz-bind-address:
hubble-export-file-compress:false
egress-masquerade-interfaces:ens+
mesh-auth-spiffe-trust-domain:spiffe.cilium
labels:
hubble-redact-kafka-apikey:false
enable-well-known-identities:false
clustermesh-ip-identities-sync-timeout:1m0s
cni-external-routing:false
tofqdns-min-ttl:0
fixed-identity-mapping:
hubble-monitor-events:
proxy-xff-num-trusted-hops-egress:0
vtep-endpoint:
bpf-events-drop-enabled:true
exclude-local-address:
tofqdns-idle-connection-grace-period:0s
cni-chaining-mode:none
agent-health-port:9879
enable-k8s:true
enable-masquerade-to-route-source:false
multicast-enabled:false
enable-wireguard-userspace-fallback:false
monitor-aggregation-interval:5s
enable-svc-source-range-check:true
vtep-mac:
enable-cilium-api-server-access:
tofqdns-enable-dns-compression:true
k8s-client-burst:20
config:
http-normalize-path:true
envoy-base-id:0
proxy-portrange-max:20000
route-metric:0
allocator-list-timeout:3m0s
bpf-ct-timeout-regular-tcp-syn:1m0s
service-no-backend-response:reject
agent-liveness-update-interval:1s
allow-icmp-frag-needed:true
encrypt-interface:
ipam-multi-pool-pre-allocation:
vlan-bpf-bypass:
tofqdns-dns-reject-response-code:refused
enable-gateway-api:false
enable-ipip-termination:false
enable-high-scale-ipcache:false
bpf-lb-acceleration:disabled
disable-endpoint-crd:false
enable-health-checking:true
k8s-client-connection-timeout:30s
enable-host-legacy-routing:false
preallocate-bpf-maps:false
api-rate-limit:
bpf-lb-sock-hostns-only:false
enable-k8s-networkpolicy:true
ipv4-pod-subnets:
enable-pmtu-discovery:false
dnsproxy-insecure-skip-transparent-mode-check:false
kvstore:
hubble-socket-path:/var/run/cilium/hubble.sock
proxy-gid:1337
cluster-id:51
vtep-cidr:
enable-bgp-control-plane:false
http-retry-timeout:0
enable-ipv4-big-tcp:false
hubble-event-buffer-capacity:4095
dnsproxy-concurrency-limit:0
ipv4-service-range:auto
identity-change-grace-period:5s
bpf-lb-maglev-map-max:0
local-router-ipv6:
log-system-load:false
cluster-name:cmesh51
enable-bandwidth-manager:false
kvstore-max-consecutive-quorum-errors:2
dns-max-ips-per-restored-rule:1000
enable-metrics:true
mesh-auth-rotated-identities-queue-size:1024
debug:false
annotate-k8s-node:false
ipv6-service-range:auto
bpf-node-map-max:16384
bpf-ct-global-any-max:262144
http-max-grpc-timeout:0
kvstore-opt:
operator-prometheus-serve-addr::9963
enable-xt-socket-fallback:true
fqdn-regex-compile-lru-size:1024
dnsproxy-concurrency-processing-grace-period:0s
enable-cilium-endpoint-slice:false
enable-mke:false
enable-tcx:true
enable-ipsec-key-watcher:true
enable-k8s-endpoint-slice:true
hubble-drop-events:false
proxy-max-connection-duration-seconds:0
enable-recorder:false
remove-cilium-node-taints:true
enable-wireguard:false
exclude-node-label-patterns:
procfs:/host/proc
bpf-lb-rss-ipv4-src-cidr:
identity-allocation-mode:crd
hubble-redact-http-userinfo:true
crd-wait-timeout:5m0s
enable-active-connection-tracking:false
proxy-portrange-min:10000
enable-bpf-clock-probe:false
enable-monitor:true
bpf-ct-timeout-service-any:1m0s
bpf-lb-map-max:65536
bpf-fragments-map-max:8192
mesh-auth-mutual-connect-timeout:5s
enable-endpoint-health-checking:true
enable-nat46x64-gateway:false
max-internal-timer-delay:0s
controller-group-metrics:
auto-create-cilium-node-resource:true
ipv6-pod-subnets:
clustermesh-config:/var/lib/cilium/clustermesh/
http-idle-timeout:0
policy-accounting:true
trace-sock:true
encryption-strict-mode-allow-remote-node-identities:false
cni-chaining-target:
endpoint-bpf-prog-watchdog-interval:30s
use-full-tls-context:false
policy-audit-mode:false
cni-log-file:/var/run/cilium/cilium-cni.log
hubble-event-queue-size:0
hubble-metrics:
local-max-addr-scope:252
operator-api-serve-addr:127.0.0.1:9234
install-no-conntrack-iptables-rules:false
http-retry-count:3
tofqdns-proxy-response-max-delay:100ms
direct-routing-skip-unreachable:false
dnsproxy-lock-count:131
ipv6-mcast-device:
monitor-aggregation-flags:all
routing-mode:tunnel
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
install-iptables-rules:true
bpf-sock-rev-map-max:262144
hubble-drop-events-interval:2m0s
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
hubble-export-denylist:
hubble-drop-events-reasons:auth_required,policy_denied
```


#### Service list

```
ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.147.25:443 (active)    
                                          2 => 172.31.232.82:443 (active)    
2    10.100.183.172:443    ClusterIP      1 => 172.31.144.60:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.50.0.183:53 (active)       
                                          2 => 10.50.0.78:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.50.0.183:9153 (active)     
                                          2 => 10.50.0.78:9153 (active)      
5    10.100.183.219:2379   ClusterIP      1 => 10.50.0.95:2379 (active)      
```

#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.50.0.227": (string) (len=6) "health",
  (string) (len=11) "10.50.0.183": (string) (len=35) "kube-system/coredns-cc6ccd49c-d4mtw",
  (string) (len=10) "10.50.0.78": (string) (len=35) "kube-system/coredns-cc6ccd49c-mp9cd",
  (string) (len=10) "10.50.0.95": (string) (len=50) "kube-system/clustermesh-apiserver-784f4468dc-ljjgm",
  (string) (len=10) "10.50.0.31": (string) (len=6) "router"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.144.60": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x400143f4a0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001c45da0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001c45da0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4000668840)(frontends:[10.100.183.172]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x40006688f0)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4003525080)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4001022dc0)(frontends:[10.100.183.219]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4000668790)(frontends:[10.100.0.1]/ports=[https]/selector=map[])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4000d81918)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-zpgc5": (*k8s.Endpoints)(0x40036e6dd0)(10.50.0.95:2379/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x40014b9aa0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4002bb01a0)(172.31.147.25:443/TCP,172.31.232.82:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x40014b9aa8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-c7gp2": (*k8s.Endpoints)(0x4001f84d00)(172.31.144.60:4244/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x40014b9ab0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-nkfzc": (*k8s.Endpoints)(0x4001560340)(10.50.0.183:53/TCP[eu-west-3a],10.50.0.183:53/UDP[eu-west-3a],10.50.0.183:9153/TCP[eu-west-3a],10.50.0.78:53/TCP[eu-west-3a],10.50.0.78:53/UDP[eu-west-3a],10.50.0.78:9153/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x40019d21c0)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4000772b90)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400423c708
  },
  gcTrigger: (chan struct {}) (cap=1) 0x40008b4060,
  gcExited: (chan struct {}) 0x40008b40c0,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001c10380)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000d19cd8)({
      MetricVec: (*prometheus.MetricVec)(0x4001c299e0)({
       metricMap: (*prometheus.metricMap)(0x4001c29a10)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001855620)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001c10400)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000d19ce0)({
      MetricVec: (*prometheus.MetricVec)(0x4001c29a70)({
       metricMap: (*prometheus.metricMap)(0x4001c29aa0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001855680)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001c10480)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000d19ce8)({
      MetricVec: (*prometheus.MetricVec)(0x4001c29b00)({
       metricMap: (*prometheus.metricMap)(0x4001c29b30)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40018556e0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001c10500)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000d19cf0)({
      MetricVec: (*prometheus.MetricVec)(0x4001c29b90)({
       metricMap: (*prometheus.metricMap)(0x4001c29bc0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001855740)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001c10580)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000d19cf8)({
      MetricVec: (*prometheus.MetricVec)(0x4001c29c20)({
       metricMap: (*prometheus.metricMap)(0x4001c29c50)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40018557a0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001c10600)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000d19d00)({
      MetricVec: (*prometheus.MetricVec)(0x4001c29cb0)({
       metricMap: (*prometheus.metricMap)(0x4001c29ce0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001855800)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001c10680)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000d19d08)({
      MetricVec: (*prometheus.MetricVec)(0x4001c29d40)({
       metricMap: (*prometheus.metricMap)(0x4001c29d70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001855860)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001c10700)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000d19d10)({
      MetricVec: (*prometheus.MetricVec)(0x4001c29dd0)({
       metricMap: (*prometheus.metricMap)(0x4001c29e00)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40018558c0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001c10780)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000d19d18)({
      MetricVec: (*prometheus.MetricVec)(0x4001c29e60)({
       metricMap: (*prometheus.metricMap)(0x4001c29e90)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001855920)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x40019d21c0)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40019d3340)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001cd4858)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 370ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```

