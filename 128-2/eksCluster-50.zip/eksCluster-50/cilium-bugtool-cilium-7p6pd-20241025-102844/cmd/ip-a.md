1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:73:d6:d6:6a:2f brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.144.60/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2687sec preferred_lft 2687sec
    inet6 fe80::473:d6ff:fed6:6a2f/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:99:6a:46:1d:ce brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8899:6aff:fe46:1dce/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:1c:97:c7:34:80 brd ff:ff:ff:ff:ff:ff
    inet 10.50.0.31/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::941c:97ff:fec7:3480/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 5e:e8:13:0a:58:47 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5ce8:13ff:fe0a:5847/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:b7:6f:8b:1e:ce brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::78b7:6fff:fe8b:1ece/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc14374704f890@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:17:8a:9b:87:45 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::2417:8aff:fe9b:8745/64 scope link 
       valid_lft forever preferred_lft forever
11: lxccfea460b77d2@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:8b:ad:d6:f0:9d brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::e88b:adff:fed6:f09d/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc047857984eb0@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:2e:08:f4:33:16 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::a82e:8ff:fef4:3316/64 scope link 
       valid_lft forever preferred_lft forever
