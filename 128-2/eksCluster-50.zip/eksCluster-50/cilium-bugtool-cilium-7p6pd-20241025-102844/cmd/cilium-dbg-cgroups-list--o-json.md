[
  {
    "containers": [
      {
        "cgroup-id": 7283,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b8bbcf4_01ba_4452_bb29_f7a4654f2340.slice/cri-containerd-7880ef2626382be97de297bded5fc6e359216563babb2c9d1f8bc920c4fafc03.scope"
      }
    ],
    "ips": [
      "10.50.0.78"
    ],
    "name": "coredns-cc6ccd49c-mp9cd",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8711,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b4e57e6_9ebb_41d5_a740_9a89d6ba5716.slice/cri-containerd-1880bf6051c426a1305ca4932ead305cffbe30cad4ae154d828970a12e534cfa.scope"
      },
      {
        "cgroup-id": 8627,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b4e57e6_9ebb_41d5_a740_9a89d6ba5716.slice/cri-containerd-1e9e5d15931d01ea88dcd2ef48031d57ba5f21e4885ea2930bf93768e5669bf1.scope"
      },
      {
        "cgroup-id": 8795,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b4e57e6_9ebb_41d5_a740_9a89d6ba5716.slice/cri-containerd-14ac4ccb306fede0db649ae2a7b140264150189aed3fba67695c5004596aa919.scope"
      }
    ],
    "ips": [
      "10.50.0.95"
    ],
    "name": "clustermesh-apiserver-784f4468dc-ljjgm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7115,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3680fb5f_4888_4dfc_a0cb_be436212a841.slice/cri-containerd-d756d757db9bc8efcffde027a25bf1bf64a2491f19e5cae2ce21bb541e7ef04d.scope"
      }
    ],
    "ips": [
      "10.50.0.183"
    ],
    "name": "coredns-cc6ccd49c-d4mtw",
    "namespace": "kube-system"
  }
]

