CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3680fb5f_4888_4dfc_a0cb_be436212a841.slice/cri-containerd-e27c8b9de7ad8fdf321bdcb6efb67211c349571a65ee2861d50c141dec611519.scope
    519      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3680fb5f_4888_4dfc_a0cb_be436212a841.slice/cri-containerd-d756d757db9bc8efcffde027a25bf1bf64a2491f19e5cae2ce21bb541e7ef04d.scope
    523      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2f95ac49_aaa5_4ce5_9eac_51a77c324971.slice/cri-containerd-d98a951c043e8cf29dabcd83a4d8fd09fb5b28a01d2a0c47e2c6707d3b34a316.scope
    78       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2f95ac49_aaa5_4ce5_9eac_51a77c324971.slice/cri-containerd-56cd35d80c827a3ddb80fa13645154a3b5bad224c928cbfc929784b809bc188a.scope
    117      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod220bebb5_da0c_43a0_b8f3_030db42523c3.slice/cri-containerd-de5737aff80b8d46f8040c6bac1d35e131482c7eb7b05360553d3445b2dbec3b.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod220bebb5_da0c_43a0_b8f3_030db42523c3.slice/cri-containerd-52faae2003a8d52c398a42d4d34a87a994ac28a748fc17e43f1e9afa4fb4534a.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b8bbcf4_01ba_4452_bb29_f7a4654f2340.slice/cri-containerd-7880ef2626382be97de297bded5fc6e359216563babb2c9d1f8bc920c4fafc03.scope
    542      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b8bbcf4_01ba_4452_bb29_f7a4654f2340.slice/cri-containerd-0e49646ecda9d40a79ef781676b003407bf56cbcb54d1d9340eed0ae8671bbbe.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod53a7577a_04ef_4780_9547_b184885f687d.slice/cri-containerd-f5b0121183e7598be88e974af978cf85ccfa70ac8aff2e858ca13251ccd80940.scope
    86       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod53a7577a_04ef_4780_9547_b184885f687d.slice/cri-containerd-395d22a9e930fd15fdaba60e8cad9cae29b44f750ca260b1360a52b7fd7f3b70.scope
    74       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2326655f_d7d8_4c56_a886_48aed4b1db60.slice/cri-containerd-45982bf48431ee58425be28df72e7e2774b777e0d2a65f12d10781a53fbb31ac.scope
    82       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2326655f_d7d8_4c56_a886_48aed4b1db60.slice/cri-containerd-d418d9aca17fd0b72dfde8de324c47a0bf481c69e74ed9196273e407a9af51d2.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b4e57e6_9ebb_41d5_a740_9a89d6ba5716.slice/cri-containerd-1880bf6051c426a1305ca4932ead305cffbe30cad4ae154d828970a12e534cfa.scope
    616      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b4e57e6_9ebb_41d5_a740_9a89d6ba5716.slice/cri-containerd-1e9e5d15931d01ea88dcd2ef48031d57ba5f21e4885ea2930bf93768e5669bf1.scope
    612      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b4e57e6_9ebb_41d5_a740_9a89d6ba5716.slice/cri-containerd-e24f875bd4759e21cbb12fa45fde476a37a083080d195babd0f44ccdc8a6bf12.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5b4e57e6_9ebb_41d5_a740_9a89d6ba5716.slice/cri-containerd-14ac4ccb306fede0db649ae2a7b140264150189aed3fba67695c5004596aa919.scope
    620      cgroup_device   multi                                          
