ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.147.25:443 (active)    
                                          2 => 172.31.232.82:443 (active)    
2    10.100.183.172:443    ClusterIP      1 => 172.31.144.60:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.50.0.183:53 (active)       
                                          2 => 10.50.0.78:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.50.0.183:9153 (active)     
                                          2 => 10.50.0.78:9153 (active)      
5    10.100.183.219:2379   ClusterIP      1 => 10.50.0.95:2379 (active)      
