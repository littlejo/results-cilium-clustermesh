alloc: 85.48MB (89634432 bytes)
total-alloc: 1.33GB (1430676808 bytes)
sys: 202.38MB (212212036 bytes)
lookups: 0
mallocs: 47764190
frees: 46985309
heap-alloc: 85.48MB (89634432 bytes)
heap-sys: 157.45MB (165093376 bytes)
heap-idle: 44.12MB (46268416 bytes)
heap-in-use: 113.32MB (118824960 bytes)
heap-released: 1.97MB (2064384 bytes)
heap-objects: 778881
stack-in-use: 34.53MB (36208640 bytes)
stack-sys: 34.53MB (36208640 bytes)
stack-mspan-inuse: 1.89MB (1979200 bytes)
stack-mspan-sys: 2.44MB (2562240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 962.39KB (985489 bytes)
gc-sys: 5.10MB (5350448 bytes)
next-gc: when heap-alloc >= 147.79MB (154973464 bytes)
last-gc: 2024-10-25 10:28:55.051133248 +0000 UTC
gc-pause-total: 8.959258ms
gc-pause: 75496
gc-pause-end: 1729852135051133248
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0003389631251465188
enable-gc: true
debug-gc: false
