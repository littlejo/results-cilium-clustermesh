Node 0, zone      DMA      3      3      6      2      2      6     21     10      3      4    172 
Node 0, zone   Normal    271     55     13     11     22      3      1      4      6      3      6 
