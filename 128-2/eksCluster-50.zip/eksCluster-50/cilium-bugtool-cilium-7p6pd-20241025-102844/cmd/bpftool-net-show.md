xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 479
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 471
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 467
cilium_host(4) clsact/egress cil_from_host-cilium_host id 468
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 458
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 459
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 513
lxc14374704f890(9) clsact/ingress cil_from_container-lxc14374704f890 id 503
lxccfea460b77d2(11) clsact/ingress cil_from_container-lxccfea460b77d2 id 529
lxc047857984eb0(15) clsact/ingress cil_from_container-lxc047857984eb0 id 588

flow_dissector:

netfilter:

