{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:16.803Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.144.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:16.803Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:21.526Z",
  "value": "id=1274  sec_id=3346695 flags=0x0000 ifindex=9   mac=D2:F5:C5:7A:D3:64 nodemac=26:17:8A:9B:87:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:21.530Z",
  "value": "id=2840  sec_id=4     flags=0x0000 ifindex=7   mac=4E:48:23:76:DA:9B nodemac=7A:B7:6F:8B:1E:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:21.532Z",
  "value": "id=1274  sec_id=3346695 flags=0x0000 ifindex=9   mac=D2:F5:C5:7A:D3:64 nodemac=26:17:8A:9B:87:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:21.564Z",
  "value": "id=2840  sec_id=4     flags=0x0000 ifindex=7   mac=4E:48:23:76:DA:9B nodemac=7A:B7:6F:8B:1E:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:22.889Z",
  "value": "id=2775  sec_id=3346695 flags=0x0000 ifindex=11  mac=5E:77:A3:FE:DC:13 nodemac=EA:8B:AD:D6:F0:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:54.354Z",
  "value": "id=2840  sec_id=4     flags=0x0000 ifindex=7   mac=4E:48:23:76:DA:9B nodemac=7A:B7:6F:8B:1E:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:54.355Z",
  "value": "id=1274  sec_id=3346695 flags=0x0000 ifindex=9   mac=D2:F5:C5:7A:D3:64 nodemac=26:17:8A:9B:87:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:54.355Z",
  "value": "id=2775  sec_id=3346695 flags=0x0000 ifindex=11  mac=5E:77:A3:FE:DC:13 nodemac=EA:8B:AD:D6:F0:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:54.384Z",
  "value": "id=900   sec_id=3368997 flags=0x0000 ifindex=13  mac=EA:9A:8B:BF:48:43 nodemac=96:5D:AE:9D:23:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:55.355Z",
  "value": "id=2775  sec_id=3346695 flags=0x0000 ifindex=11  mac=5E:77:A3:FE:DC:13 nodemac=EA:8B:AD:D6:F0:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:55.355Z",
  "value": "id=900   sec_id=3368997 flags=0x0000 ifindex=13  mac=EA:9A:8B:BF:48:43 nodemac=96:5D:AE:9D:23:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:55.355Z",
  "value": "id=1274  sec_id=3346695 flags=0x0000 ifindex=9   mac=D2:F5:C5:7A:D3:64 nodemac=26:17:8A:9B:87:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:55.355Z",
  "value": "id=2840  sec_id=4     flags=0x0000 ifindex=7   mac=4E:48:23:76:DA:9B nodemac=7A:B7:6F:8B:1E:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:45.138Z",
  "value": "id=1373  sec_id=3368997 flags=0x0000 ifindex=15  mac=F2:59:3F:19:3D:F1 nodemac=AA:2E:08:F4:33:16"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.50.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:55.503Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:08.214Z",
  "value": "id=2840  sec_id=4     flags=0x0000 ifindex=7   mac=4E:48:23:76:DA:9B nodemac=7A:B7:6F:8B:1E:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:08.214Z",
  "value": "id=1274  sec_id=3346695 flags=0x0000 ifindex=9   mac=D2:F5:C5:7A:D3:64 nodemac=26:17:8A:9B:87:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:08.215Z",
  "value": "id=2775  sec_id=3346695 flags=0x0000 ifindex=11  mac=5E:77:A3:FE:DC:13 nodemac=EA:8B:AD:D6:F0:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:08.215Z",
  "value": "id=1373  sec_id=3368997 flags=0x0000 ifindex=15  mac=F2:59:3F:19:3D:F1 nodemac=AA:2E:08:F4:33:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.193Z",
  "value": "id=1373  sec_id=3368997 flags=0x0000 ifindex=15  mac=F2:59:3F:19:3D:F1 nodemac=AA:2E:08:F4:33:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.193Z",
  "value": "id=2775  sec_id=3346695 flags=0x0000 ifindex=11  mac=5E:77:A3:FE:DC:13 nodemac=EA:8B:AD:D6:F0:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.193Z",
  "value": "id=1274  sec_id=3346695 flags=0x0000 ifindex=9   mac=D2:F5:C5:7A:D3:64 nodemac=26:17:8A:9B:87:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:09.193Z",
  "value": "id=2840  sec_id=4     flags=0x0000 ifindex=7   mac=4E:48:23:76:DA:9B nodemac=7A:B7:6F:8B:1E:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:10.193Z",
  "value": "id=2775  sec_id=3346695 flags=0x0000 ifindex=11  mac=5E:77:A3:FE:DC:13 nodemac=EA:8B:AD:D6:F0:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:10.194Z",
  "value": "id=2840  sec_id=4     flags=0x0000 ifindex=7   mac=4E:48:23:76:DA:9B nodemac=7A:B7:6F:8B:1E:CE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:10.194Z",
  "value": "id=1373  sec_id=3368997 flags=0x0000 ifindex=15  mac=F2:59:3F:19:3D:F1 nodemac=AA:2E:08:F4:33:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.50.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:10.194Z",
  "value": "id=1274  sec_id=3346695 flags=0x0000 ifindex=9   mac=D2:F5:C5:7A:D3:64 nodemac=26:17:8A:9B:87:45"
}

