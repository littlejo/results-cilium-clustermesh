key: fa 04 00 00  value: e8 01 00 00
key: 5d 05 00 00  value: 46 02 00 00
key: d7 0a 00 00  value: 13 02 00 00
key: 18 0b 00 00  value: fd 01 00 00
Found 4 elements
