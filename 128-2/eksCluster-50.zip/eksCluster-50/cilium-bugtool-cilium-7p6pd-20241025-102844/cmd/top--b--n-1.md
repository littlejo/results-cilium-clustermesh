top - 10:28:46 up 15 min,  0 users,  load average: 0.06, 0.16, 0.12
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 16.7 us, 36.7 sy,  0.0 ni, 43.3 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   3836.2 total,    813.2 free,    881.3 used,   2141.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2786.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1472560 278264  79552 S   6.7   7.1   0:24.02 cilium-+
    404 root      20   0 1228848   6672   3844 S   0.0   0.2   0:00.27 cilium-+
    656 root      20   0 1240432  16204  11100 S   0.0   0.4   0:00.02 cilium-+
    706 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    723 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    741 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
