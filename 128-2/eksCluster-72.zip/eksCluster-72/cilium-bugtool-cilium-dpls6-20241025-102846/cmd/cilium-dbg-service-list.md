ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.203.42:443 (active)     
                                         2 => 172.31.144.219:443 (active)    
2    10.100.126.149:443   ClusterIP      1 => 172.31.168.162:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.72.0.68:9153 (active)       
                                         2 => 10.72.0.41:9153 (active)       
4    10.100.0.10:53       ClusterIP      1 => 10.72.0.68:53 (active)         
                                         2 => 10.72.0.41:53 (active)         
5    10.100.51.182:2379   ClusterIP      1 => 10.72.0.89:2379 (active)       
