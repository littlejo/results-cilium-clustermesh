USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         663  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root         662  0.0  0.0 1228744 3596 ?        Ssl  10:28   0:00 /bin/gops stack 1
root         633  0.0  0.4 1240432 16324 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         700  0.0  0.4 1240432 16324 ?       R    10:28   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         701  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root           1  2.9  6.9 1472496 273108 ?      Ssl  10:14   0:25 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.1 1228848 6664 ?        Sl   10:14   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
