alloc: 95.00MB (99617792 bytes)
total-alloc: 1.37GB (1467618288 bytes)
sys: 202.32MB (212146500 bytes)
lookups: 0
mallocs: 48357811
frees: 47374616
heap-alloc: 95.00MB (99617792 bytes)
heap-sys: 157.26MB (164896768 bytes)
heap-idle: 40.19MB (42139648 bytes)
heap-in-use: 117.07MB (122757120 bytes)
heap-released: 184.00KB (188416 bytes)
heap-objects: 983195
stack-in-use: 34.72MB (36405248 bytes)
stack-sys: 34.72MB (36405248 bytes)
stack-mspan-inuse: 1.95MB (2043680 bytes)
stack-mspan-sys: 2.41MB (2529600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 918.97KB (941025 bytes)
gc-sys: 5.10MB (5352808 bytes)
next-gc: when heap-alloc >= 147.03MB (154168088 bytes)
last-gc: 2024-10-25 10:28:52.617186673 +0000 UTC
gc-pause-total: 14.106842ms
gc-pause: 75627
gc-pause-end: 1729852132617186673
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.000340787171929455
enable-gc: true
debug-gc: false
