Endpoint ID: 113
Path: /sys/fs/bpf/tc/globals/cilium_policy_00113

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83841   965       0        
Allow    Egress      0          ANY          NONE         disabled    14365   152       0        


Endpoint ID: 519
Path: /sys/fs/bpf/tc/globals/cilium_policy_00519

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    439048   5592      0        
Allow    Ingress     1          ANY          NONE         disabled    12164    142       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1815
Path: /sys/fs/bpf/tc/globals/cilium_policy_01815

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2321
Path: /sys/fs/bpf/tc/globals/cilium_policy_02321

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3834938   36428     0        
Allow    Ingress     1          ANY          NONE         disabled    3296163   33458     0        
Allow    Egress      0          ANY          NONE         disabled    5194516   47903     0        


Endpoint ID: 2450
Path: /sys/fs/bpf/tc/globals/cilium_policy_02450

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83643   962       0        
Allow    Egress      0          ANY          NONE         disabled    14477   152       0        


