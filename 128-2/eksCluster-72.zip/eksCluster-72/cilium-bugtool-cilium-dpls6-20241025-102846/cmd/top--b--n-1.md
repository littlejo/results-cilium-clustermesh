top - 10:28:48 up 15 min,  0 users,  load average: 0.14, 0.14, 0.15
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 46.7 us, 46.7 sy,  0.0 ni,  6.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    781.5 free,    913.2 used,   2141.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2754.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1472496 278916  81156 S  46.7   7.1   0:26.01 cilium-+
    393 root      20   0 1228848   6664   3840 S   0.0   0.2   0:00.26 cilium-+
    633 root      20   0 1240432  16324  11356 S   0.0   0.4   0:00.02 cilium-+
    663 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    718 root      20   0    6576   2416   2092 R   0.0   0.1   0:00.00 top
    737 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    743 root      20   0 1616264   8684   6176 S   0.0   0.2   0:00.00 runc:[2+
