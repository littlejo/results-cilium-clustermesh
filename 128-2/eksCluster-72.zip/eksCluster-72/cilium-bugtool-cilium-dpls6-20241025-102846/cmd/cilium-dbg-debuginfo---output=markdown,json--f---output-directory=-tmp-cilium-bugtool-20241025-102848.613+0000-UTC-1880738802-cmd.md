markdown output at /tmp/cilium-bugtool-20241025-102848.613+0000-UTC-1880738802/cmd/cilium-debuginfo-20241025-102919.357+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102848.613+0000-UTC-1880738802/cmd/cilium-debuginfo-20241025-102919.357+0000-UTC.json
