# Cilium debug information

#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 830520                            /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 830520                            /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 830520                            /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400c000000 rw-p 00000000 00:00 0 
ffff620c1000-ffff622b6000 rw-p 00000000 00:00 0 
ffff622be000-ffff6239f000 rw-p 00000000 00:00 0 
ffff6239f000-ffff623e0000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff623e0000-ffff62421000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff62421000-ffff62461000 rw-p 00000000 00:00 0 
ffff62461000-ffff62463000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff62463000-ffff62465000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff62465000-ffff62a2c000 rw-p 00000000 00:00 0 
ffff62a2c000-ffff62b2c000 rw-p 00000000 00:00 0 
ffff62b2c000-ffff62b3d000 rw-p 00000000 00:00 0 
ffff62b3d000-ffff64b3d000 rw-p 00000000 00:00 0 
ffff64b3d000-ffff64bbd000 ---p 00000000 00:00 0 
ffff64bbd000-ffff64bbe000 rw-p 00000000 00:00 0 
ffff64bbe000-ffff84bbd000 ---p 00000000 00:00 0 
ffff84bbd000-ffff84bbe000 rw-p 00000000 00:00 0 
ffff84bbe000-ffffa4b4d000 ---p 00000000 00:00 0 
ffffa4b4d000-ffffa4b4e000 rw-p 00000000 00:00 0 
ffffa4b4e000-ffffa8b3f000 ---p 00000000 00:00 0 
ffffa8b3f000-ffffa8b40000 rw-p 00000000 00:00 0 
ffffa8b40000-ffffa933d000 ---p 00000000 00:00 0 
ffffa933d000-ffffa933e000 rw-p 00000000 00:00 0 
ffffa933e000-ffffa943d000 ---p 00000000 00:00 0 
ffffa943d000-ffffa949d000 rw-p 00000000 00:00 0 
ffffa949d000-ffffa949f000 r--p 00000000 00:00 0                          [vvar]
ffffa949f000-ffffa94a0000 r-xp 00000000 00:00 0                          [vdso]
ffffeaf51000-ffffeaf72000 rw-p 00000000 00:00 0                          [stack]

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.72.0.184": (string) (len=6) "health",
  (string) (len=10) "10.72.0.68": (string) (len=35) "kube-system/coredns-cc6ccd49c-fqllj",
  (string) (len=10) "10.72.0.41": (string) (len=35) "kube-system/coredns-cc6ccd49c-fq95m",
  (string) (len=10) "10.72.0.89": (string) (len=50) "kube-system/clustermesh-apiserver-55c4875fbb-c44p2",
  (string) (len=11) "10.72.0.140": (string) (len=6) "router"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.168.162": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x400150d600)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001665860,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001665860,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x400150c840)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x400150c8f0)(frontends:[10.100.126.149]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x400150ca50)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4003601760)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40035de2c0)(frontends:[10.100.51.182]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x40018850b0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-r629s": (*k8s.Endpoints)(0x40030a7d40)(10.72.0.41:53/TCP[eu-west-3a],10.72.0.41:53/UDP[eu-west-3a],10.72.0.41:9153/TCP[eu-west-3a],10.72.0.68:53/TCP[eu-west-3a],10.72.0.68:53/UDP[eu-west-3a],10.72.0.68:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001473d08)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-hr56b": (*k8s.Endpoints)(0x400375da00)(10.72.0.89:2379/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x40018850a0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40035aedd0)(172.31.144.219:443/TCP,172.31.203.42:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x40018850a8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-hg2ng": (*k8s.Endpoints)(0x400323cc30)(172.31.168.162:4244/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x40019a0230)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40023054a0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x40099fa120
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4002312720,
  gcExited: (chan struct {}) 0x4002312780,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001a7e800)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000ab7f38)({
      MetricVec: (*prometheus.MetricVec)(0x4001c0d8c0)({
       metricMap: (*prometheus.metricMap)(0x4001c0d8f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001974d80)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001a7e880)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000ab7f40)({
      MetricVec: (*prometheus.MetricVec)(0x4001c0d950)({
       metricMap: (*prometheus.metricMap)(0x4001c0d980)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001974de0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001a7e900)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000ab7f48)({
      MetricVec: (*prometheus.MetricVec)(0x4001c0d9e0)({
       metricMap: (*prometheus.metricMap)(0x4001c0da10)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001974e40)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001a7e980)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000ab7f50)({
      MetricVec: (*prometheus.MetricVec)(0x4001c0da70)({
       metricMap: (*prometheus.metricMap)(0x4001c0daa0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001974ea0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001a7ea00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000ab7f58)({
      MetricVec: (*prometheus.MetricVec)(0x4001c0db00)({
       metricMap: (*prometheus.metricMap)(0x4001c0db30)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001974f00)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001a7ea80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000ab7f60)({
      MetricVec: (*prometheus.MetricVec)(0x4001c0db90)({
       metricMap: (*prometheus.metricMap)(0x4001c0dbc0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001974f60)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001a7eb00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000ab7f68)({
      MetricVec: (*prometheus.MetricVec)(0x4001c0dc20)({
       metricMap: (*prometheus.metricMap)(0x4001c0dc50)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001974fc0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001a7eb80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000ab7f70)({
      MetricVec: (*prometheus.MetricVec)(0x4001c0dcb0)({
       metricMap: (*prometheus.metricMap)(0x4001c0dce0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001975020)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001a7ec00)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000ab7f78)({
      MetricVec: (*prometheus.MetricVec)(0x4001c0dd40)({
       metricMap: (*prometheus.metricMap)(0x4001c0dd70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001975080)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x40019a0230)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40016347e0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001d58510)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 394ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption



#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.72.0.0/24, 
Allocated addresses:
  10.72.0.140 (router)
  10.72.0.184 (health)
  10.72.0.41 (kube-system/coredns-cc6ccd49c-fq95m)
  10.72.0.68 (kube-system/coredns-cc6ccd49c-fqllj)
  10.72.0.89 (kube-system/clustermesh-apiserver-55c4875fbb-c44p2)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 84d8638ee16980cd
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    56s ago        never        0       no error   
  ct-map-pressure                                                     28s ago        never        0       no error   
  daemon-validate-config                                              44s ago        never        0       no error   
  dns-garbage-collector-job                                           1m0s ago       never        0       no error   
  endpoint-113-regeneration-recovery                                  never          never        0       no error   
  endpoint-1815-regeneration-recovery                                 never          never        0       no error   
  endpoint-2321-regeneration-recovery                                 never          never        0       no error   
  endpoint-2450-regeneration-recovery                                 never          never        0       no error   
  endpoint-519-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         5m0s ago       never        0       no error   
  ep-bpf-prog-watchdog                                                28s ago        never        0       no error   
  ipcache-inject-labels                                               58s ago        never        0       no error   
  k8s-heartbeat                                                       31s ago        never        0       no error   
  link-cache                                                          13s ago        never        0       no error   
  local-identity-checkpoint                                           14m47s ago     never        0       no error   
  node-neighbor-link-updater                                          8s ago         never        0       no error   
  remote-etcd-cmesh1                                                  7m2s ago       never        0       no error   
  remote-etcd-cmesh10                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh100                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh101                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh102                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh103                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh104                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh105                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh106                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh107                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh108                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh109                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh11                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh110                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh111                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh112                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh113                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh114                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh115                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh116                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh117                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh118                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh119                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh12                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh120                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh121                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh122                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh123                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh124                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh125                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh126                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh127                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh128                                                7m2s ago       never        0       no error   
  remote-etcd-cmesh13                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh14                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh15                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh16                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh17                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh18                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh19                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh2                                                  7m2s ago       never        0       no error   
  remote-etcd-cmesh20                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh21                                                 7m3s ago       never        0       no error   
  remote-etcd-cmesh22                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh23                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh24                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh25                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh26                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh27                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh28                                                 7m3s ago       never        0       no error   
  remote-etcd-cmesh29                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh3                                                  7m2s ago       never        0       no error   
  remote-etcd-cmesh30                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh31                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh32                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh33                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh34                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh35                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh36                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh37                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh38                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh39                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh4                                                  7m2s ago       never        0       no error   
  remote-etcd-cmesh40                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh41                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh42                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh43                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh44                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh45                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh46                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh47                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh48                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh49                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh5                                                  7m2s ago       never        0       no error   
  remote-etcd-cmesh50                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh51                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh52                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh53                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh54                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh55                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh56                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh57                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh58                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh59                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh6                                                  7m2s ago       never        0       no error   
  remote-etcd-cmesh60                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh61                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh62                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh63                                                 7m3s ago       never        0       no error   
  remote-etcd-cmesh64                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh65                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh66                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh67                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh68                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh69                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh7                                                  7m2s ago       never        0       no error   
  remote-etcd-cmesh70                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh71                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh72                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh74                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh75                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh76                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh77                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh78                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh79                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh8                                                  7m2s ago       never        0       no error   
  remote-etcd-cmesh80                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh81                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh82                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh83                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh84                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh85                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh86                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh87                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh88                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh89                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh9                                                  7m2s ago       never        0       no error   
  remote-etcd-cmesh90                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh91                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh92                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh93                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh94                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh95                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh96                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh97                                                 7m3s ago       never        0       no error   
  remote-etcd-cmesh98                                                 7m2s ago       never        0       no error   
  remote-etcd-cmesh99                                                 7m2s ago       never        0       no error   
  resolve-identity-113                                                4m56s ago      never        0       no error   
  resolve-identity-1815                                               4m58s ago      never        0       no error   
  resolve-identity-2321                                               2m50s ago      never        0       no error   
  resolve-identity-2450                                               4m56s ago      never        0       no error   
  resolve-identity-519                                                4m57s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-55c4875fbb-c44p2   7m50s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-fq95m                  14m56s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-fqllj                  14m56s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      14m58s ago     never        0       no error   
  sync-policymap-113                                                  14m53s ago     never        0       no error   
  sync-policymap-1815                                                 14m56s ago     never        0       no error   
  sync-policymap-2321                                                 7m50s ago      never        0       no error   
  sync-policymap-2450                                                 14m53s ago     never        0       no error   
  sync-policymap-519                                                  14m53s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (113)                                    6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2321)                                   10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2450)                                   6s ago         never        0       no error   
  sync-utime                                                          58s ago        never        0       no error   
  write-cni-file                                                      15m0s ago      never        0       no error   
Proxy Status:            OK, ip 10.72.0.140, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 4784128, max 4849663
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 74.14   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Service list

```
ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.203.42:443 (active)     
                                         2 => 172.31.144.219:443 (active)    
2    10.100.126.149:443   ClusterIP      1 => 172.31.168.162:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.72.0.68:9153 (active)       
                                         2 => 10.72.0.41:9153 (active)       
4    10.100.0.10:53       ClusterIP      1 => 10.72.0.68:53 (active)         
                                         2 => 10.72.0.41:53 (active)         
5    10.100.51.182:2379   ClusterIP      1 => 10.72.0.89:2379 (active)       
```

#### Cilium environment keys

```
max-connected-clusters:255
hubble-redact-http-headers-deny:
monitor-aggregation:medium
bpf-events-drop-enabled:true
enable-ipv4-egress-gateway:false
enable-ipv6-big-tcp:false
k8s-kubeconfig-path:
enable-bandwidth-manager:false
static-cnp-path:
enable-xt-socket-fallback:true
bpf-fragments-map-max:8192
enable-ipv4-big-tcp:false
hubble-event-queue-size:0
join-cluster:false
encrypt-node:false
enable-mke:false
clustermesh-ip-identities-sync-timeout:1m0s
bpf-policy-map-full-reconciliation-interval:15m0s
ipv4-native-routing-cidr:
unmanaged-pod-watcher-interval:15
hubble-prefer-ipv6:false
k8s-service-cache-size:128
k8s-client-qps:10
l2-announcements-retry-period:2s
enable-route-mtu-for-cni-chaining:false
bpf-filter-priority:1
cni-log-file:/var/run/cilium/cilium-cni.log
monitor-aggregation-interval:5s
labels:
enable-ipv6-ndp:false
dns-policy-unload-on-shutdown:false
hubble-export-fieldmask:
kvstore:
proxy-xff-num-trusted-hops-egress:0
enable-custom-calls:false
mesh-auth-queue-size:1024
install-iptables-rules:true
agent-liveness-update-interval:1s
mesh-auth-spiffe-trust-domain:spiffe.cilium
enable-local-redirect-policy:false
bpf-lb-algorithm:random
enable-identity-mark:true
log-opt:
k8s-client-connection-timeout:30s
policy-trigger-interval:1s
dns-max-ips-per-restored-rule:1000
enable-session-affinity:false
enable-encryption-strict-mode:false
enable-l2-pod-announcements:false
clustermesh-config:/var/lib/cilium/clustermesh/
bpf-map-event-buffers:
proxy-prometheus-port:0
config-dir:/tmp/cilium/config-map
cflags:
k8s-service-proxy-name:
cluster-name:cmesh73
k8s-api-server:
enable-ipsec-xfrm-state-caching:true
synchronize-k8s-nodes:true
enable-bpf-clock-probe:false
enable-ipsec:false
hubble-recorder-storage-path:/var/run/cilium/pcaps
mtu:0
proxy-portrange-max:20000
log-system-load:false
bpf-lb-sock-terminate-pod-connections:false
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
pprof:false
kvstore-max-consecutive-quorum-errors:2
hubble-event-buffer-capacity:4095
mke-cgroup-mount:
ipv6-mcast-device:
enable-envoy-config:false
kvstore-lease-ttl:15m0s
clustermesh-enable-mcs-api:false
kvstore-connectivity-timeout:2m0s
direct-routing-device:
ipv6-native-routing-cidr:
exclude-local-address:
cgroup-root:/run/cilium/cgroupv2
policy-accounting:true
http-idle-timeout:0
cmdref:
enable-ipsec-encrypted-overlay:false
nodes-gc-interval:5m0s
conntrack-gc-max-interval:0s
ipv4-service-range:auto
hubble-redact-http-urlquery:false
mesh-auth-spire-admin-socket:
iptables-random-fully:false
http-retry-count:3
state-dir:/var/run/cilium
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
bpf-ct-timeout-service-any:1m0s
custom-cni-conf:false
dnsproxy-enable-transparent-mode:true
debug:false
enable-ip-masq-agent:false
egress-gateway-reconciliation-trigger-interval:1s
proxy-xff-num-trusted-hops-ingress:0
bypass-ip-availability-upon-restore:false
endpoint-queue-size:25
tunnel-protocol:vxlan
bpf-ct-timeout-regular-any:1m0s
gateway-api-secrets-namespace:
preallocate-bpf-maps:false
disable-envoy-version-check:false
enable-hubble-recorder-api:true
tofqdns-endpoint-max-ip-per-hostname:50
enable-node-selector-labels:false
clustermesh-enable-endpoint-sync:false
hubble-metrics:
log-driver:
node-port-algorithm:random
bpf-lb-affinity-map-max:0
enable-metrics:true
identity-allocation-mode:crd
proxy-connect-timeout:2
enable-masquerade-to-route-source:false
keep-config:false
force-device-detection:false
node-labels:
enable-host-firewall:false
encryption-strict-mode-cidr:
bpf-lb-external-clusterip:false
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
hubble-redact-http-headers-allow:
proxy-max-requests-per-connection:0
envoy-base-id:0
envoy-config-retry-interval:15s
disable-iptables-feeder-rules:
hubble-export-file-compress:false
bpf-events-policy-verdict-enabled:true
trace-payloadlen:128
enable-l2-neigh-discovery:true
ipam:cluster-pool
bpf-ct-global-tcp-max:524288
k8s-client-burst:20
enable-gateway-api:false
dnsproxy-insecure-skip-transparent-mode-check:false
bpf-policy-map-max:16384
local-router-ipv4:
agent-labels:
enable-nat46x64-gateway:false
hubble-skip-unknown-cgroup-ids:true
version:false
enable-wireguard:false
enable-cilium-health-api-server-access:
enable-health-checking:true
procfs:/host/proc
mesh-auth-gc-interval:5m0s
http-retry-timeout:0
enable-l7-proxy:true
enable-bpf-tproxy:false
proxy-idle-timeout-seconds:60
mesh-auth-mutual-connect-timeout:5s
node-port-mode:snat
ipv6-cluster-alloc-cidr:f00d::/64
policy-cidr-match-mode:
cilium-endpoint-gc-interval:5m0s
enable-endpoint-health-checking:true
proxy-gid:1337
bpf-lb-rss-ipv6-src-cidr:
bpf-neigh-global-max:524288
certificates-directory:/var/run/cilium/certs
enable-k8s-terminating-endpoint:true
container-ip-local-reserved-ports:auto
hubble-listen-address::4244
agent-health-port:9879
bpf-lb-map-max:65536
envoy-keep-cap-netbindservice:false
auto-direct-node-routes:false
wireguard-persistent-keepalive:0s
egress-multi-home-ip-rule-compat:false
metrics:
bgp-announce-pod-cidr:false
bpf-node-map-max:16384
disable-endpoint-crd:false
fixed-identity-mapping:
dnsproxy-concurrency-processing-grace-period:0s
hubble-flowlogs-config-path:
conntrack-gc-interval:0s
enable-sctp:false
ipv4-pod-subnets:
remove-cilium-node-taints:true
tunnel-port:0
dnsproxy-lock-count:131
http-normalize-path:true
bpf-lb-mode:snat
restore:true
bpf-ct-timeout-regular-tcp:2h13m20s
bpf-lb-maglev-table-size:16381
ipsec-key-file:
ipam-multi-pool-pre-allocation:
set-cilium-is-up-condition:true
k8s-heartbeat-timeout:30s
k8s-require-ipv4-pod-cidr:false
ipam-cilium-node-update-rate:15s
routing-mode:tunnel
encryption-strict-mode-allow-remote-node-identities:false
egress-masquerade-interfaces:ens+
iptables-lock-timeout:5s
bpf-lb-rss-ipv4-src-cidr:
ipam-default-ip-pool:default
enable-host-port:false
api-rate-limit:
enable-unreachable-routes:false
enable-node-port:false
enable-l2-announcements:false
envoy-config-timeout:2m0s
direct-routing-skip-unreachable:false
cni-external-routing:false
enable-ipip-termination:false
controller-group-metrics:
ipv4-range:auto
enable-endpoint-routes:false
monitor-queue-size:0
enable-health-check-nodeport:true
srv6-encap-mode:reduced
gops-port:9890
bpf-lb-service-map-max:0
enable-policy:default
k8s-require-ipv6-pod-cidr:false
hubble-export-allowlist:
bpf-nat-global-max:524288
set-cilium-node-taints:true
hubble-export-file-max-size-mb:10
hubble-drop-events:false
ipsec-key-rotation-duration:5m0s
use-full-tls-context:false
encrypt-interface:
enable-auto-protect-node-port-range:true
enable-high-scale-ipcache:false
tofqdns-enable-dns-compression:true
enable-host-legacy-routing:false
l2-pod-announcements-interface:
enable-bbr:false
enable-ipv4-masquerade:true
k8s-client-connection-keep-alive:30s
dnsproxy-socket-linger-timeout:10
derive-masq-ip-addr-from-device:
pprof-address:localhost
l2-announcements-renew-deadline:5s
label-prefix-file:
egress-gateway-policy-map-max:16384
socket-path:/var/run/cilium/cilium.sock
bpf-events-trace-enabled:true
enable-ingress-controller:false
http-max-grpc-timeout:0
datapath-mode:veth
local-router-ipv6:
enable-wireguard-userspace-fallback:false
ipv4-node:auto
nodeport-addresses:
kube-proxy-replacement-healthz-bind-address:
hubble-export-denylist:
hubble-drop-events-interval:2m0s
identity-heartbeat-timeout:30m0s
enable-cilium-api-server-access:
route-metric:0
multicast-enabled:false
hubble-disable-tls:false
enable-runtime-device-detection:true
enable-pmtu-discovery:false
bpf-lb-dsr-dispatch:opt
ingress-secrets-namespace:
kube-proxy-replacement:false
mesh-auth-mutual-listener-port:0
disable-external-ip-mitigation:false
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
service-no-backend-response:reject
bgp-config-path:/var/lib/cilium/bgp/config.yaml
tofqdns-idle-connection-grace-period:0s
bpf-lb-sock:false
node-port-acceleration:disabled
identity-change-grace-period:5s
proxy-portrange-min:10000
clustermesh-sync-timeout:1m0s
prepend-iptables-chains:true
devices:
vtep-mask:
lib-dir:/var/lib/cilium
bpf-lb-source-range-map-max:0
bpf-ct-global-any-max:262144
ipv6-range:auto
enable-k8s:true
enable-k8s-networkpolicy:true
envoy-log:
config-sources:config-map:kube-system/cilium-config
nat-map-stats-entries:32
external-envoy-proxy:true
ipv6-service-range:auto
allow-icmp-frag-needed:true
tofqdns-proxy-port:0
cluster-pool-ipv4-mask-size:24
hubble-redact-enabled:false
node-port-range:
kvstore-periodic-sync:5m0s
cni-exclusive:true
debug-verbose:
enable-tcx:true
enable-well-known-identities:false
bpf-lb-sock-hostns-only:false
dnsproxy-lock-timeout:500ms
envoy-secrets-namespace:
bpf-root:/sys/fs/bpf
enable-k8s-api-discovery:false
enable-bpf-masquerade:false
k8s-sync-timeout:3m0s
tofqdns-min-ttl:0
operator-api-serve-addr:127.0.0.1:9234
ip-masq-agent-config-path:/etc/config/ip-masq-agent
exclude-node-label-patterns:
hubble-socket-path:/var/run/cilium/hubble.sock
monitor-aggregation-flags:all
enable-vtep:false
hubble-recorder-sink-queue-size:1024
mesh-auth-rotated-identities-queue-size:1024
bpf-ct-timeout-regular-tcp-fin:10s
trace-sock:true
vtep-mac:
enable-ipsec-key-watcher:true
kvstore-opt:
max-internal-timer-delay:0s
bpf-sock-rev-map-max:262144
enable-local-node-route:true
cni-chaining-mode:none
enable-service-topology:false
bpf-lb-service-backend-map-max:0
bpf-ct-timeout-service-tcp-grace:1m0s
bpf-map-dynamic-size-ratio:0.0025
node-port-bind-protection:true
dnsproxy-concurrency-limit:0
enable-ipv4-fragment-tracking:true
fqdn-regex-compile-lru-size:1024
hubble-monitor-events:
max-controller-interval:0
cluster-health-port:4240
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
vtep-endpoint:
enable-icmp-rules:true
enable-stale-cilium-endpoint-cleanup:true
cluster-pool-ipv4-cidr:10.72.0.0/16
enable-hubble:true
bpf-lb-rev-nat-map-max:0
enable-recorder:false
policy-audit-mode:false
enable-monitor:true
vtep-cidr:
enable-k8s-endpoint-slice:true
ipv4-service-loopback-address:169.254.42.1
bgp-announce-lb-ip:false
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
cluster-id:73
bpf-ct-timeout-regular-tcp-syn:1m0s
operator-prometheus-serve-addr::9963
tofqdns-proxy-response-max-delay:100ms
identity-restore-grace-period:30s
annotate-k8s-node:false
enable-cilium-endpoint-slice:false
identity-gc-interval:15m0s
hubble-drop-events-reasons:auth_required,policy_denied
auto-create-cilium-node-resource:true
enable-xdp-prefilter:false
hubble-metrics-server:
ipv6-pod-subnets:
crd-wait-timeout:5m0s
k8s-namespace:kube-system
bpf-ct-timeout-service-tcp:2h13m20s
enable-ipv4:true
read-cni-conf:
hubble-export-file-path:
enable-ipv6-masquerade:true
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
hubble-redact-kafka-apikey:false
tofqdns-max-deferred-connection-deletes:10000
hubble-export-file-max-backups:5
nat-map-stats-interval:30s
enable-ipv6:false
bpf-auth-map-max:524288
cni-chaining-target:
bpf-lb-maglev-map-max:0
allocator-list-timeout:3m0s
local-max-addr-scope:252
enable-health-check-loadbalancer-ip:false
pprof-port:6060
tofqdns-dns-reject-response-code:refused
arping-refresh-period:30s
allow-localhost:auto
enable-svc-source-range-check:true
tofqdns-pre-cache:
install-no-conntrack-iptables-rules:false
enable-tracing:false
mesh-auth-enabled:true
bpf-lb-dsr-l4-xlate:frontend
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
proxy-admin-port:0
ipv6-node:auto
enable-external-ips:false
mesh-auth-signal-backoff-duration:1s
proxy-max-connection-duration-seconds:0
l2-announcements-lease-duration:15s
bpf-lb-acceleration:disabled
hubble-redact-http-userinfo:true
vlan-bpf-bypass:
endpoint-bpf-prog-watchdog-interval:30s
policy-queue-size:100
http-request-timeout:3600
enable-active-connection-tracking:false
endpoint-gc-interval:5m0s
prometheus-serve-addr:
use-cilium-internal-ip-for-ipsec:false
enable-bgp-control-plane:false
enable-srv6:false
config:
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
113        Disabled           Disabled          4787738    k8s:eks.amazonaws.com/component=coredns                                             10.72.0.41    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh73                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
519        Disabled           Disabled          4          reserved:health                                                                     10.72.0.184   ready   
1815       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                
                                                           reserved:host                                                                                             
2321       Disabled           Disabled          4787008    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.72.0.89    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh73                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
2450       Disabled           Disabled          4787738    k8s:eks.amazonaws.com/component=coredns                                             10.72.0.68    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh73                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
```

#### BPF Policy Get 113

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83841   965       0        
Allow    Egress      0          ANY          NONE         disabled    14365   152       0        

```


#### BPF CT List 113

```
Invalid argument: unknown type 113
```


#### Endpoint Get 113

```
[
  {
    "id": 113,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-113-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "cf06eb1e-8a7e-4f67-885b-5b00d5ce4f98"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-113",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:22.979Z",
            "success-count": 3
          },
          "uuid": "77d83f6c-8241-47b7-987c-bf630a6a7515"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-fq95m",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:22.978Z",
            "success-count": 1
          },
          "uuid": "f09dc114-3033-4507-bca6-7b8dd091bf62"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-113",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:25.664Z",
            "success-count": 1
          },
          "uuid": "ce5140b5-92b8-441d-bb85-700cb948a06c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (113)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:13.058Z",
            "success-count": 91
          },
          "uuid": "3dca0789-02a9-4f90-a0c9-e5405e8b0f7a"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "d54d69bc8782b98c1f2e4062635e03384a2a98a9be09f54dd01989ff459df37c:eth0",
        "container-id": "d54d69bc8782b98c1f2e4062635e03384a2a98a9be09f54dd01989ff459df37c",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-fq95m",
        "pod-name": "kube-system/coredns-cc6ccd49c-fq95m"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4787738,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh73",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh73",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:18Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.72.0.41",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "76:49:de:7f:9f:6c",
        "interface-index": 9,
        "interface-name": "lxc227bed0d9494",
        "mac": "9e:a7:44:9b:73:a9"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4787738,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4787738,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 113

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 113

```
Timestamp              Status    State                   Message
2024-10-25T10:22:18Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:18Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:18Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:22:18Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:17Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:17Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:17Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:17Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:16Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:16Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:16Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:16Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:25Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:25Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:25Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:23Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:14:23Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:22Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:22Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:14:22Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:22Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 4787738

```
ID        LABELS
4787738   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh73
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 519

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    435714   5551      0        
Allow    Ingress     1          ANY          NONE         disabled    12164    142       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 519

```
Invalid argument: unknown type 519
```


#### Endpoint Get 519

```
[
  {
    "id": 519,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-519-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "8a3de15f-df41-4d09-bdf7-e0b7ac3fb011"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-519",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:22.166Z",
            "success-count": 3
          },
          "uuid": "0e1b6d4a-84f9-4b0e-9205-ef4a7a621be9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-519",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:25.586Z",
            "success-count": 1
          },
          "uuid": "16a146a7-4398-447f-aed5-7be4f05b1c87"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:18Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.72.0.184",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "4a:6a:a1:b9:bb:af",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "d2:84:bc:60:ae:17"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 519

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 519

```
Timestamp              Status   State                   Message
2024-10-25T10:22:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:18Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:25Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:14:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:22Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:22Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:21Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 1815

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1815

```
Invalid argument: unknown type 1815
```


#### Endpoint Get 1815

```
[
  {
    "id": 1815,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1815-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5d64b3ae-f207-4fbc-aa27-5d7e7aafc7f9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1815",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:21.099Z",
            "success-count": 3
          },
          "uuid": "66093210-95f3-4778-bff3-a3efba15a799"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1815",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:22.364Z",
            "success-count": 1
          },
          "uuid": "c08e6e71-224b-4330-a9b8-65215cb41019"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:18Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "42:14:f3:8b:9f:60",
        "interface-name": "cilium_host",
        "mac": "42:14:f3:8b:9f:60"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1815

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1815

```
Timestamp              Status   State                   Message
2024-10-25T10:22:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:18Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:14:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:21Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:21Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:21Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 2321

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3831516   36391     0        
Allow    Ingress     1          ANY          NONE         disabled    3296163   33458     0        
Allow    Egress      0          ANY          NONE         disabled    5189712   47849     0        

```


#### BPF CT List 2321

```
Invalid argument: unknown type 2321
```


#### Endpoint Get 2321

```
[
  {
    "id": 2321,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2321-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7474956f-ecc6-4d32-baf3-7696aa397a17"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2321",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:28.603Z",
            "success-count": 2
          },
          "uuid": "ae806f81-0ad3-45c1-a7e3-79ef4f176be2"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-55c4875fbb-c44p2",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:28.602Z",
            "success-count": 1
          },
          "uuid": "28092041-14d3-45fb-9310-2203403aa0d5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2321",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:28.634Z",
            "success-count": 1
          },
          "uuid": "85aace98-409f-4b87-9320-300c6965a2a5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2321)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:19.032Z",
            "success-count": 49
          },
          "uuid": "ecad0ccd-2269-4441-ad0f-6b166b2b492b"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "d24895a4ba9e1a05433729489e1b75ef8b5e3261d7f0ec6dd23b6cd1922029aa:eth0",
        "container-id": "d24895a4ba9e1a05433729489e1b75ef8b5e3261d7f0ec6dd23b6cd1922029aa",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-55c4875fbb-c44p2",
        "pod-name": "kube-system/clustermesh-apiserver-55c4875fbb-c44p2"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4787008,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh73",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=55c4875fbb"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh73",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:18Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.72.0.89",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "06:30:16:3a:87:d2",
        "interface-index": 15,
        "interface-name": "lxce9b5a77ad26e",
        "mac": "9e:ad:8a:1d:f3:4d"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4787008,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4787008,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2321

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2321

```
Timestamp              Status   State                   Message
2024-10-25T10:22:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:18Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:28Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:28Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:28Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4787008

```
ID        LABELS
4787008   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh73
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 2450

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83643   962       0        
Allow    Egress      0          ANY          NONE         disabled    14477   152       0        

```


#### BPF CT List 2450

```
Invalid argument: unknown type 2450
```


#### Endpoint Get 2450

```
[
  {
    "id": 2450,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2450-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "ba0640c9-3f11-41d4-a9e4-9db0cfbaa2df"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2450",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:22.929Z",
            "success-count": 3
          },
          "uuid": "c91851de-4081-4ddb-86a7-46856467b38e"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-fqllj",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:22.927Z",
            "success-count": 1
          },
          "uuid": "dc3cc1fb-63a1-493a-a9cf-48399866a63b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2450",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:25.578Z",
            "success-count": 1
          },
          "uuid": "63796686-e738-4029-8b08-5f05e3e19a27"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2450)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:13.015Z",
            "success-count": 91
          },
          "uuid": "180431c8-ecd3-463f-b578-87920a2523a8"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "aef6716e1a846d0f9f3c81560052cf0a4ffa29dea7520b35d12908b490249dc2:eth0",
        "container-id": "aef6716e1a846d0f9f3c81560052cf0a4ffa29dea7520b35d12908b490249dc2",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-fqllj",
        "pod-name": "kube-system/coredns-cc6ccd49c-fqllj"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4787738,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh73",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh73",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:18Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.72.0.68",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "9a:28:24:47:46:f7",
        "interface-index": 11,
        "interface-name": "lxca053dd52fe9a",
        "mac": "92:64:1b:d0:20:34"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4787738,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4787738,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2450

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2450

```
Timestamp              Status   State                   Message
2024-10-25T10:22:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:18Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:25Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:14:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:22Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:22Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:22Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4787738

```
ID        LABELS
4787738   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh73
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```

