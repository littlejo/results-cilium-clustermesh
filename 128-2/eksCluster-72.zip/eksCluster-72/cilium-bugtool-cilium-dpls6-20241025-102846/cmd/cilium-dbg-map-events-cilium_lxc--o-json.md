{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:20.942Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.168.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:20.942Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:25.578Z",
  "value": "id=2450  sec_id=4787738 flags=0x0000 ifindex=11  mac=92:64:1B:D0:20:34 nodemac=9A:28:24:47:46:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:25.585Z",
  "value": "id=519   sec_id=4     flags=0x0000 ifindex=7   mac=D2:84:BC:60:AE:17 nodemac=4A:6A:A1:B9:BB:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:25.654Z",
  "value": "id=113   sec_id=4787738 flags=0x0000 ifindex=9   mac=9E:A7:44:9B:73:A9 nodemac=76:49:DE:7F:9F:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:25.737Z",
  "value": "id=2450  sec_id=4787738 flags=0x0000 ifindex=11  mac=92:64:1B:D0:20:34 nodemac=9A:28:24:47:46:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:25.784Z",
  "value": "id=519   sec_id=4     flags=0x0000 ifindex=7   mac=D2:84:BC:60:AE:17 nodemac=4A:6A:A1:B9:BB:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:58.930Z",
  "value": "id=519   sec_id=4     flags=0x0000 ifindex=7   mac=D2:84:BC:60:AE:17 nodemac=4A:6A:A1:B9:BB:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:58.931Z",
  "value": "id=2450  sec_id=4787738 flags=0x0000 ifindex=11  mac=92:64:1B:D0:20:34 nodemac=9A:28:24:47:46:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:58.931Z",
  "value": "id=113   sec_id=4787738 flags=0x0000 ifindex=9   mac=9E:A7:44:9B:73:A9 nodemac=76:49:DE:7F:9F:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:58.975Z",
  "value": "id=136   sec_id=4787008 flags=0x0000 ifindex=13  mac=36:DE:6D:D3:C9:98 nodemac=96:56:06:44:2B:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:59.931Z",
  "value": "id=519   sec_id=4     flags=0x0000 ifindex=7   mac=D2:84:BC:60:AE:17 nodemac=4A:6A:A1:B9:BB:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:59.931Z",
  "value": "id=113   sec_id=4787738 flags=0x0000 ifindex=9   mac=9E:A7:44:9B:73:A9 nodemac=76:49:DE:7F:9F:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:59.932Z",
  "value": "id=2450  sec_id=4787738 flags=0x0000 ifindex=11  mac=92:64:1B:D0:20:34 nodemac=9A:28:24:47:46:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:59.932Z",
  "value": "id=136   sec_id=4787008 flags=0x0000 ifindex=13  mac=36:DE:6D:D3:C9:98 nodemac=96:56:06:44:2B:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:28.634Z",
  "value": "id=2321  sec_id=4787008 flags=0x0000 ifindex=15  mac=9E:AD:8A:1D:F3:4D nodemac=06:30:16:3A:87:D2"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.72.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:38.891Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:16.490Z",
  "value": "id=2450  sec_id=4787738 flags=0x0000 ifindex=11  mac=92:64:1B:D0:20:34 nodemac=9A:28:24:47:46:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:16.490Z",
  "value": "id=113   sec_id=4787738 flags=0x0000 ifindex=9   mac=9E:A7:44:9B:73:A9 nodemac=76:49:DE:7F:9F:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:16.490Z",
  "value": "id=2321  sec_id=4787008 flags=0x0000 ifindex=15  mac=9E:AD:8A:1D:F3:4D nodemac=06:30:16:3A:87:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:16.491Z",
  "value": "id=519   sec_id=4     flags=0x0000 ifindex=7   mac=D2:84:BC:60:AE:17 nodemac=4A:6A:A1:B9:BB:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:17.491Z",
  "value": "id=2321  sec_id=4787008 flags=0x0000 ifindex=15  mac=9E:AD:8A:1D:F3:4D nodemac=06:30:16:3A:87:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:17.491Z",
  "value": "id=113   sec_id=4787738 flags=0x0000 ifindex=9   mac=9E:A7:44:9B:73:A9 nodemac=76:49:DE:7F:9F:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:17.491Z",
  "value": "id=2450  sec_id=4787738 flags=0x0000 ifindex=11  mac=92:64:1B:D0:20:34 nodemac=9A:28:24:47:46:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:17.491Z",
  "value": "id=519   sec_id=4     flags=0x0000 ifindex=7   mac=D2:84:BC:60:AE:17 nodemac=4A:6A:A1:B9:BB:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:18.491Z",
  "value": "id=519   sec_id=4     flags=0x0000 ifindex=7   mac=D2:84:BC:60:AE:17 nodemac=4A:6A:A1:B9:BB:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:18.491Z",
  "value": "id=2321  sec_id=4787008 flags=0x0000 ifindex=15  mac=9E:AD:8A:1D:F3:4D nodemac=06:30:16:3A:87:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:18.491Z",
  "value": "id=2450  sec_id=4787738 flags=0x0000 ifindex=11  mac=92:64:1B:D0:20:34 nodemac=9A:28:24:47:46:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.72.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:18.492Z",
  "value": "id=113   sec_id=4787738 flags=0x0000 ifindex=9   mac=9E:A7:44:9B:73:A9 nodemac=76:49:DE:7F:9F:6C"
}

