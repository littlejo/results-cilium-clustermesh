key: 71 00 00 00  value: e1 01 00 00
key: 07 02 00 00  value: 02 02 00 00
key: 11 09 00 00  value: 58 02 00 00
key: 92 09 00 00  value: fa 01 00 00
Found 4 elements
