[
  {
    "containers": [
      {
        "cgroup-id": 7283,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb1b4ad97_4f77_42b5_affc_ce5ffc20e6d7.slice/cri-containerd-f85d27fbd1d6320e24f5568a14fe86fbf18ed341dc03d360083f24201dc554d6.scope"
      }
    ],
    "ips": [
      "10.72.0.41"
    ],
    "name": "coredns-cc6ccd49c-fq95m",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7199,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7e9842c1_80fa_4c77_92f7_889718809dee.slice/cri-containerd-5d51f37156bb2e1d03f9f0b1738742d74195b226e40aeced7f1428b250781e2d.scope"
      }
    ],
    "ips": [
      "10.72.0.68"
    ],
    "name": "coredns-cc6ccd49c-fqllj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8711,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ff3a75c_22c9_4d51_8850_cc8bfc2e58ea.slice/cri-containerd-a9bce7a57d394892c7c450e772b6413e59dc0d2c2a14a18fc10cd5398681dd43.scope"
      },
      {
        "cgroup-id": 8627,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ff3a75c_22c9_4d51_8850_cc8bfc2e58ea.slice/cri-containerd-cef8b032e8e199196e4be3437ffe0a0e172794b8ec102f384d2fd874f3dfe7c5.scope"
      },
      {
        "cgroup-id": 8795,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ff3a75c_22c9_4d51_8850_cc8bfc2e58ea.slice/cri-containerd-62253dede67701b93d6f7e199077ea3c62222fc3d90218211a9dd7ecdf773094.scope"
      }
    ],
    "ips": [
      "10.72.0.89"
    ],
    "name": "clustermesh-apiserver-55c4875fbb-c44p2",
    "namespace": "kube-system"
  }
]

