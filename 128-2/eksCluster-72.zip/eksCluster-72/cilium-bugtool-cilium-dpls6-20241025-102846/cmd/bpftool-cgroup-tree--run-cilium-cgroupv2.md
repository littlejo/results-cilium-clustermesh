CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod107859f8_29e1_4676_9b64_cfd465f9eb57.slice/cri-containerd-0b2489750ff8f522342eab59f7a8b82b2634ba6965f41894da57d10e966b7f1b.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod107859f8_29e1_4676_9b64_cfd465f9eb57.slice/cri-containerd-3eee637de61e584abc98cdefa6d749bda9913226fcedd8a5b87c98b70fb1f25d.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7e9842c1_80fa_4c77_92f7_889718809dee.slice/cri-containerd-5d51f37156bb2e1d03f9f0b1738742d74195b226e40aeced7f1428b250781e2d.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7e9842c1_80fa_4c77_92f7_889718809dee.slice/cri-containerd-aef6716e1a846d0f9f3c81560052cf0a4ffa29dea7520b35d12908b490249dc2.scope
    502      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb1b4ad97_4f77_42b5_affc_ce5ffc20e6d7.slice/cri-containerd-d54d69bc8782b98c1f2e4062635e03384a2a98a9be09f54dd01989ff459df37c.scope
    521      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb1b4ad97_4f77_42b5_affc_ce5ffc20e6d7.slice/cri-containerd-f85d27fbd1d6320e24f5568a14fe86fbf18ed341dc03d360083f24201dc554d6.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6a7f67ec_4d31_43a8_9ab9_0579708de5a3.slice/cri-containerd-aa1e2795c295844379e5eed3c7abd3d355cecdfaac89cf6dfef5953c3bddaef2.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6a7f67ec_4d31_43a8_9ab9_0579708de5a3.slice/cri-containerd-af01b82682fb06fb3f5b7ac852927c7d6f25a01efa7ea489e2ed4718aaa2113a.scope
    114      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ff3a75c_22c9_4d51_8850_cc8bfc2e58ea.slice/cri-containerd-cef8b032e8e199196e4be3437ffe0a0e172794b8ec102f384d2fd874f3dfe7c5.scope
    620      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ff3a75c_22c9_4d51_8850_cc8bfc2e58ea.slice/cri-containerd-d24895a4ba9e1a05433729489e1b75ef8b5e3261d7f0ec6dd23b6cd1922029aa.scope
    604      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ff3a75c_22c9_4d51_8850_cc8bfc2e58ea.slice/cri-containerd-a9bce7a57d394892c7c450e772b6413e59dc0d2c2a14a18fc10cd5398681dd43.scope
    624      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ff3a75c_22c9_4d51_8850_cc8bfc2e58ea.slice/cri-containerd-62253dede67701b93d6f7e199077ea3c62222fc3d90218211a9dd7ecdf773094.scope
    628      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc7393040_9502_4329_8072_232bf4207686.slice/cri-containerd-0e36447a873d37737a92813f24ede2ca2ff0f1b644aaf4994255c9f87032f0eb.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc7393040_9502_4329_8072_232bf4207686.slice/cri-containerd-dfa404d47036f249ff0b8680588e8d2acb00d64f0b5cd51d32bd6cc0a6199bd6.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc38d40e9_98a5_40a8_a716_e1219e5ecff2.slice/cri-containerd-782271a2d1af7022646c724b3aa585c172343d1036209f37cf8a2be3c86b8eba.scope
    71       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc38d40e9_98a5_40a8_a716_e1219e5ecff2.slice/cri-containerd-242228a614e9e07962c89bf3c32fc3a94b94e348c5b46a8de8d044be8981ea24.scope
    83       cgroup_device   multi                                          
