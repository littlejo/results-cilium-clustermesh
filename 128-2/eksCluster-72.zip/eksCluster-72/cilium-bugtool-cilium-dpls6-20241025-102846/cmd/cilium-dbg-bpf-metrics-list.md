REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     10210     799950      677    bpf_overlay.c
Interface                 INGRESS     224879    101447982   1132   bpf_host.c
Success                   EGRESS      10471     818062      53     encap.h
Success                   EGRESS      5308      408142      1694   bpf_host.c
Success                   EGRESS      96381     12616017    1308   bpf_lxc.c
Success                   INGRESS     106741    13195267    86     l3.h
Success                   INGRESS     112292    13630981    235    trace.h
Unsupported L3 protocol   EGRESS      37        2762        1492   bpf_lxc.c
