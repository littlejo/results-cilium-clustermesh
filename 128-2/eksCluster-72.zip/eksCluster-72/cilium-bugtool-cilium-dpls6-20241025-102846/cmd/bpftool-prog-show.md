29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:36+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
68: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
71: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
72: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
75: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
80: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
83: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
111: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
114: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
455: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 114
456: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 115
457: sched_cls  name tail_handle_ipv4  tag 852e3cd9b3455929  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 71,70,77,72,93
	btf_id 116
458: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 72,93
	btf_id 117
481: sched_cls  name handle_policy  tag 999e37fc59cd3185  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,101,78,79,102,37,76,100,35,80,71,36,33,34
	btf_id 143
482: sched_cls  name tail_handle_arp  tag e460746ada2b9925  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,101
	btf_id 144
483: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,101
	btf_id 145
484: sched_cls  name tail_ipv4_ct_egress  tag 1a0ad8c51160b5af  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,101,78,79,102,80
	btf_id 146
485: sched_cls  name __send_drop_notify  tag d85cacbdfde9bdea  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 147
486: sched_cls  name cil_from_container  tag 3fc2cae1cf2320d0  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 101,72
	btf_id 148
488: sched_cls  name tail_ipv4_to_endpoint  tag f99b1114a08f45ff  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,102,37,78,79,76,100,35,101,36,33,34
	btf_id 150
489: sched_cls  name tail_handle_ipv4  tag 64f3eb8687bce20a  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,101
	btf_id 151
490: sched_cls  name tail_handle_ipv4_cont  tag f904311caef5469b  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,102,37,100,78,79,35,72,70,73,101,36,33,34,77
	btf_id 152
491: sched_cls  name tail_ipv4_ct_ingress  tag ff52433b3f5dae6b  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,101,78,79,102,80
	btf_id 153
493: sched_cls  name tail_ipv4_ct_egress  tag 1a0ad8c51160b5af  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,103,78,79,104,80
	btf_id 156
494: sched_cls  name __send_drop_notify  tag 02a45017060ada37  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 157
495: sched_cls  name tail_handle_ipv4  tag 0ed708e8d3cebd15  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,103
	btf_id 158
496: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,103
	btf_id 159
497: sched_cls  name tail_ipv4_to_endpoint  tag 74aa9858b666804d  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,104,37,78,79,76,94,35,103,36,33,34
	btf_id 160
498: sched_cls  name tail_handle_ipv4_cont  tag 4f5fbc7b16fd3d20  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,104,37,94,78,79,35,72,70,73,103,36,33,34,77
	btf_id 161
499: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
502: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
503: sched_cls  name tail_handle_arp  tag 79c201ab17b98f07  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,103
	btf_id 162
504: sched_cls  name tail_ipv4_ct_ingress  tag 2c8dc4cd47e85b9f  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,103,78,79,104,80
	btf_id 163
505: sched_cls  name cil_from_container  tag 2b40a8ff52dca971  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 103,72
	btf_id 164
506: sched_cls  name handle_policy  tag bbee07999befc4c9  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,103,78,79,104,37,76,94,35,80,71,36,33,34
	btf_id 165
507: sched_cls  name tail_handle_arp  tag f5dcf651c881979a  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,107
	btf_id 167
508: sched_cls  name tail_ipv4_ct_ingress  tag a47199893d559e56  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 72,107,78,79,106,80
	btf_id 168
509: sched_cls  name __send_drop_notify  tag ceea721cd7e6134b  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 169
510: sched_cls  name tail_handle_ipv4  tag 616eef0004f039f2  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,107
	btf_id 170
511: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,107
	btf_id 171
512: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 72,107,78,79,106,80
	btf_id 172
513: sched_cls  name tail_ipv4_to_endpoint  tag 7eca5136be23f819  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 71,72,106,37,78,79,76,95,35,107,36,33,34
	btf_id 173
514: sched_cls  name handle_policy  tag a1d906670eb295d5  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 72,107,78,79,106,37,76,95,35,80,71,36,33,34
	btf_id 174
515: sched_cls  name tail_handle_ipv4_cont  tag 50b0e128d2076003  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 71,106,37,95,78,79,35,72,70,73,107,36,33,34,77
	btf_id 175
516: sched_cls  name cil_from_container  tag 295e2af443dc928e  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 107,72
	btf_id 176
518: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
521: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:25+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
523: sched_cls  name __send_drop_notify  tag 20b8143153da59a1  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 180
524: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 72,71,109
	btf_id 181
525: sched_cls  name tail_handle_ipv4_from_host  tag ab38adc1fb2a21ad  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,109
	btf_id 182
526: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,109
	btf_id 183
528: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 185
529: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,112
	btf_id 187
531: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 189
533: sched_cls  name __send_drop_notify  tag 20b8143153da59a1  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 191
535: sched_cls  name tail_handle_ipv4_from_host  tag ab38adc1fb2a21ad  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,112
	btf_id 193
537: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 72,113,71
	btf_id 196
538: sched_cls  name __send_drop_notify  tag 20b8143153da59a1  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 197
540: sched_cls  name tail_handle_ipv4_from_host  tag ab38adc1fb2a21ad  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,113
	btf_id 199
541: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,113
	btf_id 200
543: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
546: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
547: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
550: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
590: sched_cls  name tail_handle_ipv4_cont  tag 05d8c8c20b6192e8  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,129,37,127,78,79,35,72,70,73,128,36,33,34,77
	btf_id 217
591: sched_cls  name tail_handle_ipv4  tag 215472fb5e67824a  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,128
	btf_id 218
592: sched_cls  name tail_ipv4_ct_ingress  tag 83837643341eb2aa  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,128,78,79,129,80
	btf_id 219
593: sched_cls  name tail_ipv4_ct_egress  tag a75806671e6b4ce9  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,128,78,79,129,80
	btf_id 220
594: sched_cls  name __send_drop_notify  tag 7c80891c0ef953bb  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 221
595: sched_cls  name cil_from_container  tag 19d56a3935bc94b5  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 128,72
	btf_id 222
597: sched_cls  name tail_ipv4_to_endpoint  tag 4618b401210471c9  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,129,37,78,79,76,127,35,128,36,33,34
	btf_id 224
598: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,128
	btf_id 225
599: sched_cls  name tail_handle_arp  tag d1da1fc64a1190f8  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,128
	btf_id 226
600: sched_cls  name handle_policy  tag 12736fede1660c64  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,128,78,79,129,37,76,127,35,80,71,36,33,34
	btf_id 227
601: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
604: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
617: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
620: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
621: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
624: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
625: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
628: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
