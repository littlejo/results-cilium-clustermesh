KEY             VALUE
AgentLiveness   951509514615
UTimeOffset     3378615640625000
