Node 0, zone      DMA     38      9     16     28    152     95     39      8     11      5    157 
Node 0, zone   Normal     21      4      3      3      6      8      3      1      1      1      9 
