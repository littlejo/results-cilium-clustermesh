IP ADDRESS         LOCAL ENDPOINT INFO
172.31.168.162:0   (localhost)                                                                                        
10.72.0.41:0       id=113   sec_id=4787738 flags=0x0000 ifindex=9   mac=9E:A7:44:9B:73:A9 nodemac=76:49:DE:7F:9F:6C   
10.72.0.184:0      id=519   sec_id=4     flags=0x0000 ifindex=7   mac=D2:84:BC:60:AE:17 nodemac=4A:6A:A1:B9:BB:AF     
10.72.0.68:0       id=2450  sec_id=4787738 flags=0x0000 ifindex=11  mac=92:64:1B:D0:20:34 nodemac=9A:28:24:47:46:F7   
10.72.0.89:0       id=2321  sec_id=4787008 flags=0x0000 ifindex=15  mac=9E:AD:8A:1D:F3:4D nodemac=06:30:16:3A:87:D2   
10.72.0.140:0      (localhost)                                                                                        
