CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd163bdde_7132_4470_8a4b_7f4faa5490ce.slice/cri-containerd-8755cf15462ef361aa07e3d814fe14f1cf355bdb8b9dc77ee2c9ee168657995c.scope
    514      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd163bdde_7132_4470_8a4b_7f4faa5490ce.slice/cri-containerd-58088bf1d5b87431723e1fc3cd551b91eba2fd2318bf9caacb670b3a7760b278.scope
    499      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8e2e2756_9f49_43a9_8514_5006ae537415.slice/cri-containerd-c2ad68f73b470bfc26723386555d101924921cdf27e87658647ace90bd0d9c7f.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8e2e2756_9f49_43a9_8514_5006ae537415.slice/cri-containerd-16b1d6dd244956f6b09b6ac9fdff832cd5e196121d562caaaa2770aa6397a9a8.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67d9c840_ee9a_49a5_8740_62df244700fa.slice/cri-containerd-f8a7b14e37a593cfaa35a57a794ee3e5f5b06c123ebfd8156ed601661b33a3d3.scope
    518      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67d9c840_ee9a_49a5_8740_62df244700fa.slice/cri-containerd-aa449a62c80cad3728f9dbc9b7c86d8f7e7d272cccb3eb1b5ae5490cfe6f3c6f.scope
    494      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcae370cc_0ad3_4b07_a6d4_521320da8844.slice/cri-containerd-b58f7b543e8442e9ba220251ad457013b4dfea9db51e2155d76d7fe33a3aa7a3.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcae370cc_0ad3_4b07_a6d4_521320da8844.slice/cri-containerd-c7af0800cd261ec685107ddbd07bcd864637ca8203a23b6c59512b85f16aa657.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod19724de7_b934_4df1_b713_318706daa022.slice/cri-containerd-46d15fdd161d9d70c1dedd592ea0814611b791bfe2a21d5581c0648779fdaeb6.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod19724de7_b934_4df1_b713_318706daa022.slice/cri-containerd-e2eb844cf06b71a7adca61b1739c6c85e64f586351191bff6a24cce911da4453.scope
    72       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda851642c_5e1d_4c8e_830e_5060de0f33d1.slice/cri-containerd-dc668b298e35b91e401a520e31050f45eaf5dfd3e70abc4ed4c493b49bc871d6.scope
    76       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda851642c_5e1d_4c8e_830e_5060de0f33d1.slice/cri-containerd-72ec92e773ae4ba5e04e453a2d30c64fa2f3021a24972074d5ab7d74758c1c23.scope
    61       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podecfb682d_047a_45f4_91a6_162a1a305af5.slice/cri-containerd-34205baed9ecb8dc031ba88c12c053d9d577a6ba4b1dbecf7b52f437ecf7cc75.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podecfb682d_047a_45f4_91a6_162a1a305af5.slice/cri-containerd-4f1cd1b79ddff73dc0d976469186ce15b29f24176a7ecd462036810929cb9210.scope
    613      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podecfb682d_047a_45f4_91a6_162a1a305af5.slice/cri-containerd-17b3cb995f50d9b6cec5f0c6e095571b8d98e5c81dc26f65063931b99f69539e.scope
    617      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podecfb682d_047a_45f4_91a6_162a1a305af5.slice/cri-containerd-b0a89ffd5b192ac9c60db8e63b7e1dd6ac4e0aec1abffa173a28c3f3aa869f9c.scope
    609      cgroup_device   multi                                          
