Endpoint ID: 247
Path: /sys/fs/bpf/tc/globals/cilium_policy_00247

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3854116   36548     0        
Allow    Ingress     1          ANY          NONE         disabled    3346670   34086     0        
Allow    Egress      0          ANY          NONE         disabled    4961735   45679     0        


Endpoint ID: 326
Path: /sys/fs/bpf/tc/globals/cilium_policy_00326

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83824   955       0        
Allow    Egress      0          ANY          NONE         disabled    13540   140       0        


Endpoint ID: 884
Path: /sys/fs/bpf/tc/globals/cilium_policy_00884

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    84397   961       0        
Allow    Egress      0          ANY          NONE         disabled    13500   140       0        


Endpoint ID: 3194
Path: /sys/fs/bpf/tc/globals/cilium_policy_03194

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    433237   5514      0        
Allow    Ingress     1          ANY          NONE         disabled    14262    170       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 4027
Path: /sys/fs/bpf/tc/globals/cilium_policy_04027

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


