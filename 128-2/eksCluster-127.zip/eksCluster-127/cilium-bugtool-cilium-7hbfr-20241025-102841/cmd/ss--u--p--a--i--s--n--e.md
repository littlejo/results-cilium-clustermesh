Total: 530
TCP:   1066 (estab 285, closed 762, orphaned 0, timewait 310)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  304       296       8        
INET	  314       302       12       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                  172.31.246.169%ens5:68         0.0.0.0:*    uid:192 ino:16469 sk:1 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:22870 sk:2 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:14298 sk:3 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:45897      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:22747 sk:4 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:22869 sk:5 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:14299 sk:6 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::888:79ff:fe43:8637]%ens5:546           [::]:*    uid:192 ino:16460 sk:7 cgroup:unreachable:c4e v6only:1 <->                   
