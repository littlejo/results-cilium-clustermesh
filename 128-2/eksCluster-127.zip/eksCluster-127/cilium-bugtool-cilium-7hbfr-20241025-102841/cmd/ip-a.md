1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:88:79:43:86:37 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.246.169/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2650sec preferred_lft 2650sec
    inet6 fe80::888:79ff:fe43:8637/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:8a:76:1e:e0:e0 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ec8a:76ff:fe1e:e0e0/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:7e:be:92:90:a0 brd ff:ff:ff:ff:ff:ff
    inet 10.127.0.198/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::f47e:beff:fe92:90a0/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether a6:1f:58:33:83:95 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a41f:58ff:fe33:8395/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:df:89:af:18:a3 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f0df:89ff:feaf:18a3/64 scope link 
       valid_lft forever preferred_lft forever
9: lxcb9707da35dfa@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:c5:97:be:46:95 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::7cc5:97ff:febe:4695/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc8c8432281778@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:98:ac:d3:e8:a9 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c098:acff:fed3:e8a9/64 scope link 
       valid_lft forever preferred_lft forever
15: lxcb4a69c50e9d5@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:59:9a:10:a0:80 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::3459:9aff:fe10:a080/64 scope link 
       valid_lft forever preferred_lft forever
