filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc8c8432281778 direct-action not_in_hw id 476 tag 0def2e6dba2058a7 jited 
