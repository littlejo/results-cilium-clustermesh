 10:28:42 up 16 min,  0 users,  load average: 0.17, 0.28, 0.29
