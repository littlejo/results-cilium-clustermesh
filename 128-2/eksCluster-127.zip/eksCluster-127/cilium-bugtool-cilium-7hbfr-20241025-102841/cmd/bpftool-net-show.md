xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 536
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 526
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 525
cilium_host(4) clsact/egress cil_from_host-cilium_host id 523
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 446
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 447
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 486
lxcb9707da35dfa(9) clsact/ingress cil_from_container-lxcb9707da35dfa id 500
lxc8c8432281778(11) clsact/ingress cil_from_container-lxc8c8432281778 id 476
lxcb4a69c50e9d5(15) clsact/ingress cil_from_container-lxcb4a69c50e9d5 id 580

flow_dissector:

netfilter:

