[
  {
    "containers": [
      {
        "cgroup-id": 8370,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podecfb682d_047a_45f4_91a6_162a1a305af5.slice/cri-containerd-17b3cb995f50d9b6cec5f0c6e095571b8d98e5c81dc26f65063931b99f69539e.scope"
      },
      {
        "cgroup-id": 8286,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podecfb682d_047a_45f4_91a6_162a1a305af5.slice/cri-containerd-4f1cd1b79ddff73dc0d976469186ce15b29f24176a7ecd462036810929cb9210.scope"
      },
      {
        "cgroup-id": 8202,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podecfb682d_047a_45f4_91a6_162a1a305af5.slice/cri-containerd-b0a89ffd5b192ac9c60db8e63b7e1dd6ac4e0aec1abffa173a28c3f3aa869f9c.scope"
      }
    ],
    "ips": [
      "10.127.0.48"
    ],
    "name": "clustermesh-apiserver-54886f956c-sxg8q",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6774,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd163bdde_7132_4470_8a4b_7f4faa5490ce.slice/cri-containerd-8755cf15462ef361aa07e3d814fe14f1cf355bdb8b9dc77ee2c9ee168657995c.scope"
      }
    ],
    "ips": [
      "10.127.0.133"
    ],
    "name": "coredns-cc6ccd49c-s2jqk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6858,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67d9c840_ee9a_49a5_8740_62df244700fa.slice/cri-containerd-f8a7b14e37a593cfaa35a57a794ee3e5f5b06c123ebfd8156ed601661b33a3d3.scope"
      }
    ],
    "ips": [
      "10.127.0.29"
    ],
    "name": "coredns-cc6ccd49c-rzsdz",
    "namespace": "kube-system"
  }
]

