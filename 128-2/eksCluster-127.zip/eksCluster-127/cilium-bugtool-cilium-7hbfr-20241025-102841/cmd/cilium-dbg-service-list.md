ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.176.129:443 (active)    
                                          2 => 172.31.219.169:443 (active)    
2    10.100.62.235:443     ClusterIP      1 => 172.31.246.169:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.127.0.29:53 (active)        
                                          2 => 10.127.0.133:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.127.0.29:9153 (active)      
                                          2 => 10.127.0.133:9153 (active)     
5    10.100.106.209:2379   ClusterIP      1 => 10.127.0.48:2379 (active)      
