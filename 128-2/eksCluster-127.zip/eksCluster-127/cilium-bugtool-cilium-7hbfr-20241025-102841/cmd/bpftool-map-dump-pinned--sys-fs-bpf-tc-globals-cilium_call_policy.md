key: f7 00 00 00  value: 4c 02 00 00
key: 46 01 00 00  value: f7 01 00 00
key: 74 03 00 00  value: db 01 00 00
key: 7a 0c 00 00  value: e1 01 00 00
Found 4 elements
