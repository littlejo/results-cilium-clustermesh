alloc: 128.07MB (134288832 bytes)
total-alloc: 1.37GB (1473844840 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 48405384
frees: 47126077
heap-alloc: 128.07MB (134288832 bytes)
heap-sys: 165.08MB (173096960 bytes)
heap-idle: 20.82MB (21831680 bytes)
heap-in-use: 144.26MB (151265280 bytes)
heap-released: 9.16MB (9601024 bytes)
heap-objects: 1279307
stack-in-use: 34.88MB (36569088 bytes)
stack-sys: 34.88MB (36569088 bytes)
stack-mspan-inuse: 2.25MB (2356320 bytes)
stack-mspan-sys: 2.37MB (2480640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 990.24KB (1014001 bytes)
gc-sys: 5.17MB (5425408 bytes)
next-gc: when heap-alloc >= 165.56MB (173602888 bytes)
last-gc: 2024-10-25 10:28:42.636513998 +0000 UTC
gc-pause-total: 10.365382ms
gc-pause: 275740
gc-pause-end: 1729852122636513998
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.0009233888552148809
enable-gc: true
debug-gc: false
