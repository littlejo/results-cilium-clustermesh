{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.234Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.246.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:52.234Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:05.869Z",
  "value": "id=3194  sec_id=4     flags=0x0000 ifindex=7   mac=AA:11:C2:B0:2F:80 nodemac=F2:DF:89:AF:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:05.874Z",
  "value": "id=326   sec_id=8412465 flags=0x0000 ifindex=9   mac=1A:00:13:C4:0F:9D nodemac=7E:C5:97:BE:46:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:06.192Z",
  "value": "id=884   sec_id=8412465 flags=0x0000 ifindex=11  mac=9A:C6:9D:D0:53:6B nodemac=C2:98:AC:D3:E8:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:06.669Z",
  "value": "id=3194  sec_id=4     flags=0x0000 ifindex=7   mac=AA:11:C2:B0:2F:80 nodemac=F2:DF:89:AF:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:07.143Z",
  "value": "id=326   sec_id=8412465 flags=0x0000 ifindex=9   mac=1A:00:13:C4:0F:9D nodemac=7E:C5:97:BE:46:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:37.610Z",
  "value": "id=326   sec_id=8412465 flags=0x0000 ifindex=9   mac=1A:00:13:C4:0F:9D nodemac=7E:C5:97:BE:46:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:37.611Z",
  "value": "id=884   sec_id=8412465 flags=0x0000 ifindex=11  mac=9A:C6:9D:D0:53:6B nodemac=C2:98:AC:D3:E8:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:37.611Z",
  "value": "id=3194  sec_id=4     flags=0x0000 ifindex=7   mac=AA:11:C2:B0:2F:80 nodemac=F2:DF:89:AF:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:37.639Z",
  "value": "id=3890  sec_id=8395928 flags=0x0000 ifindex=13  mac=E6:9C:9D:A7:B9:A5 nodemac=6E:12:78:29:58:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:37.640Z",
  "value": "id=3890  sec_id=8395928 flags=0x0000 ifindex=13  mac=E6:9C:9D:A7:B9:A5 nodemac=6E:12:78:29:58:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:38.611Z",
  "value": "id=3890  sec_id=8395928 flags=0x0000 ifindex=13  mac=E6:9C:9D:A7:B9:A5 nodemac=6E:12:78:29:58:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:38.612Z",
  "value": "id=3194  sec_id=4     flags=0x0000 ifindex=7   mac=AA:11:C2:B0:2F:80 nodemac=F2:DF:89:AF:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:38.612Z",
  "value": "id=326   sec_id=8412465 flags=0x0000 ifindex=9   mac=1A:00:13:C4:0F:9D nodemac=7E:C5:97:BE:46:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:38.612Z",
  "value": "id=884   sec_id=8412465 flags=0x0000 ifindex=11  mac=9A:C6:9D:D0:53:6B nodemac=C2:98:AC:D3:E8:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:42.732Z",
  "value": "id=247   sec_id=8395928 flags=0x0000 ifindex=15  mac=B2:9B:74:DA:96:6A nodemac=36:59:9A:10:A0:80"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.127.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:48.889Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.181Z",
  "value": "id=326   sec_id=8412465 flags=0x0000 ifindex=9   mac=1A:00:13:C4:0F:9D nodemac=7E:C5:97:BE:46:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.182Z",
  "value": "id=884   sec_id=8412465 flags=0x0000 ifindex=11  mac=9A:C6:9D:D0:53:6B nodemac=C2:98:AC:D3:E8:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.183Z",
  "value": "id=247   sec_id=8395928 flags=0x0000 ifindex=15  mac=B2:9B:74:DA:96:6A nodemac=36:59:9A:10:A0:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.183Z",
  "value": "id=3194  sec_id=4     flags=0x0000 ifindex=7   mac=AA:11:C2:B0:2F:80 nodemac=F2:DF:89:AF:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.182Z",
  "value": "id=247   sec_id=8395928 flags=0x0000 ifindex=15  mac=B2:9B:74:DA:96:6A nodemac=36:59:9A:10:A0:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.183Z",
  "value": "id=3194  sec_id=4     flags=0x0000 ifindex=7   mac=AA:11:C2:B0:2F:80 nodemac=F2:DF:89:AF:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.183Z",
  "value": "id=326   sec_id=8412465 flags=0x0000 ifindex=9   mac=1A:00:13:C4:0F:9D nodemac=7E:C5:97:BE:46:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:02.183Z",
  "value": "id=884   sec_id=8412465 flags=0x0000 ifindex=11  mac=9A:C6:9D:D0:53:6B nodemac=C2:98:AC:D3:E8:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:03.182Z",
  "value": "id=247   sec_id=8395928 flags=0x0000 ifindex=15  mac=B2:9B:74:DA:96:6A nodemac=36:59:9A:10:A0:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:03.182Z",
  "value": "id=3194  sec_id=4     flags=0x0000 ifindex=7   mac=AA:11:C2:B0:2F:80 nodemac=F2:DF:89:AF:18:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:03.183Z",
  "value": "id=326   sec_id=8412465 flags=0x0000 ifindex=9   mac=1A:00:13:C4:0F:9D nodemac=7E:C5:97:BE:46:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.127.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:03.183Z",
  "value": "id=884   sec_id=8412465 flags=0x0000 ifindex=11  mac=9A:C6:9D:D0:53:6B nodemac=C2:98:AC:D3:E8:A9"
}

