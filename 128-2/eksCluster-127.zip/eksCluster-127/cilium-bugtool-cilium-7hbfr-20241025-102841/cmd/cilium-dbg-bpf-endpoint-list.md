IP ADDRESS         LOCAL ENDPOINT INFO
10.127.0.48:0      id=247   sec_id=8395928 flags=0x0000 ifindex=15  mac=B2:9B:74:DA:96:6A nodemac=36:59:9A:10:A0:80   
10.127.0.133:0     id=884   sec_id=8412465 flags=0x0000 ifindex=11  mac=9A:C6:9D:D0:53:6B nodemac=C2:98:AC:D3:E8:A9   
10.127.0.153:0     id=3194  sec_id=4     flags=0x0000 ifindex=7   mac=AA:11:C2:B0:2F:80 nodemac=F2:DF:89:AF:18:A3     
172.31.246.169:0   (localhost)                                                                                        
10.127.0.29:0      id=326   sec_id=8412465 flags=0x0000 ifindex=9   mac=1A:00:13:C4:0F:9D nodemac=7E:C5:97:BE:46:95   
10.127.0.198:0     (localhost)                                                                                        
