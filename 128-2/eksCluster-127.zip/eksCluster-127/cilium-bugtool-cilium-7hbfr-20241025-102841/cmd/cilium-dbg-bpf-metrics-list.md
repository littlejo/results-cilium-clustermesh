REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     10104     792075      677    bpf_overlay.c
Interface                 INGRESS     228300    101401342   1132   bpf_host.c
Success                   EGRESS      10330     807829      53     encap.h
Success                   EGRESS      5259      404460      1694   bpf_host.c
Success                   EGRESS      95508     12642725    1308   bpf_lxc.c
Success                   INGRESS     106963    13144201    86     l3.h
Success                   INGRESS     112455    13575582    235    trace.h
Unsupported L3 protocol   EGRESS      34        2532        1492   bpf_lxc.c
