KEY             VALUE
AgentLiveness   990794025197
UTimeOffset     3378615550781250
