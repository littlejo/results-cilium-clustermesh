32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:45+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:45+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:45+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:45+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:45+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:12:45+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:12:46+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:12:46+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:12:46+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:46+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:12:50+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
58: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
61: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
62: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
65: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
68: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:04+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
69: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
72: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
73: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
76: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
444: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 113
445: sched_cls  name tail_handle_ipv4  tag 309a881cc4bd276d  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 114
446: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 115
447: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:58+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 116
468: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,98
	btf_id 141
471: sched_cls  name tail_ipv4_to_endpoint  tag 84b262166efb22e8  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,97,33,74,75,72,96,31,98,32,29,30
	btf_id 142
472: sched_cls  name tail_handle_ipv4_cont  tag 384ce78b3973120f  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,97,33,96,74,75,31,68,66,69,98,32,29,30,73
	btf_id 144
474: sched_cls  name __send_drop_notify  tag be0a93b4879fad66  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 146
475: sched_cls  name handle_policy  tag 51a908c28aca1883  gpl
	loaded_at 2024-10-25T10:14:05+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,98,74,75,97,33,72,96,31,76,67,32,29,30
	btf_id 147
476: sched_cls  name cil_from_container  tag 0def2e6dba2058a7  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 98,68
	btf_id 148
477: sched_cls  name tail_ipv4_ct_egress  tag 2f473b216908ae03  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,98,74,75,97,76
	btf_id 149
478: sched_cls  name tail_handle_arp  tag 01b1172bf2699a5b  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,98
	btf_id 150
479: sched_cls  name tail_handle_ipv4  tag 1db113f48a968fe1  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,98
	btf_id 151
480: sched_cls  name tail_ipv4_ct_ingress  tag 83661738a6ebc215  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,98,74,75,97,76
	btf_id 152
481: sched_cls  name handle_policy  tag eadcb4e5652cc22e  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,100,74,75,99,33,72,90,31,76,67,32,29,30
	btf_id 154
482: sched_cls  name tail_handle_ipv4  tag 25c88a7cb8977720  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,100
	btf_id 155
483: sched_cls  name __send_drop_notify  tag 3fa49e575c570f89  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 156
484: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,100
	btf_id 157
485: sched_cls  name tail_handle_ipv4_cont  tag 7b661a7c859b3bcb  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,99,33,90,74,75,31,68,66,69,100,32,29,30,73
	btf_id 158
486: sched_cls  name cil_from_container  tag cebd42bb4098d4a2  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 100,68
	btf_id 159
488: sched_cls  name tail_handle_arp  tag 5f37e7278b2f6bd2  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,100
	btf_id 161
489: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,100,74,75,99,76
	btf_id 162
490: sched_cls  name tail_ipv4_ct_ingress  tag 07e9ba0239290bb9  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,100,74,75,99,76
	btf_id 163
491: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
494: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
495: sched_cls  name tail_ipv4_to_endpoint  tag ca89aa98908a6236  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,99,33,74,75,72,90,31,100,32,29,30
	btf_id 164
496: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
499: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
500: sched_cls  name cil_from_container  tag dd9df5cb496aab37  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 104,68
	btf_id 166
501: sched_cls  name tail_ipv4_ct_ingress  tag 8cb308ce3e5d52bf  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 167
502: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,104
	btf_id 168
503: sched_cls  name handle_policy  tag 4d676b15a5cc71e2  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,104,74,75,103,33,72,91,31,76,67,32,29,30
	btf_id 169
504: sched_cls  name tail_handle_ipv4  tag f81c913d539ef2ba  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,104
	btf_id 170
505: sched_cls  name __send_drop_notify  tag 40f16bc216af1995  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 171
506: sched_cls  name tail_handle_arp  tag 5138ca4829bda752  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,104
	btf_id 172
507: sched_cls  name tail_ipv4_ct_egress  tag 2f473b216908ae03  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 173
508: sched_cls  name tail_handle_ipv4_cont  tag 26cb8445c13b0b4b  gpl
	loaded_at 2024-10-25T10:14:06+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,103,33,91,74,75,31,68,66,69,104,32,29,30,73
	btf_id 174
510: sched_cls  name tail_ipv4_to_endpoint  tag 54a3612ea02fafb0  gpl
	loaded_at 2024-10-25T10:14:07+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,103,33,74,75,72,91,31,104,32,29,30
	btf_id 176
511: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
514: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
515: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
518: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
519: sched_cls  name tail_handle_ipv4_from_host  tag 02077044479ffecf  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,107
	btf_id 178
520: sched_cls  name __send_drop_notify  tag 2a917bfb7da7ae3a  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 179
521: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,107
	btf_id 180
523: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,107
	btf_id 182
525: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 184
526: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 186
527: sched_cls  name tail_handle_ipv4_from_host  tag 02077044479ffecf  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,110
	btf_id 187
528: sched_cls  name __send_drop_notify  tag 2a917bfb7da7ae3a  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 188
529: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,110
	btf_id 189
533: sched_cls  name tail_handle_ipv4_from_host  tag 02077044479ffecf  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,112
	btf_id 194
534: sched_cls  name __send_drop_notify  tag 2a917bfb7da7ae3a  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 195
535: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,112
	btf_id 196
536: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:10+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,112,67
	btf_id 197
579: sched_cls  name tail_handle_ipv4_cont  tag 835368feb4134e06  gpl
	loaded_at 2024-10-25T10:21:42+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,125,33,123,74,75,31,68,66,69,124,32,29,30,73
	btf_id 215
580: sched_cls  name cil_from_container  tag 05dd2de29099ac40  gpl
	loaded_at 2024-10-25T10:21:42+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 124,68
	btf_id 216
581: sched_cls  name tail_ipv4_to_endpoint  tag b79abf12eb25784e  gpl
	loaded_at 2024-10-25T10:21:42+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,125,33,74,75,72,123,31,124,32,29,30
	btf_id 217
582: sched_cls  name tail_handle_ipv4  tag 8c9fb8974025d6e5  gpl
	loaded_at 2024-10-25T10:21:42+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,124
	btf_id 218
583: sched_cls  name tail_ipv4_ct_egress  tag 9fa40b50b97be760  gpl
	loaded_at 2024-10-25T10:21:42+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,124,74,75,125,76
	btf_id 219
584: sched_cls  name tail_handle_arp  tag 67936f1b93e4e064  gpl
	loaded_at 2024-10-25T10:21:42+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,124
	btf_id 220
585: sched_cls  name tail_ipv4_ct_ingress  tag dbf17a7c8a70a8b5  gpl
	loaded_at 2024-10-25T10:21:42+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,124,74,75,125,76
	btf_id 221
587: sched_cls  name __send_drop_notify  tag e6d6995d21310c9b  gpl
	loaded_at 2024-10-25T10:21:42+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 223
588: sched_cls  name handle_policy  tag 260632d89488c64b  gpl
	loaded_at 2024-10-25T10:21:42+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,124,74,75,125,33,72,123,31,76,67,32,29,30
	btf_id 224
589: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:42+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,124
	btf_id 225
590: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
593: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
606: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
609: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
610: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
613: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
614: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
617: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
