top - 10:28:43 up 16 min,  0 users,  load average: 0.17, 0.28, 0.29
Tasks:   7 total,   2 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 22.6 us, 22.6 sy,  0.0 ni, 54.8 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1188.8 free,    890.7 used,   1756.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2777.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 279128  78776 S   6.2   7.1   0:23.03 cilium-+
    474 root      20   0 1228848   6916   3840 S   0.0   0.2   0:00.25 cilium-+
    800 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    806 root      20   0 1240432  16364  11420 S   0.0   0.4   0:00.02 cilium-+
    843 root      20   0    6576   2416   2088 R   0.0   0.1   0:00.00 top
    861 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
    866 root      20   0 1692104   8848   6316 R   0.0   0.2   0:00.00 runc:[2+
