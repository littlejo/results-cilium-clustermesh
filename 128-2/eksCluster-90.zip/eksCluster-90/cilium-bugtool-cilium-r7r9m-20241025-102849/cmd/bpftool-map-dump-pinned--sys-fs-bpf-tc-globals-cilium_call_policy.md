key: 79 01 00 00  value: 04 02 00 00
key: d0 05 00 00  value: 73 02 00 00
key: d8 08 00 00  value: 1a 02 00 00
key: c1 0e 00 00  value: 0c 02 00 00
Found 4 elements
