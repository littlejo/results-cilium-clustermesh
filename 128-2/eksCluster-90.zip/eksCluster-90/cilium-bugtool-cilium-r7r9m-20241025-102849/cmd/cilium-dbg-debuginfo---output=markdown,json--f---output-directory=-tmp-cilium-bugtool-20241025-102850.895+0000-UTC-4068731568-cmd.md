markdown output at /tmp/cilium-bugtool-20241025-102850.895+0000-UTC-4068731568/cmd/cilium-debuginfo-20241025-102921.363+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102850.895+0000-UTC-4068731568/cmd/cilium-debuginfo-20241025-102921.363+0000-UTC.json
