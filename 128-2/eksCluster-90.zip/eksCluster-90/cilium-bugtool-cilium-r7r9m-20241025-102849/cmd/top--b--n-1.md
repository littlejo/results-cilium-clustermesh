top - 10:28:51 up 14 min,  0 users,  load average: 0.06, 0.13, 0.09
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s):  9.7 us, 22.6 sy,  0.0 ni, 58.1 id,  0.0 wa,  0.0 hi,  6.5 si,  3.2 st
MiB Mem :   3836.2 total,    794.1 free,    899.6 used,   2142.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2767.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538228 285064  79476 S   0.0   7.3   0:20.00 cilium-+
    405 root      20   0 1228848   6668   3840 S   0.0   0.2   0:00.27 cilium-+
    672 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    684 root      20   0 1240432  15852  10832 S   0.0   0.4   0:00.02 cilium-+
    690 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    720 root      20   0    6576   2424   2100 R   0.0   0.1   0:00.00 top
    738 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
