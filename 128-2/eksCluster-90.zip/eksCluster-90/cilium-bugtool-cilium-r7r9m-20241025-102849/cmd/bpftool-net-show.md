xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 571
ens6(5) clsact/ingress cil_from_netdev-ens6 id 582
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 568
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 557
cilium_host(7) clsact/egress cil_from_host-cilium_host id 561
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 533
lxcd62c4428a79b(12) clsact/ingress cil_from_container-lxcd62c4428a79b id 527
lxc409ae9f2cf40(14) clsact/ingress cil_from_container-lxc409ae9f2cf40 id 515
lxc09892745a253(18) clsact/ingress cil_from_container-lxc09892745a253 id 625

flow_dissector:

netfilter:

