{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:31.589Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.158.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:31.589Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.162.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:31.589Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:36.194Z",
  "value": "id=3777  sec_id=5982711 flags=0x0000 ifindex=12  mac=E6:88:AB:92:6E:AF nodemac=B2:E6:2D:80:21:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:36.198Z",
  "value": "id=2264  sec_id=4     flags=0x0000 ifindex=10  mac=4A:F4:D7:35:7A:25 nodemac=7A:28:64:F4:33:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:36.283Z",
  "value": "id=377   sec_id=5982711 flags=0x0000 ifindex=14  mac=8A:5C:12:1F:AC:9D nodemac=36:FE:B3:31:EC:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:36.369Z",
  "value": "id=3777  sec_id=5982711 flags=0x0000 ifindex=12  mac=E6:88:AB:92:6E:AF nodemac=B2:E6:2D:80:21:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:36.436Z",
  "value": "id=2264  sec_id=4     flags=0x0000 ifindex=10  mac=4A:F4:D7:35:7A:25 nodemac=7A:28:64:F4:33:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:53.018Z",
  "value": "id=3777  sec_id=5982711 flags=0x0000 ifindex=12  mac=E6:88:AB:92:6E:AF nodemac=B2:E6:2D:80:21:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:53.019Z",
  "value": "id=2264  sec_id=4     flags=0x0000 ifindex=10  mac=4A:F4:D7:35:7A:25 nodemac=7A:28:64:F4:33:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:53.019Z",
  "value": "id=377   sec_id=5982711 flags=0x0000 ifindex=14  mac=8A:5C:12:1F:AC:9D nodemac=36:FE:B3:31:EC:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:53.050Z",
  "value": "id=1467  sec_id=5964560 flags=0x0000 ifindex=16  mac=0A:F0:F5:41:23:A9 nodemac=1A:0B:5E:E7:E6:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:54.019Z",
  "value": "id=1467  sec_id=5964560 flags=0x0000 ifindex=16  mac=0A:F0:F5:41:23:A9 nodemac=1A:0B:5E:E7:E6:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:54.019Z",
  "value": "id=3777  sec_id=5982711 flags=0x0000 ifindex=12  mac=E6:88:AB:92:6E:AF nodemac=B2:E6:2D:80:21:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:54.019Z",
  "value": "id=377   sec_id=5982711 flags=0x0000 ifindex=14  mac=8A:5C:12:1F:AC:9D nodemac=36:FE:B3:31:EC:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:54.019Z",
  "value": "id=2264  sec_id=4     flags=0x0000 ifindex=10  mac=4A:F4:D7:35:7A:25 nodemac=7A:28:64:F4:33:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:16.061Z",
  "value": "id=1488  sec_id=5964560 flags=0x0000 ifindex=18  mac=5E:02:19:BD:AC:B9 nodemac=F6:17:94:84:A6:96"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.90.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:26.406Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:13.271Z",
  "value": "id=1488  sec_id=5964560 flags=0x0000 ifindex=18  mac=5E:02:19:BD:AC:B9 nodemac=F6:17:94:84:A6:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:13.271Z",
  "value": "id=3777  sec_id=5982711 flags=0x0000 ifindex=12  mac=E6:88:AB:92:6E:AF nodemac=B2:E6:2D:80:21:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:13.272Z",
  "value": "id=2264  sec_id=4     flags=0x0000 ifindex=10  mac=4A:F4:D7:35:7A:25 nodemac=7A:28:64:F4:33:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:13.272Z",
  "value": "id=377   sec_id=5982711 flags=0x0000 ifindex=14  mac=8A:5C:12:1F:AC:9D nodemac=36:FE:B3:31:EC:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:14.271Z",
  "value": "id=3777  sec_id=5982711 flags=0x0000 ifindex=12  mac=E6:88:AB:92:6E:AF nodemac=B2:E6:2D:80:21:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:14.271Z",
  "value": "id=1488  sec_id=5964560 flags=0x0000 ifindex=18  mac=5E:02:19:BD:AC:B9 nodemac=F6:17:94:84:A6:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:14.271Z",
  "value": "id=2264  sec_id=4     flags=0x0000 ifindex=10  mac=4A:F4:D7:35:7A:25 nodemac=7A:28:64:F4:33:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:14.271Z",
  "value": "id=377   sec_id=5982711 flags=0x0000 ifindex=14  mac=8A:5C:12:1F:AC:9D nodemac=36:FE:B3:31:EC:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:15.272Z",
  "value": "id=1488  sec_id=5964560 flags=0x0000 ifindex=18  mac=5E:02:19:BD:AC:B9 nodemac=F6:17:94:84:A6:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:15.272Z",
  "value": "id=3777  sec_id=5982711 flags=0x0000 ifindex=12  mac=E6:88:AB:92:6E:AF nodemac=B2:E6:2D:80:21:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:15.272Z",
  "value": "id=2264  sec_id=4     flags=0x0000 ifindex=10  mac=4A:F4:D7:35:7A:25 nodemac=7A:28:64:F4:33:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.90.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:24:15.273Z",
  "value": "id=377   sec_id=5982711 flags=0x0000 ifindex=14  mac=8A:5C:12:1F:AC:9D nodemac=36:FE:B3:31:EC:59"
}

