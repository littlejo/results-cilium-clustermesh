Endpoint ID: 377
Path: /sys/fs/bpf/tc/globals/cilium_policy_00377

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    72548   834       0        
Allow    Egress      0          ANY          NONE         disabled    12802   131       0        


Endpoint ID: 691
Path: /sys/fs/bpf/tc/globals/cilium_policy_00691

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1488
Path: /sys/fs/bpf/tc/globals/cilium_policy_01488

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3858914   35179     0        
Allow    Ingress     1          ANY          NONE         disabled    2602902   25810     0        
Allow    Egress      0          ANY          NONE         disabled    3507844   32985     0        


Endpoint ID: 2264
Path: /sys/fs/bpf/tc/globals/cilium_policy_02264

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    443966   5664      0        
Allow    Ingress     1          ANY          NONE         disabled    10716    126       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3777
Path: /sys/fs/bpf/tc/globals/cilium_policy_03777

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    72614   835       0        
Allow    Egress      0          ANY          NONE         disabled    12654   128       0        


