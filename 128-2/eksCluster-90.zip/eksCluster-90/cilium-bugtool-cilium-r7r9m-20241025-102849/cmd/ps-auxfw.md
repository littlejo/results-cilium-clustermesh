USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         690  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops memstats 1
root         684  0.0  0.4 1240432 15852 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         709  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         710  0.0  0.0   3728   480 ?        R    10:28   0:00  \_ bash -c hostname
root         672  0.0  0.1 1229000 4052 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  2.6  7.2 1538228 285064 ?      Ssl  10:16   0:20 cilium-agent --config-dir=/tmp/cilium/config-map
root         405  0.0  0.1 1228848 6668 ?        Sl   10:16   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
