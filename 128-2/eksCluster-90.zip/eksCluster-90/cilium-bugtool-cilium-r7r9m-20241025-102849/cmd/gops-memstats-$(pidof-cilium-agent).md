alloc: 82.30MB (86302440 bytes)
total-alloc: 1.29GB (1384374672 bytes)
sys: 206.51MB (216540500 bytes)
lookups: 0
mallocs: 47088089
frees: 46360320
heap-alloc: 82.30MB (86302440 bytes)
heap-sys: 161.32MB (169156608 bytes)
heap-idle: 47.16MB (49455104 bytes)
heap-in-use: 114.16MB (119701504 bytes)
heap-released: 736.00KB (753664 bytes)
heap-objects: 727769
stack-in-use: 34.66MB (36339712 bytes)
stack-sys: 34.66MB (36339712 bytes)
stack-mspan-inuse: 1.90MB (1993920 bytes)
stack-mspan-sys: 2.54MB (2660160 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 824.99KB (844793 bytes)
gc-sys: 5.27MB (5521640 bytes)
next-gc: when heap-alloc >= 148.71MB (155936200 bytes)
last-gc: 2024-10-25 10:29:01.77112164 +0000 UTC
gc-pause-total: 12.724619ms
gc-pause: 79927
gc-pause-end: 1729852141771121640
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.0003134448091832561
enable-gc: true
debug-gc: false
