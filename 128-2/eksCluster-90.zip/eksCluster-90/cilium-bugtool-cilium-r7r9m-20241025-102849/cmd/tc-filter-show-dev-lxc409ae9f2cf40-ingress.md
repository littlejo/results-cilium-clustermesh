filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc409ae9f2cf40 direct-action not_in_hw id 515 tag 0668f7c0cb985dc2 jited 
