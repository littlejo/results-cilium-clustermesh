IP ADDRESS         LOCAL ENDPOINT INFO
10.90.0.123:0      id=377   sec_id=5982711 flags=0x0000 ifindex=14  mac=8A:5C:12:1F:AC:9D nodemac=36:FE:B3:31:EC:59   
10.90.0.141:0      id=2264  sec_id=4     flags=0x0000 ifindex=10  mac=4A:F4:D7:35:7A:25 nodemac=7A:28:64:F4:33:8C     
172.31.162.75:0    (localhost)                                                                                        
172.31.158.174:0   (localhost)                                                                                        
10.90.0.226:0      (localhost)                                                                                        
10.90.0.66:0       id=1488  sec_id=5964560 flags=0x0000 ifindex=18  mac=5E:02:19:BD:AC:B9 nodemac=F6:17:94:84:A6:96   
10.90.0.218:0      id=3777  sec_id=5982711 flags=0x0000 ifindex=12  mac=E6:88:AB:92:6E:AF nodemac=B2:E6:2D:80:21:7A   
