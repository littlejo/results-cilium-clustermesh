[
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8985fe90_1c90_4ada_8c9e_e3e7e7c65c03.slice/cri-containerd-65193de3aa9b68e7f0db07e5e073a5113bc222af50bf3c649cf858d120a2f4c8.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8985fe90_1c90_4ada_8c9e_e3e7e7c65c03.slice/cri-containerd-cc543f0393323d8da2d6e357823c63c2f405dcda0b0ff6116705a6a28d69d6a6.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8985fe90_1c90_4ada_8c9e_e3e7e7c65c03.slice/cri-containerd-6ccd219d8e5c50641c6f5296356f1e4158a343fd6bee9047e5e239fdece78784.scope"
      }
    ],
    "ips": [
      "10.90.0.66"
    ],
    "name": "clustermesh-apiserver-6ffd5c84d9-xgb9m",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod96cdeb66_2e08_44c6_b55e_06984b2e191f.slice/cri-containerd-78636accebc0e2dbdbaac8ea187a4daba772fe2d9c5523cbc994c5c031a294a6.scope"
      }
    ],
    "ips": [
      "10.90.0.123"
    ],
    "name": "coredns-cc6ccd49c-jdsg2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa17c1ac_022f_49a7_920b_53a1a04d8db9.slice/cri-containerd-b02768517d680d387319126ded60a20d3bb09cba58187e9b31edd470955ac673.scope"
      }
    ],
    "ips": [
      "10.90.0.218"
    ],
    "name": "coredns-cc6ccd49c-qbd85",
    "namespace": "kube-system"
  }
]

