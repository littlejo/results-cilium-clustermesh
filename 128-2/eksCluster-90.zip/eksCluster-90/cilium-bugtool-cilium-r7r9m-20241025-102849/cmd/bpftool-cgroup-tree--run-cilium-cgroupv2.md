CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1c72efa8_59ac_45a2_a008_3102d95ba16e.slice/cri-containerd-52471157c7e171d2a3ca3fa4ae88a42c9b637b125ba5d9c3c209ae4de6d3fbec.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1c72efa8_59ac_45a2_a008_3102d95ba16e.slice/cri-containerd-d9eb2199df8b1841465c4841d5711ff597527e46000dd75c4def7accfb551738.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ab961a4_5ff0_4067_af73_00edcdf87251.slice/cri-containerd-323971402995eb4e3e196ce762a19a57175d31d647e7cf98e81d258a6d3917e0.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ab961a4_5ff0_4067_af73_00edcdf87251.slice/cri-containerd-a742fac925ca65542c55d5d8cbaee6bbd83df5bf5d21f46f5e789b7140438c03.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod96cdeb66_2e08_44c6_b55e_06984b2e191f.slice/cri-containerd-78636accebc0e2dbdbaac8ea187a4daba772fe2d9c5523cbc994c5c031a294a6.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod96cdeb66_2e08_44c6_b55e_06984b2e191f.slice/cri-containerd-7d30583a6ec7a2b9c38d5e556e25130f43c8716f1493d86c900571f0f53695a6.scope
    543      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa17c1ac_022f_49a7_920b_53a1a04d8db9.slice/cri-containerd-d3e93f1d0f3c2518f2de0f072e2db81d5d1e5d853f8014dbc906820fb849a7cb.scope
    523      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa17c1ac_022f_49a7_920b_53a1a04d8db9.slice/cri-containerd-b02768517d680d387319126ded60a20d3bb09cba58187e9b31edd470955ac673.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b93eede_6e33_4b7d_88b5_919bca3d46bc.slice/cri-containerd-22e207619f0cadb683768f619d4010eb973060e6a8b4b34d28fb61c817c14f6f.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b93eede_6e33_4b7d_88b5_919bca3d46bc.slice/cri-containerd-3e7f5ab114278afd4d6909772c588bebc492756861f1e3a152ad31d6be387fcf.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7aed477f_3b56_489a_978e_7e91e091bcb7.slice/cri-containerd-3fbbbf0d31f91253d5baac181a960f0569ec076bc36643cd1b58dfb4ca554e48.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7aed477f_3b56_489a_978e_7e91e091bcb7.slice/cri-containerd-5086ac794ad2726ec21b54e1ac116b3651467f2c7ed19ab98a2f255cab4709bb.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8985fe90_1c90_4ada_8c9e_e3e7e7c65c03.slice/cri-containerd-6ccd219d8e5c50641c6f5296356f1e4158a343fd6bee9047e5e239fdece78784.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8985fe90_1c90_4ada_8c9e_e3e7e7c65c03.slice/cri-containerd-65193de3aa9b68e7f0db07e5e073a5113bc222af50bf3c649cf858d120a2f4c8.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8985fe90_1c90_4ada_8c9e_e3e7e7c65c03.slice/cri-containerd-cc543f0393323d8da2d6e357823c63c2f405dcda0b0ff6116705a6a28d69d6a6.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8985fe90_1c90_4ada_8c9e_e3e7e7c65c03.slice/cri-containerd-2473238ab73f043c24d707c54a63e760da549f0dbb4ef9ccbd89d0d53fdb879f.scope
    637      cgroup_device   multi                                          
