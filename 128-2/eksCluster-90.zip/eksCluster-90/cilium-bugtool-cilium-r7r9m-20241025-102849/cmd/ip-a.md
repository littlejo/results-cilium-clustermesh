1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:37:e2:62:e7:c1 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.162.75/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2766sec preferred_lft 2766sec
    inet6 fe80::437:e2ff:fe62:e7c1/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:52:89:40:07:b3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.158.174/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::452:89ff:fe40:7b3/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:ee:50:5f:cf:6f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d8ee:50ff:fe5f:cf6f/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:3e:cf:91:a5:6a brd ff:ff:ff:ff:ff:ff
    inet 10.90.0.226/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::543e:cfff:fe91:a56a/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether e6:f3:53:4f:c9:cb brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e4f3:53ff:fe4f:c9cb/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:28:64:f4:33:8c brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::7828:64ff:fef4:338c/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcd62c4428a79b@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:e6:2d:80:21:7a brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b0e6:2dff:fe80:217a/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc409ae9f2cf40@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:fe:b3:31:ec:59 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::34fe:b3ff:fe31:ec59/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc09892745a253@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:17:94:84:a6:96 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::f417:94ff:fe84:a696/64 scope link 
       valid_lft forever preferred_lft forever
