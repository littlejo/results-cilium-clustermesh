Node 0, zone      DMA      2      1     17     17      8     16     35     15      5      2    167 
Node 0, zone   Normal    539     17     17     27      7      3      3      2      2      1      8 
