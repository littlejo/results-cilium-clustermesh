REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     202140    82635194   1132   bpf_host.c
Interface                 INGRESS     8943      697058     677    bpf_overlay.c
Success                   EGRESS      3937      297694     1694   bpf_host.c
Success                   EGRESS      8362      654582     53     encap.h
Success                   EGRESS      85678     11821860   1308   bpf_lxc.c
Success                   INGRESS     101233    12093390   235    trace.h
Success                   INGRESS     95578     11650120   86     l3.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
