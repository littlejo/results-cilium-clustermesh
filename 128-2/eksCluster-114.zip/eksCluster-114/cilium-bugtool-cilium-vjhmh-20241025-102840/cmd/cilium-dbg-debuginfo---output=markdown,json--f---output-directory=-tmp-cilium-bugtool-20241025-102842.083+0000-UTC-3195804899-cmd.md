markdown output at /tmp/cilium-bugtool-20241025-102842.083+0000-UTC-3195804899/cmd/cilium-debuginfo-20241025-102912.721+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102842.083+0000-UTC-3195804899/cmd/cilium-debuginfo-20241025-102912.721+0000-UTC.json
