key: 24 00 00 00  value: 6a 02 00 00
key: 63 00 00 00  value: 28 02 00 00
key: 9f 09 00 00  value: 20 02 00 00
key: 30 0f 00 00  value: 0b 02 00 00
Found 4 elements
