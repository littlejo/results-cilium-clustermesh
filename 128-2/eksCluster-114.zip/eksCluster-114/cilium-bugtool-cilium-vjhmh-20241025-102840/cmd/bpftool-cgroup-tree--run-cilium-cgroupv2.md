CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod849fdc44_bf7c_4243_a242_fb84c1ba09cd.slice/cri-containerd-c667c731b1260c27760f0b0466203a8aaeb2242b0a832c61d949979f3d1c73d1.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod849fdc44_bf7c_4243_a242_fb84c1ba09cd.slice/cri-containerd-4ccb4f35dba4e7efbe6600e9e1c47ea6d3f9a813d747bd3a2326d4ed42aa74a2.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod769dec14_ffa5_4b42_821f_84b423190bde.slice/cri-containerd-362afd87a15618d2673900393967073738ded06d8be10b8baa741f289f933216.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod769dec14_ffa5_4b42_821f_84b423190bde.slice/cri-containerd-edc20e11ae2eb510f0ea252702851398ea8f48d10cb23301650734edcdc5646f.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod33b7a76d_4a08_485c_90c9_b7dfa7c06c82.slice/cri-containerd-097a636b126210262ad4a450d8c3e7d7aa2c973c96b8f851a5919a07a11020d1.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod33b7a76d_4a08_485c_90c9_b7dfa7c06c82.slice/cri-containerd-d191be03e6fe46806b200593b719b8479093ec5294fe4ca33f70c266ce6aa856.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod40e56f02_cd51_4a1a_9140_317983a7e0e9.slice/cri-containerd-ca3d0c49074d27b9a5a73793d2a4f48de546af605344fec666e418818b1ed555.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod40e56f02_cd51_4a1a_9140_317983a7e0e9.slice/cri-containerd-a6ee32e4a961860ae117e876b1361aca9d4918ad9886b03d8b4ee4e47d2edd13.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod277787ff_b094_47d0_9eb6_b5adcfdadcef.slice/cri-containerd-7630e642a2c8a108ea0fa28c17de0e8ceb173ebccab5d936a07eab9097245e46.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod277787ff_b094_47d0_9eb6_b5adcfdadcef.slice/cri-containerd-4c54326ceddf3fc9cc9b36b8d2c92b3121565dd51e8ef59e5baae65df4416d5b.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod334c9459_e982_44a5_9c3c_b7dc0e9f5cde.slice/cri-containerd-66bbd91fd8f711802fb9c60ab1d62f1f31048f6c7f2b0f80147245886af3f7e1.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod334c9459_e982_44a5_9c3c_b7dc0e9f5cde.slice/cri-containerd-8e789f51f82835eef76c4309b9ab711a3586d44de5d6de68faeffbe324f305dc.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod334c9459_e982_44a5_9c3c_b7dc0e9f5cde.slice/cri-containerd-e427eec054f098e642f8bb2bf2cb6a3bfccfc92765d49834ba158dc780ce793a.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod334c9459_e982_44a5_9c3c_b7dc0e9f5cde.slice/cri-containerd-d7fd587098aae764f160cc507f53947b0019a3bb93bd75d47ffe4d66f01c6c64.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3fef812d_be7a_4461_b79c_d93e68783217.slice/cri-containerd-7b0fea2d64e7fcf499e94b213d4743af19600de8b2efd593ed611188d8b97f4e.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3fef812d_be7a_4461_b79c_d93e68783217.slice/cri-containerd-5fe97c1e21d57f05927d85b5f46fbbd30482972a4995ca8fa991665675d965b7.scope
    103      cgroup_device   multi                                          
