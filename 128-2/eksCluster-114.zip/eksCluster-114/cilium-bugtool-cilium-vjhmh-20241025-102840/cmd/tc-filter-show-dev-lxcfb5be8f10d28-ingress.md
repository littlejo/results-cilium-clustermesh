filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcfb5be8f10d28 direct-action not_in_hw id 613 tag 54e16b08f5502e1c jited 
