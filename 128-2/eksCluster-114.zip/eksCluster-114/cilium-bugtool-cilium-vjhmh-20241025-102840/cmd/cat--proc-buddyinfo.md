Node 0, zone      DMA      2      1      2      3      2      2      2      4      3      2    167 
Node 0, zone   Normal    442     89     32      5     21     10      1      2      3      2      7 
