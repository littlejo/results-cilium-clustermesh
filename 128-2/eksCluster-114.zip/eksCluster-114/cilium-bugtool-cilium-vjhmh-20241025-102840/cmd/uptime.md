 10:28:42 up 13 min,  0 users,  load average: 0.22, 0.28, 0.24
