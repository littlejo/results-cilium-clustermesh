1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:c3:fd:96:2d:73 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.143.66/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2787sec preferred_lft 2787sec
    inet6 fe80::4c3:fdff:fe96:2d73/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d0:a6:2c:11:75 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.170.78/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4d0:a6ff:fe2c:1175/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:b7:4e:ee:5d:15 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8cb7:4eff:feee:5d15/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:c5:13:17:5f:d8 brd ff:ff:ff:ff:ff:ff
    inet 10.114.0.17/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::40c5:13ff:fe17:5fd8/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 42:e9:38:a9:b6:21 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::40e9:38ff:fea9:b621/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:24:42:ba:f1:c1 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::1c24:42ff:feba:f1c1/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc314f4c1e86e6@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:29:6e:03:47:1f brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::a429:6eff:fe03:471f/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc53bef211e503@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:9d:0a:bd:d6:32 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c49d:aff:febd:d632/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcfb5be8f10d28@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:c2:aa:57:5c:e3 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::a8c2:aaff:fe57:5ce3/64 scope link 
       valid_lft forever preferred_lft forever
