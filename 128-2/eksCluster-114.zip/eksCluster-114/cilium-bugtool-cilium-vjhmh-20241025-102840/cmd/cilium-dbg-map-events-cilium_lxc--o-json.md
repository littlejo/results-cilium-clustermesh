{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.049Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.143.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.049Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.170.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:55.049Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:59.498Z",
  "value": "id=3888  sec_id=7551770 flags=0x0000 ifindex=12  mac=46:3B:56:96:AB:E6 nodemac=A6:29:6E:03:47:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:59.506Z",
  "value": "id=99    sec_id=4     flags=0x0000 ifindex=10  mac=CA:B5:DC:76:68:AB nodemac=1E:24:42:BA:F1:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:59.565Z",
  "value": "id=2463  sec_id=7551770 flags=0x0000 ifindex=14  mac=C6:EB:82:35:19:2D nodemac=C6:9D:0A:BD:D6:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:59.579Z",
  "value": "id=99    sec_id=4     flags=0x0000 ifindex=10  mac=CA:B5:DC:76:68:AB nodemac=1E:24:42:BA:F1:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.592Z",
  "value": "id=99    sec_id=4     flags=0x0000 ifindex=10  mac=CA:B5:DC:76:68:AB nodemac=1E:24:42:BA:F1:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.593Z",
  "value": "id=3888  sec_id=7551770 flags=0x0000 ifindex=12  mac=46:3B:56:96:AB:E6 nodemac=A6:29:6E:03:47:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.593Z",
  "value": "id=2463  sec_id=7551770 flags=0x0000 ifindex=14  mac=C6:EB:82:35:19:2D nodemac=C6:9D:0A:BD:D6:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.623Z",
  "value": "id=2099  sec_id=7562843 flags=0x0000 ifindex=16  mac=62:71:DE:74:DD:52 nodemac=C6:0F:7B:6D:C8:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:11.593Z",
  "value": "id=99    sec_id=4     flags=0x0000 ifindex=10  mac=CA:B5:DC:76:68:AB nodemac=1E:24:42:BA:F1:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:11.593Z",
  "value": "id=3888  sec_id=7551770 flags=0x0000 ifindex=12  mac=46:3B:56:96:AB:E6 nodemac=A6:29:6E:03:47:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:11.594Z",
  "value": "id=2463  sec_id=7551770 flags=0x0000 ifindex=14  mac=C6:EB:82:35:19:2D nodemac=C6:9D:0A:BD:D6:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:11.594Z",
  "value": "id=2099  sec_id=7562843 flags=0x0000 ifindex=16  mac=62:71:DE:74:DD:52 nodemac=C6:0F:7B:6D:C8:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:45.054Z",
  "value": "id=36    sec_id=7562843 flags=0x0000 ifindex=18  mac=16:4E:93:C9:AF:29 nodemac=AA:C2:AA:57:5C:E3"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.114.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:55.376Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:35.995Z",
  "value": "id=2463  sec_id=7551770 flags=0x0000 ifindex=14  mac=C6:EB:82:35:19:2D nodemac=C6:9D:0A:BD:D6:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:35.997Z",
  "value": "id=36    sec_id=7562843 flags=0x0000 ifindex=18  mac=16:4E:93:C9:AF:29 nodemac=AA:C2:AA:57:5C:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:35.998Z",
  "value": "id=99    sec_id=4     flags=0x0000 ifindex=10  mac=CA:B5:DC:76:68:AB nodemac=1E:24:42:BA:F1:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:35.999Z",
  "value": "id=3888  sec_id=7551770 flags=0x0000 ifindex=12  mac=46:3B:56:96:AB:E6 nodemac=A6:29:6E:03:47:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:36.992Z",
  "value": "id=36    sec_id=7562843 flags=0x0000 ifindex=18  mac=16:4E:93:C9:AF:29 nodemac=AA:C2:AA:57:5C:E3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:36.992Z",
  "value": "id=99    sec_id=4     flags=0x0000 ifindex=10  mac=CA:B5:DC:76:68:AB nodemac=1E:24:42:BA:F1:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:36.992Z",
  "value": "id=3888  sec_id=7551770 flags=0x0000 ifindex=12  mac=46:3B:56:96:AB:E6 nodemac=A6:29:6E:03:47:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:36.992Z",
  "value": "id=2463  sec_id=7551770 flags=0x0000 ifindex=14  mac=C6:EB:82:35:19:2D nodemac=C6:9D:0A:BD:D6:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:37.992Z",
  "value": "id=99    sec_id=4     flags=0x0000 ifindex=10  mac=CA:B5:DC:76:68:AB nodemac=1E:24:42:BA:F1:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:37.992Z",
  "value": "id=2463  sec_id=7551770 flags=0x0000 ifindex=14  mac=C6:EB:82:35:19:2D nodemac=C6:9D:0A:BD:D6:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:37.992Z",
  "value": "id=3888  sec_id=7551770 flags=0x0000 ifindex=12  mac=46:3B:56:96:AB:E6 nodemac=A6:29:6E:03:47:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.114.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:37.992Z",
  "value": "id=36    sec_id=7562843 flags=0x0000 ifindex=18  mac=16:4E:93:C9:AF:29 nodemac=AA:C2:AA:57:5C:E3"
}

