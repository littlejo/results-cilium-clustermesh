KEY             VALUE
AgentLiveness   852608896279
UTimeOffset     3378615820312500
