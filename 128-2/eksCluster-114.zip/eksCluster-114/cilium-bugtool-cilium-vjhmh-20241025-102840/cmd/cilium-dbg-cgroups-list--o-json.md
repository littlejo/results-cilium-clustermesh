[
  {
    "containers": [
      {
        "cgroup-id": 9220,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod334c9459_e982_44a5_9c3c_b7dc0e9f5cde.slice/cri-containerd-8e789f51f82835eef76c4309b9ab711a3586d44de5d6de68faeffbe324f305dc.scope"
      },
      {
        "cgroup-id": 9136,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod334c9459_e982_44a5_9c3c_b7dc0e9f5cde.slice/cri-containerd-d7fd587098aae764f160cc507f53947b0019a3bb93bd75d47ffe4d66f01c6c64.scope"
      },
      {
        "cgroup-id": 9304,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod334c9459_e982_44a5_9c3c_b7dc0e9f5cde.slice/cri-containerd-e427eec054f098e642f8bb2bf2cb6a3bfccfc92765d49834ba158dc780ce793a.scope"
      }
    ],
    "ips": [
      "10.114.0.25"
    ],
    "name": "clustermesh-apiserver-8595d85bd7-m66rq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod769dec14_ffa5_4b42_821f_84b423190bde.slice/cri-containerd-362afd87a15618d2673900393967073738ded06d8be10b8baa741f289f933216.scope"
      }
    ],
    "ips": [
      "10.114.0.181"
    ],
    "name": "coredns-cc6ccd49c-jxb4b",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod33b7a76d_4a08_485c_90c9_b7dfa7c06c82.slice/cri-containerd-d191be03e6fe46806b200593b719b8479093ec5294fe4ca33f70c266ce6aa856.scope"
      }
    ],
    "ips": [
      "10.114.0.172"
    ],
    "name": "coredns-cc6ccd49c-hlc6b",
    "namespace": "kube-system"
  }
]

