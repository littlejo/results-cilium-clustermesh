Endpoint ID: 36
Path: /sys/fs/bpf/tc/globals/cilium_policy_00036

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3859165   36573     0        
Allow    Ingress     1          ANY          NONE         disabled    3161412   32026     0        
Allow    Egress      0          ANY          NONE         disabled    4919428   45230     0        


Endpoint ID: 99
Path: /sys/fs/bpf/tc/globals/cilium_policy_00099

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    433522   5523      0        
Allow    Ingress     1          ANY          NONE         disabled    10484    122       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1372
Path: /sys/fs/bpf/tc/globals/cilium_policy_01372

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2463
Path: /sys/fs/bpf/tc/globals/cilium_policy_02463

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    68647   787       0        
Allow    Egress      0          ANY          NONE         disabled    12821   132       0        


Endpoint ID: 3888
Path: /sys/fs/bpf/tc/globals/cilium_policy_03888

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69043   793       0        
Allow    Egress      0          ANY          NONE         disabled    12373   127       0        


