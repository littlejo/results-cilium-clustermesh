ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.137.114:443 (active)   
                                          2 => 172.31.255.63:443 (active)    
2    10.100.156.30:443     ClusterIP      1 => 172.31.143.66:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.114.0.172:53 (active)      
                                          2 => 10.114.0.181:53 (active)      
4    10.100.0.10:9153      ClusterIP      1 => 10.114.0.172:9153 (active)    
                                          2 => 10.114.0.181:9153 (active)    
5    10.100.143.152:2379   ClusterIP      1 => 10.114.0.25:2379 (active)     
