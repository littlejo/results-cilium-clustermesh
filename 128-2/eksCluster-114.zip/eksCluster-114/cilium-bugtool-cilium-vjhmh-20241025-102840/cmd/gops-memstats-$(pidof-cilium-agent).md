alloc: 109.85MB (115181648 bytes)
total-alloc: 1.34GB (1442152952 bytes)
sys: 210.13MB (220341588 bytes)
lookups: 0
mallocs: 47929564
frees: 46844317
heap-alloc: 109.85MB (115181648 bytes)
heap-sys: 165.13MB (173154304 bytes)
heap-idle: 34.20MB (35864576 bytes)
heap-in-use: 130.93MB (137289728 bytes)
heap-released: 3.00MB (3145728 bytes)
heap-objects: 1085247
stack-in-use: 34.84MB (36536320 bytes)
stack-sys: 34.84MB (36536320 bytes)
stack-mspan-inuse: 2.08MB (2183840 bytes)
stack-mspan-sys: 2.49MB (2611200 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 669.19KB (685249 bytes)
gc-sys: 5.11MB (5355608 bytes)
next-gc: when heap-alloc >= 146.62MB (153742504 bytes)
last-gc: 2024-10-25 10:28:45.732876594 +0000 UTC
gc-pause-total: 18.642313ms
gc-pause: 79099
gc-pause-end: 1729852125732876594
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.0005931664969663977
enable-gc: true
debug-gc: false
