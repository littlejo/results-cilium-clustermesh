USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         917  0.0  0.4 1240432 15840 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         939  0.0  0.0   6408  1632 ?        R    10:28   0:00  \_ ps auxfw
root         910  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops stack 1
root         897  0.0  0.0 1228744 3656 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  3.1  6.9 1472240 271216 ?      Ssl  10:16   0:22 cilium-agent --config-dir=/tmp/cilium/config-map
root         656  0.0  0.1 1228848 6904 ?        Sl   10:16   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
