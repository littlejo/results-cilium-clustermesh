IP ADDRESS        LOCAL ENDPOINT INFO
172.31.143.66:0   (localhost)                                                                                        
10.114.0.223:0    id=99    sec_id=4     flags=0x0000 ifindex=10  mac=CA:B5:DC:76:68:AB nodemac=1E:24:42:BA:F1:C1     
10.114.0.172:0    id=3888  sec_id=7551770 flags=0x0000 ifindex=12  mac=46:3B:56:96:AB:E6 nodemac=A6:29:6E:03:47:1F   
10.114.0.181:0    id=2463  sec_id=7551770 flags=0x0000 ifindex=14  mac=C6:EB:82:35:19:2D nodemac=C6:9D:0A:BD:D6:32   
10.114.0.17:0     (localhost)                                                                                        
10.114.0.25:0     id=36    sec_id=7562843 flags=0x0000 ifindex=18  mac=16:4E:93:C9:AF:29 nodemac=AA:C2:AA:57:5C:E3   
172.31.170.78:0   (localhost)                                                                                        
