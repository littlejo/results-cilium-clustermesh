REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10120     792916     677    bpf_overlay.c
Interface                 INGRESS     221477    85466465   1132   bpf_host.c
Success                   EGRESS      10329     807720     53     encap.h
Success                   EGRESS      5261      404496     1694   bpf_host.c
Success                   EGRESS      93745     12402339   1308   bpf_lxc.c
Success                   INGRESS     104403    12887720   86     l3.h
Success                   INGRESS     109911    13320046   235    trace.h
Unsupported L3 protocol   EGRESS      41        3102       1492   bpf_lxc.c
