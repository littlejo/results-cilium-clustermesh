Node 0, zone      DMA      5      6      4      4     10      9      8      7      6      6    222 
Node 0, zone   Normal      2      2      1      2      0     10      3      1      1      0     13 
