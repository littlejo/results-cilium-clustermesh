CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9da378d6_e284_403b_a3a7_f98212602c18.slice/cri-containerd-2d5afe08b6db232bd8b4c8c603dfa62948f79758ecc828af4dcf804956fd2d46.scope
    524      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9da378d6_e284_403b_a3a7_f98212602c18.slice/cri-containerd-5379ef791d483d34533af23d9867a89676dec4ced64703f6566a16acb7380ab0.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod74ade53a_5670_4433_b8cf_aae37272f006.slice/cri-containerd-095a7c6bc99ef62cef81d369157f25f0bed8096b1e8d09883f2fee08ae50baef.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod74ade53a_5670_4433_b8cf_aae37272f006.slice/cri-containerd-bb2d0c1391859250cf923eec091bd21e9f04d7935c7785024b185c284583d791.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcc3578e7_3ce7_4c2b_be30_b4bb8a7300f6.slice/cri-containerd-dc7d7fc636e38fc9d939ddf178a23364900bedd352a3fd427972573f58f2999e.scope
    72       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcc3578e7_3ce7_4c2b_be30_b4bb8a7300f6.slice/cri-containerd-2c40a55cc06a17ffb177610155594dc0e8d0319e713b8aec8abe40c5f1c39b9e.scope
    107      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3bb58c9b_6bf3_491d_9c1d_0f79556e5817.slice/cri-containerd-ced423e370e97d13aea9f2c25dbd4838eed8d6df5498cd0ecc0316661a4688d0.scope
    520      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3bb58c9b_6bf3_491d_9c1d_0f79556e5817.slice/cri-containerd-9e5e2d434fff5290bad16dd2d07cbc90728ab4de6ced31020eb0933358ee75d7.scope
    528      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e1e5d44_4868_4a45_ae2f_8b50d8545964.slice/cri-containerd-d34667199a97d1343e0f6d0fe73fa532c874ad1a7a00c7e911ff2de2cefe4c6c.scope
    76       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e1e5d44_4868_4a45_ae2f_8b50d8545964.slice/cri-containerd-d87ca95bba25c98e6afdbb2f136cb38ae06ab31b1e830b800d1e5f269d3ab987.scope
    64       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95293618_36b0_4fd3_8ed5_f4f38200e14f.slice/cri-containerd-836b7c9596b4090d5513d0544a23da602269d4cd919e62e1628032f5bf74cbc7.scope
    610      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95293618_36b0_4fd3_8ed5_f4f38200e14f.slice/cri-containerd-667c285df84dc1c2f64454fd9532c06f5105a562247ebc218d3af09b94bbb501.scope
    602      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95293618_36b0_4fd3_8ed5_f4f38200e14f.slice/cri-containerd-4cb711a669ea7e11d2a2a73f47c0e5906f58ee1c9be03ba8e0a12da2f12b6f4e.scope
    606      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95293618_36b0_4fd3_8ed5_f4f38200e14f.slice/cri-containerd-a472d42869155d43b04ae54ddf080127ba76a0befe6d5423fad98eb28d58b7ba.scope
    586      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0825548b_fc77_4c53_b467_ea571807ed66.slice/cri-containerd-f2602c5d410c52fbe4b964f24a4d03579f5daa760f0b9bbef5dcf4717491b2a6.scope
    80       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0825548b_fc77_4c53_b467_ea571807ed66.slice/cri-containerd-5d4d7ad69c50e620f8b20d1883d13f8501e25b78d10c76d494551459160b1316.scope
    68       cgroup_device   multi                                          
