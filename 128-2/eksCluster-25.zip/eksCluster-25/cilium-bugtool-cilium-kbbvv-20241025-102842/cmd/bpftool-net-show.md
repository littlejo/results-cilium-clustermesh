xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 471
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 462
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 457
cilium_host(4) clsact/egress cil_from_host-cilium_host id 452
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 449
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 448
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 516
lxcfbc8ef1fa150(9) clsact/ingress cil_from_container-lxcfbc8ef1fa150 id 486
lxcd7c013290867(11) clsact/ingress cil_from_container-lxcd7c013290867 id 509
lxc3a4a24bc8560(15) clsact/ingress cil_from_container-lxc3a4a24bc8560 id 578

flow_dissector:

netfilter:

