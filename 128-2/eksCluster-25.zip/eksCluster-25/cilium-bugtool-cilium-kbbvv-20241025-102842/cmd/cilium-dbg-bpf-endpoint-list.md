IP ADDRESS         LOCAL ENDPOINT INFO
10.25.0.193:0      (localhost)                                                                                        
10.25.0.179:0      id=659   sec_id=1705444 flags=0x0000 ifindex=11  mac=12:2A:A9:57:E0:8E nodemac=E6:2C:5E:12:A4:8F   
10.25.0.72:0       id=1457  sec_id=4     flags=0x0000 ifindex=7   mac=36:31:CB:EB:FA:B1 nodemac=52:93:D0:C8:DD:4E     
172.31.217.133:0   (localhost)                                                                                        
10.25.0.58:0       id=681   sec_id=1751173 flags=0x0000 ifindex=15  mac=0E:B1:24:EF:58:11 nodemac=9E:21:F1:E7:EE:28   
10.25.0.30:0       id=2854  sec_id=1705444 flags=0x0000 ifindex=9   mac=AE:0C:FE:ED:01:62 nodemac=DA:EC:F1:B5:6B:20   
