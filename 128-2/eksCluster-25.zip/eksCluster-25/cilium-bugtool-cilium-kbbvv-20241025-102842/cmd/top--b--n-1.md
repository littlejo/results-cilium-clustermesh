top - 10:28:43 up 15 min,  0 users,  load average: 0.11, 0.12, 0.09
Tasks:   9 total,   2 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 35.5 us, 51.6 sy,  0.0 ni, 12.9 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1034.3 free,    884.3 used,   1917.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2783.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1472624 274120  77096 S   0.0   7.0   0:18.98 cilium-+
    394 root      20   0 1228848   5780   2868 S   0.0   0.1   0:00.24 cilium-+
    615 root      20   0 1240432  16084  11100 S   0.0   0.4   0:00.02 cilium-+
    641 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    651 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    684 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    690 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
    691 root      20   0 1228744   3132   2660 R   0.0   0.1   0:00.00 gops
    697 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
