filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcd7c013290867 direct-action not_in_hw id 509 tag e35fe199016a4ef8 jited 
