[
  {
    "containers": [
      {
        "cgroup-id": 8627,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95293618_36b0_4fd3_8ed5_f4f38200e14f.slice/cri-containerd-836b7c9596b4090d5513d0544a23da602269d4cd919e62e1628032f5bf74cbc7.scope"
      },
      {
        "cgroup-id": 8543,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95293618_36b0_4fd3_8ed5_f4f38200e14f.slice/cri-containerd-4cb711a669ea7e11d2a2a73f47c0e5906f58ee1c9be03ba8e0a12da2f12b6f4e.scope"
      },
      {
        "cgroup-id": 8459,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod95293618_36b0_4fd3_8ed5_f4f38200e14f.slice/cri-containerd-667c285df84dc1c2f64454fd9532c06f5105a562247ebc218d3af09b94bbb501.scope"
      }
    ],
    "ips": [
      "10.25.0.58"
    ],
    "name": "clustermesh-apiserver-6787446b5f-5jvsj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7031,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3bb58c9b_6bf3_491d_9c1d_0f79556e5817.slice/cri-containerd-9e5e2d434fff5290bad16dd2d07cbc90728ab4de6ced31020eb0933358ee75d7.scope"
      }
    ],
    "ips": [
      "10.25.0.30"
    ],
    "name": "coredns-cc6ccd49c-x6rrm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7115,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9da378d6_e284_403b_a3a7_f98212602c18.slice/cri-containerd-5379ef791d483d34533af23d9867a89676dec4ced64703f6566a16acb7380ab0.scope"
      }
    ],
    "ips": [
      "10.25.0.179"
    ],
    "name": "coredns-cc6ccd49c-6498q",
    "namespace": "kube-system"
  }
]

