29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:11+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:11+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:11+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:11+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:11+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:11+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:12+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:12+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:12+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:12+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:28+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
61: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
64: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
69: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
72: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
73: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
76: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
77: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
80: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
104: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
107: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
448: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:59+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 112
449: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:59+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 70,91
	btf_id 113
450: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:59+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 114
451: sched_cls  name tail_handle_ipv4  tag b93f1e1b8cb43d12  gpl
	loaded_at 2024-10-25T10:13:59+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 69,68,75,70,91
	btf_id 115
452: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 70,69,94
	btf_id 117
454: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,94
	btf_id 119
455: sched_cls  name __send_drop_notify  tag 97b020d0cd6492df  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 120
456: sched_cls  name tail_handle_ipv4_from_host  tag 36ae01374539d602  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,94
	btf_id 121
457: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 122
459: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,96
	btf_id 125
460: sched_cls  name __send_drop_notify  tag 97b020d0cd6492df  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 126
461: sched_cls  name tail_handle_ipv4_from_host  tag 36ae01374539d602  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,96
	btf_id 127
462: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 128
467: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,97
	btf_id 134
468: sched_cls  name __send_drop_notify  tag 97b020d0cd6492df  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 135
469: sched_cls  name tail_handle_ipv4_from_host  tag 36ae01374539d602  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,97
	btf_id 136
471: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:00+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 70,97,69
	btf_id 138
474: sched_cls  name tail_handle_ipv4  tag a6462bebfabcfec9  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,103
	btf_id 143
475: sched_cls  name tail_ipv4_ct_egress  tag 002aa849d39a159d  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,103,76,77,102,78
	btf_id 145
476: sched_cls  name tail_handle_ipv4_cont  tag 21dd6f93cd5614ee  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,102,35,99,76,77,33,70,68,71,103,34,31,32,75
	btf_id 146
479: sched_cls  name tail_handle_arp  tag 4398bfc5e3bc2c96  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,103
	btf_id 149
482: sched_cls  name tail_ipv4_ct_ingress  tag 00958a7b051cfbb4  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,103,76,77,102,78
	btf_id 150
485: sched_cls  name tail_ipv4_to_endpoint  tag 0bc92dd88ddab206  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,102,35,76,77,74,99,33,103,34,31,32
	btf_id 153
486: sched_cls  name cil_from_container  tag d735ba899d5c39bf  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 103,70
	btf_id 156
487: sched_cls  name __send_drop_notify  tag 3aa48067ce8619e8  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 157
488: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,103
	btf_id 158
494: sched_cls  name handle_policy  tag a9771fd61eafc94f  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,103,76,77,102,35,74,99,33,78,69,34,31,32
	btf_id 159
495: sched_cls  name tail_handle_arp  tag 77a3e6e6820919c7  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,107
	btf_id 166
497: sched_cls  name tail_handle_arp  tag 77616bc363f4ed98  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,105
	btf_id 169
498: sched_cls  name tail_ipv4_ct_ingress  tag bdf51f284de6bedf  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 70,107,76,77,108,78
	btf_id 167
499: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,107
	btf_id 171
500: sched_cls  name tail_ipv4_to_endpoint  tag 0bf8b7e22d8577ac  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,106,35,76,77,74,104,33,105,34,31,32
	btf_id 170
501: sched_cls  name tail_ipv4_to_endpoint  tag 95c540552ab071dc  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 69,70,108,35,76,77,74,92,33,107,34,31,32
	btf_id 172
502: sched_cls  name tail_handle_ipv4_cont  tag 325f9fad0a1c5504  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,106,35,104,76,77,33,70,68,71,105,34,31,32,75
	btf_id 173
503: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 70,107,76,77,108,78
	btf_id 174
505: sched_cls  name tail_handle_ipv4_cont  tag 13c0cd3629c4cb37  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 69,108,35,92,76,77,33,70,68,71,107,34,31,32,75
	btf_id 177
506: sched_cls  name tail_handle_ipv4  tag 4bd8b4f57c1b6136  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,105
	btf_id 175
507: sched_cls  name tail_ipv4_ct_egress  tag 002aa849d39a159d  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,105,76,77,106,78
	btf_id 179
508: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,105
	btf_id 180
509: sched_cls  name cil_from_container  tag e35fe199016a4ef8  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 105,70
	btf_id 181
510: sched_cls  name __send_drop_notify  tag 0bd43a5a3c3b241e  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 182
511: sched_cls  name tail_ipv4_ct_ingress  tag 715323469a7a280f  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,105,76,77,106,78
	btf_id 183
512: sched_cls  name tail_handle_ipv4  tag 8b1a19826b70792d  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,107
	btf_id 178
513: sched_cls  name __send_drop_notify  tag 536f4469eab04ab0  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 185
514: sched_cls  name handle_policy  tag c0e4442b7f53bb89  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,105,76,77,106,35,74,104,33,78,69,34,31,32
	btf_id 184
515: sched_cls  name handle_policy  tag 009033c74778996e  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 70,107,76,77,108,35,74,92,33,78,69,34,31,32
	btf_id 186
516: sched_cls  name cil_from_container  tag 4b114893a5777c77  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 107,70
	btf_id 187
517: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
520: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
521: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
524: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
525: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
528: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
529: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
532: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
572: sched_cls  name tail_ipv4_ct_egress  tag 9d0a13297f4e22dd  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,125,76,77,124,78
	btf_id 203
573: sched_cls  name tail_ipv4_to_endpoint  tag 3a8fd3e2facfaa4d  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,124,35,76,77,74,123,33,125,34,31,32
	btf_id 204
574: sched_cls  name __send_drop_notify  tag fb74045d5f4ec2b1  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 205
575: sched_cls  name tail_handle_arp  tag f40b61b19812a628  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,125
	btf_id 206
576: sched_cls  name tail_ipv4_ct_ingress  tag 5fecd754859aaa59  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,125,76,77,124,78
	btf_id 207
577: sched_cls  name tail_handle_ipv4  tag 566f8770f9325e20  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,125
	btf_id 208
578: sched_cls  name cil_from_container  tag a4bbafb886945510  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 125,70
	btf_id 209
579: sched_cls  name tail_handle_ipv4_cont  tag 1bffeb818a14d6c9  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,124,35,123,76,77,33,70,68,71,125,34,31,32,75
	btf_id 210
581: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,125
	btf_id 212
582: sched_cls  name handle_policy  tag 217e5215d6b0242b  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,125,76,77,124,35,74,123,33,78,69,34,31,32
	btf_id 213
583: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
586: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
599: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
602: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
603: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
606: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
607: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
610: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
