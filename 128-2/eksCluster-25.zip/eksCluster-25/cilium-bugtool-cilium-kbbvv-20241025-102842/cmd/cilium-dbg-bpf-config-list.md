KEY             VALUE
AgentLiveness   965534799221
UTimeOffset     3378615601562500
