REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     210350    99401880   1132   bpf_host.c
Interface                 INGRESS     9417      735599     677    bpf_overlay.c
Success                   EGRESS      4556      348073     1694   bpf_host.c
Success                   EGRESS      87082     11945501   1308   bpf_lxc.c
Success                   EGRESS      9213      722088     53     encap.h
Success                   INGRESS     103727    12352588   235    trace.h
Success                   INGRESS     98217     11921156   86     l3.h
Unsupported L3 protocol   EGRESS      45        3398       1492   bpf_lxc.c
