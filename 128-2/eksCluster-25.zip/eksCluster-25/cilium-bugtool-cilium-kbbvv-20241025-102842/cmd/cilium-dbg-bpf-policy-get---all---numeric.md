Endpoint ID: 659
Path: /sys/fs/bpf/tc/globals/cilium_policy_00659

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    85540   981       0        
Allow    Egress      0          ANY          NONE         disabled    14482   153       0        


Endpoint ID: 681
Path: /sys/fs/bpf/tc/globals/cilium_policy_00681

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3887810   35795     0        
Allow    Ingress     1          ANY          NONE         disabled    2759935   27542     0        
Allow    Egress      0          ANY          NONE         disabled    3705752   34519     0        


Endpoint ID: 1457
Path: /sys/fs/bpf/tc/globals/cilium_policy_01457

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    434511   5549      0        
Allow    Ingress     1          ANY          NONE         disabled    12330    142       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1826
Path: /sys/fs/bpf/tc/globals/cilium_policy_01826

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2854
Path: /sys/fs/bpf/tc/globals/cilium_policy_02854

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    85561   984       0        
Allow    Egress      0          ANY          NONE         disabled    15282   162       0        


