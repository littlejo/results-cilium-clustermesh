key: 93 02 00 00  value: 02 02 00 00
key: a9 02 00 00  value: 46 02 00 00
key: b1 05 00 00  value: 03 02 00 00
key: 26 0b 00 00  value: ee 01 00 00
Found 4 elements
