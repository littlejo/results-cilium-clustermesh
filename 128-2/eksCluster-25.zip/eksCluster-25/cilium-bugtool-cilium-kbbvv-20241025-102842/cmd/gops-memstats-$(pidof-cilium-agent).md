alloc: 110.35MB (115714400 bytes)
total-alloc: 1.31GB (1404148408 bytes)
sys: 198.44MB (208083268 bytes)
lookups: 0
mallocs: 47492600
frees: 46265665
heap-alloc: 110.35MB (115714400 bytes)
heap-sys: 153.04MB (160473088 bytes)
heap-idle: 23.99MB (25157632 bytes)
heap-in-use: 129.05MB (135315456 bytes)
heap-released: 1.00MB (1048576 bytes)
heap-objects: 1226935
stack-in-use: 34.94MB (36634624 bytes)
stack-sys: 34.94MB (36634624 bytes)
stack-mspan-inuse: 2.17MB (2271840 bytes)
stack-mspan-sys: 2.47MB (2594880 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 943.38KB (966017 bytes)
gc-sys: 5.16MB (5411864 bytes)
next-gc: when heap-alloc >= 146.07MB (153165112 bytes)
last-gc: 2024-10-25 10:28:45.277709379 +0000 UTC
gc-pause-total: 5.607002ms
gc-pause: 80246
gc-pause-end: 1729852125277709379
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00026784421908548775
enable-gc: true
debug-gc: false
