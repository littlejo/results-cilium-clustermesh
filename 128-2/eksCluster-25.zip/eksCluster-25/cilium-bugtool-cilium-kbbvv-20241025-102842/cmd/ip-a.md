1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:c0:55:71:64:eb brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.217.133/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2676sec preferred_lft 2676sec
    inet6 fe80::8c0:55ff:fe71:64eb/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:6c:c7:89:99:2b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::706c:c7ff:fe89:992b/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:31:25:06:ce:e1 brd ff:ff:ff:ff:ff:ff
    inet 10.25.0.193/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d031:25ff:fe06:cee1/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 66:58:8e:a2:36:ec brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6458:8eff:fea2:36ec/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:93:d0:c8:dd:4e brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::5093:d0ff:fec8:dd4e/64 scope link 
       valid_lft forever preferred_lft forever
9: lxcfbc8ef1fa150@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:ec:f1:b5:6b:20 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::d8ec:f1ff:feb5:6b20/64 scope link 
       valid_lft forever preferred_lft forever
11: lxcd7c013290867@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:2c:5e:12:a4:8f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::e42c:5eff:fe12:a48f/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc3a4a24bc8560@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:21:f1:e7:ee:28 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::9c21:f1ff:fee7:ee28/64 scope link 
       valid_lft forever preferred_lft forever
