{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:56.975Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.217.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:56.975Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:01.599Z",
  "value": "id=1457  sec_id=4     flags=0x0000 ifindex=7   mac=36:31:CB:EB:FA:B1 nodemac=52:93:D0:C8:DD:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:01.601Z",
  "value": "id=2854  sec_id=1705444 flags=0x0000 ifindex=9   mac=AE:0C:FE:ED:01:62 nodemac=DA:EC:F1:B5:6B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:01.660Z",
  "value": "id=659   sec_id=1705444 flags=0x0000 ifindex=11  mac=12:2A:A9:57:E0:8E nodemac=E6:2C:5E:12:A4:8F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:01.661Z",
  "value": "id=1457  sec_id=4     flags=0x0000 ifindex=7   mac=36:31:CB:EB:FA:B1 nodemac=52:93:D0:C8:DD:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:01.663Z",
  "value": "id=2854  sec_id=1705444 flags=0x0000 ifindex=9   mac=AE:0C:FE:ED:01:62 nodemac=DA:EC:F1:B5:6B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:01.783Z",
  "value": "id=1457  sec_id=4     flags=0x0000 ifindex=7   mac=36:31:CB:EB:FA:B1 nodemac=52:93:D0:C8:DD:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:01.784Z",
  "value": "id=2854  sec_id=1705444 flags=0x0000 ifindex=9   mac=AE:0C:FE:ED:01:62 nodemac=DA:EC:F1:B5:6B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:01.784Z",
  "value": "id=659   sec_id=1705444 flags=0x0000 ifindex=11  mac=12:2A:A9:57:E0:8E nodemac=E6:2C:5E:12:A4:8F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:28.802Z",
  "value": "id=659   sec_id=1705444 flags=0x0000 ifindex=11  mac=12:2A:A9:57:E0:8E nodemac=E6:2C:5E:12:A4:8F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:28.802Z",
  "value": "id=1457  sec_id=4     flags=0x0000 ifindex=7   mac=36:31:CB:EB:FA:B1 nodemac=52:93:D0:C8:DD:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:28.803Z",
  "value": "id=2854  sec_id=1705444 flags=0x0000 ifindex=9   mac=AE:0C:FE:ED:01:62 nodemac=DA:EC:F1:B5:6B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:28.832Z",
  "value": "id=821   sec_id=1751173 flags=0x0000 ifindex=13  mac=EE:DB:8A:5B:8F:AB nodemac=E6:DA:DF:AF:8A:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:29.802Z",
  "value": "id=1457  sec_id=4     flags=0x0000 ifindex=7   mac=36:31:CB:EB:FA:B1 nodemac=52:93:D0:C8:DD:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:29.802Z",
  "value": "id=659   sec_id=1705444 flags=0x0000 ifindex=11  mac=12:2A:A9:57:E0:8E nodemac=E6:2C:5E:12:A4:8F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:29.802Z",
  "value": "id=821   sec_id=1751173 flags=0x0000 ifindex=13  mac=EE:DB:8A:5B:8F:AB nodemac=E6:DA:DF:AF:8A:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:29.802Z",
  "value": "id=2854  sec_id=1705444 flags=0x0000 ifindex=9   mac=AE:0C:FE:ED:01:62 nodemac=DA:EC:F1:B5:6B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:02.557Z",
  "value": "id=681   sec_id=1751173 flags=0x0000 ifindex=15  mac=0E:B1:24:EF:58:11 nodemac=9E:21:F1:E7:EE:28"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.25.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:07.945Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:38.890Z",
  "value": "id=1457  sec_id=4     flags=0x0000 ifindex=7   mac=36:31:CB:EB:FA:B1 nodemac=52:93:D0:C8:DD:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:38.891Z",
  "value": "id=2854  sec_id=1705444 flags=0x0000 ifindex=9   mac=AE:0C:FE:ED:01:62 nodemac=DA:EC:F1:B5:6B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:38.892Z",
  "value": "id=659   sec_id=1705444 flags=0x0000 ifindex=11  mac=12:2A:A9:57:E0:8E nodemac=E6:2C:5E:12:A4:8F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:38.892Z",
  "value": "id=681   sec_id=1751173 flags=0x0000 ifindex=15  mac=0E:B1:24:EF:58:11 nodemac=9E:21:F1:E7:EE:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:39.890Z",
  "value": "id=1457  sec_id=4     flags=0x0000 ifindex=7   mac=36:31:CB:EB:FA:B1 nodemac=52:93:D0:C8:DD:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:39.890Z",
  "value": "id=681   sec_id=1751173 flags=0x0000 ifindex=15  mac=0E:B1:24:EF:58:11 nodemac=9E:21:F1:E7:EE:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:39.890Z",
  "value": "id=2854  sec_id=1705444 flags=0x0000 ifindex=9   mac=AE:0C:FE:ED:01:62 nodemac=DA:EC:F1:B5:6B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:39.890Z",
  "value": "id=659   sec_id=1705444 flags=0x0000 ifindex=11  mac=12:2A:A9:57:E0:8E nodemac=E6:2C:5E:12:A4:8F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:40.891Z",
  "value": "id=2854  sec_id=1705444 flags=0x0000 ifindex=9   mac=AE:0C:FE:ED:01:62 nodemac=DA:EC:F1:B5:6B:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:40.891Z",
  "value": "id=681   sec_id=1751173 flags=0x0000 ifindex=15  mac=0E:B1:24:EF:58:11 nodemac=9E:21:F1:E7:EE:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:40.891Z",
  "value": "id=659   sec_id=1705444 flags=0x0000 ifindex=11  mac=12:2A:A9:57:E0:8E nodemac=E6:2C:5E:12:A4:8F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.25.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:40.891Z",
  "value": "id=1457  sec_id=4     flags=0x0000 ifindex=7   mac=36:31:CB:EB:FA:B1 nodemac=52:93:D0:C8:DD:4E"
}

