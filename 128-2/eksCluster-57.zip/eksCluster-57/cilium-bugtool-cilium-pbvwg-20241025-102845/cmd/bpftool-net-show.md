xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 557
ens6(5) clsact/ingress cil_from_netdev-ens6 id 568
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 548
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 539
cilium_host(7) clsact/egress cil_from_host-cilium_host id 544
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 482
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 571
lxc2b68d1390598(12) clsact/ingress cil_from_container-lxc2b68d1390598 id 522
lxcc50d46ba305b(14) clsact/ingress cil_from_container-lxcc50d46ba305b id 570
lxcc28d7b0c502d(18) clsact/ingress cil_from_container-lxcc28d7b0c502d id 642

flow_dissector:

netfilter:

