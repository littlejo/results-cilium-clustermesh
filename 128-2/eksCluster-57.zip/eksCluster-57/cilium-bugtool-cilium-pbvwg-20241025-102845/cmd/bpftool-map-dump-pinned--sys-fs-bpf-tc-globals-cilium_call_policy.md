key: a5 02 00 00  value: 88 02 00 00
key: 8f 04 00 00  value: 42 02 00 00
key: 90 08 00 00  value: 0f 02 00 00
key: 66 0a 00 00  value: 43 02 00 00
Found 4 elements
