{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:47.895Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.231.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:47.895Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.250.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:47.895Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:52.233Z",
  "value": "id=2192  sec_id=3820400 flags=0x0000 ifindex=12  mac=0A:E4:AA:50:C8:BD nodemac=DA:D8:BE:40:D4:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:52.252Z",
  "value": "id=2662  sec_id=4     flags=0x0000 ifindex=10  mac=82:B4:00:13:7D:F6 nodemac=7A:19:A8:6B:28:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:52.296Z",
  "value": "id=1167  sec_id=3820400 flags=0x0000 ifindex=14  mac=7A:0D:DA:04:AA:93 nodemac=3E:28:D7:E6:B5:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:52.312Z",
  "value": "id=2662  sec_id=4     flags=0x0000 ifindex=10  mac=82:B4:00:13:7D:F6 nodemac=7A:19:A8:6B:28:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:01.544Z",
  "value": "id=2662  sec_id=4     flags=0x0000 ifindex=10  mac=82:B4:00:13:7D:F6 nodemac=7A:19:A8:6B:28:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:01.545Z",
  "value": "id=2192  sec_id=3820400 flags=0x0000 ifindex=12  mac=0A:E4:AA:50:C8:BD nodemac=DA:D8:BE:40:D4:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:01.545Z",
  "value": "id=1167  sec_id=3820400 flags=0x0000 ifindex=14  mac=7A:0D:DA:04:AA:93 nodemac=3E:28:D7:E6:B5:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:01.573Z",
  "value": "id=448   sec_id=3836637 flags=0x0000 ifindex=16  mac=4E:4D:F6:E2:A5:34 nodemac=4A:1A:7F:48:8C:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.544Z",
  "value": "id=2192  sec_id=3820400 flags=0x0000 ifindex=12  mac=0A:E4:AA:50:C8:BD nodemac=DA:D8:BE:40:D4:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.544Z",
  "value": "id=1167  sec_id=3820400 flags=0x0000 ifindex=14  mac=7A:0D:DA:04:AA:93 nodemac=3E:28:D7:E6:B5:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.544Z",
  "value": "id=2662  sec_id=4     flags=0x0000 ifindex=10  mac=82:B4:00:13:7D:F6 nodemac=7A:19:A8:6B:28:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:02.544Z",
  "value": "id=448   sec_id=3836637 flags=0x0000 ifindex=16  mac=4E:4D:F6:E2:A5:34 nodemac=4A:1A:7F:48:8C:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:59.173Z",
  "value": "id=677   sec_id=3836637 flags=0x0000 ifindex=18  mac=DE:98:B7:0D:C4:AD nodemac=46:9E:44:58:65:F5"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.57.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:04.336Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:09.736Z",
  "value": "id=1167  sec_id=3820400 flags=0x0000 ifindex=14  mac=7A:0D:DA:04:AA:93 nodemac=3E:28:D7:E6:B5:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:09.737Z",
  "value": "id=677   sec_id=3836637 flags=0x0000 ifindex=18  mac=DE:98:B7:0D:C4:AD nodemac=46:9E:44:58:65:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:09.737Z",
  "value": "id=2662  sec_id=4     flags=0x0000 ifindex=10  mac=82:B4:00:13:7D:F6 nodemac=7A:19:A8:6B:28:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:09.738Z",
  "value": "id=2192  sec_id=3820400 flags=0x0000 ifindex=12  mac=0A:E4:AA:50:C8:BD nodemac=DA:D8:BE:40:D4:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:10.736Z",
  "value": "id=2192  sec_id=3820400 flags=0x0000 ifindex=12  mac=0A:E4:AA:50:C8:BD nodemac=DA:D8:BE:40:D4:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:10.736Z",
  "value": "id=677   sec_id=3836637 flags=0x0000 ifindex=18  mac=DE:98:B7:0D:C4:AD nodemac=46:9E:44:58:65:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:10.737Z",
  "value": "id=1167  sec_id=3820400 flags=0x0000 ifindex=14  mac=7A:0D:DA:04:AA:93 nodemac=3E:28:D7:E6:B5:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:10.737Z",
  "value": "id=2662  sec_id=4     flags=0x0000 ifindex=10  mac=82:B4:00:13:7D:F6 nodemac=7A:19:A8:6B:28:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:11.737Z",
  "value": "id=1167  sec_id=3820400 flags=0x0000 ifindex=14  mac=7A:0D:DA:04:AA:93 nodemac=3E:28:D7:E6:B5:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:11.738Z",
  "value": "id=677   sec_id=3836637 flags=0x0000 ifindex=18  mac=DE:98:B7:0D:C4:AD nodemac=46:9E:44:58:65:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:11.738Z",
  "value": "id=2662  sec_id=4     flags=0x0000 ifindex=10  mac=82:B4:00:13:7D:F6 nodemac=7A:19:A8:6B:28:AB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.57.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:11.738Z",
  "value": "id=2192  sec_id=3820400 flags=0x0000 ifindex=12  mac=0A:E4:AA:50:C8:BD nodemac=DA:D8:BE:40:D4:C1"
}

