1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:66:c2:90:3f:07 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.231.209/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2798sec preferred_lft 2798sec
    inet6 fe80::866:c2ff:fe90:3f07/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:3a:e5:fa:b5:87 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.250.221/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::83a:e5ff:fefa:b587/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:29:b2:53:a2:3e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2429:b2ff:fe53:a23e/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:ac:0f:a6:19:30 brd ff:ff:ff:ff:ff:ff
    inet 10.57.0.76/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::34ac:fff:fea6:1930/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 62:69:2c:46:8a:4f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6069:2cff:fe46:8a4f/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:19:a8:6b:28:ab brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::7819:a8ff:fe6b:28ab/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc2b68d1390598@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:d8:be:40:d4:c1 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d8d8:beff:fe40:d4c1/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcc50d46ba305b@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:28:d7:e6:b5:b4 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::3c28:d7ff:fee6:b5b4/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcc28d7b0c502d@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:9e:44:58:65:f5 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::449e:44ff:fe58:65f5/64 scope link 
       valid_lft forever preferred_lft forever
