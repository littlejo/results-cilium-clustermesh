ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.138.228:443 (active)    
                                          2 => 172.31.231.155:443 (active)    
2    10.100.4.50:443       ClusterIP      1 => 172.31.231.209:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.57.0.217:53 (active)        
                                          2 => 10.57.0.227:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.57.0.217:9153 (active)      
                                          2 => 10.57.0.227:9153 (active)      
5    10.100.121.153:2379   ClusterIP      1 => 10.57.0.232:2379 (active)      
