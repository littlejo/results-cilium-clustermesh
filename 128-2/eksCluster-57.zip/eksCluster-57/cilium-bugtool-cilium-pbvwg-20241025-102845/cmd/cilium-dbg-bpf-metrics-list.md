REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10057     788231     677    bpf_overlay.c
Interface                 INGRESS     221552    85142199   1132   bpf_host.c
Success                   EGRESS      10260     803528     53     encap.h
Success                   EGRESS      5147      396961     1694   bpf_host.c
Success                   EGRESS      93483     12412462   1308   bpf_lxc.c
Success                   INGRESS     105603    12894780   86     l3.h
Success                   INGRESS     111162    13329956   235    trace.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
