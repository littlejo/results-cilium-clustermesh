Node 0, zone      DMA      1      1     15     48     25     10      4      1      1      3    165 
Node 0, zone   Normal    536     57     12     22     12      8      5      1      5      3      6 
