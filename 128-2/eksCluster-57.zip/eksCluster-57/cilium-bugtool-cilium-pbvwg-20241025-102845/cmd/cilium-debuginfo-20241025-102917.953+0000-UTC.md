# Cilium debug information

#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.57.0.30": (string) (len=6) "health",
  (string) (len=11) "10.57.0.227": (string) (len=35) "kube-system/coredns-cc6ccd49c-g2922",
  (string) (len=11) "10.57.0.217": (string) (len=35) "kube-system/coredns-cc6ccd49c-jrgft",
  (string) (len=11) "10.57.0.232": (string) (len=49) "kube-system/clustermesh-apiserver-5b5dbbfb8-2bz5d",
  (string) (len=10) "10.57.0.76": (string) (len=6) "router"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.231.209": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40017048f0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001b3ac00,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001b3ac00,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4001d11340)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4001d113f0)(frontends:[10.100.4.50]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4001d11550)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4001d45760)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40023600b0)(frontends:[10.100.121.153]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x40012752a8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40015156c0)(172.31.138.228:443/TCP,172.31.231.155:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x40012752b0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-7ggxv": (*k8s.Endpoints)(0x40019d3040)(172.31.231.209:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x40012752b8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-f4gw4": (*k8s.Endpoints)(0x40031bd1e0)(10.57.0.217:53/TCP[eu-west-3b],10.57.0.217:53/UDP[eu-west-3b],10.57.0.217:9153/TCP[eu-west-3b],10.57.0.227:53/TCP[eu-west-3b],10.57.0.227:53/UDP[eu-west-3b],10.57.0.227:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001446a88)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-lhxgc": (*k8s.Endpoints)(0x40019d3c70)(10.57.0.232:2379/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4002371180)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4000598d20)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4008581c50
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4001b3d6e0,
  gcExited: (chan struct {}) 0x4001b3d740,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x40016e1a00)({
     ObserverVec: (*prometheus.HistogramVec)(0x40011f7240)({
      MetricVec: (*prometheus.MetricVec)(0x4001a27d10)({
       metricMap: (*prometheus.metricMap)(0x4001a27d40)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017c4480)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x40016e1a80)({
     ObserverVec: (*prometheus.HistogramVec)(0x40011f7248)({
      MetricVec: (*prometheus.MetricVec)(0x4001a27da0)({
       metricMap: (*prometheus.metricMap)(0x4001a27dd0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017c44e0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x40016e1b00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40011f7250)({
      MetricVec: (*prometheus.MetricVec)(0x4001a27e30)({
       metricMap: (*prometheus.metricMap)(0x4001a27e60)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017c4540)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x40016e1b80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40011f7258)({
      MetricVec: (*prometheus.MetricVec)(0x4001a27ec0)({
       metricMap: (*prometheus.metricMap)(0x4001a27ef0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017c45a0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x40016e1c00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40011f7260)({
      MetricVec: (*prometheus.MetricVec)(0x4001a27f50)({
       metricMap: (*prometheus.metricMap)(0x4001a3e000)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017c4600)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x40016e1c80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40011f7268)({
      MetricVec: (*prometheus.MetricVec)(0x4001a3e060)({
       metricMap: (*prometheus.metricMap)(0x4001a3e090)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017c4660)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x40016e1d00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40011f7270)({
      MetricVec: (*prometheus.MetricVec)(0x4001a3e0f0)({
       metricMap: (*prometheus.metricMap)(0x4001a3e120)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017c46c0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x40016e1d80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40011f7278)({
      MetricVec: (*prometheus.MetricVec)(0x4001a3e180)({
       metricMap: (*prometheus.metricMap)(0x4001a3e1b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017c4720)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x40016e1e00)({
     ObserverVec: (*prometheus.HistogramVec)(0x40011f7280)({
      MetricVec: (*prometheus.MetricVec)(0x4001a3e210)({
       metricMap: (*prometheus.metricMap)(0x4001a3e240)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017c4780)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4002371180)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001b52380)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001a0dd10)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 385ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.57.0.0/24, 
Allocated addresses:
  10.57.0.217 (kube-system/coredns-cc6ccd49c-jrgft)
  10.57.0.227 (kube-system/coredns-cc6ccd49c-g2922)
  10.57.0.232 (kube-system/clustermesh-apiserver-5b5dbbfb8-2bz5d)
  10.57.0.30 (health)
  10.57.0.76 (router)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 238dee843fda0c2b
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                               Last success   Last error   Count   Message
  cilium-health-ep                                                   28s ago        never        0       no error   
  ct-map-pressure                                                    29s ago        never        0       no error   
  daemon-validate-config                                             17s ago        never        0       no error   
  dns-garbage-collector-job                                          32s ago        never        0       no error   
  endpoint-1167-regeneration-recovery                                never          never        0       no error   
  endpoint-1615-regeneration-recovery                                never          never        0       no error   
  endpoint-2192-regeneration-recovery                                never          never        0       no error   
  endpoint-2662-regeneration-recovery                                never          never        0       no error   
  endpoint-677-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                        2m32s ago      never        0       no error   
  ep-bpf-prog-watchdog                                               29s ago        never        0       no error   
  ipcache-inject-labels                                              30s ago        never        0       no error   
  k8s-heartbeat                                                      32s ago        never        0       no error   
  link-cache                                                         14s ago        never        0       no error   
  local-identity-checkpoint                                          12m29s ago     never        0       no error   
  node-neighbor-link-updater                                         9s ago         never        0       no error   
  remote-etcd-cmesh1                                                 7m8s ago       never        0       no error   
  remote-etcd-cmesh10                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh100                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh101                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh102                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh103                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh104                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh105                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh106                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh107                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh108                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh109                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh11                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh110                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh111                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh112                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh113                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh114                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh115                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh116                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh117                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh118                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh119                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh12                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh120                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh121                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh122                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh123                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh124                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh125                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh126                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh127                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh128                                               7m8s ago       never        0       no error   
  remote-etcd-cmesh13                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh14                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh15                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh16                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh17                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh18                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh19                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh2                                                 7m8s ago       never        0       no error   
  remote-etcd-cmesh20                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh21                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh22                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh23                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh24                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh25                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh26                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh27                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh28                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh29                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh3                                                 7m8s ago       never        0       no error   
  remote-etcd-cmesh30                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh31                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh32                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh33                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh34                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh35                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh36                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh37                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh38                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh39                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh4                                                 7m8s ago       never        0       no error   
  remote-etcd-cmesh40                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh41                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh42                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh43                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh44                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh45                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh46                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh47                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh48                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh49                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh5                                                 7m8s ago       never        0       no error   
  remote-etcd-cmesh50                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh51                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh52                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh53                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh54                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh55                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh56                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh57                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh59                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh6                                                 7m8s ago       never        0       no error   
  remote-etcd-cmesh60                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh61                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh62                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh63                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh64                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh65                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh66                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh67                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh68                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh69                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh7                                                 7m8s ago       never        0       no error   
  remote-etcd-cmesh70                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh71                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh72                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh73                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh74                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh75                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh76                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh77                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh78                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh79                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh8                                                 7m8s ago       never        0       no error   
  remote-etcd-cmesh80                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh81                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh82                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh83                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh84                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh85                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh86                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh87                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh88                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh89                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh9                                                 7m8s ago       never        0       no error   
  remote-etcd-cmesh90                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh91                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh92                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh93                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh94                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh95                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh96                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh97                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh98                                                7m8s ago       never        0       no error   
  remote-etcd-cmesh99                                                7m8s ago       never        0       no error   
  resolve-identity-1167                                              2m28s ago      never        0       no error   
  resolve-identity-1615                                              2m29s ago      never        0       no error   
  resolve-identity-2192                                              2m28s ago      never        0       no error   
  resolve-identity-2662                                              2m28s ago      never        0       no error   
  resolve-identity-677                                               2m18s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-5b5dbbfb8-2bz5d   7m18s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-g2922                 12m28s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-jrgft                 12m28s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                     12m29s ago     never        0       no error   
  sync-policymap-1167                                                12m25s ago     never        0       no error   
  sync-policymap-1615                                                12m28s ago     never        0       no error   
  sync-policymap-2192                                                12m25s ago     never        0       no error   
  sync-policymap-2662                                                12m25s ago     never        0       no error   
  sync-policymap-677                                                 7m18s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (1167)                                  8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2192)                                  8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (677)                                   8s ago         never        0       no error   
  sync-utime                                                         30s ago        never        0       no error   
  write-cni-file                                                     12m32s ago     never        0       no error   
Proxy Status:            OK, ip 10.57.0.76, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 3801088, max 3866623
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 86.41   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
monitor-queue-size:0
enable-custom-calls:false
proxy-gid:1337
container-ip-local-reserved-ports:auto
enable-bpf-masquerade:false
cni-external-routing:false
datapath-mode:veth
proxy-prometheus-port:0
policy-cidr-match-mode:
monitor-aggregation-interval:5s
identity-change-grace-period:5s
ipv6-cluster-alloc-cidr:f00d::/64
mesh-auth-spiffe-trust-domain:spiffe.cilium
enable-identity-mark:true
enable-ipsec:false
k8s-service-proxy-name:
disable-envoy-version-check:false
hubble-skip-unknown-cgroup-ids:true
mke-cgroup-mount:
hubble-redact-http-headers-allow:
enable-endpoint-health-checking:true
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
bpf-fragments-map-max:8192
local-router-ipv4:
tofqdns-pre-cache:
ipam:cluster-pool
proxy-portrange-min:10000
local-router-ipv6:
k8s-sync-timeout:3m0s
enable-tcx:true
mesh-auth-signal-backoff-duration:1s
monitor-aggregation:medium
hubble-redact-http-headers-deny:
enable-xdp-prefilter:false
envoy-log:
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
devices:
tunnel-protocol:vxlan
mesh-auth-mutual-listener-port:0
ip-masq-agent-config-path:/etc/config/ip-masq-agent
enable-ipv4:true
enable-node-port:false
tofqdns-enable-dns-compression:true
debug-verbose:
http-retry-count:3
node-port-range:
use-full-tls-context:false
ipv4-range:auto
hubble-metrics:
ipsec-key-rotation-duration:5m0s
set-cilium-is-up-condition:true
envoy-keep-cap-netbindservice:false
ipv4-native-routing-cidr:
dnsproxy-lock-timeout:500ms
config:
l2-announcements-lease-duration:15s
bpf-lb-mode:snat
k8s-require-ipv4-pod-cidr:false
enable-k8s:true
bpf-lb-sock:false
bpf-lb-algorithm:random
bpf-lb-sock-hostns-only:false
allocator-list-timeout:3m0s
clustermesh-enable-endpoint-sync:false
policy-queue-size:100
proxy-xff-num-trusted-hops-egress:0
egress-masquerade-interfaces:ens+
policy-accounting:true
k8s-kubeconfig-path:
agent-liveness-update-interval:1s
http-max-grpc-timeout:0
enable-ipv4-masquerade:true
enable-ipsec-encrypted-overlay:false
hubble-drop-events:false
disable-endpoint-crd:false
hubble-export-file-compress:false
trace-sock:true
hubble-listen-address::4244
version:false
identity-allocation-mode:crd
endpoint-gc-interval:5m0s
bpf-events-drop-enabled:true
bpf-ct-timeout-regular-any:1m0s
api-rate-limit:
cni-log-file:/var/run/cilium/cilium-cni.log
enable-host-port:false
bpf-ct-timeout-regular-tcp-fin:10s
conntrack-gc-interval:0s
tofqdns-proxy-port:0
k8s-heartbeat-timeout:30s
preallocate-bpf-maps:false
bpf-auth-map-max:524288
hubble-export-file-max-size-mb:10
hubble-redact-enabled:false
operator-api-serve-addr:127.0.0.1:9234
http-request-timeout:3600
disable-iptables-feeder-rules:
monitor-aggregation-flags:all
vlan-bpf-bypass:
bypass-ip-availability-upon-restore:false
clustermesh-sync-timeout:1m0s
dnsproxy-enable-transparent-mode:true
bpf-lb-rev-nat-map-max:0
envoy-secrets-namespace:
enable-ingress-controller:false
enable-service-topology:false
agent-health-port:9879
hubble-monitor-events:
enable-nat46x64-gateway:false
dnsproxy-concurrency-limit:0
cni-chaining-target:
bpf-ct-global-any-max:262144
dnsproxy-socket-linger-timeout:10
bpf-lb-rss-ipv6-src-cidr:
http-normalize-path:true
read-cni-conf:
enable-health-check-nodeport:true
annotate-k8s-node:false
enable-bpf-tproxy:false
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
log-driver:
tofqdns-min-ttl:0
hubble-recorder-sink-queue-size:1024
l2-announcements-renew-deadline:5s
node-port-mode:snat
enable-active-connection-tracking:false
ipv6-native-routing-cidr:
bpf-map-dynamic-size-ratio:0.0025
pprof-port:6060
node-port-bind-protection:true
encrypt-node:false
bpf-filter-priority:1
local-max-addr-scope:252
hubble-prefer-ipv6:false
mesh-auth-queue-size:1024
ipv6-pod-subnets:
route-metric:0
enable-local-redirect-policy:false
enable-ipsec-key-watcher:true
wireguard-persistent-keepalive:0s
hubble-drop-events-interval:2m0s
mesh-auth-spire-admin-socket:
policy-audit-mode:false
ipv4-service-range:auto
kvstore-connectivity-timeout:2m0s
vtep-endpoint:
mesh-auth-rotated-identities-queue-size:1024
bpf-ct-timeout-service-tcp-grace:1m0s
bpf-ct-timeout-service-any:1m0s
http-idle-timeout:0
enable-external-ips:false
cluster-id:58
kvstore-max-consecutive-quorum-errors:2
enable-bandwidth-manager:false
enable-endpoint-routes:false
enable-l2-announcements:false
bpf-policy-map-max:16384
socket-path:/var/run/cilium/cilium.sock
hubble-flowlogs-config-path:
clustermesh-enable-mcs-api:false
ipv6-node:auto
hubble-recorder-storage-path:/var/run/cilium/pcaps
hubble-event-queue-size:0
bpf-lb-map-max:65536
kvstore-opt:
node-port-algorithm:random
enable-ipv6-masquerade:true
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
bpf-lb-affinity-map-max:0
hubble-redact-http-urlquery:false
identity-restore-grace-period:30s
enable-hubble-recorder-api:true
multicast-enabled:false
proxy-max-connection-duration-seconds:0
enable-l2-pod-announcements:false
use-cilium-internal-ip-for-ipsec:false
dnsproxy-lock-count:131
hubble-export-denylist:
custom-cni-conf:false
k8s-namespace:kube-system
identity-heartbeat-timeout:30m0s
bpf-lb-source-range-map-max:0
dnsproxy-concurrency-processing-grace-period:0s
enable-k8s-terminating-endpoint:true
metrics:
cluster-name:cmesh58
bpf-lb-dsr-l4-xlate:frontend
bgp-announce-pod-cidr:false
certificates-directory:/var/run/cilium/certs
enable-runtime-device-detection:true
dnsproxy-insecure-skip-transparent-mode-check:false
enable-k8s-api-discovery:false
enable-unreachable-routes:false
enable-policy:default
hubble-export-file-max-backups:5
node-port-acceleration:disabled
bpf-policy-map-full-reconciliation-interval:15m0s
config-dir:/tmp/cilium/config-map
ingress-secrets-namespace:
operator-prometheus-serve-addr::9963
egress-multi-home-ip-rule-compat:false
bpf-lb-maglev-map-max:0
tofqdns-endpoint-max-ip-per-hostname:50
endpoint-queue-size:25
enable-icmp-rules:true
kvstore:
hubble-redact-http-userinfo:true
gops-port:9890
bpf-ct-timeout-regular-tcp:2h13m20s
fqdn-regex-compile-lru-size:1024
mesh-auth-mutual-connect-timeout:5s
enable-bgp-control-plane:false
proxy-xff-num-trusted-hops-ingress:0
l2-announcements-retry-period:2s
remove-cilium-node-taints:true
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
enable-pmtu-discovery:false
max-connected-clusters:255
iptables-random-fully:false
crd-wait-timeout:5m0s
enable-ipv4-fragment-tracking:true
enable-host-legacy-routing:false
enable-ip-masq-agent:false
procfs:/host/proc
install-no-conntrack-iptables-rules:false
enable-monitor:true
envoy-config-timeout:2m0s
auto-create-cilium-node-resource:true
enable-srv6:false
gateway-api-secrets-namespace:
hubble-disable-tls:false
bpf-neigh-global-max:524288
clustermesh-ip-identities-sync-timeout:1m0s
egress-gateway-reconciliation-trigger-interval:1s
enable-ipv6-ndp:false
prepend-iptables-chains:true
restore:true
enable-sctp:false
enable-node-selector-labels:false
enable-k8s-endpoint-slice:true
enable-cilium-health-api-server-access:
derive-masq-ip-addr-from-device:
enable-session-affinity:false
kvstore-periodic-sync:5m0s
enable-host-firewall:false
k8s-client-qps:10
pprof-address:localhost
log-system-load:false
bpf-lb-dsr-dispatch:opt
enable-tracing:false
mesh-auth-enabled:true
enable-bbr:false
config-sources:config-map:kube-system/cilium-config
fixed-identity-mapping:
mtu:0
k8s-service-cache-size:128
srv6-encap-mode:reduced
envoy-base-id:0
enable-envoy-config:false
join-cluster:false
enable-health-checking:true
bpf-nat-global-max:524288
debug:false
enable-wireguard:false
arping-refresh-period:30s
external-envoy-proxy:true
enable-ipip-termination:false
node-labels:
lib-dir:/var/lib/cilium
k8s-client-burst:20
ipv6-range:auto
cluster-pool-ipv4-cidr:10.57.0.0/16
bpf-sock-rev-map-max:262144
ipv4-pod-subnets:
vtep-mac:
proxy-connect-timeout:2
enable-high-scale-ipcache:false
bpf-ct-global-tcp-max:524288
enable-mke:false
hubble-metrics-server:
bpf-ct-timeout-service-tcp:2h13m20s
enable-cilium-api-server-access:
enable-masquerade-to-route-source:false
cmdref:
http-retry-timeout:0
agent-labels:
nodeport-addresses:
labels:
tunnel-port:0
enable-l2-neigh-discovery:true
nat-map-stats-interval:30s
proxy-idle-timeout-seconds:60
encryption-strict-mode-allow-remote-node-identities:false
allow-icmp-frag-needed:true
bpf-map-event-buffers:
cflags:
bpf-lb-sock-terminate-pod-connections:false
nat-map-stats-entries:32
cluster-pool-ipv4-mask-size:24
set-cilium-node-taints:true
log-opt:
controller-group-metrics:
enable-hubble:true
force-device-detection:false
ipv6-service-range:auto
nodes-gc-interval:5m0s
bpf-lb-service-backend-map-max:0
ipv4-node:auto
bpf-events-trace-enabled:true
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
enable-cilium-endpoint-slice:false
dns-policy-unload-on-shutdown:false
endpoint-bpf-prog-watchdog-interval:30s
enable-health-check-loadbalancer-ip:false
vtep-mask:
dns-max-ips-per-restored-rule:1000
max-controller-interval:0
unmanaged-pod-watcher-interval:15
hubble-export-fieldmask:
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
enable-svc-source-range-check:true
ipv6-mcast-device:
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
pprof:false
enable-metrics:true
exclude-node-label-patterns:
enable-gateway-api:false
bpf-node-map-max:16384
iptables-lock-timeout:5s
bpf-ct-timeout-regular-tcp-syn:1m0s
mesh-auth-gc-interval:5m0s
direct-routing-device:
synchronize-k8s-nodes:true
tofqdns-proxy-response-max-delay:100ms
proxy-max-requests-per-connection:0
hubble-drop-events-reasons:auth_required,policy_denied
static-cnp-path:
enable-wireguard-userspace-fallback:false
hubble-export-file-path:
k8s-client-connection-keep-alive:30s
enable-encryption-strict-mode:false
kvstore-lease-ttl:15m0s
l2-pod-announcements-interface:
kube-proxy-replacement:false
bpf-lb-acceleration:disabled
clustermesh-config:/var/lib/cilium/clustermesh/
bpf-lb-service-map-max:0
enable-k8s-networkpolicy:true
label-prefix-file:
enable-ipv4-egress-gateway:false
ipam-multi-pool-pre-allocation:
envoy-config-retry-interval:15s
cni-chaining-mode:none
exclude-local-address:
auto-direct-node-routes:false
service-no-backend-response:reject
disable-external-ip-mitigation:false
cgroup-root:/run/cilium/cgroupv2
hubble-socket-path:/var/run/cilium/hubble.sock
proxy-admin-port:0
enable-ipsec-xfrm-state-caching:true
prometheus-serve-addr:
enable-auto-protect-node-port-range:true
bpf-events-policy-verdict-enabled:true
enable-ipv6-big-tcp:false
kube-proxy-replacement-healthz-bind-address:
ipam-default-ip-pool:default
cluster-health-port:4240
bpf-root:/sys/fs/bpf
encryption-strict-mode-cidr:
tofqdns-max-deferred-connection-deletes:10000
proxy-portrange-max:20000
bgp-announce-lb-ip:false
routing-mode:tunnel
allow-localhost:auto
cilium-endpoint-gc-interval:5m0s
enable-route-mtu-for-cni-chaining:false
hubble-export-allowlist:
direct-routing-skip-unreachable:false
encrypt-interface:
conntrack-gc-max-interval:0s
enable-xt-socket-fallback:true
k8s-client-connection-timeout:30s
enable-bpf-clock-probe:false
ipv4-service-loopback-address:169.254.42.1
enable-vtep:false
bgp-config-path:/var/lib/cilium/bgp/config.yaml
ipsec-key-file:
max-internal-timer-delay:0s
identity-gc-interval:15m0s
install-iptables-rules:true
vtep-cidr:
state-dir:/var/run/cilium
bpf-lb-rss-ipv4-src-cidr:
keep-config:false
cni-exclusive:true
bpf-lb-maglev-table-size:16381
enable-ipv6:false
enable-stale-cilium-endpoint-cleanup:true
enable-recorder:false
policy-trigger-interval:1s
enable-local-node-route:true
enable-well-known-identities:false
k8s-require-ipv6-pod-cidr:false
bpf-lb-external-clusterip:false
hubble-event-buffer-capacity:4095
tofqdns-dns-reject-response-code:refused
hubble-redact-kafka-apikey:false
trace-payloadlen:128
enable-ipv4-big-tcp:false
egress-gateway-policy-map-max:16384
k8s-api-server:
enable-l7-proxy:true
ipam-cilium-node-update-rate:15s
tofqdns-idle-connection-grace-period:0s
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
677        Disabled           Disabled          3836637    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.57.0.232   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh58                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
1167       Disabled           Disabled          3820400    k8s:eks.amazonaws.com/component=coredns                                             10.57.0.217   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh58                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
1615       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                
                                                           reserved:host                                                                                             
2192       Disabled           Disabled          3820400    k8s:eks.amazonaws.com/component=coredns                                             10.57.0.227   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh58                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
2662       Disabled           Disabled          4          reserved:health                                                                     10.57.0.30    ready   
```

#### BPF Policy Get 677

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3869176   36598     0        
Allow    Ingress     1          ANY          NONE         disabled    3347155   34101     0        
Allow    Egress      0          ANY          NONE         disabled    4709442   43498     0        

```


#### BPF CT List 677

```
Invalid argument: unknown type 677
```


#### Endpoint Get 677

```
[
  {
    "id": 677,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-677-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "9f615180-a152-485c-b405-aacb8ffd113f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-677",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:59.141Z",
            "success-count": 2
          },
          "uuid": "b8659b81-f599-44d3-a388-702b248c2ca7"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-5b5dbbfb8-2bz5d",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:59.140Z",
            "success-count": 1
          },
          "uuid": "f251d500-cad7-4fdc-801f-95393184c98c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-677",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:59.173Z",
            "success-count": 1
          },
          "uuid": "ff1ca072-47c4-410e-8e16-14575b14955f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (677)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:09.192Z",
            "success-count": 45
          },
          "uuid": "bfabbcfe-5ace-418a-81be-80abd99d6377"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "953fadd06668c9469a22020a5ac5879a8c1e06b893a6a133b9748e97a50a50a3:eth0",
        "container-id": "953fadd06668c9469a22020a5ac5879a8c1e06b893a6a133b9748e97a50a50a3",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-5b5dbbfb8-2bz5d",
        "pod-name": "kube-system/clustermesh-apiserver-5b5dbbfb8-2bz5d"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3836637,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh58",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=5b5dbbfb8"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh58",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:11Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.57.0.232",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "46:9e:44:58:65:f5",
        "interface-index": 18,
        "interface-name": "lxcc28d7b0c502d",
        "mac": "de:98:b7:0d:c4:ad"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3836637,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3836637,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 677

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 677

```
Timestamp              Status   State                   Message
2024-10-25T10:22:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:11Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:59Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:59Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:59Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3836637

```
ID        LABELS
3836637   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh58
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1167

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69401   797       0        
Allow    Egress      0          ANY          NONE         disabled    12866   132       0        

```


#### BPF CT List 1167

```
Invalid argument: unknown type 1167
```


#### Endpoint Get 1167

```
[
  {
    "id": 1167,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1167-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "af1201cd-63a5-4511-af41-84fea9162088"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1167",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:49.659Z",
            "success-count": 3
          },
          "uuid": "53ee9e83-30bd-4df1-8e16-64dafec8d244"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-jrgft",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:49.658Z",
            "success-count": 1
          },
          "uuid": "c0f442ec-d619-4e42-97ec-a1cd237cc0fa"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1167",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:52.297Z",
            "success-count": 1
          },
          "uuid": "1ed3bc54-be04-41a8-a831-603c0f7d2950"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1167)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:09.736Z",
            "success-count": 76
          },
          "uuid": "c5ac23ca-1117-4fdc-9de7-4abdfe4a64d7"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "ad7d286f4dd6b9cac2f67ce37c1004f24276617f7abb0c99137ba2c0b06adcc8:eth0",
        "container-id": "ad7d286f4dd6b9cac2f67ce37c1004f24276617f7abb0c99137ba2c0b06adcc8",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-jrgft",
        "pod-name": "kube-system/coredns-cc6ccd49c-jrgft"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3820400,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh58",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh58",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:11Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.57.0.217",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "3e:28:d7:e6:b5:b4",
        "interface-index": 14,
        "interface-name": "lxcc50d46ba305b",
        "mac": "7a:0d:da:04:aa:93"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3820400,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3820400,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1167

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1167

```
Timestamp              Status   State                   Message
2024-10-25T10:22:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:11Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:16:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:52Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:16:50Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:16:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:16:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:16:49Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:16:49Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3820400

```
ID        LABELS
3820400   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh58
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1615

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1615

```
Invalid argument: unknown type 1615
```


#### Endpoint Get 1615

```
[
  {
    "id": 1615,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1615-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "32846f5e-3511-4a11-8407-59a93afa8c2e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1615",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:48.055Z",
            "success-count": 3
          },
          "uuid": "91860f0b-9b24-4dbd-9268-b6fa3a90e352"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1615",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:49.044Z",
            "success-count": 1
          },
          "uuid": "3c717afa-da91-4193-a498-4e1e2b8c0037"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:11Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "36:ac:0f:a6:19:30",
        "interface-name": "cilium_host",
        "mac": "36:ac:0f:a6:19:30"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1615

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1615

```
Timestamp              Status   State                   Message
2024-10-25T10:22:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:11Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:16:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:52Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:16:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:50Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:16:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:16:49Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:16:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:48Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:16:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:16:48Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:16:48Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 2192

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69929   805       0        
Allow    Egress      0          ANY          NONE         disabled    12577   129       0        

```


#### BPF CT List 2192

```
Invalid argument: unknown type 2192
```


#### Endpoint Get 2192

```
[
  {
    "id": 2192,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2192-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5cb83119-046a-4242-b3ff-d90908d26784"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2192",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:49.619Z",
            "success-count": 3
          },
          "uuid": "69561355-4f17-48f1-9ce7-4fbcf1c827a9"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-g2922",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:49.618Z",
            "success-count": 1
          },
          "uuid": "a63da423-d854-45e6-b988-b4d53312bf8c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2192",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:52.233Z",
            "success-count": 1
          },
          "uuid": "c797fe75-7b5a-4423-82a9-9e2af001c570"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2192)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:09.682Z",
            "success-count": 76
          },
          "uuid": "bc571d2a-568f-4768-bb5d-e7c23297f022"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "b769d464a2d7abde52d83952f93d03870372dd68f74331e38a8425e6ebf8520a:eth0",
        "container-id": "b769d464a2d7abde52d83952f93d03870372dd68f74331e38a8425e6ebf8520a",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-g2922",
        "pod-name": "kube-system/coredns-cc6ccd49c-g2922"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3820400,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh58",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh58",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:11Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.57.0.227",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "da:d8:be:40:d4:c1",
        "interface-index": 12,
        "interface-name": "lxc2b68d1390598",
        "mac": "0a:e4:aa:50:c8:bd"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3820400,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3820400,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2192

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2192

```
Timestamp              Status    State                   Message
2024-10-25T10:22:11Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:11Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:11Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:22:11Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:10Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:10Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:10Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:10Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:02Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:16:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:51Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:16:50Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:16:49Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:16:49Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:16:49Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:16:49Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:49Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 3820400

```
ID        LABELS
3820400   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh58
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 2662

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    436492   5576      0        
Allow    Ingress     1          ANY          NONE         disabled    10758    127       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 2662

```
Invalid argument: unknown type 2662
```


#### Endpoint Get 2662

```
[
  {
    "id": 2662,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2662-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d02c38db-53aa-4c3f-a9b5-178a0fe89e6c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2662",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:49.108Z",
            "success-count": 3
          },
          "uuid": "2b5c9d9b-998c-4b84-99b1-7c8f681b151f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2662",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:16:52.256Z",
            "success-count": 1
          },
          "uuid": "1452b54e-bcf1-4889-be00-ed565f31e368"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:11Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.57.0.30",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "7a:19:a8:6b:28:ab",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "82:b4:00:13:7d:f6"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2662

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2662

```
Timestamp              Status   State                   Message
2024-10-25T10:22:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:11Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:16:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:16:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:16:52Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:16:50Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:16:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:16:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:16:49Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:16:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:16:49Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:16:48Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.138.228:443 (active)    
                                          2 => 172.31.231.155:443 (active)    
2    10.100.4.50:443       ClusterIP      1 => 172.31.231.209:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.57.0.217:53 (active)        
                                          2 => 10.57.0.227:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.57.0.217:9153 (active)      
                                          2 => 10.57.0.227:9153 (active)      
5    10.100.121.153:2379   ClusterIP      1 => 10.57.0.232:2379 (active)      
```

#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 33636736                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 33636736                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 33636736                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400cc00000 rw-p 00000000 00:00 0 
400cc00000-4010000000 ---p 00000000 00:00 0 
ffff44b13000-ffff44d49000 rw-p 00000000 00:00 0 
ffff44d51000-ffff44e72000 rw-p 00000000 00:00 0 
ffff44e72000-ffff44eb3000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff44eb3000-ffff44ef4000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff44ef4000-ffff44ef6000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff44ef6000-ffff44ef8000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff44ef8000-ffff4548f000 rw-p 00000000 00:00 0 
ffff4548f000-ffff4558f000 rw-p 00000000 00:00 0 
ffff4558f000-ffff455a0000 rw-p 00000000 00:00 0 
ffff455a0000-ffff475a0000 rw-p 00000000 00:00 0 
ffff475a0000-ffff47620000 ---p 00000000 00:00 0 
ffff47620000-ffff47621000 rw-p 00000000 00:00 0 
ffff47621000-ffff67620000 ---p 00000000 00:00 0 
ffff67620000-ffff67621000 rw-p 00000000 00:00 0 
ffff67621000-ffff875b0000 ---p 00000000 00:00 0 
ffff875b0000-ffff875b1000 rw-p 00000000 00:00 0 
ffff875b1000-ffff8b5a2000 ---p 00000000 00:00 0 
ffff8b5a2000-ffff8b5a3000 rw-p 00000000 00:00 0 
ffff8b5a3000-ffff8bda0000 ---p 00000000 00:00 0 
ffff8bda0000-ffff8bda1000 rw-p 00000000 00:00 0 
ffff8bda1000-ffff8bea0000 ---p 00000000 00:00 0 
ffff8bea0000-ffff8bf00000 rw-p 00000000 00:00 0 
ffff8bf00000-ffff8bf02000 r--p 00000000 00:00 0                          [vvar]
ffff8bf02000-ffff8bf03000 r-xp 00000000 00:00 0                          [vdso]
ffffd0911000-ffffd0932000 rw-p 00000000 00:00 0                          [stack]

```

