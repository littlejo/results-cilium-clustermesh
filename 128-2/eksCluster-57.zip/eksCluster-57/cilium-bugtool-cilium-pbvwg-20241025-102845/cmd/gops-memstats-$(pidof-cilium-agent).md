alloc: 106.16MB (111312896 bytes)
total-alloc: 1.35GB (1444631200 bytes)
sys: 198.32MB (207952196 bytes)
lookups: 0
mallocs: 48136752
frees: 46976434
heap-alloc: 106.16MB (111312896 bytes)
heap-sys: 153.35MB (160800768 bytes)
heap-idle: 27.27MB (28598272 bytes)
heap-in-use: 126.08MB (132202496 bytes)
heap-released: 0 bytes
heap-objects: 1160318
stack-in-use: 34.62MB (36306944 bytes)
stack-sys: 34.62MB (36306944 bytes)
stack-mspan-inuse: 2.12MB (2220800 bytes)
stack-mspan-sys: 2.47MB (2594880 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 894.24KB (915697 bytes)
gc-sys: 5.07MB (5315776 bytes)
next-gc: when heap-alloc >= 145.80MB (152882024 bytes)
last-gc: 2024-10-25 10:28:49.839590228 +0000 UTC
gc-pause-total: 16.824186ms
gc-pause: 233881
gc-pause-end: 1729852129839590228
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.0003875821823187492
enable-gc: true
debug-gc: false
