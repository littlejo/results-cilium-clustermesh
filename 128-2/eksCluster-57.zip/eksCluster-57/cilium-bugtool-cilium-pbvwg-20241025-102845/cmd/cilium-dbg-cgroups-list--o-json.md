[
  {
    "containers": [
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod01a0ad65_d6fb_4b9c_aa68_b29360ca48fe.slice/cri-containerd-c8fa12657d24a04b6f7da851c33707bae7f98c471bb0c3a4b0b050301f4ca8f2.scope"
      },
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod01a0ad65_d6fb_4b9c_aa68_b29360ca48fe.slice/cri-containerd-807f189501c468614fe9a9824d6fb8c20e581daa50341a6ef80aa302527f563b.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod01a0ad65_d6fb_4b9c_aa68_b29360ca48fe.slice/cri-containerd-173fb6a690e57799d1045641242c4dc77178ae8ca26e3c464c3e208c4b89f73a.scope"
      }
    ],
    "ips": [
      "10.57.0.232"
    ],
    "name": "clustermesh-apiserver-5b5dbbfb8-2bz5d",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbc6ec0eb_5f45_4b4c_b676_a5bb5a17d623.slice/cri-containerd-29462f595452e999cdb37d4a742052e1ed6828fce1baf6a5d6e6ac90eb2a1098.scope"
      }
    ],
    "ips": [
      "10.57.0.217"
    ],
    "name": "coredns-cc6ccd49c-jrgft",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc8db03e4_360f_47b1_932b_6223e5d61bde.slice/cri-containerd-0b719d749566bc67d99579614146a103e4d9d9bc9a32539c5b0489fdf743b769.scope"
      }
    ],
    "ips": [
      "10.57.0.227"
    ],
    "name": "coredns-cc6ccd49c-g2922",
    "namespace": "kube-system"
  }
]

