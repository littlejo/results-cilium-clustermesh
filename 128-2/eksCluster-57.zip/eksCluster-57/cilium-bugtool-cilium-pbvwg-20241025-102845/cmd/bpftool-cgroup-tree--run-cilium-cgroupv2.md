CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod257b012d_f914_4aab_896f_04d5bf293090.slice/cri-containerd-b8652f3e8e6391938fa0c081036b3137d9b8c1c3833cd0461e59b01b94a2402b.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod257b012d_f914_4aab_896f_04d5bf293090.slice/cri-containerd-813edcd651c59bfc07b42236528c1178cc7abc3ebcabbf4099a87edc8953a6f5.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode18806f5_abfb_4ea9_8655_b4af001a93a0.slice/cri-containerd-fc770b89e9c6ba5094753a2177b2e1f71780682fba335dbd4c27925ccc5c3c2d.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode18806f5_abfb_4ea9_8655_b4af001a93a0.slice/cri-containerd-3cedbde6a6024b78667b5c020cc1c11293cbef1e0b85e31d00c069e949423359.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc8db03e4_360f_47b1_932b_6223e5d61bde.slice/cri-containerd-b769d464a2d7abde52d83952f93d03870372dd68f74331e38a8425e6ebf8520a.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc8db03e4_360f_47b1_932b_6223e5d61bde.slice/cri-containerd-0b719d749566bc67d99579614146a103e4d9d9bc9a32539c5b0489fdf743b769.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbc6ec0eb_5f45_4b4c_b676_a5bb5a17d623.slice/cri-containerd-29462f595452e999cdb37d4a742052e1ed6828fce1baf6a5d6e6ac90eb2a1098.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbc6ec0eb_5f45_4b4c_b676_a5bb5a17d623.slice/cri-containerd-ad7d286f4dd6b9cac2f67ce37c1004f24276617f7abb0c99137ba2c0b06adcc8.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd055145c_8133_4a55_9dca_8702483d46f5.slice/cri-containerd-e95a37bd7e45171c13f3e0d2f9279879b921ff00c56b6cfb3fb2f8996c443f93.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd055145c_8133_4a55_9dca_8702483d46f5.slice/cri-containerd-50fc6d10b45d28633b50914e1a316cf22cbbc6f9f49acbc9fb3e89488ae660d0.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod690d0a6a_a882_4718_aec3_8384cd836f46.slice/cri-containerd-e197d358df04797c582fb319c96196d175510604874555c0fea53bb8af5d005b.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod690d0a6a_a882_4718_aec3_8384cd836f46.slice/cri-containerd-2ae1167ee870613f579372d5fffb99fc437501a7705790eacc8d062fd90c4175.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod01a0ad65_d6fb_4b9c_aa68_b29360ca48fe.slice/cri-containerd-953fadd06668c9469a22020a5ac5879a8c1e06b893a6a133b9748e97a50a50a3.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod01a0ad65_d6fb_4b9c_aa68_b29360ca48fe.slice/cri-containerd-c8fa12657d24a04b6f7da851c33707bae7f98c471bb0c3a4b0b050301f4ca8f2.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod01a0ad65_d6fb_4b9c_aa68_b29360ca48fe.slice/cri-containerd-807f189501c468614fe9a9824d6fb8c20e581daa50341a6ef80aa302527f563b.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod01a0ad65_d6fb_4b9c_aa68_b29360ca48fe.slice/cri-containerd-173fb6a690e57799d1045641242c4dc77178ae8ca26e3c464c3e208c4b89f73a.scope
    670      cgroup_device   multi                                          
