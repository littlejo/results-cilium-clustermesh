Endpoint ID: 677
Path: /sys/fs/bpf/tc/globals/cilium_policy_00677

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3890132   36828     0        
Allow    Ingress     1          ANY          NONE         disabled    3348183   34113     0        
Allow    Egress      0          ANY          NONE         disabled    4716872   43580     0        


Endpoint ID: 1167
Path: /sys/fs/bpf/tc/globals/cilium_policy_01167

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    70362   808       0        
Allow    Egress      0          ANY          NONE         disabled    12866   132       0        


Endpoint ID: 1615
Path: /sys/fs/bpf/tc/globals/cilium_policy_01615

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2192
Path: /sys/fs/bpf/tc/globals/cilium_policy_02192

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    70890   816       0        
Allow    Egress      0          ANY          NONE         disabled    12577   129       0        


Endpoint ID: 2662
Path: /sys/fs/bpf/tc/globals/cilium_policy_02662

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    437346   5586      0        
Allow    Ingress     1          ANY          NONE         disabled    10758    127       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


