IP ADDRESS         LOCAL ENDPOINT INFO
10.57.0.232:0      id=677   sec_id=3836637 flags=0x0000 ifindex=18  mac=DE:98:B7:0D:C4:AD nodemac=46:9E:44:58:65:F5   
10.57.0.227:0      id=2192  sec_id=3820400 flags=0x0000 ifindex=12  mac=0A:E4:AA:50:C8:BD nodemac=DA:D8:BE:40:D4:C1   
172.31.231.209:0   (localhost)                                                                                        
172.31.250.221:0   (localhost)                                                                                        
10.57.0.76:0       (localhost)                                                                                        
10.57.0.217:0      id=1167  sec_id=3820400 flags=0x0000 ifindex=14  mac=7A:0D:DA:04:AA:93 nodemac=3E:28:D7:E6:B5:B4   
10.57.0.30:0       id=2662  sec_id=4     flags=0x0000 ifindex=10  mac=82:B4:00:13:7D:F6 nodemac=7A:19:A8:6B:28:AB     
