KEY             VALUE
AgentLiveness   843453086005
UTimeOffset     3378615847656250
