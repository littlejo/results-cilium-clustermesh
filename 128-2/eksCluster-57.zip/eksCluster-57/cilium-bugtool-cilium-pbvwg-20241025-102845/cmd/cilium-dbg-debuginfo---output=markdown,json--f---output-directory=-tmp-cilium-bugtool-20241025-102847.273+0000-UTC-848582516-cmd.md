markdown output at /tmp/cilium-bugtool-20241025-102847.273+0000-UTC-848582516/cmd/cilium-debuginfo-20241025-102917.953+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102847.273+0000-UTC-848582516/cmd/cilium-debuginfo-20241025-102917.953+0000-UTC.json
