key: 31 00 00 00  value: 47 02 00 00
key: 52 04 00 00  value: 16 02 00 00
key: af 08 00 00  value: 35 02 00 00
key: c8 0b 00 00  value: 7c 02 00 00
Found 4 elements
