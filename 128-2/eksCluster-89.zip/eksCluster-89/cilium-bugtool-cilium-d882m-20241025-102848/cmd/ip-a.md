1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:87:c0:d1:f4:d7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.234.174/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2701sec preferred_lft 2701sec
    inet6 fe80::887:c0ff:fed1:f4d7/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST> mtu 1500 qdisc noop state DOWN group default qlen 1000
    link/ether 0a:56:31:b4:56:33 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:92:4c:da:a8:61 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4892:4cff:feda:a861/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:d3:82:5a:67:3f brd ff:ff:ff:ff:ff:ff
    inet 10.89.0.237/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::acd3:82ff:fe5a:673f/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 7e:58:f2:3e:ac:43 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::7c58:f2ff:fe3e:ac43/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:43:09:70:ab:53 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::8843:9ff:fe70:ab53/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc8bc1a60d10ba@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:a6:b9:b2:78:68 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::84a6:b9ff:feb2:7868/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcdf976f297946@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:af:e8:9e:09:da brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b4af:e8ff:fe9e:9da/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcc8e18ba05dd9@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:f9:47:c0:b0:0c brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::50f9:47ff:fec0:b00c/64 scope link 
       valid_lft forever preferred_lft forever
