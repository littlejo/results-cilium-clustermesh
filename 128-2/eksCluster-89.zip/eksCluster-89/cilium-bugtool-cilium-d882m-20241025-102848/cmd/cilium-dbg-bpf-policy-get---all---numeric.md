Endpoint ID: 49
Path: /sys/fs/bpf/tc/globals/cilium_policy_00049

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    81609   940       0        
Allow    Egress      0          ANY          NONE         disabled    14474   152       0        


Endpoint ID: 465
Path: /sys/fs/bpf/tc/globals/cilium_policy_00465

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1106
Path: /sys/fs/bpf/tc/globals/cilium_policy_01106

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    82026   942       0        
Allow    Egress      0          ANY          NONE         disabled    14657   153       0        


Endpoint ID: 2223
Path: /sys/fs/bpf/tc/globals/cilium_policy_02223

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    445068   5691      0        
Allow    Ingress     1          ANY          NONE         disabled    12136    142       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3016
Path: /sys/fs/bpf/tc/globals/cilium_policy_03016

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3921307   36582     0        
Allow    Ingress     1          ANY          NONE         disabled    2791717   27851     0        
Allow    Egress      0          ANY          NONE         disabled    4210826   39092     0        


