IP ADDRESS         LOCAL ENDPOINT INFO
10.89.0.214:0      id=1106  sec_id=5963165 flags=0x0000 ifindex=12  mac=4E:1B:10:AA:A4:BA nodemac=86:A6:B9:B2:78:68   
10.89.0.97:0       id=2223  sec_id=4     flags=0x0000 ifindex=10  mac=DE:C5:11:A8:A0:92 nodemac=8A:43:09:70:AB:53     
10.89.0.31:0       id=49    sec_id=5963165 flags=0x0000 ifindex=14  mac=02:05:99:FC:4E:9D nodemac=B6:AF:E8:9E:09:DA   
10.89.0.216:0      id=3016  sec_id=5932289 flags=0x0000 ifindex=18  mac=5A:D5:9C:80:3F:89 nodemac=52:F9:47:C0:B0:0C   
172.31.234.174:0   (localhost)                                                                                        
10.89.0.237:0      (localhost)                                                                                        
