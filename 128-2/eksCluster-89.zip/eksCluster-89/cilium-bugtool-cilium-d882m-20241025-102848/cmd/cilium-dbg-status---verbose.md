KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.89.0.0/24, 
Allocated addresses:
  10.89.0.214 (kube-system/coredns-cc6ccd49c-slxgc)
  10.89.0.216 (kube-system/clustermesh-apiserver-76948b4cc8-mmkh2)
  10.89.0.237 (router)
  10.89.0.31 (kube-system/coredns-cc6ccd49c-sbr5f)
  10.89.0.97 (health)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3f315cb39e9899ee
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    37s ago        never        0       no error   
  ct-map-pressure                                                     9s ago         never        0       no error   
  daemon-validate-config                                              25s ago        never        0       no error   
  dns-garbage-collector-job                                           42s ago        never        0       no error   
  endpoint-1106-regeneration-recovery                                 never          never        0       no error   
  endpoint-2223-regeneration-recovery                                 never          never        0       no error   
  endpoint-3016-regeneration-recovery                                 never          never        0       no error   
  endpoint-465-regeneration-recovery                                  never          never        0       no error   
  endpoint-49-regeneration-recovery                                   never          never        0       no error   
  endpoint-gc                                                         4m42s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                9s ago         never        0       no error   
  ipcache-inject-labels                                               39s ago        never        0       no error   
  k8s-heartbeat                                                       12s ago        never        0       no error   
  link-cache                                                          9s ago         never        0       no error   
  local-identity-checkpoint                                           14m39s ago     never        0       no error   
  node-neighbor-link-updater                                          9s ago         never        0       no error   
  remote-etcd-cmesh1                                                  5m47s ago      never        0       no error   
  remote-etcd-cmesh10                                                 5m46s ago      never        0       no error   
  remote-etcd-cmesh100                                                5m46s ago      never        0       no error   
  remote-etcd-cmesh101                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh102                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh103                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh104                                                5m46s ago      never        0       no error   
  remote-etcd-cmesh105                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh106                                                5m46s ago      never        0       no error   
  remote-etcd-cmesh107                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh108                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh109                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh11                                                 5m46s ago      never        0       no error   
  remote-etcd-cmesh110                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh111                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh112                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh113                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh114                                                5m46s ago      never        0       no error   
  remote-etcd-cmesh115                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh116                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh117                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh118                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh119                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh12                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh120                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh121                                                5m46s ago      never        0       no error   
  remote-etcd-cmesh122                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh123                                                5m46s ago      never        0       no error   
  remote-etcd-cmesh124                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh125                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh126                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh127                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh128                                                5m47s ago      never        0       no error   
  remote-etcd-cmesh13                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh14                                                 5m46s ago      never        0       no error   
  remote-etcd-cmesh15                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh16                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh17                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh18                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh19                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh2                                                  5m47s ago      never        0       no error   
  remote-etcd-cmesh20                                                 5m46s ago      never        0       no error   
  remote-etcd-cmesh21                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh22                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh23                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh24                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh25                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh26                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh27                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh28                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh29                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh3                                                  5m47s ago      never        0       no error   
  remote-etcd-cmesh30                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh31                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh32                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh33                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh34                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh35                                                 5m46s ago      never        0       no error   
  remote-etcd-cmesh36                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh37                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh38                                                 5m46s ago      never        0       no error   
  remote-etcd-cmesh39                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh4                                                  5m47s ago      never        0       no error   
  remote-etcd-cmesh40                                                 5m46s ago      never        0       no error   
  remote-etcd-cmesh41                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh42                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh43                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh44                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh45                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh46                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh47                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh48                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh49                                                 5m46s ago      never        0       no error   
  remote-etcd-cmesh5                                                  5m47s ago      never        0       no error   
  remote-etcd-cmesh50                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh51                                                 5m46s ago      never        0       no error   
  remote-etcd-cmesh52                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh53                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh54                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh55                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh56                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh57                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh58                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh59                                                 5m46s ago      never        0       no error   
  remote-etcd-cmesh6                                                  5m46s ago      never        0       no error   
  remote-etcd-cmesh60                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh61                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh62                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh63                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh64                                                 5m46s ago      never        0       no error   
  remote-etcd-cmesh65                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh66                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh67                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh68                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh69                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh7                                                  5m47s ago      never        0       no error   
  remote-etcd-cmesh70                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh71                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh72                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh73                                                 5m46s ago      never        0       no error   
  remote-etcd-cmesh74                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh75                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh76                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh77                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh78                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh79                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh8                                                  5m47s ago      never        0       no error   
  remote-etcd-cmesh80                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh81                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh82                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh83                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh84                                                 5m46s ago      never        0       no error   
  remote-etcd-cmesh85                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh86                                                 5m46s ago      never        0       no error   
  remote-etcd-cmesh87                                                 5m46s ago      never        0       no error   
  remote-etcd-cmesh88                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh89                                                 5m46s ago      never        0       no error   
  remote-etcd-cmesh9                                                  5m47s ago      never        0       no error   
  remote-etcd-cmesh91                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh92                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh93                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh94                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh95                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh96                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh97                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh98                                                 5m47s ago      never        0       no error   
  remote-etcd-cmesh99                                                 5m47s ago      never        0       no error   
  resolve-identity-1106                                               4m39s ago      never        0       no error   
  resolve-identity-2223                                               4m38s ago      never        0       no error   
  resolve-identity-3016                                               1m50s ago      never        0       no error   
  resolve-identity-465                                                4m39s ago      never        0       no error   
  resolve-identity-49                                                 4m27s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-76948b4cc8-mmkh2   6m50s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-sbr5f                  14m27s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-slxgc                  14m39s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      14m39s ago     never        0       no error   
  sync-policymap-1106                                                 14m36s ago     never        0       no error   
  sync-policymap-2223                                                 14m33s ago     never        0       no error   
  sync-policymap-3016                                                 6m50s ago      never        0       no error   
  sync-policymap-465                                                  14m38s ago     never        0       no error   
  sync-policymap-49                                                   14m27s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (1106)                                   9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3016)                                   10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (49)                                     7s ago         never        0       no error   
  sync-utime                                                          39s ago        never        0       no error   
  write-cni-file                                                      14m42s ago     never        0       no error   
Proxy Status:            OK, ip 10.89.0.237, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 5898240, max 5963775
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 70.41   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:                                                          Disabled           
Cluster health:                                                      96/128 reachable   (2024-10-25T10:28:45Z)
  Name                                                               IP                 Node          Endpoints
  cmesh90/ip-172-31-234-174.eu-west-3.compute.internal (localhost)   172.31.234.174     reachable     reachable
  cmesh1/ip-172-31-188-219.eu-west-3.compute.internal                172.31.188.219     reachable     reachable
  cmesh10/ip-172-31-208-120.eu-west-3.compute.internal               172.31.208.120     reachable     reachable
  cmesh100/ip-172-31-201-30.eu-west-3.compute.internal               172.31.201.30      unreachable   reachable
  cmesh101/ip-172-31-165-24.eu-west-3.compute.internal               172.31.165.24      reachable     reachable
  cmesh102/ip-172-31-195-223.eu-west-3.compute.internal              172.31.195.223     reachable     reachable
  cmesh103/ip-172-31-184-93.eu-west-3.compute.internal               172.31.184.93      reachable     reachable
  cmesh104/ip-172-31-216-37.eu-west-3.compute.internal               172.31.216.37      reachable     reachable
  cmesh105/ip-172-31-188-169.eu-west-3.compute.internal              172.31.188.169     reachable     reachable
  cmesh106/ip-172-31-227-91.eu-west-3.compute.internal               172.31.227.91      reachable     reachable
  cmesh107/ip-172-31-178-197.eu-west-3.compute.internal              172.31.178.197     reachable     reachable
  cmesh108/ip-172-31-238-183.eu-west-3.compute.internal              172.31.238.183     reachable     unreachable
  cmesh109/ip-172-31-173-246.eu-west-3.compute.internal              172.31.173.246     reachable     reachable
  cmesh11/ip-172-31-155-27.eu-west-3.compute.internal                172.31.155.27      reachable     unreachable
  cmesh110/ip-172-31-224-45.eu-west-3.compute.internal               172.31.224.45      unreachable   reachable
  cmesh111/ip-172-31-152-109.eu-west-3.compute.internal              172.31.152.109     reachable     reachable
  cmesh112/ip-172-31-227-62.eu-west-3.compute.internal               172.31.227.62      reachable     reachable
  cmesh113/ip-172-31-179-165.eu-west-3.compute.internal              172.31.179.165     reachable     reachable
  cmesh114/ip-172-31-195-97.eu-west-3.compute.internal               172.31.195.97      reachable     reachable
  cmesh115/ip-172-31-143-66.eu-west-3.compute.internal               172.31.143.66      reachable     reachable
  cmesh116/ip-172-31-197-216.eu-west-3.compute.internal              172.31.197.216     reachable     reachable
  cmesh117/ip-172-31-163-31.eu-west-3.compute.internal               172.31.163.31      reachable     reachable
  cmesh118/ip-172-31-209-231.eu-west-3.compute.internal              172.31.209.231     reachable     reachable
  cmesh119/ip-172-31-169-120.eu-west-3.compute.internal              172.31.169.120     reachable     reachable
  cmesh12/ip-172-31-197-79.eu-west-3.compute.internal                172.31.197.79      reachable     reachable
  cmesh120/ip-172-31-250-55.eu-west-3.compute.internal               172.31.250.55      reachable     unreachable
  cmesh121/ip-172-31-149-225.eu-west-3.compute.internal              172.31.149.225     reachable     reachable
  cmesh122/ip-172-31-220-42.eu-west-3.compute.internal               172.31.220.42      reachable     reachable
  cmesh123/ip-172-31-144-245.eu-west-3.compute.internal              172.31.144.245     reachable     unreachable
  cmesh124/ip-172-31-226-176.eu-west-3.compute.internal              172.31.226.176     reachable     reachable
  cmesh125/ip-172-31-147-32.eu-west-3.compute.internal               172.31.147.32      reachable     reachable
  cmesh126/ip-172-31-220-135.eu-west-3.compute.internal              172.31.220.135     reachable     reachable
  cmesh127/ip-172-31-181-107.eu-west-3.compute.internal              172.31.181.107     reachable     reachable
  cmesh128/ip-172-31-246-169.eu-west-3.compute.internal              172.31.246.169     reachable     reachable
  cmesh13/ip-172-31-170-139.eu-west-3.compute.internal               172.31.170.139     reachable     reachable
  cmesh14/ip-172-31-226-178.eu-west-3.compute.internal               172.31.226.178     unreachable   reachable
  cmesh15/ip-172-31-147-77.eu-west-3.compute.internal                172.31.147.77      reachable     reachable
  cmesh16/ip-172-31-234-25.eu-west-3.compute.internal                172.31.234.25      reachable     unreachable
  cmesh17/ip-172-31-154-239.eu-west-3.compute.internal               172.31.154.239     reachable     reachable
  cmesh18/ip-172-31-247-244.eu-west-3.compute.internal               172.31.247.244     reachable     reachable
  cmesh19/ip-172-31-161-89.eu-west-3.compute.internal                172.31.161.89      reachable     reachable
  cmesh2/ip-172-31-197-251.eu-west-3.compute.internal                172.31.197.251     reachable     reachable
  cmesh20/ip-172-31-210-89.eu-west-3.compute.internal                172.31.210.89      unreachable   reachable
  cmesh21/ip-172-31-169-166.eu-west-3.compute.internal               172.31.169.166     reachable     reachable
  cmesh22/ip-172-31-247-164.eu-west-3.compute.internal               172.31.247.164     reachable     reachable
  cmesh23/ip-172-31-180-212.eu-west-3.compute.internal               172.31.180.212     reachable     reachable
  cmesh24/ip-172-31-206-64.eu-west-3.compute.internal                172.31.206.64      reachable     reachable
  cmesh25/ip-172-31-148-101.eu-west-3.compute.internal               172.31.148.101     unreachable   reachable
  cmesh26/ip-172-31-217-133.eu-west-3.compute.internal               172.31.217.133     reachable     reachable
  cmesh27/ip-172-31-147-228.eu-west-3.compute.internal               172.31.147.228     reachable     reachable
  cmesh28/ip-172-31-253-235.eu-west-3.compute.internal               172.31.253.235     reachable     reachable
  cmesh29/ip-172-31-144-216.eu-west-3.compute.internal               172.31.144.216     reachable     reachable
  cmesh3/ip-172-31-169-175.eu-west-3.compute.internal                172.31.169.175     reachable     reachable
  cmesh30/ip-172-31-243-59.eu-west-3.compute.internal                172.31.243.59      unreachable   reachable
  cmesh31/ip-172-31-161-158.eu-west-3.compute.internal               172.31.161.158     reachable     reachable
  cmesh32/ip-172-31-247-172.eu-west-3.compute.internal               172.31.247.172     reachable     unreachable
  cmesh33/ip-172-31-186-90.eu-west-3.compute.internal                172.31.186.90      reachable     reachable
  cmesh34/ip-172-31-229-207.eu-west-3.compute.internal               172.31.229.207     unreachable   reachable
  cmesh35/ip-172-31-189-5.eu-west-3.compute.internal                 172.31.189.5       reachable     unreachable
  cmesh36/ip-172-31-193-211.eu-west-3.compute.internal               172.31.193.211     reachable     reachable
  cmesh37/ip-172-31-142-96.eu-west-3.compute.internal                172.31.142.96      reachable     reachable
  cmesh38/ip-172-31-235-234.eu-west-3.compute.internal               172.31.235.234     reachable     reachable
  cmesh39/ip-172-31-172-183.eu-west-3.compute.internal               172.31.172.183     unreachable   reachable
  cmesh4/ip-172-31-250-86.eu-west-3.compute.internal                 172.31.250.86      reachable     reachable
  cmesh40/ip-172-31-246-192.eu-west-3.compute.internal               172.31.246.192     reachable     reachable
  cmesh41/ip-172-31-175-121.eu-west-3.compute.internal               172.31.175.121     reachable     reachable
  cmesh42/ip-172-31-249-77.eu-west-3.compute.internal                172.31.249.77      reachable     reachable
  cmesh43/ip-172-31-149-98.eu-west-3.compute.internal                172.31.149.98      reachable     reachable
  cmesh44/ip-172-31-251-101.eu-west-3.compute.internal               172.31.251.101     unreachable   reachable
  cmesh45/ip-172-31-140-221.eu-west-3.compute.internal               172.31.140.221     reachable     reachable
  cmesh46/ip-172-31-210-97.eu-west-3.compute.internal                172.31.210.97      unreachable   reachable
  cmesh47/ip-172-31-190-180.eu-west-3.compute.internal               172.31.190.180     unreachable   reachable
  cmesh48/ip-172-31-206-43.eu-west-3.compute.internal                172.31.206.43      reachable     reachable
  cmesh49/ip-172-31-149-115.eu-west-3.compute.internal               172.31.149.115     reachable     reachable
  cmesh5/ip-172-31-172-128.eu-west-3.compute.internal                172.31.172.128     reachable     reachable
  cmesh50/ip-172-31-231-255.eu-west-3.compute.internal               172.31.231.255     unreachable   reachable
  cmesh51/ip-172-31-144-60.eu-west-3.compute.internal                172.31.144.60      reachable     reachable
  cmesh52/ip-172-31-245-66.eu-west-3.compute.internal                172.31.245.66      reachable     reachable
  cmesh53/ip-172-31-143-87.eu-west-3.compute.internal                172.31.143.87      reachable     reachable
  cmesh54/ip-172-31-222-147.eu-west-3.compute.internal               172.31.222.147     reachable     reachable
  cmesh55/ip-172-31-145-45.eu-west-3.compute.internal                172.31.145.45      reachable     reachable
  cmesh56/ip-172-31-246-231.eu-west-3.compute.internal               172.31.246.231     reachable     unreachable
  cmesh57/ip-172-31-158-50.eu-west-3.compute.internal                172.31.158.50      unreachable   reachable
  cmesh58/ip-172-31-231-209.eu-west-3.compute.internal               172.31.231.209     reachable     reachable
  cmesh59/ip-172-31-172-29.eu-west-3.compute.internal                172.31.172.29      unreachable   unreachable
  cmesh6/ip-172-31-239-114.eu-west-3.compute.internal                172.31.239.114     reachable     reachable
  cmesh60/ip-172-31-249-105.eu-west-3.compute.internal               172.31.249.105     reachable     unreachable
  cmesh61/ip-172-31-184-13.eu-west-3.compute.internal                172.31.184.13      reachable     reachable
  cmesh62/ip-172-31-242-183.eu-west-3.compute.internal               172.31.242.183     reachable     reachable
  cmesh63/ip-172-31-134-163.eu-west-3.compute.internal               172.31.134.163     reachable     reachable
  cmesh64/ip-172-31-240-216.eu-west-3.compute.internal               172.31.240.216     unreachable   reachable
  cmesh65/ip-172-31-129-220.eu-west-3.compute.internal               172.31.129.220     reachable     reachable
  cmesh66/ip-172-31-232-182.eu-west-3.compute.internal               172.31.232.182     reachable     reachable
  cmesh67/ip-172-31-170-17.eu-west-3.compute.internal                172.31.170.17      reachable     reachable
  cmesh68/ip-172-31-217-208.eu-west-3.compute.internal               172.31.217.208     reachable     reachable
  cmesh69/ip-172-31-137-105.eu-west-3.compute.internal               172.31.137.105     reachable     reachable
  cmesh7/ip-172-31-174-163.eu-west-3.compute.internal                172.31.174.163     reachable     unreachable
  cmesh70/ip-172-31-197-74.eu-west-3.compute.internal                172.31.197.74      reachable     unreachable
  cmesh71/ip-172-31-176-0.eu-west-3.compute.internal                 172.31.176.0       reachable     reachable
  cmesh72/ip-172-31-244-208.eu-west-3.compute.internal               172.31.244.208     reachable     reachable
  cmesh73/ip-172-31-168-162.eu-west-3.compute.internal               172.31.168.162     reachable     reachable
  cmesh74/ip-172-31-213-46.eu-west-3.compute.internal                172.31.213.46      reachable     unreachable
  cmesh75/ip-172-31-135-32.eu-west-3.compute.internal                172.31.135.32      reachable     reachable
  cmesh76/ip-172-31-198-153.eu-west-3.compute.internal               172.31.198.153     reachable     unreachable
  cmesh77/ip-172-31-158-228.eu-west-3.compute.internal               172.31.158.228     reachable     reachable
  cmesh78/ip-172-31-236-177.eu-west-3.compute.internal               172.31.236.177     reachable     reachable
  cmesh79/ip-172-31-133-70.eu-west-3.compute.internal                172.31.133.70      reachable     reachable
  cmesh8/ip-172-31-194-36.eu-west-3.compute.internal                 172.31.194.36      reachable     reachable
  cmesh80/ip-172-31-217-236.eu-west-3.compute.internal               172.31.217.236     reachable     reachable
  cmesh81/ip-172-31-133-51.eu-west-3.compute.internal                172.31.133.51      reachable     reachable
  cmesh82/ip-172-31-195-150.eu-west-3.compute.internal               172.31.195.150     reachable     reachable
  cmesh83/ip-172-31-139-233.eu-west-3.compute.internal               172.31.139.233     reachable     reachable
  cmesh84/ip-172-31-231-66.eu-west-3.compute.internal                172.31.231.66      reachable     reachable
  cmesh85/ip-172-31-140-168.eu-west-3.compute.internal               172.31.140.168     reachable     reachable
  cmesh86/ip-172-31-228-79.eu-west-3.compute.internal                172.31.228.79      reachable     reachable
  cmesh87/ip-172-31-156-163.eu-west-3.compute.internal               172.31.156.163     reachable     unreachable
  cmesh88/ip-172-31-209-17.eu-west-3.compute.internal                172.31.209.17      reachable     reachable
  cmesh89/ip-172-31-167-92.eu-west-3.compute.internal                172.31.167.92      unreachable   reachable
  cmesh9/ip-172-31-191-155.eu-west-3.compute.internal                172.31.191.155     reachable     reachable
  cmesh91/ip-172-31-162-75.eu-west-3.compute.internal                172.31.162.75      reachable     reachable
  cmesh92/ip-172-31-225-137.eu-west-3.compute.internal               172.31.225.137     unreachable   reachable
  cmesh93/ip-172-31-129-184.eu-west-3.compute.internal               172.31.129.184     reachable     reachable
  cmesh94/ip-172-31-250-1.eu-west-3.compute.internal                 172.31.250.1       reachable     unreachable
  cmesh95/ip-172-31-186-243.eu-west-3.compute.internal               172.31.186.243     reachable     reachable
  cmesh96/ip-172-31-207-111.eu-west-3.compute.internal               172.31.207.111     reachable     reachable
  cmesh97/ip-172-31-129-241.eu-west-3.compute.internal               172.31.129.241     reachable     reachable
  cmesh98/ip-172-31-225-158.eu-west-3.compute.internal               172.31.225.158     reachable     reachable
  cmesh99/ip-172-31-173-171.eu-west-3.compute.internal               172.31.173.171     reachable     reachable
Modules Health:
      agent
      ├── controlplane
      │   ├── auth
      │   │   ├── observer-job-auth gc-identity-events            [OK] OK (5.629µs) [3] (13m, x1)
      │   │   ├── observer-job-auth request-authentication        [OK] Primed (14m, x1)
      │   │   └── timer-job-auth gc-cleanup                       [OK] OK (16.287µs) (4m42s, x1)
      │   ├── bgp-control-plane
      │   │   └── job-diffstore-events                            [OK] Running (14m, x2)
      │   ├── clustermesh
      │   │   ├── job-clustermesh-ipset-notifier                  [OK] Running (14m, x1)
      │   │   └── job-clustermesh-nodemanager-notifier            [OK] Running (14m, x1)
      │   ├── daemon
      │   │   ├──                                                 [OK] daemon-validate-config (25s, x15)
      │   │   ├── ep-bpf-prog-watchdog
      │   │   │   └── ep-bpf-prog-watchdog                        [OK] ep-bpf-prog-watchdog (9s, x30)
      │   │   └── job-sync-hostips                                [OK] Synchronized (39s, x15)
      │   ├── endpoint-manager
      │   │   ├── cilium-endpoint-1106 (kube-system/coredns-cc6ccd49c-slxgc)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (1106) (9s, x89)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (5m45s, x7)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-1106 (14m, x1)
      │   │   ├── cilium-endpoint-2223 (/)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (5m45s, x7)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-2223 (14m, x1)
      │   │   ├── cilium-endpoint-3016 (kube-system/clustermesh-apiserver-76948b4cc8-mmkh2)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (3016) (0s, x43)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (5m45s, x4)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-3016 (6m50s, x1)
      │   │   ├── cilium-endpoint-465 (/)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (5m45s, x8)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-465 (14m, x1)
      │   │   ├── cilium-endpoint-49 (kube-system/coredns-cc6ccd49c-sbr5f)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (49) (7s, x88)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (5m45s, x6)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-49 (14m, x1)
      │   │   └── endpoint-gc                                     [OK] endpoint-gc (4m42s, x3)
      │   ├── envoy-proxy
      │   │   └── timer-job-version-check                         [OK] OK (2.375788ms) (4m39s, x1)
      │   ├── l2-announcer
      │   │   └── job-l2-announcer lease-gc                       [OK] Running (14m, x1)
      │   ├── node-manager
      │   │   ├── background-sync                                 [OK] Node validation successful (31s, x14)
      │   │   ├── node-checkpoint-writer                          [OK] node checkpoint written (3m47s, x4)
      │   │   └── nodes-add                                       [OK] Node adds successful (5m46s, x128)
      │   ├── service-manager
      │   │   └── job-ServiceReconciler                           [OK] 1 NodePort frontend addresses (14m, x1)
      │   ├── service-resolver
      │   │   └── job-service-reloader-initializer                [OK] Synchronized (5m47s, x1)
      │   ├── stale-endpoint-cleanup
      │   │   └── job-endpoint-cleanup                            [OK] Running (14m, x1)
      │   └── timer-job-device-reloader                           [OK] OK (4.719219128s) (6m44s, x1)
      ├── datapath
      │   ├── agent-liveness-updater
      │   │   └── timer-job-agent-liveness-updater                [OK] OK (33.535µs) (0s, x1)
      │   ├── iptables
      │   │   ├── ipset
      │   │   │   ├── job-ipset-init-finalizer                    [OK] Running (14m, x1)
      │   │   │   └── job-reconciler-loop                         [OK] OK, 0 objects (14m, x1)
      │   │   └── job-iptables-reconciliation-loop                [OK] iptables rules full reconciliation completed (14m, x1)
      │   ├── l2-responder
      │   │   └── job-l2-responder-reconciler                     [OK] Running (14m, x1)
      │   ├── maps
      │   │   └── bwmap
      │   │       └── timer-job-pressure-metric-throttle          [OK] OK (1.756µs) (9s, x1)
      │   ├── node-address
      │   │   └── job-node-address-update                         [OK] 10.89.0.237 (primary), fe80::acd3:82ff:fe5a:673f (primary) (14m, x1)
      │   └── sysctl
      │       └── job-reconciler-loop                             [OK] OK, 20 objects (4m42s, x18)
      └── infra
          └── k8s-synced-crdsync
              └── job-sync-crds                                   [OK] Running (14m, x1)
      
