fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxc8bc1a60d10ba proto kernel metric 256 pref medium
fe80::/64 dev lxcdf976f297946 proto kernel metric 256 pref medium
fe80::/64 dev lxcc8e18ba05dd9 proto kernel metric 256 pref medium
