REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     214311    84502408   1132   bpf_host.c
Interface                 INGRESS     9724      757530     677    bpf_overlay.c
Success                   EGRESS      4699      357591     1694   bpf_host.c
Success                   EGRESS      89511     12041019   1308   bpf_lxc.c
Success                   EGRESS      9514      743093     53     encap.h
Success                   INGRESS     105014    12654776   235    trace.h
Success                   INGRESS     99340     12210931   86     l3.h
Unsupported L3 protocol   EGRESS      42        3188       1492   bpf_lxc.c
