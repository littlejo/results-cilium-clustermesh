CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9107f9b2_2b67_4516_916e_0e6470895840.slice/cri-containerd-8fad1d1d55fef93fd4cecf84ec823275de8e0dcb41594b2b520333c26d61d3bf.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9107f9b2_2b67_4516_916e_0e6470895840.slice/cri-containerd-6f3428c669db0beb8ee0c5116f15df4959360dd8191b3e13f250672672bee865.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod62c41ba0_de7b_4849_b2e2_d9ed685b0020.slice/cri-containerd-2a84dd55622ea8e9b92e6ab77e1a733c36e2a9a8dcde02abe5297bddc80ca86a.scope
    491      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod62c41ba0_de7b_4849_b2e2_d9ed685b0020.slice/cri-containerd-7e843a41519e3693e9cae297dd7f9a6ea5d3bb7dd200d0bd013a97fe8f3c2e12.scope
    495      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podedd77393_84ad_4aed_b037_c52e70e89dd8.slice/cri-containerd-bb18b8a9663f55d0a1d8e3ff8aab2ba75df1d47a900f0512752a0b06cdc82d22.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podedd77393_84ad_4aed_b037_c52e70e89dd8.slice/cri-containerd-738068da4bc3415c77c4d96301c25f89f3afdcaf8e1c3cac0ee5c90bd785882e.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod22b15c4b_07d2_4fe8_a07d_fb28500b82b9.slice/cri-containerd-c9edf9baa2c1a143b22a5fbb0eb63213b58a70fab5ee299fa07cc6d1e1147a6c.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod22b15c4b_07d2_4fe8_a07d_fb28500b82b9.slice/cri-containerd-dfe013f9b7bc8485d9766c909fcedca836f37d92b1768ff30a93da07f92e1111.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda73c0bb_c75e_48c2_84dd_4bb6be10ee9c.slice/cri-containerd-559d007d9784569e7056ae2031dd4198fefa86258314d1a2fc75513bab4d57df.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda73c0bb_c75e_48c2_84dd_4bb6be10ee9c.slice/cri-containerd-c21b7f2c8e77de589b85453cb8c5466c8698a2996694f7c0d85d3a39663182a1.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33e21b93_7979_41d3_ab4e_87d3d2a66878.slice/cri-containerd-95a25fba5ee1b83bbeae176091a3a76854cc633352e9b0f21d2138dabcd686f0.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33e21b93_7979_41d3_ab4e_87d3d2a66878.slice/cri-containerd-4fc0c4a09b5a51c0e5ab5e0770f63bbc535228a6a2eaf20a91c96a90fab06945.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33e21b93_7979_41d3_ab4e_87d3d2a66878.slice/cri-containerd-6f44334099b88536db0ef4bcdf0b2483ec2b17d0aefc487d390dbca6d0b3d807.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33e21b93_7979_41d3_ab4e_87d3d2a66878.slice/cri-containerd-fdefcc42fbef6f24660b56cf280175716a59edee98353a25b0ee0ae5e2336ec0.scope
    663      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod24f67f0f_6246_427e_b23b_7320f1403870.slice/cri-containerd-456db0c08b752882836ff29f245c2a220809afa117e9deaa663ceff9a6b8115f.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod24f67f0f_6246_427e_b23b_7320f1403870.slice/cri-containerd-a6d6f377fe26871d83a366fb18ed3a825e3f85aaf88938cc0704a0e189d4b60b.scope
    105      cgroup_device   multi                                          
