key: 01 00 00 00  value: f2 01 00 00
key: 07 00 00 00  value: f3 01 00 00
Found 2 elements
