Node 0, zone      DMA      3      1      4     31      9      1     10     14      8      4    164 
Node 0, zone   Normal      5      5     28     37     16     18      4      2      5      3      6 
