alloc: 72.38MB (75900056 bytes)
total-alloc: 1.33GB (1427162944 bytes)
sys: 214.38MB (224798036 bytes)
lookups: 0
mallocs: 47699788
frees: 47130436
heap-alloc: 72.38MB (75900056 bytes)
heap-sys: 169.60MB (177840128 bytes)
heap-idle: 56.85MB (59613184 bytes)
heap-in-use: 112.75MB (118226944 bytes)
heap-released: 1.83MB (1916928 bytes)
heap-objects: 569352
stack-in-use: 34.38MB (36044800 bytes)
stack-sys: 34.38MB (36044800 bytes)
stack-mspan-inuse: 1.91MB (1999040 bytes)
stack-mspan-sys: 2.49MB (2611200 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 879.67KB (900785 bytes)
gc-sys: 5.13MB (5376184 bytes)
next-gc: when heap-alloc >= 146.21MB (153316792 bytes)
last-gc: 2024-10-25 10:29:13.142725691 +0000 UTC
gc-pause-total: 6.999317ms
gc-pause: 70589
gc-pause-end: 1729852153142725691
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.0003757464712097458
enable-gc: true
debug-gc: false
