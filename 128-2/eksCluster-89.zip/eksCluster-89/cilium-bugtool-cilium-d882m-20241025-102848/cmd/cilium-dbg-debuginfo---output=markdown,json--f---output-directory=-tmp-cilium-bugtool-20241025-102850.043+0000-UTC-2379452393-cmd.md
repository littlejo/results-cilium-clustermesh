markdown output at /tmp/cilium-bugtool-20241025-102850.043+0000-UTC-2379452393/cmd/cilium-debuginfo-20241025-102920.569+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102850.043+0000-UTC-2379452393/cmd/cilium-debuginfo-20241025-102920.569+0000-UTC.json
