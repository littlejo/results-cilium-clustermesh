[
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33e21b93_7979_41d3_ab4e_87d3d2a66878.slice/cri-containerd-4fc0c4a09b5a51c0e5ab5e0770f63bbc535228a6a2eaf20a91c96a90fab06945.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33e21b93_7979_41d3_ab4e_87d3d2a66878.slice/cri-containerd-fdefcc42fbef6f24660b56cf280175716a59edee98353a25b0ee0ae5e2336ec0.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33e21b93_7979_41d3_ab4e_87d3d2a66878.slice/cri-containerd-95a25fba5ee1b83bbeae176091a3a76854cc633352e9b0f21d2138dabcd686f0.scope"
      }
    ],
    "ips": [
      "10.89.0.216"
    ],
    "name": "clustermesh-apiserver-76948b4cc8-mmkh2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7535,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod62c41ba0_de7b_4849_b2e2_d9ed685b0020.slice/cri-containerd-7e843a41519e3693e9cae297dd7f9a6ea5d3bb7dd200d0bd013a97fe8f3c2e12.scope"
      }
    ],
    "ips": [
      "10.89.0.214"
    ],
    "name": "coredns-cc6ccd49c-slxgc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9107f9b2_2b67_4516_916e_0e6470895840.slice/cri-containerd-8fad1d1d55fef93fd4cecf84ec823275de8e0dcb41594b2b520333c26d61d3bf.scope"
      }
    ],
    "ips": [
      "10.89.0.31"
    ],
    "name": "coredns-cc6ccd49c-sbr5f",
    "namespace": "kube-system"
  }
]

