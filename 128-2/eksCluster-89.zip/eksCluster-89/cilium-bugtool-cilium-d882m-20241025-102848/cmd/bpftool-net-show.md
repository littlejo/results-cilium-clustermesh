xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 558
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 554
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 541
cilium_host(7) clsact/egress cil_from_host-cilium_host id 545
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 496
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 497
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 568
lxc8bc1a60d10ba(12) clsact/ingress cil_from_container-lxc8bc1a60d10ba id 522
lxcdf976f297946(14) clsact/ingress cil_from_container-lxcdf976f297946 id 585
lxcc8e18ba05dd9(18) clsact/ingress cil_from_container-lxcc8e18ba05dd9 id 643

flow_dissector:

netfilter:

