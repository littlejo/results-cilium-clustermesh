{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:42.849Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.234.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:42.849Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:46.038Z",
  "value": "id=1106  sec_id=5963165 flags=0x0000 ifindex=12  mac=4E:1B:10:AA:A4:BA nodemac=86:A6:B9:B2:78:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:49.414Z",
  "value": "id=2223  sec_id=4     flags=0x0000 ifindex=10  mac=DE:C5:11:A8:A0:92 nodemac=8A:43:09:70:AB:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:49.423Z",
  "value": "id=1106  sec_id=5963165 flags=0x0000 ifindex=12  mac=4E:1B:10:AA:A4:BA nodemac=86:A6:B9:B2:78:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:49.452Z",
  "value": "id=2223  sec_id=4     flags=0x0000 ifindex=10  mac=DE:C5:11:A8:A0:92 nodemac=8A:43:09:70:AB:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:55.467Z",
  "value": "id=49    sec_id=5963165 flags=0x0000 ifindex=14  mac=02:05:99:FC:4E:9D nodemac=B6:AF:E8:9E:09:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:37.393Z",
  "value": "id=1106  sec_id=5963165 flags=0x0000 ifindex=12  mac=4E:1B:10:AA:A4:BA nodemac=86:A6:B9:B2:78:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:37.394Z",
  "value": "id=2223  sec_id=4     flags=0x0000 ifindex=10  mac=DE:C5:11:A8:A0:92 nodemac=8A:43:09:70:AB:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:37.394Z",
  "value": "id=49    sec_id=5963165 flags=0x0000 ifindex=14  mac=02:05:99:FC:4E:9D nodemac=B6:AF:E8:9E:09:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:37.424Z",
  "value": "id=260   sec_id=5932289 flags=0x0000 ifindex=16  mac=DE:D0:31:C3:35:B1 nodemac=DA:1F:75:1F:1D:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:38.391Z",
  "value": "id=2223  sec_id=4     flags=0x0000 ifindex=10  mac=DE:C5:11:A8:A0:92 nodemac=8A:43:09:70:AB:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:38.392Z",
  "value": "id=1106  sec_id=5963165 flags=0x0000 ifindex=12  mac=4E:1B:10:AA:A4:BA nodemac=86:A6:B9:B2:78:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:38.392Z",
  "value": "id=49    sec_id=5963165 flags=0x0000 ifindex=14  mac=02:05:99:FC:4E:9D nodemac=B6:AF:E8:9E:09:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:38.392Z",
  "value": "id=260   sec_id=5932289 flags=0x0000 ifindex=16  mac=DE:D0:31:C3:35:B1 nodemac=DA:1F:75:1F:1D:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:32.330Z",
  "value": "id=3016  sec_id=5932289 flags=0x0000 ifindex=18  mac=5A:D5:9C:80:3F:89 nodemac=52:F9:47:C0:B0:0C"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.89.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:38.548Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:35.436Z",
  "value": "id=1106  sec_id=5963165 flags=0x0000 ifindex=12  mac=4E:1B:10:AA:A4:BA nodemac=86:A6:B9:B2:78:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:35.437Z",
  "value": "id=49    sec_id=5963165 flags=0x0000 ifindex=14  mac=02:05:99:FC:4E:9D nodemac=B6:AF:E8:9E:09:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:35.437Z",
  "value": "id=2223  sec_id=4     flags=0x0000 ifindex=10  mac=DE:C5:11:A8:A0:92 nodemac=8A:43:09:70:AB:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:35.444Z",
  "value": "id=3016  sec_id=5932289 flags=0x0000 ifindex=18  mac=5A:D5:9C:80:3F:89 nodemac=52:F9:47:C0:B0:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:36.433Z",
  "value": "id=1106  sec_id=5963165 flags=0x0000 ifindex=12  mac=4E:1B:10:AA:A4:BA nodemac=86:A6:B9:B2:78:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:36.433Z",
  "value": "id=3016  sec_id=5932289 flags=0x0000 ifindex=18  mac=5A:D5:9C:80:3F:89 nodemac=52:F9:47:C0:B0:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:36.433Z",
  "value": "id=49    sec_id=5963165 flags=0x0000 ifindex=14  mac=02:05:99:FC:4E:9D nodemac=B6:AF:E8:9E:09:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:36.433Z",
  "value": "id=2223  sec_id=4     flags=0x0000 ifindex=10  mac=DE:C5:11:A8:A0:92 nodemac=8A:43:09:70:AB:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:37.433Z",
  "value": "id=2223  sec_id=4     flags=0x0000 ifindex=10  mac=DE:C5:11:A8:A0:92 nodemac=8A:43:09:70:AB:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:37.433Z",
  "value": "id=3016  sec_id=5932289 flags=0x0000 ifindex=18  mac=5A:D5:9C:80:3F:89 nodemac=52:F9:47:C0:B0:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:37.434Z",
  "value": "id=49    sec_id=5963165 flags=0x0000 ifindex=14  mac=02:05:99:FC:4E:9D nodemac=B6:AF:E8:9E:09:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.89.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:37.434Z",
  "value": "id=1106  sec_id=5963165 flags=0x0000 ifindex=12  mac=4E:1B:10:AA:A4:BA nodemac=86:A6:B9:B2:78:68"
}

