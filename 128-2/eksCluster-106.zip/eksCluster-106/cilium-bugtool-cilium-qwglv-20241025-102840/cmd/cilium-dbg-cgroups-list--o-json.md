[
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a719fbd_963f_41da_82d3_b7be70b99d54.slice/cri-containerd-ccc26b7ccfec5dd2d5d69ea1a7219c3fe80735e792ba3f52f31e57d4911f5f95.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a719fbd_963f_41da_82d3_b7be70b99d54.slice/cri-containerd-6a551a0715d944add4cc5ba14217eedc50f46e918a61500cb70d24b031c0c0f3.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a719fbd_963f_41da_82d3_b7be70b99d54.slice/cri-containerd-0fadb5e5b667db7c0838b081bff90c0ef722c08dd4d51f42acd383fc96bd32e7.scope"
      }
    ],
    "ips": [
      "10.106.0.160"
    ],
    "name": "clustermesh-apiserver-cb96766c-78pcs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7619,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcd898286_fbba_427c_90e7_3d20f8122406.slice/cri-containerd-50a1d837f9793a65bc2a407df4024f130a6fd5846368e089c8906277998b7c17.scope"
      }
    ],
    "ips": [
      "10.106.0.247"
    ],
    "name": "coredns-cc6ccd49c-tmtgb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod959aaaca_00d7_47a6_b3eb_474a4ac103d9.slice/cri-containerd-01f970fd2bace014a10b6ebfa4f85254bc675577e7ef4c14afcfa32365db6a98.scope"
      }
    ],
    "ips": [
      "10.106.0.207"
    ],
    "name": "coredns-cc6ccd49c-xhjkg",
    "namespace": "kube-system"
  }
]

