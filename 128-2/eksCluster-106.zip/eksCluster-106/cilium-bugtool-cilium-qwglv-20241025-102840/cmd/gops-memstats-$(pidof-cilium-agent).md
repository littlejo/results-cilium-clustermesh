alloc: 86.00MB (90173920 bytes)
total-alloc: 1.39GB (1495899096 bytes)
sys: 206.38MB (216409428 bytes)
lookups: 0
mallocs: 48524260
frees: 47722220
heap-alloc: 86.00MB (90173920 bytes)
heap-sys: 160.07MB (167845888 bytes)
heap-idle: 39.41MB (41328640 bytes)
heap-in-use: 120.66MB (126517248 bytes)
heap-released: 3.66MB (3833856 bytes)
heap-objects: 802040
stack-in-use: 35.91MB (37650432 bytes)
stack-sys: 35.91MB (37650432 bytes)
stack-mspan-inuse: 2.02MB (2116320 bytes)
stack-mspan-sys: 2.44MB (2562240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 885.42KB (906673 bytes)
gc-sys: 5.17MB (5419360 bytes)
next-gc: when heap-alloc >= 146.26MB (153365224 bytes)
last-gc: 2024-10-25 10:28:51.708288349 +0000 UTC
gc-pause-total: 13.216081ms
gc-pause: 62918
gc-pause-end: 1729852131708288349
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.00046808483985788876
enable-gc: true
debug-gc: false
