{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:35.500Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.146.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:35.500Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.178.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:35.500Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:38.740Z",
  "value": "id=2166  sec_id=7042333 flags=0x0000 ifindex=12  mac=7A:FC:CF:EE:98:9F nodemac=02:67:3E:C2:EB:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:41.877Z",
  "value": "id=3966  sec_id=7042333 flags=0x0000 ifindex=14  mac=86:CB:11:C3:B6:09 nodemac=AA:46:5E:3A:14:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:41.881Z",
  "value": "id=1704  sec_id=4     flags=0x0000 ifindex=10  mac=FA:D2:F1:1D:EF:43 nodemac=F6:52:C8:A8:FE:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:41.948Z",
  "value": "id=2166  sec_id=7042333 flags=0x0000 ifindex=12  mac=7A:FC:CF:EE:98:9F nodemac=02:67:3E:C2:EB:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:41.980Z",
  "value": "id=3966  sec_id=7042333 flags=0x0000 ifindex=14  mac=86:CB:11:C3:B6:09 nodemac=AA:46:5E:3A:14:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:42.064Z",
  "value": "id=1704  sec_id=4     flags=0x0000 ifindex=10  mac=FA:D2:F1:1D:EF:43 nodemac=F6:52:C8:A8:FE:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.197Z",
  "value": "id=2166  sec_id=7042333 flags=0x0000 ifindex=12  mac=7A:FC:CF:EE:98:9F nodemac=02:67:3E:C2:EB:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.198Z",
  "value": "id=3966  sec_id=7042333 flags=0x0000 ifindex=14  mac=86:CB:11:C3:B6:09 nodemac=AA:46:5E:3A:14:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.198Z",
  "value": "id=1704  sec_id=4     flags=0x0000 ifindex=10  mac=FA:D2:F1:1D:EF:43 nodemac=F6:52:C8:A8:FE:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:56.232Z",
  "value": "id=2243  sec_id=7035009 flags=0x0000 ifindex=16  mac=3A:C0:D9:DD:68:4D nodemac=B6:82:CB:66:AD:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:57.198Z",
  "value": "id=2243  sec_id=7035009 flags=0x0000 ifindex=16  mac=3A:C0:D9:DD:68:4D nodemac=B6:82:CB:66:AD:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:57.199Z",
  "value": "id=3966  sec_id=7042333 flags=0x0000 ifindex=14  mac=86:CB:11:C3:B6:09 nodemac=AA:46:5E:3A:14:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:57.199Z",
  "value": "id=1704  sec_id=4     flags=0x0000 ifindex=10  mac=FA:D2:F1:1D:EF:43 nodemac=F6:52:C8:A8:FE:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:57.199Z",
  "value": "id=2166  sec_id=7042333 flags=0x0000 ifindex=12  mac=7A:FC:CF:EE:98:9F nodemac=02:67:3E:C2:EB:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:46.796Z",
  "value": "id=268   sec_id=7035009 flags=0x0000 ifindex=18  mac=62:0A:4F:75:8B:39 nodemac=EE:83:21:EB:D0:9D"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.106.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.026Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.726Z",
  "value": "id=1704  sec_id=4     flags=0x0000 ifindex=10  mac=FA:D2:F1:1D:EF:43 nodemac=F6:52:C8:A8:FE:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.726Z",
  "value": "id=268   sec_id=7035009 flags=0x0000 ifindex=18  mac=62:0A:4F:75:8B:39 nodemac=EE:83:21:EB:D0:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.727Z",
  "value": "id=2166  sec_id=7042333 flags=0x0000 ifindex=12  mac=7A:FC:CF:EE:98:9F nodemac=02:67:3E:C2:EB:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.728Z",
  "value": "id=3966  sec_id=7042333 flags=0x0000 ifindex=14  mac=86:CB:11:C3:B6:09 nodemac=AA:46:5E:3A:14:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.737Z",
  "value": "id=268   sec_id=7035009 flags=0x0000 ifindex=18  mac=62:0A:4F:75:8B:39 nodemac=EE:83:21:EB:D0:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.738Z",
  "value": "id=2166  sec_id=7042333 flags=0x0000 ifindex=12  mac=7A:FC:CF:EE:98:9F nodemac=02:67:3E:C2:EB:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.739Z",
  "value": "id=3966  sec_id=7042333 flags=0x0000 ifindex=14  mac=86:CB:11:C3:B6:09 nodemac=AA:46:5E:3A:14:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.739Z",
  "value": "id=1704  sec_id=4     flags=0x0000 ifindex=10  mac=FA:D2:F1:1D:EF:43 nodemac=F6:52:C8:A8:FE:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.735Z",
  "value": "id=2166  sec_id=7042333 flags=0x0000 ifindex=12  mac=7A:FC:CF:EE:98:9F nodemac=02:67:3E:C2:EB:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.735Z",
  "value": "id=268   sec_id=7035009 flags=0x0000 ifindex=18  mac=62:0A:4F:75:8B:39 nodemac=EE:83:21:EB:D0:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.735Z",
  "value": "id=3966  sec_id=7042333 flags=0x0000 ifindex=14  mac=86:CB:11:C3:B6:09 nodemac=AA:46:5E:3A:14:A5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.735Z",
  "value": "id=1704  sec_id=4     flags=0x0000 ifindex=10  mac=FA:D2:F1:1D:EF:43 nodemac=F6:52:C8:A8:FE:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:55.735Z",
  "value": "id=1704  sec_id=4     flags=0x0000 ifindex=10  mac=FA:D2:F1:1D:EF:43 nodemac=F6:52:C8:A8:FE:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:55.735Z",
  "value": "id=268   sec_id=7035009 flags=0x0000 ifindex=18  mac=62:0A:4F:75:8B:39 nodemac=EE:83:21:EB:D0:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:55.735Z",
  "value": "id=2166  sec_id=7042333 flags=0x0000 ifindex=12  mac=7A:FC:CF:EE:98:9F nodemac=02:67:3E:C2:EB:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:55.736Z",
  "value": "id=3966  sec_id=7042333 flags=0x0000 ifindex=14  mac=86:CB:11:C3:B6:09 nodemac=AA:46:5E:3A:14:A5"
}

