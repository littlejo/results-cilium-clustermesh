Endpoint ID: 141
Path: /sys/fs/bpf/tc/globals/cilium_policy_00141

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 268
Path: /sys/fs/bpf/tc/globals/cilium_policy_00268

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3907146   36194     0        
Allow    Ingress     1          ANY          NONE         disabled    3379389   32571     0        
Allow    Egress      0          ANY          NONE         disabled    3956186   36827     0        


Endpoint ID: 1704
Path: /sys/fs/bpf/tc/globals/cilium_policy_01704

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    433563   5541      0        
Allow    Ingress     1          ANY          NONE         disabled    10568    124       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2166
Path: /sys/fs/bpf/tc/globals/cilium_policy_02166

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    71035   816       0        
Allow    Egress      0          ANY          NONE         disabled    13630   141       0        


Endpoint ID: 3966
Path: /sys/fs/bpf/tc/globals/cilium_policy_03966

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    71299   820       0        
Allow    Egress      0          ANY          NONE         disabled    12983   133       0        


