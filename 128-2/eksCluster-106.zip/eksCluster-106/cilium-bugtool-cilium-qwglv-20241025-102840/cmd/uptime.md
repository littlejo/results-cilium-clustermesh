 10:28:42 up 13 min,  0 users,  load average: 0.12, 0.19, 0.17
