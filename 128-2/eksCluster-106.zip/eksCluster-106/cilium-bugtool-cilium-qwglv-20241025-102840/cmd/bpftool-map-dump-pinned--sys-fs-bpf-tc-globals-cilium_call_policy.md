key: 0c 01 00 00  value: 81 02 00 00
key: a8 06 00 00  value: 32 02 00 00
key: 76 08 00 00  value: 1a 02 00 00
key: 7e 0f 00 00  value: 25 02 00 00
Found 4 elements
