markdown output at /tmp/cilium-bugtool-20241025-102841.996+0000-UTC-3181508363/cmd/cilium-debuginfo-20241025-102912.695+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102841.996+0000-UTC-3181508363/cmd/cilium-debuginfo-20241025-102912.695+0000-UTC.json
