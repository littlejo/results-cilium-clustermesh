IP ADDRESS         LOCAL ENDPOINT INFO
10.106.0.247:0     id=2166  sec_id=7042333 flags=0x0000 ifindex=12  mac=7A:FC:CF:EE:98:9F nodemac=02:67:3E:C2:EB:63   
10.106.0.59:0      (localhost)                                                                                        
172.31.146.221:0   (localhost)                                                                                        
10.106.0.207:0     id=3966  sec_id=7042333 flags=0x0000 ifindex=14  mac=86:CB:11:C3:B6:09 nodemac=AA:46:5E:3A:14:A5   
10.106.0.160:0     id=268   sec_id=7035009 flags=0x0000 ifindex=18  mac=62:0A:4F:75:8B:39 nodemac=EE:83:21:EB:D0:9D   
10.106.0.5:0       id=1704  sec_id=4     flags=0x0000 ifindex=10  mac=FA:D2:F1:1D:EF:43 nodemac=F6:52:C8:A8:FE:A2     
172.31.178.197:0   (localhost)                                                                                        
