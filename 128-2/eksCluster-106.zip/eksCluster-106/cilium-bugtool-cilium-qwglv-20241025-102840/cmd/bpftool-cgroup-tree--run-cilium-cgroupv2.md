CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod959aaaca_00d7_47a6_b3eb_474a4ac103d9.slice/cri-containerd-01f970fd2bace014a10b6ebfa4f85254bc675577e7ef4c14afcfa32365db6a98.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod959aaaca_00d7_47a6_b3eb_474a4ac103d9.slice/cri-containerd-830edc487c6bab9e380ce088758a6e22e659068ad9cd664d1a302c19dc96c78c.scope
    556      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb496b492_37f2_42f3_909c_7a78aefabfbf.slice/cri-containerd-a0d77bd8ef2d9c73fdb6c9b68ec3ee777d15f6a502aea2c54e21ec14f0f2ed62.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb496b492_37f2_42f3_909c_7a78aefabfbf.slice/cri-containerd-c2d38614095b0e35daab5f7c3b355f503f9acb8934dc024401ac4abe6e5ee633.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcd898286_fbba_427c_90e7_3d20f8122406.slice/cri-containerd-cafc2343631a71dab4031840bb0eaa150b95e9754b1f8cbba6630068e9c5acbf.scope
    498      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcd898286_fbba_427c_90e7_3d20f8122406.slice/cri-containerd-50a1d837f9793a65bc2a407df4024f130a6fd5846368e089c8906277998b7c17.scope
    502      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67e6a8f1_57a5_44bc_928b_6e2bff03a994.slice/cri-containerd-da478ecebb6bf2d8162af0a35e74710e6c5d250ff3a48a8d4e260ba36e02d8f5.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67e6a8f1_57a5_44bc_928b_6e2bff03a994.slice/cri-containerd-b5b247efc094a8f55e4e35320531c6cdcb7faedad92e899aa1b011fd09bf043e.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podefd9a34a_9f0a_446d_8b93_5fda8f625318.slice/cri-containerd-3dfe5bc8a18fa9fa288300772d17de58a8f757ee7450eb449214b7b3a497b5dd.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podefd9a34a_9f0a_446d_8b93_5fda8f625318.slice/cri-containerd-2f3a0b44d3397b4b97fa043b3aa23d01c725169aa696364adaa86bf48458ba5c.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a719fbd_963f_41da_82d3_b7be70b99d54.slice/cri-containerd-6a551a0715d944add4cc5ba14217eedc50f46e918a61500cb70d24b031c0c0f3.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a719fbd_963f_41da_82d3_b7be70b99d54.slice/cri-containerd-0fadb5e5b667db7c0838b081bff90c0ef722c08dd4d51f42acd383fc96bd32e7.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a719fbd_963f_41da_82d3_b7be70b99d54.slice/cri-containerd-ccc26b7ccfec5dd2d5d69ea1a7219c3fe80735e792ba3f52f31e57d4911f5f95.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3a719fbd_963f_41da_82d3_b7be70b99d54.slice/cri-containerd-19a97df80cca2033c9e26f58b8510ed6ec2bf4d1704f3fdadfaf1a07e48731d6.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74b575d3_2ab4_4e61_86c3_b8e83b9aa49f.slice/cri-containerd-530fdadf787228b40cf2795d5d38d07a6507d8a83ef795c7ed0aec97a6653153.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74b575d3_2ab4_4e61_86c3_b8e83b9aa49f.slice/cri-containerd-634b9695cac025a3459c9607317538629955c08f3859776d45dd3b2853ea55b1.scope
    101      cgroup_device   multi                                          
