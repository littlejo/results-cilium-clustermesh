1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:dd:d6:6a:7c:77 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.178.197/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2777sec preferred_lft 2777sec
    inet6 fe80::4dd:d6ff:fe6a:7c77/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:3e:b8:d2:d0:7d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.146.221/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::43e:b8ff:fed2:d07d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:28:53:77:21:60 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f828:53ff:fe77:2160/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:10:0b:c6:1e:e1 brd ff:ff:ff:ff:ff:ff
    inet 10.106.0.59/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a810:bff:fec6:1ee1/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 9e:38:0b:56:28:7b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9c38:bff:fe56:287b/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:52:c8:a8:fe:a2 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::f452:c8ff:fea8:fea2/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc6efd36c5f74e@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:67:3e:c2:eb:63 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::67:3eff:fec2:eb63/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc97c4f0da1572@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:46:5e:3a:14:a5 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a846:5eff:fe3a:14a5/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc0fed70184aa2@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:83:21:eb:d0:9d brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::ec83:21ff:feeb:d09d/64 scope link 
       valid_lft forever preferred_lft forever
