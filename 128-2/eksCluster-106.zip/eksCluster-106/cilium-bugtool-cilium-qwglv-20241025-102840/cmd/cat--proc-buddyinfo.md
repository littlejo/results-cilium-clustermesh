Node 0, zone      DMA     72     48     11     39     13      5      3      2      3      2    165 
Node 0, zone   Normal      1      3      2      2      2      5      2      5      2      2      8 
