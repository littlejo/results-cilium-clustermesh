xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 589
ens6(5) clsact/ingress cil_from_netdev-ens6 id 592
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 577
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 572
cilium_host(7) clsact/egress cil_from_host-cilium_host id 575
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 504
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 505
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 565
lxc6efd36c5f74e(12) clsact/ingress cil_from_container-lxc6efd36c5f74e id 539
lxc97c4f0da1572(14) clsact/ingress cil_from_container-lxc97c4f0da1572 id 540
lxc0fed70184aa2(18) clsact/ingress cil_from_container-lxc0fed70184aa2 id 639

flow_dissector:

netfilter:

