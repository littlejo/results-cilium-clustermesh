top - 10:28:42 up 13 min,  0 users,  load average: 0.12, 0.19, 0.17
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 37.5 us, 40.6 sy,  0.0 ni, 15.6 id,  0.0 wa,  0.0 hi,  6.2 si,  0.0 st
MiB Mem :   3836.2 total,    775.8 free,    918.0 used,   2142.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2749.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1472496 281072  78208 S  46.7   7.2   0:24.66 cilium-+
    677 root      20   0 1240432  17044  11548 S   6.7   0.4   0:00.03 cilium-+
    415 root      20   0 1228848   5776   2928 S   0.0   0.1   0:00.26 cilium-+
    716 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    738 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    757 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
