ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.139.132:443 (active)    
                                          2 => 172.31.251.102:443 (active)    
2    10.100.212.72:443     ClusterIP      1 => 172.31.178.197:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.106.0.247:53 (active)       
                                          2 => 10.106.0.207:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.106.0.247:9153 (active)     
                                          2 => 10.106.0.207:9153 (active)     
5    10.100.251.172:2379   ClusterIP      1 => 10.106.0.160:2379 (active)     
