USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         716  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root         678  0.0  0.1 1228744 4036 ?        Ssl  10:28   0:00 /bin/gops memstats 1
root         677  0.0  0.4 1240432 16400 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         727  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         732  0.0  0.0   3852  1288 ?        R    10:28   0:00  \_ bash -c ip -d -s l
root         671  0.0  0.0 1228744 3776 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         670  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops stats 1
root         659  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops stack 1
root           1  3.3  7.0 1472496 277376 ?      Ssl  10:16   0:24 cilium-agent --config-dir=/tmp/cilium/config-map
root         415  0.0  0.1 1228848 5776 ?        Sl   10:16   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
