REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     221722    84921150   1132   bpf_host.c
Interface                 INGRESS     9575      746038     677    bpf_overlay.c
Success                   EGRESS      4699      357623     1694   bpf_host.c
Success                   EGRESS      9438      736439     53     encap.h
Success                   EGRESS      96595     13132392   1308   bpf_lxc.c
Success                   INGRESS     107148    13140917   86     l3.h
Success                   INGRESS     112673    13573238   235    trace.h
Unsupported L3 protocol   EGRESS      36        2692       1492   bpf_lxc.c
