KEY             VALUE
AgentLiveness   804566417376
UTimeOffset     3378615914062500
