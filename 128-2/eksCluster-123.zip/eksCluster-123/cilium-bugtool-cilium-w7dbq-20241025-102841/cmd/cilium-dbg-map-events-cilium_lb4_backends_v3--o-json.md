{
  "action": "update",
  "desired-action": "sync",
  "key": "1",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:03.753Z",
  "value": "ANY://172.31.168.8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "2",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:03.753Z",
  "value": "ANY://172.31.245.38"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:03.753Z",
  "value": "ANY://172.31.228.123"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:03.753Z",
  "value": "ANY://172.31.233.121"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "5",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:03.753Z",
  "value": "ANY://172.31.233.121"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "6",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:03.753Z",
  "value": "ANY://172.31.228.123"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "5",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:06.919Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:06.919Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "7",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:07.956Z",
  "value": "ANY://172.31.226.176"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:11.361Z",
  "value": "ANY://10.123.0.113"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "9",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:11.361Z",
  "value": "ANY://10.123.0.113"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "6",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:16.609Z",
  "value": "ANY://172.31.228.123"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:16.609Z",
  "value": "ANY://172.31.228.123"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:17.412Z",
  "value": "ANY://10.123.0.94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "11",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:17.412Z",
  "value": "ANY://10.123.0.94"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "6",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:21.869Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:21.869Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "12",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:27.472Z",
  "value": "ANY://10.123.0.92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "13",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:06.064Z",
  "value": "ANY://10.123.0.11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "12",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:06.145Z",
  "value": "ANY://10.123.0.92"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "12",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:06.570Z",
  "value": "\u003cnil\u003e"
}

