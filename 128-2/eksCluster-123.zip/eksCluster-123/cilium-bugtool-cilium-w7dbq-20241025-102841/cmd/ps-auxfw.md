USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         647  0.0  0.1 1228744 4040 ?        Ssl  10:28   0:00 /bin/gops memstats 1
root         642  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         635  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops stack 1
root         630  0.0  0.3 1240432 15468 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         674  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root           1  2.8  6.9 1472496 272280 ?      Ssl  10:16   0:19 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.0  0.1 1228848 6412 ?        Sl   10:17   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
