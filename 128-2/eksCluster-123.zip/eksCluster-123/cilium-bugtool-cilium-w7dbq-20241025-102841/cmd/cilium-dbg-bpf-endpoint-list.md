IP ADDRESS         LOCAL ENDPOINT INFO
10.123.0.42:0      id=444   sec_id=4     flags=0x0000 ifindex=10  mac=1E:9A:07:0F:ED:77 nodemac=36:3A:98:B3:6B:FC     
10.123.0.109:0     (localhost)                                                                                        
10.123.0.113:0     id=236   sec_id=8146521 flags=0x0000 ifindex=12  mac=52:6F:51:66:10:54 nodemac=4A:B0:01:1F:51:D4   
172.31.193.222:0   (localhost)                                                                                        
172.31.226.176:0   (localhost)                                                                                        
10.123.0.11:0      id=530   sec_id=8148649 flags=0x0000 ifindex=18  mac=F6:11:EC:CF:F3:E2 nodemac=86:C7:FE:E8:F3:D4   
10.123.0.94:0      id=2597  sec_id=8146521 flags=0x0000 ifindex=14  mac=2A:57:57:2C:C4:BD nodemac=BE:15:85:B6:9F:3D   
