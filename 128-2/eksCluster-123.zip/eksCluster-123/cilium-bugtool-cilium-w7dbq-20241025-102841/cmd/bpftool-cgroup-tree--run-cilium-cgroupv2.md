CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2c8fed6f_5615_4f53_9cca_db4402943080.slice/cri-containerd-4df3f44261a5b2127a19502d9f9d2dc4a1449a675c68eed1cb61b2ea394ae78c.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2c8fed6f_5615_4f53_9cca_db4402943080.slice/cri-containerd-c647dbb7e28651d7512ea4003a60485442565194eb6690475f5ecc2fddd445a9.scope
    553      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf2630a5_426f_4571_a5e1_5369885c710f.slice/cri-containerd-406794a013e5dbffaba88e5d2bc3585e4ee810ec0725620c77d6d4ab936375ab.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf2630a5_426f_4571_a5e1_5369885c710f.slice/cri-containerd-bb579ecd251df559af5d04a7eb40b9a35b4b29798e828a0216a24ee2ae023b7b.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4327da12_8c5d_431c_9d1d_53af2ce55982.slice/cri-containerd-8e0add7894a99e2a0d3160a3fb88d94a58b8809be1fbced6462fa260bc5b3edb.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4327da12_8c5d_431c_9d1d_53af2ce55982.slice/cri-containerd-793eb58a43ae28839480dc08afba404008c42149686bcb24c9f81fa0aeb1f8b0.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2d922f52_061c_4607_9d27_9919c23261fe.slice/cri-containerd-8caf7f50aae6dbb52fbba8faec42f5eca975e67763a50bac8901fed456928be4.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2d922f52_061c_4607_9d27_9919c23261fe.slice/cri-containerd-9f071f879ca1393eba0f9ec0a2c858535268bc45ad7cd3ee072796378c143c36.scope
    576      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e472705_8f61_42a8_9d8f_1a003c95acaa.slice/cri-containerd-ab41b08efff6ea36a4d6e692be35894f39e265d3076460cd6eb50f265121c5ce.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e472705_8f61_42a8_9d8f_1a003c95acaa.slice/cri-containerd-100a200452e70ca3ee3db65213a54c493f45c9703552b36f8a271bbc270bb213.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e472705_8f61_42a8_9d8f_1a003c95acaa.slice/cri-containerd-df8132f2570d1570d0743637ece866f2f112bfcac772894211f8c5dad48ce0ca.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e472705_8f61_42a8_9d8f_1a003c95acaa.slice/cri-containerd-5f9a4bc668bad19bfc6aaeb95398abda98d348be4eb9b8023323c112d7172d29.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod885a99ff_d8d0_4e0e_ab65_62e54e03b911.slice/cri-containerd-c10012944e300b2727fbe661d494d57b6dceaa31305882c82c6e4ba3a4033fdb.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod885a99ff_d8d0_4e0e_ab65_62e54e03b911.slice/cri-containerd-2c1e564543fdc668e52f7afde25e395dc0ebdca6ff3fb7602be2f4cb3305774a.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcbd8486b_dd84_4b85_b030_54528f8d548f.slice/cri-containerd-24146a84f044ca02269253417915d8c1fe8daf54abbe7890a0a8b223f806a12b.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcbd8486b_dd84_4b85_b030_54528f8d548f.slice/cri-containerd-b4adaa1f4e4a7bc045ba0bdd70efe45ab647c16a47c1beac113d670f204c8d98.scope
    94       cgroup_device   multi                                          
