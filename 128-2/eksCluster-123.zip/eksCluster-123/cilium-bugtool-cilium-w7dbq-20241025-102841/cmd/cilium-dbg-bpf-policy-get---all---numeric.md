Endpoint ID: 236
Path: /sys/fs/bpf/tc/globals/cilium_policy_00236

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    68278   785       0        
Allow    Egress      0          ANY          NONE         disabled    12650   129       0        


Endpoint ID: 444
Path: /sys/fs/bpf/tc/globals/cilium_policy_00444

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    431922   5506      0        
Allow    Ingress     1          ANY          NONE         disabled    10460    122       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 530
Path: /sys/fs/bpf/tc/globals/cilium_policy_00530

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3880014   35702     0        
Allow    Ingress     1          ANY          NONE         disabled    2684601   26700     0        
Allow    Egress      0          ANY          NONE         disabled    3704184   34510     0        


Endpoint ID: 2597
Path: /sys/fs/bpf/tc/globals/cilium_policy_02597

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    67442   778       0        
Allow    Egress      0          ANY          NONE         disabled    12828   130       0        


Endpoint ID: 3398
Path: /sys/fs/bpf/tc/globals/cilium_policy_03398

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


