filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc81ce6337c1e9 direct-action not_in_hw id 558 tag b2167426e2525759 jited 
