alloc: 94.66MB (99257216 bytes)
total-alloc: 1.29GB (1388824904 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 47160298
frees: 46226399
heap-alloc: 94.66MB (99257216 bytes)
heap-sys: 165.26MB (173285376 bytes)
heap-idle: 48.99MB (51372032 bytes)
heap-in-use: 116.27MB (121913344 bytes)
heap-released: 2.80MB (2940928 bytes)
heap-objects: 933899
stack-in-use: 34.72MB (36405248 bytes)
stack-sys: 34.72MB (36405248 bytes)
stack-mspan-inuse: 1.93MB (2023200 bytes)
stack-mspan-sys: 2.43MB (2545920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 972.97KB (996321 bytes)
gc-sys: 5.12MB (5365848 bytes)
next-gc: when heap-alloc >= 146.04MB (153137848 bytes)
last-gc: 2024-10-25 10:28:50.445527288 +0000 UTC
gc-pause-total: 13.887593ms
gc-pause: 80769
gc-pause-end: 1729852130445527288
num-gc: 71
num-forced-gc: 0
gc-cpu-fraction: 0.00038474489929797275
enable-gc: true
debug-gc: false
