top - 10:28:42 up 12 min,  0 users,  load average: 0.09, 0.20, 0.17
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 41.4 us, 41.4 sy,  0.0 ni, 13.8 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   3836.2 total,    803.8 free,    890.7 used,   2141.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2776.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 278080  78272 S  46.7   7.1   0:20.03 cilium-+
    396 root      20   0 1228848   6412   3840 S   0.0   0.2   0:00.26 cilium-+
    630 root      20   0 1240432  15468  10576 S   0.0   0.4   0:00.03 cilium-+
    685 root      20   0    6576   2412   2088 R   0.0   0.1   0:00.00 top
    694 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    714 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
