[
  {
    "containers": [
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e472705_8f61_42a8_9d8f_1a003c95acaa.slice/cri-containerd-ab41b08efff6ea36a4d6e692be35894f39e265d3076460cd6eb50f265121c5ce.scope"
      },
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e472705_8f61_42a8_9d8f_1a003c95acaa.slice/cri-containerd-df8132f2570d1570d0743637ece866f2f112bfcac772894211f8c5dad48ce0ca.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e472705_8f61_42a8_9d8f_1a003c95acaa.slice/cri-containerd-100a200452e70ca3ee3db65213a54c493f45c9703552b36f8a271bbc270bb213.scope"
      }
    ],
    "ips": [
      "10.123.0.11"
    ],
    "name": "clustermesh-apiserver-6b8b6d6579-75zt6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7535,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2c8fed6f_5615_4f53_9cca_db4402943080.slice/cri-containerd-c647dbb7e28651d7512ea4003a60485442565194eb6690475f5ecc2fddd445a9.scope"
      }
    ],
    "ips": [
      "10.123.0.113"
    ],
    "name": "coredns-cc6ccd49c-dsk56",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8039,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2d922f52_061c_4607_9d27_9919c23261fe.slice/cri-containerd-9f071f879ca1393eba0f9ec0a2c858535268bc45ad7cd3ee072796378c143c36.scope"
      }
    ],
    "ips": [
      "10.123.0.94"
    ],
    "name": "coredns-cc6ccd49c-w7567",
    "namespace": "kube-system"
  }
]

