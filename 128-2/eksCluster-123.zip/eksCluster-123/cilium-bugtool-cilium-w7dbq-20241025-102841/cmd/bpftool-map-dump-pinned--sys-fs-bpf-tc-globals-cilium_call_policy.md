key: ec 00 00 00  value: 0d 02 00 00
key: bc 01 00 00  value: 21 02 00 00
key: 12 02 00 00  value: 68 02 00 00
key: 25 0a 00 00  value: 31 02 00 00
Found 4 elements
