Total: 528
TCP:   1057 (estab 295, closed 743, orphaned 0, timewait 294)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  314       303       11       
INET	  324       309       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:37877      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:24740 sk:256 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.226.176%ens5:68         0.0.0.0:*    uid:192 ino:15764 sk:257 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:24893 sk:258 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15591 sk:259 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:24892 sk:25a cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15592 sk:25b cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::847:48ff:fe2e:9749]%ens5:546           [::]:*    uid:192 ino:15754 sk:25c cgroup:unreachable:c4e v6only:1 <->                   
