ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.168.8:443 (active)      
                                          2 => 172.31.245.38:443 (active)     
2    10.100.79.147:443     ClusterIP      1 => 172.31.226.176:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.123.0.113:9153 (active)     
                                          2 => 10.123.0.94:9153 (active)      
4    10.100.0.10:53        ClusterIP      1 => 10.123.0.113:53 (active)       
                                          2 => 10.123.0.94:53 (active)        
5    10.100.253.141:2379   ClusterIP      1 => 10.123.0.11:2379 (active)      
