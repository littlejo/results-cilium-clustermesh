{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:05.993Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.193.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:05.993Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.226.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:05.993Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.380Z",
  "value": "id=444   sec_id=4     flags=0x0000 ifindex=10  mac=1E:9A:07:0F:ED:77 nodemac=36:3A:98:B3:6B:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.381Z",
  "value": "id=236   sec_id=8146521 flags=0x0000 ifindex=12  mac=52:6F:51:66:10:54 nodemac=4A:B0:01:1F:51:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.391Z",
  "value": "id=236   sec_id=8146521 flags=0x0000 ifindex=12  mac=52:6F:51:66:10:54 nodemac=4A:B0:01:1F:51:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:10.418Z",
  "value": "id=444   sec_id=4     flags=0x0000 ifindex=10  mac=1E:9A:07:0F:ED:77 nodemac=36:3A:98:B3:6B:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:17.096Z",
  "value": "id=2597  sec_id=8146521 flags=0x0000 ifindex=14  mac=2A:57:57:2C:C4:BD nodemac=BE:15:85:B6:9F:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:19.660Z",
  "value": "id=444   sec_id=4     flags=0x0000 ifindex=10  mac=1E:9A:07:0F:ED:77 nodemac=36:3A:98:B3:6B:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:19.660Z",
  "value": "id=236   sec_id=8146521 flags=0x0000 ifindex=12  mac=52:6F:51:66:10:54 nodemac=4A:B0:01:1F:51:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:19.660Z",
  "value": "id=2597  sec_id=8146521 flags=0x0000 ifindex=14  mac=2A:57:57:2C:C4:BD nodemac=BE:15:85:B6:9F:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:19.689Z",
  "value": "id=32    sec_id=8148649 flags=0x0000 ifindex=16  mac=0A:F9:5A:5A:21:8F nodemac=F2:B3:D0:29:AB:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:19.690Z",
  "value": "id=32    sec_id=8148649 flags=0x0000 ifindex=16  mac=0A:F9:5A:5A:21:8F nodemac=F2:B3:D0:29:AB:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:20.660Z",
  "value": "id=444   sec_id=4     flags=0x0000 ifindex=10  mac=1E:9A:07:0F:ED:77 nodemac=36:3A:98:B3:6B:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:20.661Z",
  "value": "id=236   sec_id=8146521 flags=0x0000 ifindex=12  mac=52:6F:51:66:10:54 nodemac=4A:B0:01:1F:51:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:20.661Z",
  "value": "id=32    sec_id=8148649 flags=0x0000 ifindex=16  mac=0A:F9:5A:5A:21:8F nodemac=F2:B3:D0:29:AB:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:20.661Z",
  "value": "id=2597  sec_id=8146521 flags=0x0000 ifindex=14  mac=2A:57:57:2C:C4:BD nodemac=BE:15:85:B6:9F:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:00.593Z",
  "value": "id=530   sec_id=8148649 flags=0x0000 ifindex=18  mac=F6:11:EC:CF:F3:E2 nodemac=86:C7:FE:E8:F3:D4"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.123.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:06.478Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:55.455Z",
  "value": "id=2597  sec_id=8146521 flags=0x0000 ifindex=14  mac=2A:57:57:2C:C4:BD nodemac=BE:15:85:B6:9F:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:55.455Z",
  "value": "id=530   sec_id=8148649 flags=0x0000 ifindex=18  mac=F6:11:EC:CF:F3:E2 nodemac=86:C7:FE:E8:F3:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:55.458Z",
  "value": "id=444   sec_id=4     flags=0x0000 ifindex=10  mac=1E:9A:07:0F:ED:77 nodemac=36:3A:98:B3:6B:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:55.459Z",
  "value": "id=236   sec_id=8146521 flags=0x0000 ifindex=12  mac=52:6F:51:66:10:54 nodemac=4A:B0:01:1F:51:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:56.456Z",
  "value": "id=444   sec_id=4     flags=0x0000 ifindex=10  mac=1E:9A:07:0F:ED:77 nodemac=36:3A:98:B3:6B:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:56.456Z",
  "value": "id=236   sec_id=8146521 flags=0x0000 ifindex=12  mac=52:6F:51:66:10:54 nodemac=4A:B0:01:1F:51:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:56.457Z",
  "value": "id=530   sec_id=8148649 flags=0x0000 ifindex=18  mac=F6:11:EC:CF:F3:E2 nodemac=86:C7:FE:E8:F3:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:56.457Z",
  "value": "id=2597  sec_id=8146521 flags=0x0000 ifindex=14  mac=2A:57:57:2C:C4:BD nodemac=BE:15:85:B6:9F:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:57.456Z",
  "value": "id=444   sec_id=4     flags=0x0000 ifindex=10  mac=1E:9A:07:0F:ED:77 nodemac=36:3A:98:B3:6B:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:57.457Z",
  "value": "id=236   sec_id=8146521 flags=0x0000 ifindex=12  mac=52:6F:51:66:10:54 nodemac=4A:B0:01:1F:51:D4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:57.457Z",
  "value": "id=2597  sec_id=8146521 flags=0x0000 ifindex=14  mac=2A:57:57:2C:C4:BD nodemac=BE:15:85:B6:9F:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.123.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:57.457Z",
  "value": "id=530   sec_id=8148649 flags=0x0000 ifindex=18  mac=F6:11:EC:CF:F3:E2 nodemac=86:C7:FE:E8:F3:D4"
}

