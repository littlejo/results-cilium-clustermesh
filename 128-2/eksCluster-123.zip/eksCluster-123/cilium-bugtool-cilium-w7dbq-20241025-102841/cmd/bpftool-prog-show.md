32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:15:50+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:50+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:50+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:51+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:51+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:15:51+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:15:52+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:15:52+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:52+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:15:52+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:15:52+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:15:52+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:15:55+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:16:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:17:08+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
482: sched_cls  name tail_handle_ipv4  tag 30070724f452c728  gpl
	loaded_at 2024-10-25T10:17:08+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
483: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:17:08+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
484: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:17:08+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 127
486: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,101
	btf_id 130
488: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 132
489: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,101
	btf_id 133
490: sched_cls  name tail_handle_ipv4_from_host  tag 5108ac89b6aaa503  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,101
	btf_id 134
491: sched_cls  name __send_drop_notify  tag 0cec2a7fdfbc2b47  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 135
495: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 140
496: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,103
	btf_id 141
497: sched_cls  name tail_handle_ipv4_from_host  tag 5108ac89b6aaa503  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,103
	btf_id 142
498: sched_cls  name __send_drop_notify  tag 0cec2a7fdfbc2b47  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 143
499: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,105,75
	btf_id 145
503: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,105
	btf_id 149
504: sched_cls  name tail_handle_ipv4_from_host  tag 5108ac89b6aaa503  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,105
	btf_id 150
505: sched_cls  name __send_drop_notify  tag 0cec2a7fdfbc2b47  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 151
506: sched_cls  name __send_drop_notify  tag 0cec2a7fdfbc2b47  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 153
507: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,108,75
	btf_id 154
511: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,108
	btf_id 158
512: sched_cls  name tail_handle_ipv4_from_host  tag 5108ac89b6aaa503  gpl
	loaded_at 2024-10-25T10:17:09+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,108
	btf_id 159
513: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 163
517: sched_cls  name tail_handle_ipv4_cont  tag a18a7bce037a0c75  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 164
519: sched_cls  name tail_ipv4_to_endpoint  tag 0e4f7292200e08dd  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,113,40,37,38
	btf_id 168
523: sched_cls  name tail_ipv4_ct_egress  tag f58838743a8f215a  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 171
525: sched_cls  name handle_policy  tag 0ab813c9f16d0ac6  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 174
529: sched_cls  name tail_handle_ipv4  tag 201936d9ede0c941  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 176
530: sched_cls  name cil_from_container  tag 26bfce8ec1b9ee8c  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 180
532: sched_cls  name tail_ipv4_ct_ingress  tag fc438fc1ea9d2124  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 181
533: sched_cls  name __send_drop_notify  tag e976cc88d08b3bbc  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 182
534: sched_cls  name tail_handle_arp  tag c96feb73e56bcbf7  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 183
536: sched_cls  name tail_handle_arp  tag a034d8afdd6f1123  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 186
537: sched_cls  name __send_drop_notify  tag 8cb9f2528317ed93  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 187
538: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 188
539: sched_cls  name tail_handle_ipv4  tag 90dde601c56ff528  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 189
540: sched_cls  name tail_handle_ipv4_cont  tag 6b70d11c2b4ff243  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,114,41,100,82,83,39,76,74,77,115,40,37,38,81
	btf_id 190
541: sched_cls  name tail_ipv4_to_endpoint  tag 9e03d50ec83c3ec1  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,114,41,82,83,80,100,39,115,40,37,38
	btf_id 191
542: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,115,82,83,114,84
	btf_id 192
543: sched_cls  name cil_from_container  tag bf630910b300464f  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 115,76
	btf_id 193
544: sched_cls  name tail_ipv4_ct_ingress  tag 955f3ef6e42c51c9  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,115,82,83,114,84
	btf_id 194
545: sched_cls  name handle_policy  tag 905b52228d3a8ef1  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,115,82,83,114,41,80,100,39,84,75,40,37,38
	btf_id 195
546: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
549: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
550: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
553: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
558: sched_cls  name cil_from_container  tag b2167426e2525759  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 120,76
	btf_id 197
559: sched_cls  name tail_handle_ipv4_cont  tag d6fa8e9e0d3034c1  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,121,41,119,82,83,39,76,74,77,120,40,37,38,81
	btf_id 198
560: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,120
	btf_id 199
561: sched_cls  name handle_policy  tag 46950d5cdc3b72a8  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,120,82,83,121,41,80,119,39,84,75,40,37,38
	btf_id 200
562: sched_cls  name tail_ipv4_ct_egress  tag f58838743a8f215a  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,120,82,83,121,84
	btf_id 201
563: sched_cls  name tail_handle_arp  tag ca23b1e288d7e26a  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,120
	btf_id 202
565: sched_cls  name tail_ipv4_to_endpoint  tag a33b2f271169c58b  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,121,41,82,83,80,119,39,120,40,37,38
	btf_id 204
566: sched_cls  name __send_drop_notify  tag 509c1de2251dd8fa  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 205
567: sched_cls  name tail_ipv4_ct_ingress  tag 77990fa20443dc21  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,120,82,83,121,84
	btf_id 206
568: sched_cls  name tail_handle_ipv4  tag a59808279ad1f007  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,120
	btf_id 207
569: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
572: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
573: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
576: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
612: sched_cls  name tail_handle_arp  tag 35ce4c4097d76e78  gpl
	loaded_at 2024-10-25T10:23:00+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,135
	btf_id 221
613: sched_cls  name __send_drop_notify  tag aee5600d16aad7e3  gpl
	loaded_at 2024-10-25T10:23:00+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 222
614: sched_cls  name tail_handle_ipv4_cont  tag 6f9bb174523774af  gpl
	loaded_at 2024-10-25T10:23:00+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,134,41,133,82,83,39,76,74,77,135,40,37,38,81
	btf_id 223
615: sched_cls  name tail_ipv4_ct_ingress  tag fe0b2eb2b0eca680  gpl
	loaded_at 2024-10-25T10:23:00+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 224
616: sched_cls  name handle_policy  tag d614f70149c2da3f  gpl
	loaded_at 2024-10-25T10:23:00+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,135,82,83,134,41,80,133,39,84,75,40,37,38
	btf_id 225
617: sched_cls  name tail_ipv4_ct_egress  tag 5a7be0a5e6f17b64  gpl
	loaded_at 2024-10-25T10:23:00+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 226
618: sched_cls  name tail_ipv4_to_endpoint  tag a4af71e4e8b7b895  gpl
	loaded_at 2024-10-25T10:23:00+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,134,41,82,83,80,133,39,135,40,37,38
	btf_id 227
619: sched_cls  name tail_handle_ipv4  tag 0a67ef2cc4e975e0  gpl
	loaded_at 2024-10-25T10:23:00+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,135
	btf_id 228
620: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:23:00+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,135
	btf_id 229
622: sched_cls  name cil_from_container  tag 39c406d5504a7f06  gpl
	loaded_at 2024-10-25T10:23:00+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 135,76
	btf_id 231
623: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
626: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
639: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
642: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
643: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
646: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
647: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
650: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
