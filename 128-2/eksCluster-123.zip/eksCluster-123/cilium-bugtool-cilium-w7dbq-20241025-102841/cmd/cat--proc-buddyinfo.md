Node 0, zone      DMA     81     51      3      1      2      8     26      9      9      4    168 
Node 0, zone   Normal    121     12      7      0      1      2      0      2      2      1      9 
