key: 18 00 00 00  value: 4a 02 00 00
key: 9b 01 00 00  value: 02 02 00 00
key: 93 08 00 00  value: 10 02 00 00
key: c2 0f 00 00  value: f3 01 00 00
Found 4 elements
