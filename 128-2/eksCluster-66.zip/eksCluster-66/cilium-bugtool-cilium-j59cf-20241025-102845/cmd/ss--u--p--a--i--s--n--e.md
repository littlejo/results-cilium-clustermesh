Total: 548
TCP:   1067 (estab 302, closed 746, orphaned 0, timewait 282)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  321       312       9        
INET	  331       318       13       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                            127.0.0.1:34275      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=41)) ino:22637 sk:1001 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.170.17%ens5:68         0.0.0.0:*    uid:192 ino:14319 sk:1002 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:23720 sk:1003 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15431 sk:1004 cgroup:unreachable:f0c <->                                    
UNCONN 0      0      [fe80::42d:b9ff:fe84:1ccb]%ens5:546           [::]:*    uid:192 ino:14310 sk:1005 cgroup:unreachable:c4e v6only:1 <->                   
UNCONN 0      0                                 [::]:8472          [::]:*    ino:23719 sk:1006 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15432 sk:1007 cgroup:unreachable:f0c v6only:1 <->                           
