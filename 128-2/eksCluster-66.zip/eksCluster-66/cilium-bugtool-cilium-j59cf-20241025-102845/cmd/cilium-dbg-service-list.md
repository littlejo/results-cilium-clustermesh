ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.153.80:443 (active)    
                                         2 => 172.31.218.229:443 (active)   
2    10.100.158.9:443     ClusterIP      1 => 172.31.170.17:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.66.0.209:53 (active)       
                                         2 => 10.66.0.166:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.66.0.209:9153 (active)     
                                         2 => 10.66.0.166:9153 (active)     
5    10.100.237.37:2379   ClusterIP      1 => 10.66.0.242:2379 (active)     
