REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     10096     790728      677    bpf_overlay.c
Interface                 INGRESS     220494    100431357   1132   bpf_host.c
Success                   EGRESS      10260     803794      53     encap.h
Success                   EGRESS      5141      396488      1694   bpf_host.c
Success                   EGRESS      91043     12226444    1308   bpf_lxc.c
Success                   INGRESS     102731    12529233    86     l3.h
Success                   INGRESS     108335    12967379    235    trace.h
Unsupported L3 protocol   EGRESS      46        3524        1492   bpf_lxc.c
