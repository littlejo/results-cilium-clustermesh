Endpoint ID: 24
Path: /sys/fs/bpf/tc/globals/cilium_policy_00024

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3890785   36429     0        
Allow    Ingress     1          ANY          NONE         disabled    3088628   31202     0        
Allow    Egress      0          ANY          NONE         disabled    4372565   40541     0        


Endpoint ID: 283
Path: /sys/fs/bpf/tc/globals/cilium_policy_00283

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 411
Path: /sys/fs/bpf/tc/globals/cilium_policy_00411

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    86097   993       0        
Allow    Egress      0          ANY          NONE         disabled    13570   141       0        


Endpoint ID: 2195
Path: /sys/fs/bpf/tc/globals/cilium_policy_02195

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    85965   991       0        
Allow    Egress      0          ANY          NONE         disabled    13770   144       0        


Endpoint ID: 4034
Path: /sys/fs/bpf/tc/globals/cilium_policy_04034

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    439959   5627      0        
Allow    Ingress     1          ANY          NONE         disabled    12470    144       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


