fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxce09bae52c183 proto kernel metric 256 pref medium
fe80::/64 dev lxc45944f524c34 proto kernel metric 256 pref medium
fe80::/64 dev lxc1185b997b01f proto kernel metric 256 pref medium
