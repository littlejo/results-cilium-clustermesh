CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode018adb4_22d0_4fcb_b17a_18f818309303.slice/cri-containerd-934e5e49b85a16db530d9211e7560d3daab55a0d6ca8da25bb0944411ef43d64.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode018adb4_22d0_4fcb_b17a_18f818309303.slice/cri-containerd-da2d6131bcffa7e428429f766d22c6c730bfc5be060105b0d3883d263dff7734.scope
    117      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67c958a4_3c6d_4f16_a889_3d34b4945cb3.slice/cri-containerd-484ba5e7bec07881289fa294e2fbb16918b1fa21ae96bbb0e6dd1ea4cdf93094.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67c958a4_3c6d_4f16_a889_3d34b4945cb3.slice/cri-containerd-ee69f38d2806e685cc442c237fc8cee28c16b2b16ce14c8dbeae4028a43f690f.scope
    542      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podde087062_10b3_4170_baf5_ba4fddd335d7.slice/cri-containerd-09300c40fafbafe5401bcdc43d8494eb717e7552fa8f3960864b30853a19ed27.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podde087062_10b3_4170_baf5_ba4fddd335d7.slice/cri-containerd-f5ea63899c534c412b623bbf3c021f210a83d91b22a9a59925b654226bdb8c38.scope
    519      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podded24f02_ad4b_464c_9f5d_478331861e63.slice/cri-containerd-295da433888f1f97b87c8c3e5cb3709a5247b4ed430e829b1ad9869fd99139bf.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podded24f02_ad4b_464c_9f5d_478331861e63.slice/cri-containerd-27a8eee048cf540884fb14234458c02a4a672ae66bd747141e179b17a532bd84.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod192a7a22_0a0b_47f5_b4a4_275f17f817d7.slice/cri-containerd-3aa0d4495000faafd2c6c23d6f6cfbd48125bb386e332e682d73c7b244be1276.scope
    71       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod192a7a22_0a0b_47f5_b4a4_275f17f817d7.slice/cri-containerd-27cdb8c0b4dc09f07c93eb99c422da7a8a93ca9431baf342140ff9c084c9f7cc.scope
    86       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod044e2a10_5a95_4de3_84b2_42e1b19026e7.slice/cri-containerd-e7b517b90bfba86fa8de39593a15ada0e4f0510275c80dda1b201baf316208ae.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod044e2a10_5a95_4de3_84b2_42e1b19026e7.slice/cri-containerd-d02ab926013764bee8cfc41788dc7a3f1a058ef3b7a57a311d8fb8ef1ddc309b.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeca62fa1_76a2_4519_8dd9_c3c170f09781.slice/cri-containerd-a18d2e60fe0d68128f912ce1f0b3c3cfed2c50a0bd8a3561ff589ccab4f907cf.scope
    620      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeca62fa1_76a2_4519_8dd9_c3c170f09781.slice/cri-containerd-a1a8bc03dba3ea5ef209ccb9ce48ee13bccbbc30110fc840c2ec2c62df0dbfb4.scope
    616      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeca62fa1_76a2_4519_8dd9_c3c170f09781.slice/cri-containerd-3c4adaed3b5a38fcda2845019fe79b9851a77af8c74ec74b069f0df67c53b914.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeca62fa1_76a2_4519_8dd9_c3c170f09781.slice/cri-containerd-655ba49a48efd4aa244b270f1cb374fc27d1b109c890a934458bbae3d4521224.scope
    612      cgroup_device   multi                                          
