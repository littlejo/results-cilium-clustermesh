# Cilium debug information

#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium environment keys

```
hubble-export-file-compress:false
tofqdns-min-ttl:0
tofqdns-proxy-port:0
enable-wireguard:false
enable-hubble-recorder-api:true
hubble-export-file-path:
hubble-export-fieldmask:
bpf-policy-map-full-reconciliation-interval:15m0s
enable-bgp-control-plane:false
bpf-lb-dsr-dispatch:opt
hubble-redact-http-headers-allow:
identity-gc-interval:15m0s
enable-svc-source-range-check:true
proxy-max-requests-per-connection:0
version:false
metrics:
bpf-policy-map-max:16384
log-system-load:false
container-ip-local-reserved-ports:auto
identity-allocation-mode:crd
cmdref:
conntrack-gc-max-interval:0s
disable-envoy-version-check:false
enable-ipsec-key-watcher:true
k8s-service-proxy-name:
enable-masquerade-to-route-source:false
ipam-multi-pool-pre-allocation:
bpf-ct-timeout-regular-tcp:2h13m20s
bpf-lb-source-range-map-max:0
max-connected-clusters:255
bpf-lb-service-map-max:0
bpf-neigh-global-max:524288
tofqdns-proxy-response-max-delay:100ms
fixed-identity-mapping:
egress-gateway-reconciliation-trigger-interval:1s
proxy-portrange-max:20000
encryption-strict-mode-allow-remote-node-identities:false
ip-masq-agent-config-path:/etc/config/ip-masq-agent
envoy-base-id:0
bpf-events-trace-enabled:true
direct-routing-skip-unreachable:false
mesh-auth-mutual-listener-port:0
enable-local-redirect-policy:false
enable-nat46x64-gateway:false
mesh-auth-enabled:true
proxy-connect-timeout:2
mtu:0
enable-local-node-route:true
hubble-flowlogs-config-path:
enable-unreachable-routes:false
policy-cidr-match-mode:
enable-k8s:true
k8s-require-ipv4-pod-cidr:false
hubble-export-file-max-size-mb:10
http-retry-timeout:0
bpf-ct-global-any-max:262144
gateway-api-secrets-namespace:
enable-endpoint-health-checking:true
log-opt:
vtep-mask:
ipv4-service-loopback-address:169.254.42.1
enable-k8s-networkpolicy:true
enable-high-scale-ipcache:false
hubble-skip-unknown-cgroup-ids:true
bpf-lb-external-clusterip:false
enable-identity-mark:true
config:
ingress-secrets-namespace:
dnsproxy-lock-timeout:500ms
dnsproxy-concurrency-processing-grace-period:0s
enable-l7-proxy:true
proxy-gid:1337
kvstore:
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
enable-health-check-nodeport:true
kvstore-connectivity-timeout:2m0s
bpf-lb-algorithm:random
identity-change-grace-period:5s
identity-heartbeat-timeout:30m0s
wireguard-persistent-keepalive:0s
http-max-grpc-timeout:0
clustermesh-enable-endpoint-sync:false
enable-vtep:false
kube-proxy-replacement-healthz-bind-address:
dns-policy-unload-on-shutdown:false
enable-well-known-identities:false
cni-chaining-mode:none
set-cilium-node-taints:true
bpf-events-drop-enabled:true
bpf-lb-sock:false
k8s-namespace:kube-system
proxy-portrange-min:10000
preallocate-bpf-maps:false
use-full-tls-context:false
iptables-random-fully:false
hubble-export-denylist:
enable-stale-cilium-endpoint-cleanup:true
enable-health-check-loadbalancer-ip:false
enable-icmp-rules:true
bpf-events-policy-verdict-enabled:true
enable-external-ips:false
bpf-lb-rss-ipv6-src-cidr:
mesh-auth-rotated-identities-queue-size:1024
agent-health-port:9879
egress-multi-home-ip-rule-compat:false
ipv4-pod-subnets:
encrypt-node:false
ipam-default-ip-pool:default
operator-api-serve-addr:127.0.0.1:9234
enable-endpoint-routes:false
enable-bandwidth-manager:false
operator-prometheus-serve-addr::9963
hubble-redact-http-userinfo:true
bpf-lb-dsr-l4-xlate:frontend
enable-service-topology:false
trace-payloadlen:128
exclude-local-address:
ipsec-key-rotation-duration:5m0s
bpf-lb-service-backend-map-max:0
enable-bpf-clock-probe:false
remove-cilium-node-taints:true
dnsproxy-concurrency-limit:0
tunnel-port:0
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
hubble-export-allowlist:
mesh-auth-signal-backoff-duration:1s
enable-ipip-termination:false
enable-ipsec:false
enable-k8s-endpoint-slice:true
hubble-drop-events-reasons:auth_required,policy_denied
allocator-list-timeout:3m0s
mesh-auth-mutual-connect-timeout:5s
exclude-node-label-patterns:
bpf-auth-map-max:524288
bpf-lb-maglev-map-max:0
cgroup-root:/run/cilium/cgroupv2
enable-mke:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
bpf-nat-global-max:524288
node-port-acceleration:disabled
vtep-cidr:
tofqdns-idle-connection-grace-period:0s
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
enable-ip-masq-agent:false
set-cilium-is-up-condition:true
kube-proxy-replacement:false
hubble-recorder-storage-path:/var/run/cilium/pcaps
devices:
conntrack-gc-interval:0s
bpf-ct-timeout-regular-tcp-fin:10s
envoy-config-timeout:2m0s
enable-recorder:false
monitor-aggregation-interval:5s
enable-srv6:false
enable-cilium-endpoint-slice:false
bpf-ct-timeout-service-tcp-grace:1m0s
ipv6-node:auto
socket-path:/var/run/cilium/cilium.sock
ipv6-pod-subnets:
disable-external-ip-mitigation:false
http-retry-count:3
hubble-redact-kafka-apikey:false
k8s-client-connection-timeout:30s
enable-bpf-masquerade:false
k8s-client-qps:10
dnsproxy-socket-linger-timeout:10
mesh-auth-queue-size:1024
pprof-port:6060
enable-ipv4-masquerade:true
enable-wireguard-userspace-fallback:false
direct-routing-device:
nat-map-stats-interval:30s
multicast-enabled:false
bpf-root:/sys/fs/bpf
enable-ipv4-fragment-tracking:true
ipam-cilium-node-update-rate:15s
dnsproxy-enable-transparent-mode:true
enable-policy:default
bpf-lb-maglev-table-size:16381
k8s-heartbeat-timeout:30s
policy-queue-size:100
node-port-mode:snat
envoy-log:
ipv6-service-range:auto
l2-announcements-retry-period:2s
k8s-client-burst:20
bpf-lb-sock-hostns-only:false
k8s-sync-timeout:3m0s
pprof-address:localhost
bpf-ct-timeout-service-any:1m0s
enable-tracing:false
enable-route-mtu-for-cni-chaining:false
bpf-lb-sock-terminate-pod-connections:false
k8s-client-connection-keep-alive:30s
kvstore-opt:
clustermesh-ip-identities-sync-timeout:1m0s
ipv6-range:auto
bgp-announce-pod-cidr:false
hubble-export-file-max-backups:5
enable-l2-pod-announcements:false
use-cilium-internal-ip-for-ipsec:false
custom-cni-conf:false
encrypt-interface:
tofqdns-max-deferred-connection-deletes:10000
synchronize-k8s-nodes:true
bpf-node-map-max:16384
procfs:/host/proc
bpf-sock-rev-map-max:262144
dns-max-ips-per-restored-rule:1000
envoy-config-retry-interval:15s
endpoint-gc-interval:5m0s
bpf-lb-map-max:65536
egress-gateway-policy-map-max:16384
hubble-event-queue-size:0
route-metric:0
enable-cilium-api-server-access:
k8s-kubeconfig-path:
bgp-announce-lb-ip:false
enable-node-selector-labels:false
k8s-require-ipv6-pod-cidr:false
policy-accounting:true
mesh-auth-gc-interval:5m0s
endpoint-bpf-prog-watchdog-interval:30s
enable-ipv4-egress-gateway:false
egress-masquerade-interfaces:ens+
mesh-auth-spiffe-trust-domain:spiffe.cilium
controller-group-metrics:
kvstore-max-consecutive-quorum-errors:2
agent-labels:
k8s-api-server:
bpf-lb-rev-nat-map-max:0
local-router-ipv4:
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
enable-k8s-api-discovery:false
bgp-config-path:/var/lib/cilium/bgp/config.yaml
labels:
prepend-iptables-chains:true
datapath-mode:veth
enable-envoy-config:false
enable-ipsec-encrypted-overlay:false
derive-masq-ip-addr-from-device:
keep-config:false
hubble-drop-events-interval:2m0s
monitor-aggregation:medium
mke-cgroup-mount:
hubble-listen-address::4244
ipv6-mcast-device:
cluster-pool-ipv4-mask-size:24
arping-refresh-period:30s
enable-custom-calls:false
log-driver:
allow-localhost:auto
enable-ipsec-xfrm-state-caching:true
api-rate-limit:
cilium-endpoint-gc-interval:5m0s
hubble-redact-http-headers-deny:
proxy-xff-num-trusted-hops-egress:0
enable-metrics:true
srv6-encap-mode:reduced
node-port-range:
enable-ipv6-masquerade:true
proxy-max-connection-duration-seconds:0
encryption-strict-mode-cidr:
cni-chaining-target:
auto-direct-node-routes:false
config-dir:/tmp/cilium/config-map
identity-restore-grace-period:30s
enable-host-firewall:false
http-request-timeout:3600
bpf-lb-rss-ipv4-src-cidr:
restore:true
clustermesh-sync-timeout:1m0s
bypass-ip-availability-upon-restore:false
bpf-lb-mode:snat
vtep-mac:
enable-xdp-prefilter:false
enable-host-legacy-routing:false
debug-verbose:
unmanaged-pod-watcher-interval:15
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
ipv4-node:auto
envoy-keep-cap-netbindservice:false
enable-l2-neigh-discovery:true
ipam:cluster-pool
dnsproxy-insecure-skip-transparent-mode-check:false
proxy-idle-timeout-seconds:60
enable-active-connection-tracking:false
enable-bpf-tproxy:false
bpf-fragments-map-max:8192
service-no-backend-response:reject
clustermesh-enable-mcs-api:false
external-envoy-proxy:true
bpf-map-event-buffers:
enable-l2-announcements:false
http-normalize-path:true
max-controller-interval:0
enable-ipv6:false
cni-external-routing:false
hubble-event-buffer-capacity:4095
enable-ingress-controller:false
allow-icmp-frag-needed:true
l2-announcements-renew-deadline:5s
hubble-recorder-sink-queue-size:1024
static-cnp-path:
bpf-lb-affinity-map-max:0
enable-gateway-api:false
cluster-name:cmesh67
trace-sock:true
kvstore-lease-ttl:15m0s
prometheus-serve-addr:
endpoint-queue-size:25
enable-hubble:true
agent-liveness-update-interval:1s
enable-auto-protect-node-port-range:true
hubble-metrics:
enable-k8s-terminating-endpoint:true
proxy-admin-port:0
enable-tcx:true
enable-monitor:true
bpf-filter-priority:1
tofqdns-dns-reject-response-code:refused
nat-map-stats-entries:32
pprof:false
gops-port:9890
enable-pmtu-discovery:false
cluster-pool-ipv4-cidr:10.66.0.0/16
enable-cilium-health-api-server-access:
iptables-lock-timeout:5s
ipv6-native-routing-cidr:
tofqdns-endpoint-max-ip-per-hostname:50
vlan-bpf-bypass:
install-no-conntrack-iptables-rules:false
config-sources:config-map:kube-system/cilium-config
cluster-health-port:4240
node-port-bind-protection:true
enable-node-port:false
node-labels:
hubble-socket-path:/var/run/cilium/hubble.sock
local-max-addr-scope:252
tofqdns-enable-dns-compression:true
ipv4-range:auto
debug:false
cni-exclusive:true
ipv4-service-range:auto
enable-bbr:false
disable-iptables-feeder-rules:
clustermesh-config:/var/lib/cilium/clustermesh/
hubble-drop-events:false
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
monitor-queue-size:0
dnsproxy-lock-count:131
label-prefix-file:
read-cni-conf:
k8s-service-cache-size:128
enable-encryption-strict-mode:false
policy-audit-mode:false
enable-ipv4-big-tcp:false
max-internal-timer-delay:0s
bpf-ct-timeout-service-tcp:2h13m20s
nodeport-addresses:
proxy-xff-num-trusted-hops-ingress:0
tofqdns-pre-cache:
bpf-ct-timeout-regular-any:1m0s
crd-wait-timeout:5m0s
hubble-prefer-ipv6:false
hubble-disable-tls:false
enable-runtime-device-detection:true
enable-session-affinity:false
l2-pod-announcements-interface:
kvstore-periodic-sync:5m0s
annotate-k8s-node:false
mesh-auth-spire-admin-socket:
certificates-directory:/var/run/cilium/certs
cni-log-file:/var/run/cilium/cilium-cni.log
routing-mode:tunnel
enable-ipv6-big-tcp:false
hubble-redact-enabled:false
enable-sctp:false
enable-xt-socket-fallback:true
local-router-ipv6:
proxy-prometheus-port:0
lib-dir:/var/lib/cilium
http-idle-timeout:0
disable-endpoint-crd:false
envoy-secrets-namespace:
force-device-detection:false
auto-create-cilium-node-resource:true
fqdn-regex-compile-lru-size:1024
node-port-algorithm:random
ipv4-native-routing-cidr:
policy-trigger-interval:1s
hubble-redact-http-urlquery:false
enable-ipv6-ndp:false
ipsec-key-file:
enable-ipv4:true
bpf-map-dynamic-size-ratio:0.0025
monitor-aggregation-flags:all
bpf-lb-acceleration:disabled
enable-health-checking:true
state-dir:/var/run/cilium
install-iptables-rules:true
cluster-id:67
hubble-monitor-events:
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
cflags:
tunnel-protocol:vxlan
vtep-endpoint:
bpf-ct-timeout-regular-tcp-syn:1m0s
l2-announcements-lease-duration:15s
enable-host-port:false
nodes-gc-interval:5m0s
hubble-metrics-server:
ipv6-cluster-alloc-cidr:f00d::/64
bpf-ct-global-tcp-max:524288
join-cluster:false
```


#### Service list

```
ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.153.80:443 (active)    
                                         2 => 172.31.218.229:443 (active)   
2    10.100.158.9:443     ClusterIP      1 => 172.31.170.17:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.66.0.209:53 (active)       
                                         2 => 10.66.0.166:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.66.0.209:9153 (active)     
                                         2 => 10.66.0.166:9153 (active)     
5    10.100.237.37:2379   ClusterIP      1 => 10.66.0.242:2379 (active)     
```

#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 8422047                           /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 8422047                           /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 8422047                           /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400c000000 rw-p 00000000 00:00 0 
ffff55ed5000-ffff560ca000 rw-p 00000000 00:00 0 
ffff560d2000-ffff561b3000 rw-p 00000000 00:00 0 
ffff561b3000-ffff561f4000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff561f4000-ffff56234000 rw-p 00000000 00:00 0 
ffff56234000-ffff56275000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff56275000-ffff56277000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff56277000-ffff56279000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff56279000-ffff56840000 rw-p 00000000 00:00 0 
ffff56840000-ffff56940000 rw-p 00000000 00:00 0 
ffff56940000-ffff56951000 rw-p 00000000 00:00 0 
ffff56951000-ffff58951000 rw-p 00000000 00:00 0 
ffff58951000-ffff589d1000 ---p 00000000 00:00 0 
ffff589d1000-ffff589d2000 rw-p 00000000 00:00 0 
ffff589d2000-ffff789d1000 ---p 00000000 00:00 0 
ffff789d1000-ffff789d2000 rw-p 00000000 00:00 0 
ffff789d2000-ffff98961000 ---p 00000000 00:00 0 
ffff98961000-ffff98962000 rw-p 00000000 00:00 0 
ffff98962000-ffff9c953000 ---p 00000000 00:00 0 
ffff9c953000-ffff9c954000 rw-p 00000000 00:00 0 
ffff9c954000-ffff9d151000 ---p 00000000 00:00 0 
ffff9d151000-ffff9d152000 rw-p 00000000 00:00 0 
ffff9d152000-ffff9d251000 ---p 00000000 00:00 0 
ffff9d251000-ffff9d2b1000 rw-p 00000000 00:00 0 
ffff9d2b1000-ffff9d2b3000 r--p 00000000 00:00 0                          [vvar]
ffff9d2b3000-ffff9d2b4000 r-xp 00000000 00:00 0                          [vdso]
ffffdb314000-ffffdb335000 rw-p 00000000 00:00 0                          [stack]

```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.66.0.0/24, 
Allocated addresses:
  10.66.0.101 (router)
  10.66.0.166 (kube-system/coredns-cc6ccd49c-jvprx)
  10.66.0.209 (kube-system/coredns-cc6ccd49c-fmq5k)
  10.66.0.242 (kube-system/clustermesh-apiserver-987b657b9-b5s92)
  10.66.0.31 (health)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 36015a4e78a50fc9
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                               Last success   Last error   Count   Message
  cilium-health-ep                                                   10s ago        never        0       no error   
  ct-map-pressure                                                    11s ago        never        0       no error   
  daemon-validate-config                                             57s ago        never        0       no error   
  dns-garbage-collector-job                                          13s ago        never        0       no error   
  endpoint-2195-regeneration-recovery                                never          never        0       no error   
  endpoint-24-regeneration-recovery                                  never          never        0       no error   
  endpoint-283-regeneration-recovery                                 never          never        0       no error   
  endpoint-4034-regeneration-recovery                                never          never        0       no error   
  endpoint-411-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                        13s ago        never        0       no error   
  ep-bpf-prog-watchdog                                               11s ago        never        0       no error   
  ipcache-inject-labels                                              11s ago        never        0       no error   
  k8s-heartbeat                                                      14s ago        never        0       no error   
  link-cache                                                         11s ago        never        0       no error   
  local-identity-checkpoint                                          14m22s ago     never        0       no error   
  node-neighbor-link-updater                                         1s ago         never        0       no error   
  remote-etcd-cmesh1                                                 6m37s ago      never        0       no error   
  remote-etcd-cmesh10                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh100                                               6m38s ago      never        0       no error   
  remote-etcd-cmesh101                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh102                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh103                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh104                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh105                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh106                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh107                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh108                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh109                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh11                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh110                                               6m38s ago      never        0       no error   
  remote-etcd-cmesh111                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh112                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh113                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh114                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh115                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh116                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh117                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh118                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh119                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh12                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh120                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh121                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh122                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh123                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh124                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh125                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh126                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh127                                               6m37s ago      never        0       no error   
  remote-etcd-cmesh128                                               6m38s ago      never        0       no error   
  remote-etcd-cmesh13                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh14                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh15                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh16                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh17                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh18                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh19                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh2                                                 6m37s ago      never        0       no error   
  remote-etcd-cmesh20                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh21                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh22                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh23                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh24                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh25                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh26                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh27                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh28                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh29                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh3                                                 6m37s ago      never        0       no error   
  remote-etcd-cmesh30                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh31                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh32                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh33                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh34                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh35                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh36                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh37                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh38                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh39                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh4                                                 6m37s ago      never        0       no error   
  remote-etcd-cmesh40                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh41                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh42                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh43                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh44                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh45                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh46                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh47                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh48                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh49                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh5                                                 6m38s ago      never        0       no error   
  remote-etcd-cmesh50                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh51                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh52                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh53                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh54                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh55                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh56                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh57                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh58                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh59                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh6                                                 6m37s ago      never        0       no error   
  remote-etcd-cmesh60                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh61                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh62                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh63                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh64                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh65                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh66                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh68                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh69                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh7                                                 6m37s ago      never        0       no error   
  remote-etcd-cmesh70                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh71                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh72                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh73                                                6m38s ago      never        0       no error   
  remote-etcd-cmesh74                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh75                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh76                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh77                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh78                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh79                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh8                                                 6m37s ago      never        0       no error   
  remote-etcd-cmesh80                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh81                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh82                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh83                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh84                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh85                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh86                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh87                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh88                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh89                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh9                                                 6m37s ago      never        0       no error   
  remote-etcd-cmesh90                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh91                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh92                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh93                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh94                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh95                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh96                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh97                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh98                                                6m37s ago      never        0       no error   
  remote-etcd-cmesh99                                                6m37s ago      never        0       no error   
  resolve-identity-2195                                              1s ago         never        0       no error   
  resolve-identity-24                                                1m55s ago      never        0       no error   
  resolve-identity-283                                               11s ago        never        0       no error   
  resolve-identity-4034                                              10s ago        never        0       no error   
  resolve-identity-411                                               2s ago         never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-987b657b9-b5s92   6m55s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-fmq5k                 15m1s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-jvprx                 15m2s ago      never        0       no error   
  sync-lb-maps-with-k8s-services                                     15m11s ago     never        0       no error   
  sync-policymap-2195                                                1s ago         never        0       no error   
  sync-policymap-24                                                  6m55s ago      never        0       no error   
  sync-policymap-283                                                 10s ago        never        0       no error   
  sync-policymap-4034                                                6s ago         never        0       no error   
  sync-policymap-411                                                 2s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2195)                                  1s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (24)                                    5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (411)                                   2s ago         never        0       no error   
  sync-utime                                                         11s ago        never        0       no error   
  write-cni-file                                                     15m13s ago     never        0       no error   
Proxy Status:            OK, ip 10.66.0.101, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 4390912, max 4456447
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 70.51   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
24         Disabled           Disabled          4424847    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.66.0.242   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh67                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
283        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az1                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3a                                                                
                                                           reserved:host                                                                                             
411        Disabled           Disabled          4392568    k8s:eks.amazonaws.com/component=coredns                                             10.66.0.166   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh67                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
2195       Disabled           Disabled          4392568    k8s:eks.amazonaws.com/component=coredns                                             10.66.0.209   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh67                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
4034       Disabled           Disabled          4          reserved:health                                                                     10.66.0.31    ready   
```

#### BPF Policy Get 24

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3887527   36393     0        
Allow    Ingress     1          ANY          NONE         disabled    3088628   31202     0        
Allow    Egress      0          ANY          NONE         disabled    4365773   40465     0        

```


#### BPF CT List 24

```
Invalid argument: unknown type 24
```


#### Endpoint Get 24

```
[
  {
    "id": 24,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-24-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "1e4f65bc-fcc8-400b-b958-79a1d185fd68"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-24",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:22.109Z",
            "success-count": 2
          },
          "uuid": "b3e8ecd9-dc83-4cfb-9e6e-bb26f05e2a83"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-987b657b9-b5s92",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:22.108Z",
            "success-count": 1
          },
          "uuid": "3c0f0bd6-3127-451d-b570-8553ecaf809f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-24",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:22.145Z",
            "success-count": 1
          },
          "uuid": "620678e9-9c06-499e-8e63-c9cec3469efc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (24)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:12.153Z",
            "success-count": 43
          },
          "uuid": "11b87b7f-8af2-4f33-a826-9e6ef88edd51"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "3c4adaed3b5a38fcda2845019fe79b9851a77af8c74ec74b069f0df67c53b914:eth0",
        "container-id": "3c4adaed3b5a38fcda2845019fe79b9851a77af8c74ec74b069f0df67c53b914",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-987b657b9-b5s92",
        "pod-name": "kube-system/clustermesh-apiserver-987b657b9-b5s92"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4424847,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh67",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=987b657b9"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh67",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:41Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.66.0.242",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "66:57:a1:aa:89:9b",
        "interface-index": 15,
        "interface-name": "lxc1185b997b01f",
        "mac": "52:01:20:66:d2:ec"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4424847,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4424847,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 24

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 24

```
Timestamp              Status   State                   Message
2024-10-25T10:22:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:41Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:22:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:22Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:22:22Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:22:22Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4424847

```
ID        LABELS
4424847   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh67
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 283

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 283

```
Invalid argument: unknown type 283
```


#### Endpoint Get 283

```
[
  {
    "id": 283,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-283-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "6fdd1af0-0cd1-4b6b-bc11-5e45b5750d80"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-283",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:06.526Z",
            "success-count": 4
          },
          "uuid": "51d5a7fc-97f2-40bd-9895-e1c82d81f9c2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-283",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:07.592Z",
            "success-count": 2
          },
          "uuid": "8675b11d-f8bd-4a62-8ad1-c3add7a6345a"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az1",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:41Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "f6:10:6a:bd:28:14",
        "interface-name": "cilium_host",
        "mac": "f6:10:6a:bd:28:14"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 283

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 283

```
Timestamp              Status   State                   Message
2024-10-25T10:22:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:41Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:14:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:08Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:14:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:14:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:06Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:06Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:06Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 411

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    86097   993       0        
Allow    Egress      0          ANY          NONE         disabled    13570   141       0        

```


#### BPF CT List 411

```
Invalid argument: unknown type 411
```


#### Endpoint Get 411

```
[
  {
    "id": 411,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-411-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5ddd5b40-0216-41dd-a312-b14b5f3fb9c3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-411",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:15.502Z",
            "success-count": 4
          },
          "uuid": "0a378ea0-f475-42c5-ac53-a522428ffe63"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-jvprx",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:15.498Z",
            "success-count": 1
          },
          "uuid": "7cc0999e-668c-4e5c-b823-bf9044e00ea3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-411",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:15.530Z",
            "success-count": 2
          },
          "uuid": "b9bca696-efd5-453d-9e6c-fd4ebd7b8113"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (411)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:15.580Z",
            "success-count": 92
          },
          "uuid": "74c30b62-3e59-4436-b92f-8c359fdaea39"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "f5ea63899c534c412b623bbf3c021f210a83d91b22a9a59925b654226bdb8c38:eth0",
        "container-id": "f5ea63899c534c412b623bbf3c021f210a83d91b22a9a59925b654226bdb8c38",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-jvprx",
        "pod-name": "kube-system/coredns-cc6ccd49c-jvprx"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4392568,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh67",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh67",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:41Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.66.0.166",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "b6:b8:08:a3:5a:7c",
        "interface-index": 9,
        "interface-name": "lxce09bae52c183",
        "mac": "ee:39:3c:9b:08:19"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4392568,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4392568,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 411

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 411

```
Timestamp              Status    State                   Message
2024-10-25T10:22:41Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:41Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:41Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:22:41Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:40Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:40Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:40Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:40Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:39Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:39Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:39Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:39Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:40Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:40Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:40Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:40Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:39Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:39Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:39Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:39Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:16Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:16Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:16Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:16Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:15Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:15Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:15Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:15Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:15Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:14:15Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:15Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 4392568

```
ID        LABELS
4392568   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh67
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 2195

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    85965   991       0        
Allow    Egress      0          ANY          NONE         disabled    13770   144       0        

```


#### BPF CT List 2195

```
Invalid argument: unknown type 2195
```


#### Endpoint Get 2195

```
[
  {
    "id": 2195,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2195-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "897457cc-3f5b-4819-b46a-e720bd229e06"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2195",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:16.544Z",
            "success-count": 4
          },
          "uuid": "c6c4b8b3-e41f-43ec-b51d-b7090b3df5c0"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-fmq5k",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:16.541Z",
            "success-count": 1
          },
          "uuid": "857d9c0e-cbc7-4439-bdd7-8430a9215112"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2195",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:16.582Z",
            "success-count": 2
          },
          "uuid": "837766bc-2ac4-4bc1-8a51-0fe39223ced0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2195)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:16.624Z",
            "success-count": 92
          },
          "uuid": "88ba173c-d29a-4051-9761-663992b5b0b7"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "484ba5e7bec07881289fa294e2fbb16918b1fa21ae96bbb0e6dd1ea4cdf93094:eth0",
        "container-id": "484ba5e7bec07881289fa294e2fbb16918b1fa21ae96bbb0e6dd1ea4cdf93094",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-fmq5k",
        "pod-name": "kube-system/coredns-cc6ccd49c-fmq5k"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4392568,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh67",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh67",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:41Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.66.0.209",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "b2:3b:0e:53:c8:9b",
        "interface-index": 11,
        "interface-name": "lxc45944f524c34",
        "mac": "e2:a7:cf:91:45:43"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4392568,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4392568,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2195

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2195

```
Timestamp              Status   State                   Message
2024-10-25T10:22:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:41Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:16Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:16Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:16Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4392568

```
ID        LABELS
4392568   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh67
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 4034

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    438965   5615      0        
Allow    Ingress     1          ANY          NONE         disabled    12470    144       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 4034

```
Invalid argument: unknown type 4034
```


#### Endpoint Get 4034

```
[
  {
    "id": 4034,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-4034-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "102b8a02-9881-47c4-8eee-f2a548e326be"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-4034",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:07.622Z",
            "success-count": 4
          },
          "uuid": "1fb381b5-03ea-4a14-9252-26181bce625d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-4034",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:10.813Z",
            "success-count": 2
          },
          "uuid": "685af198-ae74-4be8-afe1-70413ccc2ba8"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:41Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.66.0.31",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "26:f1:bf:ca:5f:ea",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "e2:45:0d:79:d8:23"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 4034

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 4034

```
Timestamp              Status   State                   Message
2024-10-25T10:22:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:41Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:14:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:10Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:14:10Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:14:07Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:07Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:06Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.66.0.31": (string) (len=6) "health",
  (string) (len=11) "10.66.0.166": (string) (len=35) "kube-system/coredns-cc6ccd49c-jvprx",
  (string) (len=11) "10.66.0.209": (string) (len=35) "kube-system/coredns-cc6ccd49c-fmq5k",
  (string) (len=11) "10.66.0.242": (string) (len=49) "kube-system/clustermesh-apiserver-987b657b9-b5s92",
  (string) (len=11) "10.66.0.101": (string) (len=6) "router"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.170.17": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x400180e8f0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001bdb4a0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001bdb4a0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x40024798c0)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4002479a20)(frontends:[10.100.237.37]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4000b11b80)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4000b11c30)(frontends:[10.100.158.9]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4000b11d90)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4001250c58)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-mdgj7": (*k8s.Endpoints)(0x4002fe09c0)(10.66.0.166:53/TCP[eu-west-3a],10.66.0.166:53/UDP[eu-west-3a],10.66.0.166:9153/TCP[eu-west-3a],10.66.0.209:53/TCP[eu-west-3a],10.66.0.209:53/UDP[eu-west-3a],10.66.0.209:9153/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001959a20)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-mzpzf": (*k8s.Endpoints)(0x4001eaedd0)(10.66.0.242:2379/TCP[eu-west-3a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4001250c48)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4003133e10)(172.31.153.80:443/TCP,172.31.218.229:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4001250c50)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-kvxfj": (*k8s.Endpoints)(0x40026d5e10)(172.31.170.17:4244/TCP[eu-west-3a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x40018ec310)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40007a7270)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4009c9a5b8
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4001a5e4e0,
  gcExited: (chan struct {}) 0x4001a5e540,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001adc500)({
     ObserverVec: (*prometheus.HistogramVec)(0x40016438c0)({
      MetricVec: (*prometheus.MetricVec)(0x4001b6cb40)({
       metricMap: (*prometheus.metricMap)(0x4001b6cb70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001888d20)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001adc580)({
     ObserverVec: (*prometheus.HistogramVec)(0x40016438c8)({
      MetricVec: (*prometheus.MetricVec)(0x4001b6cbd0)({
       metricMap: (*prometheus.metricMap)(0x4001b6cc00)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001888d80)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001adc600)({
     GaugeVec: (*prometheus.GaugeVec)(0x40016438d0)({
      MetricVec: (*prometheus.MetricVec)(0x4001b6cc60)({
       metricMap: (*prometheus.metricMap)(0x4001b6cc90)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001888de0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001adc680)({
     GaugeVec: (*prometheus.GaugeVec)(0x40016438d8)({
      MetricVec: (*prometheus.MetricVec)(0x4001b6ccf0)({
       metricMap: (*prometheus.metricMap)(0x4001b6cd20)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001888e40)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001adc700)({
     GaugeVec: (*prometheus.GaugeVec)(0x40016438e0)({
      MetricVec: (*prometheus.MetricVec)(0x4001b6cd80)({
       metricMap: (*prometheus.metricMap)(0x4001b6cdb0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001888ea0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001adc780)({
     GaugeVec: (*prometheus.GaugeVec)(0x40016438e8)({
      MetricVec: (*prometheus.MetricVec)(0x4001b6ce10)({
       metricMap: (*prometheus.metricMap)(0x4001b6ce40)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001888f00)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001adc800)({
     GaugeVec: (*prometheus.GaugeVec)(0x40016438f0)({
      MetricVec: (*prometheus.MetricVec)(0x4001b6cea0)({
       metricMap: (*prometheus.metricMap)(0x4001b6ced0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001888f60)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001adc880)({
     GaugeVec: (*prometheus.GaugeVec)(0x40016438f8)({
      MetricVec: (*prometheus.MetricVec)(0x4001b6cf30)({
       metricMap: (*prometheus.metricMap)(0x4001b6cf60)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001888fc0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001adc900)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001643900)({
      MetricVec: (*prometheus.MetricVec)(0x4001b6cfc0)({
       metricMap: (*prometheus.metricMap)(0x4001b6cff0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001889020)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x40018ec310)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40018ed490)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001b3d758)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 353ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### Cilium encryption


