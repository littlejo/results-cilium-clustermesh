Node 0, zone      DMA     33     24      3      1      1      2      3     16      4      4    167 
Node 0, zone   Normal    368     76     10      0     22      7      2      2      0      2      8 
