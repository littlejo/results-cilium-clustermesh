1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:2d:b9:84:1c:cb brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.170.17/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2678sec preferred_lft 2678sec
    inet6 fe80::42d:b9ff:fe84:1ccb/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:b8:58:ee:c8:4f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b4b8:58ff:feee:c84f/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:10:6a:bd:28:14 brd ff:ff:ff:ff:ff:ff
    inet 10.66.0.101/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::f410:6aff:febd:2814/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether da:bb:41:04:c1:bb brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d8bb:41ff:fe04:c1bb/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:f1:bf:ca:5f:ea brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::24f1:bfff:feca:5fea/64 scope link 
       valid_lft forever preferred_lft forever
9: lxce09bae52c183@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:b8:08:a3:5a:7c brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b4b8:8ff:fea3:5a7c/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc45944f524c34@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:3b:0e:53:c8:9b brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::b03b:eff:fe53:c89b/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc1185b997b01f@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:57:a1:aa:89:9b brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::6457:a1ff:feaa:899b/64 scope link 
       valid_lft forever preferred_lft forever
