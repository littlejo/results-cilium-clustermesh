KEY             VALUE
AgentLiveness   961914679310
UTimeOffset     3378615617187500
