alloc: 97.64MB (102383928 bytes)
total-alloc: 1.35GB (1453744376 bytes)
sys: 202.32MB (212146500 bytes)
lookups: 0
mallocs: 48093898
frees: 47113253
heap-alloc: 97.64MB (102383928 bytes)
heap-sys: 157.23MB (164864000 bytes)
heap-idle: 37.12MB (38920192 bytes)
heap-in-use: 120.11MB (125943808 bytes)
heap-released: 1.98MB (2080768 bytes)
heap-objects: 980645
stack-in-use: 34.75MB (36438016 bytes)
stack-sys: 34.75MB (36438016 bytes)
stack-mspan-inuse: 1.99MB (2088480 bytes)
stack-mspan-sys: 2.43MB (2545920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 968.29KB (991529 bytes)
gc-sys: 5.06MB (5301392 bytes)
next-gc: when heap-alloc >= 147.10MB (154243064 bytes)
last-gc: 2024-10-25 10:28:52.745746805 +0000 UTC
gc-pause-total: 12.367715ms
gc-pause: 1222290
gc-pause-end: 1729852132745746805
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00032445902270038994
enable-gc: true
debug-gc: false
