xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 477
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 469
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 464
cilium_host(4) clsact/egress cil_from_host-cilium_host id 462
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 460
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 459
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 495
lxce09bae52c183(9) clsact/ingress cil_from_container-lxce09bae52c183 id 512
lxc45944f524c34(11) clsact/ingress cil_from_container-lxc45944f524c34 id 523
lxc1185b997b01f(15) clsact/ingress cil_from_container-lxc1185b997b01f id 587

flow_dissector:

netfilter:

