{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:06.356Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.170.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:06.356Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:10.812Z",
  "value": "id=4034  sec_id=4     flags=0x0000 ifindex=7   mac=E2:45:0D:79:D8:23 nodemac=26:F1:BF:CA:5F:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:10.841Z",
  "value": "id=4034  sec_id=4     flags=0x0000 ifindex=7   mac=E2:45:0D:79:D8:23 nodemac=26:F1:BF:CA:5F:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:15.497Z",
  "value": "id=4034  sec_id=4     flags=0x0000 ifindex=7   mac=E2:45:0D:79:D8:23 nodemac=26:F1:BF:CA:5F:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:15.528Z",
  "value": "id=411   sec_id=4392568 flags=0x0000 ifindex=9   mac=EE:39:3C:9B:08:19 nodemac=B6:B8:08:A3:5A:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:16.498Z",
  "value": "id=411   sec_id=4392568 flags=0x0000 ifindex=9   mac=EE:39:3C:9B:08:19 nodemac=B6:B8:08:A3:5A:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:16.499Z",
  "value": "id=4034  sec_id=4     flags=0x0000 ifindex=7   mac=E2:45:0D:79:D8:23 nodemac=26:F1:BF:CA:5F:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:16.581Z",
  "value": "id=2195  sec_id=4392568 flags=0x0000 ifindex=11  mac=E2:A7:CF:91:45:43 nodemac=B2:3B:0E:53:C8:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:39.317Z",
  "value": "id=2195  sec_id=4392568 flags=0x0000 ifindex=11  mac=E2:A7:CF:91:45:43 nodemac=B2:3B:0E:53:C8:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:39.317Z",
  "value": "id=4034  sec_id=4     flags=0x0000 ifindex=7   mac=E2:45:0D:79:D8:23 nodemac=26:F1:BF:CA:5F:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:39.317Z",
  "value": "id=411   sec_id=4392568 flags=0x0000 ifindex=9   mac=EE:39:3C:9B:08:19 nodemac=B6:B8:08:A3:5A:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:39.349Z",
  "value": "id=3620  sec_id=4424847 flags=0x0000 ifindex=13  mac=76:FE:14:FF:B5:2F nodemac=06:D6:81:FC:D9:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:40.316Z",
  "value": "id=3620  sec_id=4424847 flags=0x0000 ifindex=13  mac=76:FE:14:FF:B5:2F nodemac=06:D6:81:FC:D9:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:40.317Z",
  "value": "id=2195  sec_id=4392568 flags=0x0000 ifindex=11  mac=E2:A7:CF:91:45:43 nodemac=B2:3B:0E:53:C8:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:40.317Z",
  "value": "id=4034  sec_id=4     flags=0x0000 ifindex=7   mac=E2:45:0D:79:D8:23 nodemac=26:F1:BF:CA:5F:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:40.317Z",
  "value": "id=411   sec_id=4392568 flags=0x0000 ifindex=9   mac=EE:39:3C:9B:08:19 nodemac=B6:B8:08:A3:5A:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:22.145Z",
  "value": "id=24    sec_id=4424847 flags=0x0000 ifindex=15  mac=52:01:20:66:D2:EC nodemac=66:57:A1:AA:89:9B"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.66.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:28.091Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:39.613Z",
  "value": "id=24    sec_id=4424847 flags=0x0000 ifindex=15  mac=52:01:20:66:D2:EC nodemac=66:57:A1:AA:89:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:39.614Z",
  "value": "id=4034  sec_id=4     flags=0x0000 ifindex=7   mac=E2:45:0D:79:D8:23 nodemac=26:F1:BF:CA:5F:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:39.614Z",
  "value": "id=411   sec_id=4392568 flags=0x0000 ifindex=9   mac=EE:39:3C:9B:08:19 nodemac=B6:B8:08:A3:5A:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:39.614Z",
  "value": "id=2195  sec_id=4392568 flags=0x0000 ifindex=11  mac=E2:A7:CF:91:45:43 nodemac=B2:3B:0E:53:C8:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:40.613Z",
  "value": "id=24    sec_id=4424847 flags=0x0000 ifindex=15  mac=52:01:20:66:D2:EC nodemac=66:57:A1:AA:89:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:40.614Z",
  "value": "id=411   sec_id=4392568 flags=0x0000 ifindex=9   mac=EE:39:3C:9B:08:19 nodemac=B6:B8:08:A3:5A:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:40.614Z",
  "value": "id=2195  sec_id=4392568 flags=0x0000 ifindex=11  mac=E2:A7:CF:91:45:43 nodemac=B2:3B:0E:53:C8:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:40.614Z",
  "value": "id=4034  sec_id=4     flags=0x0000 ifindex=7   mac=E2:45:0D:79:D8:23 nodemac=26:F1:BF:CA:5F:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:41.614Z",
  "value": "id=24    sec_id=4424847 flags=0x0000 ifindex=15  mac=52:01:20:66:D2:EC nodemac=66:57:A1:AA:89:9B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:41.614Z",
  "value": "id=411   sec_id=4392568 flags=0x0000 ifindex=9   mac=EE:39:3C:9B:08:19 nodemac=B6:B8:08:A3:5A:7C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:41.614Z",
  "value": "id=4034  sec_id=4     flags=0x0000 ifindex=7   mac=E2:45:0D:79:D8:23 nodemac=26:F1:BF:CA:5F:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.66.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:41.615Z",
  "value": "id=2195  sec_id=4392568 flags=0x0000 ifindex=11  mac=E2:A7:CF:91:45:43 nodemac=B2:3B:0E:53:C8:9B"
}

