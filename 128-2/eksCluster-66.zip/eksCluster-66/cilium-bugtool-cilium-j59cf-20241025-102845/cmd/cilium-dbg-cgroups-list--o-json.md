[
  {
    "containers": [
      {
        "cgroup-id": 8706,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeca62fa1_76a2_4519_8dd9_c3c170f09781.slice/cri-containerd-a1a8bc03dba3ea5ef209ccb9ce48ee13bccbbc30110fc840c2ec2c62df0dbfb4.scope"
      },
      {
        "cgroup-id": 8622,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeca62fa1_76a2_4519_8dd9_c3c170f09781.slice/cri-containerd-655ba49a48efd4aa244b270f1cb374fc27d1b109c890a934458bbae3d4521224.scope"
      },
      {
        "cgroup-id": 8790,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeca62fa1_76a2_4519_8dd9_c3c170f09781.slice/cri-containerd-a18d2e60fe0d68128f912ce1f0b3c3cfed2c50a0bd8a3561ff589ccab4f907cf.scope"
      }
    ],
    "ips": [
      "10.66.0.242"
    ],
    "name": "clustermesh-apiserver-987b657b9-b5s92",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7110,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podde087062_10b3_4170_baf5_ba4fddd335d7.slice/cri-containerd-09300c40fafbafe5401bcdc43d8494eb717e7552fa8f3960864b30853a19ed27.scope"
      }
    ],
    "ips": [
      "10.66.0.166"
    ],
    "name": "coredns-cc6ccd49c-jvprx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7278,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67c958a4_3c6d_4f16_a889_3d34b4945cb3.slice/cri-containerd-ee69f38d2806e685cc442c237fc8cee28c16b2b16ce14c8dbeae4028a43f690f.scope"
      }
    ],
    "ips": [
      "10.66.0.209"
    ],
    "name": "coredns-cc6ccd49c-fmq5k",
    "namespace": "kube-system"
  }
]

