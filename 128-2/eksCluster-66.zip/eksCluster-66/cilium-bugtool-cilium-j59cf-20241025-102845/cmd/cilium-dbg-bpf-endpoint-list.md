IP ADDRESS        LOCAL ENDPOINT INFO
172.31.170.17:0   (localhost)                                                                                        
10.66.0.242:0     id=24    sec_id=4424847 flags=0x0000 ifindex=15  mac=52:01:20:66:D2:EC nodemac=66:57:A1:AA:89:9B   
10.66.0.101:0     (localhost)                                                                                        
10.66.0.209:0     id=2195  sec_id=4392568 flags=0x0000 ifindex=11  mac=E2:A7:CF:91:45:43 nodemac=B2:3B:0E:53:C8:9B   
10.66.0.166:0     id=411   sec_id=4392568 flags=0x0000 ifindex=9   mac=EE:39:3C:9B:08:19 nodemac=B6:B8:08:A3:5A:7C   
10.66.0.31:0      id=4034  sec_id=4     flags=0x0000 ifindex=7   mac=E2:45:0D:79:D8:23 nodemac=26:F1:BF:CA:5F:EA     
