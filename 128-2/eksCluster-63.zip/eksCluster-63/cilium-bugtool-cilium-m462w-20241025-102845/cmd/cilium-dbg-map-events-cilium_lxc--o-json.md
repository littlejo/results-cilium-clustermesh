{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:12.084Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.240.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:12.084Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:16.512Z",
  "value": "id=692   sec_id=4     flags=0x0000 ifindex=7   mac=06:84:E3:E3:B1:66 nodemac=16:22:96:B1:98:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:16.514Z",
  "value": "id=211   sec_id=4207172 flags=0x0000 ifindex=9   mac=7E:B8:B6:6A:1F:36 nodemac=9E:B5:59:D4:E7:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:16.558Z",
  "value": "id=1080  sec_id=4207172 flags=0x0000 ifindex=11  mac=BA:31:28:B0:51:B9 nodemac=06:6F:F9:53:6E:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:16.618Z",
  "value": "id=692   sec_id=4     flags=0x0000 ifindex=7   mac=06:84:E3:E3:B1:66 nodemac=16:22:96:B1:98:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:16.670Z",
  "value": "id=211   sec_id=4207172 flags=0x0000 ifindex=9   mac=7E:B8:B6:6A:1F:36 nodemac=9E:B5:59:D4:E7:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:58.402Z",
  "value": "id=1080  sec_id=4207172 flags=0x0000 ifindex=11  mac=BA:31:28:B0:51:B9 nodemac=06:6F:F9:53:6E:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:58.403Z",
  "value": "id=692   sec_id=4     flags=0x0000 ifindex=7   mac=06:84:E3:E3:B1:66 nodemac=16:22:96:B1:98:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:58.404Z",
  "value": "id=211   sec_id=4207172 flags=0x0000 ifindex=9   mac=7E:B8:B6:6A:1F:36 nodemac=9E:B5:59:D4:E7:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:58.439Z",
  "value": "id=279   sec_id=4216907 flags=0x0000 ifindex=13  mac=26:46:79:62:64:BF nodemac=16:52:57:C1:5D:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:59.402Z",
  "value": "id=692   sec_id=4     flags=0x0000 ifindex=7   mac=06:84:E3:E3:B1:66 nodemac=16:22:96:B1:98:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:59.402Z",
  "value": "id=279   sec_id=4216907 flags=0x0000 ifindex=13  mac=26:46:79:62:64:BF nodemac=16:52:57:C1:5D:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:59.402Z",
  "value": "id=211   sec_id=4207172 flags=0x0000 ifindex=9   mac=7E:B8:B6:6A:1F:36 nodemac=9E:B5:59:D4:E7:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:59.403Z",
  "value": "id=1080  sec_id=4207172 flags=0x0000 ifindex=11  mac=BA:31:28:B0:51:B9 nodemac=06:6F:F9:53:6E:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.105Z",
  "value": "id=694   sec_id=4216907 flags=0x0000 ifindex=15  mac=B2:DC:9E:9A:87:80 nodemac=EE:9E:46:23:26:79"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.63.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:06.605Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:51.844Z",
  "value": "id=694   sec_id=4216907 flags=0x0000 ifindex=15  mac=B2:DC:9E:9A:87:80 nodemac=EE:9E:46:23:26:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:51.845Z",
  "value": "id=692   sec_id=4     flags=0x0000 ifindex=7   mac=06:84:E3:E3:B1:66 nodemac=16:22:96:B1:98:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:51.845Z",
  "value": "id=211   sec_id=4207172 flags=0x0000 ifindex=9   mac=7E:B8:B6:6A:1F:36 nodemac=9E:B5:59:D4:E7:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:51.846Z",
  "value": "id=1080  sec_id=4207172 flags=0x0000 ifindex=11  mac=BA:31:28:B0:51:B9 nodemac=06:6F:F9:53:6E:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.844Z",
  "value": "id=211   sec_id=4207172 flags=0x0000 ifindex=9   mac=7E:B8:B6:6A:1F:36 nodemac=9E:B5:59:D4:E7:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.844Z",
  "value": "id=692   sec_id=4     flags=0x0000 ifindex=7   mac=06:84:E3:E3:B1:66 nodemac=16:22:96:B1:98:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.844Z",
  "value": "id=1080  sec_id=4207172 flags=0x0000 ifindex=11  mac=BA:31:28:B0:51:B9 nodemac=06:6F:F9:53:6E:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.844Z",
  "value": "id=694   sec_id=4216907 flags=0x0000 ifindex=15  mac=B2:DC:9E:9A:87:80 nodemac=EE:9E:46:23:26:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.844Z",
  "value": "id=692   sec_id=4     flags=0x0000 ifindex=7   mac=06:84:E3:E3:B1:66 nodemac=16:22:96:B1:98:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.844Z",
  "value": "id=1080  sec_id=4207172 flags=0x0000 ifindex=11  mac=BA:31:28:B0:51:B9 nodemac=06:6F:F9:53:6E:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.844Z",
  "value": "id=211   sec_id=4207172 flags=0x0000 ifindex=9   mac=7E:B8:B6:6A:1F:36 nodemac=9E:B5:59:D4:E7:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.75:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.844Z",
  "value": "id=694   sec_id=4216907 flags=0x0000 ifindex=15  mac=B2:DC:9E:9A:87:80 nodemac=EE:9E:46:23:26:79"
}

