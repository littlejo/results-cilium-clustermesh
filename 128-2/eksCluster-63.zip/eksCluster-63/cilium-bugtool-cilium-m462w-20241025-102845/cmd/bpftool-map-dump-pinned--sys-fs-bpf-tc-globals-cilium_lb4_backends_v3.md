key: 04 00 00 00  value: 0a 3f 00 22 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 3f 00 77 23 c1 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f d4 0e 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 3f 00 77 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 3f 00 4b 09 4b 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f a3 0f 01 bb 00 00  00 00 00 00
key: 03 00 00 00  value: ac 1f f0 d8 10 94 00 00  00 00 00 00
key: 05 00 00 00  value: 0a 3f 00 22 23 c1 00 00  00 00 00 00
Found 8 elements
