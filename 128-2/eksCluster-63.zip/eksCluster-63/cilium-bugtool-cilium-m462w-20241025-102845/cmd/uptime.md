 10:28:47 up 15 min,  0 users,  load average: 0.06, 0.26, 0.33
