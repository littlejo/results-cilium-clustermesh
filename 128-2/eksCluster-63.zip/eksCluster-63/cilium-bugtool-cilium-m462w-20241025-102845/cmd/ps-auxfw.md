USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         636  0.0  0.4 1240432 16644 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         661  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         662  0.0  0.0   3852  1292 ?        R    10:28   0:00  \_ bash -c hostname
root           1  2.6  7.1 1472688 280160 ?      Ssl  10:15   0:21 cilium-agent --config-dir=/tmp/cilium/config-map
root         413  0.0  0.1 1228848 5808 ?        Sl   10:15   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
