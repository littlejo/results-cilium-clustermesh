filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxce3f8f0c47f80 direct-action not_in_hw id 505 tag 44c79a501deb1caf jited 
