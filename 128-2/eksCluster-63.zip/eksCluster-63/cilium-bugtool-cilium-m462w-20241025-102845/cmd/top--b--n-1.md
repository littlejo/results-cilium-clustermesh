top - 10:28:47 up 15 min,  0 users,  load average: 0.06, 0.26, 0.33
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 46.7 us, 46.7 sy,  0.0 ni,  6.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1048.1 free,    900.1 used,   1888.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2767.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538292 282324  77816 S  46.7   7.2   0:21.83 cilium-+
    636 root      20   0 1240432  16644  11356 S  13.3   0.4   0:00.03 cilium-+
    413 root      20   0 1228848   5808   2928 S   0.0   0.1   0:00.26 cilium-+
    672 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    676 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    682 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    691 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    699 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    735 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
