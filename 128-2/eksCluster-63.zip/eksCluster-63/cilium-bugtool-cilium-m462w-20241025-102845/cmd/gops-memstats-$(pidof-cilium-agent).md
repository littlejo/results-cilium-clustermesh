alloc: 77.00MB (80744096 bytes)
total-alloc: 1.35GB (1444322448 bytes)
sys: 210.57MB (220800340 bytes)
lookups: 0
mallocs: 48002067
frees: 47373549
heap-alloc: 77.00MB (80744096 bytes)
heap-sys: 165.35MB (173383680 bytes)
heap-idle: 50.24MB (52682752 bytes)
heap-in-use: 115.11MB (120700928 bytes)
heap-released: 192.00KB (196608 bytes)
heap-objects: 628518
stack-in-use: 34.62MB (36306944 bytes)
stack-sys: 34.62MB (36306944 bytes)
stack-mspan-inuse: 1.95MB (2042560 bytes)
stack-mspan-sys: 2.58MB (2709120 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 768.45KB (786889 bytes)
gc-sys: 5.35MB (5611824 bytes)
next-gc: when heap-alloc >= 145.73MB (152806936 bytes)
last-gc: 2024-10-25 10:29:12.448581586 +0000 UTC
gc-pause-total: 10.941022ms
gc-pause: 59667
gc-pause-end: 1729852152448581586
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0003246715062111766
enable-gc: true
debug-gc: false
