xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 533
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 529
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 518
cilium_host(4) clsact/egress cil_from_host-cilium_host id 524
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 453
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 454
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 494
lxce3f8f0c47f80(9) clsact/ingress cil_from_container-lxce3f8f0c47f80 id 505
lxc1c20a285da53(11) clsact/ingress cil_from_container-lxc1c20a285da53 id 485
lxca26d9d36ff87(15) clsact/ingress cil_from_container-lxca26d9d36ff87 id 592

flow_dissector:

netfilter:

