Endpoint ID: 211
Path: /sys/fs/bpf/tc/globals/cilium_policy_00211

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    78945   906       0        
Allow    Egress      0          ANY          NONE         disabled    13166   137       0        


Endpoint ID: 692
Path: /sys/fs/bpf/tc/globals/cilium_policy_00692

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    438756   5601      0        
Allow    Ingress     1          ANY          NONE         disabled    12218    143       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 694
Path: /sys/fs/bpf/tc/globals/cilium_policy_00694

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3912629   36902     0        
Allow    Ingress     1          ANY          NONE         disabled    3067251   30935     0        
Allow    Egress      0          ANY          NONE         disabled    4719674   43735     0        


Endpoint ID: 781
Path: /sys/fs/bpf/tc/globals/cilium_policy_00781

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1080
Path: /sys/fs/bpf/tc/globals/cilium_policy_01080

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    78716   905       0        
Allow    Egress      0          ANY          NONE         disabled    13656   142       0        


