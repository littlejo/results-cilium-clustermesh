32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:39+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:40+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:40+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:40+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:41+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
58: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
61: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
62: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
65: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
66: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
69: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
72: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:14:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
80: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
83: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
107: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
110: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
451: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:15:14+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 113
452: sched_cls  name tail_handle_ipv4  tag 4b65895ba8edab4a  gpl
	loaded_at 2024-10-25T10:15:14+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 69,68,75,70,91
	btf_id 114
453: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:15:14+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 70,91
	btf_id 115
454: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:15:14+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 116
477: sched_cls  name tail_ipv4_ct_egress  tag e746dd46a3424048  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,99,76,77,100,78
	btf_id 142
479: sched_cls  name tail_ipv4_to_endpoint  tag 517a79e9a3971e80  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,100,35,76,77,74,98,33,99,34,31,32
	btf_id 144
480: sched_cls  name tail_handle_ipv4_cont  tag 8307a89e0aaf7ccf  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,100,35,98,76,77,33,70,68,71,99,34,31,32,75
	btf_id 145
481: sched_cls  name __send_drop_notify  tag 1a0dde4320a7cdb1  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 146
482: sched_cls  name tail_handle_ipv4  tag e1f3d8bf576d9ca1  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,99
	btf_id 147
483: sched_cls  name handle_policy  tag b1cd52c13f1ea3db  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,99,76,77,100,35,74,98,33,78,69,34,31,32
	btf_id 148
484: sched_cls  name tail_ipv4_ct_ingress  tag bac44235058cae2e  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,99,76,77,100,78
	btf_id 149
485: sched_cls  name cil_from_container  tag 8bec0fb2c182ffce  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 99,70
	btf_id 150
486: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,99
	btf_id 151
487: sched_cls  name tail_handle_arp  tag 57ad373e3ee8d817  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,99
	btf_id 152
488: sched_cls  name tail_handle_ipv4_cont  tag d787a2cade603e07  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 69,101,35,93,76,77,33,70,68,71,102,34,31,32,75
	btf_id 154
489: sched_cls  name handle_policy  tag e60420158917a0ac  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 70,102,76,77,101,35,74,93,33,78,69,34,31,32
	btf_id 155
490: sched_cls  name tail_handle_arp  tag 9681c50bda8e5878  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,102
	btf_id 156
491: sched_cls  name __send_drop_notify  tag 86814da5646cb1b8  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 157
492: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,102
	btf_id 158
493: sched_cls  name tail_handle_ipv4  tag dabe898df2f427b4  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,102
	btf_id 159
494: sched_cls  name cil_from_container  tag fbeda607fa1b6d5d  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 102,70
	btf_id 160
495: sched_cls  name tail_ipv4_ct_ingress  tag f8dfb2d538c15694  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 70,102,76,77,101,78
	btf_id 161
497: sched_cls  name tail_ipv4_to_endpoint  tag 840f27d71b8e5951  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 69,70,101,35,76,77,74,93,33,102,34,31,32
	btf_id 163
498: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 70,102,76,77,101,78
	btf_id 164
499: sched_cls  name handle_policy  tag 9cc846a2b4877eb4  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,104,76,77,103,35,74,92,33,78,69,34,31,32
	btf_id 166
500: sched_cls  name tail_ipv4_ct_ingress  tag 67d0d9bf3be984d7  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,104,76,77,103,78
	btf_id 167
501: sched_cls  name tail_handle_arp  tag ea92f80d1dddb9ab  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,104
	btf_id 168
502: sched_cls  name __send_drop_notify  tag ea21ec58f5362b55  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 169
503: sched_cls  name tail_handle_ipv4  tag 7b6062a9335819b5  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,104
	btf_id 170
504: sched_cls  name tail_ipv4_to_endpoint  tag a51fe2f37349d771  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,103,35,76,77,74,92,33,104,34,31,32
	btf_id 171
505: sched_cls  name cil_from_container  tag 44c79a501deb1caf  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 104,70
	btf_id 172
506: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,104
	btf_id 173
507: sched_cls  name tail_handle_ipv4_cont  tag ddcbe8b24ba44001  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,103,35,92,76,77,33,70,68,71,104,34,31,32,75
	btf_id 174
509: sched_cls  name tail_ipv4_ct_egress  tag e746dd46a3424048  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,104,76,77,103,78
	btf_id 176
510: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
513: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
514: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
517: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
518: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 178
519: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,107
	btf_id 179
520: sched_cls  name tail_handle_ipv4_from_host  tag eb04014f53c29372  gpl
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,107
	btf_id 180
522: sched_cls  name __send_drop_notify  tag ea7201216168bfb9  gpl
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 182
524: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 70,69,107
	btf_id 184
526: sched_cls  name __send_drop_notify  tag ea7201216168bfb9  gpl
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 187
529: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 190
530: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,110
	btf_id 191
531: sched_cls  name tail_handle_ipv4_from_host  tag eb04014f53c29372  gpl
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,110
	btf_id 192
532: sched_cls  name __send_drop_notify  tag ea7201216168bfb9  gpl
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 194
533: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 70,111,69
	btf_id 195
536: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,111
	btf_id 198
537: sched_cls  name tail_handle_ipv4_from_host  tag eb04014f53c29372  gpl
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,111
	btf_id 199
539: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
542: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
543: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
546: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
586: sched_cls  name tail_handle_ipv4  tag 646a4102acb81f42  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,127
	btf_id 215
587: sched_cls  name tail_ipv4_ct_ingress  tag b8571b4c572df394  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,127,76,77,126,78
	btf_id 216
588: sched_cls  name tail_handle_ipv4_cont  tag 8573fa6e1dcb45ef  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,126,35,125,76,77,33,70,68,71,127,34,31,32,75
	btf_id 217
589: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,127
	btf_id 218
590: sched_cls  name tail_handle_arp  tag fb91826926cb4272  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,127
	btf_id 219
591: sched_cls  name __send_drop_notify  tag ff3256a1b4d78509  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 220
592: sched_cls  name cil_from_container  tag 9942ac8d9bbd9d4a  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 127,70
	btf_id 221
593: sched_cls  name tail_ipv4_to_endpoint  tag be30c196490b1e3e  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,126,35,76,77,74,125,33,127,34,31,32
	btf_id 222
594: sched_cls  name handle_policy  tag b3102f8bb9f39dec  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,127,76,77,126,35,74,125,33,78,69,34,31,32
	btf_id 223
595: sched_cls  name tail_ipv4_ct_egress  tag 27e30eb64d3b3a1e  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,127,76,77,126,78
	btf_id 224
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
613: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
616: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
617: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
620: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
621: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
624: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
