REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     10202     797849      677    bpf_overlay.c
Interface                 INGRESS     219929    100734852   1132   bpf_host.c
Success                   EGRESS      10355     810339      53     encap.h
Success                   EGRESS      5295      406684      1694   bpf_host.c
Success                   EGRESS      93090     12386358    1308   bpf_lxc.c
Success                   INGRESS     103454    12730403    86     l3.h
Success                   INGRESS     109010    13165474    235    trace.h
Unsupported L3 protocol   EGRESS      36        2672        1492   bpf_lxc.c
