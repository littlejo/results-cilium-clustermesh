CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0d2907f9_0a21_427c_9b57_f4c049dbc8b3.slice/cri-containerd-ca6f19a41a65cf5eb256942c082d4ce004b4cc758c9ac6cd8fac4c78ba9a3957.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0d2907f9_0a21_427c_9b57_f4c049dbc8b3.slice/cri-containerd-9966a87c9c7d8684d8e99bb5fc8f6bdf30a6638db414a3fa2414d2c5a1b2cda1.scope
    72       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9b14d28b_cf0f_4b90_8976_a5b8a4e73b50.slice/cri-containerd-e951c08860a23a95a88efc15389659a828e6b1a288dd3d138d2d0c2a2d36c3dc.scope
    110      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9b14d28b_cf0f_4b90_8976_a5b8a4e73b50.slice/cri-containerd-864517eca70ceda615b5fda7a71b488913188561d904a56d1a038e17f5f18ab1.scope
    61       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod46d9313d_2290_4c5a_9824_52b848398c1b.slice/cri-containerd-9e6199b9eb866c92bbbd170c5985c9fa60e727e738e9f1aa79c357f54018f329.scope
    513      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod46d9313d_2290_4c5a_9824_52b848398c1b.slice/cri-containerd-760807479e09239167e726554d9fc5f21e1ce31a223cbcece52a0c565f2cc5ab.scope
    542      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod551ff9fe_8b88_4504_a4b8_6e1ef7850f55.slice/cri-containerd-6a7f062d71d20774b8ab0ba0cfb582ef19bcdf6c5434ebcb8ca41e17bd86cdec.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod551ff9fe_8b88_4504_a4b8_6e1ef7850f55.slice/cri-containerd-6d6c8f957534367d275e77e6d869603a9d7fa98ee68f000252be48db4c78cc57.scope
    517      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1cef6352_c506_4306_80c3_dde98825cbf5.slice/cri-containerd-82182139dcd0d9b8612482d1fe462ec4690439f9e08a50807f896cd3916db4d7.scope
    616      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1cef6352_c506_4306_80c3_dde98825cbf5.slice/cri-containerd-25d8e067d62f5b7c6689cf2b3c1d4b0a155413cd8474f9ed5e1108e57409e601.scope
    620      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1cef6352_c506_4306_80c3_dde98825cbf5.slice/cri-containerd-3b37745bab3dda2d6a0ee5368f5dae2f671e34dd3b1d125f7731b89925da1603.scope
    624      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1cef6352_c506_4306_80c3_dde98825cbf5.slice/cri-containerd-ddf607b675a2028a88f59d50356b4c9cffffc1a1829272c3771eb053fa29ec57.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4d356fb0_0194_4671_b73b_93c072900020.slice/cri-containerd-09577a71a67c4055b146deea2e1425f0149d8a5549ecd49d75d0e3825f9dd555.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4d356fb0_0194_4671_b73b_93c072900020.slice/cri-containerd-25fad6edcdccb100b3de890e2339d163f98f5605031a6be55e26ee2730593b5e.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7d77a267_cdcc_4c97_a0e3_4c6d42a36679.slice/cri-containerd-85c786123f945a39d95aaa964a369597d179daa73a339120f48711424cd39089.scope
    69       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7d77a267_cdcc_4c97_a0e3_4c6d42a36679.slice/cri-containerd-3b5d6487e8ddadb7ad91737a5b9c8240c83c3ceab525ea25c0120ac8ead5247f.scope
    83       cgroup_device   multi                                          
