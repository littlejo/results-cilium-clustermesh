key: d3 00 00 00  value: f3 01 00 00
key: b4 02 00 00  value: e9 01 00 00
key: b6 02 00 00  value: 52 02 00 00
key: 38 04 00 00  value: e3 01 00 00
Found 4 elements
