[
  {
    "containers": [
      {
        "cgroup-id": 7031,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod551ff9fe_8b88_4504_a4b8_6e1ef7850f55.slice/cri-containerd-6a7f062d71d20774b8ab0ba0cfb582ef19bcdf6c5434ebcb8ca41e17bd86cdec.scope"
      }
    ],
    "ips": [
      "10.63.0.34"
    ],
    "name": "coredns-cc6ccd49c-9xm8p",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7115,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod46d9313d_2290_4c5a_9824_52b848398c1b.slice/cri-containerd-760807479e09239167e726554d9fc5f21e1ce31a223cbcece52a0c565f2cc5ab.scope"
      }
    ],
    "ips": [
      "10.63.0.119"
    ],
    "name": "coredns-cc6ccd49c-h5fpx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8543,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1cef6352_c506_4306_80c3_dde98825cbf5.slice/cri-containerd-25d8e067d62f5b7c6689cf2b3c1d4b0a155413cd8474f9ed5e1108e57409e601.scope"
      },
      {
        "cgroup-id": 8459,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1cef6352_c506_4306_80c3_dde98825cbf5.slice/cri-containerd-82182139dcd0d9b8612482d1fe462ec4690439f9e08a50807f896cd3916db4d7.scope"
      },
      {
        "cgroup-id": 8627,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1cef6352_c506_4306_80c3_dde98825cbf5.slice/cri-containerd-3b37745bab3dda2d6a0ee5368f5dae2f671e34dd3b1d125f7731b89925da1603.scope"
      }
    ],
    "ips": [
      "10.63.0.75"
    ],
    "name": "clustermesh-apiserver-9b89f5589-td8k7",
    "namespace": "kube-system"
  }
]

