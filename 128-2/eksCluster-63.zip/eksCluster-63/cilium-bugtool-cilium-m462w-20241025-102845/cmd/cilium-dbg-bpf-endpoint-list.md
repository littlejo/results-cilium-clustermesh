IP ADDRESS         LOCAL ENDPOINT INFO
10.63.0.92:0       id=692   sec_id=4     flags=0x0000 ifindex=7   mac=06:84:E3:E3:B1:66 nodemac=16:22:96:B1:98:B3     
10.63.0.119:0      id=211   sec_id=4207172 flags=0x0000 ifindex=9   mac=7E:B8:B6:6A:1F:36 nodemac=9E:B5:59:D4:E7:01   
10.63.0.115:0      (localhost)                                                                                        
10.63.0.34:0       id=1080  sec_id=4207172 flags=0x0000 ifindex=11  mac=BA:31:28:B0:51:B9 nodemac=06:6F:F9:53:6E:A6   
10.63.0.75:0       id=694   sec_id=4216907 flags=0x0000 ifindex=15  mac=B2:DC:9E:9A:87:80 nodemac=EE:9E:46:23:26:79   
172.31.240.216:0   (localhost)                                                                                        
