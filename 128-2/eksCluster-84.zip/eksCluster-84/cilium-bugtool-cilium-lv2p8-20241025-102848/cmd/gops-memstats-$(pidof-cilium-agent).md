alloc: 109.67MB (114995840 bytes)
total-alloc: 1.36GB (1458573208 bytes)
sys: 214.45MB (224863572 bytes)
lookups: 0
mallocs: 48116360
frees: 46900501
heap-alloc: 109.67MB (114995840 bytes)
heap-sys: 169.32MB (177545216 bytes)
heap-idle: 43.02MB (45105152 bytes)
heap-in-use: 126.30MB (132440064 bytes)
heap-released: 2.00MB (2097152 bytes)
heap-objects: 1215859
stack-in-use: 34.66MB (36339712 bytes)
stack-sys: 34.66MB (36339712 bytes)
stack-mspan-inuse: 2.11MB (2209920 bytes)
stack-mspan-sys: 2.49MB (2611200 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 881.46KB (902617 bytes)
gc-sys: 5.22MB (5468440 bytes)
next-gc: when heap-alloc >= 145.74MB (152814936 bytes)
last-gc: 2024-10-25 10:28:52.306173336 +0000 UTC
gc-pause-total: 8.676437ms
gc-pause: 109810
gc-pause-end: 1729852132306173336
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00030784823559090794
enable-gc: true
debug-gc: false
