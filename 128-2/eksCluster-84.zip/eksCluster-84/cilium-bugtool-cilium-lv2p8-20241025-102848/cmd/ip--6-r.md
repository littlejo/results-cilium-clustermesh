fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxca3b774e8ca32 proto kernel metric 256 pref medium
fe80::/64 dev lxc90737d2ffded proto kernel metric 256 pref medium
fe80::/64 dev lxccaa468e91b4c proto kernel metric 256 pref medium
