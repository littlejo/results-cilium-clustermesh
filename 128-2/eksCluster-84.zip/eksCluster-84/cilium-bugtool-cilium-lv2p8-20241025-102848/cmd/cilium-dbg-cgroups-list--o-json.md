[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a0873d7_8c62_4b97_a92c_3d509c14b794.slice/cri-containerd-9532383d5f044675a1ebc7677a9c2e52c0ed2c3400e303a2d87abd5ca7a7bc6c.scope"
      }
    ],
    "ips": [
      "10.84.0.241"
    ],
    "name": "coredns-cc6ccd49c-725lp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7530,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6630974b_fa88_473b_9e03_1e9bda228501.slice/cri-containerd-041c283966a5e963384126a8f12fce63e8f0153dc760eef07aac0c86c9de1289.scope"
      }
    ],
    "ips": [
      "10.84.0.17"
    ],
    "name": "coredns-cc6ccd49c-qsz62",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd085406e_8a70_423b_8ffc_54afeaa8178d.slice/cri-containerd-1e9a995f7635c8a5c67d794dfbb7d8f196521f2742443d1c014cff6cfb940fc9.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd085406e_8a70_423b_8ffc_54afeaa8178d.slice/cri-containerd-4e49c16855a4ab8f21ff53ca30af245292961d5e70b1f858e0b1b33f2bc813a4.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd085406e_8a70_423b_8ffc_54afeaa8178d.slice/cri-containerd-456819600065b2660786e702a1ed753ca25b6370e7f3a0f173615e6617cea78a.scope"
      }
    ],
    "ips": [
      "10.84.0.191"
    ],
    "name": "clustermesh-apiserver-6664d8fd7c-xfwcp",
    "namespace": "kube-system"
  }
]

