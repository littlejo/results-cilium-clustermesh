1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:2f:2c:f1:77:27 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.140.168/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2677sec preferred_lft 2677sec
    inet6 fe80::42f:2cff:fef1:7727/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:8f:e7:07:d3:ef brd ff:ff:ff:ff:ff:ff
    inet6 fe80::808f:e7ff:fe07:d3ef/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:10:40:c4:46:90 brd ff:ff:ff:ff:ff:ff
    inet 10.84.0.62/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::3410:40ff:fec4:4690/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 42:53:dd:e9:83:a6 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4053:ddff:fee9:83a6/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc_health@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:d5:a3:55:a2:98 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d4d5:a3ff:fe55:a298/64 scope link 
       valid_lft forever preferred_lft forever
11: lxca3b774e8ca32@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:e7:c6:dc:4f:b1 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::fce7:c6ff:fedc:4fb1/64 scope link 
       valid_lft forever preferred_lft forever
13: lxc90737d2ffded@if12: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:0e:ea:3d:1a:4e brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::d40e:eaff:fe3d:1a4e/64 scope link 
       valid_lft forever preferred_lft forever
17: lxccaa468e91b4c@if16: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:c2:5e:fb:5c:e6 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c4c2:5eff:fefb:5ce6/64 scope link 
       valid_lft forever preferred_lft forever
