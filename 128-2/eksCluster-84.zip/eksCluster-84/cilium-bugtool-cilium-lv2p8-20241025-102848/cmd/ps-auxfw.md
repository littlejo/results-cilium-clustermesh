USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         890  0.0  0.2 1616520 8772 ?        Ssl  10:28   0:00 /usr/sbin/runc init
root         872  0.0  0.0   2208   792 ?        Ss   10:28   0:00 timeout --signal SIGINT --preserve-status 5 bash -c hubble observe --last 10000 --debug -o jsonpb
root         878  5.0  0.5 1244340 21848 ?       Sl   10:28   0:00  \_ hubble observe --last 10000 --debug -o jsonpb
root         855  1.0  0.4 1240432 15804 ?       Dsl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         897  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         899  0.0  0.4 1240432 15804 ?       R    10:28   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  2.6  7.2 1538164 284440 ?      Ssl  10:13   0:23 cilium-agent --config-dir=/tmp/cilium/config-map
root         593  0.0  0.1 1228848 6896 ?        Sl   10:14   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
