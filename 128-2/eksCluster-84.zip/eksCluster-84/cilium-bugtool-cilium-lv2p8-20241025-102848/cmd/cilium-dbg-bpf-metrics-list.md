REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10193     798870     677    bpf_overlay.c
Interface                 INGRESS     224639    85743665   1132   bpf_host.c
Success                   EGRESS      10306     807825     53     encap.h
Success                   EGRESS      5228      402134     1694   bpf_host.c
Success                   EGRESS      93602     12424349   1308   bpf_lxc.c
Success                   INGRESS     104159    12813639   86     l3.h
Success                   INGRESS     109773    13254281   235    trace.h
Unsupported L3 protocol   EGRESS      46        3524       1492   bpf_lxc.c
