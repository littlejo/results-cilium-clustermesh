filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxca3b774e8ca32 direct-action not_in_hw id 531 tag 3d8131c787e3c2c2 jited 
