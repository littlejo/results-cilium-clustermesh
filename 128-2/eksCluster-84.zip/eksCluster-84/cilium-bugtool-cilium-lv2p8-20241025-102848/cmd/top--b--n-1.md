top - 10:28:50 up 15 min,  0 users,  load average: 0.08, 0.18, 0.14
Tasks:   8 total,   2 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 59.4 us, 34.4 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  6.2 si,  0.0 st
MiB Mem :   3836.2 total,    777.1 free,    917.0 used,   2142.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2750.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    878 root      20   0 1244340  22524  14524 S  37.5   0.6   0:00.17 hubble
      1 root      20   0 1538164 284440  77884 S  12.5   7.2   0:24.02 cilium-+
    593 root      20   0 1228848   6896   3836 S   0.0   0.2   0:00.27 cilium-+
    855 root      20   0 1240432  15804  10960 S   0.0   0.4   0:00.03 cilium-+
    872 root      20   0    2208    792    716 S   0.0   0.0   0:00.00 timeout
    890 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    920 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    944 root      20   0    3784    400    360 R   0.0   0.0   0:00.00 bash
