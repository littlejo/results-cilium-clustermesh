Node 0, zone      DMA      0      2      0      3      4     10      7      2      2      3    167 
Node 0, zone   Normal    864    101     14     31     22      5      2      2      1      2      7 
