Endpoint ID: 427
Path: /sys/fs/bpf/tc/globals/cilium_policy_00427

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    84404   970       0        
Allow    Egress      0          ANY          NONE         disabled    13371   140       0        


Endpoint ID: 1154
Path: /sys/fs/bpf/tc/globals/cilium_policy_01154

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3909712   36847     0        
Allow    Ingress     1          ANY          NONE         disabled    3103743   31283     0        
Allow    Egress      0          ANY          NONE         disabled    4707240   43589     0        


Endpoint ID: 1400
Path: /sys/fs/bpf/tc/globals/cilium_policy_01400

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    83765   963       0        
Allow    Egress      0          ANY          NONE         disabled    14046   147       0        


Endpoint ID: 2576
Path: /sys/fs/bpf/tc/globals/cilium_policy_02576

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    441338   5623      0        
Allow    Ingress     1          ANY          NONE         disabled    12690    147       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 3087
Path: /sys/fs/bpf/tc/globals/cilium_policy_03087

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


