CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4eb0b95e_1563_40bd_8d70_77b047656c05.slice/cri-containerd-44e22d305dd90a3476e7578331a9492e10730318b886f8a6ab320c6b33a83870.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4eb0b95e_1563_40bd_8d70_77b047656c05.slice/cri-containerd-0defdaff992f061a5704cba3530a2e20e6f1c904784655ab7143021f2073d606.scope
    67       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03346f5c_0413_440b_9834_34b153a0fb7f.slice/cri-containerd-1374bd6af09d1a97fcdba82649d7f47c4c8b23179c32e4218b603b946cafe4d3.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03346f5c_0413_440b_9834_34b153a0fb7f.slice/cri-containerd-dd516a538cb9b3f44f0c73abdc4902261799ce0eba7c261e1e101ef92154c0c4.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a0873d7_8c62_4b97_a92c_3d509c14b794.slice/cri-containerd-9532383d5f044675a1ebc7677a9c2e52c0ed2c3400e303a2d87abd5ca7a7bc6c.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a0873d7_8c62_4b97_a92c_3d509c14b794.slice/cri-containerd-06686bbec6123a7e0958c8420c3e87ed6a27712289698e00de5c6c498a5370c1.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6630974b_fa88_473b_9e03_1e9bda228501.slice/cri-containerd-041c283966a5e963384126a8f12fce63e8f0153dc760eef07aac0c86c9de1289.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6630974b_fa88_473b_9e03_1e9bda228501.slice/cri-containerd-237dd3e79b2ebfd6698741c332fb74af54880cef670b5512a96b199207d98c30.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd085406e_8a70_423b_8ffc_54afeaa8178d.slice/cri-containerd-4e49c16855a4ab8f21ff53ca30af245292961d5e70b1f858e0b1b33f2bc813a4.scope
    628      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd085406e_8a70_423b_8ffc_54afeaa8178d.slice/cri-containerd-79ea38f19707159c8f2df946b748f4e9c1c0df8b40fed10acd314b641b4aa050.scope
    612      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd085406e_8a70_423b_8ffc_54afeaa8178d.slice/cri-containerd-1e9a995f7635c8a5c67d794dfbb7d8f196521f2742443d1c014cff6cfb940fc9.scope
    632      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd085406e_8a70_423b_8ffc_54afeaa8178d.slice/cri-containerd-456819600065b2660786e702a1ed753ca25b6370e7f3a0f173615e6617cea78a.scope
    636      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82df4ba2_93da_4df1_85c2_0dd6baf765cc.slice/cri-containerd-2138655d39b95775cb663a504dcb303f48fad4daf2c54ebc7f6899c34c0e11e4.scope
    71       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82df4ba2_93da_4df1_85c2_0dd6baf765cc.slice/cri-containerd-4fc38002db0420fd91ad43c68b16b0b5c207f5ca13a8d8d4eb3379121b16c2ff.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc179b25_d003_46d5_9b40_05e1ef50d354.slice/cri-containerd-0abe0896fc6e27020b36880a8cbe000897ac60c64e8d1fe6b6ea4dd74dc0fe05.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc179b25_d003_46d5_9b40_05e1ef50d354.slice/cri-containerd-87efacd144f157ff6b2d43b1d4779649116d36297b35cfff0beaf42cc5d4b9c6.scope
    79       cgroup_device   multi                                          
