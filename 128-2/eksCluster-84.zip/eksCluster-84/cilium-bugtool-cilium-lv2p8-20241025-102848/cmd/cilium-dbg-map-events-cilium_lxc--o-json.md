{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:10.609Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.140.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:10.609Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:15.509Z",
  "value": "id=2576  sec_id=4     flags=0x0000 ifindex=9   mac=A2:27:5D:26:74:69 nodemac=D6:D5:A3:55:A2:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:15.539Z",
  "value": "id=2576  sec_id=4     flags=0x0000 ifindex=9   mac=A2:27:5D:26:74:69 nodemac=D6:D5:A3:55:A2:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:19.822Z",
  "value": "id=2576  sec_id=4     flags=0x0000 ifindex=9   mac=A2:27:5D:26:74:69 nodemac=D6:D5:A3:55:A2:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:19.859Z",
  "value": "id=427   sec_id=5598271 flags=0x0000 ifindex=11  mac=F6:EA:86:0D:2A:FB nodemac=FE:E7:C6:DC:4F:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:19.860Z",
  "value": "id=427   sec_id=5598271 flags=0x0000 ifindex=11  mac=F6:EA:86:0D:2A:FB nodemac=FE:E7:C6:DC:4F:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:20.821Z",
  "value": "id=427   sec_id=5598271 flags=0x0000 ifindex=11  mac=F6:EA:86:0D:2A:FB nodemac=FE:E7:C6:DC:4F:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:20.822Z",
  "value": "id=2576  sec_id=4     flags=0x0000 ifindex=9   mac=A2:27:5D:26:74:69 nodemac=D6:D5:A3:55:A2:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:34.843Z",
  "value": "id=1400  sec_id=5598271 flags=0x0000 ifindex=13  mac=72:F7:05:8F:4E:50 nodemac=D6:0E:EA:3D:1A:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:46.069Z",
  "value": "id=1400  sec_id=5598271 flags=0x0000 ifindex=13  mac=72:F7:05:8F:4E:50 nodemac=D6:0E:EA:3D:1A:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:46.071Z",
  "value": "id=427   sec_id=5598271 flags=0x0000 ifindex=11  mac=F6:EA:86:0D:2A:FB nodemac=FE:E7:C6:DC:4F:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:46.071Z",
  "value": "id=2576  sec_id=4     flags=0x0000 ifindex=9   mac=A2:27:5D:26:74:69 nodemac=D6:D5:A3:55:A2:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:46.103Z",
  "value": "id=158   sec_id=5578572 flags=0x0000 ifindex=15  mac=0A:3E:B4:A7:D7:10 nodemac=5E:4A:91:CA:EE:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:46.104Z",
  "value": "id=158   sec_id=5578572 flags=0x0000 ifindex=15  mac=0A:3E:B4:A7:D7:10 nodemac=5E:4A:91:CA:EE:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:47.069Z",
  "value": "id=2576  sec_id=4     flags=0x0000 ifindex=9   mac=A2:27:5D:26:74:69 nodemac=D6:D5:A3:55:A2:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:47.069Z",
  "value": "id=1400  sec_id=5598271 flags=0x0000 ifindex=13  mac=72:F7:05:8F:4E:50 nodemac=D6:0E:EA:3D:1A:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:47.069Z",
  "value": "id=158   sec_id=5578572 flags=0x0000 ifindex=15  mac=0A:3E:B4:A7:D7:10 nodemac=5E:4A:91:CA:EE:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:47.069Z",
  "value": "id=427   sec_id=5598271 flags=0x0000 ifindex=11  mac=F6:EA:86:0D:2A:FB nodemac=FE:E7:C6:DC:4F:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:00.805Z",
  "value": "id=1154  sec_id=5578572 flags=0x0000 ifindex=17  mac=D2:EE:A7:66:B9:2C nodemac=C6:C2:5E:FB:5C:E6"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.84.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:11.084Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.056Z",
  "value": "id=1400  sec_id=5598271 flags=0x0000 ifindex=13  mac=72:F7:05:8F:4E:50 nodemac=D6:0E:EA:3D:1A:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.057Z",
  "value": "id=1154  sec_id=5578572 flags=0x0000 ifindex=17  mac=D2:EE:A7:66:B9:2C nodemac=C6:C2:5E:FB:5C:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.057Z",
  "value": "id=2576  sec_id=4     flags=0x0000 ifindex=9   mac=A2:27:5D:26:74:69 nodemac=D6:D5:A3:55:A2:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.058Z",
  "value": "id=427   sec_id=5598271 flags=0x0000 ifindex=11  mac=F6:EA:86:0D:2A:FB nodemac=FE:E7:C6:DC:4F:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:58.057Z",
  "value": "id=2576  sec_id=4     flags=0x0000 ifindex=9   mac=A2:27:5D:26:74:69 nodemac=D6:D5:A3:55:A2:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:58.057Z",
  "value": "id=1400  sec_id=5598271 flags=0x0000 ifindex=13  mac=72:F7:05:8F:4E:50 nodemac=D6:0E:EA:3D:1A:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:58.058Z",
  "value": "id=427   sec_id=5598271 flags=0x0000 ifindex=11  mac=F6:EA:86:0D:2A:FB nodemac=FE:E7:C6:DC:4F:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:58.058Z",
  "value": "id=1154  sec_id=5578572 flags=0x0000 ifindex=17  mac=D2:EE:A7:66:B9:2C nodemac=C6:C2:5E:FB:5C:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:59.058Z",
  "value": "id=427   sec_id=5598271 flags=0x0000 ifindex=11  mac=F6:EA:86:0D:2A:FB nodemac=FE:E7:C6:DC:4F:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:59.058Z",
  "value": "id=1400  sec_id=5598271 flags=0x0000 ifindex=13  mac=72:F7:05:8F:4E:50 nodemac=D6:0E:EA:3D:1A:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:59.058Z",
  "value": "id=1154  sec_id=5578572 flags=0x0000 ifindex=17  mac=D2:EE:A7:66:B9:2C nodemac=C6:C2:5E:FB:5C:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:59.058Z",
  "value": "id=2576  sec_id=4     flags=0x0000 ifindex=9   mac=A2:27:5D:26:74:69 nodemac=D6:D5:A3:55:A2:98"
}

