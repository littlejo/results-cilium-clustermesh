ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.160.174:443 (active)    
                                         2 => 172.31.215.232:443 (active)    
2    10.100.103.179:443   ClusterIP      1 => 172.31.140.168:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.84.0.17:53 (active)         
                                         2 => 10.84.0.241:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.84.0.17:9153 (active)       
                                         2 => 10.84.0.241:9153 (active)      
5    10.100.55.105:2379   ClusterIP      1 => 10.84.0.191:2379 (active)      
