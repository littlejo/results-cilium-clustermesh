xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 494
cilium_net(5) clsact/ingress cil_to_host-cilium_net id 488
cilium_host(6) clsact/ingress cil_to_host-cilium_host id 480
cilium_host(6) clsact/egress cil_from_host-cilium_host id 479
cilium_vxlan(7) clsact/ingress cil_from_overlay-cilium_vxlan id 477
cilium_vxlan(7) clsact/egress cil_to_overlay-cilium_vxlan id 474
lxc_health(9) clsact/ingress cil_from_container-lxc_health id 519
lxca3b774e8ca32(11) clsact/ingress cil_from_container-lxca3b774e8ca32 id 531
lxc90737d2ffded(13) clsact/ingress cil_from_container-lxc90737d2ffded id 541
lxccaa468e91b4c(17) clsact/ingress cil_from_container-lxccaa468e91b4c id 605

flow_dissector:

netfilter:

