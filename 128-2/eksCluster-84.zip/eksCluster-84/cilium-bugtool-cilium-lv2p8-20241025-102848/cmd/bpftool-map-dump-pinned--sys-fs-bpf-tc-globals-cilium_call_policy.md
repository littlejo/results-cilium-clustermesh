key: ab 01 00 00  value: 0a 02 00 00
key: 82 04 00 00  value: 5c 02 00 00
key: 78 05 00 00  value: 23 02 00 00
key: 10 0a 00 00  value: ff 01 00 00
Found 4 elements
