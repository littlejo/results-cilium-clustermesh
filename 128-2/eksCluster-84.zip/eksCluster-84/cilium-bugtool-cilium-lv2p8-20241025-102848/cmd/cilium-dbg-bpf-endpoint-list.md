IP ADDRESS         LOCAL ENDPOINT INFO
10.84.0.62:0       (localhost)                                                                                        
10.84.0.106:0      id=2576  sec_id=4     flags=0x0000 ifindex=9   mac=A2:27:5D:26:74:69 nodemac=D6:D5:A3:55:A2:98     
10.84.0.191:0      id=1154  sec_id=5578572 flags=0x0000 ifindex=17  mac=D2:EE:A7:66:B9:2C nodemac=C6:C2:5E:FB:5C:E6   
10.84.0.241:0      id=1400  sec_id=5598271 flags=0x0000 ifindex=13  mac=72:F7:05:8F:4E:50 nodemac=D6:0E:EA:3D:1A:4E   
172.31.140.168:0   (localhost)                                                                                        
10.84.0.17:0       id=427   sec_id=5598271 flags=0x0000 ifindex=11  mac=F6:EA:86:0D:2A:FB nodemac=FE:E7:C6:DC:4F:B1   
