alloc: 103.52MB (108552400 bytes)
total-alloc: 1.36GB (1463557064 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 48246510
frees: 47114535
heap-alloc: 103.52MB (108552400 bytes)
heap-sys: 165.26MB (173285376 bytes)
heap-idle: 44.34MB (46497792 bytes)
heap-in-use: 120.91MB (126787584 bytes)
heap-released: 11.82MB (12394496 bytes)
heap-objects: 1131975
stack-in-use: 34.72MB (36405248 bytes)
stack-sys: 34.72MB (36405248 bytes)
stack-mspan-inuse: 2.01MB (2107680 bytes)
stack-mspan-sys: 2.40MB (2513280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 991.69KB (1015489 bytes)
gc-sys: 5.14MB (5390568 bytes)
next-gc: when heap-alloc >= 146.42MB (153527576 bytes)
last-gc: 2024-10-25 10:28:43.057857044 +0000 UTC
gc-pause-total: 10.2658ms
gc-pause: 1002575
gc-pause-end: 1729852123057857044
num-gc: 74
num-forced-gc: 0
gc-cpu-fraction: 0.00037091720888314674
enable-gc: true
debug-gc: false
