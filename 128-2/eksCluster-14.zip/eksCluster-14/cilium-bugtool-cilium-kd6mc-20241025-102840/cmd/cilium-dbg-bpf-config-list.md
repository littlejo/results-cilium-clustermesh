KEY             VALUE
AgentLiveness   980764691900
UTimeOffset     3378615570312500
