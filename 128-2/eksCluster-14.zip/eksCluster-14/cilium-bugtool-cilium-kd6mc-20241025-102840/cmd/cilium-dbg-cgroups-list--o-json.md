[
  {
    "containers": [
      {
        "cgroup-id": 6779,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8e130850_4584_468e_b594_1e72cfdda1c9.slice/cri-containerd-096a47292682768a69ec97c38ccba79aa3663b475dcc183f75b8725460182969.scope"
      }
    ],
    "ips": [
      "10.14.0.138"
    ],
    "name": "coredns-cc6ccd49c-k6k4d",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8207,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod624e929c_fbab_4402_b67f_8c5d8ca4b5ae.slice/cri-containerd-726d12621535e1768ae3e640c387b62249354a236354ff3e9514feaf71b4873e.scope"
      },
      {
        "cgroup-id": 8375,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod624e929c_fbab_4402_b67f_8c5d8ca4b5ae.slice/cri-containerd-38d4f891543be90bdf00d38cfddebe82ea207673c05bfd81a7244013dd4b1379.scope"
      },
      {
        "cgroup-id": 8291,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod624e929c_fbab_4402_b67f_8c5d8ca4b5ae.slice/cri-containerd-86262780ae9387fdaae818f17685c146965427f7780cd6c520d94af563aeda16.scope"
      }
    ],
    "ips": [
      "10.14.0.45"
    ],
    "name": "clustermesh-apiserver-6cbc459966-bk2cs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6863,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode333150c_c25a_440c_a185_40835862ff90.slice/cri-containerd-157eb4c554ca71613b096149693405d59bb8f5bb8343a6689c29f1b520ae29dc.scope"
      }
    ],
    "ips": [
      "10.14.0.205"
    ],
    "name": "coredns-cc6ccd49c-7qnfm",
    "namespace": "kube-system"
  }
]

