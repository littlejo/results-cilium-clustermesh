ID   Frontend            Service Type   Backend                            
1    10.100.0.1:443      ClusterIP      1 => 172.31.215.230:443 (active)   
                                        2 => 172.31.156.132:443 (active)   
2    10.100.67.62:443    ClusterIP      1 => 172.31.147.77:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.14.0.138:53 (active)       
                                        2 => 10.14.0.205:53 (active)       
4    10.100.0.10:9153    ClusterIP      1 => 10.14.0.138:9153 (active)     
                                        2 => 10.14.0.205:9153 (active)     
5    10.100.27.66:2379   ClusterIP      1 => 10.14.0.45:2379 (active)      
