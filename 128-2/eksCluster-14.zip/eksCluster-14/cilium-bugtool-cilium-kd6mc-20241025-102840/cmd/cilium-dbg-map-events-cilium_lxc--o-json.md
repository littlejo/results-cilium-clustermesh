{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.205Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.147.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.205Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:43.011Z",
  "value": "id=2845  sec_id=1041050 flags=0x0000 ifindex=9   mac=8E:9B:F6:75:4D:11 nodemac=3A:A1:16:A1:27:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:43.016Z",
  "value": "id=1971  sec_id=4     flags=0x0000 ifindex=7   mac=EE:0A:A3:FA:6A:4B nodemac=62:1F:66:D8:83:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:43.062Z",
  "value": "id=930   sec_id=1041050 flags=0x0000 ifindex=11  mac=92:12:BD:4C:02:04 nodemac=36:C6:B7:5D:FB:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:43.161Z",
  "value": "id=2845  sec_id=1041050 flags=0x0000 ifindex=9   mac=8E:9B:F6:75:4D:11 nodemac=3A:A1:16:A1:27:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:43.231Z",
  "value": "id=1971  sec_id=4     flags=0x0000 ifindex=7   mac=EE:0A:A3:FA:6A:4B nodemac=62:1F:66:D8:83:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:00.498Z",
  "value": "id=930   sec_id=1041050 flags=0x0000 ifindex=11  mac=92:12:BD:4C:02:04 nodemac=36:C6:B7:5D:FB:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:00.499Z",
  "value": "id=1971  sec_id=4     flags=0x0000 ifindex=7   mac=EE:0A:A3:FA:6A:4B nodemac=62:1F:66:D8:83:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:00.500Z",
  "value": "id=2845  sec_id=1041050 flags=0x0000 ifindex=9   mac=8E:9B:F6:75:4D:11 nodemac=3A:A1:16:A1:27:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:00.528Z",
  "value": "id=2016  sec_id=1013686 flags=0x0000 ifindex=13  mac=52:14:DE:D6:BD:07 nodemac=96:2E:2D:14:4A:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:00.529Z",
  "value": "id=2016  sec_id=1013686 flags=0x0000 ifindex=13  mac=52:14:DE:D6:BD:07 nodemac=96:2E:2D:14:4A:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:01.498Z",
  "value": "id=2016  sec_id=1013686 flags=0x0000 ifindex=13  mac=52:14:DE:D6:BD:07 nodemac=96:2E:2D:14:4A:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:01.498Z",
  "value": "id=2845  sec_id=1041050 flags=0x0000 ifindex=9   mac=8E:9B:F6:75:4D:11 nodemac=3A:A1:16:A1:27:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:01.498Z",
  "value": "id=930   sec_id=1041050 flags=0x0000 ifindex=11  mac=92:12:BD:4C:02:04 nodemac=36:C6:B7:5D:FB:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:01.498Z",
  "value": "id=1971  sec_id=4     flags=0x0000 ifindex=7   mac=EE:0A:A3:FA:6A:4B nodemac=62:1F:66:D8:83:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:01.146Z",
  "value": "id=2788  sec_id=1013686 flags=0x0000 ifindex=15  mac=72:6A:5B:2F:A8:C7 nodemac=D6:4E:0A:8B:59:88"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.14.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.878Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:20.732Z",
  "value": "id=1971  sec_id=4     flags=0x0000 ifindex=7   mac=EE:0A:A3:FA:6A:4B nodemac=62:1F:66:D8:83:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:20.733Z",
  "value": "id=2845  sec_id=1041050 flags=0x0000 ifindex=9   mac=8E:9B:F6:75:4D:11 nodemac=3A:A1:16:A1:27:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:20.733Z",
  "value": "id=930   sec_id=1041050 flags=0x0000 ifindex=11  mac=92:12:BD:4C:02:04 nodemac=36:C6:B7:5D:FB:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:20.734Z",
  "value": "id=2788  sec_id=1013686 flags=0x0000 ifindex=15  mac=72:6A:5B:2F:A8:C7 nodemac=D6:4E:0A:8B:59:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:21.733Z",
  "value": "id=2845  sec_id=1041050 flags=0x0000 ifindex=9   mac=8E:9B:F6:75:4D:11 nodemac=3A:A1:16:A1:27:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:21.733Z",
  "value": "id=930   sec_id=1041050 flags=0x0000 ifindex=11  mac=92:12:BD:4C:02:04 nodemac=36:C6:B7:5D:FB:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:21.733Z",
  "value": "id=2788  sec_id=1013686 flags=0x0000 ifindex=15  mac=72:6A:5B:2F:A8:C7 nodemac=D6:4E:0A:8B:59:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:21.734Z",
  "value": "id=1971  sec_id=4     flags=0x0000 ifindex=7   mac=EE:0A:A3:FA:6A:4B nodemac=62:1F:66:D8:83:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:22.733Z",
  "value": "id=1971  sec_id=4     flags=0x0000 ifindex=7   mac=EE:0A:A3:FA:6A:4B nodemac=62:1F:66:D8:83:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:22.733Z",
  "value": "id=2788  sec_id=1013686 flags=0x0000 ifindex=15  mac=72:6A:5B:2F:A8:C7 nodemac=D6:4E:0A:8B:59:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:22.734Z",
  "value": "id=2845  sec_id=1041050 flags=0x0000 ifindex=9   mac=8E:9B:F6:75:4D:11 nodemac=3A:A1:16:A1:27:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.14.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:22.734Z",
  "value": "id=930   sec_id=1041050 flags=0x0000 ifindex=11  mac=92:12:BD:4C:02:04 nodemac=36:C6:B7:5D:FB:29"
}

