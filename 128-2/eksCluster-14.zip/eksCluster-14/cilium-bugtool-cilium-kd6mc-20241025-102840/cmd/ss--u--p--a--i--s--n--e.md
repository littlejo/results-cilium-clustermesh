Total: 545
TCP:   1298 (estab 297, closed 982, orphaned 0, timewait 526)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  316       306       10       
INET	  326       312       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:21244 sk:341 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15528 sk:342 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:45083      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=41)) ino:21828 sk:343 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.147.77%ens5:68         0.0.0.0:*    uid:192 ino:15755 sk:344 cgroup:unreachable:c4e <->                            
UNCONN 0      0                                 [::]:8472          [::]:*    ino:21243 sk:345 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15529 sk:346 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::451:89ff:fee0:3f05]%ens5:546           [::]:*    uid:192 ino:15753 sk:347 cgroup:unreachable:c4e v6only:1 <->                   
