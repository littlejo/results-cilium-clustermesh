filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc52ed4f63e6df direct-action not_in_hw id 484 tag f6ac4e9e71cac93a jited 
