REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     10176     795280      677    bpf_overlay.c
Interface                 INGRESS     224381    100907594   1132   bpf_host.c
Success                   EGRESS      10402     812287      53     encap.h
Success                   EGRESS      5270      405187      1694   bpf_host.c
Success                   EGRESS      94082     12608216    1308   bpf_lxc.c
Success                   INGRESS     106041    12956420    86     l3.h
Success                   INGRESS     111597    13390489    235    trace.h
Unsupported L3 protocol   EGRESS      36        2672        1492   bpf_lxc.c
