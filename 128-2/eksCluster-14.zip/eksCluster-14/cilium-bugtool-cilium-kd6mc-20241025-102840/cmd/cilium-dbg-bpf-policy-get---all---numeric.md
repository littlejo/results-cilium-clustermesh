Endpoint ID: 319
Path: /sys/fs/bpf/tc/globals/cilium_policy_00319

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 930
Path: /sys/fs/bpf/tc/globals/cilium_policy_00930

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    87792   1008      0        
Allow    Egress      0          ANY          NONE         disabled    14090   147       0        


Endpoint ID: 1971
Path: /sys/fs/bpf/tc/globals/cilium_policy_01971

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    434923   5566      0        
Allow    Ingress     1          ANY          NONE         disabled    13460    159       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2788
Path: /sys/fs/bpf/tc/globals/cilium_policy_02788

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3913291   36908     0        
Allow    Ingress     1          ANY          NONE         disabled    3281751   33393     0        
Allow    Egress      0          ANY          NONE         disabled    4640567   42718     0        


Endpoint ID: 2845
Path: /sys/fs/bpf/tc/globals/cilium_policy_02845

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    87858   1009      0        
Allow    Egress      0          ANY          NONE         disabled    14853   156       0        


