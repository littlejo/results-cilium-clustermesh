key: a2 03 00 00  value: db 01 00 00
key: b3 07 00 00  value: f3 01 00 00
key: e4 0a 00 00  value: 48 02 00 00
key: 1d 0b 00 00  value: e6 01 00 00
Found 4 elements
