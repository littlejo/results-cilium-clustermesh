CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4d22d13a_1ae7_48e9_96f8_fcc0d8223a8f.slice/cri-containerd-92a42db4e427d446c2db614397ad6e49b75f8719544f74f4fa13b04e2051d104.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4d22d13a_1ae7_48e9_96f8_fcc0d8223a8f.slice/cri-containerd-f0c4ed7847b416f1fb429b741f9f396dffdacb93b646df2ab5d0a61777053a79.scope
    71       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode333150c_c25a_440c_a185_40835862ff90.slice/cri-containerd-42a7c2589d11c2f7e1f61ba398324241ff719e3e305ae39f78658e8575e2d8d4.scope
    497      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode333150c_c25a_440c_a185_40835862ff90.slice/cri-containerd-157eb4c554ca71613b096149693405d59bb8f5bb8343a6689c29f1b520ae29dc.scope
    521      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8e130850_4584_468e_b594_1e72cfdda1c9.slice/cri-containerd-a78747fbac09d87a76f2fb6fa20e8272be9dd0c200bbf7ea8a9e760e0949091d.scope
    511      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8e130850_4584_468e_b594_1e72cfdda1c9.slice/cri-containerd-096a47292682768a69ec97c38ccba79aa3663b475dcc183f75b8725460182969.scope
    517      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ef54a46_4554_448c_82ad_ce6586857fbf.slice/cri-containerd-d244b657a2776fc9c9727425884834f60439c7436be1f2e58862051ea7e74178.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ef54a46_4554_448c_82ad_ce6586857fbf.slice/cri-containerd-062f6cb8a8540a18f596fc30c35a6f6e79d45723c9cf33b6a63e19eb61d120b8.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod829953e8_005f_4588_8bd6_fcf11be51e8d.slice/cri-containerd-915dc7ae00cd9bfb6ac3fc4a7b98d3edc2a7622175a199bbffc7e239cc81a64d.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod829953e8_005f_4588_8bd6_fcf11be51e8d.slice/cri-containerd-1cf42d2fc8b930a0274824bf28dd1567460e0b417252cabbad5d9316118d565a.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podccb5fe40_25df_4de1_b7a5_b4fe1ef877b6.slice/cri-containerd-1e26717d2a302709ddaa624ffaa2f2620b71a433c40e5979757a43e6a2209e07.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podccb5fe40_25df_4de1_b7a5_b4fe1ef877b6.slice/cri-containerd-7e1813f17cd883dd7c213567bb649f28dd87685a7892b7583e48d46c1e838d7e.scope
    64       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod624e929c_fbab_4402_b67f_8c5d8ca4b5ae.slice/cri-containerd-726d12621535e1768ae3e640c387b62249354a236354ff3e9514feaf71b4873e.scope
    612      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod624e929c_fbab_4402_b67f_8c5d8ca4b5ae.slice/cri-containerd-38d4f891543be90bdf00d38cfddebe82ea207673c05bfd81a7244013dd4b1379.scope
    620      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod624e929c_fbab_4402_b67f_8c5d8ca4b5ae.slice/cri-containerd-86262780ae9387fdaae818f17685c146965427f7780cd6c520d94af563aeda16.scope
    616      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod624e929c_fbab_4402_b67f_8c5d8ca4b5ae.slice/cri-containerd-42d91b01176e86956ae791e6846361748c468ea789c365414d85817d4b4fd7e3.scope
    596      cgroup_device   multi                                          
