1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:51:89:e0:3f:05 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.147.77/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2659sec preferred_lft 2659sec
    inet6 fe80::451:89ff:fee0:3f05/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:56:a8:cb:e0:ef brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c456:a8ff:fecb:e0ef/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:cc:cf:79:7d:89 brd ff:ff:ff:ff:ff:ff
    inet 10.14.0.231/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a0cc:cfff:fe79:7d89/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ce:ad:b4:dd:65:b1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ccad:b4ff:fedd:65b1/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:1f:66:d8:83:18 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::601f:66ff:fed8:8318/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc52ed4f63e6df@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:a1:16:a1:27:87 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::38a1:16ff:fea1:2787/64 scope link 
       valid_lft forever preferred_lft forever
11: lxca259f915a443@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:c6:b7:5d:fb:29 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::34c6:b7ff:fe5d:fb29/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc32f396bed709@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:4e:0a:8b:59:88 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::d44e:aff:fe8b:5988/64 scope link 
       valid_lft forever preferred_lft forever
