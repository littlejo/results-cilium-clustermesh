35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:54+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:54+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:54+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:54+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:54+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:12:54+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:55+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
61: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
64: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
71: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
72: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
75: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
447: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:40+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 112
448: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:40+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 113
449: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:40+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 114
450: sched_cls  name tail_handle_ipv4  tag 2568e2058bb7e9f3  gpl
	loaded_at 2024-10-25T10:13:40+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 115
473: sched_cls  name cil_from_container  tag 26174962fe7a8d37  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 98,68
	btf_id 141
474: sched_cls  name tail_ipv4_ct_egress  tag 48d430de7fc5755f  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,98,74,75,97,76
	btf_id 142
475: sched_cls  name handle_policy  tag 2a3fcede43315b83  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,98,74,75,97,33,72,96,31,76,67,32,29,30
	btf_id 143
476: sched_cls  name tail_handle_ipv4_cont  tag 6b42267c4f2c613c  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,97,33,96,74,75,31,68,66,69,98,32,29,30,73
	btf_id 144
477: sched_cls  name tail_handle_arp  tag 66bb20ec8ca589be  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,98
	btf_id 145
478: sched_cls  name tail_ipv4_ct_ingress  tag 3b0def5cbe9fe20d  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,98,74,75,97,76
	btf_id 146
479: sched_cls  name tail_handle_ipv4  tag 50be391e009cd1b9  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,98
	btf_id 147
481: sched_cls  name __send_drop_notify  tag c8a89cf0dce6acdf  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 149
482: sched_cls  name tail_ipv4_to_endpoint  tag 99936b8b2f06bdc3  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,97,33,74,75,72,96,31,98,32,29,30
	btf_id 150
483: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,98
	btf_id 151
484: sched_cls  name cil_from_container  tag f6ac4e9e71cac93a  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 99,68
	btf_id 153
485: sched_cls  name tail_ipv4_ct_egress  tag 48d430de7fc5755f  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,99,74,75,100,76
	btf_id 154
486: sched_cls  name handle_policy  tag 425c4e1ae3d7fd3d  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,99,74,75,100,33,72,90,31,76,67,32,29,30
	btf_id 155
487: sched_cls  name tail_handle_arp  tag 278cc87db0f1d32c  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,99
	btf_id 156
488: sched_cls  name tail_ipv4_ct_ingress  tag 138e397e0228902b  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,99,74,75,100,76
	btf_id 157
489: sched_cls  name tail_handle_ipv4_cont  tag b4ecee6bc813d962  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,100,33,90,74,75,31,68,66,69,99,32,29,30,73
	btf_id 158
491: sched_cls  name __send_drop_notify  tag b606ccf05902d066  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 160
492: sched_cls  name tail_handle_ipv4  tag 3ae34363764a4642  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,99
	btf_id 161
493: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
495: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,99
	btf_id 162
497: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
498: sched_cls  name tail_ipv4_to_endpoint  tag a78144776e38a7ca  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,100,33,74,75,72,90,31,99,32,29,30
	btf_id 163
499: sched_cls  name handle_policy  tag 0c8b619bae01ca29  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,103,74,75,102,33,72,91,31,76,67,32,29,30
	btf_id 165
500: sched_cls  name tail_ipv4_ct_ingress  tag d6ecc728337a2c80  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,103,74,75,102,76
	btf_id 166
501: sched_cls  name cil_from_container  tag ddabc52de731665a  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 103,68
	btf_id 167
502: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,103
	btf_id 168
503: sched_cls  name tail_handle_arp  tag af408ed7541518be  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,103
	btf_id 169
504: sched_cls  name tail_ipv4_to_endpoint  tag 15b51d81bfb131d1  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,102,33,74,75,72,91,31,103,32,29,30
	btf_id 170
505: sched_cls  name __send_drop_notify  tag aff144c81e9cf848  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 171
507: sched_cls  name tail_handle_ipv4  tag 37a523f379b8981b  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,103
	btf_id 173
508: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
511: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
512: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,103,74,75,102,76
	btf_id 174
513: sched_cls  name tail_handle_ipv4_cont  tag e14d02c395b7e979  gpl
	loaded_at 2024-10-25T10:13:43+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,102,33,91,74,75,31,68,66,69,103,32,29,30,73
	btf_id 175
514: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
517: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
518: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
521: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
522: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,108
	btf_id 177
523: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 178
524: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,108
	btf_id 179
525: sched_cls  name __send_drop_notify  tag 1428386ed47a8689  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 180
526: sched_cls  name tail_handle_ipv4_from_host  tag 6a075031c62d650c  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,108
	btf_id 181
529: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 185
530: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,109
	btf_id 186
531: sched_cls  name __send_drop_notify  tag 1428386ed47a8689  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 187
532: sched_cls  name tail_handle_ipv4_from_host  tag 6a075031c62d650c  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,109
	btf_id 188
537: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,111
	btf_id 194
538: sched_cls  name __send_drop_notify  tag 1428386ed47a8689  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 195
539: sched_cls  name tail_handle_ipv4_from_host  tag 6a075031c62d650c  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,111
	btf_id 196
541: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:13:44+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,111,67
	btf_id 198
582: sched_cls  name tail_handle_ipv4_cont  tag 96a1637d3f1c45c8  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,124,33,123,74,75,31,68,66,69,125,32,29,30,73
	btf_id 215
583: sched_cls  name tail_ipv4_to_endpoint  tag b61feeb2bb6c40de  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,124,33,74,75,72,123,31,125,32,29,30
	btf_id 216
584: sched_cls  name handle_policy  tag dfbf772a5f0e3623  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,125,74,75,124,33,72,123,31,76,67,32,29,30
	btf_id 217
586: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,125
	btf_id 219
587: sched_cls  name cil_from_container  tag 77ce76bc5739ebc3  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 125,68
	btf_id 220
588: sched_cls  name tail_handle_ipv4  tag 1038b27dc7405237  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,125
	btf_id 221
589: sched_cls  name tail_handle_arp  tag 0458443ad2308cee  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,125
	btf_id 222
590: sched_cls  name tail_ipv4_ct_ingress  tag 4778cd34b1b6b6cd  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,125,74,75,124,76
	btf_id 223
591: sched_cls  name tail_ipv4_ct_egress  tag 13a408cc8044f458  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,125,74,75,124,76
	btf_id 224
592: sched_cls  name __send_drop_notify  tag aafa9395f89e8f66  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 225
593: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
596: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
609: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
612: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
613: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
616: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
617: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
620: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
