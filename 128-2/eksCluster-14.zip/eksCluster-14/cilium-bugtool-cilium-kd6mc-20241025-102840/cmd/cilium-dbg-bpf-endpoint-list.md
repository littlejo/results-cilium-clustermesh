IP ADDRESS        LOCAL ENDPOINT INFO
10.14.0.205:0     id=2845  sec_id=1041050 flags=0x0000 ifindex=9   mac=8E:9B:F6:75:4D:11 nodemac=3A:A1:16:A1:27:87   
172.31.147.77:0   (localhost)                                                                                        
10.14.0.45:0      id=2788  sec_id=1013686 flags=0x0000 ifindex=15  mac=72:6A:5B:2F:A8:C7 nodemac=D6:4E:0A:8B:59:88   
10.14.0.22:0      id=1971  sec_id=4     flags=0x0000 ifindex=7   mac=EE:0A:A3:FA:6A:4B nodemac=62:1F:66:D8:83:18     
10.14.0.138:0     id=930   sec_id=1041050 flags=0x0000 ifindex=11  mac=92:12:BD:4C:02:04 nodemac=36:C6:B7:5D:FB:29   
10.14.0.231:0     (localhost)                                                                                        
