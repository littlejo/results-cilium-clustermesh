markdown output at /tmp/cilium-bugtool-20241025-102841.771+0000-UTC-299324557/cmd/cilium-debuginfo-20241025-102912.477+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102841.771+0000-UTC-299324557/cmd/cilium-debuginfo-20241025-102912.477+0000-UTC.json
