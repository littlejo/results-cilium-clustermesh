[
  {
    "containers": [
      {
        "cgroup-id": 8286,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61496677_4a1e_45c0_8bc8_5bc47625ba7b.slice/cri-containerd-4f8f843c08c99d1f65b33a31705a1beb0aa60672171ad12558a57c9b01b0412e.scope"
      },
      {
        "cgroup-id": 8202,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61496677_4a1e_45c0_8bc8_5bc47625ba7b.slice/cri-containerd-3ddfbe774b770ebea4bd5c7ed971c31fd2962fdb00f2956cf9992cb1f71558ec.scope"
      },
      {
        "cgroup-id": 8370,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61496677_4a1e_45c0_8bc8_5bc47625ba7b.slice/cri-containerd-13f753972b30413b719da78f101428eae7178dd9a9ea534dcededeae24a9836a.scope"
      }
    ],
    "ips": [
      "10.118.0.35"
    ],
    "name": "clustermesh-apiserver-666f6db888-m6tkb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6858,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd4eac16b_7c04_4d03_9b40_abd3c4f88ae3.slice/cri-containerd-9c7b311ce627c678993a90810607a748b498ccdb05bb45cf5d02ac6b82dd0909.scope"
      }
    ],
    "ips": [
      "10.118.0.41"
    ],
    "name": "coredns-cc6ccd49c-n9fdp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6774,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf877e34_0eff_4e86_ba44_680ccb732a4e.slice/cri-containerd-3bb6956f1a36eedec1549c5f93bd34568d8fcb633df1855e7bddb3692d0d012d.scope"
      }
    ],
    "ips": [
      "10.118.0.8"
    ],
    "name": "coredns-cc6ccd49c-6qprz",
    "namespace": "kube-system"
  }
]

