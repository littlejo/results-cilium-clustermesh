xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 466
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 462
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 452
cilium_host(4) clsact/egress cil_from_host-cilium_host id 455
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 448
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 449
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 505
lxc877c26b669c1(9) clsact/ingress cil_from_container-lxc877c26b669c1 id 472
lxc6fe8df2bf1fe(11) clsact/ingress cil_from_container-lxc6fe8df2bf1fe id 492
lxc0876ce53612d(15) clsact/ingress cil_from_container-lxc0876ce53612d id 575

flow_dissector:

netfilter:

