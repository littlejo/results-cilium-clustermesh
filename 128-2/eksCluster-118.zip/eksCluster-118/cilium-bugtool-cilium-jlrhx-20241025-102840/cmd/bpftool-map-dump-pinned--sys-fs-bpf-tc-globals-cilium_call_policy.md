key: 87 01 00 00  value: dc 01 00 00
key: c4 02 00 00  value: eb 01 00 00
key: 6c 05 00 00  value: 3b 02 00 00
key: 62 0f 00 00  value: fc 01 00 00
Found 4 elements
