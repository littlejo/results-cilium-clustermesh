Endpoint ID: 391
Path: /sys/fs/bpf/tc/globals/cilium_policy_00391

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    87726   1007      0        
Allow    Egress      0          ANY          NONE         disabled    13383   140       0        


Endpoint ID: 708
Path: /sys/fs/bpf/tc/globals/cilium_policy_00708

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    87809   1011      0        
Allow    Egress      0          ANY          NONE         disabled    14212   150       0        


Endpoint ID: 1388
Path: /sys/fs/bpf/tc/globals/cilium_policy_01388

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3854923   35408     0        
Allow    Ingress     1          ANY          NONE         disabled    2799762   27945     0        
Allow    Egress      0          ANY          NONE         disabled    3699926   34583     0        


Endpoint ID: 3299
Path: /sys/fs/bpf/tc/globals/cilium_policy_03299

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3938
Path: /sys/fs/bpf/tc/globals/cilium_policy_03938

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    433720   5533      0        
Allow    Ingress     1          ANY          NONE         disabled    12690    147       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


