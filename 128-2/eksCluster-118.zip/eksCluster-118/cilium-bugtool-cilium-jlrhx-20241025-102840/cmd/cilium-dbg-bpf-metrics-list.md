REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     210920    99494084   1132   bpf_host.c
Interface                 INGRESS     9587      747601     677    bpf_overlay.c
Success                   EGRESS      4718      358981     1694   bpf_host.c
Success                   EGRESS      87487     11964835   1308   bpf_lxc.c
Success                   EGRESS      9439      736876     53     encap.h
Success                   INGRESS     103977    12381075   235    trace.h
Success                   INGRESS     98459     11948549   86     l3.h
Unsupported L3 protocol   EGRESS      37        2742       1492   bpf_lxc.c
