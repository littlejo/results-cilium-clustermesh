markdown output at /tmp/cilium-bugtool-20241025-102841.8+0000-UTC-817954654/cmd/cilium-debuginfo-20241025-102912.475+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102841.8+0000-UTC-817954654/cmd/cilium-debuginfo-20241025-102912.475+0000-UTC.json
