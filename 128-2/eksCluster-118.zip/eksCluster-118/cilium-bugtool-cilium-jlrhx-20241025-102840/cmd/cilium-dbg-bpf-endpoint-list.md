IP ADDRESS         LOCAL ENDPOINT INFO
10.118.0.41:0      id=391   sec_id=7827054 flags=0x0000 ifindex=9   mac=5E:8C:EF:12:15:60 nodemac=FE:FD:42:9A:B1:42   
10.118.0.139:0     (localhost)                                                                                        
10.118.0.8:0       id=708   sec_id=7827054 flags=0x0000 ifindex=11  mac=EA:DD:72:2F:E3:68 nodemac=56:0E:DC:EE:D7:E6   
10.118.0.76:0      id=3938  sec_id=4     flags=0x0000 ifindex=7   mac=FE:05:9D:7B:68:76 nodemac=B2:50:B6:10:99:29     
10.118.0.35:0      id=1388  sec_id=7804999 flags=0x0000 ifindex=15  mac=42:4A:65:A6:24:8D nodemac=62:C5:A6:39:B7:BD   
172.31.169.120:0   (localhost)                                                                                        
