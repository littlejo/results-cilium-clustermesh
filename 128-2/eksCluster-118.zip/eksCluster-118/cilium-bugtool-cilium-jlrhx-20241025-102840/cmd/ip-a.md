1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:6e:a4:97:2d:0b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.169.120/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2654sec preferred_lft 2654sec
    inet6 fe80::46e:a4ff:fe97:2d0b/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:e8:cb:bb:6a:dd brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f0e8:cbff:febb:6add/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:0c:08:d0:c0:68 brd ff:ff:ff:ff:ff:ff
    inet 10.118.0.139/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::9c0c:8ff:fed0:c068/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether c6:90:78:bf:b3:1a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c490:78ff:febf:b31a/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:50:b6:10:99:29 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::b050:b6ff:fe10:9929/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc877c26b669c1@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:fd:42:9a:b1:42 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::fcfd:42ff:fe9a:b142/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc6fe8df2bf1fe@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:0e:dc:ee:d7:e6 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::540e:dcff:feee:d7e6/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc0876ce53612d@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:c5:a6:39:b7:bd brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::60c5:a6ff:fe39:b7bd/64 scope link 
       valid_lft forever preferred_lft forever
