{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:32.322Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.169.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:32.322Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:37.101Z",
  "value": "id=3938  sec_id=4     flags=0x0000 ifindex=7   mac=FE:05:9D:7B:68:76 nodemac=B2:50:B6:10:99:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:37.129Z",
  "value": "id=391   sec_id=7827054 flags=0x0000 ifindex=9   mac=5E:8C:EF:12:15:60 nodemac=FE:FD:42:9A:B1:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:37.139Z",
  "value": "id=708   sec_id=7827054 flags=0x0000 ifindex=11  mac=EA:DD:72:2F:E3:68 nodemac=56:0E:DC:EE:D7:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:37.144Z",
  "value": "id=391   sec_id=7827054 flags=0x0000 ifindex=9   mac=5E:8C:EF:12:15:60 nodemac=FE:FD:42:9A:B1:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:37.167Z",
  "value": "id=3938  sec_id=4     flags=0x0000 ifindex=7   mac=FE:05:9D:7B:68:76 nodemac=B2:50:B6:10:99:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:56.153Z",
  "value": "id=3938  sec_id=4     flags=0x0000 ifindex=7   mac=FE:05:9D:7B:68:76 nodemac=B2:50:B6:10:99:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:56.154Z",
  "value": "id=391   sec_id=7827054 flags=0x0000 ifindex=9   mac=5E:8C:EF:12:15:60 nodemac=FE:FD:42:9A:B1:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:56.155Z",
  "value": "id=708   sec_id=7827054 flags=0x0000 ifindex=11  mac=EA:DD:72:2F:E3:68 nodemac=56:0E:DC:EE:D7:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:56.187Z",
  "value": "id=3086  sec_id=7804999 flags=0x0000 ifindex=13  mac=32:B0:E9:CE:98:FF nodemac=A2:2E:BC:70:4A:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:57.154Z",
  "value": "id=391   sec_id=7827054 flags=0x0000 ifindex=9   mac=5E:8C:EF:12:15:60 nodemac=FE:FD:42:9A:B1:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:57.154Z",
  "value": "id=3938  sec_id=4     flags=0x0000 ifindex=7   mac=FE:05:9D:7B:68:76 nodemac=B2:50:B6:10:99:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:57.154Z",
  "value": "id=708   sec_id=7827054 flags=0x0000 ifindex=11  mac=EA:DD:72:2F:E3:68 nodemac=56:0E:DC:EE:D7:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:57.155Z",
  "value": "id=3086  sec_id=7804999 flags=0x0000 ifindex=13  mac=32:B0:E9:CE:98:FF nodemac=A2:2E:BC:70:4A:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:02.576Z",
  "value": "id=1388  sec_id=7804999 flags=0x0000 ifindex=15  mac=42:4A:65:A6:24:8D nodemac=62:C5:A6:39:B7:BD"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.118.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:08.113Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:25.673Z",
  "value": "id=1388  sec_id=7804999 flags=0x0000 ifindex=15  mac=42:4A:65:A6:24:8D nodemac=62:C5:A6:39:B7:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:25.674Z",
  "value": "id=3938  sec_id=4     flags=0x0000 ifindex=7   mac=FE:05:9D:7B:68:76 nodemac=B2:50:B6:10:99:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:25.674Z",
  "value": "id=391   sec_id=7827054 flags=0x0000 ifindex=9   mac=5E:8C:EF:12:15:60 nodemac=FE:FD:42:9A:B1:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:25.674Z",
  "value": "id=708   sec_id=7827054 flags=0x0000 ifindex=11  mac=EA:DD:72:2F:E3:68 nodemac=56:0E:DC:EE:D7:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:26.673Z",
  "value": "id=3938  sec_id=4     flags=0x0000 ifindex=7   mac=FE:05:9D:7B:68:76 nodemac=B2:50:B6:10:99:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:26.674Z",
  "value": "id=391   sec_id=7827054 flags=0x0000 ifindex=9   mac=5E:8C:EF:12:15:60 nodemac=FE:FD:42:9A:B1:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:26.674Z",
  "value": "id=708   sec_id=7827054 flags=0x0000 ifindex=11  mac=EA:DD:72:2F:E3:68 nodemac=56:0E:DC:EE:D7:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:26.674Z",
  "value": "id=1388  sec_id=7804999 flags=0x0000 ifindex=15  mac=42:4A:65:A6:24:8D nodemac=62:C5:A6:39:B7:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:27.674Z",
  "value": "id=708   sec_id=7827054 flags=0x0000 ifindex=11  mac=EA:DD:72:2F:E3:68 nodemac=56:0E:DC:EE:D7:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:27.674Z",
  "value": "id=3938  sec_id=4     flags=0x0000 ifindex=7   mac=FE:05:9D:7B:68:76 nodemac=B2:50:B6:10:99:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:27.674Z",
  "value": "id=1388  sec_id=7804999 flags=0x0000 ifindex=15  mac=42:4A:65:A6:24:8D nodemac=62:C5:A6:39:B7:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:27.674Z",
  "value": "id=391   sec_id=7827054 flags=0x0000 ifindex=9   mac=5E:8C:EF:12:15:60 nodemac=FE:FD:42:9A:B1:42"
}

