top - 10:28:42 up 15 min,  0 users,  load average: 0.27, 0.20, 0.18
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 41.4 us, 34.5 sy,  0.0 ni, 24.1 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1174.3 free,    905.6 used,   1756.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2762.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 282812  79804 S  26.7   7.2   0:25.29 cilium-+
    663 root      20   0 1240432  16976  11548 S   6.7   0.4   0:00.03 cilium-+
    412 root      20   0 1228848   5816   2928 S   0.0   0.1   0:00.27 cilium-+
    660 root      20   0 1228744   3656   2976 S   0.0   0.1   0:00.00 gops
    706 root      20   0    6576   2408   2084 R   0.0   0.1   0:00.00 top
    732 root      20   0 1228744   3776   3104 S   0.0   0.1   0:00.00 gops
