fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxc877c26b669c1 proto kernel metric 256 pref medium
fe80::/64 dev lxc6fe8df2bf1fe proto kernel metric 256 pref medium
fe80::/64 dev lxc0876ce53612d proto kernel metric 256 pref medium
