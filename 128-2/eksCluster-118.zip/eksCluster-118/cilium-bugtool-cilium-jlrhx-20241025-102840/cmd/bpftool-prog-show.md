35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:48+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:12:48+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:12:49+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:12:49+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:12:49+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:49+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:12:53+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
61: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
64: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
71: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
72: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
75: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
447: sched_cls  name tail_handle_ipv4  tag 61a8623580af96da  gpl
	loaded_at 2024-10-25T10:13:34+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 112
448: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:34+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 113
449: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:34+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 114
450: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:34+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 115
452: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 118
453: sched_cls  name tail_handle_ipv4_from_host  tag e890b05eb51f1cb2  gpl
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,91
	btf_id 119
455: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,91
	btf_id 121
456: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,91
	btf_id 122
457: sched_cls  name __send_drop_notify  tag c7e27ec03aba6791  gpl
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 123
459: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,93
	btf_id 126
460: sched_cls  name __send_drop_notify  tag c7e27ec03aba6791  gpl
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 127
462: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 129
463: sched_cls  name tail_handle_ipv4_from_host  tag e890b05eb51f1cb2  gpl
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,93
	btf_id 130
465: sched_cls  name tail_handle_ipv4_from_host  tag e890b05eb51f1cb2  gpl
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,96
	btf_id 133
466: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,96,67
	btf_id 134
468: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,96
	btf_id 136
469: sched_cls  name __send_drop_notify  tag c7e27ec03aba6791  gpl
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 137
472: sched_cls  name cil_from_container  tag 670a13a9bd58ba68  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 101,68
	btf_id 142
473: sched_cls  name tail_ipv4_ct_ingress  tag e76783ad20afeacd  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,101,74,75,100,76
	btf_id 144
476: sched_cls  name handle_policy  tag cebc69245c75ae48  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,101,74,75,100,33,72,97,31,76,67,32,29,30
	btf_id 145
479: sched_cls  name tail_handle_ipv4  tag 86f52e0c6d2323a9  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,101
	btf_id 148
481: sched_cls  name __send_drop_notify  tag c5a7935601a07377  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 151
485: sched_cls  name tail_ipv4_ct_egress  tag eb854592ed50c339  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,101,74,75,100,76
	btf_id 154
489: sched_cls  name tail_ipv4_to_endpoint  tag 11d57f8444a18247  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,100,33,74,75,72,97,31,101,32,29,30
	btf_id 157
490: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,101
	btf_id 162
491: sched_cls  name handle_policy  tag 5b6e7f08ed3d4f86  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,104,74,75,103,33,72,102,31,76,67,32,29,30
	btf_id 161
492: sched_cls  name cil_from_container  tag eac9b01b40024b43  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 104,68
	btf_id 163
493: sched_cls  name tail_ipv4_ct_ingress  tag 7b9a7b27c1eb4707  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 164
494: sched_cls  name tail_handle_arp  tag d4754b261e99710a  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,101
	btf_id 166
496: sched_cls  name tail_handle_ipv4  tag 38c52d85365ab1ae  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,104
	btf_id 165
498: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,104
	btf_id 170
499: sched_cls  name tail_handle_arp  tag 40a4d460639eede8  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,104
	btf_id 171
500: sched_cls  name tail_ipv4_to_endpoint  tag 6b76ec1da5648eb1  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,103,33,74,75,72,102,31,104,32,29,30
	btf_id 172
501: sched_cls  name tail_handle_ipv4_cont  tag 93d2875acc71604f  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,100,33,97,74,75,31,68,66,69,101,32,29,30,73
	btf_id 169
502: sched_cls  name tail_ipv4_ct_egress  tag eb854592ed50c339  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 173
503: sched_cls  name __send_drop_notify  tag 981a260eae01420f  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 174
504: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,105
	btf_id 176
505: sched_cls  name cil_from_container  tag 472b079b6469165c  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 105,68
	btf_id 177
506: sched_cls  name __send_drop_notify  tag d9eb0e231742a8c3  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 178
507: sched_cls  name tail_handle_ipv4_cont  tag fa4520506aa1f182  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,103,33,102,74,75,31,68,66,69,104,32,29,30,73
	btf_id 180
508: sched_cls  name handle_policy  tag 557b39d6e3a3e6a2  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,105,74,75,106,33,72,90,31,76,67,32,29,30
	btf_id 179
510: sched_cls  name tail_ipv4_to_endpoint  tag 479bda2d14135745  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,106,33,74,75,72,90,31,105,32,29,30
	btf_id 182
511: sched_cls  name tail_handle_arp  tag 2c75b22b54acea7b  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,105
	btf_id 183
512: sched_cls  name tail_handle_ipv4  tag d3efb92781d0d20f  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,105
	btf_id 184
513: sched_cls  name tail_handle_ipv4_cont  tag c0d907948fb0d0f5  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,106,33,90,74,75,31,68,66,69,105,32,29,30,73
	btf_id 185
514: sched_cls  name tail_ipv4_ct_ingress  tag c7f57b1b15b3bd1a  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,105,74,75,106,76
	btf_id 186
515: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,105,74,75,106,76
	btf_id 187
516: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
519: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
520: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
523: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:37+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
524: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
527: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
528: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
531: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
571: sched_cls  name handle_policy  tag add7f4b8965d198a  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,122,74,75,123,33,72,121,31,76,67,32,29,30
	btf_id 203
572: sched_cls  name tail_ipv4_ct_ingress  tag b6002c64491b6e1a  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,122,74,75,123,76
	btf_id 204
573: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,122
	btf_id 205
574: sched_cls  name tail_handle_arp  tag 8ca16a7c5a3052f0  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,122
	btf_id 206
575: sched_cls  name cil_from_container  tag 234f8fb9b2760bbb  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 122,68
	btf_id 207
576: sched_cls  name __send_drop_notify  tag 5ec56d071eb3e5b2  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 208
578: sched_cls  name tail_handle_ipv4_cont  tag 9af33b4a419d3c5a  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,123,33,121,74,75,31,68,66,69,122,32,29,30,73
	btf_id 210
579: sched_cls  name tail_handle_ipv4  tag 03bd8dd3442431aa  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,122
	btf_id 211
580: sched_cls  name tail_ipv4_to_endpoint  tag cfda6198836f9e55  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,123,33,74,75,72,121,31,122,32,29,30
	btf_id 212
581: sched_cls  name tail_ipv4_ct_egress  tag 99b0a01a9392c886  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,122,74,75,123,76
	btf_id 213
582: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
585: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
598: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
601: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
602: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
605: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
606: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
609: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:23:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
