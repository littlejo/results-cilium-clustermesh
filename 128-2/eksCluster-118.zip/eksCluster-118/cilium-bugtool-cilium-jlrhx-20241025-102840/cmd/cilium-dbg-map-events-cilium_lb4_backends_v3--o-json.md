{
  "action": "update",
  "desired-action": "sync",
  "key": "1",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:30.026Z",
  "value": "ANY://172.31.190.56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "2",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:34.444Z",
  "value": "ANY://172.31.169.120"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.455Z",
  "value": "ANY://10.118.0.41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:38.455Z",
  "value": "ANY://10.118.0.41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "5",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:39.421Z",
  "value": "ANY://10.118.0.8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "6",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:39.421Z",
  "value": "ANY://10.118.0.8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "7",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:04.529Z",
  "value": "ANY://10.118.0.86"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:09.790Z",
  "value": "ANY://172.31.211.167"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "9",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:07.659Z",
  "value": "ANY://10.118.0.35"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "7",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:07.744Z",
  "value": "ANY://10.118.0.86"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "7",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:08.212Z",
  "value": "\u003cnil\u003e"
}

