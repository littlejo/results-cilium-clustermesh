ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.190.56:443 (active)     
                                          2 => 172.31.211.167:443 (active)    
2    10.100.70.45:443      ClusterIP      1 => 172.31.169.120:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.118.0.41:53 (active)        
                                          2 => 10.118.0.8:53 (active)         
4    10.100.0.10:9153      ClusterIP      1 => 10.118.0.41:9153 (active)      
                                          2 => 10.118.0.8:9153 (active)       
5    10.100.119.252:2379   ClusterIP      1 => 10.118.0.35:2379 (active)      
