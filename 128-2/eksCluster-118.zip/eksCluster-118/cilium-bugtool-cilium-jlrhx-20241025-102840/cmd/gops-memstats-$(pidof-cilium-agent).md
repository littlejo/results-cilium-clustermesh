alloc: 103.93MB (108980320 bytes)
total-alloc: 1.33GB (1423669040 bytes)
sys: 214.38MB (224798036 bytes)
lookups: 0
mallocs: 47608297
frees: 46489222
heap-alloc: 103.93MB (108980320 bytes)
heap-sys: 169.54MB (177774592 bytes)
heap-idle: 46.48MB (48734208 bytes)
heap-in-use: 123.06MB (129040384 bytes)
heap-released: 9.92MB (10403840 bytes)
heap-objects: 1119075
stack-in-use: 34.44MB (36110336 bytes)
stack-sys: 34.44MB (36110336 bytes)
stack-mspan-inuse: 2.05MB (2145280 bytes)
stack-mspan-sys: 2.40MB (2513280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 948.21KB (970969 bytes)
gc-sys: 5.16MB (5415264 bytes)
next-gc: when heap-alloc >= 147.60MB (154768072 bytes)
last-gc: 2024-10-25 10:28:43.129564222 +0000 UTC
gc-pause-total: 6.421117ms
gc-pause: 90864
gc-pause-end: 1729852123129564222
num-gc: 75
num-forced-gc: 0
gc-cpu-fraction: 0.00038293272218332735
enable-gc: true
debug-gc: false
