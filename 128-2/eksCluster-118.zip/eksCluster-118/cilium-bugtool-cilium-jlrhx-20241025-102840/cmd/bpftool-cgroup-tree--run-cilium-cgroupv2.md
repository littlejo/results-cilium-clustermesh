CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf877e34_0eff_4e86_ba44_680ccb732a4e.slice/cri-containerd-3bb6956f1a36eedec1549c5f93bd34568d8fcb633df1855e7bddb3692d0d012d.scope
    527      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf877e34_0eff_4e86_ba44_680ccb732a4e.slice/cri-containerd-fe27c36e4aadc40e2c9c65bcdedca959bb763fa51903a8fbff1dec91d724a993.scope
    523      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod61599cd1_ee4e_4489_8f2e_52f308473bb0.slice/cri-containerd-2b754babf6a0e8c64b15e60a1d09b16a11e8dce4b0d80c982cc6301e437284d0.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod61599cd1_ee4e_4489_8f2e_52f308473bb0.slice/cri-containerd-431e20cea504ff239ce0d7d9185784d9e64e61bc893210f67e27e66085dc9ed1.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8071081a_27f2_4538_9743_b908d81e37e6.slice/cri-containerd-01ea0032e64efd89e9d47c0d8654cd03ad1b567b286137db4e7e156f290cd22b.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8071081a_27f2_4538_9743_b908d81e37e6.slice/cri-containerd-acbbb1d5e2183fb314b0d751f25ce891d36e6fc211729cd3eb0aceb9a5e465f1.scope
    71       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd4eac16b_7c04_4d03_9b40_abd3c4f88ae3.slice/cri-containerd-f0fb448e9f348ebcd324f6d52470837b511e139b81400098e4d5f927c3ffb482.scope
    519      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd4eac16b_7c04_4d03_9b40_abd3c4f88ae3.slice/cri-containerd-9c7b311ce627c678993a90810607a748b498ccdb05bb45cf5d02ac6b82dd0909.scope
    531      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61496677_4a1e_45c0_8bc8_5bc47625ba7b.slice/cri-containerd-13f753972b30413b719da78f101428eae7178dd9a9ea534dcededeae24a9836a.scope
    609      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61496677_4a1e_45c0_8bc8_5bc47625ba7b.slice/cri-containerd-bc42ea65f60b55d3f215d582b4f7603ba765bbb20e481a07f808a5f9f9cc4050.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61496677_4a1e_45c0_8bc8_5bc47625ba7b.slice/cri-containerd-3ddfbe774b770ebea4bd5c7ed971c31fd2962fdb00f2956cf9992cb1f71558ec.scope
    601      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61496677_4a1e_45c0_8bc8_5bc47625ba7b.slice/cri-containerd-4f8f843c08c99d1f65b33a31705a1beb0aa60672171ad12558a57c9b01b0412e.scope
    605      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf192be63_a15c_4217_a61b_313e0f4aa667.slice/cri-containerd-858ddc4804d0a307b2e68c55725be4a55c720ff288df29780b5139886a562535.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf192be63_a15c_4217_a61b_313e0f4aa667.slice/cri-containerd-a39c17b89e0ffc638fe23b5d7de8096ec3f868734628fd122714dd0b1e1edcb8.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod487952c4_5797_4b56_9d9f_5d85c9e75dd9.slice/cri-containerd-df75f253046bdac564a9abee01d49ff0a581539b1428edd3638c783020643246.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod487952c4_5797_4b56_9d9f_5d85c9e75dd9.slice/cri-containerd-2aac7b64caee2ffb14c98a6dce325eb7b1ab6b087b32dc4a09c00301fcfd62df.scope
    64       cgroup_device   multi                                          
