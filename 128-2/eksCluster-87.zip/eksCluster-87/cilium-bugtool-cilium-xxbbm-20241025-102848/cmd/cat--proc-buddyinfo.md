Node 0, zone      DMA      1      1      3     16     22      2      3      7      3      4    165 
Node 0, zone   Normal    556    105      8      3     11     10      1      1      2      3      7 
