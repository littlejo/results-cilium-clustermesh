REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     215339    84852916   1132   bpf_host.c
Interface                 INGRESS     9686      755839     677    bpf_overlay.c
Success                   EGRESS      4605      351307     1694   bpf_host.c
Success                   EGRESS      92753     12425739   1308   bpf_lxc.c
Success                   EGRESS      9463      739690     53     encap.h
Success                   INGRESS     101432    12577685   86     l3.h
Success                   INGRESS     107162    13026123   235    trace.h
Unsupported L3 protocol   EGRESS      38        2852       1492   bpf_lxc.c
