markdown output at /tmp/cilium-bugtool-20241025-102850.422+0000-UTC-3106884476/cmd/cilium-debuginfo-20241025-102921.028+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102850.422+0000-UTC-3106884476/cmd/cilium-debuginfo-20241025-102921.028+0000-UTC.json
