CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd707752a_1cc3_4715_87ed_3966c036fc03.slice/cri-containerd-29c70cb65123b29384d3fc721c8de25743c183b11a073c87987be1165f01f334.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd707752a_1cc3_4715_87ed_3966c036fc03.slice/cri-containerd-bc48a4286d4fc3da540e8e00973facc37d96289d2c7cf95351904fc81eabf7de.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9226d70c_df62_4086_93fb_b2de238a007e.slice/cri-containerd-6f697983cceff7f08fd37ff184c67cd8795f6ff83eacd4f24ab1c73d68b8f89c.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9226d70c_df62_4086_93fb_b2de238a007e.slice/cri-containerd-d578a36b0897d1f3974c29e32845e5101a14561fccd3b9f52496efa6dbd54f19.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode446a0b2_2fb2_4c10_85b9_37f3a9bc46b2.slice/cri-containerd-d56575b2b00fe14144a345fbdb6d4fc73ac4da4ef103dded49b0963835a606db.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode446a0b2_2fb2_4c10_85b9_37f3a9bc46b2.slice/cri-containerd-f36d5f252fd7d5fd109d66f955ff2a97b777c1fefab6cfc9c6faced61213682a.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb8c8e653_adc1_444a_aa60_10023fc55e06.slice/cri-containerd-51d7367b1ac2959c96b4d33d8e72c3d2d8863d624dc533d3af4473c5bcbdf8ea.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb8c8e653_adc1_444a_aa60_10023fc55e06.slice/cri-containerd-5fb7586dc713f01939bc5d380b12f417d144c8f4c07d7eb2bfac8f65f7311ce8.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode371132c_96ab_473a_98d5_76ede691fe63.slice/cri-containerd-d4d236aab600ea15f3e61ab8a584483d73c1213fa134638ed59eca41dfe77e64.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode371132c_96ab_473a_98d5_76ede691fe63.slice/cri-containerd-1f48c5b3667b13eee7b020a88aaf1d8a08eb1b567dce14d942d1dcac90040d84.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd71c2a0_ed88_441b_ad54_da9c50fb827f.slice/cri-containerd-4d005b0619d6dcfbbaa4bb41f592d8bcc31d36513f95648ad42f342754bd1a03.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd71c2a0_ed88_441b_ad54_da9c50fb827f.slice/cri-containerd-c796719edfee5d4d3dfb3057b24ec8b5352f19a7dbd7afe8444dbae96365f038.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbcaec37e_73da_4f3a_a56b_5654792556e0.slice/cri-containerd-c40caa933297ae8b69d94fcc66b60b9e5fc7ebf1ec0179f87547b226f7dedfb6.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbcaec37e_73da_4f3a_a56b_5654792556e0.slice/cri-containerd-6e4d29f790794e22b39dd8c526390622d354e4d99eaf0c0f9847b4cbbd15fef0.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbcaec37e_73da_4f3a_a56b_5654792556e0.slice/cri-containerd-775a80ffbf4b6415da347244329efe3a06a42c35e943141effdd1c138c39b0eb.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbcaec37e_73da_4f3a_a56b_5654792556e0.slice/cri-containerd-17adb0a00fc0ef6c325b8c9fb6b850cfce9023ba0341ca9e36d2c38297dac769.scope
    664      cgroup_device   multi                                          
