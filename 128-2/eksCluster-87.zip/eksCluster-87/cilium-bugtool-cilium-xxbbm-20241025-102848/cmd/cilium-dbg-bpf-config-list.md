KEY             VALUE
AgentLiveness   833905458029
UTimeOffset     3378615873046875
