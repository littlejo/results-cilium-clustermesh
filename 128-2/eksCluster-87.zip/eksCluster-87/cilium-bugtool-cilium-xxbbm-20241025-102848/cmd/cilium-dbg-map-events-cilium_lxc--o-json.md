{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:59.346Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.201.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:59.346Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.209.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:59.346Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:03.618Z",
  "value": "id=2026  sec_id=4     flags=0x0000 ifindex=10  mac=12:AE:AA:69:A4:C4 nodemac=C2:E0:82:60:7F:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:03.622Z",
  "value": "id=3254  sec_id=5776013 flags=0x0000 ifindex=12  mac=0E:9A:A1:6B:2D:4B nodemac=8A:9E:04:9C:8E:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:03.679Z",
  "value": "id=961   sec_id=5776013 flags=0x0000 ifindex=14  mac=BA:89:12:4A:F9:70 nodemac=72:AC:86:E3:9D:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:03.732Z",
  "value": "id=2026  sec_id=4     flags=0x0000 ifindex=10  mac=12:AE:AA:69:A4:C4 nodemac=C2:E0:82:60:7F:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:03.820Z",
  "value": "id=3254  sec_id=5776013 flags=0x0000 ifindex=12  mac=0E:9A:A1:6B:2D:4B nodemac=8A:9E:04:9C:8E:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:12.668Z",
  "value": "id=2026  sec_id=4     flags=0x0000 ifindex=10  mac=12:AE:AA:69:A4:C4 nodemac=C2:E0:82:60:7F:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:12.669Z",
  "value": "id=3254  sec_id=5776013 flags=0x0000 ifindex=12  mac=0E:9A:A1:6B:2D:4B nodemac=8A:9E:04:9C:8E:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:12.669Z",
  "value": "id=961   sec_id=5776013 flags=0x0000 ifindex=14  mac=BA:89:12:4A:F9:70 nodemac=72:AC:86:E3:9D:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:12.697Z",
  "value": "id=3060  sec_id=5780442 flags=0x0000 ifindex=16  mac=96:E3:7E:4A:09:71 nodemac=CE:74:16:0A:68:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:12.697Z",
  "value": "id=3060  sec_id=5780442 flags=0x0000 ifindex=16  mac=96:E3:7E:4A:09:71 nodemac=CE:74:16:0A:68:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:00.960Z",
  "value": "id=784   sec_id=5780442 flags=0x0000 ifindex=18  mac=AA:32:08:FC:EE:63 nodemac=82:77:AC:27:B3:87"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.87.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:06.797Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:20.145Z",
  "value": "id=784   sec_id=5780442 flags=0x0000 ifindex=18  mac=AA:32:08:FC:EE:63 nodemac=82:77:AC:27:B3:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:20.145Z",
  "value": "id=961   sec_id=5776013 flags=0x0000 ifindex=14  mac=BA:89:12:4A:F9:70 nodemac=72:AC:86:E3:9D:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:20.146Z",
  "value": "id=2026  sec_id=4     flags=0x0000 ifindex=10  mac=12:AE:AA:69:A4:C4 nodemac=C2:E0:82:60:7F:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:20.146Z",
  "value": "id=3254  sec_id=5776013 flags=0x0000 ifindex=12  mac=0E:9A:A1:6B:2D:4B nodemac=8A:9E:04:9C:8E:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:21.131Z",
  "value": "id=2026  sec_id=4     flags=0x0000 ifindex=10  mac=12:AE:AA:69:A4:C4 nodemac=C2:E0:82:60:7F:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:21.131Z",
  "value": "id=784   sec_id=5780442 flags=0x0000 ifindex=18  mac=AA:32:08:FC:EE:63 nodemac=82:77:AC:27:B3:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:21.132Z",
  "value": "id=961   sec_id=5776013 flags=0x0000 ifindex=14  mac=BA:89:12:4A:F9:70 nodemac=72:AC:86:E3:9D:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:21.132Z",
  "value": "id=3254  sec_id=5776013 flags=0x0000 ifindex=12  mac=0E:9A:A1:6B:2D:4B nodemac=8A:9E:04:9C:8E:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.132Z",
  "value": "id=3254  sec_id=5776013 flags=0x0000 ifindex=12  mac=0E:9A:A1:6B:2D:4B nodemac=8A:9E:04:9C:8E:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.132Z",
  "value": "id=784   sec_id=5780442 flags=0x0000 ifindex=18  mac=AA:32:08:FC:EE:63 nodemac=82:77:AC:27:B3:87"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.133Z",
  "value": "id=961   sec_id=5776013 flags=0x0000 ifindex=14  mac=BA:89:12:4A:F9:70 nodemac=72:AC:86:E3:9D:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:22.133Z",
  "value": "id=2026  sec_id=4     flags=0x0000 ifindex=10  mac=12:AE:AA:69:A4:C4 nodemac=C2:E0:82:60:7F:0D"
}

