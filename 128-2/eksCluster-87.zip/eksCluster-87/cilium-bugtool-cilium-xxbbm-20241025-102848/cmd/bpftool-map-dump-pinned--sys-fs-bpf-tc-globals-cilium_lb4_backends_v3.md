key: 06 00 00 00  value: 0a 57 00 63 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 57 00 17 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f d7 bd 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 57 00 17 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 8a e6 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f d1 11 10 94 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 57 00 e8 09 4b 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 57 00 63 23 c1 00 00  00 00 00 00
Found 8 elements
