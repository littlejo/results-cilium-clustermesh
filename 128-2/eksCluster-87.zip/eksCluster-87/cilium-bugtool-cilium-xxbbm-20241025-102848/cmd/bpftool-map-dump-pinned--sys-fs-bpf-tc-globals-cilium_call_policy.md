key: 10 03 00 00  value: 79 02 00 00
key: c1 03 00 00  value: 04 02 00 00
key: ea 07 00 00  value: 0e 02 00 00
key: b6 0c 00 00  value: 23 02 00 00
Found 4 elements
