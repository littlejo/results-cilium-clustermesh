top - 10:28:50 up 13 min,  0 users,  load average: 0.05, 0.11, 0.15
Tasks:   9 total,   2 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 23.3 us, 36.7 sy,  0.0 ni, 40.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    787.2 free,    906.4 used,   2142.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2760.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    620 root      20   0 1240432  16364  11356 S   6.7   0.4   0:00.02 cilium-+
      1 root      20   0 1472624 274700  79168 S   0.0   7.0   0:19.17 cilium-+
    395 root      20   0 1228848   6940   3900 S   0.0   0.2   0:00.25 cilium-+
    630 root      20   0 1228744   3604   2912 S   0.0   0.1   0:00.00 gops
    667 root      20   0    6576   2412   2088 R   0.0   0.1   0:00.00 top
    685 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    690 root      20   0 1615752   8416   6340 S   0.0   0.2   0:00.00 runc:[2+
    696 root      20   0 1692104   8856   6360 S   0.0   0.2   0:00.00 runc:[2+
    697 root      20   0 1616008   6164   4428 R   0.0   0.2   0:00.00 runc:[2+
