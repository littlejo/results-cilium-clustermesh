[
  {
    "containers": [
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbcaec37e_73da_4f3a_a56b_5654792556e0.slice/cri-containerd-17adb0a00fc0ef6c325b8c9fb6b850cfce9023ba0341ca9e36d2c38297dac769.scope"
      },
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbcaec37e_73da_4f3a_a56b_5654792556e0.slice/cri-containerd-6e4d29f790794e22b39dd8c526390622d354e4d99eaf0c0f9847b4cbbd15fef0.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbcaec37e_73da_4f3a_a56b_5654792556e0.slice/cri-containerd-775a80ffbf4b6415da347244329efe3a06a42c35e943141effdd1c138c39b0eb.scope"
      }
    ],
    "ips": [
      "10.87.0.232"
    ],
    "name": "clustermesh-apiserver-787fbcd447-jzwz5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode446a0b2_2fb2_4c10_85b9_37f3a9bc46b2.slice/cri-containerd-f36d5f252fd7d5fd109d66f955ff2a97b777c1fefab6cfc9c6faced61213682a.scope"
      }
    ],
    "ips": [
      "10.87.0.99"
    ],
    "name": "coredns-cc6ccd49c-v9htt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd707752a_1cc3_4715_87ed_3966c036fc03.slice/cri-containerd-bc48a4286d4fc3da540e8e00973facc37d96289d2c7cf95351904fc81eabf7de.scope"
      }
    ],
    "ips": [
      "10.87.0.23"
    ],
    "name": "coredns-cc6ccd49c-fvhp4",
    "namespace": "kube-system"
  }
]

