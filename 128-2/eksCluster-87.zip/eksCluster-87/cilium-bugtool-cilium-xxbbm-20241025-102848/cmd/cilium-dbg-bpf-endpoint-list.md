IP ADDRESS         LOCAL ENDPOINT INFO
10.87.0.232:0      id=784   sec_id=5780442 flags=0x0000 ifindex=18  mac=AA:32:08:FC:EE:63 nodemac=82:77:AC:27:B3:87   
172.31.201.159:0   (localhost)                                                                                        
10.87.0.23:0       id=961   sec_id=5776013 flags=0x0000 ifindex=14  mac=BA:89:12:4A:F9:70 nodemac=72:AC:86:E3:9D:71   
10.87.0.121:0      (localhost)                                                                                        
10.87.0.99:0       id=3254  sec_id=5776013 flags=0x0000 ifindex=12  mac=0E:9A:A1:6B:2D:4B nodemac=8A:9E:04:9C:8E:52   
10.87.0.179:0      id=2026  sec_id=4     flags=0x0000 ifindex=10  mac=12:AE:AA:69:A4:C4 nodemac=C2:E0:82:60:7F:0D     
172.31.209.17:0    (localhost)                                                                                        
