Endpoint ID: 784
Path: /sys/fs/bpf/tc/globals/cilium_policy_00784

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3947434   37141     0        
Allow    Ingress     1          ANY          NONE         disabled    2899086   29051     0        
Allow    Egress      0          ANY          NONE         disabled    4735846   43916     0        


Endpoint ID: 961
Path: /sys/fs/bpf/tc/globals/cilium_policy_00961

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69654   803       0        
Allow    Egress      0          ANY          NONE         disabled    13275   137       0        


Endpoint ID: 2026
Path: /sys/fs/bpf/tc/globals/cilium_policy_02026

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    449068   5738      0        
Allow    Ingress     1          ANY          NONE         disabled    10254    119       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2810
Path: /sys/fs/bpf/tc/globals/cilium_policy_02810

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3254
Path: /sys/fs/bpf/tc/globals/cilium_policy_03254

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    69456   800       0        
Allow    Egress      0          ANY          NONE         disabled    13179   135       0        


