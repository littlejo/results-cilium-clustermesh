alloc: 99.34MB (104162320 bytes)
total-alloc: 1.31GB (1409566776 bytes)
sys: 202.44MB (212277572 bytes)
lookups: 0
mallocs: 47626019
frees: 46611639
heap-alloc: 99.34MB (104162320 bytes)
heap-sys: 157.41MB (165060608 bytes)
heap-idle: 37.86MB (39698432 bytes)
heap-in-use: 119.55MB (125362176 bytes)
heap-released: 1.28MB (1343488 bytes)
heap-objects: 1014380
stack-in-use: 34.56MB (36241408 bytes)
stack-sys: 34.56MB (36241408 bytes)
stack-mspan-inuse: 1.99MB (2081440 bytes)
stack-mspan-sys: 2.47MB (2594880 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 909.05KB (930865 bytes)
gc-sys: 5.21MB (5459184 bytes)
next-gc: when heap-alloc >= 146.12MB (153219384 bytes)
last-gc: 2024-10-25 10:28:54.999979872 +0000 UTC
gc-pause-total: 21.552682ms
gc-pause: 200140
gc-pause-end: 1729852134999979872
num-gc: 71
num-forced-gc: 0
gc-cpu-fraction: 0.0003633252446455619
enable-gc: true
debug-gc: false
