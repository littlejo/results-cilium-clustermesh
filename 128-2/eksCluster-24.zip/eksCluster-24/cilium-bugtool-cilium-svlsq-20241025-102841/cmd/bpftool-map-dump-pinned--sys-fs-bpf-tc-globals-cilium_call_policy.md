key: 2a 01 00 00  value: 15 02 00 00
key: 91 03 00 00  value: 55 02 00 00
key: 15 07 00 00  value: df 01 00 00
key: f9 0d 00 00  value: fb 01 00 00
Found 4 elements
