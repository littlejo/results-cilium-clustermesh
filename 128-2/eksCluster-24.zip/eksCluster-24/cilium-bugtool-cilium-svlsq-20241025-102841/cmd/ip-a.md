1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:f8:08:0c:aa:d7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.148.101/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2663sec preferred_lft 2663sec
    inet6 fe80::4f8:8ff:fe0c:aad7/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:14:6f:54:e5:55 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::7c14:6fff:fe54:e555/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:79:bb:d4:4c:52 brd ff:ff:ff:ff:ff:ff
    inet 10.24.0.180/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::9479:bbff:fed4:4c52/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 12:aa:b5:2f:2f:c1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::10aa:b5ff:fe2f:2fc1/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:f3:f2:5d:c2:a0 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::e4f3:f2ff:fe5d:c2a0/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc90c86841445f@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:6f:cd:15:50:a0 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::8c6f:cdff:fe15:50a0/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc8995de88d20e@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:dd:cd:41:87:ad brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::10dd:cdff:fe41:87ad/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc80ed87983d46@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:2b:09:a0:7c:fb brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::702b:9ff:fea0:7cfb/64 scope link 
       valid_lft forever preferred_lft forever
