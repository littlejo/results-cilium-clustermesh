REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     216236    100073464   1132   bpf_host.c
Interface                 INGRESS     9487      741045      677    bpf_overlay.c
Success                   EGRESS      4630      353109      1694   bpf_host.c
Success                   EGRESS      90110     12176867    1308   bpf_lxc.c
Success                   EGRESS      9340      730260      53     encap.h
Success                   INGRESS     101048    12370621    86     l3.h
Success                   INGRESS     106554    12802463    235    trace.h
Unsupported L3 protocol   EGRESS      37        2742        1492   bpf_lxc.c
