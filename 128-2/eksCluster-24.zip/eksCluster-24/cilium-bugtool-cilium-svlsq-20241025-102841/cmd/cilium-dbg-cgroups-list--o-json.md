[
  {
    "containers": [
      {
        "cgroup-id": 6774,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8f049efa_3dbe_4c3f_a09e_e1eb94b1a013.slice/cri-containerd-6dc93ff295494be0a7c39ab0d5f16498c0252355e939823a73f01ec342d99b49.scope"
      }
    ],
    "ips": [
      "10.24.0.57"
    ],
    "name": "coredns-cc6ccd49c-q47wj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8286,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod435da87f_8170_46b8_ae9a_958dd0c7c55e.slice/cri-containerd-6c81b0a7b7955e5d86b03007ce922bfea5e10be078f45bc5bd38ec54a00e7c1c.scope"
      },
      {
        "cgroup-id": 8202,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod435da87f_8170_46b8_ae9a_958dd0c7c55e.slice/cri-containerd-71e74dce9d33d59385f2b8eed256a9a4fd7cf3273dfb6e912cd3fd9d784af550.scope"
      },
      {
        "cgroup-id": 8370,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod435da87f_8170_46b8_ae9a_958dd0c7c55e.slice/cri-containerd-ee6bfd68c14c11d78c759761d7fd530d42fc283eb5e6fd904b976df542eb783a.scope"
      }
    ],
    "ips": [
      "10.24.0.204"
    ],
    "name": "clustermesh-apiserver-55b55c5c8d-9zzs7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6858,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36f90bc7_216a_4969_ac90_042ba981877d.slice/cri-containerd-056e5873279b2794f3a92357410f0f3be167e196bf484a515f726b05394a3571.scope"
      }
    ],
    "ips": [
      "10.24.0.25"
    ],
    "name": "coredns-cc6ccd49c-284xd",
    "namespace": "kube-system"
  }
]

