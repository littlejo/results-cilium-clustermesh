Endpoint ID: 61
Path: /sys/fs/bpf/tc/globals/cilium_policy_00061

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 298
Path: /sys/fs/bpf/tc/globals/cilium_policy_00298

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    433848   5532      0        
Allow    Ingress     1          ANY          NONE         disabled    12418    143       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 913
Path: /sys/fs/bpf/tc/globals/cilium_policy_00913

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3880964   36195     0        
Allow    Ingress     1          ANY          NONE         disabled    2907538   29165     0        
Allow    Egress      0          ANY          NONE         disabled    4238794   39178     0        


Endpoint ID: 1813
Path: /sys/fs/bpf/tc/globals/cilium_policy_01813

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    87553   1007      0        
Allow    Egress      0          ANY          NONE         disabled    13996   146       0        


Endpoint ID: 3577
Path: /sys/fs/bpf/tc/globals/cilium_policy_03577

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    87619   1008      0        
Allow    Egress      0          ANY          NONE         disabled    14914   157       0        


