{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:43.417Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.148.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:43.417Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:48.189Z",
  "value": "id=298   sec_id=4     flags=0x0000 ifindex=7   mac=DE:8E:19:82:0D:71 nodemac=E6:F3:F2:5D:C2:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:48.194Z",
  "value": "id=1813  sec_id=1652215 flags=0x0000 ifindex=9   mac=FE:E1:C1:A3:D5:18 nodemac=8E:6F:CD:15:50:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:48.234Z",
  "value": "id=3577  sec_id=1652215 flags=0x0000 ifindex=11  mac=0E:8C:CD:0A:D8:30 nodemac=12:DD:CD:41:87:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:13:48.273Z",
  "value": "id=298   sec_id=4     flags=0x0000 ifindex=7   mac=DE:8E:19:82:0D:71 nodemac=E6:F3:F2:5D:C2:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:15.368Z",
  "value": "id=298   sec_id=4     flags=0x0000 ifindex=7   mac=DE:8E:19:82:0D:71 nodemac=E6:F3:F2:5D:C2:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:15.369Z",
  "value": "id=1813  sec_id=1652215 flags=0x0000 ifindex=9   mac=FE:E1:C1:A3:D5:18 nodemac=8E:6F:CD:15:50:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:15.370Z",
  "value": "id=3577  sec_id=1652215 flags=0x0000 ifindex=11  mac=0E:8C:CD:0A:D8:30 nodemac=12:DD:CD:41:87:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:15.416Z",
  "value": "id=165   sec_id=1683852 flags=0x0000 ifindex=13  mac=1A:64:38:70:7B:70 nodemac=9E:26:36:A1:8F:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:16.369Z",
  "value": "id=165   sec_id=1683852 flags=0x0000 ifindex=13  mac=1A:64:38:70:7B:70 nodemac=9E:26:36:A1:8F:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:16.369Z",
  "value": "id=298   sec_id=4     flags=0x0000 ifindex=7   mac=DE:8E:19:82:0D:71 nodemac=E6:F3:F2:5D:C2:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:16.369Z",
  "value": "id=3577  sec_id=1652215 flags=0x0000 ifindex=11  mac=0E:8C:CD:0A:D8:30 nodemac=12:DD:CD:41:87:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:16.369Z",
  "value": "id=1813  sec_id=1652215 flags=0x0000 ifindex=9   mac=FE:E1:C1:A3:D5:18 nodemac=8E:6F:CD:15:50:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:26.916Z",
  "value": "id=913   sec_id=1683852 flags=0x0000 ifindex=15  mac=FE:2D:18:2F:EA:89 nodemac=72:2B:09:A0:7C:FB"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.24.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:37.324Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:13.786Z",
  "value": "id=3577  sec_id=1652215 flags=0x0000 ifindex=11  mac=0E:8C:CD:0A:D8:30 nodemac=12:DD:CD:41:87:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:13.787Z",
  "value": "id=913   sec_id=1683852 flags=0x0000 ifindex=15  mac=FE:2D:18:2F:EA:89 nodemac=72:2B:09:A0:7C:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:13.788Z",
  "value": "id=298   sec_id=4     flags=0x0000 ifindex=7   mac=DE:8E:19:82:0D:71 nodemac=E6:F3:F2:5D:C2:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:13.788Z",
  "value": "id=1813  sec_id=1652215 flags=0x0000 ifindex=9   mac=FE:E1:C1:A3:D5:18 nodemac=8E:6F:CD:15:50:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:14.786Z",
  "value": "id=913   sec_id=1683852 flags=0x0000 ifindex=15  mac=FE:2D:18:2F:EA:89 nodemac=72:2B:09:A0:7C:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:14.787Z",
  "value": "id=1813  sec_id=1652215 flags=0x0000 ifindex=9   mac=FE:E1:C1:A3:D5:18 nodemac=8E:6F:CD:15:50:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:14.787Z",
  "value": "id=298   sec_id=4     flags=0x0000 ifindex=7   mac=DE:8E:19:82:0D:71 nodemac=E6:F3:F2:5D:C2:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:14.787Z",
  "value": "id=3577  sec_id=1652215 flags=0x0000 ifindex=11  mac=0E:8C:CD:0A:D8:30 nodemac=12:DD:CD:41:87:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:15.787Z",
  "value": "id=298   sec_id=4     flags=0x0000 ifindex=7   mac=DE:8E:19:82:0D:71 nodemac=E6:F3:F2:5D:C2:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:15.787Z",
  "value": "id=3577  sec_id=1652215 flags=0x0000 ifindex=11  mac=0E:8C:CD:0A:D8:30 nodemac=12:DD:CD:41:87:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:15.787Z",
  "value": "id=913   sec_id=1683852 flags=0x0000 ifindex=15  mac=FE:2D:18:2F:EA:89 nodemac=72:2B:09:A0:7C:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.24.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:15.788Z",
  "value": "id=1813  sec_id=1652215 flags=0x0000 ifindex=9   mac=FE:E1:C1:A3:D5:18 nodemac=8E:6F:CD:15:50:A0"
}

