CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2565d74c_0684_4949_a233_4d2bed8a8cc1.slice/cri-containerd-40ae3317cea131093ee73ffb2ceb0215cb3741039a6b73a22e27959ae6463c14.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2565d74c_0684_4949_a233_4d2bed8a8cc1.slice/cri-containerd-7afbde2da36c214fe132ea8907fb1ab665ae6af389a9f53fd1dc6b100d77e728.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod00781af7_b370_4ba0_8e93_bddd5775e121.slice/cri-containerd-2cd7a12c09179c7b6d651471a1a3e068f688102710e8cbdc0e9611baa082a983.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod00781af7_b370_4ba0_8e93_bddd5775e121.slice/cri-containerd-c9ce211e8d5f18339a4284ac678265f7c5433d838c014738a09c56b786c7e040.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36f90bc7_216a_4969_ac90_042ba981877d.slice/cri-containerd-056e5873279b2794f3a92357410f0f3be167e196bf484a515f726b05394a3571.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36f90bc7_216a_4969_ac90_042ba981877d.slice/cri-containerd-4fe2425c134b2223b6477facadb2f3ce344d39d6141c436ea10d7b2b88d563a9.scope
    541      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8f049efa_3dbe_4c3f_a09e_e1eb94b1a013.slice/cri-containerd-e15e3e64372191df578b142305468bd5bed694d4aa11fd1171c323d425804b4f.scope
    537      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8f049efa_3dbe_4c3f_a09e_e1eb94b1a013.slice/cri-containerd-6dc93ff295494be0a7c39ab0d5f16498c0252355e939823a73f01ec342d99b49.scope
    545      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc0b064f_0322_4717_89fb_705b3f203918.slice/cri-containerd-5a07b71d97c3c53daf76ab0d342645d1d9b4e9e939a2a24cff60b72a54e82cef.scope
    76       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcc0b064f_0322_4717_89fb_705b3f203918.slice/cri-containerd-a727be50b23c202d0bdfdaab28ba1c8ffc8f949d8d9f0748bf7bd5f3da222dd1.scope
    61       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ae413cd_3ce1_4278_b169_be22ff82316a.slice/cri-containerd-081c42fa1f3d053e561357e115f8a4547e94826e83b71ec89bb3e8c232983891.scope
    72       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ae413cd_3ce1_4278_b169_be22ff82316a.slice/cri-containerd-3b2c9d65c1cf97002de93fccb9e45560c5b955fbfb943c3bb6bf26dd32c9fb60.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod435da87f_8170_46b8_ae9a_958dd0c7c55e.slice/cri-containerd-ee6bfd68c14c11d78c759761d7fd530d42fc283eb5e6fd904b976df542eb783a.scope
    627      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod435da87f_8170_46b8_ae9a_958dd0c7c55e.slice/cri-containerd-71e74dce9d33d59385f2b8eed256a9a4fd7cf3273dfb6e912cd3fd9d784af550.scope
    619      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod435da87f_8170_46b8_ae9a_958dd0c7c55e.slice/cri-containerd-6c81b0a7b7955e5d86b03007ce922bfea5e10be078f45bc5bd38ec54a00e7c1c.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod435da87f_8170_46b8_ae9a_958dd0c7c55e.slice/cri-containerd-aeee6051ac5c5de2bc681de0864cd9250ef5eb2fa3256c87369c8b222ca72c96.scope
    603      cgroup_device   multi                                          
