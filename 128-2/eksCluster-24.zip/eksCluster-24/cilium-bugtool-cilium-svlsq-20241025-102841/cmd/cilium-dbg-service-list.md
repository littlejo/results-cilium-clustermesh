ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.193.144:443 (active)    
                                         2 => 172.31.158.164:443 (active)    
2    10.100.191.173:443   ClusterIP      1 => 172.31.148.101:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.24.0.57:53 (active)         
                                         2 => 10.24.0.25:53 (active)         
4    10.100.0.10:9153     ClusterIP      1 => 10.24.0.57:9153 (active)       
                                         2 => 10.24.0.25:9153 (active)       
5    10.100.40.222:2379   ClusterIP      1 => 10.24.0.204:2379 (active)      
