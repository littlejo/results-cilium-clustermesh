ip-172-31-148-101.eu-west-3.compute.internal
