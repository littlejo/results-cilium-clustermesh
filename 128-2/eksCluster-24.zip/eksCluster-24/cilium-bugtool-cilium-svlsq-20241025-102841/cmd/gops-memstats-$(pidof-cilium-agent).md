alloc: 129.28MB (135560568 bytes)
total-alloc: 1.33GB (1432165160 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 47771606
frees: 46477477
heap-alloc: 129.28MB (135560568 bytes)
heap-sys: 165.02MB (173031424 bytes)
heap-idle: 19.51MB (20455424 bytes)
heap-in-use: 145.51MB (152576000 bytes)
heap-released: 2.52MB (2637824 bytes)
heap-objects: 1294129
stack-in-use: 34.94MB (36634624 bytes)
stack-sys: 34.94MB (36634624 bytes)
stack-mspan-inuse: 2.26MB (2369120 bytes)
stack-mspan-sys: 2.35MB (2464320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.01MB (1057697 bytes)
gc-sys: 5.15MB (5404856 bytes)
next-gc: when heap-alloc >= 158.12MB (165803880 bytes)
last-gc: 2024-10-25 10:28:42.778406426 +0000 UTC
gc-pause-total: 16.544338ms
gc-pause: 5903699
gc-pause-end: 1729852122778406426
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0004177883177298307
enable-gc: true
debug-gc: false
