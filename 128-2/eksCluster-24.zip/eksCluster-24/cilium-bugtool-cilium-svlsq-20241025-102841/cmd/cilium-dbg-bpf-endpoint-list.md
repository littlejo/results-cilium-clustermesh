IP ADDRESS         LOCAL ENDPOINT INFO
10.24.0.204:0      id=913   sec_id=1683852 flags=0x0000 ifindex=15  mac=FE:2D:18:2F:EA:89 nodemac=72:2B:09:A0:7C:FB   
10.24.0.57:0       id=1813  sec_id=1652215 flags=0x0000 ifindex=9   mac=FE:E1:C1:A3:D5:18 nodemac=8E:6F:CD:15:50:A0   
10.24.0.252:0      id=298   sec_id=4     flags=0x0000 ifindex=7   mac=DE:8E:19:82:0D:71 nodemac=E6:F3:F2:5D:C2:A0     
10.24.0.25:0       id=3577  sec_id=1652215 flags=0x0000 ifindex=11  mac=0E:8C:CD:0A:D8:30 nodemac=12:DD:CD:41:87:AD   
10.24.0.180:0      (localhost)                                                                                        
172.31.148.101:0   (localhost)                                                                                        
