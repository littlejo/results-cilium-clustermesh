32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:12:58+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:12:59+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:12:59+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:59+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:12:59+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:12:59+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:12:59+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:03+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
58: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
61: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
62: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
65: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
68: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
69: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
72: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
73: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
76: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
444: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 112
445: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 113
446: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 114
447: sched_cls  name tail_handle_ipv4  tag ed92d0e31e7cb003  gpl
	loaded_at 2024-10-25T10:13:45+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 115
469: sched_cls  name tail_ipv4_ct_ingress  tag 27d38b5583116126  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,98,74,75,100,76
	btf_id 143
472: sched_cls  name tail_ipv4_ct_egress  tag 763d31be0a8dc5d2  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,98,74,75,100,76
	btf_id 144
474: sched_cls  name tail_handle_ipv4_cont  tag 82be3cb7ec03078e  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,100,33,97,74,75,31,68,66,69,98,32,29,30,73
	btf_id 147
479: sched_cls  name handle_policy  tag 58466d70caba66c4  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,98,74,75,100,33,72,97,31,76,67,32,29,30
	btf_id 149
481: sched_cls  name tail_ipv4_to_endpoint  tag a7436d28290e9389  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,100,33,74,75,72,97,31,98,32,29,30
	btf_id 154
482: sched_cls  name __send_drop_notify  tag 2679e3645dec048e  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 156
483: sched_cls  name tail_handle_arp  tag 8de8f8647fb20dce  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,98
	btf_id 157
484: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,98
	btf_id 158
488: sched_cls  name cil_from_container  tag 236de4387485749f  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 104,68
	btf_id 163
489: sched_cls  name tail_handle_ipv4  tag 3f25d95e63e3ff7c  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,98
	btf_id 159
490: sched_cls  name cil_from_container  tag d96dab40e81f6222  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 98,68
	btf_id 165
492: sched_cls  name tail_ipv4_ct_ingress  tag 1b2cc206f86a39bb  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 164
493: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 169
494: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,106
	btf_id 170
496: sched_cls  name __send_drop_notify  tag 4fb6aef83b639d38  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 172
497: sched_cls  name tail_handle_ipv4_from_host  tag fdb508fe0d684e80  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,106
	btf_id 173
499: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,106
	btf_id 175
502: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 179
503: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,108
	btf_id 180
505: sched_cls  name __send_drop_notify  tag 4fb6aef83b639d38  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 182
506: sched_cls  name tail_handle_ipv4_from_host  tag fdb508fe0d684e80  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,108
	btf_id 183
507: sched_cls  name handle_policy  tag 0a2034fbbf631c4f  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,104,74,75,103,33,72,102,31,76,67,32,29,30
	btf_id 167
510: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,110
	btf_id 188
511: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,110,67
	btf_id 189
512: sched_cls  name __send_drop_notify  tag 4fb6aef83b639d38  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 190
513: sched_cls  name tail_handle_ipv4_from_host  tag fdb508fe0d684e80  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,110
	btf_id 191
516: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,112
	btf_id 195
517: sched_cls  name tail_handle_ipv4  tag 1758af0db48e24e3  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,104
	btf_id 186
518: sched_cls  name tail_ipv4_to_endpoint  tag a1bcfae9d93c6aa4  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,103,33,74,75,72,102,31,104,32,29,30
	btf_id 196
519: sched_cls  name tail_handle_arp  tag 8554a41a7bfb085c  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,104
	btf_id 198
520: sched_cls  name tail_handle_ipv4_cont  tag 03ba96ff87c1600c  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,111,33,90,74,75,31,68,66,69,112,32,29,30,73
	btf_id 197
521: sched_cls  name tail_ipv4_ct_egress  tag 763d31be0a8dc5d2  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 199
522: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,104
	btf_id 200
524: sched_cls  name tail_handle_ipv4_cont  tag 22797ba4e02c3413  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,103,33,102,74,75,31,68,66,69,104,32,29,30,73
	btf_id 202
525: sched_cls  name __send_drop_notify  tag 50c3002070413767  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 203
526: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,112,74,75,111,76
	btf_id 204
527: sched_cls  name __send_drop_notify  tag 47cde7e10502b66f  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 205
528: sched_cls  name tail_handle_arp  tag ea460daf31082eb6  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,112
	btf_id 206
529: sched_cls  name tail_ipv4_ct_ingress  tag aca4767d078da95e  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,112,74,75,111,76
	btf_id 207
530: sched_cls  name cil_from_container  tag 32587f114dbe3b48  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 112,68
	btf_id 208
531: sched_cls  name tail_handle_ipv4  tag ed91452f391b86f5  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,112
	btf_id 209
532: sched_cls  name tail_ipv4_to_endpoint  tag e631665fe4722e47  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,111,33,74,75,72,90,31,112,32,29,30
	btf_id 210
533: sched_cls  name handle_policy  tag 36a8f47e07e968cb  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,112,74,75,111,33,72,90,31,76,67,32,29,30
	btf_id 211
534: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
537: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
538: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
541: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
542: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
545: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
546: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
549: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
590: sched_cls  name tail_ipv4_ct_ingress  tag e1b4566f70f31568  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,128,74,75,129,76
	btf_id 228
591: sched_cls  name tail_handle_arp  tag dbd29cd69e4b677a  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,128
	btf_id 229
592: sched_cls  name __send_drop_notify  tag 9392f5dee7f9cf9e  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 230
593: sched_cls  name tail_ipv4_ct_egress  tag b121c8aecec7d56b  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,128,74,75,129,76
	btf_id 231
594: sched_cls  name tail_handle_ipv4  tag 622c7df887837bd8  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,128
	btf_id 232
595: sched_cls  name tail_ipv4_to_endpoint  tag bdbce78859e99fe0  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,129,33,74,75,72,127,31,128,32,29,30
	btf_id 233
596: sched_cls  name cil_from_container  tag d38bfa33f3f03a0c  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 128,68
	btf_id 234
597: sched_cls  name handle_policy  tag 2f32ebae8faa447e  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,128,74,75,129,33,72,127,31,76,67,32,29,30
	btf_id 235
598: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,128
	btf_id 236
599: sched_cls  name tail_handle_ipv4_cont  tag 99d6ec287f0e3c72  gpl
	loaded_at 2024-10-25T10:22:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,129,33,127,74,75,31,68,66,69,128,32,29,30,73
	btf_id 237
600: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
603: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
616: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
619: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
620: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
623: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
624: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
627: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
