markdown output at /tmp/cilium-bugtool-20241025-102842.698+0000-UTC-2522010073/cmd/cilium-debuginfo-20241025-102913.389+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102842.698+0000-UTC-2522010073/cmd/cilium-debuginfo-20241025-102913.389+0000-UTC.json
