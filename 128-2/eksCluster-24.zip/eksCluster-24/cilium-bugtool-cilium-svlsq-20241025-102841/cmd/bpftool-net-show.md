xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 511
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 502
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 493
cilium_host(4) clsact/egress cil_from_host-cilium_host id 499
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 445
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 444
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 530
lxc90c86841445f(9) clsact/ingress cil_from_container-lxc90c86841445f id 490
lxc8995de88d20e(11) clsact/ingress cil_from_container-lxc8995de88d20e id 488
lxc80ed87983d46(15) clsact/ingress cil_from_container-lxc80ed87983d46 id 596

flow_dissector:

netfilter:

