{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:52.651Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.159.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:52.651Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.165.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:52.651Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:57.413Z",
  "value": "id=941   sec_id=4     flags=0x0000 ifindex=10  mac=06:41:9D:F0:DE:87 nodemac=4A:0C:03:92:1C:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:57.419Z",
  "value": "id=516   sec_id=6621480 flags=0x0000 ifindex=12  mac=5A:85:14:0D:7C:EA nodemac=1A:60:4C:D2:08:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:57.456Z",
  "value": "id=1968  sec_id=6621480 flags=0x0000 ifindex=14  mac=A6:69:76:99:01:89 nodemac=0A:44:2A:06:D1:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:57.536Z",
  "value": "id=941   sec_id=4     flags=0x0000 ifindex=10  mac=06:41:9D:F0:DE:87 nodemac=4A:0C:03:92:1C:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:32.323Z",
  "value": "id=941   sec_id=4     flags=0x0000 ifindex=10  mac=06:41:9D:F0:DE:87 nodemac=4A:0C:03:92:1C:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:32.324Z",
  "value": "id=516   sec_id=6621480 flags=0x0000 ifindex=12  mac=5A:85:14:0D:7C:EA nodemac=1A:60:4C:D2:08:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:32.324Z",
  "value": "id=1968  sec_id=6621480 flags=0x0000 ifindex=14  mac=A6:69:76:99:01:89 nodemac=0A:44:2A:06:D1:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:32.354Z",
  "value": "id=2947  sec_id=6621045 flags=0x0000 ifindex=16  mac=22:06:B9:E3:43:0F nodemac=DE:64:F9:44:58:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:33.323Z",
  "value": "id=941   sec_id=4     flags=0x0000 ifindex=10  mac=06:41:9D:F0:DE:87 nodemac=4A:0C:03:92:1C:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:33.323Z",
  "value": "id=1968  sec_id=6621480 flags=0x0000 ifindex=14  mac=A6:69:76:99:01:89 nodemac=0A:44:2A:06:D1:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:33.323Z",
  "value": "id=516   sec_id=6621480 flags=0x0000 ifindex=12  mac=5A:85:14:0D:7C:EA nodemac=1A:60:4C:D2:08:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:33.323Z",
  "value": "id=2947  sec_id=6621045 flags=0x0000 ifindex=16  mac=22:06:B9:E3:43:0F nodemac=DE:64:F9:44:58:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:28.557Z",
  "value": "id=264   sec_id=6621045 flags=0x0000 ifindex=18  mac=FE:64:87:16:86:C2 nodemac=76:75:30:D7:65:0B"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:38.851Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:05.169Z",
  "value": "id=264   sec_id=6621045 flags=0x0000 ifindex=18  mac=FE:64:87:16:86:C2 nodemac=76:75:30:D7:65:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:05.184Z",
  "value": "id=941   sec_id=4     flags=0x0000 ifindex=10  mac=06:41:9D:F0:DE:87 nodemac=4A:0C:03:92:1C:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:05.185Z",
  "value": "id=516   sec_id=6621480 flags=0x0000 ifindex=12  mac=5A:85:14:0D:7C:EA nodemac=1A:60:4C:D2:08:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:05.186Z",
  "value": "id=1968  sec_id=6621480 flags=0x0000 ifindex=14  mac=A6:69:76:99:01:89 nodemac=0A:44:2A:06:D1:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:06.136Z",
  "value": "id=516   sec_id=6621480 flags=0x0000 ifindex=12  mac=5A:85:14:0D:7C:EA nodemac=1A:60:4C:D2:08:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:06.136Z",
  "value": "id=1968  sec_id=6621480 flags=0x0000 ifindex=14  mac=A6:69:76:99:01:89 nodemac=0A:44:2A:06:D1:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:06.136Z",
  "value": "id=264   sec_id=6621045 flags=0x0000 ifindex=18  mac=FE:64:87:16:86:C2 nodemac=76:75:30:D7:65:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:06.137Z",
  "value": "id=941   sec_id=4     flags=0x0000 ifindex=10  mac=06:41:9D:F0:DE:87 nodemac=4A:0C:03:92:1C:19"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.136Z",
  "value": "id=516   sec_id=6621480 flags=0x0000 ifindex=12  mac=5A:85:14:0D:7C:EA nodemac=1A:60:4C:D2:08:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.136Z",
  "value": "id=264   sec_id=6621045 flags=0x0000 ifindex=18  mac=FE:64:87:16:86:C2 nodemac=76:75:30:D7:65:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.137Z",
  "value": "id=1968  sec_id=6621480 flags=0x0000 ifindex=14  mac=A6:69:76:99:01:89 nodemac=0A:44:2A:06:D1:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:07.137Z",
  "value": "id=941   sec_id=4     flags=0x0000 ifindex=10  mac=06:41:9D:F0:DE:87 nodemac=4A:0C:03:92:1C:19"
}

