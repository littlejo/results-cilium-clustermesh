KEY             VALUE
AgentLiveness   896207036357
UTimeOffset     3378615734375000
