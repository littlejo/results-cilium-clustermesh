REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10087     790783     677    bpf_overlay.c
Interface                 INGRESS     223720    85677395   1132   bpf_host.c
Success                   EGRESS      10317     806778     53     encap.h
Success                   EGRESS      5185      399509     1694   bpf_host.c
Success                   EGRESS      95652     12539395   1308   bpf_lxc.c
Success                   INGRESS     106444    13141291   86     l3.h
Success                   INGRESS     111995    13576471   235    trace.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
