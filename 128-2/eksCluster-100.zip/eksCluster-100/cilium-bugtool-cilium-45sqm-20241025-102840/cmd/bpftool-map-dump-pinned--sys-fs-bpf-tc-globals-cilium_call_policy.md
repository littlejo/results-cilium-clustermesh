key: 08 01 00 00  value: 81 02 00 00
key: 04 02 00 00  value: 05 02 00 00
key: ad 03 00 00  value: 48 02 00 00
key: b0 07 00 00  value: 2b 02 00 00
Found 4 elements
