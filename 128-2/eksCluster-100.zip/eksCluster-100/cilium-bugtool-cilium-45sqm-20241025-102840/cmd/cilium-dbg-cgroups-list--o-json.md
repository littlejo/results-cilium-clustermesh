[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod60176ea7_5435_45ae_88d7_92cf6167d23c.slice/cri-containerd-1f04ebe76a55e834504caace745d5033c905073eb293df0ccbe597aaec2c2714.scope"
      }
    ],
    "ips": [
      "10.100.0.212"
    ],
    "name": "coredns-cc6ccd49c-l744t",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod88c14d51_20dd_43b0_94c7_9cf4907bd74b.slice/cri-containerd-60ee76799b294dbe3547293dcde931ed35d4d92af539db398e7a9bb203875712.scope"
      }
    ],
    "ips": [
      "10.100.0.20"
    ],
    "name": "coredns-cc6ccd49c-hjs2l",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5cbb562e_330c_418a_8ff2_91d86ced3540.slice/cri-containerd-972af5da0365c72a0cd7111cf409137401cbf001671ffcbcc4b1150b9e139315.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5cbb562e_330c_418a_8ff2_91d86ced3540.slice/cri-containerd-9acbf51d14ce950852b64d4c167d950e275244e8112dcd6051968dfb48c8db56.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5cbb562e_330c_418a_8ff2_91d86ced3540.slice/cri-containerd-e74ab36319a69e4b8285a6a911809d45de59c26514eadc3c8c09fa22f225bd66.scope"
      }
    ],
    "ips": [
      "10.100.0.58"
    ],
    "name": "clustermesh-apiserver-6d759d98c4-vj5dq",
    "namespace": "kube-system"
  }
]

