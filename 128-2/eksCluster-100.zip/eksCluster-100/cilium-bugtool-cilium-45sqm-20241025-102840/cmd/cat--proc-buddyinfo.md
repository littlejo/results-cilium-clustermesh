Node 0, zone      DMA      2      8      9      6      3     29     73     17      8      4    157 
Node 0, zone   Normal      3      2      1      1      0     14     10      7      4      1      7 
