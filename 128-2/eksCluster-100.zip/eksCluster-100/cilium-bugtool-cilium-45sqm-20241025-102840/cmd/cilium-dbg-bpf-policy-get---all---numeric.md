Endpoint ID: 264
Path: /sys/fs/bpf/tc/globals/cilium_policy_00264

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3810640   36209     0        
Allow    Ingress     1          ANY          NONE         disabled    3346779   34077     0        
Allow    Egress      0          ANY          NONE         disabled    5133484   47172     0        


Endpoint ID: 516
Path: /sys/fs/bpf/tc/globals/cilium_policy_00516

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    74734   860       0        
Allow    Egress      0          ANY          NONE         disabled    13320   137       0        


Endpoint ID: 941
Path: /sys/fs/bpf/tc/globals/cilium_policy_00941

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    436001   5562      0        
Allow    Ingress     1          ANY          NONE         disabled    11152    129       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1669
Path: /sys/fs/bpf/tc/globals/cilium_policy_01669

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1968
Path: /sys/fs/bpf/tc/globals/cilium_policy_01968

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    74623   856       0        
Allow    Egress      0          ANY          NONE         disabled    13028   133       0        


