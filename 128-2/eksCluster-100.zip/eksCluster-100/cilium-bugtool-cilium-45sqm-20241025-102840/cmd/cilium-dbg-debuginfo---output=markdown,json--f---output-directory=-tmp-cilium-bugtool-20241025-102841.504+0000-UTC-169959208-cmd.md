markdown output at /tmp/cilium-bugtool-20241025-102841.504+0000-UTC-169959208/cmd/cilium-debuginfo-20241025-102912.181+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102841.504+0000-UTC-169959208/cmd/cilium-debuginfo-20241025-102912.181+0000-UTC.json
