IP ADDRESS         LOCAL ENDPOINT INFO
10.100.0.20:0      id=516   sec_id=6621480 flags=0x0000 ifindex=12  mac=5A:85:14:0D:7C:EA nodemac=1A:60:4C:D2:08:BC   
10.100.0.204:0     id=941   sec_id=4     flags=0x0000 ifindex=10  mac=06:41:9D:F0:DE:87 nodemac=4A:0C:03:92:1C:19     
172.31.159.111:0   (localhost)                                                                                        
10.100.0.85:0      (localhost)                                                                                        
172.31.165.24:0    (localhost)                                                                                        
10.100.0.212:0     id=1968  sec_id=6621480 flags=0x0000 ifindex=14  mac=A6:69:76:99:01:89 nodemac=0A:44:2A:06:D1:14   
10.100.0.58:0      id=264   sec_id=6621045 flags=0x0000 ifindex=18  mac=FE:64:87:16:86:C2 nodemac=76:75:30:D7:65:0B   
