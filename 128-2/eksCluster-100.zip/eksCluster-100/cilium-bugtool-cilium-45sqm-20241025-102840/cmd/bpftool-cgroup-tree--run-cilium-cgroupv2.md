CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod160bd40a_e8ff_46f6_9e66_1b220ac102c7.slice/cri-containerd-d87de199e571ee649b8614c98f3163673918f197de5f666c7222ffabdad1c75b.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod160bd40a_e8ff_46f6_9e66_1b220ac102c7.slice/cri-containerd-13eb85261a2d437eb040f7b16923295c701b5aca6b1f23f9124d7546e1a2c44b.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod60176ea7_5435_45ae_88d7_92cf6167d23c.slice/cri-containerd-1f04ebe76a55e834504caace745d5033c905073eb293df0ccbe597aaec2c2714.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod60176ea7_5435_45ae_88d7_92cf6167d23c.slice/cri-containerd-6ac3714251cdcd8c83863334604fbaf23d8a0da580bd0575dcf3f3653034e6d6.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod88c14d51_20dd_43b0_94c7_9cf4907bd74b.slice/cri-containerd-90cedf83567f2e4c9525a2ee1419c81d9330b92c9ad70a623d56401f1b58d93e.scope
    583      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod88c14d51_20dd_43b0_94c7_9cf4907bd74b.slice/cri-containerd-60ee76799b294dbe3547293dcde931ed35d4d92af539db398e7a9bb203875712.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf529f7dc_754b_417f_bdba_74326e8a71a4.slice/cri-containerd-30a1e9a6b48bd8dcbc3eb35e25e807826d35fcfb2b1d80a1d0fb7c39a89a50b4.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf529f7dc_754b_417f_bdba_74326e8a71a4.slice/cri-containerd-bdbf5acdc80c7347ed637b567c45fc7c998d87e9c23e4caafacd40731f8c1daf.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod53d92904_1521_46e1_bbb1_dc46cfedc523.slice/cri-containerd-737b63fd8b370d94647768729db8c24334bbbbab9541bc5652614218f3eff503.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod53d92904_1521_46e1_bbb1_dc46cfedc523.slice/cri-containerd-cb22e8fdb85c603c55910bfbb4e421ed4ea48a898499e11b473848c10d7e69ca.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc94738a2_e8cf_4cb6_9ce7_d907c64d5498.slice/cri-containerd-ce8087b1f6b8b6b7995162addeea635aa8e2b4aec5d3bc5e807f6d5ac7cc58b4.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc94738a2_e8cf_4cb6_9ce7_d907c64d5498.slice/cri-containerd-b8b48569d9b66dcca228a4cbef3a5aeb7a4f55a68fed007799d4df69635cdf79.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5cbb562e_330c_418a_8ff2_91d86ced3540.slice/cri-containerd-8adaea9a29872dace400c7047b6f3f3117ff46934a30ed08884e632f8b914a4a.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5cbb562e_330c_418a_8ff2_91d86ced3540.slice/cri-containerd-9acbf51d14ce950852b64d4c167d950e275244e8112dcd6051968dfb48c8db56.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5cbb562e_330c_418a_8ff2_91d86ced3540.slice/cri-containerd-e74ab36319a69e4b8285a6a911809d45de59c26514eadc3c8c09fa22f225bd66.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5cbb562e_330c_418a_8ff2_91d86ced3540.slice/cri-containerd-972af5da0365c72a0cd7111cf409137401cbf001671ffcbcc4b1150b9e139315.scope
    671      cgroup_device   multi                                          
