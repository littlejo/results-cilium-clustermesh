 10:28:41 up 14 min,  0 users,  load average: 0.14, 0.19, 0.16
