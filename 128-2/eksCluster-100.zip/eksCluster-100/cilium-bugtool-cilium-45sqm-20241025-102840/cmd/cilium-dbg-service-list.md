ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.243.67:443 (active)    
                                         2 => 172.31.147.123:443 (active)   
2    10.100.247.82:443    ClusterIP      1 => 172.31.165.24:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.100.0.20:53 (active)       
                                         2 => 10.100.0.212:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.100.0.20:9153 (active)     
                                         2 => 10.100.0.212:9153 (active)    
5    10.100.65.138:2379   ClusterIP      1 => 10.100.0.58:2379 (active)     
