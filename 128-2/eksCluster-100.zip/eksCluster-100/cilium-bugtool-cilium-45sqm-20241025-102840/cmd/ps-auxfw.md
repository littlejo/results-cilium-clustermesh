USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         665  0.0  0.3 1240432 15696 ?       Dsl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         694  0.0  0.3 1240432 15696 ?       R    10:28   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         695  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         664  0.0  0.1 1229000 4056 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         646  0.0  0.1 1228744 4036 ?        Ssl  10:28   0:00 /bin/gops stats 1
root         645  0.0  0.1 1228744 4036 ?        Ssl  10:28   0:00 /bin/gops memstats 1
root         644  0.0  0.0 1228744 3780 ?        Ssl  10:28   0:00 /bin/gops stack 1
root           1  3.0  7.1 1538100 281172 ?      Ssl  10:15   0:23 cilium-agent --config-dir=/tmp/cilium/config-map
root         406  0.0  0.1 1228848 6648 ?        Sl   10:15   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
