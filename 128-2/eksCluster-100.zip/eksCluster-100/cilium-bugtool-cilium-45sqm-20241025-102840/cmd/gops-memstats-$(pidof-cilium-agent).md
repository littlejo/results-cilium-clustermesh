alloc: 86.78MB (91000360 bytes)
total-alloc: 1.36GB (1459291832 bytes)
sys: 214.38MB (224798036 bytes)
lookups: 0
mallocs: 48249819
frees: 47456969
heap-alloc: 86.78MB (91000360 bytes)
heap-sys: 169.20MB (177414144 bytes)
heap-idle: 50.30MB (52740096 bytes)
heap-in-use: 118.90MB (124674048 bytes)
heap-released: 3.84MB (4030464 bytes)
heap-objects: 792850
stack-in-use: 34.78MB (36470784 bytes)
stack-sys: 34.78MB (36470784 bytes)
stack-mspan-inuse: 2.00MB (2096320 bytes)
stack-mspan-sys: 2.43MB (2545920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 928.38KB (950665 bytes)
gc-sys: 5.15MB (5400904 bytes)
next-gc: when heap-alloc >= 147.04MB (154179592 bytes)
last-gc: 2024-10-25 10:28:53.962608289 +0000 UTC
gc-pause-total: 6.277223ms
gc-pause: 60063
gc-pause-end: 1729852133962608289
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0003827510546882976
enable-gc: true
debug-gc: false
