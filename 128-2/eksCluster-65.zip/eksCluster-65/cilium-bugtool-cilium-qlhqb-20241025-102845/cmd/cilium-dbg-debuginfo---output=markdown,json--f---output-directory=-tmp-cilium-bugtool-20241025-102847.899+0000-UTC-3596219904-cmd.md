markdown output at /tmp/cilium-bugtool-20241025-102847.899+0000-UTC-3596219904/cmd/cilium-debuginfo-20241025-102917.973+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102847.899+0000-UTC-3596219904/cmd/cilium-debuginfo-20241025-102917.973+0000-UTC.json
