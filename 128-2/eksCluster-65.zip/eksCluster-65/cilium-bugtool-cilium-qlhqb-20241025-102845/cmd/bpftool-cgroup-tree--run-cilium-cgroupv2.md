CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6f98ab9_5dad_42e9_bb8e_224d887759d5.slice/cri-containerd-33a01ca54f3ece959b18dfc0883a68a3226214bdf8cb3cde51ec9daaa1b4377f.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6f98ab9_5dad_42e9_bb8e_224d887759d5.slice/cri-containerd-c1771998bb7842b23e74c7b209a67d830a77fa161c73d4b42d36075a5a7a5e0c.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0ba74476_bd66_4f5c_8c67_4d5c2cb6cb66.slice/cri-containerd-ad7f2d4fd6f9142ec5a2e43f51ee58443593270c67afbe64f9c3c36311b35208.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0ba74476_bd66_4f5c_8c67_4d5c2cb6cb66.slice/cri-containerd-2b8e28469cadd83c195d17ac3244f84dac6133aa365175e4d3773962679bc104.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67accedc_2489_4c5c_b22d_745c0a671793.slice/cri-containerd-03739dbcb4c34183b7598e1d2f4ce5a1de3d441c94fd077d0062cce2a05c2861.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod67accedc_2489_4c5c_b22d_745c0a671793.slice/cri-containerd-f1c90035286fc100706bbdc70871d2ef7fba36a66640465f5961c126f35b679c.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod174cc86c_3ae9_4716_82f2_5893b08daf5e.slice/cri-containerd-3acc533aee10126682ee96044314336a3066f600dcc644aa187d191df0acd1f6.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod174cc86c_3ae9_4716_82f2_5893b08daf5e.slice/cri-containerd-b150d6315bfe916681d8a6d7618495a6ced19a91aa810b90c6046d8561e2190e.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ddd2ab8_28c7_4962_9fb5_962eea1c100f.slice/cri-containerd-8a460e37c785440ed22b467e0ae9904bb6aab84f8acae76f8d421efb2d820c39.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8ddd2ab8_28c7_4962_9fb5_962eea1c100f.slice/cri-containerd-bd874f82c6ee92903f44688dcb5d73396fb5d91322c4e2b3f1e0b1c033246961.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb2f104f_90d4_47e9_ad62_79273aabae53.slice/cri-containerd-c25013415ed547cb3aecbe8ca30029a60a2a08ac9333d56cfd0d933b8ddf6e3a.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb2f104f_90d4_47e9_ad62_79273aabae53.slice/cri-containerd-8cc589d18c6f0afdcb06005049581f3b10c00240ddd1bce038967616e5c11e7b.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb2f104f_90d4_47e9_ad62_79273aabae53.slice/cri-containerd-1b2b55ef025bfb1fa36f1bdefa114a95444a11a739b1edcd4ae1e651fcafbec3.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb2f104f_90d4_47e9_ad62_79273aabae53.slice/cri-containerd-c38220d36d4c6ca5200a49ffa01ec297c0a5b36bb12fe341281c154103307984.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod351fa413_8726_4940_b916_3d6d53dca50d.slice/cri-containerd-721a322e64100e34eac63534b94699d4982c15239f1cceb71e4af6a27ef0cba0.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod351fa413_8726_4940_b916_3d6d53dca50d.slice/cri-containerd-b595202e76f7ef083bebf2b513274bf696c42fb5190324754a68c7a91520d6d3.scope
    94       cgroup_device   multi                                          
