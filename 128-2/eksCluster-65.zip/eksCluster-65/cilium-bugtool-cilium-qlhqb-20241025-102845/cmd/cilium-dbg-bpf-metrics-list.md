REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10154     795396     677    bpf_overlay.c
Interface                 INGRESS     221878    85797658   1132   bpf_host.c
Success                   EGRESS      10314     807539     53     encap.h
Success                   EGRESS      5198      400330     1694   bpf_host.c
Success                   EGRESS      94109     12425008   1308   bpf_lxc.c
Success                   INGRESS     103988    12868735   86     l3.h
Success                   INGRESS     109593    13307707   235    trace.h
Unsupported L3 protocol   EGRESS      37        2762       1492   bpf_lxc.c
