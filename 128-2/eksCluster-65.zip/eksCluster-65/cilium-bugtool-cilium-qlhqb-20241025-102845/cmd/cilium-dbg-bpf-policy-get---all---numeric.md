Endpoint ID: 137
Path: /sys/fs/bpf/tc/globals/cilium_policy_00137

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    75167   863       0        
Allow    Egress      0          ANY          NONE         disabled    12623   130       0        


Endpoint ID: 881
Path: /sys/fs/bpf/tc/globals/cilium_policy_00881

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    74441   852       0        
Allow    Egress      0          ANY          NONE         disabled    13690   142       0        


Endpoint ID: 1711
Path: /sys/fs/bpf/tc/globals/cilium_policy_01711

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3883235   36831     0        
Allow    Ingress     1          ANY          NONE         disabled    3067057   30996     0        
Allow    Egress      0          ANY          NONE         disabled    4962311   45793     0        


Endpoint ID: 2167
Path: /sys/fs/bpf/tc/globals/cilium_policy_02167

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    441418   5636      0        
Allow    Ingress     1          ANY          NONE         disabled    11448    134       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2359
Path: /sys/fs/bpf/tc/globals/cilium_policy_02359

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


