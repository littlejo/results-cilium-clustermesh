key: 89 00 00 00  value: 1e 02 00 00
key: 71 03 00 00  value: 0c 02 00 00
key: af 06 00 00  value: 81 02 00 00
key: 77 08 00 00  value: 40 02 00 00
Found 4 elements
