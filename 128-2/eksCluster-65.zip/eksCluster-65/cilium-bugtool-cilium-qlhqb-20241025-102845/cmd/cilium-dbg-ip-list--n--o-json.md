[
  {
    "cidr": "0.0.0.0/0",
    "identity": 2
  },
  {
    "cidr": "10.0.0.5/32",
    "hostIP": "172.31.188.219",
    "identity": 6
  },
  {
    "cidr": "10.0.0.110/32",
    "hostIP": "172.31.188.219",
    "identity": 111677,
    "metadata": {
      "name": "coredns-cc6ccd49c-p8kfz",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.0.0.126/32",
    "hostIP": "172.31.188.219",
    "identity": 4
  },
  {
    "cidr": "10.0.0.134/32",
    "hostIP": "172.31.188.219",
    "identity": 111677,
    "metadata": {
      "name": "coredns-cc6ccd49c-5c2kl",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.0.0.254/32",
    "hostIP": "172.31.188.219",
    "identity": 74789,
    "metadata": {
      "name": "clustermesh-apiserver-84bc65c54-kmw2v",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.1.0.46/32",
    "hostIP": "172.31.197.251",
    "identity": 145489,
    "metadata": {
      "name": "clustermesh-apiserver-6f65fcb5cc-qhmjp",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.1.0.71/32",
    "hostIP": "172.31.197.251",
    "identity": 135171,
    "metadata": {
      "name": "coredns-cc6ccd49c-rdkcg",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.1.0.172/32",
    "hostIP": "172.31.197.251",
    "identity": 4
  },
  {
    "cidr": "10.1.0.180/32",
    "hostIP": "172.31.197.251",
    "identity": 135171,
    "metadata": {
      "name": "coredns-cc6ccd49c-bsslx",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.1.0.212/32",
    "hostIP": "172.31.197.251",
    "identity": 6
  },
  {
    "cidr": "10.2.0.87/32",
    "hostIP": "172.31.169.175",
    "identity": 202977,
    "metadata": {
      "name": "coredns-cc6ccd49c-4dqbw",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.2.0.139/32",
    "hostIP": "172.31.169.175",
    "identity": 4
  },
  {
    "cidr": "10.2.0.169/32",
    "hostIP": "172.31.169.175",
    "identity": 240185,
    "metadata": {
      "name": "clustermesh-apiserver-78b75cd744-wxc4j",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.2.0.188/32",
    "hostIP": "172.31.169.175",
    "identity": 202977,
    "metadata": {
      "name": "coredns-cc6ccd49c-42gpd",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.2.0.244/32",
    "hostIP": "172.31.169.175",
    "identity": 6
  },
  {
    "cidr": "10.3.0.60/32",
    "hostIP": "172.31.250.86",
    "identity": 6
  },
  {
    "cidr": "10.3.0.141/32",
    "hostIP": "172.31.250.86",
    "identity": 273182,
    "metadata": {
      "name": "clustermesh-apiserver-6f8f5797cc-nrjng",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.3.0.169/32",
    "hostIP": "172.31.250.86",
    "identity": 4
  },
  {
    "cidr": "10.3.0.224/32",
    "hostIP": "172.31.250.86",
    "identity": 319189,
    "metadata": {
      "name": "coredns-cc6ccd49c-89bs4",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.3.0.230/32",
    "hostIP": "172.31.250.86",
    "identity": 319189,
    "metadata": {
      "name": "coredns-cc6ccd49c-g79vj",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.4.0.4/32",
    "hostIP": "172.31.172.128",
    "identity": 6
  },
  {
    "cidr": "10.4.0.51/32",
    "hostIP": "172.31.172.128",
    "identity": 379782,
    "metadata": {
      "name": "coredns-cc6ccd49c-85l2r",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.4.0.158/32",
    "hostIP": "172.31.172.128",
    "identity": 337601,
    "metadata": {
      "name": "clustermesh-apiserver-b54d45b4b-z5pgz",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.4.0.207/32",
    "hostIP": "172.31.172.128",
    "identity": 4
  },
  {
    "cidr": "10.4.0.231/32",
    "hostIP": "172.31.172.128",
    "identity": 379782,
    "metadata": {
      "name": "coredns-cc6ccd49c-n4vz4",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.5.0.44/32",
    "hostIP": "172.31.239.114",
    "identity": 4
  },
  {
    "cidr": "10.5.0.90/32",
    "hostIP": "172.31.239.114",
    "identity": 399993,
    "metadata": {
      "name": "clustermesh-apiserver-6ff445c446-wb5ct",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.5.0.101/32",
    "hostIP": "172.31.239.114",
    "identity": 447746,
    "metadata": {
      "name": "coredns-cc6ccd49c-9ktbk",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.5.0.156/32",
    "hostIP": "172.31.239.114",
    "identity": 447746,
    "metadata": {
      "name": "coredns-cc6ccd49c-pmfk8",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.5.0.166/32",
    "hostIP": "172.31.239.114",
    "identity": 6
  },
  {
    "cidr": "10.6.0.9/32",
    "hostIP": "172.31.174.163",
    "identity": 6
  },
  {
    "cidr": "10.6.0.79/32",
    "hostIP": "172.31.174.163",
    "identity": 4
  },
  {
    "cidr": "10.6.0.174/32",
    "hostIP": "172.31.174.163",
    "identity": 523246,
    "metadata": {
      "name": "clustermesh-apiserver-7f79d77f7f-gkmhp",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.6.0.201/32",
    "hostIP": "172.31.174.163",
    "identity": 462596,
    "metadata": {
      "name": "coredns-cc6ccd49c-fw7f9",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.6.0.236/32",
    "hostIP": "172.31.174.163",
    "identity": 462596,
    "metadata": {
      "name": "coredns-cc6ccd49c-g456q",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.7.0.57/32",
    "hostIP": "172.31.194.36",
    "identity": 528033,
    "metadata": {
      "name": "clustermesh-apiserver-6dfbb8d56f-hztz6",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.7.0.112/32",
    "hostIP": "172.31.194.36",
    "identity": 553023,
    "metadata": {
      "name": "coredns-cc6ccd49c-c9tq6",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.7.0.135/32",
    "hostIP": "172.31.194.36",
    "identity": 4
  },
  {
    "cidr": "10.7.0.150/32",
    "hostIP": "172.31.194.36",
    "identity": 6
  },
  {
    "cidr": "10.7.0.193/32",
    "hostIP": "172.31.194.36",
    "identity": 553023,
    "metadata": {
      "name": "coredns-cc6ccd49c-2tfkx",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.8.0.129/32",
    "hostIP": "172.31.191.155",
    "identity": 6
  },
  {
    "cidr": "10.8.0.136/32",
    "hostIP": "172.31.191.155",
    "identity": 620887,
    "metadata": {
      "name": "coredns-cc6ccd49c-f96m6",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.8.0.145/32",
    "hostIP": "172.31.191.155",
    "identity": 620887,
    "metadata": {
      "name": "coredns-cc6ccd49c-65v59",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.8.0.209/32",
    "hostIP": "172.31.191.155",
    "identity": 594581,
    "metadata": {
      "name": "clustermesh-apiserver-68f6bb4cb5-6j4d8",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.8.0.247/32",
    "hostIP": "172.31.191.155",
    "identity": 4
  },
  {
    "cidr": "10.9.0.64/32",
    "hostIP": "172.31.208.120",
    "identity": 668279,
    "metadata": {
      "name": "coredns-cc6ccd49c-8fb42",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.9.0.100/32",
    "hostIP": "172.31.208.120",
    "identity": 680340,
    "metadata": {
      "name": "clustermesh-apiserver-5bb46d8484-bgjqh",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.9.0.186/32",
    "hostIP": "172.31.208.120",
    "identity": 6
  },
  {
    "cidr": "10.9.0.214/32",
    "hostIP": "172.31.208.120",
    "identity": 668279,
    "metadata": {
      "name": "coredns-cc6ccd49c-5wrnq",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.9.0.233/32",
    "hostIP": "172.31.208.120",
    "identity": 4
  },
  {
    "cidr": "10.10.0.95/32",
    "hostIP": "172.31.155.27",
    "identity": 741304,
    "metadata": {
      "name": "coredns-cc6ccd49c-p4m4t",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.10.0.102/32",
    "hostIP": "172.31.155.27",
    "identity": 6
  },
  {
    "cidr": "10.10.0.104/32",
    "hostIP": "172.31.155.27",
    "identity": 4
  },
  {
    "cidr": "10.10.0.124/32",
    "hostIP": "172.31.155.27",
    "identity": 785668,
    "metadata": {
      "name": "clustermesh-apiserver-db5ccd4fb-zqxjd",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.10.0.137/32",
    "hostIP": "172.31.155.27",
    "identity": 741304,
    "metadata": {
      "name": "coredns-cc6ccd49c-7fxhf",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.11.0.96/32",
    "hostIP": "172.31.197.79",
    "identity": 6
  },
  {
    "cidr": "10.11.0.129/32",
    "hostIP": "172.31.197.79",
    "identity": 4
  },
  {
    "cidr": "10.11.0.143/32",
    "hostIP": "172.31.197.79",
    "identity": 824053,
    "metadata": {
      "name": "coredns-cc6ccd49c-mxps6",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.11.0.146/32",
    "hostIP": "172.31.197.79",
    "identity": 824053,
    "metadata": {
      "name": "coredns-cc6ccd49c-f4cnk",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.11.0.185/32",
    "hostIP": "172.31.197.79",
    "identity": 812112,
    "metadata": {
      "name": "clustermesh-apiserver-67769f67d8-7k4xb",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.12.0.4/32",
    "hostIP": "172.31.170.139",
    "identity": 899644,
    "metadata": {
      "name": "clustermesh-apiserver-6b868d67c9-dx5s9",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.12.0.59/32",
    "hostIP": "172.31.170.139",
    "identity": 905284,
    "metadata": {
      "name": "coredns-cc6ccd49c-7khkd",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.12.0.124/32",
    "hostIP": "172.31.170.139",
    "identity": 905284,
    "metadata": {
      "name": "coredns-cc6ccd49c-pb6zr",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.12.0.142/32",
    "hostIP": "172.31.170.139",
    "identity": 4
  },
  {
    "cidr": "10.12.0.155/32",
    "hostIP": "172.31.170.139",
    "identity": 6
  },
  {
    "cidr": "10.13.0.68/32",
    "hostIP": "172.31.226.178",
    "identity": 6
  },
  {
    "cidr": "10.13.0.139/32",
    "hostIP": "172.31.226.178",
    "identity": 4
  },
  {
    "cidr": "10.13.0.156/32",
    "hostIP": "172.31.226.178",
    "identity": 973353,
    "metadata": {
      "name": "coredns-cc6ccd49c-lbvdz",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.13.0.204/32",
    "hostIP": "172.31.226.178",
    "identity": 956136,
    "metadata": {
      "name": "clustermesh-apiserver-6d5c89b589-97jrw",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.13.0.254/32",
    "hostIP": "172.31.226.178",
    "identity": 973353,
    "metadata": {
      "name": "coredns-cc6ccd49c-lvxsf",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.14.0.22/32",
    "hostIP": "172.31.147.77",
    "identity": 4
  },
  {
    "cidr": "10.14.0.45/32",
    "hostIP": "172.31.147.77",
    "identity": 1013686,
    "metadata": {
      "name": "clustermesh-apiserver-6cbc459966-bk2cs",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.14.0.138/32",
    "hostIP": "172.31.147.77",
    "identity": 1041050,
    "metadata": {
      "name": "coredns-cc6ccd49c-k6k4d",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.14.0.205/32",
    "hostIP": "172.31.147.77",
    "identity": 1041050,
    "metadata": {
      "name": "coredns-cc6ccd49c-7qnfm",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.14.0.231/32",
    "hostIP": "172.31.147.77",
    "identity": 6
  },
  {
    "cidr": "10.15.0.60/32",
    "hostIP": "172.31.234.25",
    "identity": 1078774,
    "metadata": {
      "name": "coredns-cc6ccd49c-qc4np",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.15.0.78/32",
    "hostIP": "172.31.234.25",
    "identity": 1061807,
    "metadata": {
      "name": "clustermesh-apiserver-5c7dc99697-smvgm",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.15.0.116/32",
    "hostIP": "172.31.234.25",
    "identity": 6
  },
  {
    "cidr": "10.15.0.122/32",
    "hostIP": "172.31.234.25",
    "identity": 1078774,
    "metadata": {
      "name": "coredns-cc6ccd49c-5jgkq",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.15.0.157/32",
    "hostIP": "172.31.234.25",
    "identity": 4
  },
  {
    "cidr": "10.16.0.76/32",
    "hostIP": "172.31.154.239",
    "identity": 1169229,
    "metadata": {
      "name": "clustermesh-apiserver-66d978f94d-fjbr4",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.16.0.81/32",
    "hostIP": "172.31.154.239",
    "identity": 4
  },
  {
    "cidr": "10.16.0.96/32",
    "hostIP": "172.31.154.239",
    "identity": 1150457,
    "metadata": {
      "name": "coredns-cc6ccd49c-dm4lx",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.16.0.140/32",
    "hostIP": "172.31.154.239",
    "identity": 1150457,
    "metadata": {
      "name": "coredns-cc6ccd49c-zrkbh",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.16.0.226/32",
    "hostIP": "172.31.154.239",
    "identity": 6
  },
  {
    "cidr": "10.17.0.65/32",
    "hostIP": "172.31.247.244",
    "identity": 6
  },
  {
    "cidr": "10.17.0.178/32",
    "hostIP": "172.31.247.244",
    "identity": 4
  },
  {
    "cidr": "10.17.0.179/32",
    "hostIP": "172.31.247.244",
    "identity": 1187483,
    "metadata": {
      "name": "clustermesh-apiserver-7dcfc8984-vrrpx",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.17.0.190/32",
    "hostIP": "172.31.247.244",
    "identity": 1203169,
    "metadata": {
      "name": "coredns-cc6ccd49c-mztsg",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.17.0.248/32",
    "hostIP": "172.31.247.244",
    "identity": 1203169,
    "metadata": {
      "name": "coredns-cc6ccd49c-n6wz9",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.18.0.61/32",
    "hostIP": "172.31.161.89",
    "identity": 1282951,
    "metadata": {
      "name": "coredns-cc6ccd49c-cpgvv",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.18.0.160/32",
    "hostIP": "172.31.161.89",
    "identity": 6
  },
  {
    "cidr": "10.18.0.187/32",
    "hostIP": "172.31.161.89",
    "identity": 1282951,
    "metadata": {
      "name": "coredns-cc6ccd49c-xghjx",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.18.0.205/32",
    "hostIP": "172.31.161.89",
    "identity": 1252286,
    "metadata": {
      "name": "clustermesh-apiserver-5d768676b9-4r6mj",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.18.0.213/32",
    "hostIP": "172.31.161.89",
    "identity": 4
  },
  {
    "cidr": "10.19.0.12/32",
    "hostIP": "172.31.210.89",
    "identity": 6
  },
  {
    "cidr": "10.19.0.14/32",
    "hostIP": "172.31.210.89",
    "identity": 1317395,
    "metadata": {
      "name": "clustermesh-apiserver-69cbc8f474-9zm8g",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.19.0.39/32",
    "hostIP": "172.31.210.89",
    "identity": 1321319,
    "metadata": {
      "name": "coredns-cc6ccd49c-smwz4",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.19.0.59/32",
    "hostIP": "172.31.210.89",
    "identity": 1321319,
    "metadata": {
      "name": "coredns-cc6ccd49c-xs66j",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.19.0.84/32",
    "hostIP": "172.31.210.89",
    "identity": 4
  },
  {
    "cidr": "10.20.0.10/32",
    "hostIP": "172.31.169.166",
    "identity": 4
  },
  {
    "cidr": "10.20.0.15/32",
    "hostIP": "172.31.169.166",
    "identity": 6
  },
  {
    "cidr": "10.20.0.41/32",
    "hostIP": "172.31.169.166",
    "identity": 1436627,
    "metadata": {
      "name": "coredns-cc6ccd49c-7fjv4",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.20.0.234/32",
    "hostIP": "172.31.169.166",
    "identity": 1426970,
    "metadata": {
      "name": "clustermesh-apiserver-55f8d8cb74-d5kk7",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.20.0.245/32",
    "hostIP": "172.31.169.166",
    "identity": 1436627,
    "metadata": {
      "name": "coredns-cc6ccd49c-k9sqh",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.21.0.49/32",
    "hostIP": "172.31.247.164",
    "identity": 1449296,
    "metadata": {
      "name": "coredns-cc6ccd49c-8gkmj",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.21.0.122/32",
    "hostIP": "172.31.247.164",
    "identity": 1467853,
    "metadata": {
      "name": "clustermesh-apiserver-567c89b4d6-sdpf7",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.21.0.176/32",
    "hostIP": "172.31.247.164",
    "identity": 1449296,
    "metadata": {
      "name": "coredns-cc6ccd49c-82h5c",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.21.0.180/32",
    "hostIP": "172.31.247.164",
    "identity": 4
  },
  {
    "cidr": "10.21.0.211/32",
    "hostIP": "172.31.247.164",
    "identity": 6
  },
  {
    "cidr": "10.22.0.49/32",
    "hostIP": "172.31.180.212",
    "identity": 1565320,
    "metadata": {
      "name": "coredns-cc6ccd49c-s6kvs",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.22.0.76/32",
    "hostIP": "172.31.180.212",
    "identity": 1565320,
    "metadata": {
      "name": "coredns-cc6ccd49c-s2llk",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.22.0.112/32",
    "hostIP": "172.31.180.212",
    "identity": 1521205,
    "metadata": {
      "name": "clustermesh-apiserver-77f599fc67-q2d9h",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.22.0.195/32",
    "hostIP": "172.31.180.212",
    "identity": 6
  },
  {
    "cidr": "10.22.0.208/32",
    "hostIP": "172.31.180.212",
    "identity": 4
  },
  {
    "cidr": "10.23.0.5/32",
    "hostIP": "172.31.206.64",
    "identity": 6
  },
  {
    "cidr": "10.23.0.92/32",
    "hostIP": "172.31.206.64",
    "identity": 1589556,
    "metadata": {
      "name": "coredns-cc6ccd49c-bgmf4",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.23.0.174/32",
    "hostIP": "172.31.206.64",
    "identity": 1592160,
    "metadata": {
      "name": "clustermesh-apiserver-55b457c4d-kmvdj",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.23.0.202/32",
    "hostIP": "172.31.206.64",
    "identity": 4
  },
  {
    "cidr": "10.23.0.221/32",
    "hostIP": "172.31.206.64",
    "identity": 1589556,
    "metadata": {
      "name": "coredns-cc6ccd49c-szcdc",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.24.0.25/32",
    "hostIP": "172.31.148.101",
    "identity": 1652215,
    "metadata": {
      "name": "coredns-cc6ccd49c-284xd",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.24.0.57/32",
    "hostIP": "172.31.148.101",
    "identity": 1652215,
    "metadata": {
      "name": "coredns-cc6ccd49c-q47wj",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.24.0.180/32",
    "hostIP": "172.31.148.101",
    "identity": 6
  },
  {
    "cidr": "10.24.0.204/32",
    "hostIP": "172.31.148.101",
    "identity": 1683852,
    "metadata": {
      "name": "clustermesh-apiserver-55b55c5c8d-9zzs7",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.24.0.252/32",
    "hostIP": "172.31.148.101",
    "identity": 4
  },
  {
    "cidr": "10.25.0.30/32",
    "hostIP": "172.31.217.133",
    "identity": 1705444,
    "metadata": {
      "name": "coredns-cc6ccd49c-x6rrm",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.25.0.58/32",
    "hostIP": "172.31.217.133",
    "identity": 1751173,
    "metadata": {
      "name": "clustermesh-apiserver-6787446b5f-5jvsj",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.25.0.72/32",
    "hostIP": "172.31.217.133",
    "identity": 4
  },
  {
    "cidr": "10.25.0.179/32",
    "hostIP": "172.31.217.133",
    "identity": 1705444,
    "metadata": {
      "name": "coredns-cc6ccd49c-6498q",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.25.0.193/32",
    "hostIP": "172.31.217.133",
    "identity": 6
  },
  {
    "cidr": "10.26.0.2/32",
    "hostIP": "172.31.147.228",
    "identity": 1774281,
    "metadata": {
      "name": "coredns-cc6ccd49c-5cnnv",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.26.0.29/32",
    "hostIP": "172.31.147.228",
    "identity": 1774281,
    "metadata": {
      "name": "coredns-cc6ccd49c-85ljd",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.26.0.72/32",
    "hostIP": "172.31.147.228",
    "identity": 6
  },
  {
    "cidr": "10.26.0.188/32",
    "hostIP": "172.31.147.228",
    "identity": 1804115,
    "metadata": {
      "name": "clustermesh-apiserver-599b667977-wzcx9",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.26.0.233/32",
    "hostIP": "172.31.147.228",
    "identity": 4
  },
  {
    "cidr": "10.27.0.6/32",
    "hostIP": "172.31.253.235",
    "identity": 1870740,
    "metadata": {
      "name": "coredns-cc6ccd49c-gpc6c",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.27.0.43/32",
    "hostIP": "172.31.253.235",
    "identity": 1856085,
    "metadata": {
      "name": "clustermesh-apiserver-888bd477d-67g8w",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.27.0.75/32",
    "hostIP": "172.31.253.235",
    "identity": 1870740,
    "metadata": {
      "name": "coredns-cc6ccd49c-9c784",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.27.0.220/32",
    "hostIP": "172.31.253.235",
    "identity": 4
  },
  {
    "cidr": "10.27.0.236/32",
    "hostIP": "172.31.253.235",
    "identity": 6
  },
  {
    "cidr": "10.28.0.189/32",
    "hostIP": "172.31.144.216",
    "identity": 1908893,
    "metadata": {
      "name": "coredns-cc6ccd49c-q4rpq",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.28.0.191/32",
    "hostIP": "172.31.144.216",
    "identity": 4
  },
  {
    "cidr": "10.28.0.197/32",
    "hostIP": "172.31.144.216",
    "identity": 1908893,
    "metadata": {
      "name": "coredns-cc6ccd49c-pv9ch",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.28.0.214/32",
    "hostIP": "172.31.144.216",
    "identity": 6
  },
  {
    "cidr": "10.28.0.252/32",
    "hostIP": "172.31.144.216",
    "identity": 1957897,
    "metadata": {
      "name": "clustermesh-apiserver-74469cd8d9-dslk9",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.29.0.44/32",
    "hostIP": "172.31.243.59",
    "identity": 1978426,
    "metadata": {
      "name": "clustermesh-apiserver-857f579f48-99dsz",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.29.0.151/32",
    "hostIP": "172.31.243.59",
    "identity": 6
  },
  {
    "cidr": "10.29.0.226/32",
    "hostIP": "172.31.243.59",
    "identity": 1970653,
    "metadata": {
      "name": "coredns-cc6ccd49c-57fs8",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.29.0.241/32",
    "hostIP": "172.31.243.59",
    "identity": 4
  },
  {
    "cidr": "10.29.0.245/32",
    "hostIP": "172.31.243.59",
    "identity": 1970653,
    "metadata": {
      "name": "coredns-cc6ccd49c-jssgv",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.30.0.33/32",
    "hostIP": "172.31.161.158",
    "identity": 2087625,
    "metadata": {
      "name": "clustermesh-apiserver-86fc96ddb-jzlcn",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.30.0.87/32",
    "hostIP": "172.31.161.158",
    "identity": 4
  },
  {
    "cidr": "10.30.0.141/32",
    "hostIP": "172.31.161.158",
    "identity": 2037924,
    "metadata": {
      "name": "coredns-cc6ccd49c-szfl4",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.30.0.148/32",
    "hostIP": "172.31.161.158",
    "identity": 2037924,
    "metadata": {
      "name": "coredns-cc6ccd49c-c5vms",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.30.0.203/32",
    "hostIP": "172.31.161.158",
    "identity": 6
  },
  {
    "cidr": "10.31.0.66/32",
    "hostIP": "172.31.247.172",
    "identity": 4
  },
  {
    "cidr": "10.31.0.168/32",
    "hostIP": "172.31.247.172",
    "identity": 2106292,
    "metadata": {
      "name": "clustermesh-apiserver-6d59957dcd-75vsf",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.31.0.171/32",
    "hostIP": "172.31.247.172",
    "identity": 2106273,
    "metadata": {
      "name": "coredns-cc6ccd49c-2x4s9",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.31.0.199/32",
    "hostIP": "172.31.247.172",
    "identity": 6
  },
  {
    "cidr": "10.31.0.241/32",
    "hostIP": "172.31.247.172",
    "identity": 2106273,
    "metadata": {
      "name": "coredns-cc6ccd49c-hzjjb",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.32.0.29/32",
    "hostIP": "172.31.186.90",
    "identity": 4
  },
  {
    "cidr": "10.32.0.46/32",
    "hostIP": "172.31.186.90",
    "identity": 2174873,
    "metadata": {
      "name": "clustermesh-apiserver-6f49498686-t88mv",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.32.0.51/32",
    "hostIP": "172.31.186.90",
    "identity": 2186963,
    "metadata": {
      "name": "coredns-cc6ccd49c-22f9p",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.32.0.96/32",
    "hostIP": "172.31.186.90",
    "identity": 2186963,
    "metadata": {
      "name": "coredns-cc6ccd49c-ggctg",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.32.0.142/32",
    "hostIP": "172.31.186.90",
    "identity": 6
  },
  {
    "cidr": "10.33.0.3/32",
    "hostIP": "172.31.229.207",
    "identity": 6
  },
  {
    "cidr": "10.33.0.4/32",
    "hostIP": "172.31.229.207",
    "identity": 2254015,
    "metadata": {
      "name": "coredns-cc6ccd49c-rpvwp",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.33.0.47/32",
    "hostIP": "172.31.229.207",
    "identity": 2276158,
    "metadata": {
      "name": "clustermesh-apiserver-6b6c6fb48c-khg5b",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.33.0.206/32",
    "hostIP": "172.31.229.207",
    "identity": 4
  },
  {
    "cidr": "10.33.0.244/32",
    "hostIP": "172.31.229.207",
    "identity": 2254015,
    "metadata": {
      "name": "coredns-cc6ccd49c-bcxsk",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.34.0.2/32",
    "hostIP": "172.31.189.5",
    "identity": 6
  },
  {
    "cidr": "10.34.0.188/32",
    "hostIP": "172.31.189.5",
    "identity": 2302320,
    "metadata": {
      "name": "clustermesh-apiserver-6ff6d88f79-k67cz",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.34.0.202/32",
    "hostIP": "172.31.189.5",
    "identity": 4
  },
  {
    "cidr": "10.34.0.217/32",
    "hostIP": "172.31.189.5",
    "identity": 2345099,
    "metadata": {
      "name": "coredns-cc6ccd49c-p2njr",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.34.0.226/32",
    "hostIP": "172.31.189.5",
    "identity": 2345099,
    "metadata": {
      "name": "coredns-cc6ccd49c-76wvd",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.35.0.71/32",
    "hostIP": "172.31.193.211",
    "identity": 2398546,
    "metadata": {
      "name": "coredns-cc6ccd49c-wtwz9",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.35.0.90/32",
    "hostIP": "172.31.193.211",
    "identity": 4
  },
  {
    "cidr": "10.35.0.91/32",
    "hostIP": "172.31.193.211",
    "identity": 2375851,
    "metadata": {
      "name": "clustermesh-apiserver-588c8d87bd-wkvj2",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.35.0.165/32",
    "hostIP": "172.31.193.211",
    "identity": 2398546,
    "metadata": {
      "name": "coredns-cc6ccd49c-c7ksf",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.35.0.180/32",
    "hostIP": "172.31.193.211",
    "identity": 6
  },
  {
    "cidr": "10.36.0.35/32",
    "hostIP": "172.31.142.96",
    "identity": 6
  },
  {
    "cidr": "10.36.0.114/32",
    "hostIP": "172.31.142.96",
    "identity": 2448634,
    "metadata": {
      "name": "coredns-cc6ccd49c-lj52n",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.36.0.138/32",
    "hostIP": "172.31.142.96",
    "identity": 2473754,
    "metadata": {
      "name": "clustermesh-apiserver-65d76cbf76-jns9h",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.36.0.153/32",
    "hostIP": "172.31.142.96",
    "identity": 2448634,
    "metadata": {
      "name": "coredns-cc6ccd49c-gdxzd",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.36.0.163/32",
    "hostIP": "172.31.142.96",
    "identity": 4
  },
  {
    "cidr": "10.37.0.31/32",
    "hostIP": "172.31.235.234",
    "identity": 2537688,
    "metadata": {
      "name": "clustermesh-apiserver-7b7fb9b4b4-6fqsq",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.37.0.121/32",
    "hostIP": "172.31.235.234",
    "identity": 2492322,
    "metadata": {
      "name": "coredns-cc6ccd49c-bprc6",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.37.0.134/32",
    "hostIP": "172.31.235.234",
    "identity": 4
  },
  {
    "cidr": "10.37.0.216/32",
    "hostIP": "172.31.235.234",
    "identity": 2492322,
    "metadata": {
      "name": "coredns-cc6ccd49c-gh552",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.37.0.251/32",
    "hostIP": "172.31.235.234",
    "identity": 6
  },
  {
    "cidr": "10.38.0.100/32",
    "hostIP": "172.31.172.183",
    "identity": 2567020,
    "metadata": {
      "name": "coredns-cc6ccd49c-r5trn",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.38.0.142/32",
    "hostIP": "172.31.172.183",
    "identity": 2616627,
    "metadata": {
      "name": "clustermesh-apiserver-6b8445b784-q9cbn",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.38.0.205/32",
    "hostIP": "172.31.172.183",
    "identity": 6
  },
  {
    "cidr": "10.38.0.236/32",
    "hostIP": "172.31.172.183",
    "identity": 4
  },
  {
    "cidr": "10.38.0.245/32",
    "hostIP": "172.31.172.183",
    "identity": 2567020,
    "metadata": {
      "name": "coredns-cc6ccd49c-p82x8",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.39.0.23/32",
    "hostIP": "172.31.246.192",
    "identity": 6
  },
  {
    "cidr": "10.39.0.151/32",
    "hostIP": "172.31.246.192",
    "identity": 2681750,
    "metadata": {
      "name": "coredns-cc6ccd49c-j2vbm",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.39.0.175/32",
    "hostIP": "172.31.246.192",
    "identity": 2681750,
    "metadata": {
      "name": "coredns-cc6ccd49c-6rrvh",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.39.0.180/32",
    "hostIP": "172.31.246.192",
    "identity": 4
  },
  {
    "cidr": "10.39.0.246/32",
    "hostIP": "172.31.246.192",
    "identity": 2668485,
    "metadata": {
      "name": "clustermesh-apiserver-947b46b-6bnkd",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.40.0.37/32",
    "hostIP": "172.31.175.121",
    "identity": 4
  },
  {
    "cidr": "10.40.0.62/32",
    "hostIP": "172.31.175.121",
    "identity": 2718645,
    "metadata": {
      "name": "coredns-cc6ccd49c-2wp86",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.40.0.67/32",
    "hostIP": "172.31.175.121",
    "identity": 2718645,
    "metadata": {
      "name": "coredns-cc6ccd49c-cnjg8",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.40.0.144/32",
    "hostIP": "172.31.175.121",
    "identity": 6
  },
  {
    "cidr": "10.40.0.179/32",
    "hostIP": "172.31.175.121",
    "identity": 2718529,
    "metadata": {
      "name": "clustermesh-apiserver-76cb65fbbd-7m6gw",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.41.0.30/32",
    "hostIP": "172.31.249.77",
    "identity": 2816506,
    "metadata": {
      "name": "clustermesh-apiserver-d9b79b9c-7rdw7",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.41.0.67/32",
    "hostIP": "172.31.249.77",
    "identity": 4
  },
  {
    "cidr": "10.41.0.69/32",
    "hostIP": "172.31.249.77",
    "identity": 6
  },
  {
    "cidr": "10.41.0.113/32",
    "hostIP": "172.31.249.77",
    "identity": 2754028,
    "metadata": {
      "name": "coredns-cc6ccd49c-nz7jf",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.41.0.225/32",
    "hostIP": "172.31.249.77",
    "identity": 2754028,
    "metadata": {
      "name": "coredns-cc6ccd49c-sdtfj",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.42.0.29/32",
    "hostIP": "172.31.149.98",
    "identity": 2857503,
    "metadata": {
      "name": "coredns-cc6ccd49c-bx695",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.42.0.95/32",
    "hostIP": "172.31.149.98",
    "identity": 6
  },
  {
    "cidr": "10.42.0.169/32",
    "hostIP": "172.31.149.98",
    "identity": 2865109,
    "metadata": {
      "name": "clustermesh-apiserver-54f8c6679b-27cq9",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.42.0.183/32",
    "hostIP": "172.31.149.98",
    "identity": 2857503,
    "metadata": {
      "name": "coredns-cc6ccd49c-svx22",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.42.0.249/32",
    "hostIP": "172.31.149.98",
    "identity": 4
  },
  {
    "cidr": "10.43.0.94/32",
    "hostIP": "172.31.251.101",
    "identity": 2928214,
    "metadata": {
      "name": "clustermesh-apiserver-6459bfdd66-j5tqg",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.43.0.137/32",
    "hostIP": "172.31.251.101",
    "identity": 4
  },
  {
    "cidr": "10.43.0.168/32",
    "hostIP": "172.31.251.101",
    "identity": 2916653,
    "metadata": {
      "name": "coredns-cc6ccd49c-5pnbm",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.43.0.247/32",
    "hostIP": "172.31.251.101",
    "identity": 2916653,
    "metadata": {
      "name": "coredns-cc6ccd49c-x5jsh",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.43.0.254/32",
    "hostIP": "172.31.251.101",
    "identity": 6
  },
  {
    "cidr": "10.44.0.18/32",
    "hostIP": "172.31.140.221",
    "identity": 2962584,
    "metadata": {
      "name": "coredns-cc6ccd49c-z9txs",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.44.0.59/32",
    "hostIP": "172.31.140.221",
    "identity": 4
  },
  {
    "cidr": "10.44.0.60/32",
    "hostIP": "172.31.140.221",
    "identity": 6
  },
  {
    "cidr": "10.44.0.77/32",
    "hostIP": "172.31.140.221",
    "identity": 3002561,
    "metadata": {
      "name": "clustermesh-apiserver-7bb9d9dcbc-7b6fn",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.44.0.154/32",
    "hostIP": "172.31.140.221",
    "identity": 2962584,
    "metadata": {
      "name": "coredns-cc6ccd49c-rbdtz",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.45.0.73/32",
    "hostIP": "172.31.210.97",
    "identity": 3023022,
    "metadata": {
      "name": "coredns-cc6ccd49c-b72qz",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.45.0.75/32",
    "hostIP": "172.31.210.97",
    "identity": 3068569,
    "metadata": {
      "name": "clustermesh-apiserver-85bb6bcd77-g9hv6",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.45.0.89/32",
    "hostIP": "172.31.210.97",
    "identity": 6
  },
  {
    "cidr": "10.45.0.93/32",
    "hostIP": "172.31.210.97",
    "identity": 3023022,
    "metadata": {
      "name": "coredns-cc6ccd49c-gzzxt",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.45.0.161/32",
    "hostIP": "172.31.210.97",
    "identity": 4
  },
  {
    "cidr": "10.46.0.37/32",
    "hostIP": "172.31.190.180",
    "identity": 3083710,
    "metadata": {
      "name": "clustermesh-apiserver-56b8f55d54-kl5zp",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.46.0.78/32",
    "hostIP": "172.31.190.180",
    "identity": 3082991,
    "metadata": {
      "name": "coredns-cc6ccd49c-2dgkz",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.46.0.114/32",
    "hostIP": "172.31.190.180",
    "identity": 3082991,
    "metadata": {
      "name": "coredns-cc6ccd49c-4h98l",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.46.0.170/32",
    "hostIP": "172.31.190.180",
    "identity": 6
  },
  {
    "cidr": "10.46.0.246/32",
    "hostIP": "172.31.190.180",
    "identity": 4
  },
  {
    "cidr": "10.47.0.19/32",
    "hostIP": "172.31.206.43",
    "identity": 3178929,
    "metadata": {
      "name": "clustermesh-apiserver-85b7cb6cdf-g6ch7",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.47.0.74/32",
    "hostIP": "172.31.206.43",
    "identity": 6
  },
  {
    "cidr": "10.47.0.133/32",
    "hostIP": "172.31.206.43",
    "identity": 3187487,
    "metadata": {
      "name": "coredns-cc6ccd49c-dnk27",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.47.0.158/32",
    "hostIP": "172.31.206.43",
    "identity": 4
  },
  {
    "cidr": "10.47.0.236/32",
    "hostIP": "172.31.206.43",
    "identity": 3187487,
    "metadata": {
      "name": "coredns-cc6ccd49c-ld8gz",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.48.0.31/32",
    "hostIP": "172.31.149.115",
    "identity": 4
  },
  {
    "cidr": "10.48.0.47/32",
    "hostIP": "172.31.149.115",
    "identity": 6
  },
  {
    "cidr": "10.48.0.115/32",
    "hostIP": "172.31.149.115",
    "identity": 3263470,
    "metadata": {
      "name": "clustermesh-apiserver-777566c59b-8zf6x",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.48.0.164/32",
    "hostIP": "172.31.149.115",
    "identity": 3216961,
    "metadata": {
      "name": "coredns-cc6ccd49c-pk99f",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.48.0.220/32",
    "hostIP": "172.31.149.115",
    "identity": 3216961,
    "metadata": {
      "name": "coredns-cc6ccd49c-hntvl",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.49.0.28/32",
    "hostIP": "172.31.231.255",
    "identity": 4
  },
  {
    "cidr": "10.49.0.34/32",
    "hostIP": "172.31.231.255",
    "identity": 3285871,
    "metadata": {
      "name": "clustermesh-apiserver-69949878cc-f7w7v",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.49.0.51/32",
    "hostIP": "172.31.231.255",
    "identity": 3281168,
    "metadata": {
      "name": "coredns-cc6ccd49c-f4s4k",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.49.0.73/32",
    "hostIP": "172.31.231.255",
    "identity": 3281168,
    "metadata": {
      "name": "coredns-cc6ccd49c-sfk5f",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.49.0.108/32",
    "hostIP": "172.31.231.255",
    "identity": 6
  },
  {
    "cidr": "10.50.0.31/32",
    "hostIP": "172.31.144.60",
    "identity": 6
  },
  {
    "cidr": "10.50.0.78/32",
    "hostIP": "172.31.144.60",
    "identity": 3346695,
    "metadata": {
      "name": "coredns-cc6ccd49c-mp9cd",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.50.0.95/32",
    "hostIP": "172.31.144.60",
    "identity": 3368997,
    "metadata": {
      "name": "clustermesh-apiserver-784f4468dc-ljjgm",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.50.0.183/32",
    "hostIP": "172.31.144.60",
    "identity": 3346695,
    "metadata": {
      "name": "coredns-cc6ccd49c-d4mtw",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.50.0.227/32",
    "hostIP": "172.31.144.60",
    "identity": 4
  },
  {
    "cidr": "10.51.0.19/32",
    "hostIP": "172.31.245.66",
    "identity": 3440100,
    "metadata": {
      "name": "clustermesh-apiserver-7769dd85f8-ln6cv",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.51.0.132/32",
    "hostIP": "172.31.245.66",
    "identity": 3459824,
    "metadata": {
      "name": "coredns-cc6ccd49c-djs4m",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.51.0.169/32",
    "hostIP": "172.31.245.66",
    "identity": 3459824,
    "metadata": {
      "name": "coredns-cc6ccd49c-57kww",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.51.0.173/32",
    "hostIP": "172.31.245.66",
    "identity": 4
  },
  {
    "cidr": "10.51.0.216/32",
    "hostIP": "172.31.245.66",
    "identity": 6
  },
  {
    "cidr": "10.52.0.13/32",
    "hostIP": "172.31.143.87",
    "identity": 3538278,
    "metadata": {
      "name": "coredns-cc6ccd49c-8lp5m",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.52.0.125/32",
    "hostIP": "172.31.143.87",
    "identity": 3489880,
    "metadata": {
      "name": "clustermesh-apiserver-7c7d7cb89f-4rjjm",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.52.0.130/32",
    "hostIP": "172.31.143.87",
    "identity": 3538278,
    "metadata": {
      "name": "coredns-cc6ccd49c-9ptpr",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.52.0.154/32",
    "hostIP": "172.31.143.87",
    "identity": 6
  },
  {
    "cidr": "10.52.0.161/32",
    "hostIP": "172.31.143.87",
    "identity": 4
  },
  {
    "cidr": "10.53.0.68/32",
    "hostIP": "172.31.222.147",
    "identity": 4
  },
  {
    "cidr": "10.53.0.89/32",
    "hostIP": "172.31.222.147",
    "identity": 3582731,
    "metadata": {
      "name": "coredns-cc6ccd49c-pn6vt",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.53.0.181/32",
    "hostIP": "172.31.222.147",
    "identity": 6
  },
  {
    "cidr": "10.53.0.195/32",
    "hostIP": "172.31.222.147",
    "identity": 3604221,
    "metadata": {
      "name": "clustermesh-apiserver-65c8447649-m6xtr",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.53.0.242/32",
    "hostIP": "172.31.222.147",
    "identity": 3582731,
    "metadata": {
      "name": "coredns-cc6ccd49c-m7f65",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.54.0.53/32",
    "hostIP": "172.31.145.45",
    "identity": 3611620,
    "metadata": {
      "name": "coredns-cc6ccd49c-jbhtj",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.54.0.57/32",
    "hostIP": "172.31.145.45",
    "identity": 3611620,
    "metadata": {
      "name": "coredns-cc6ccd49c-zckmt",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.54.0.92/32",
    "hostIP": "172.31.145.45",
    "identity": 4
  },
  {
    "cidr": "10.54.0.151/32",
    "hostIP": "172.31.145.45",
    "identity": 3609450,
    "metadata": {
      "name": "clustermesh-apiserver-6466cff77-lss49",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.54.0.211/32",
    "hostIP": "172.31.145.45",
    "identity": 6
  },
  {
    "cidr": "10.55.0.27/32",
    "hostIP": "172.31.246.231",
    "identity": 3698386,
    "metadata": {
      "name": "coredns-cc6ccd49c-frwh6",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.55.0.48/32",
    "hostIP": "172.31.246.231",
    "identity": 3702661,
    "metadata": {
      "name": "clustermesh-apiserver-568b9994d7-dc46s",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.55.0.64/32",
    "hostIP": "172.31.246.231",
    "identity": 4
  },
  {
    "cidr": "10.55.0.160/32",
    "hostIP": "172.31.246.231",
    "identity": 3698386,
    "metadata": {
      "name": "coredns-cc6ccd49c-jn58w",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.55.0.200/32",
    "hostIP": "172.31.246.231",
    "identity": 6
  },
  {
    "cidr": "10.56.0.41/32",
    "hostIP": "172.31.158.50",
    "identity": 3739806,
    "metadata": {
      "name": "coredns-cc6ccd49c-sxhn9",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.56.0.43/32",
    "hostIP": "172.31.158.50",
    "identity": 6
  },
  {
    "cidr": "10.56.0.160/32",
    "hostIP": "172.31.158.50",
    "identity": 3739806,
    "metadata": {
      "name": "coredns-cc6ccd49c-bwnpz",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.56.0.186/32",
    "hostIP": "172.31.158.50",
    "identity": 4
  },
  {
    "cidr": "10.56.0.249/32",
    "hostIP": "172.31.158.50",
    "identity": 3777465,
    "metadata": {
      "name": "clustermesh-apiserver-66b5d758c7-8d5rx",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.57.0.30/32",
    "hostIP": "172.31.231.209",
    "identity": 4
  },
  {
    "cidr": "10.57.0.76/32",
    "hostIP": "172.31.231.209",
    "identity": 6
  },
  {
    "cidr": "10.57.0.217/32",
    "hostIP": "172.31.231.209",
    "identity": 3820400,
    "metadata": {
      "name": "coredns-cc6ccd49c-jrgft",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.57.0.227/32",
    "hostIP": "172.31.231.209",
    "identity": 3820400,
    "metadata": {
      "name": "coredns-cc6ccd49c-g2922",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.57.0.232/32",
    "hostIP": "172.31.231.209",
    "identity": 3836637,
    "metadata": {
      "name": "clustermesh-apiserver-5b5dbbfb8-2bz5d",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.58.0.38/32",
    "hostIP": "172.31.172.29",
    "identity": 6
  },
  {
    "cidr": "10.58.0.84/32",
    "hostIP": "172.31.172.29",
    "identity": 3921194,
    "metadata": {
      "name": "coredns-cc6ccd49c-7wglv",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.58.0.129/32",
    "hostIP": "172.31.172.29",
    "identity": 3921194,
    "metadata": {
      "name": "coredns-cc6ccd49c-n27t9",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.58.0.134/32",
    "hostIP": "172.31.172.29",
    "identity": 3906585,
    "metadata": {
      "name": "clustermesh-apiserver-7d9f745589-mr5g8",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.58.0.234/32",
    "hostIP": "172.31.172.29",
    "identity": 4
  },
  {
    "cidr": "10.59.0.13/32",
    "hostIP": "172.31.249.105",
    "identity": 3937054,
    "metadata": {
      "name": "coredns-cc6ccd49c-wr6v4",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.59.0.86/32",
    "hostIP": "172.31.249.105",
    "identity": 6
  },
  {
    "cidr": "10.59.0.133/32",
    "hostIP": "172.31.249.105",
    "identity": 4
  },
  {
    "cidr": "10.59.0.166/32",
    "hostIP": "172.31.249.105",
    "identity": 3937054,
    "metadata": {
      "name": "coredns-cc6ccd49c-9vlk2",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.59.0.181/32",
    "hostIP": "172.31.249.105",
    "identity": 3938435,
    "metadata": {
      "name": "clustermesh-apiserver-dc4744d8f-gxsxj",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.60.0.19/32",
    "hostIP": "172.31.184.13",
    "identity": 4034097,
    "metadata": {
      "name": "coredns-cc6ccd49c-w7nlp",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.60.0.24/32",
    "hostIP": "172.31.184.13",
    "identity": 6
  },
  {
    "cidr": "10.60.0.93/32",
    "hostIP": "172.31.184.13",
    "identity": 4
  },
  {
    "cidr": "10.60.0.236/32",
    "hostIP": "172.31.184.13",
    "identity": 4034097,
    "metadata": {
      "name": "coredns-cc6ccd49c-lz5hq",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.60.0.244/32",
    "hostIP": "172.31.184.13",
    "identity": 4003608,
    "metadata": {
      "name": "clustermesh-apiserver-77c47f9d8b-zv4dx",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.61.0.18/32",
    "hostIP": "172.31.242.183",
    "identity": 4066606,
    "metadata": {
      "name": "coredns-cc6ccd49c-h28xg",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.61.0.25/32",
    "hostIP": "172.31.242.183",
    "identity": 6
  },
  {
    "cidr": "10.61.0.34/32",
    "hostIP": "172.31.242.183",
    "identity": 4066606,
    "metadata": {
      "name": "coredns-cc6ccd49c-qn8jg",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.61.0.97/32",
    "hostIP": "172.31.242.183",
    "identity": 4086854,
    "metadata": {
      "name": "clustermesh-apiserver-59ddb7ff56-7h6vw",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.61.0.165/32",
    "hostIP": "172.31.242.183",
    "identity": 4
  },
  {
    "cidr": "10.62.0.19/32",
    "hostIP": "172.31.134.163",
    "identity": 6
  },
  {
    "cidr": "10.62.0.73/32",
    "hostIP": "172.31.134.163",
    "identity": 4
  },
  {
    "cidr": "10.62.0.113/32",
    "hostIP": "172.31.134.163",
    "identity": 4179164,
    "metadata": {
      "name": "coredns-cc6ccd49c-2f9m5",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.62.0.148/32",
    "hostIP": "172.31.134.163",
    "identity": 4179164,
    "metadata": {
      "name": "coredns-cc6ccd49c-kw982",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.62.0.241/32",
    "hostIP": "172.31.134.163",
    "identity": 4147480,
    "metadata": {
      "name": "clustermesh-apiserver-6cd5d55dd9-h7rz8",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.63.0.34/32",
    "hostIP": "172.31.240.216",
    "identity": 4207172,
    "metadata": {
      "name": "coredns-cc6ccd49c-9xm8p",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.63.0.75/32",
    "hostIP": "172.31.240.216",
    "identity": 4216907,
    "metadata": {
      "name": "clustermesh-apiserver-9b89f5589-td8k7",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.63.0.92/32",
    "hostIP": "172.31.240.216",
    "identity": 4
  },
  {
    "cidr": "10.63.0.115/32",
    "hostIP": "172.31.240.216",
    "identity": 6
  },
  {
    "cidr": "10.63.0.119/32",
    "hostIP": "172.31.240.216",
    "identity": 4207172,
    "metadata": {
      "name": "coredns-cc6ccd49c-h5fpx",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.64.0.104/32",
    "hostIP": "172.31.129.220",
    "identity": 4316056,
    "metadata": {
      "name": "coredns-cc6ccd49c-nb4sh",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.64.0.112/32",
    "hostIP": "172.31.129.220",
    "identity": 6
  },
  {
    "cidr": "10.64.0.169/32",
    "hostIP": "172.31.129.220",
    "identity": 4
  },
  {
    "cidr": "10.64.0.213/32",
    "hostIP": "172.31.129.220",
    "identity": 4260343,
    "metadata": {
      "name": "clustermesh-apiserver-85d7845c5c-nvc8s",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.64.0.234/32",
    "hostIP": "172.31.129.220",
    "identity": 4316056,
    "metadata": {
      "name": "coredns-cc6ccd49c-md6d6",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.65.0.128/32",
    "hostIP": "172.31.232.182",
    "identity": 4
  },
  {
    "cidr": "10.65.0.135/32",
    "hostIP": "172.31.232.182",
    "identity": 1
  },
  {
    "cidr": "10.65.0.160/32",
    "hostIP": "172.31.232.182",
    "identity": 4381653,
    "metadata": {
      "name": "clustermesh-apiserver-6b69cb88b8-7pcwc",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.65.0.172/32",
    "hostIP": "172.31.232.182",
    "identity": 4342590,
    "metadata": {
      "name": "coredns-cc6ccd49c-h5zcm",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.65.0.215/32",
    "hostIP": "172.31.232.182",
    "identity": 4342590,
    "metadata": {
      "name": "coredns-cc6ccd49c-kslc2",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.66.0.31/32",
    "hostIP": "172.31.170.17",
    "identity": 4
  },
  {
    "cidr": "10.66.0.101/32",
    "hostIP": "172.31.170.17",
    "identity": 6
  },
  {
    "cidr": "10.66.0.166/32",
    "hostIP": "172.31.170.17",
    "identity": 4392568,
    "metadata": {
      "name": "coredns-cc6ccd49c-jvprx",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.66.0.209/32",
    "hostIP": "172.31.170.17",
    "identity": 4392568,
    "metadata": {
      "name": "coredns-cc6ccd49c-fmq5k",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.66.0.242/32",
    "hostIP": "172.31.170.17",
    "identity": 4424847,
    "metadata": {
      "name": "clustermesh-apiserver-987b657b9-b5s92",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.67.0.5/32",
    "hostIP": "172.31.217.208",
    "identity": 4
  },
  {
    "cidr": "10.67.0.107/32",
    "hostIP": "172.31.217.208",
    "identity": 4514958,
    "metadata": {
      "name": "coredns-cc6ccd49c-c26s9",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.67.0.129/32",
    "hostIP": "172.31.217.208",
    "identity": 4514958,
    "metadata": {
      "name": "coredns-cc6ccd49c-q8cgb",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.67.0.141/32",
    "hostIP": "172.31.217.208",
    "identity": 4474565,
    "metadata": {
      "name": "clustermesh-apiserver-546c656c9b-k46jt",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.67.0.236/32",
    "hostIP": "172.31.217.208",
    "identity": 6
  },
  {
    "cidr": "10.68.0.2/32",
    "hostIP": "172.31.137.105",
    "identity": 4586135,
    "metadata": {
      "name": "coredns-cc6ccd49c-bp5d7",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.68.0.19/32",
    "hostIP": "172.31.137.105",
    "identity": 6
  },
  {
    "cidr": "10.68.0.32/32",
    "hostIP": "172.31.137.105",
    "identity": 4557083,
    "metadata": {
      "name": "clustermesh-apiserver-77cb5b8554-9gr6v",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.68.0.116/32",
    "hostIP": "172.31.137.105",
    "identity": 4586135,
    "metadata": {
      "name": "coredns-cc6ccd49c-n6dnq",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.68.0.164/32",
    "hostIP": "172.31.137.105",
    "identity": 4
  },
  {
    "cidr": "10.69.0.61/32",
    "hostIP": "172.31.197.74",
    "identity": 6
  },
  {
    "cidr": "10.69.0.73/32",
    "hostIP": "172.31.197.74",
    "identity": 4632448,
    "metadata": {
      "name": "coredns-cc6ccd49c-xwpg2",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.69.0.94/32",
    "hostIP": "172.31.197.74",
    "identity": 4632448,
    "metadata": {
      "name": "coredns-cc6ccd49c-kmwsv",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.69.0.132/32",
    "hostIP": "172.31.197.74",
    "identity": 4594071,
    "metadata": {
      "name": "clustermesh-apiserver-8c746c559-nc64s",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.69.0.170/32",
    "hostIP": "172.31.197.74",
    "identity": 4
  },
  {
    "cidr": "10.70.0.13/32",
    "hostIP": "172.31.176.0",
    "identity": 4706226,
    "metadata": {
      "name": "clustermesh-apiserver-856d9f5566-n65mt",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.70.0.18/32",
    "hostIP": "172.31.176.0",
    "identity": 4
  },
  {
    "cidr": "10.70.0.37/32",
    "hostIP": "172.31.176.0",
    "identity": 6
  },
  {
    "cidr": "10.70.0.77/32",
    "hostIP": "172.31.176.0",
    "identity": 4715518,
    "metadata": {
      "name": "coredns-cc6ccd49c-hvzqr",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.70.0.190/32",
    "hostIP": "172.31.176.0",
    "identity": 4715518,
    "metadata": {
      "name": "coredns-cc6ccd49c-kb9rx",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.71.0.52/32",
    "hostIP": "172.31.244.208",
    "identity": 4750488,
    "metadata": {
      "name": "coredns-cc6ccd49c-wftlb",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.71.0.176/32",
    "hostIP": "172.31.244.208",
    "identity": 4750488,
    "metadata": {
      "name": "coredns-cc6ccd49c-sq98x",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.71.0.183/32",
    "hostIP": "172.31.244.208",
    "identity": 4
  },
  {
    "cidr": "10.71.0.197/32",
    "hostIP": "172.31.244.208",
    "identity": 4719313,
    "metadata": {
      "name": "clustermesh-apiserver-5c656676f9-hbck6",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.71.0.214/32",
    "hostIP": "172.31.244.208",
    "identity": 6
  },
  {
    "cidr": "10.72.0.41/32",
    "hostIP": "172.31.168.162",
    "identity": 4787738,
    "metadata": {
      "name": "coredns-cc6ccd49c-fq95m",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.72.0.68/32",
    "hostIP": "172.31.168.162",
    "identity": 4787738,
    "metadata": {
      "name": "coredns-cc6ccd49c-fqllj",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.72.0.89/32",
    "hostIP": "172.31.168.162",
    "identity": 4787008,
    "metadata": {
      "name": "clustermesh-apiserver-55c4875fbb-c44p2",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.72.0.140/32",
    "hostIP": "172.31.168.162",
    "identity": 6
  },
  {
    "cidr": "10.72.0.184/32",
    "hostIP": "172.31.168.162",
    "identity": 4
  },
  {
    "cidr": "10.73.0.43/32",
    "hostIP": "172.31.213.46",
    "identity": 6
  },
  {
    "cidr": "10.73.0.59/32",
    "hostIP": "172.31.213.46",
    "identity": 4888610,
    "metadata": {
      "name": "coredns-cc6ccd49c-8vfwr",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.73.0.60/32",
    "hostIP": "172.31.213.46",
    "identity": 4903555,
    "metadata": {
      "name": "clustermesh-apiserver-d8c4fdbdc-fgrjg",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.73.0.193/32",
    "hostIP": "172.31.213.46",
    "identity": 4
  },
  {
    "cidr": "10.73.0.203/32",
    "hostIP": "172.31.213.46",
    "identity": 4888610,
    "metadata": {
      "name": "coredns-cc6ccd49c-6q2zn",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.74.0.28/32",
    "hostIP": "172.31.135.32",
    "identity": 4925712,
    "metadata": {
      "name": "clustermesh-apiserver-6cdfbf8df6-q6dv2",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.74.0.84/32",
    "hostIP": "172.31.135.32",
    "identity": 4918468,
    "metadata": {
      "name": "coredns-cc6ccd49c-qnxq9",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.74.0.98/32",
    "hostIP": "172.31.135.32",
    "identity": 6
  },
  {
    "cidr": "10.74.0.148/32",
    "hostIP": "172.31.135.32",
    "identity": 4
  },
  {
    "cidr": "10.74.0.163/32",
    "hostIP": "172.31.135.32",
    "identity": 4918468,
    "metadata": {
      "name": "coredns-cc6ccd49c-lz786",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.75.0.18/32",
    "hostIP": "172.31.198.153",
    "identity": 4
  },
  {
    "cidr": "10.75.0.46/32",
    "hostIP": "172.31.198.153",
    "identity": 5031388,
    "metadata": {
      "name": "clustermesh-apiserver-7644bfb4b-5rhhr",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.75.0.67/32",
    "hostIP": "172.31.198.153",
    "identity": 6
  },
  {
    "cidr": "10.75.0.103/32",
    "hostIP": "172.31.198.153",
    "identity": 5005442,
    "metadata": {
      "name": "coredns-cc6ccd49c-5g7f5",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.75.0.226/32",
    "hostIP": "172.31.198.153",
    "identity": 5005442,
    "metadata": {
      "name": "coredns-cc6ccd49c-nb7vc",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.76.0.10/32",
    "hostIP": "172.31.158.228",
    "identity": 5051738,
    "metadata": {
      "name": "clustermesh-apiserver-64dc5b6c5b-4wd6j",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.76.0.119/32",
    "hostIP": "172.31.158.228",
    "identity": 5050532,
    "metadata": {
      "name": "coredns-cc6ccd49c-5btjx",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.76.0.138/32",
    "hostIP": "172.31.158.228",
    "identity": 5050532,
    "metadata": {
      "name": "coredns-cc6ccd49c-dnfbx",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.76.0.156/32",
    "hostIP": "172.31.158.228",
    "identity": 6
  },
  {
    "cidr": "10.76.0.172/32",
    "hostIP": "172.31.158.228",
    "identity": 4
  },
  {
    "cidr": "10.77.0.180/32",
    "hostIP": "172.31.236.177",
    "identity": 5164343,
    "metadata": {
      "name": "coredns-cc6ccd49c-xpj4g",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.77.0.185/32",
    "hostIP": "172.31.236.177",
    "identity": 4
  },
  {
    "cidr": "10.77.0.192/32",
    "hostIP": "172.31.236.177",
    "identity": 6
  },
  {
    "cidr": "10.77.0.203/32",
    "hostIP": "172.31.236.177",
    "identity": 5164343,
    "metadata": {
      "name": "coredns-cc6ccd49c-jjxdr",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.77.0.249/32",
    "hostIP": "172.31.236.177",
    "identity": 5140967,
    "metadata": {
      "name": "clustermesh-apiserver-5c5f75ff5-r76fv",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.78.0.60/32",
    "hostIP": "172.31.133.70",
    "identity": 4
  },
  {
    "cidr": "10.78.0.154/32",
    "hostIP": "172.31.133.70",
    "identity": 5234507,
    "metadata": {
      "name": "clustermesh-apiserver-556f68d94b-rgvfh",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.78.0.227/32",
    "hostIP": "172.31.133.70",
    "identity": 5181692,
    "metadata": {
      "name": "coredns-cc6ccd49c-64276",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.78.0.235/32",
    "hostIP": "172.31.133.70",
    "identity": 6
  },
  {
    "cidr": "10.78.0.239/32",
    "hostIP": "172.31.133.70",
    "identity": 5181692,
    "metadata": {
      "name": "coredns-cc6ccd49c-tbgrq",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.79.0.57/32",
    "hostIP": "172.31.217.236",
    "identity": 5268971,
    "metadata": {
      "name": "coredns-cc6ccd49c-chhqn",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.79.0.102/32",
    "hostIP": "172.31.217.236",
    "identity": 5246949,
    "metadata": {
      "name": "clustermesh-apiserver-7596bf47f9-z8kvz",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.79.0.164/32",
    "hostIP": "172.31.217.236",
    "identity": 6
  },
  {
    "cidr": "10.79.0.183/32",
    "hostIP": "172.31.217.236",
    "identity": 4
  },
  {
    "cidr": "10.79.0.222/32",
    "hostIP": "172.31.217.236",
    "identity": 5268971,
    "metadata": {
      "name": "coredns-cc6ccd49c-dss99",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.80.0.8/32",
    "hostIP": "172.31.133.51",
    "identity": 4
  },
  {
    "cidr": "10.80.0.72/32",
    "hostIP": "172.31.133.51",
    "identity": 5364893,
    "metadata": {
      "name": "clustermesh-apiserver-5f876cfc56-c94xr",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.80.0.93/32",
    "hostIP": "172.31.133.51",
    "identity": 5365663,
    "metadata": {
      "name": "coredns-cc6ccd49c-gbhr2",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.80.0.143/32",
    "hostIP": "172.31.133.51",
    "identity": 5365663,
    "metadata": {
      "name": "coredns-cc6ccd49c-f8lhs",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.80.0.211/32",
    "hostIP": "172.31.133.51",
    "identity": 6
  },
  {
    "cidr": "10.81.0.5/32",
    "hostIP": "172.31.195.150",
    "identity": 6
  },
  {
    "cidr": "10.81.0.9/32",
    "hostIP": "172.31.195.150",
    "identity": 5395910,
    "metadata": {
      "name": "coredns-cc6ccd49c-944g5",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.81.0.31/32",
    "hostIP": "172.31.195.150",
    "identity": 4
  },
  {
    "cidr": "10.81.0.83/32",
    "hostIP": "172.31.195.150",
    "identity": 5379799,
    "metadata": {
      "name": "clustermesh-apiserver-5fb4d4b8cf-qfb8f",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.81.0.144/32",
    "hostIP": "172.31.195.150",
    "identity": 5395910,
    "metadata": {
      "name": "coredns-cc6ccd49c-5frf9",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.82.0.65/32",
    "hostIP": "172.31.139.233",
    "identity": 5467195,
    "metadata": {
      "name": "coredns-cc6ccd49c-cd7xq",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.82.0.95/32",
    "hostIP": "172.31.139.233",
    "identity": 5467195,
    "metadata": {
      "name": "coredns-cc6ccd49c-v5956",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.82.0.139/32",
    "hostIP": "172.31.139.233",
    "identity": 4
  },
  {
    "cidr": "10.82.0.146/32",
    "hostIP": "172.31.139.233",
    "identity": 6
  },
  {
    "cidr": "10.82.0.217/32",
    "hostIP": "172.31.139.233",
    "identity": 5486641,
    "metadata": {
      "name": "clustermesh-apiserver-6669554d88-hf76n",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.83.0.53/32",
    "hostIP": "172.31.231.66",
    "identity": 4
  },
  {
    "cidr": "10.83.0.78/32",
    "hostIP": "172.31.231.66",
    "identity": 5540605,
    "metadata": {
      "name": "coredns-cc6ccd49c-cwnc6",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.83.0.150/32",
    "hostIP": "172.31.231.66",
    "identity": 5510743,
    "metadata": {
      "name": "clustermesh-apiserver-7dbf7fb7b6-gq6mz",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.83.0.221/32",
    "hostIP": "172.31.231.66",
    "identity": 6
  },
  {
    "cidr": "10.83.0.237/32",
    "hostIP": "172.31.231.66",
    "identity": 5540605,
    "metadata": {
      "name": "coredns-cc6ccd49c-j7457",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.84.0.17/32",
    "hostIP": "172.31.140.168",
    "identity": 5598271,
    "metadata": {
      "name": "coredns-cc6ccd49c-qsz62",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.84.0.62/32",
    "hostIP": "172.31.140.168",
    "identity": 6
  },
  {
    "cidr": "10.84.0.106/32",
    "hostIP": "172.31.140.168",
    "identity": 4
  },
  {
    "cidr": "10.84.0.191/32",
    "hostIP": "172.31.140.168",
    "identity": 5578572,
    "metadata": {
      "name": "clustermesh-apiserver-6664d8fd7c-xfwcp",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.84.0.241/32",
    "hostIP": "172.31.140.168",
    "identity": 5598271,
    "metadata": {
      "name": "coredns-cc6ccd49c-725lp",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.85.0.63/32",
    "hostIP": "172.31.228.79",
    "identity": 4
  },
  {
    "cidr": "10.85.0.105/32",
    "hostIP": "172.31.228.79",
    "identity": 5670699,
    "metadata": {
      "name": "coredns-cc6ccd49c-x4krt",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.85.0.106/32",
    "hostIP": "172.31.228.79",
    "identity": 5643711,
    "metadata": {
      "name": "clustermesh-apiserver-6cbfd85b78-p6d8g",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.85.0.154/32",
    "hostIP": "172.31.228.79",
    "identity": 6
  },
  {
    "cidr": "10.85.0.194/32",
    "hostIP": "172.31.228.79",
    "identity": 5670699,
    "metadata": {
      "name": "coredns-cc6ccd49c-bl8bf",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.86.0.1/32",
    "hostIP": "172.31.156.163",
    "identity": 5765474,
    "metadata": {
      "name": "coredns-cc6ccd49c-kq7nt",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.86.0.39/32",
    "hostIP": "172.31.156.163",
    "identity": 5702245,
    "metadata": {
      "name": "clustermesh-apiserver-7c8779c849-xlpfc",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.86.0.48/32",
    "hostIP": "172.31.156.163",
    "identity": 5765474,
    "metadata": {
      "name": "coredns-cc6ccd49c-72vnv",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.86.0.92/32",
    "hostIP": "172.31.156.163",
    "identity": 4
  },
  {
    "cidr": "10.86.0.197/32",
    "hostIP": "172.31.156.163",
    "identity": 6
  },
  {
    "cidr": "10.87.0.23/32",
    "hostIP": "172.31.209.17",
    "identity": 5776013,
    "metadata": {
      "name": "coredns-cc6ccd49c-fvhp4",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.87.0.99/32",
    "hostIP": "172.31.209.17",
    "identity": 5776013,
    "metadata": {
      "name": "coredns-cc6ccd49c-v9htt",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.87.0.121/32",
    "hostIP": "172.31.209.17",
    "identity": 6
  },
  {
    "cidr": "10.87.0.179/32",
    "hostIP": "172.31.209.17",
    "identity": 4
  },
  {
    "cidr": "10.87.0.232/32",
    "hostIP": "172.31.209.17",
    "identity": 5780442,
    "metadata": {
      "name": "clustermesh-apiserver-787fbcd447-jzwz5",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.88.0.151/32",
    "hostIP": "172.31.167.92",
    "identity": 4
  },
  {
    "cidr": "10.88.0.157/32",
    "hostIP": "172.31.167.92",
    "identity": 6
  },
  {
    "cidr": "10.88.0.171/32",
    "hostIP": "172.31.167.92",
    "identity": 5869258,
    "metadata": {
      "name": "clustermesh-apiserver-6cb6c6c7b4-jzrjx",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.88.0.198/32",
    "hostIP": "172.31.167.92",
    "identity": 5885380,
    "metadata": {
      "name": "coredns-cc6ccd49c-st56c",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.88.0.201/32",
    "hostIP": "172.31.167.92",
    "identity": 5885380,
    "metadata": {
      "name": "coredns-cc6ccd49c-gwnwm",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.89.0.31/32",
    "hostIP": "172.31.234.174",
    "identity": 5963165,
    "metadata": {
      "name": "coredns-cc6ccd49c-sbr5f",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.89.0.97/32",
    "hostIP": "172.31.234.174",
    "identity": 4
  },
  {
    "cidr": "10.89.0.214/32",
    "hostIP": "172.31.234.174",
    "identity": 5963165,
    "metadata": {
      "name": "coredns-cc6ccd49c-slxgc",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.89.0.216/32",
    "hostIP": "172.31.234.174",
    "identity": 5932289,
    "metadata": {
      "name": "clustermesh-apiserver-76948b4cc8-mmkh2",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.89.0.237/32",
    "hostIP": "172.31.234.174",
    "identity": 6
  },
  {
    "cidr": "10.90.0.66/32",
    "hostIP": "172.31.162.75",
    "identity": 5964560,
    "metadata": {
      "name": "clustermesh-apiserver-6ffd5c84d9-xgb9m",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.90.0.123/32",
    "hostIP": "172.31.162.75",
    "identity": 5982711,
    "metadata": {
      "name": "coredns-cc6ccd49c-jdsg2",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.90.0.141/32",
    "hostIP": "172.31.162.75",
    "identity": 4
  },
  {
    "cidr": "10.90.0.218/32",
    "hostIP": "172.31.162.75",
    "identity": 5982711,
    "metadata": {
      "name": "coredns-cc6ccd49c-qbd85",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.90.0.226/32",
    "hostIP": "172.31.162.75",
    "identity": 6
  },
  {
    "cidr": "10.91.0.11/32",
    "hostIP": "172.31.225.137",
    "identity": 6042107,
    "metadata": {
      "name": "clustermesh-apiserver-6c444cbbc9-knqth",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.91.0.47/32",
    "hostIP": "172.31.225.137",
    "identity": 6051532,
    "metadata": {
      "name": "coredns-cc6ccd49c-hcncb",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.91.0.78/32",
    "hostIP": "172.31.225.137",
    "identity": 4
  },
  {
    "cidr": "10.91.0.194/32",
    "hostIP": "172.31.225.137",
    "identity": 6
  },
  {
    "cidr": "10.91.0.234/32",
    "hostIP": "172.31.225.137",
    "identity": 6051532,
    "metadata": {
      "name": "coredns-cc6ccd49c-fhjl5",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.92.0.87/32",
    "hostIP": "172.31.129.184",
    "identity": 4
  },
  {
    "cidr": "10.92.0.92/32",
    "hostIP": "172.31.129.184",
    "identity": 6
  },
  {
    "cidr": "10.92.0.155/32",
    "hostIP": "172.31.129.184",
    "identity": 6096447,
    "metadata": {
      "name": "clustermesh-apiserver-7d6dcdb66c-26bq5",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.92.0.163/32",
    "hostIP": "172.31.129.184",
    "identity": 6133973,
    "metadata": {
      "name": "coredns-cc6ccd49c-jqmgf",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.92.0.166/32",
    "hostIP": "172.31.129.184",
    "identity": 6133973,
    "metadata": {
      "name": "coredns-cc6ccd49c-24hr7",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.93.0.4/32",
    "hostIP": "172.31.250.1",
    "identity": 4
  },
  {
    "cidr": "10.93.0.42/32",
    "hostIP": "172.31.250.1",
    "identity": 6163463,
    "metadata": {
      "name": "clustermesh-apiserver-5d89f7744c-vwk9r",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.93.0.49/32",
    "hostIP": "172.31.250.1",
    "identity": 6215900,
    "metadata": {
      "name": "coredns-cc6ccd49c-gr9rn",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.93.0.99/32",
    "hostIP": "172.31.250.1",
    "identity": 6215900,
    "metadata": {
      "name": "coredns-cc6ccd49c-sq7jc",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.93.0.125/32",
    "hostIP": "172.31.250.1",
    "identity": 6
  },
  {
    "cidr": "10.94.0.74/32",
    "hostIP": "172.31.186.243",
    "identity": 4
  },
  {
    "cidr": "10.94.0.119/32",
    "hostIP": "172.31.186.243",
    "identity": 6
  },
  {
    "cidr": "10.94.0.121/32",
    "hostIP": "172.31.186.243",
    "identity": 6246044,
    "metadata": {
      "name": "clustermesh-apiserver-795cf847cd-b89h6",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.94.0.161/32",
    "hostIP": "172.31.186.243",
    "identity": 6232298,
    "metadata": {
      "name": "coredns-cc6ccd49c-hw98h",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.94.0.192/32",
    "hostIP": "172.31.186.243",
    "identity": 6232298,
    "metadata": {
      "name": "coredns-cc6ccd49c-5jrpl",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.95.0.25/32",
    "hostIP": "172.31.207.111",
    "identity": 4
  },
  {
    "cidr": "10.95.0.84/32",
    "hostIP": "172.31.207.111",
    "identity": 6
  },
  {
    "cidr": "10.95.0.147/32",
    "hostIP": "172.31.207.111",
    "identity": 6323134,
    "metadata": {
      "name": "coredns-cc6ccd49c-bg4hg",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.95.0.233/32",
    "hostIP": "172.31.207.111",
    "identity": 6323134,
    "metadata": {
      "name": "coredns-cc6ccd49c-xwwwp",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.95.0.250/32",
    "hostIP": "172.31.207.111",
    "identity": 6292321,
    "metadata": {
      "name": "clustermesh-apiserver-5b6b8f4845-4rc4f",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.96.0.21/32",
    "hostIP": "172.31.129.241",
    "identity": 6365046,
    "metadata": {
      "name": "coredns-cc6ccd49c-j8cgw",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.96.0.116/32",
    "hostIP": "172.31.129.241",
    "identity": 6361306,
    "metadata": {
      "name": "clustermesh-apiserver-77669b494c-4r5xr",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.96.0.197/32",
    "hostIP": "172.31.129.241",
    "identity": 6
  },
  {
    "cidr": "10.96.0.200/32",
    "hostIP": "172.31.129.241",
    "identity": 6365046,
    "metadata": {
      "name": "coredns-cc6ccd49c-4dz52",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.96.0.231/32",
    "hostIP": "172.31.129.241",
    "identity": 4
  },
  {
    "cidr": "10.97.0.22/32",
    "hostIP": "172.31.225.158",
    "identity": 4
  },
  {
    "cidr": "10.97.0.52/32",
    "hostIP": "172.31.225.158",
    "identity": 6429657,
    "metadata": {
      "name": "coredns-cc6ccd49c-vfbbz",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.97.0.95/32",
    "hostIP": "172.31.225.158",
    "identity": 6
  },
  {
    "cidr": "10.97.0.222/32",
    "hostIP": "172.31.225.158",
    "identity": 6454857,
    "metadata": {
      "name": "clustermesh-apiserver-5f4b96578-qqwxf",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.97.0.251/32",
    "hostIP": "172.31.225.158",
    "identity": 6429657,
    "metadata": {
      "name": "coredns-cc6ccd49c-r8k22",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.98.0.55/32",
    "hostIP": "172.31.173.171",
    "identity": 6
  },
  {
    "cidr": "10.98.0.126/32",
    "hostIP": "172.31.173.171",
    "identity": 4
  },
  {
    "cidr": "10.98.0.167/32",
    "hostIP": "172.31.173.171",
    "identity": 6522857,
    "metadata": {
      "name": "clustermesh-apiserver-7f5c896f94-hq45n",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.98.0.210/32",
    "hostIP": "172.31.173.171",
    "identity": 6545166,
    "metadata": {
      "name": "coredns-cc6ccd49c-n2mlv",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.98.0.216/32",
    "hostIP": "172.31.173.171",
    "identity": 6545166,
    "metadata": {
      "name": "coredns-cc6ccd49c-j9446",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.99.0.78/32",
    "hostIP": "172.31.201.30",
    "identity": 6
  },
  {
    "cidr": "10.99.0.119/32",
    "hostIP": "172.31.201.30",
    "identity": 6572220,
    "metadata": {
      "name": "coredns-cc6ccd49c-lcdmg",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.99.0.170/32",
    "hostIP": "172.31.201.30",
    "identity": 4
  },
  {
    "cidr": "10.99.0.181/32",
    "hostIP": "172.31.201.30",
    "identity": 6572220,
    "metadata": {
      "name": "coredns-cc6ccd49c-c65lk",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.99.0.183/32",
    "hostIP": "172.31.201.30",
    "identity": 6564329,
    "metadata": {
      "name": "clustermesh-apiserver-77695dc8d7-ddsjl",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.100.0.20/32",
    "hostIP": "172.31.165.24",
    "identity": 6621480,
    "metadata": {
      "name": "coredns-cc6ccd49c-hjs2l",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.100.0.58/32",
    "hostIP": "172.31.165.24",
    "identity": 6621045,
    "metadata": {
      "name": "clustermesh-apiserver-6d759d98c4-vj5dq",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.100.0.85/32",
    "hostIP": "172.31.165.24",
    "identity": 6
  },
  {
    "cidr": "10.100.0.204/32",
    "hostIP": "172.31.165.24",
    "identity": 4
  },
  {
    "cidr": "10.100.0.212/32",
    "hostIP": "172.31.165.24",
    "identity": 6621480,
    "metadata": {
      "name": "coredns-cc6ccd49c-l744t",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.101.0.8/32",
    "hostIP": "172.31.195.223",
    "identity": 6
  },
  {
    "cidr": "10.101.0.119/32",
    "hostIP": "172.31.195.223",
    "identity": 6699851,
    "metadata": {
      "name": "clustermesh-apiserver-765c658dd5-5hlbs",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.101.0.128/32",
    "hostIP": "172.31.195.223",
    "identity": 6707244,
    "metadata": {
      "name": "coredns-cc6ccd49c-f4p48",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.101.0.168/32",
    "hostIP": "172.31.195.223",
    "identity": 4
  },
  {
    "cidr": "10.101.0.228/32",
    "hostIP": "172.31.195.223",
    "identity": 6707244,
    "metadata": {
      "name": "coredns-cc6ccd49c-48lj6",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.102.0.20/32",
    "hostIP": "172.31.184.93",
    "identity": 6
  },
  {
    "cidr": "10.102.0.29/32",
    "hostIP": "172.31.184.93",
    "identity": 6765596,
    "metadata": {
      "name": "coredns-cc6ccd49c-ckxjk",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.102.0.61/32",
    "hostIP": "172.31.184.93",
    "identity": 4
  },
  {
    "cidr": "10.102.0.132/32",
    "hostIP": "172.31.184.93",
    "identity": 6771774,
    "metadata": {
      "name": "clustermesh-apiserver-6c7b5ccd57-w6lps",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.102.0.155/32",
    "hostIP": "172.31.184.93",
    "identity": 6765596,
    "metadata": {
      "name": "coredns-cc6ccd49c-rq4r6",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.103.0.65/32",
    "hostIP": "172.31.216.37",
    "identity": 6
  },
  {
    "cidr": "10.103.0.166/32",
    "hostIP": "172.31.216.37",
    "identity": 4
  },
  {
    "cidr": "10.103.0.191/32",
    "hostIP": "172.31.216.37",
    "identity": 6871442,
    "metadata": {
      "name": "coredns-cc6ccd49c-twbn8",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.103.0.234/32",
    "hostIP": "172.31.216.37",
    "identity": 6820238,
    "metadata": {
      "name": "clustermesh-apiserver-6774c89bd-rz5s6",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.103.0.247/32",
    "hostIP": "172.31.216.37",
    "identity": 6871442,
    "metadata": {
      "name": "coredns-cc6ccd49c-9sgb2",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.104.0.7/32",
    "hostIP": "172.31.188.169",
    "identity": 6936077,
    "metadata": {
      "name": "coredns-cc6ccd49c-kxzvc",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.104.0.34/32",
    "hostIP": "172.31.188.169",
    "identity": 6
  },
  {
    "cidr": "10.104.0.154/32",
    "hostIP": "172.31.188.169",
    "identity": 4
  },
  {
    "cidr": "10.104.0.193/32",
    "hostIP": "172.31.188.169",
    "identity": 6911961,
    "metadata": {
      "name": "clustermesh-apiserver-7474669c9f-lxkpt",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.104.0.224/32",
    "hostIP": "172.31.188.169",
    "identity": 6936077,
    "metadata": {
      "name": "coredns-cc6ccd49c-9dpp8",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.105.0.35/32",
    "hostIP": "172.31.227.91",
    "identity": 6
  },
  {
    "cidr": "10.105.0.59/32",
    "hostIP": "172.31.227.91",
    "identity": 6965962,
    "metadata": {
      "name": "clustermesh-apiserver-775b76db66-mgx9w",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.105.0.136/32",
    "hostIP": "172.31.227.91",
    "identity": 6972169,
    "metadata": {
      "name": "coredns-cc6ccd49c-hf7lf",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.105.0.237/32",
    "hostIP": "172.31.227.91",
    "identity": 4
  },
  {
    "cidr": "10.105.0.247/32",
    "hostIP": "172.31.227.91",
    "identity": 6972169,
    "metadata": {
      "name": "coredns-cc6ccd49c-vmcl4",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.106.0.5/32",
    "hostIP": "172.31.178.197",
    "identity": 4
  },
  {
    "cidr": "10.106.0.59/32",
    "hostIP": "172.31.178.197",
    "identity": 6
  },
  {
    "cidr": "10.106.0.160/32",
    "hostIP": "172.31.178.197",
    "identity": 7035009,
    "metadata": {
      "name": "clustermesh-apiserver-cb96766c-78pcs",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.106.0.207/32",
    "hostIP": "172.31.178.197",
    "identity": 7042333,
    "metadata": {
      "name": "coredns-cc6ccd49c-xhjkg",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.106.0.247/32",
    "hostIP": "172.31.178.197",
    "identity": 7042333,
    "metadata": {
      "name": "coredns-cc6ccd49c-tmtgb",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.107.0.109/32",
    "hostIP": "172.31.238.183",
    "identity": 4
  },
  {
    "cidr": "10.107.0.111/32",
    "hostIP": "172.31.238.183",
    "identity": 6
  },
  {
    "cidr": "10.107.0.165/32",
    "hostIP": "172.31.238.183",
    "identity": 7085474,
    "metadata": {
      "name": "coredns-cc6ccd49c-ks5k9",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.107.0.220/32",
    "hostIP": "172.31.238.183",
    "identity": 7117408,
    "metadata": {
      "name": "clustermesh-apiserver-d7bcff55b-w2q6b",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.107.0.235/32",
    "hostIP": "172.31.238.183",
    "identity": 7085474,
    "metadata": {
      "name": "coredns-cc6ccd49c-tsptq",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.108.0.5/32",
    "hostIP": "172.31.173.246",
    "identity": 6
  },
  {
    "cidr": "10.108.0.40/32",
    "hostIP": "172.31.173.246",
    "identity": 7180185,
    "metadata": {
      "name": "coredns-cc6ccd49c-mkwj5",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.108.0.89/32",
    "hostIP": "172.31.173.246",
    "identity": 7187788,
    "metadata": {
      "name": "clustermesh-apiserver-6f6fdbfccf-6vsps",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.108.0.127/32",
    "hostIP": "172.31.173.246",
    "identity": 4
  },
  {
    "cidr": "10.108.0.171/32",
    "hostIP": "172.31.173.246",
    "identity": 7180185,
    "metadata": {
      "name": "coredns-cc6ccd49c-ww7st",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.109.0.5/32",
    "hostIP": "172.31.224.45",
    "identity": 7223452,
    "metadata": {
      "name": "clustermesh-apiserver-57dfd86f8f-ff77t",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.109.0.163/32",
    "hostIP": "172.31.224.45",
    "identity": 7215329,
    "metadata": {
      "name": "coredns-cc6ccd49c-5b4rc",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.109.0.196/32",
    "hostIP": "172.31.224.45",
    "identity": 4
  },
  {
    "cidr": "10.109.0.211/32",
    "hostIP": "172.31.224.45",
    "identity": 7215329,
    "metadata": {
      "name": "coredns-cc6ccd49c-hkfbp",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.109.0.243/32",
    "hostIP": "172.31.224.45",
    "identity": 6
  },
  {
    "cidr": "10.110.0.15/32",
    "hostIP": "172.31.152.109",
    "identity": 7318862,
    "metadata": {
      "name": "coredns-cc6ccd49c-7lp8l",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.110.0.39/32",
    "hostIP": "172.31.152.109",
    "identity": 6
  },
  {
    "cidr": "10.110.0.73/32",
    "hostIP": "172.31.152.109",
    "identity": 4
  },
  {
    "cidr": "10.110.0.172/32",
    "hostIP": "172.31.152.109",
    "identity": 7318862,
    "metadata": {
      "name": "coredns-cc6ccd49c-z6gpf",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.110.0.243/32",
    "hostIP": "172.31.152.109",
    "identity": 7307047,
    "metadata": {
      "name": "clustermesh-apiserver-b49584847-6cvm5",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.111.0.43/32",
    "hostIP": "172.31.227.62",
    "identity": 6
  },
  {
    "cidr": "10.111.0.77/32",
    "hostIP": "172.31.227.62",
    "identity": 7379824,
    "metadata": {
      "name": "coredns-cc6ccd49c-qxzrx",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.111.0.79/32",
    "hostIP": "172.31.227.62",
    "identity": 7398745,
    "metadata": {
      "name": "clustermesh-apiserver-d57dbc4f-plm5h",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.111.0.105/32",
    "hostIP": "172.31.227.62",
    "identity": 4
  },
  {
    "cidr": "10.111.0.162/32",
    "hostIP": "172.31.227.62",
    "identity": 7379824,
    "metadata": {
      "name": "coredns-cc6ccd49c-bxvtl",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.112.0.68/32",
    "hostIP": "172.31.179.165",
    "identity": 7435919,
    "metadata": {
      "name": "coredns-cc6ccd49c-99xv9",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.112.0.135/32",
    "hostIP": "172.31.179.165",
    "identity": 4
  },
  {
    "cidr": "10.112.0.163/32",
    "hostIP": "172.31.179.165",
    "identity": 6
  },
  {
    "cidr": "10.112.0.168/32",
    "hostIP": "172.31.179.165",
    "identity": 7435919,
    "metadata": {
      "name": "coredns-cc6ccd49c-8twpf",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.112.0.199/32",
    "hostIP": "172.31.179.165",
    "identity": 7430613,
    "metadata": {
      "name": "clustermesh-apiserver-7bd95d4974-jqnw8",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.113.0.28/32",
    "hostIP": "172.31.195.97",
    "identity": 7498628,
    "metadata": {
      "name": "coredns-cc6ccd49c-fvfq6",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.113.0.87/32",
    "hostIP": "172.31.195.97",
    "identity": 7498628,
    "metadata": {
      "name": "coredns-cc6ccd49c-pdtlc",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.113.0.127/32",
    "hostIP": "172.31.195.97",
    "identity": 6
  },
  {
    "cidr": "10.113.0.198/32",
    "hostIP": "172.31.195.97",
    "identity": 4
  },
  {
    "cidr": "10.113.0.223/32",
    "hostIP": "172.31.195.97",
    "identity": 7489522,
    "metadata": {
      "name": "clustermesh-apiserver-7cdb49698f-mfdkd",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.114.0.17/32",
    "hostIP": "172.31.143.66",
    "identity": 6
  },
  {
    "cidr": "10.114.0.25/32",
    "hostIP": "172.31.143.66",
    "identity": 7562843,
    "metadata": {
      "name": "clustermesh-apiserver-8595d85bd7-m66rq",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.114.0.172/32",
    "hostIP": "172.31.143.66",
    "identity": 7551770,
    "metadata": {
      "name": "coredns-cc6ccd49c-hlc6b",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.114.0.181/32",
    "hostIP": "172.31.143.66",
    "identity": 7551770,
    "metadata": {
      "name": "coredns-cc6ccd49c-jxb4b",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.114.0.223/32",
    "hostIP": "172.31.143.66",
    "identity": 4
  },
  {
    "cidr": "10.115.0.20/32",
    "hostIP": "172.31.197.216",
    "identity": 7610734,
    "metadata": {
      "name": "coredns-cc6ccd49c-rj7c4",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.115.0.50/32",
    "hostIP": "172.31.197.216",
    "identity": 7610734,
    "metadata": {
      "name": "coredns-cc6ccd49c-wdxdk",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.115.0.160/32",
    "hostIP": "172.31.197.216",
    "identity": 7610633,
    "metadata": {
      "name": "clustermesh-apiserver-84c4b75b4d-79d9v",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.115.0.166/32",
    "hostIP": "172.31.197.216",
    "identity": 6
  },
  {
    "cidr": "10.115.0.242/32",
    "hostIP": "172.31.197.216",
    "identity": 4
  },
  {
    "cidr": "10.116.0.114/32",
    "hostIP": "172.31.163.31",
    "identity": 7671537,
    "metadata": {
      "name": "clustermesh-apiserver-66bc96f6cf-kkxrv",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.116.0.139/32",
    "hostIP": "172.31.163.31",
    "identity": 6
  },
  {
    "cidr": "10.116.0.168/32",
    "hostIP": "172.31.163.31",
    "identity": 7689467,
    "metadata": {
      "name": "coredns-cc6ccd49c-cckwj",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.116.0.248/32",
    "hostIP": "172.31.163.31",
    "identity": 4
  },
  {
    "cidr": "10.116.0.250/32",
    "hostIP": "172.31.163.31",
    "identity": 7689467,
    "metadata": {
      "name": "coredns-cc6ccd49c-mp48w",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.117.0.30/32",
    "hostIP": "172.31.209.231",
    "identity": 7740688,
    "metadata": {
      "name": "coredns-cc6ccd49c-pggt8",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.117.0.58/32",
    "hostIP": "172.31.209.231",
    "identity": 7767784,
    "metadata": {
      "name": "clustermesh-apiserver-748b7c8b8c-jqkzk",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.117.0.137/32",
    "hostIP": "172.31.209.231",
    "identity": 7740688,
    "metadata": {
      "name": "coredns-cc6ccd49c-l6vrz",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.117.0.145/32",
    "hostIP": "172.31.209.231",
    "identity": 4
  },
  {
    "cidr": "10.117.0.238/32",
    "hostIP": "172.31.209.231",
    "identity": 6
  },
  {
    "cidr": "10.118.0.8/32",
    "hostIP": "172.31.169.120",
    "identity": 7827054,
    "metadata": {
      "name": "coredns-cc6ccd49c-6qprz",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.118.0.35/32",
    "hostIP": "172.31.169.120",
    "identity": 7804999,
    "metadata": {
      "name": "clustermesh-apiserver-666f6db888-m6tkb",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.118.0.41/32",
    "hostIP": "172.31.169.120",
    "identity": 7827054,
    "metadata": {
      "name": "coredns-cc6ccd49c-n9fdp",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.118.0.76/32",
    "hostIP": "172.31.169.120",
    "identity": 4
  },
  {
    "cidr": "10.118.0.139/32",
    "hostIP": "172.31.169.120",
    "identity": 6
  },
  {
    "cidr": "10.119.0.11/32",
    "hostIP": "172.31.250.55",
    "identity": 7887282,
    "metadata": {
      "name": "coredns-cc6ccd49c-dhpbw",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.119.0.35/32",
    "hostIP": "172.31.250.55",
    "identity": 7887282,
    "metadata": {
      "name": "coredns-cc6ccd49c-xgqsk",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.119.0.129/32",
    "hostIP": "172.31.250.55",
    "identity": 4
  },
  {
    "cidr": "10.119.0.174/32",
    "hostIP": "172.31.250.55",
    "identity": 7891667,
    "metadata": {
      "name": "clustermesh-apiserver-5dfb8d7b84-xhtcx",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.119.0.245/32",
    "hostIP": "172.31.250.55",
    "identity": 6
  },
  {
    "cidr": "10.120.0.129/32",
    "hostIP": "172.31.149.225",
    "identity": 7963982,
    "metadata": {
      "name": "coredns-cc6ccd49c-jvhz4",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.120.0.130/32",
    "hostIP": "172.31.149.225",
    "identity": 4
  },
  {
    "cidr": "10.120.0.158/32",
    "hostIP": "172.31.149.225",
    "identity": 7963982,
    "metadata": {
      "name": "coredns-cc6ccd49c-44p5w",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.120.0.208/32",
    "hostIP": "172.31.149.225",
    "identity": 7943068,
    "metadata": {
      "name": "clustermesh-apiserver-78b66fbf65-xpwq2",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.120.0.242/32",
    "hostIP": "172.31.149.225",
    "identity": 6
  },
  {
    "cidr": "10.121.0.39/32",
    "hostIP": "172.31.220.42",
    "identity": 8008002,
    "metadata": {
      "name": "coredns-cc6ccd49c-8h96d",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.121.0.119/32",
    "hostIP": "172.31.220.42",
    "identity": 6
  },
  {
    "cidr": "10.121.0.129/32",
    "hostIP": "172.31.220.42",
    "identity": 8008002,
    "metadata": {
      "name": "coredns-cc6ccd49c-mc8zr",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.121.0.206/32",
    "hostIP": "172.31.220.42",
    "identity": 8019820,
    "metadata": {
      "name": "clustermesh-apiserver-6bd457c78f-h8tg7",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.121.0.254/32",
    "hostIP": "172.31.220.42",
    "identity": 4
  },
  {
    "cidr": "10.122.0.37/32",
    "hostIP": "172.31.144.245",
    "identity": 4
  },
  {
    "cidr": "10.122.0.83/32",
    "hostIP": "172.31.144.245",
    "identity": 8080194,
    "metadata": {
      "name": "clustermesh-apiserver-679685866b-chrkh",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.122.0.103/32",
    "hostIP": "172.31.144.245",
    "identity": 6
  },
  {
    "cidr": "10.122.0.114/32",
    "hostIP": "172.31.144.245",
    "identity": 8075225,
    "metadata": {
      "name": "coredns-cc6ccd49c-68fdg",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.122.0.232/32",
    "hostIP": "172.31.144.245",
    "identity": 8075225,
    "metadata": {
      "name": "coredns-cc6ccd49c-pdbb8",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.123.0.11/32",
    "hostIP": "172.31.226.176",
    "identity": 8148649,
    "metadata": {
      "name": "clustermesh-apiserver-6b8b6d6579-75zt6",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.123.0.42/32",
    "hostIP": "172.31.226.176",
    "identity": 4
  },
  {
    "cidr": "10.123.0.94/32",
    "hostIP": "172.31.226.176",
    "identity": 8146521,
    "metadata": {
      "name": "coredns-cc6ccd49c-w7567",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.123.0.109/32",
    "hostIP": "172.31.226.176",
    "identity": 6
  },
  {
    "cidr": "10.123.0.113/32",
    "hostIP": "172.31.226.176",
    "identity": 8146521,
    "metadata": {
      "name": "coredns-cc6ccd49c-dsk56",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.124.0.67/32",
    "hostIP": "172.31.147.32",
    "identity": 8195318,
    "metadata": {
      "name": "coredns-cc6ccd49c-mbtcz",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.124.0.78/32",
    "hostIP": "172.31.147.32",
    "identity": 8215642,
    "metadata": {
      "name": "clustermesh-apiserver-774c9cfb7-dpcxx",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.124.0.89/32",
    "hostIP": "172.31.147.32",
    "identity": 8195318,
    "metadata": {
      "name": "coredns-cc6ccd49c-2qds6",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.124.0.136/32",
    "hostIP": "172.31.147.32",
    "identity": 6
  },
  {
    "cidr": "10.124.0.160/32",
    "hostIP": "172.31.147.32",
    "identity": 4
  },
  {
    "cidr": "10.125.0.30/32",
    "hostIP": "172.31.220.135",
    "identity": 6
  },
  {
    "cidr": "10.125.0.87/32",
    "hostIP": "172.31.220.135",
    "identity": 8264628,
    "metadata": {
      "name": "clustermesh-apiserver-648dc49d66-9zt94",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.125.0.108/32",
    "hostIP": "172.31.220.135",
    "identity": 4
  },
  {
    "cidr": "10.125.0.129/32",
    "hostIP": "172.31.220.135",
    "identity": 8312322,
    "metadata": {
      "name": "coredns-cc6ccd49c-phmh4",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.125.0.132/32",
    "hostIP": "172.31.220.135",
    "identity": 8312322,
    "metadata": {
      "name": "coredns-cc6ccd49c-k5bzn",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.126.0.14/32",
    "hostIP": "172.31.181.107",
    "identity": 8349339,
    "metadata": {
      "name": "clustermesh-apiserver-67b7c554fd-7rvqz",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.126.0.44/32",
    "hostIP": "172.31.181.107",
    "identity": 4
  },
  {
    "cidr": "10.126.0.147/32",
    "hostIP": "172.31.181.107",
    "identity": 8323263,
    "metadata": {
      "name": "coredns-cc6ccd49c-d46j4",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.126.0.166/32",
    "hostIP": "172.31.181.107",
    "identity": 6
  },
  {
    "cidr": "10.126.0.236/32",
    "hostIP": "172.31.181.107",
    "identity": 8323263,
    "metadata": {
      "name": "coredns-cc6ccd49c-szvgs",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.127.0.29/32",
    "hostIP": "172.31.246.169",
    "identity": 8412465,
    "metadata": {
      "name": "coredns-cc6ccd49c-rzsdz",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.127.0.48/32",
    "hostIP": "172.31.246.169",
    "identity": 8395928,
    "metadata": {
      "name": "clustermesh-apiserver-54886f956c-sxg8q",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.127.0.133/32",
    "hostIP": "172.31.246.169",
    "identity": 8412465,
    "metadata": {
      "name": "coredns-cc6ccd49c-s2jqk",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.127.0.153/32",
    "hostIP": "172.31.246.169",
    "identity": 4
  },
  {
    "cidr": "10.127.0.198/32",
    "hostIP": "172.31.246.169",
    "identity": 6
  },
  {
    "cidr": "172.31.129.184/32",
    "identity": 6
  },
  {
    "cidr": "172.31.129.220/32",
    "identity": 6
  },
  {
    "cidr": "172.31.129.241/32",
    "identity": 6
  },
  {
    "cidr": "172.31.133.51/32",
    "identity": 6
  },
  {
    "cidr": "172.31.133.70/32",
    "identity": 6
  },
  {
    "cidr": "172.31.134.163/32",
    "identity": 6
  },
  {
    "cidr": "172.31.135.32/32",
    "identity": 6
  },
  {
    "cidr": "172.31.137.105/32",
    "identity": 6
  },
  {
    "cidr": "172.31.139.233/32",
    "identity": 6
  },
  {
    "cidr": "172.31.140.168/32",
    "identity": 6
  },
  {
    "cidr": "172.31.140.221/32",
    "identity": 6
  },
  {
    "cidr": "172.31.142.96/32",
    "identity": 6
  },
  {
    "cidr": "172.31.143.66/32",
    "identity": 6
  },
  {
    "cidr": "172.31.143.87/32",
    "identity": 6
  },
  {
    "cidr": "172.31.144.60/32",
    "identity": 6
  },
  {
    "cidr": "172.31.144.216/32",
    "identity": 6
  },
  {
    "cidr": "172.31.144.245/32",
    "identity": 6
  },
  {
    "cidr": "172.31.145.45/32",
    "identity": 6
  },
  {
    "cidr": "172.31.147.32/32",
    "identity": 6
  },
  {
    "cidr": "172.31.147.77/32",
    "identity": 6
  },
  {
    "cidr": "172.31.147.228/32",
    "identity": 6
  },
  {
    "cidr": "172.31.148.101/32",
    "identity": 6
  },
  {
    "cidr": "172.31.149.98/32",
    "identity": 6
  },
  {
    "cidr": "172.31.149.115/32",
    "identity": 6
  },
  {
    "cidr": "172.31.149.225/32",
    "identity": 6
  },
  {
    "cidr": "172.31.152.109/32",
    "identity": 6
  },
  {
    "cidr": "172.31.154.239/32",
    "identity": 6
  },
  {
    "cidr": "172.31.155.27/32",
    "identity": 6
  },
  {
    "cidr": "172.31.156.163/32",
    "identity": 6
  },
  {
    "cidr": "172.31.158.50/32",
    "identity": 6
  },
  {
    "cidr": "172.31.158.228/32",
    "identity": 6
  },
  {
    "cidr": "172.31.161.89/32",
    "identity": 6
  },
  {
    "cidr": "172.31.161.158/32",
    "identity": 6
  },
  {
    "cidr": "172.31.162.75/32",
    "identity": 6
  },
  {
    "cidr": "172.31.163.31/32",
    "identity": 6
  },
  {
    "cidr": "172.31.164.50/32",
    "identity": 16777217
  },
  {
    "cidr": "172.31.165.24/32",
    "identity": 6
  },
  {
    "cidr": "172.31.167.92/32",
    "identity": 6
  },
  {
    "cidr": "172.31.168.162/32",
    "identity": 6
  },
  {
    "cidr": "172.31.169.120/32",
    "identity": 6
  },
  {
    "cidr": "172.31.169.166/32",
    "identity": 6
  },
  {
    "cidr": "172.31.169.175/32",
    "identity": 6
  },
  {
    "cidr": "172.31.170.17/32",
    "identity": 6
  },
  {
    "cidr": "172.31.170.139/32",
    "identity": 6
  },
  {
    "cidr": "172.31.172.29/32",
    "identity": 6
  },
  {
    "cidr": "172.31.172.128/32",
    "identity": 6
  },
  {
    "cidr": "172.31.172.183/32",
    "identity": 6
  },
  {
    "cidr": "172.31.173.171/32",
    "identity": 6
  },
  {
    "cidr": "172.31.173.246/32",
    "identity": 6
  },
  {
    "cidr": "172.31.174.163/32",
    "identity": 6
  },
  {
    "cidr": "172.31.175.121/32",
    "identity": 6
  },
  {
    "cidr": "172.31.176.0/32",
    "identity": 6
  },
  {
    "cidr": "172.31.178.197/32",
    "identity": 6
  },
  {
    "cidr": "172.31.179.165/32",
    "identity": 6
  },
  {
    "cidr": "172.31.180.212/32",
    "identity": 6
  },
  {
    "cidr": "172.31.181.107/32",
    "identity": 6
  },
  {
    "cidr": "172.31.184.13/32",
    "identity": 6
  },
  {
    "cidr": "172.31.184.93/32",
    "identity": 6
  },
  {
    "cidr": "172.31.186.90/32",
    "identity": 6
  },
  {
    "cidr": "172.31.186.243/32",
    "identity": 6
  },
  {
    "cidr": "172.31.188.169/32",
    "identity": 6
  },
  {
    "cidr": "172.31.188.219/32",
    "identity": 6
  },
  {
    "cidr": "172.31.189.5/32",
    "identity": 6
  },
  {
    "cidr": "172.31.190.180/32",
    "identity": 6
  },
  {
    "cidr": "172.31.191.155/32",
    "identity": 6
  },
  {
    "cidr": "172.31.193.211/32",
    "identity": 6
  },
  {
    "cidr": "172.31.194.36/32",
    "identity": 6
  },
  {
    "cidr": "172.31.195.97/32",
    "identity": 6
  },
  {
    "cidr": "172.31.195.150/32",
    "identity": 6
  },
  {
    "cidr": "172.31.195.223/32",
    "identity": 6
  },
  {
    "cidr": "172.31.197.74/32",
    "identity": 6
  },
  {
    "cidr": "172.31.197.79/32",
    "identity": 6
  },
  {
    "cidr": "172.31.197.216/32",
    "identity": 6
  },
  {
    "cidr": "172.31.197.251/32",
    "identity": 6
  },
  {
    "cidr": "172.31.198.153/32",
    "identity": 6
  },
  {
    "cidr": "172.31.201.30/32",
    "identity": 6
  },
  {
    "cidr": "172.31.206.43/32",
    "identity": 6
  },
  {
    "cidr": "172.31.206.64/32",
    "identity": 6
  },
  {
    "cidr": "172.31.207.111/32",
    "identity": 6
  },
  {
    "cidr": "172.31.208.120/32",
    "identity": 6
  },
  {
    "cidr": "172.31.209.17/32",
    "identity": 6
  },
  {
    "cidr": "172.31.209.231/32",
    "identity": 6
  },
  {
    "cidr": "172.31.210.89/32",
    "identity": 6
  },
  {
    "cidr": "172.31.210.97/32",
    "identity": 6
  },
  {
    "cidr": "172.31.213.46/32",
    "identity": 6
  },
  {
    "cidr": "172.31.216.37/32",
    "identity": 6
  },
  {
    "cidr": "172.31.217.133/32",
    "identity": 6
  },
  {
    "cidr": "172.31.217.208/32",
    "identity": 6
  },
  {
    "cidr": "172.31.217.236/32",
    "identity": 6
  },
  {
    "cidr": "172.31.220.42/32",
    "identity": 6
  },
  {
    "cidr": "172.31.220.135/32",
    "identity": 6
  },
  {
    "cidr": "172.31.222.147/32",
    "identity": 6
  },
  {
    "cidr": "172.31.224.45/32",
    "identity": 6
  },
  {
    "cidr": "172.31.225.137/32",
    "identity": 6
  },
  {
    "cidr": "172.31.225.158/32",
    "identity": 6
  },
  {
    "cidr": "172.31.226.176/32",
    "identity": 6
  },
  {
    "cidr": "172.31.226.178/32",
    "identity": 6
  },
  {
    "cidr": "172.31.227.62/32",
    "identity": 6
  },
  {
    "cidr": "172.31.227.91/32",
    "identity": 6
  },
  {
    "cidr": "172.31.228.79/32",
    "identity": 6
  },
  {
    "cidr": "172.31.229.207/32",
    "identity": 6
  },
  {
    "cidr": "172.31.231.66/32",
    "identity": 6
  },
  {
    "cidr": "172.31.231.209/32",
    "identity": 6
  },
  {
    "cidr": "172.31.231.255/32",
    "identity": 6
  },
  {
    "cidr": "172.31.232.182/32",
    "identity": 1
  },
  {
    "cidr": "172.31.234.25/32",
    "identity": 6
  },
  {
    "cidr": "172.31.234.174/32",
    "identity": 6
  },
  {
    "cidr": "172.31.235.234/32",
    "identity": 6
  },
  {
    "cidr": "172.31.236.177/32",
    "identity": 6
  },
  {
    "cidr": "172.31.238.183/32",
    "identity": 6
  },
  {
    "cidr": "172.31.239.114/32",
    "identity": 6
  },
  {
    "cidr": "172.31.240.216/32",
    "identity": 6
  },
  {
    "cidr": "172.31.242.183/32",
    "identity": 6
  },
  {
    "cidr": "172.31.243.59/32",
    "identity": 6
  },
  {
    "cidr": "172.31.243.81/32",
    "identity": 16777218
  },
  {
    "cidr": "172.31.244.208/32",
    "identity": 6
  },
  {
    "cidr": "172.31.245.66/32",
    "identity": 6
  },
  {
    "cidr": "172.31.246.169/32",
    "identity": 6
  },
  {
    "cidr": "172.31.246.192/32",
    "identity": 6
  },
  {
    "cidr": "172.31.246.231/32",
    "identity": 6
  },
  {
    "cidr": "172.31.247.164/32",
    "identity": 6
  },
  {
    "cidr": "172.31.247.172/32",
    "identity": 6
  },
  {
    "cidr": "172.31.247.244/32",
    "identity": 6
  },
  {
    "cidr": "172.31.249.77/32",
    "identity": 6
  },
  {
    "cidr": "172.31.249.105/32",
    "identity": 6
  },
  {
    "cidr": "172.31.250.1/32",
    "identity": 6
  },
  {
    "cidr": "172.31.250.55/32",
    "identity": 6
  },
  {
    "cidr": "172.31.250.86/32",
    "identity": 6
  },
  {
    "cidr": "172.31.251.101/32",
    "identity": 6
  },
  {
    "cidr": "172.31.252.108/32",
    "identity": 1
  },
  {
    "cidr": "172.31.253.235/32",
    "identity": 6
  }
]

