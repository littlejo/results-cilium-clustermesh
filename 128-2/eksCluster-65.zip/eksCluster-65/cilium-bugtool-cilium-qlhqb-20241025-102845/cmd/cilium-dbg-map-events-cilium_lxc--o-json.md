{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:53.087Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.232.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:53.087Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.252.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:53.087Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:57.525Z",
  "value": "id=881   sec_id=4342590 flags=0x0000 ifindex=12  mac=72:38:A8:AC:62:02 nodemac=72:F6:1B:15:B6:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:57.549Z",
  "value": "id=2167  sec_id=4     flags=0x0000 ifindex=10  mac=26:FA:60:81:30:48 nodemac=06:77:C3:B7:F4:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:57.580Z",
  "value": "id=137   sec_id=4342590 flags=0x0000 ifindex=14  mac=22:B4:D4:98:F3:8A nodemac=4E:52:71:A8:EA:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:57.618Z",
  "value": "id=2167  sec_id=4     flags=0x0000 ifindex=10  mac=26:FA:60:81:30:48 nodemac=06:77:C3:B7:F4:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:30.898Z",
  "value": "id=2167  sec_id=4     flags=0x0000 ifindex=10  mac=26:FA:60:81:30:48 nodemac=06:77:C3:B7:F4:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:30.900Z",
  "value": "id=881   sec_id=4342590 flags=0x0000 ifindex=12  mac=72:38:A8:AC:62:02 nodemac=72:F6:1B:15:B6:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:30.900Z",
  "value": "id=137   sec_id=4342590 flags=0x0000 ifindex=14  mac=22:B4:D4:98:F3:8A nodemac=4E:52:71:A8:EA:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:30.928Z",
  "value": "id=401   sec_id=4381653 flags=0x0000 ifindex=16  mac=3A:E3:54:7E:AA:61 nodemac=9E:36:09:9A:64:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:31.899Z",
  "value": "id=401   sec_id=4381653 flags=0x0000 ifindex=16  mac=3A:E3:54:7E:AA:61 nodemac=9E:36:09:9A:64:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:31.900Z",
  "value": "id=881   sec_id=4342590 flags=0x0000 ifindex=12  mac=72:38:A8:AC:62:02 nodemac=72:F6:1B:15:B6:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:31.900Z",
  "value": "id=2167  sec_id=4     flags=0x0000 ifindex=10  mac=26:FA:60:81:30:48 nodemac=06:77:C3:B7:F4:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:31.900Z",
  "value": "id=137   sec_id=4342590 flags=0x0000 ifindex=14  mac=22:B4:D4:98:F3:8A nodemac=4E:52:71:A8:EA:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:43.864Z",
  "value": "id=1711  sec_id=4381653 flags=0x0000 ifindex=18  mac=12:20:C3:69:91:EC nodemac=5E:E3:D9:3A:D4:C7"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.65.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:54.158Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.877Z",
  "value": "id=137   sec_id=4342590 flags=0x0000 ifindex=14  mac=22:B4:D4:98:F3:8A nodemac=4E:52:71:A8:EA:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.877Z",
  "value": "id=1711  sec_id=4381653 flags=0x0000 ifindex=18  mac=12:20:C3:69:91:EC nodemac=5E:E3:D9:3A:D4:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.878Z",
  "value": "id=2167  sec_id=4     flags=0x0000 ifindex=10  mac=26:FA:60:81:30:48 nodemac=06:77:C3:B7:F4:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:52.878Z",
  "value": "id=881   sec_id=4342590 flags=0x0000 ifindex=12  mac=72:38:A8:AC:62:02 nodemac=72:F6:1B:15:B6:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.878Z",
  "value": "id=137   sec_id=4342590 flags=0x0000 ifindex=14  mac=22:B4:D4:98:F3:8A nodemac=4E:52:71:A8:EA:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.878Z",
  "value": "id=1711  sec_id=4381653 flags=0x0000 ifindex=18  mac=12:20:C3:69:91:EC nodemac=5E:E3:D9:3A:D4:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.878Z",
  "value": "id=881   sec_id=4342590 flags=0x0000 ifindex=12  mac=72:38:A8:AC:62:02 nodemac=72:F6:1B:15:B6:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:53.878Z",
  "value": "id=2167  sec_id=4     flags=0x0000 ifindex=10  mac=26:FA:60:81:30:48 nodemac=06:77:C3:B7:F4:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.879Z",
  "value": "id=2167  sec_id=4     flags=0x0000 ifindex=10  mac=26:FA:60:81:30:48 nodemac=06:77:C3:B7:F4:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.880Z",
  "value": "id=881   sec_id=4342590 flags=0x0000 ifindex=12  mac=72:38:A8:AC:62:02 nodemac=72:F6:1B:15:B6:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.880Z",
  "value": "id=137   sec_id=4342590 flags=0x0000 ifindex=14  mac=22:B4:D4:98:F3:8A nodemac=4E:52:71:A8:EA:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:54.880Z",
  "value": "id=1711  sec_id=4381653 flags=0x0000 ifindex=18  mac=12:20:C3:69:91:EC nodemac=5E:E3:D9:3A:D4:C7"
}

