ip-172-31-232-182.eu-west-3.compute.internal
