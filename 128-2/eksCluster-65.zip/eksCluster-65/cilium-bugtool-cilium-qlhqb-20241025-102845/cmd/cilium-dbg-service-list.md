ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.164.50:443 (active)     
                                         2 => 172.31.243.81:443 (active)     
2    10.100.64.16:443     ClusterIP      1 => 172.31.232.182:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.65.0.172:9153 (active)      
                                         2 => 10.65.0.215:9153 (active)      
4    10.100.0.10:53       ClusterIP      1 => 10.65.0.172:53 (active)        
                                         2 => 10.65.0.215:53 (active)        
5    10.100.157.69:2379   ClusterIP      1 => 10.65.0.160:2379 (active)      
