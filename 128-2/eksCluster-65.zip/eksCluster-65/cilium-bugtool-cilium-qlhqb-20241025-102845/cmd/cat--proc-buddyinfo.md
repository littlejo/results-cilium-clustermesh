Node 0, zone      DMA      2      3      1      8      2      5      4      1      2      2    163 
Node 0, zone   Normal     43      2      7      6      2      1      1      4      7      2      7 
