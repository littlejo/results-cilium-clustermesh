alloc: 131.44MB (137823896 bytes)
total-alloc: 1.34GB (1442382192 bytes)
sys: 218.38MB (228992340 bytes)
lookups: 0
mallocs: 47998916
frees: 46663506
heap-alloc: 131.44MB (137823896 bytes)
heap-sys: 171.08MB (179388416 bytes)
heap-idle: 23.03MB (24150016 bytes)
heap-in-use: 148.05MB (155238400 bytes)
heap-released: 10.74MB (11264000 bytes)
heap-objects: 1335410
stack-in-use: 36.66MB (38436864 bytes)
stack-sys: 36.66MB (38436864 bytes)
stack-mspan-inuse: 2.32MB (2434080 bytes)
stack-mspan-sys: 2.38MB (2496960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1003.51KB (1027593 bytes)
gc-sys: 5.39MB (5648616 bytes)
next-gc: when heap-alloc >= 143.61MB (150583592 bytes)
last-gc: 2024-10-25 10:28:42.353745444 +0000 UTC
gc-pause-total: 19.720391ms
gc-pause: 82643
gc-pause-end: 1729852122353745444
num-gc: 71
num-forced-gc: 0
gc-cpu-fraction: 0.0003576575331775425
enable-gc: true
debug-gc: false
