IP ADDRESS         LOCAL ENDPOINT INFO
172.31.252.108:0   (localhost)                                                                                        
10.65.0.135:0      (localhost)                                                                                        
10.65.0.160:0      id=1711  sec_id=4381653 flags=0x0000 ifindex=18  mac=12:20:C3:69:91:EC nodemac=5E:E3:D9:3A:D4:C7   
10.65.0.128:0      id=2167  sec_id=4     flags=0x0000 ifindex=10  mac=26:FA:60:81:30:48 nodemac=06:77:C3:B7:F4:7D     
172.31.232.182:0   (localhost)                                                                                        
10.65.0.215:0      id=881   sec_id=4342590 flags=0x0000 ifindex=12  mac=72:38:A8:AC:62:02 nodemac=72:F6:1B:15:B6:E1   
10.65.0.172:0      id=137   sec_id=4342590 flags=0x0000 ifindex=14  mac=22:B4:D4:98:F3:8A nodemac=4E:52:71:A8:EA:8D   
