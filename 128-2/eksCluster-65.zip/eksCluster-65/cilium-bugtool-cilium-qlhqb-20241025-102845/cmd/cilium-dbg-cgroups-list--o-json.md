[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6f98ab9_5dad_42e9_bb8e_224d887759d5.slice/cri-containerd-33a01ca54f3ece959b18dfc0883a68a3226214bdf8cb3cde51ec9daaa1b4377f.scope"
      }
    ],
    "ips": [
      "10.65.0.215"
    ],
    "name": "coredns-cc6ccd49c-kslc2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0ba74476_bd66_4f5c_8c67_4d5c2cb6cb66.slice/cri-containerd-ad7f2d4fd6f9142ec5a2e43f51ee58443593270c67afbe64f9c3c36311b35208.scope"
      }
    ],
    "ips": [
      "10.65.0.172"
    ],
    "name": "coredns-cc6ccd49c-h5zcm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb2f104f_90d4_47e9_ad62_79273aabae53.slice/cri-containerd-1b2b55ef025bfb1fa36f1bdefa114a95444a11a739b1edcd4ae1e651fcafbec3.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb2f104f_90d4_47e9_ad62_79273aabae53.slice/cri-containerd-c38220d36d4c6ca5200a49ffa01ec297c0a5b36bb12fe341281c154103307984.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb2f104f_90d4_47e9_ad62_79273aabae53.slice/cri-containerd-c25013415ed547cb3aecbe8ca30029a60a2a08ac9333d56cfd0d933b8ddf6e3a.scope"
      }
    ],
    "ips": [
      "10.65.0.160"
    ],
    "name": "clustermesh-apiserver-6b69cb88b8-7pcwc",
    "namespace": "kube-system"
  }
]

