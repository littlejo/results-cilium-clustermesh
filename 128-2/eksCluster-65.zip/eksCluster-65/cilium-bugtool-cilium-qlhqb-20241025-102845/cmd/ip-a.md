1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:a6:73:94:1b:87 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.232.182/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2741sec preferred_lft 2741sec
    inet6 fe80::8a6:73ff:fe94:1b87/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:6f:e4:bf:8c:41 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.252.108/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::86f:e4ff:febf:8c41/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:fd:08:b8:ce:2b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3cfd:8ff:feb8:ce2b/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:9f:c3:05:1e:59 brd ff:ff:ff:ff:ff:ff
    inet 10.65.0.135/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::209f:c3ff:fe05:1e59/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether e6:28:9b:a1:ef:40 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e428:9bff:fea1:ef40/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:77:c3:b7:f4:7d brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::477:c3ff:feb7:f47d/64 scope link 
       valid_lft forever preferred_lft forever
12: lxca0e21a53546e@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:f6:1b:15:b6:e1 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::70f6:1bff:fe15:b6e1/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc0b4436dc98f1@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:52:71:a8:ea:8d brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::4c52:71ff:fea8:ea8d/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc35e69ae6e70e@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:e3:d9:3a:d4:c7 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::5ce3:d9ff:fe3a:d4c7/64 scope link 
       valid_lft forever preferred_lft forever
