32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:22+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:22+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:14:22+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:14:23+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:14:37+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name tail_handle_ipv4  tag 5cd98dd21abc8a6c  gpl
	loaded_at 2024-10-25T10:15:55+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
482: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:15:55+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
483: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:15:55+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:15:55+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
513: sched_cls  name __send_drop_notify  tag 5a1113edea0c545b  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 162
514: sched_cls  name cil_from_container  tag a94067ce6c2d9643  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 164
515: sched_cls  name tail_handle_arp  tag c436a022034614f2  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 165
517: sched_cls  name tail_ipv4_to_endpoint  tag 45e4ddebbf33a454  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,111,40,37,38
	btf_id 166
519: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 168
521: sched_cls  name tail_ipv4_ct_egress  tag 344800148a042589  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,113,84
	btf_id 170
524: sched_cls  name handle_policy  tag c8688c5019cf93c4  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 172
527: sched_cls  name tail_ipv4_ct_ingress  tag 52ef5f8b0d15fe4a  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,113,84
	btf_id 175
529: sched_cls  name tail_handle_ipv4  tag 7455afbf6b04fa07  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 178
530: sched_cls  name tail_handle_ipv4_cont  tag fc7c65b1e6382af9  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,111,40,37,38,81
	btf_id 179
533: sched_cls  name tail_handle_ipv4  tag 0badc9dae8e21459  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 182
534: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 185
535: sched_cls  name cil_from_container  tag ecb6d305fe858bf9  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 186
536: sched_cls  name tail_ipv4_ct_ingress  tag 2c3ad542628e8a93  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 187
537: sched_cls  name __send_drop_notify  tag 6dacbec2b6b6e1b0  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 188
541: sched_cls  name tail_handle_ipv4_from_host  tag dcb28afa21292cb6  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 193
542: sched_cls  name handle_policy  tag 71f6ac2a2093cbab  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 190
543: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 194
544: sched_cls  name tail_handle_arp  tag 24513c08ff89c3ad  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 195
546: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 76,75,118
	btf_id 198
548: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 200
549: sched_cls  name __send_drop_notify  tag 48669f5478fdd047  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
552: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 205
553: sched_cls  name __send_drop_notify  tag 48669f5478fdd047  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 206
554: sched_cls  name tail_ipv4_to_endpoint  tag 898e44634f779598  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 197
555: sched_cls  name tail_handle_ipv4_from_host  tag dcb28afa21292cb6  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 207
556: sched_cls  name tail_ipv4_ct_egress  tag 344800148a042589  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 208
557: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 209
559: sched_cls  name tail_handle_ipv4_cont  tag 4404ed6d158798ee  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 211
561: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 215
562: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 217
566: sched_cls  name __send_drop_notify  tag 48669f5478fdd047  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 221
567: sched_cls  name tail_ipv4_ct_ingress  tag 13c55c1b5e1521d5  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,123,82,83,124,84
	btf_id 216
568: sched_cls  name tail_handle_ipv4_from_host  tag dcb28afa21292cb6  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 222
572: sched_cls  name __send_drop_notify  tag 48669f5478fdd047  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 228
573: sched_cls  name tail_handle_ipv4_from_host  tag dcb28afa21292cb6  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,125
	btf_id 229
574: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,125
	btf_id 230
575: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,125,75
	btf_id 231
576: sched_cls  name handle_policy  tag 910df56bda832fd0  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,123,82,83,124,41,80,100,39,84,75,40,37,38
	btf_id 223
577: sched_cls  name __send_drop_notify  tag b0241ea3948dc552  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 232
578: sched_cls  name tail_handle_arp  tag 02223a7f71bab239  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,123
	btf_id 233
579: sched_cls  name tail_ipv4_to_endpoint  tag 29aa4570ef911d9e  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,124,41,82,83,80,100,39,123,40,37,38
	btf_id 234
580: sched_cls  name tail_handle_ipv4_cont  tag fc0ac17174fa4044  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 75,124,41,100,82,83,39,76,74,77,123,40,37,38,81
	btf_id 235
581: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,123,82,83,124,84
	btf_id 236
582: sched_cls  name cil_from_container  tag 1b981bda73d1e81b  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 123,76
	btf_id 237
583: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,123
	btf_id 238
584: sched_cls  name tail_handle_ipv4  tag 650ef93cc3def2ed  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,123
	btf_id 239
585: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
588: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
589: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
592: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
593: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
596: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:15:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: sched_cls  name tail_ipv4_ct_egress  tag 2e76135c7f725358  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 253
641: sched_cls  name handle_policy  tag 358c8734ef7994ec  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,142,82,83,143,41,80,141,39,84,75,40,37,38
	btf_id 254
642: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,142
	btf_id 255
643: sched_cls  name tail_handle_ipv4  tag 9801efd667ee317c  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,142
	btf_id 256
644: sched_cls  name __send_drop_notify  tag d9939799dc8fae57  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 257
645: sched_cls  name cil_from_container  tag da45c4f590f6685a  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 142,76
	btf_id 258
646: sched_cls  name tail_handle_ipv4_cont  tag 7ce7cfb81558ecd4  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 75,143,41,141,82,83,39,76,74,77,142,40,37,38,81
	btf_id 259
647: sched_cls  name tail_handle_arp  tag ec9b903f04785caa  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,142
	btf_id 260
648: sched_cls  name tail_ipv4_to_endpoint  tag 208e5990c53a86da  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,143,41,82,83,80,141,39,142,40,37,38
	btf_id 261
649: sched_cls  name tail_ipv4_ct_ingress  tag 867648c2cc82b76d  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 262
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
667: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
670: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
671: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
674: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
675: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
678: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
