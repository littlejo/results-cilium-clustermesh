USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         666  0.0  0.2 1616264 8744 ?        Ssl  10:28   0:00 /usr/sbin/runc init
root         634  0.0  0.0 1228744 3596 ?        Ssl  10:28   0:00 /bin/gops memstats 1
root         624  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops pprof-heap 1
root         616  0.0  0.4 1240432 16428 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         673  0.0  0.0   6408  1648 ?        R    10:28   0:00  \_ ps auxfw
root         674  0.0  0.0   3852  1276 ?        R    10:28   0:00  \_ bash -c hostname
root         595  0.0  0.0 1228744 3600 ?        Ssl  10:28   0:00 /bin/gops pprof-cpu 1
root           1  2.5  6.9 1538100 273584 ?      Ssl  10:15   0:19 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.0  0.1 1228848 6652 ?        Sl   10:15   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
