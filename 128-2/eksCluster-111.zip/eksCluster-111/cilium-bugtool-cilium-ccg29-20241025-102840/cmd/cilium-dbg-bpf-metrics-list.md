REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     10130     793568     677    bpf_overlay.c
Interface                 INGRESS     218537    85559714   1132   bpf_host.c
Success                   EGRESS      10301     806128     53     encap.h
Success                   EGRESS      5273      405248     1694   bpf_host.c
Success                   EGRESS      92766     12177014   1308   bpf_lxc.c
Success                   INGRESS     102428    12703693   86     l3.h
Success                   INGRESS     107934    13135919   235    trace.h
Unsupported L3 protocol   EGRESS      42        3188       1492   bpf_lxc.c
