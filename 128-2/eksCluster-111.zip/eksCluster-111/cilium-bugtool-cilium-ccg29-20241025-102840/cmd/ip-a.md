1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:9c:f5:96:70:9d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.227.62/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2721sec preferred_lft 2721sec
    inet6 fe80::89c:f5ff:fe96:709d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:25:3a:b0:5b:f1 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.203.93/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::825:3aff:feb0:5bf1/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:c8:b0:80:35:f8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::30c8:b0ff:fe80:35f8/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:ff:88:db:b8:95 brd ff:ff:ff:ff:ff:ff
    inet 10.111.0.43/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d8ff:88ff:fedb:b895/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 96:f4:46:82:58:ef brd ff:ff:ff:ff:ff:ff
    inet6 fe80::94f4:46ff:fe82:58ef/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:fa:6c:01:d0:7e brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::f4fa:6cff:fe01:d07e/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcd2ebe7d793fc@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:1d:ba:6b:50:90 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::541d:baff:fe6b:5090/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc6b15c366c19f@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:27:d7:56:4b:a2 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::7827:d7ff:fe56:4ba2/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc41531ff7e349@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:59:1e:2a:69:37 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::9859:1eff:fe2a:6937/64 scope link 
       valid_lft forever preferred_lft forever
