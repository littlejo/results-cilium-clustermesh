IP ADDRESS        LOCAL ENDPOINT INFO
172.31.227.62:0   (localhost)                                                                                        
10.111.0.77:0     id=299   sec_id=7379824 flags=0x0000 ifindex=12  mac=5A:25:0D:E0:63:EE nodemac=56:1D:BA:6B:50:90   
10.111.0.43:0     (localhost)                                                                                        
10.111.0.105:0    id=2707  sec_id=4     flags=0x0000 ifindex=10  mac=2E:46:DC:AF:0E:9D nodemac=F6:FA:6C:01:D0:7E     
10.111.0.162:0    id=2339  sec_id=7379824 flags=0x0000 ifindex=14  mac=36:3D:DB:C1:01:08 nodemac=7A:27:D7:56:4B:A2   
172.31.203.93:0   (localhost)                                                                                        
10.111.0.79:0     id=985   sec_id=7398745 flags=0x0000 ifindex=18  mac=9E:32:CD:4C:E9:8E nodemac=9A:59:1E:2A:69:37   
