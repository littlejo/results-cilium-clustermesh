{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:05.469Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.203.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:05.469Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.227.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:05.469Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:09.973Z",
  "value": "id=2707  sec_id=4     flags=0x0000 ifindex=10  mac=2E:46:DC:AF:0E:9D nodemac=F6:FA:6C:01:D0:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:09.978Z",
  "value": "id=299   sec_id=7379824 flags=0x0000 ifindex=12  mac=5A:25:0D:E0:63:EE nodemac=56:1D:BA:6B:50:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:10.018Z",
  "value": "id=2707  sec_id=4     flags=0x0000 ifindex=10  mac=2E:46:DC:AF:0E:9D nodemac=F6:FA:6C:01:D0:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:10.065Z",
  "value": "id=299   sec_id=7379824 flags=0x0000 ifindex=12  mac=5A:25:0D:E0:63:EE nodemac=56:1D:BA:6B:50:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:17.360Z",
  "value": "id=2339  sec_id=7379824 flags=0x0000 ifindex=14  mac=36:3D:DB:C1:01:08 nodemac=7A:27:D7:56:4B:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:59.936Z",
  "value": "id=2707  sec_id=4     flags=0x0000 ifindex=10  mac=2E:46:DC:AF:0E:9D nodemac=F6:FA:6C:01:D0:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:59.937Z",
  "value": "id=299   sec_id=7379824 flags=0x0000 ifindex=12  mac=5A:25:0D:E0:63:EE nodemac=56:1D:BA:6B:50:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:59.938Z",
  "value": "id=2339  sec_id=7379824 flags=0x0000 ifindex=14  mac=36:3D:DB:C1:01:08 nodemac=7A:27:D7:56:4B:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:59.969Z",
  "value": "id=753   sec_id=7398745 flags=0x0000 ifindex=16  mac=52:76:C3:D6:E9:45 nodemac=B2:5C:9D:8C:F6:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:00.936Z",
  "value": "id=2339  sec_id=7379824 flags=0x0000 ifindex=14  mac=36:3D:DB:C1:01:08 nodemac=7A:27:D7:56:4B:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:00.936Z",
  "value": "id=753   sec_id=7398745 flags=0x0000 ifindex=16  mac=52:76:C3:D6:E9:45 nodemac=B2:5C:9D:8C:F6:02"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:00.936Z",
  "value": "id=2707  sec_id=4     flags=0x0000 ifindex=10  mac=2E:46:DC:AF:0E:9D nodemac=F6:FA:6C:01:D0:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:00.936Z",
  "value": "id=299   sec_id=7379824 flags=0x0000 ifindex=12  mac=5A:25:0D:E0:63:EE nodemac=56:1D:BA:6B:50:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:42.639Z",
  "value": "id=985   sec_id=7398745 flags=0x0000 ifindex=18  mac=9E:32:CD:4C:E9:8E nodemac=9A:59:1E:2A:69:37"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.111.0.212:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:47.935Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:56.853Z",
  "value": "id=2339  sec_id=7379824 flags=0x0000 ifindex=14  mac=36:3D:DB:C1:01:08 nodemac=7A:27:D7:56:4B:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:56.853Z",
  "value": "id=985   sec_id=7398745 flags=0x0000 ifindex=18  mac=9E:32:CD:4C:E9:8E nodemac=9A:59:1E:2A:69:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:56.854Z",
  "value": "id=2707  sec_id=4     flags=0x0000 ifindex=10  mac=2E:46:DC:AF:0E:9D nodemac=F6:FA:6C:01:D0:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:56.855Z",
  "value": "id=299   sec_id=7379824 flags=0x0000 ifindex=12  mac=5A:25:0D:E0:63:EE nodemac=56:1D:BA:6B:50:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.853Z",
  "value": "id=2339  sec_id=7379824 flags=0x0000 ifindex=14  mac=36:3D:DB:C1:01:08 nodemac=7A:27:D7:56:4B:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.854Z",
  "value": "id=985   sec_id=7398745 flags=0x0000 ifindex=18  mac=9E:32:CD:4C:E9:8E nodemac=9A:59:1E:2A:69:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.854Z",
  "value": "id=299   sec_id=7379824 flags=0x0000 ifindex=12  mac=5A:25:0D:E0:63:EE nodemac=56:1D:BA:6B:50:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:57.855Z",
  "value": "id=2707  sec_id=4     flags=0x0000 ifindex=10  mac=2E:46:DC:AF:0E:9D nodemac=F6:FA:6C:01:D0:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:58.854Z",
  "value": "id=985   sec_id=7398745 flags=0x0000 ifindex=18  mac=9E:32:CD:4C:E9:8E nodemac=9A:59:1E:2A:69:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:58.854Z",
  "value": "id=2707  sec_id=4     flags=0x0000 ifindex=10  mac=2E:46:DC:AF:0E:9D nodemac=F6:FA:6C:01:D0:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:58.855Z",
  "value": "id=299   sec_id=7379824 flags=0x0000 ifindex=12  mac=5A:25:0D:E0:63:EE nodemac=56:1D:BA:6B:50:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.111.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:58.855Z",
  "value": "id=2339  sec_id=7379824 flags=0x0000 ifindex=14  mac=36:3D:DB:C1:01:08 nodemac=7A:27:D7:56:4B:A2"
}

