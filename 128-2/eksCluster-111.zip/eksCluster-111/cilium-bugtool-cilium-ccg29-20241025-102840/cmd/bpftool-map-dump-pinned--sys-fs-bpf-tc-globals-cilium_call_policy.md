key: 2b 01 00 00  value: 08 02 00 00
key: d9 03 00 00  value: 6d 02 00 00
key: 23 09 00 00  value: 39 02 00 00
key: 93 0a 00 00  value: f8 01 00 00
Found 4 elements
