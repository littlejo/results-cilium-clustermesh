Node 0, zone      DMA    152    104     19     15      6      6      5      3      7      6    166 
Node 0, zone   Normal    663    127     36     37     15      6      4      0      0      1      8 
