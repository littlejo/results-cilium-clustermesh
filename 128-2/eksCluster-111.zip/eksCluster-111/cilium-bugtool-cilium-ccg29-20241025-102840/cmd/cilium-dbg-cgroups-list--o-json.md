[
  {
    "containers": [
      {
        "cgroup-id": 7530,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod536ab4ed_1d39_46af_b615_06e12d4d985b.slice/cri-containerd-2f91a09e37cfddb6dc10839c6b7d13b43cc6ec3c44ebe7f0b0b5708a5e06230d.scope"
      }
    ],
    "ips": [
      "10.111.0.77"
    ],
    "name": "coredns-cc6ccd49c-qxzrx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ac90601_d103_4504_9dce_e126a7d97018.slice/cri-containerd-33ed833814503ee9c15a035f680f2ffd9808070107b0b4112265bbbf65dc829e.scope"
      }
    ],
    "ips": [
      "10.111.0.162"
    ],
    "name": "coredns-cc6ccd49c-bxvtl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd76a5eb4_0370_4315_9212_3978a353f06e.slice/cri-containerd-ca300276b5a99594a8a57bc677ed820729e83a09a8424abdd3ba23951241aa52.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd76a5eb4_0370_4315_9212_3978a353f06e.slice/cri-containerd-4dfd2b638825470869242d51d6407a8a383dcf54da827f2e92f457683e797799.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd76a5eb4_0370_4315_9212_3978a353f06e.slice/cri-containerd-9d5cad61941a0d02b3b902624e262a8b7fc845cca8fda7ad1a00c7e826d93698.scope"
      }
    ],
    "ips": [
      "10.111.0.79"
    ],
    "name": "clustermesh-apiserver-d57dbc4f-plm5h",
    "namespace": "kube-system"
  }
]

