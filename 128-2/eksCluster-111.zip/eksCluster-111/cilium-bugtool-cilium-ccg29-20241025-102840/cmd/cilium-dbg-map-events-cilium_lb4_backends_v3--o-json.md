{
  "action": "update",
  "desired-action": "sync",
  "key": "1",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:02.241Z",
  "value": "ANY://172.31.133.198"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "2",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:02.241Z",
  "value": "ANY://172.31.234.95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:02.241Z",
  "value": "ANY://172.31.233.66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:02.241Z",
  "value": "ANY://172.31.202.241"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "5",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:02.241Z",
  "value": "ANY://172.31.233.66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "6",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:02.241Z",
  "value": "ANY://172.31.202.241"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "7",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:07.075Z",
  "value": "ANY://172.31.227.62"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "5",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:07.142Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:07.142Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:10.647Z",
  "value": "ANY://10.111.0.77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "9",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:10.647Z",
  "value": "ANY://10.111.0.77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "6",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:16.820Z",
  "value": "ANY://172.31.202.241"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:16.820Z",
  "value": "ANY://172.31.202.241"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:18.644Z",
  "value": "ANY://10.111.0.162"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "11",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:18.645Z",
  "value": "ANY://10.111.0.162"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:22.055Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "6",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:22.055Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "12",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:16:10.717Z",
  "value": "ANY://10.111.0.212"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "13",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:47.413Z",
  "value": "ANY://10.111.0.79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "12",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:47.505Z",
  "value": "ANY://10.111.0.212"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "12",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:48.021Z",
  "value": "\u003cnil\u003e"
}

