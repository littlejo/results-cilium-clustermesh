top - 10:28:42 up 14 min,  0 users,  load average: 0.19, 0.21, 0.18
Tasks:   8 total,   2 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 40.6 us, 25.0 sy,  0.0 ni, 31.2 id,  0.0 wa,  0.0 hi,  3.1 si,  0.0 st
MiB Mem :   3836.2 total,    777.7 free,    915.9 used,   2142.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2751.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    664 root      20   0 1240432  16536  11356 S  13.3   0.4   0:00.03 cilium-+
      1 root      20   0 1538100 283092  78492 S   6.7   7.2   0:24.77 cilium-+
    417 root      20   0 1228848   5836   2928 S   0.0   0.1   0:00.27 cilium-+
    678 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
    726 root      20   0    6576   2408   2084 R   0.0   0.1   0:00.00 top
    745 root      20   0 1228744   3712   3040 S   0.0   0.1   0:00.00 gops
    756 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    762 root      20   0 1242420  12904  10880 R   0.0   0.3   0:00.00 hubble
