CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1f8bafae_d940_4dfd_ad88_0ace2820458d.slice/cri-containerd-b496c624a728eccee6610a1c994828be4cc6884fbea69c491ecf2a0e518275e4.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1f8bafae_d940_4dfd_ad88_0ace2820458d.slice/cri-containerd-88ac10f65784776afd381cef281074bc3502eda84410ce81a3c1e5471adf91af.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ac90601_d103_4504_9dce_e126a7d97018.slice/cri-containerd-33ed833814503ee9c15a035f680f2ffd9808070107b0b4112265bbbf65dc829e.scope
    580      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6ac90601_d103_4504_9dce_e126a7d97018.slice/cri-containerd-c339354e98ae07dff7adf788b73c63f4097e2ee924a25d0611348138bdf519a4.scope
    576      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfec74caf_891f_4091_8cbb_1e3525c32068.slice/cri-containerd-e47fcd747539d25785df073276954707ab14b934b2be26a072917ab077212fba.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfec74caf_891f_4091_8cbb_1e3525c32068.slice/cri-containerd-d9ee535ffd4ebeff93038886e3166dcf1be0fa5e65f61d298bae3802d3e29005.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod536ab4ed_1d39_46af_b615_06e12d4d985b.slice/cri-containerd-2f91a09e37cfddb6dc10839c6b7d13b43cc6ec3c44ebe7f0b0b5708a5e06230d.scope
    533      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod536ab4ed_1d39_46af_b615_06e12d4d985b.slice/cri-containerd-ffa4a3b2703f65985f9a8ad73fa66db588eb10e4ebf8e2bd07d6c918aab7b693.scope
    529      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5e146e8f_329c_42c8_bf6f_9a67ba40c3fd.slice/cri-containerd-faec60f642336c9060c59954fdd138c80c5953c007d502b3154768f59df1ae5b.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5e146e8f_329c_42c8_bf6f_9a67ba40c3fd.slice/cri-containerd-833b15aa3bba77b7c08b1b7bd5dfab50247a7902e291e29970860e830d452992.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd76a5eb4_0370_4315_9212_3978a353f06e.slice/cri-containerd-41d6a57e823d21079c82fa40aba526cc7c2d8535e4ab37df511efe8b6144bc23.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd76a5eb4_0370_4315_9212_3978a353f06e.slice/cri-containerd-9d5cad61941a0d02b3b902624e262a8b7fc845cca8fda7ad1a00c7e826d93698.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd76a5eb4_0370_4315_9212_3978a353f06e.slice/cri-containerd-ca300276b5a99594a8a57bc677ed820729e83a09a8424abdd3ba23951241aa52.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd76a5eb4_0370_4315_9212_3978a353f06e.slice/cri-containerd-4dfd2b638825470869242d51d6407a8a383dcf54da827f2e92f457683e797799.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod408bf55b_3287_4a8d_897a_6d1b59e7aee0.slice/cri-containerd-d2b185757c747d7d70c09978604c90a64d75114f4125bc2b1067237d42826ae4.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod408bf55b_3287_4a8d_897a_6d1b59e7aee0.slice/cri-containerd-7e341a90b96c84bf49d024bb14acb3df341d2bcd6c7df33c89c27f8280671dc4.scope
    95       cgroup_device   multi                                          
