markdown output at /tmp/cilium-bugtool-20241025-102841.838+0000-UTC-2572870216/cmd/cilium-debuginfo-20241025-102912.35+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102841.838+0000-UTC-2572870216/cmd/cilium-debuginfo-20241025-102912.35+0000-UTC.json
