alloc: 87.47MB (91720016 bytes)
total-alloc: 1.34GB (1442457640 bytes)
sys: 210.38MB (220603732 bytes)
lookups: 0
mallocs: 47970168
frees: 47179062
heap-alloc: 87.47MB (91720016 bytes)
heap-sys: 165.29MB (173318144 bytes)
heap-idle: 46.34MB (48594944 bytes)
heap-in-use: 118.95MB (124723200 bytes)
heap-released: 3.87MB (4055040 bytes)
heap-objects: 791106
stack-in-use: 34.69MB (36372480 bytes)
stack-sys: 34.69MB (36372480 bytes)
stack-mspan-inuse: 1.98MB (2080320 bytes)
stack-mspan-sys: 2.54MB (2660160 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 835.99KB (856049 bytes)
gc-sys: 5.14MB (5386424 bytes)
next-gc: when heap-alloc >= 146.03MB (153120328 bytes)
last-gc: 2024-10-25 10:28:54.489393041 +0000 UTC
gc-pause-total: 9.172731ms
gc-pause: 66052
gc-pause-end: 1729852134489393041
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.0003521572291467825
enable-gc: true
debug-gc: false
