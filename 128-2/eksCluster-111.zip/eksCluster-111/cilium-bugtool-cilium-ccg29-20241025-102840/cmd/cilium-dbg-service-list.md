ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.133.198:443 (active)   
                                          2 => 172.31.234.95:443 (active)    
2    10.100.45.9:443       ClusterIP      1 => 172.31.227.62:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.111.0.77:9153 (active)     
                                          2 => 10.111.0.162:9153 (active)    
4    10.100.0.10:53        ClusterIP      1 => 10.111.0.77:53 (active)       
                                          2 => 10.111.0.162:53 (active)      
5    10.100.243.155:2379   ClusterIP      1 => 10.111.0.79:2379 (active)     
