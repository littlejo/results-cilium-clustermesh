Endpoint ID: 299
Path: /sys/fs/bpf/tc/globals/cilium_policy_00299

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    79275   911       0        
Allow    Egress      0          ANY          NONE         disabled    14083   148       0        


Endpoint ID: 809
Path: /sys/fs/bpf/tc/globals/cilium_policy_00809

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 985
Path: /sys/fs/bpf/tc/globals/cilium_policy_00985

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3820886   36291     0        
Allow    Ingress     1          ANY          NONE         disabled    3023872   30404     0        
Allow    Egress      0          ANY          NONE         disabled    4967645   45753     0        


Endpoint ID: 2339
Path: /sys/fs/bpf/tc/globals/cilium_policy_02339

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    78726   902       0        
Allow    Egress      0          ANY          NONE         disabled    12689   130       0        


Endpoint ID: 2707
Path: /sys/fs/bpf/tc/globals/cilium_policy_02707

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    433488   5522      0        
Allow    Ingress     1          ANY          NONE         disabled    12076    140       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


