KEY             VALUE
AgentLiveness   920031065892
UTimeOffset     3378615687500000
