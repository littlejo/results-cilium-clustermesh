IP ADDRESS        LOCAL ENDPOINT INFO
10.99.0.170:0     id=3741  sec_id=4     flags=0x0000 ifindex=7   mac=22:16:6F:E0:0F:11 nodemac=92:EC:EF:97:F4:BF     
10.99.0.183:0     id=1346  sec_id=6564329 flags=0x0000 ifindex=15  mac=FA:E6:60:19:00:2B nodemac=92:DA:B4:38:E3:75   
172.31.201.30:0   (localhost)                                                                                        
10.99.0.181:0     id=27    sec_id=6572220 flags=0x0000 ifindex=9   mac=46:D2:D4:DD:5B:75 nodemac=92:68:A1:54:3B:1D   
10.99.0.78:0      (localhost)                                                                                        
10.99.0.119:0     id=1927  sec_id=6572220 flags=0x0000 ifindex=11  mac=02:00:E1:9A:B9:09 nodemac=A2:9F:F1:4E:A8:1D   
