alloc: 76.94MB (80678752 bytes)
total-alloc: 1.34GB (1443089424 bytes)
sys: 222.38MB (233186644 bytes)
lookups: 0
mallocs: 48117581
frees: 47479895
heap-alloc: 76.94MB (80678752 bytes)
heap-sys: 177.60MB (186228736 bytes)
heap-idle: 63.13MB (66199552 bytes)
heap-in-use: 114.47MB (120029184 bytes)
heap-released: 11.88MB (12451840 bytes)
heap-objects: 637686
stack-in-use: 34.38MB (36044800 bytes)
stack-sys: 34.38MB (36044800 bytes)
stack-mspan-inuse: 1.91MB (2006880 bytes)
stack-mspan-sys: 2.43MB (2545920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 923.42KB (945585 bytes)
gc-sys: 5.17MB (5421384 bytes)
next-gc: when heap-alloc >= 146.30MB (153404376 bytes)
last-gc: 2024-10-25 10:29:10.65985823 +0000 UTC
gc-pause-total: 19.691977ms
gc-pause: 80164
gc-pause-end: 1729852150659858230
num-gc: 73
num-forced-gc: 0
gc-cpu-fraction: 0.00039673483466056656
enable-gc: true
debug-gc: false
