32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:16:24+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:16:24+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:16:24+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:16:24+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:16:24+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:16:25+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:16:25+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:16:25+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:16:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:16:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:16:25+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:16:25+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:16:29+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:16:40+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
64: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
67: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
68: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
71: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
72: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
75: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:16:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:16:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
107: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
110: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
451: sched_cls  name tail_handle_ipv4  tag e843a8588e722f89  gpl
	loaded_at 2024-10-25T10:17:23+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 69,68,75,70,91
	btf_id 113
452: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:17:23+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 70,91
	btf_id 114
453: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:17:23+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 115
454: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:17:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 116
477: sched_cls  name tail_ipv4_ct_ingress  tag fc51965a0c4007a1  gpl
	loaded_at 2024-10-25T10:17:25+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,100,76,77,99,78
	btf_id 142
478: sched_cls  name tail_handle_arp  tag 290181de6047c2ad  gpl
	loaded_at 2024-10-25T10:17:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,100
	btf_id 143
479: sched_cls  name tail_ipv4_to_endpoint  tag 4862e02189cc9ef1  gpl
	loaded_at 2024-10-25T10:17:25+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,99,35,76,77,74,98,33,100,34,31,32
	btf_id 144
480: sched_cls  name handle_policy  tag 0d1c5b97786410b1  gpl
	loaded_at 2024-10-25T10:17:25+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,100,76,77,99,35,74,98,33,78,69,34,31,32
	btf_id 145
481: sched_cls  name tail_handle_ipv4  tag abb09f4627633fa3  gpl
	loaded_at 2024-10-25T10:17:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,100
	btf_id 146
482: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:17:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,100
	btf_id 147
483: sched_cls  name __send_drop_notify  tag 55e7c7fff28f58cc  gpl
	loaded_at 2024-10-25T10:17:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 148
485: sched_cls  name tail_ipv4_ct_egress  tag cfe38d259d0c8170  gpl
	loaded_at 2024-10-25T10:17:25+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,100,76,77,99,78
	btf_id 150
486: sched_cls  name tail_handle_ipv4_cont  tag 5893290280186562  gpl
	loaded_at 2024-10-25T10:17:25+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,99,35,98,76,77,33,70,68,71,100,34,31,32,75
	btf_id 151
487: sched_cls  name cil_from_container  tag 70ba3f605ecc9d98  gpl
	loaded_at 2024-10-25T10:17:25+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 100,70
	btf_id 152
488: sched_cls  name tail_handle_ipv4  tag 3381b0a61f83296e  gpl
	loaded_at 2024-10-25T10:17:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,102
	btf_id 154
490: sched_cls  name tail_ipv4_ct_ingress  tag a7b1a5673f916b58  gpl
	loaded_at 2024-10-25T10:17:25+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,102,76,77,101,78
	btf_id 156
491: sched_cls  name cil_from_container  tag 92d68c2c3d0bbbcb  gpl
	loaded_at 2024-10-25T10:17:25+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 102,70
	btf_id 157
492: sched_cls  name tail_ipv4_to_endpoint  tag 0c477260fe76eaec  gpl
	loaded_at 2024-10-25T10:17:25+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,101,35,76,77,74,92,33,102,34,31,32
	btf_id 158
493: sched_cls  name handle_policy  tag be2e7fe9eb1aa1e2  gpl
	loaded_at 2024-10-25T10:17:25+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,102,76,77,101,35,74,92,33,78,69,34,31,32
	btf_id 159
494: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:17:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,102
	btf_id 160
495: sched_cls  name __send_drop_notify  tag d703cef9f182f971  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 161
496: sched_cls  name tail_handle_arp  tag c877f042e2ddc50a  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,102
	btf_id 162
497: sched_cls  name tail_handle_ipv4_cont  tag 6a8b7f81f77984ae  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,101,35,92,76,77,33,70,68,71,102,34,31,32,75
	btf_id 163
498: sched_cls  name tail_ipv4_ct_egress  tag cfe38d259d0c8170  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,102,76,77,101,78
	btf_id 164
499: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,104
	btf_id 166
500: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
503: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
504: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 70,104,76,77,103,78
	btf_id 167
505: sched_cls  name tail_handle_arp  tag d10811f0d51afc4a  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,104
	btf_id 168
506: sched_cls  name tail_handle_ipv4_cont  tag 20e97c153d34099f  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 69,103,35,93,76,77,33,70,68,71,104,34,31,32,75
	btf_id 169
507: sched_cls  name handle_policy  tag c2765b6592aa19ed  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 70,104,76,77,103,35,74,93,33,78,69,34,31,32
	btf_id 170
508: sched_cls  name tail_handle_ipv4  tag f6d3ee364abae3c5  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,104
	btf_id 171
509: sched_cls  name tail_ipv4_ct_ingress  tag 1381aa8a776fe27a  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 70,104,76,77,103,78
	btf_id 172
510: sched_cls  name cil_from_container  tag e06871e79e197be2  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 104,70
	btf_id 173
512: sched_cls  name __send_drop_notify  tag 92dd16d9a152453c  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 175
513: sched_cls  name tail_ipv4_to_endpoint  tag d662bd3947b3b5cd  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 69,70,103,35,76,77,74,93,33,104,34,31,32
	btf_id 176
514: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
517: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
518: sched_cls  name __send_drop_notify  tag ef56a68e76a072da  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 178
519: sched_cls  name tail_handle_ipv4_from_host  tag 41922796f1273534  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,107
	btf_id 179
520: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,107
	btf_id 180
521: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 181
523: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 70,69,107
	btf_id 183
526: sched_cls  name __send_drop_notify  tag ef56a68e76a072da  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 187
527: sched_cls  name tail_handle_ipv4_from_host  tag 41922796f1273534  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,109
	btf_id 188
528: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,109
	btf_id 189
529: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 70
	btf_id 190
533: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 70,111,69
	btf_id 195
536: sched_cls  name __send_drop_notify  tag ef56a68e76a072da  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 35
	btf_id 198
537: sched_cls  name tail_handle_ipv4_from_host  tag 41922796f1273534  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 68,69,70,71,35,75,111
	btf_id 199
538: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:17:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 70,111
	btf_id 200
539: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
542: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
543: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:17:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
546: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:17:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
586: sched_cls  name cil_from_container  tag a66e9b4a763ad03f  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 127,70
	btf_id 215
587: sched_cls  name tail_handle_ipv4_cont  tag 129fabdf9cfd8399  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 69,126,35,125,76,77,33,70,68,71,127,34,31,32,75
	btf_id 216
588: sched_cls  name handle_policy  tag 41e97f31930329c9  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 70,127,76,77,126,35,74,125,33,78,69,34,31,32
	btf_id 217
589: sched_cls  name tail_ipv4_to_endpoint  tag 97b2bb57af04691b  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 69,70,126,35,76,77,74,125,33,127,34,31,32
	btf_id 218
590: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 70,127
	btf_id 219
591: sched_cls  name tail_ipv4_ct_egress  tag 97f2eb38db6e3230  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 70,127,76,77,126,78
	btf_id 220
592: sched_cls  name tail_handle_ipv4  tag eeb39ce7f84fe029  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 78,70,72,76,77,73,33,127
	btf_id 221
593: sched_cls  name tail_ipv4_ct_ingress  tag 746152b920b96273  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 70,127,76,77,126,78
	btf_id 222
594: sched_cls  name tail_handle_arp  tag 60e2e7380d72c8b8  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 70,127
	btf_id 223
595: sched_cls  name __send_drop_notify  tag f3005535fe640e43  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 35
	btf_id 224
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
613: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
616: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
617: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
620: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
621: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:21:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
624: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:21:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
