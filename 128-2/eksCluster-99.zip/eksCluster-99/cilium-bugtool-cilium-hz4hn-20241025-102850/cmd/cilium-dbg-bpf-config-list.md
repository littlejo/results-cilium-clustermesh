KEY             VALUE
AgentLiveness   780107906328
UTimeOffset     3378615980468750
