1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:6e:cd:da:66:ed brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.201.30/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2860sec preferred_lft 2860sec
    inet6 fe80::86e:cdff:feda:66ed/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:b9:6c:be:04:11 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::fcb9:6cff:febe:411/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:6b:37:a1:f6:64 brd ff:ff:ff:ff:ff:ff
    inet 10.99.0.78/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::5c6b:37ff:fea1:f664/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether f6:d7:7b:aa:a9:c8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f4d7:7bff:feaa:a9c8/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:ec:ef:97:f4:bf brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::90ec:efff:fe97:f4bf/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc4468fde50545@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:68:a1:54:3b:1d brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::9068:a1ff:fe54:3b1d/64 scope link 
       valid_lft forever preferred_lft forever
11: lxcf60d7877516b@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:9f:f1:4e:a8:1d brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::a09f:f1ff:fe4e:a81d/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc9a88b3afbaaf@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:da:b4:38:e3:75 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::90da:b4ff:fe38:e375/64 scope link 
       valid_lft forever preferred_lft forever
