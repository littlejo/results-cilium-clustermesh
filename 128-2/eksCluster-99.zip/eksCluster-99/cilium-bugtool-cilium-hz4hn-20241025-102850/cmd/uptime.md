 10:28:51 up 12 min,  0 users,  load average: 0.10, 0.21, 0.18
