{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:21.546Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.201.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:21.547Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:25.891Z",
  "value": "id=27    sec_id=6572220 flags=0x0000 ifindex=9   mac=46:D2:D4:DD:5B:75 nodemac=92:68:A1:54:3B:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:25.895Z",
  "value": "id=3741  sec_id=4     flags=0x0000 ifindex=7   mac=22:16:6F:E0:0F:11 nodemac=92:EC:EF:97:F4:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:25.959Z",
  "value": "id=1927  sec_id=6572220 flags=0x0000 ifindex=11  mac=02:00:E1:9A:B9:09 nodemac=A2:9F:F1:4E:A8:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:26.018Z",
  "value": "id=27    sec_id=6572220 flags=0x0000 ifindex=9   mac=46:D2:D4:DD:5B:75 nodemac=92:68:A1:54:3B:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:26.060Z",
  "value": "id=3741  sec_id=4     flags=0x0000 ifindex=7   mac=22:16:6F:E0:0F:11 nodemac=92:EC:EF:97:F4:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:38.390Z",
  "value": "id=3741  sec_id=4     flags=0x0000 ifindex=7   mac=22:16:6F:E0:0F:11 nodemac=92:EC:EF:97:F4:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:38.391Z",
  "value": "id=27    sec_id=6572220 flags=0x0000 ifindex=9   mac=46:D2:D4:DD:5B:75 nodemac=92:68:A1:54:3B:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:38.391Z",
  "value": "id=1927  sec_id=6572220 flags=0x0000 ifindex=11  mac=02:00:E1:9A:B9:09 nodemac=A2:9F:F1:4E:A8:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:38.422Z",
  "value": "id=613   sec_id=6564329 flags=0x0000 ifindex=13  mac=16:53:0D:15:7B:3C nodemac=26:A9:67:11:C9:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:39.390Z",
  "value": "id=27    sec_id=6572220 flags=0x0000 ifindex=9   mac=46:D2:D4:DD:5B:75 nodemac=92:68:A1:54:3B:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:39.391Z",
  "value": "id=3741  sec_id=4     flags=0x0000 ifindex=7   mac=22:16:6F:E0:0F:11 nodemac=92:EC:EF:97:F4:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:39.391Z",
  "value": "id=613   sec_id=6564329 flags=0x0000 ifindex=13  mac=16:53:0D:15:7B:3C nodemac=26:A9:67:11:C9:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:17:39.391Z",
  "value": "id=1927  sec_id=6572220 flags=0x0000 ifindex=11  mac=02:00:E1:9A:B9:09 nodemac=A2:9F:F1:4E:A8:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:28.115Z",
  "value": "id=1346  sec_id=6564329 flags=0x0000 ifindex=15  mac=FA:E6:60:19:00:2B nodemac=92:DA:B4:38:E3:75"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.99.0.153:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:21:34.975Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:23.404Z",
  "value": "id=1346  sec_id=6564329 flags=0x0000 ifindex=15  mac=FA:E6:60:19:00:2B nodemac=92:DA:B4:38:E3:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:23.404Z",
  "value": "id=27    sec_id=6572220 flags=0x0000 ifindex=9   mac=46:D2:D4:DD:5B:75 nodemac=92:68:A1:54:3B:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:23.404Z",
  "value": "id=1927  sec_id=6572220 flags=0x0000 ifindex=11  mac=02:00:E1:9A:B9:09 nodemac=A2:9F:F1:4E:A8:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:23.404Z",
  "value": "id=3741  sec_id=4     flags=0x0000 ifindex=7   mac=22:16:6F:E0:0F:11 nodemac=92:EC:EF:97:F4:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.404Z",
  "value": "id=3741  sec_id=4     flags=0x0000 ifindex=7   mac=22:16:6F:E0:0F:11 nodemac=92:EC:EF:97:F4:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.404Z",
  "value": "id=27    sec_id=6572220 flags=0x0000 ifindex=9   mac=46:D2:D4:DD:5B:75 nodemac=92:68:A1:54:3B:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.405Z",
  "value": "id=1927  sec_id=6572220 flags=0x0000 ifindex=11  mac=02:00:E1:9A:B9:09 nodemac=A2:9F:F1:4E:A8:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:24.405Z",
  "value": "id=1346  sec_id=6564329 flags=0x0000 ifindex=15  mac=FA:E6:60:19:00:2B nodemac=92:DA:B4:38:E3:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:25.404Z",
  "value": "id=3741  sec_id=4     flags=0x0000 ifindex=7   mac=22:16:6F:E0:0F:11 nodemac=92:EC:EF:97:F4:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:25.404Z",
  "value": "id=1346  sec_id=6564329 flags=0x0000 ifindex=15  mac=FA:E6:60:19:00:2B nodemac=92:DA:B4:38:E3:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:25.404Z",
  "value": "id=1927  sec_id=6572220 flags=0x0000 ifindex=11  mac=02:00:E1:9A:B9:09 nodemac=A2:9F:F1:4E:A8:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:25.404Z",
  "value": "id=27    sec_id=6572220 flags=0x0000 ifindex=9   mac=46:D2:D4:DD:5B:75 nodemac=92:68:A1:54:3B:1D"
}

