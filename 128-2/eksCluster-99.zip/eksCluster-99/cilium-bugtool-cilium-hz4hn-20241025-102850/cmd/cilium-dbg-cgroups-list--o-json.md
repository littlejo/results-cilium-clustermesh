[
  {
    "containers": [
      {
        "cgroup-id": 7110,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod21cb0799_11bc_4739_9eec_5511d5fd3590.slice/cri-containerd-24475a9bd8ef08c43da71a0c4131c1cebfeaf9a0d55086c4d0a5de65dff880c7.scope"
      }
    ],
    "ips": [
      "10.99.0.181"
    ],
    "name": "coredns-cc6ccd49c-c65lk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8538,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod249f226c_256d_4fd4_851c_25d6024591f3.slice/cri-containerd-f109419e1287f45ee7091909c98a07b8ebe14679c00dfe7469f60d95c3262fd2.scope"
      },
      {
        "cgroup-id": 8454,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod249f226c_256d_4fd4_851c_25d6024591f3.slice/cri-containerd-8e5e750146387a6eb889d8e050e84371a362a2801c42c111eb41411784822f97.scope"
      },
      {
        "cgroup-id": 8622,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod249f226c_256d_4fd4_851c_25d6024591f3.slice/cri-containerd-e2eb9997529e3bcd2c04f9cf66ec1b18d0ffee2ae944e1f48004a42d98b83516.scope"
      }
    ],
    "ips": [
      "10.99.0.183"
    ],
    "name": "clustermesh-apiserver-77695dc8d7-ddsjl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7026,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd63d6615_a38d_4d05_bbdf_66e24503c23c.slice/cri-containerd-df418701c907459706376b054b42cf0a0b99fa0e2174107295eb8912c3321753.scope"
      }
    ],
    "ips": [
      "10.99.0.119"
    ],
    "name": "coredns-cc6ccd49c-lcdmg",
    "namespace": "kube-system"
  }
]

