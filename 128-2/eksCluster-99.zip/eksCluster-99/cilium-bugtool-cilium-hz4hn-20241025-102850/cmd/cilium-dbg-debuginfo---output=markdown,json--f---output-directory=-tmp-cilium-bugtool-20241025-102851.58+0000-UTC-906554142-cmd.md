markdown output at /tmp/cilium-bugtool-20241025-102851.58+0000-UTC-906554142/cmd/cilium-debuginfo-20241025-102922.25+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102851.58+0000-UTC-906554142/cmd/cilium-debuginfo-20241025-102922.25+0000-UTC.json
