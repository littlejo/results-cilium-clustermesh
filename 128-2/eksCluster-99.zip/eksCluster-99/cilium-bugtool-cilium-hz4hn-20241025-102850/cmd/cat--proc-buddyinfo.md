Node 0, zone      DMA      3      4      2     14     10      8      7      6      6      6    220 
Node 0, zone   Normal      3      0      1      0      1      1      3      2      2      1      9 
