Total: 532
TCP:   1057 (estab 287, closed 751, orphaned 0, timewait 299)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  306       296       10       
INET	  316       302       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                   172.31.201.30%ens5:68         0.0.0.0:*    uid:192 ino:16401 sk:254 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:22015 sk:255 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:13257 sk:256 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:44781      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:21919 sk:257 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:22014 sk:258 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:13258 sk:259 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::86e:cdff:feda:66ed]%ens5:546           [::]:*    uid:192 ino:15623 sk:25a cgroup:unreachable:c4e v6only:1 <->                   
