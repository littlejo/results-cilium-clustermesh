Endpoint ID: 12
Path: /sys/fs/bpf/tc/globals/cilium_policy_00012

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 27
Path: /sys/fs/bpf/tc/globals/cilium_policy_00027

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    67281   772       0        
Allow    Egress      0          ANY          NONE         disabled    12619   129       0        


Endpoint ID: 1346
Path: /sys/fs/bpf/tc/globals/cilium_policy_01346

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3875088   36973     0        
Allow    Ingress     1          ANY          NONE         disabled    3292268   33441     0        
Allow    Egress      0          ANY          NONE         disabled    5216401   48183     0        


Endpoint ID: 1927
Path: /sys/fs/bpf/tc/globals/cilium_policy_01927

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    66951   767       0        
Allow    Egress      0          ANY          NONE         disabled    12414   127       0        


Endpoint ID: 3741
Path: /sys/fs/bpf/tc/globals/cilium_policy_03741

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    447154   5709      0        
Allow    Ingress     1          ANY          NONE         disabled    10794    128       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


