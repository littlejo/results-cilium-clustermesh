xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 533
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 529
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 521
cilium_host(4) clsact/egress cil_from_host-cilium_host id 523
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 452
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 453
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 510
lxc4468fde50545(9) clsact/ingress cil_from_container-lxc4468fde50545 id 491
lxcf60d7877516b(11) clsact/ingress cil_from_container-lxcf60d7877516b id 487
lxc9a88b3afbaaf(15) clsact/ingress cil_from_container-lxc9a88b3afbaaf id 586

flow_dissector:

netfilter:

