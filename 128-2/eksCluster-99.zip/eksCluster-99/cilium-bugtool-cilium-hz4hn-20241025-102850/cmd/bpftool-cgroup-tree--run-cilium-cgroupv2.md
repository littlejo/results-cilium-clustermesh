CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod21cb0799_11bc_4739_9eec_5511d5fd3590.slice/cri-containerd-af141063dc8aba1fbe49c285d8dc2bcefce7971c7f5475029828716ae48190e4.scope
    503      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod21cb0799_11bc_4739_9eec_5511d5fd3590.slice/cri-containerd-24475a9bd8ef08c43da71a0c4131c1cebfeaf9a0d55086c4d0a5de65dff880c7.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda0e81cbe_c958_41b9_bff2_def825336dee.slice/cri-containerd-f1da315fe14d57da220aae7ee8311198b1bbdcca3f0de88091b800e16d7b490a.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda0e81cbe_c958_41b9_bff2_def825336dee.slice/cri-containerd-70333a9dd11802b2f01d0336f265d7d62b8df360f2975826d1d0394bf7695888.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod532c4e29_616a_4f08_834d_9d303a36ac87.slice/cri-containerd-c01e7824de072cd3f3dc3b021b1d81a0ce8328c95bbaf2cf9f379d2d9f0571a0.scope
    110      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod532c4e29_616a_4f08_834d_9d303a36ac87.slice/cri-containerd-b94830412c9ca86fef987d1ac49dc8b4e5fdae4493bf78f5af6ea6cad0078391.scope
    67       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd63d6615_a38d_4d05_bbdf_66e24503c23c.slice/cri-containerd-f1211de7a9cd2569d0b49f84dd0610b95183f2bbe8c1e09e15e5522c31a47371.scope
    517      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd63d6615_a38d_4d05_bbdf_66e24503c23c.slice/cri-containerd-df418701c907459706376b054b42cf0a0b99fa0e2174107295eb8912c3321753.scope
    542      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56a3806a_8ce2_4d6b_87db_80ebd62d6062.slice/cri-containerd-a3f58fe68fc62d8d2001f528fe05187315a73e4cc9e7f5d8d2a273b02b240be4.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56a3806a_8ce2_4d6b_87db_80ebd62d6062.slice/cri-containerd-fdaf16f81e22c9d80b01fde0e6b4a0497123f7a6ebf371eb5d7434280f13a53e.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc48af80b_f5c0_42f5_9b04_fce730827266.slice/cri-containerd-cb64d22a6628b9f3b010a0fa50ba7378bb5051787f997dcc4838cf03dcd47c60.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc48af80b_f5c0_42f5_9b04_fce730827266.slice/cri-containerd-1f79ce61f2512d27d5ff69a3aaee5d7ca99284958a6cfd450bd5a2d896dadb1b.scope
    71       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod249f226c_256d_4fd4_851c_25d6024591f3.slice/cri-containerd-49cbb4e7051caaca3af78f14ae36103f859bae456abfa6fdaa0b716d26453527.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod249f226c_256d_4fd4_851c_25d6024591f3.slice/cri-containerd-f109419e1287f45ee7091909c98a07b8ebe14679c00dfe7469f60d95c3262fd2.scope
    620      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod249f226c_256d_4fd4_851c_25d6024591f3.slice/cri-containerd-8e5e750146387a6eb889d8e050e84371a362a2801c42c111eb41411784822f97.scope
    616      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod249f226c_256d_4fd4_851c_25d6024591f3.slice/cri-containerd-e2eb9997529e3bcd2c04f9cf66ec1b18d0ffee2ae944e1f48004a42d98b83516.scope
    624      cgroup_device   multi                                          
