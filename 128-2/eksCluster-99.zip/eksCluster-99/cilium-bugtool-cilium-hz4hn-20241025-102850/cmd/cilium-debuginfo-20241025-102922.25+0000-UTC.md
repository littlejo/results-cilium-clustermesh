# Cilium debug information

#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium environment keys

```
l2-announcements-retry-period:2s
external-envoy-proxy:true
enable-encryption-strict-mode:false
debug-verbose:
hubble-metrics-server:
enable-local-redirect-policy:false
bpf-policy-map-full-reconciliation-interval:15m0s
tofqdns-pre-cache:
hubble-export-file-max-backups:5
ipv6-node:auto
vtep-endpoint:
enable-xt-socket-fallback:true
set-cilium-is-up-condition:true
hubble-drop-events-interval:2m0s
enable-node-port:false
enable-ipv4-masquerade:true
ipv4-service-range:auto
enable-ipv4-egress-gateway:false
kvstore-opt:
bpf-lb-rev-nat-map-max:0
fqdn-regex-compile-lru-size:1024
dnsproxy-enable-transparent-mode:true
hubble-export-file-path:
operator-api-serve-addr:127.0.0.1:9234
tofqdns-idle-connection-grace-period:0s
tofqdns-proxy-response-max-delay:100ms
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
enable-l7-proxy:true
k8s-service-proxy-name:
clustermesh-enable-endpoint-sync:false
cflags:
mtu:0
bpf-map-event-buffers:
tunnel-port:0
cmdref:
bpf-lb-source-range-map-max:0
hubble-export-fieldmask:
ipv4-node:auto
bpf-policy-map-max:16384
envoy-secrets-namespace:
enable-session-affinity:false
cni-external-routing:false
enable-stale-cilium-endpoint-cleanup:true
restore:true
proxy-max-connection-duration-seconds:0
bpf-lb-maglev-map-max:0
enable-l2-pod-announcements:false
enable-srv6:false
mesh-auth-rotated-identities-queue-size:1024
hubble-redact-http-urlquery:false
enable-policy:default
bpf-lb-service-map-max:0
enable-wireguard-userspace-fallback:false
log-driver:
hubble-event-queue-size:0
enable-ipv6-masquerade:true
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
hubble-recorder-storage-path:/var/run/cilium/pcaps
ipam:cluster-pool
k8s-client-connection-timeout:30s
cni-log-file:/var/run/cilium/cilium-cni.log
ipam-default-ip-pool:default
k8s-require-ipv4-pod-cidr:false
cni-chaining-mode:none
dnsproxy-socket-linger-timeout:10
enable-endpoint-routes:false
wireguard-persistent-keepalive:0s
encryption-strict-mode-allow-remote-node-identities:false
hubble-prefer-ipv6:false
kube-proxy-replacement-healthz-bind-address:
dnsproxy-lock-count:131
mesh-auth-spire-admin-socket:
enable-health-check-loadbalancer-ip:false
hubble-redact-kafka-apikey:false
enable-gateway-api:false
dns-policy-unload-on-shutdown:false
envoy-config-retry-interval:15s
controller-group-metrics:
enable-active-connection-tracking:false
debug:false
monitor-aggregation-flags:all
pprof:false
enable-ipv6-ndp:false
proxy-idle-timeout-seconds:60
endpoint-bpf-prog-watchdog-interval:30s
enable-svc-source-range-check:true
bpf-lb-rss-ipv4-src-cidr:
kvstore-connectivity-timeout:2m0s
mesh-auth-spiffe-trust-domain:spiffe.cilium
hubble-event-buffer-capacity:4095
hubble-listen-address::4244
hubble-metrics:
hubble-redact-http-headers-allow:
cluster-name:cmesh100
tofqdns-endpoint-max-ip-per-hostname:50
force-device-detection:false
procfs:/host/proc
ipv6-cluster-alloc-cidr:f00d::/64
enable-well-known-identities:false
ipv4-range:auto
dnsproxy-insecure-skip-transparent-mode-check:false
node-port-mode:snat
kvstore-periodic-sync:5m0s
cgroup-root:/run/cilium/cgroupv2
join-cluster:false
enable-ipsec-encrypted-overlay:false
fixed-identity-mapping:
egress-gateway-policy-map-max:16384
ipv6-mcast-device:
enable-mke:false
bpf-ct-timeout-service-tcp-grace:1m0s
set-cilium-node-taints:true
enable-ipsec-key-watcher:true
monitor-queue-size:0
k8s-heartbeat-timeout:30s
prepend-iptables-chains:true
mke-cgroup-mount:
prometheus-serve-addr:
cluster-pool-ipv4-mask-size:24
proxy-admin-port:0
label-prefix-file:
enable-icmp-rules:true
mesh-auth-mutual-listener-port:0
bpf-events-trace-enabled:true
bpf-lb-affinity-map-max:0
bpf-lb-map-max:65536
hubble-flowlogs-config-path:
envoy-config-timeout:2m0s
unmanaged-pod-watcher-interval:15
cluster-health-port:4240
proxy-connect-timeout:2
nat-map-stats-interval:30s
mesh-auth-gc-interval:5m0s
clustermesh-ip-identities-sync-timeout:1m0s
l2-pod-announcements-interface:
enable-runtime-device-detection:true
bpf-ct-timeout-regular-tcp-fin:10s
enable-cilium-health-api-server-access:
enable-envoy-config:false
enable-tracing:false
k8s-api-server:
disable-iptables-feeder-rules:
vtep-mac:
l2-announcements-lease-duration:15s
multicast-enabled:false
identity-allocation-mode:crd
http-request-timeout:3600
container-ip-local-reserved-ports:auto
local-router-ipv4:
dnsproxy-concurrency-limit:0
enable-tcx:true
agent-liveness-update-interval:1s
envoy-keep-cap-netbindservice:false
tofqdns-enable-dns-compression:true
bpf-sock-rev-map-max:262144
socket-path:/var/run/cilium/cilium.sock
enable-health-check-nodeport:true
bypass-ip-availability-upon-restore:false
node-port-algorithm:random
bpf-lb-maglev-table-size:16381
proxy-portrange-min:10000
bpf-root:/sys/fs/bpf
cluster-pool-ipv4-cidr:10.99.0.0/16
enable-k8s-endpoint-slice:true
enable-host-firewall:false
install-iptables-rules:true
state-dir:/var/run/cilium
gops-port:9890
bgp-config-path:/var/lib/cilium/bgp/config.yaml
disable-endpoint-crd:false
kvstore-max-consecutive-quorum-errors:2
identity-heartbeat-timeout:30m0s
bpf-neigh-global-max:524288
enable-l2-neigh-discovery:true
cluster-id:100
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
http-retry-timeout:0
local-router-ipv6:
bpf-lb-mode:snat
hubble-redact-http-headers-deny:
hubble-drop-events:false
bpf-lb-external-clusterip:false
enable-bandwidth-manager:false
auto-create-cilium-node-resource:true
route-metric:0
srv6-encap-mode:reduced
k8s-client-qps:10
metrics:
iptables-lock-timeout:5s
identity-restore-grace-period:30s
identity-change-grace-period:5s
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
mesh-auth-queue-size:1024
hubble-redact-http-userinfo:true
enable-hubble:true
derive-masq-ip-addr-from-device:
ipv6-native-routing-cidr:
node-port-bind-protection:true
trace-sock:true
direct-routing-device:
hubble-skip-unknown-cgroup-ids:true
mesh-auth-mutual-connect-timeout:5s
bpf-node-map-max:16384
ipam-cilium-node-update-rate:15s
bpf-ct-global-tcp-max:524288
routing-mode:tunnel
bpf-lb-dsr-dispatch:opt
enable-nat46x64-gateway:false
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
encrypt-node:false
allocator-list-timeout:3m0s
config:
enable-xdp-prefilter:false
envoy-log:
hubble-export-file-max-size-mb:10
tofqdns-min-ttl:0
k8s-client-connection-keep-alive:30s
preallocate-bpf-maps:false
enable-external-ips:false
endpoint-gc-interval:5m0s
bpf-ct-global-any-max:262144
bpf-events-drop-enabled:true
operator-prometheus-serve-addr::9963
local-max-addr-scope:252
pprof-port:6060
encryption-strict-mode-cidr:
devices:
synchronize-k8s-nodes:true
crd-wait-timeout:5m0s
proxy-gid:1337
arping-refresh-period:30s
enable-ip-masq-agent:false
enable-ipip-termination:false
bpf-lb-sock-hostns-only:false
enable-identity-mark:true
ipam-multi-pool-pre-allocation:
datapath-mode:veth
api-rate-limit:
ipsec-key-file:
agent-health-port:9879
cilium-endpoint-gc-interval:5m0s
bpf-nat-global-max:524288
l2-announcements-renew-deadline:5s
enable-host-legacy-routing:false
enable-l2-announcements:false
http-idle-timeout:0
hubble-redact-enabled:false
labels:
enable-ipv4-fragment-tracking:true
enable-bgp-control-plane:false
read-cni-conf:
ip-masq-agent-config-path:/etc/config/ip-masq-agent
bpf-lb-service-backend-map-max:0
dnsproxy-lock-timeout:500ms
enable-ipsec-xfrm-state-caching:true
bpf-ct-timeout-regular-tcp-syn:1m0s
monitor-aggregation:medium
enable-health-checking:true
config-dir:/tmp/cilium/config-map
enable-host-port:false
monitor-aggregation-interval:5s
conntrack-gc-max-interval:0s
hubble-export-allowlist:
max-internal-timer-delay:0s
proxy-max-requests-per-connection:0
bpf-auth-map-max:524288
bpf-events-policy-verdict-enabled:true
annotate-k8s-node:false
enable-route-mtu-for-cni-chaining:false
clustermesh-config:/var/lib/cilium/clustermesh/
enable-ipv6:false
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
bpf-lb-sock:false
agent-labels:
ipsec-key-rotation-duration:5m0s
enable-ipsec:false
http-max-grpc-timeout:0
enable-local-node-route:true
policy-accounting:true
proxy-xff-num-trusted-hops-egress:0
log-opt:
enable-k8s-terminating-endpoint:true
static-cnp-path:
enable-wireguard:false
enable-unreachable-routes:false
use-full-tls-context:false
encrypt-interface:
max-connected-clusters:255
ipv6-pod-subnets:
enable-ipv6-big-tcp:false
ipv6-service-range:auto
hubble-monitor-events:
envoy-base-id:0
cni-chaining-target:
hubble-drop-events-reasons:auth_required,policy_denied
version:false
enable-service-topology:false
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
proxy-portrange-max:20000
tofqdns-dns-reject-response-code:refused
conntrack-gc-interval:0s
enable-ipv4:true
kvstore-lease-ttl:15m0s
log-system-load:false
k8s-require-ipv6-pod-cidr:false
enable-vtep:false
k8s-service-cache-size:128
vtep-mask:
enable-k8s:true
mesh-auth-signal-backoff-duration:1s
hubble-export-denylist:
http-retry-count:3
ipv4-native-routing-cidr:
enable-custom-calls:false
remove-cilium-node-taints:true
bpf-map-dynamic-size-ratio:0.0025
max-controller-interval:0
clustermesh-sync-timeout:1m0s
exclude-node-label-patterns:
enable-k8s-networkpolicy:true
ingress-secrets-namespace:
enable-cilium-api-server-access:
k8s-namespace:kube-system
enable-recorder:false
nodeport-addresses:
tofqdns-max-deferred-connection-deletes:10000
http-normalize-path:true
trace-payloadlen:128
bpf-ct-timeout-service-tcp:2h13m20s
use-cilium-internal-ip-for-ipsec:false
ipv4-service-loopback-address:169.254.42.1
bpf-lb-dsr-l4-xlate:frontend
k8s-sync-timeout:3m0s
nat-map-stats-entries:32
enable-high-scale-ipcache:false
ipv6-range:auto
hubble-socket-path:/var/run/cilium/hubble.sock
auto-direct-node-routes:false
kube-proxy-replacement:false
enable-ipv4-big-tcp:false
vlan-bpf-bypass:
keep-config:false
enable-endpoint-health-checking:true
dns-max-ips-per-restored-rule:1000
k8s-kubeconfig-path:
ipv4-pod-subnets:
config-sources:config-map:kube-system/cilium-config
enable-ingress-controller:false
mesh-auth-enabled:true
iptables-random-fully:false
gateway-api-secrets-namespace:
proxy-xff-num-trusted-hops-ingress:0
node-port-acceleration:disabled
bpf-lb-algorithm:random
policy-trigger-interval:1s
enable-masquerade-to-route-source:false
dnsproxy-concurrency-processing-grace-period:0s
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
hubble-recorder-sink-queue-size:1024
vtep-cidr:
enable-pmtu-discovery:false
certificates-directory:/var/run/cilium/certs
disable-external-ip-mitigation:false
enable-monitor:true
egress-multi-home-ip-rule-compat:false
allow-icmp-frag-needed:true
enable-cilium-endpoint-slice:false
kvstore:
node-port-range:
enable-metrics:true
pprof-address:localhost
egress-masquerade-interfaces:ens+
cni-exclusive:true
nodes-gc-interval:5m0s
direct-routing-skip-unreachable:false
disable-envoy-version-check:false
policy-cidr-match-mode:
bpf-ct-timeout-regular-tcp:2h13m20s
bpf-filter-priority:1
enable-hubble-recorder-api:true
enable-k8s-api-discovery:false
enable-bpf-masquerade:false
proxy-prometheus-port:0
hubble-disable-tls:false
bgp-announce-pod-cidr:false
enable-node-selector-labels:false
service-no-backend-response:reject
policy-queue-size:100
k8s-client-burst:20
custom-cni-conf:false
bpf-ct-timeout-regular-any:1m0s
allow-localhost:auto
endpoint-queue-size:25
enable-bpf-clock-probe:false
exclude-local-address:
clustermesh-enable-mcs-api:false
enable-sctp:false
enable-bpf-tproxy:false
bpf-lb-rss-ipv6-src-cidr:
enable-bbr:false
identity-gc-interval:15m0s
hubble-export-file-compress:false
install-no-conntrack-iptables-rules:false
bpf-fragments-map-max:8192
bpf-ct-timeout-service-any:1m0s
enable-auto-protect-node-port-range:true
node-labels:
bpf-lb-acceleration:disabled
bpf-lb-sock-terminate-pod-connections:false
egress-gateway-reconciliation-trigger-interval:1s
lib-dir:/var/lib/cilium
tunnel-protocol:vxlan
tofqdns-proxy-port:0
policy-audit-mode:false
bgp-announce-lb-ip:false
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
12         Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                
                                                           reserved:host                                                                                             
27         Disabled           Disabled          6572220    k8s:eks.amazonaws.com/component=coredns                                             10.99.0.181   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh100                                                                 
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
1346       Disabled           Disabled          6564329    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.99.0.183   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh100                                                                 
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
1927       Disabled           Disabled          6572220    k8s:eks.amazonaws.com/component=coredns                                             10.99.0.119   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh100                                                                 
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
3741       Disabled           Disabled          4          reserved:health                                                                     10.99.0.170   ready   
```

#### BPF Policy Get 12

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 12

```
Invalid argument: unknown type 12
```


#### Endpoint Get 12

```
[
  {
    "id": 12,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-12-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5c1c6181-a030-4082-83ad-c67fa32b9e0c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-12",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:21.852Z",
            "success-count": 3
          },
          "uuid": "63bb4b7c-a382-4191-bbab-8d2c88259a42"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-12",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:22.861Z",
            "success-count": 1
          },
          "uuid": "598624e5-a347-40b5-8e37-56bfb0cc025b"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:25Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "5e:6b:37:a1:f6:64",
        "interface-name": "cilium_host",
        "mac": "5e:6b:37:a1:f6:64"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 12

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 12

```
Timestamp              Status   State                   Message
2024-10-25T10:22:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:25Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:17:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:17:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:17:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:21Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:17:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:17:21Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:17:21Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 27

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    66386   762       0        
Allow    Egress      0          ANY          NONE         disabled    12619   129       0        

```


#### BPF CT List 27

```
Invalid argument: unknown type 27
```


#### Endpoint Get 27

```
[
  {
    "id": 27,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-27-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "a3ded7b2-0366-433c-9db0-2e2fd3811ac5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-27",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:23.675Z",
            "success-count": 3
          },
          "uuid": "9f0ea50e-bd56-476a-b3af-055a89f6d7e9"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-c65lk",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:23.672Z",
            "success-count": 1
          },
          "uuid": "80bc9a37-f98c-4716-a5e4-7fc19690088b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-27",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:25.891Z",
            "success-count": 1
          },
          "uuid": "02935de8-2465-452f-8d96-cbcb4206f610"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (27)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:13.738Z",
            "success-count": 73
          },
          "uuid": "eb2c50b8-d03b-40b2-9336-00d18193fdea"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "af141063dc8aba1fbe49c285d8dc2bcefce7971c7f5475029828716ae48190e4:eth0",
        "container-id": "af141063dc8aba1fbe49c285d8dc2bcefce7971c7f5475029828716ae48190e4",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-c65lk",
        "pod-name": "kube-system/coredns-cc6ccd49c-c65lk"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6572220,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh100",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh100",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:25Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.99.0.181",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "92:68:a1:54:3b:1d",
        "interface-index": 9,
        "interface-name": "lxc4468fde50545",
        "mac": "46:d2:d4:dd:5b:75"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6572220,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6572220,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 27

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 27

```
Timestamp              Status   State                   Message
2024-10-25T10:22:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:25Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:25Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:17:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:17:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:17:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:23Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:17:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:17:23Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:17:23Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 6572220

```
ID        LABELS
6572220   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh100
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1346

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3870580   36924     0        
Allow    Ingress     1          ANY          NONE         disabled    3292268   33441     0        
Allow    Egress      0          ANY          NONE         disabled    5212419   48139     0        

```


#### BPF CT List 1346

```
Invalid argument: unknown type 1346
```


#### Endpoint Get 1346

```
[
  {
    "id": 1346,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1346-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "66bcb3b9-9fdd-4188-b437-5d9e2223608c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1346",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:26:28.084Z",
            "success-count": 2
          },
          "uuid": "ffe4ead9-fc01-4ded-b814-517d122e9e44"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-77695dc8d7-ddsjl",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:28.082Z",
            "success-count": 1
          },
          "uuid": "710c7eb8-7e78-4611-983d-0d1f2b6f98f9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1346",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:21:28.116Z",
            "success-count": 1
          },
          "uuid": "bbaf76d1-439a-4434-996e-83e2d54b9069"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1346)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:18.128Z",
            "success-count": 49
          },
          "uuid": "3a0902b2-4304-4833-81c4-e8f4785700c9"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "49cbb4e7051caaca3af78f14ae36103f859bae456abfa6fdaa0b716d26453527:eth0",
        "container-id": "49cbb4e7051caaca3af78f14ae36103f859bae456abfa6fdaa0b716d26453527",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-77695dc8d7-ddsjl",
        "pod-name": "kube-system/clustermesh-apiserver-77695dc8d7-ddsjl"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6564329,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh100",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=77695dc8d7"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh100",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:25Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.99.0.183",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "92:da:b4:38:e3:75",
        "interface-index": 15,
        "interface-name": "lxc9a88b3afbaaf",
        "mac": "fa:e6:60:19:00:2b"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6564329,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6564329,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1346

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1346

```
Timestamp              Status   State                   Message
2024-10-25T10:22:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:25Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:21:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:21:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:21:28Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:21:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:21:28Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:21:28Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 6564329

```
ID        LABELS
6564329   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh100
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1927

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    65924   755       0        
Allow    Egress      0          ANY          NONE         disabled    12414   127       0        

```


#### BPF CT List 1927

```
Invalid argument: unknown type 1927
```


#### Endpoint Get 1927

```
[
  {
    "id": 1927,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1927-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "766a75c8-5ed6-43f1-97a0-27bb2f64a286"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1927",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:23.764Z",
            "success-count": 3
          },
          "uuid": "47674053-05f0-46b2-8dc6-f8c6ab9e1905"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-lcdmg",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:23.750Z",
            "success-count": 1
          },
          "uuid": "c488b8d5-3bcc-47ac-a0ca-891b40380e5c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1927",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:25.960Z",
            "success-count": 1
          },
          "uuid": "a5980aa9-72ba-41cc-a330-b01149a0fdeb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1927)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:29:13.810Z",
            "success-count": 73
          },
          "uuid": "a467d119-2ae5-4bf9-94ed-7faa28c06bfa"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "f1211de7a9cd2569d0b49f84dd0610b95183f2bbe8c1e09e15e5522c31a47371:eth0",
        "container-id": "f1211de7a9cd2569d0b49f84dd0610b95183f2bbe8c1e09e15e5522c31a47371",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-lcdmg",
        "pod-name": "kube-system/coredns-cc6ccd49c-lcdmg"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6572220,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh100",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh100",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:25Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.99.0.119",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "a2:9f:f1:4e:a8:1d",
        "interface-index": 11,
        "interface-name": "lxcf60d7877516b",
        "mac": "02:00:e1:9a:b9:09"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6572220,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6572220,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1927

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1927

```
Timestamp              Status   State                   Message
2024-10-25T10:22:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:25Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:17:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:25Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:17:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:17:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:17:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:17:23Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:17:23Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 6572220

```
ID        LABELS
6572220   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh100
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 3741

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    446590   5702      0        
Allow    Ingress     1          ANY          NONE         disabled    10794    128       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 3741

```
Invalid argument: unknown type 3741
```


#### Endpoint Get 3741

```
[
  {
    "id": 3741,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3741-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7357c588-80e5-4a5f-b624-c43d98472053"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3741",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:22.906Z",
            "success-count": 3
          },
          "uuid": "14661c1d-9b8b-439f-b333-fc07171382d6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3741",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:17:25.896Z",
            "success-count": 1
          },
          "uuid": "84d32d94-2399-4102-b929-700d449849b0"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:22:25Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.99.0.170",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "92:ec:ef:97:f4:bf",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "22:16:6f:e0:0f:11"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3741

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3741

```
Timestamp              Status   State                   Message
2024-10-25T10:22:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:22:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:25Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:22:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:17:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:17:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:17:25Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:17:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-25T10:17:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:17:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:17:22Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:17:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:17:22Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:17:21Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Service list

```
ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.191.56:443 (active)    
                                         2 => 172.31.239.123:443 (active)   
2    10.100.136.107:443   ClusterIP      1 => 172.31.201.30:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.99.0.119:53 (active)       
                                         2 => 10.99.0.181:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.99.0.119:9153 (active)     
                                         2 => 10.99.0.181:9153 (active)     
5    10.100.11.17:2379    ClusterIP      1 => 10.99.0.183:2379 (active)     
```

#### Policy get

```
:
 []
Revision: 1

```


#### Cilium encryption



#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.99.0.0/24, 
Allocated addresses:
  10.99.0.119 (kube-system/coredns-cc6ccd49c-lcdmg)
  10.99.0.170 (health)
  10.99.0.181 (kube-system/coredns-cc6ccd49c-c65lk)
  10.99.0.183 (kube-system/clustermesh-apiserver-77695dc8d7-ddsjl)
  10.99.0.78 (router)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 5c654da506d51ab3
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    1m0s ago       never        0       no error   
  ct-map-pressure                                                     1s ago         never        0       no error   
  daemon-validate-config                                              50s ago        never        0       no error   
  dns-garbage-collector-job                                           4s ago         never        0       no error   
  endpoint-12-regeneration-recovery                                   never          never        0       no error   
  endpoint-1346-regeneration-recovery                                 never          never        0       no error   
  endpoint-1927-regeneration-recovery                                 never          never        0       no error   
  endpoint-27-regeneration-recovery                                   never          never        0       no error   
  endpoint-3741-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                         2m4s ago       never        0       no error   
  ep-bpf-prog-watchdog                                                1s ago         never        0       no error   
  ipcache-inject-labels                                               2s ago         never        0       no error   
  k8s-heartbeat                                                       4s ago         never        0       no error   
  link-cache                                                          1s ago         never        0       no error   
  local-identity-checkpoint                                           12m1s ago      never        0       no error   
  node-neighbor-link-updater                                          1s ago         never        0       no error   
  remote-etcd-cmesh1                                                  7m0s ago       never        0       no error   
  remote-etcd-cmesh10                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh101                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh102                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh103                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh104                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh105                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh106                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh107                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh108                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh109                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh11                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh110                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh111                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh112                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh113                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh114                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh115                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh116                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh117                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh118                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh119                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh12                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh120                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh121                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh122                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh123                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh124                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh125                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh126                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh127                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh128                                                7m0s ago       never        0       no error   
  remote-etcd-cmesh13                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh14                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh15                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh16                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh17                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh18                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh19                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh2                                                  7m0s ago       never        0       no error   
  remote-etcd-cmesh20                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh21                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh22                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh23                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh24                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh25                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh26                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh27                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh28                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh29                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh3                                                  7m0s ago       never        0       no error   
  remote-etcd-cmesh30                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh31                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh32                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh33                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh34                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh35                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh36                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh37                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh38                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh39                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh4                                                  7m0s ago       never        0       no error   
  remote-etcd-cmesh40                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh41                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh42                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh43                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh44                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh45                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh46                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh47                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh48                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh49                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh5                                                  7m0s ago       never        0       no error   
  remote-etcd-cmesh50                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh51                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh52                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh53                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh54                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh55                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh56                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh57                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh58                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh59                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh6                                                  7m0s ago       never        0       no error   
  remote-etcd-cmesh60                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh61                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh62                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh63                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh64                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh65                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh66                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh67                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh68                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh69                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh7                                                  7m0s ago       never        0       no error   
  remote-etcd-cmesh70                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh71                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh72                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh73                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh74                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh75                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh76                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh77                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh78                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh79                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh8                                                  7m0s ago       never        0       no error   
  remote-etcd-cmesh80                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh81                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh82                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh83                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh84                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh85                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh86                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh87                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh88                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh89                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh9                                                  7m0s ago       never        0       no error   
  remote-etcd-cmesh90                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh91                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh92                                                 6m59s ago      never        0       no error   
  remote-etcd-cmesh93                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh94                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh95                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh96                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh97                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh98                                                 7m0s ago       never        0       no error   
  remote-etcd-cmesh99                                                 7m0s ago       never        0       no error   
  resolve-identity-12                                                 2m1s ago       never        0       no error   
  resolve-identity-1346                                               2m55s ago      never        0       no error   
  resolve-identity-1927                                               2m0s ago       never        0       no error   
  resolve-identity-27                                                 2m0s ago       never        0       no error   
  resolve-identity-3741                                               2m0s ago       never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-77695dc8d7-ddsjl   7m55s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-c65lk                  12m0s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-lcdmg                  12m0s ago      never        0       no error   
  sync-lb-maps-with-k8s-services                                      12m1s ago      never        0       no error   
  sync-policymap-12                                                   12m0s ago      never        0       no error   
  sync-policymap-1346                                                 7m55s ago      never        0       no error   
  sync-policymap-1927                                                 11m57s ago     never        0       no error   
  sync-policymap-27                                                   11m57s ago     never        0       no error   
  sync-policymap-3741                                                 11m57s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (1346)                                   5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1927)                                   9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (27)                                     10s ago        never        0       no error   
  sync-utime                                                          2s ago         never        0       no error   
  write-cni-file                                                      12m4s ago      never        0       no error   
Proxy Status:            OK, ip 10.99.0.78, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 6553600, max 6619135
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 92.17   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 27281454                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 27281454                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 27281454                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400d400000 rw-p 00000000 00:00 0 
400d400000-4010000000 ---p 00000000 00:00 0 
ffff73852000-ffff73a38000 rw-p 00000000 00:00 0 
ffff73a40000-ffff73b61000 rw-p 00000000 00:00 0 
ffff73b61000-ffff73ba2000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff73ba2000-ffff73be3000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff73be3000-ffff73c23000 rw-p 00000000 00:00 0 
ffff73c23000-ffff73c25000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff73c25000-ffff73c27000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff73c27000-ffff741ce000 rw-p 00000000 00:00 0 
ffff741ce000-ffff742ce000 rw-p 00000000 00:00 0 
ffff742ce000-ffff742df000 rw-p 00000000 00:00 0 
ffff742df000-ffff762df000 rw-p 00000000 00:00 0 
ffff762df000-ffff7635f000 ---p 00000000 00:00 0 
ffff7635f000-ffff76360000 rw-p 00000000 00:00 0 
ffff76360000-ffff9635f000 ---p 00000000 00:00 0 
ffff9635f000-ffff96360000 rw-p 00000000 00:00 0 
ffff96360000-ffffb62ef000 ---p 00000000 00:00 0 
ffffb62ef000-ffffb62f0000 rw-p 00000000 00:00 0 
ffffb62f0000-ffffba2e1000 ---p 00000000 00:00 0 
ffffba2e1000-ffffba2e2000 rw-p 00000000 00:00 0 
ffffba2e2000-ffffbaadf000 ---p 00000000 00:00 0 
ffffbaadf000-ffffbaae0000 rw-p 00000000 00:00 0 
ffffbaae0000-ffffbabdf000 ---p 00000000 00:00 0 
ffffbabdf000-ffffbac3f000 rw-p 00000000 00:00 0 
ffffbac3f000-ffffbac41000 r--p 00000000 00:00 0                          [vvar]
ffffbac41000-ffffbac42000 r-xp 00000000 00:00 0                          [vdso]
ffffdd93b000-ffffdd95c000 rw-p 00000000 00:00 0                          [stack]

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.99.0.78": (string) (len=6) "router",
  (string) (len=11) "10.99.0.170": (string) (len=6) "health",
  (string) (len=11) "10.99.0.181": (string) (len=35) "kube-system/coredns-cc6ccd49c-c65lk",
  (string) (len=11) "10.99.0.119": (string) (len=35) "kube-system/coredns-cc6ccd49c-lcdmg",
  (string) (len=11) "10.99.0.183": (string) (len=50) "kube-system/clustermesh-apiserver-77695dc8d7-ddsjl"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.201.30": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40022ee790)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001b628a0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001b628a0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4002354d10)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4002354dc0)(frontends:[10.100.136.107]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4002354e70)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4003515810)(frontends:[]/ports=[etcd-metrics apiserv-metrics kvmesh-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40035158c0)(frontends:[10.100.11.17]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4001147450)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-jnp9t": (*k8s.Endpoints)(0x4003933930)(10.99.0.119:53/TCP[eu-west-3b],10.99.0.119:53/UDP[eu-west-3b],10.99.0.119:9153/TCP[eu-west-3b],10.99.0.181:53/TCP[eu-west-3b],10.99.0.181:53/UDP[eu-west-3b],10.99.0.181:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001b46998)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-tqgc4": (*k8s.Endpoints)(0x4000d888f0)(10.99.0.183:2379/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4001147440)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40023a5790)(172.31.191.56:443/TCP,172.31.239.123:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4001147448)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-89w5k": (*k8s.Endpoints)(0x40022b05b0)(172.31.201.30:4244/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4000211b90)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x400292d1d0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400881e4c8
  },
  gcTrigger: (chan struct {}) (cap=1) 0x40029299e0,
  gcExited: (chan struct {}) 0x4002929a40,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4002405b00)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001a3d5e0)({
      MetricVec: (*prometheus.MetricVec)(0x4000d18090)({
       metricMap: (*prometheus.metricMap)(0x4000d180c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000def7a0)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4002405b80)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001a3d5e8)({
      MetricVec: (*prometheus.MetricVec)(0x4000d18150)({
       metricMap: (*prometheus.metricMap)(0x4000d18210)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000def800)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4002405c00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001a3d5f0)({
      MetricVec: (*prometheus.MetricVec)(0x4000d18330)({
       metricMap: (*prometheus.metricMap)(0x4000d183f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000def860)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4002405c80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001a3d5f8)({
      MetricVec: (*prometheus.MetricVec)(0x4000d185d0)({
       metricMap: (*prometheus.metricMap)(0x4000d186f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000def8c0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4002405d00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001a3d600)({
      MetricVec: (*prometheus.MetricVec)(0x4000d189f0)({
       metricMap: (*prometheus.metricMap)(0x4000d18ab0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000def980)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4002405d80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001a3d608)({
      MetricVec: (*prometheus.MetricVec)(0x4000d18bd0)({
       metricMap: (*prometheus.metricMap)(0x4000d18c60)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000def9e0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4002405e00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001a3d610)({
      MetricVec: (*prometheus.MetricVec)(0x4000d18d80)({
       metricMap: (*prometheus.metricMap)(0x4000d18e70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000defa40)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4002405e80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001a3d618)({
      MetricVec: (*prometheus.MetricVec)(0x4000d18ed0)({
       metricMap: (*prometheus.metricMap)(0x4000d18f00)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000defaa0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4002405f00)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001a3d620)({
      MetricVec: (*prometheus.MetricVec)(0x4000d18f60)({
       metricMap: (*prometheus.metricMap)(0x4000d18f90)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000defb00)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4000211b90)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40005c02a0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x40013389a8)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 180ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations

