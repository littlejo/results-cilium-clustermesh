ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.191.56:443 (active)    
                                         2 => 172.31.239.123:443 (active)   
2    10.100.136.107:443   ClusterIP      1 => 172.31.201.30:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.99.0.119:53 (active)       
                                         2 => 10.99.0.181:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.99.0.119:9153 (active)     
                                         2 => 10.99.0.181:9153 (active)     
5    10.100.11.17:2379    ClusterIP      1 => 10.99.0.183:2379 (active)     
