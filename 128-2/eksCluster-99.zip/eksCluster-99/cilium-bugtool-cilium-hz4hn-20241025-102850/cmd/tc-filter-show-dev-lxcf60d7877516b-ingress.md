filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf60d7877516b direct-action not_in_hw id 487 tag 70ba3f605ecc9d98 jited 
