USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         623  0.0  0.4 1240432 16576 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         649  0.0  0.0   2204   784 ?        R    10:28   0:00  \_ cat /proc/net/xfrm_stat
root         650  0.0  0.0   6408  1652 ?        R    10:28   0:00  \_ ps auxfw
root         589  1.0  0.4 1229640 16744 ?       Ssl  10:28   0:00 /bin/gops stack 1
root           1  2.9  7.2 1538100 283808 ?      Ssl  10:17   0:20 cilium-agent --config-dir=/tmp/cilium/config-map
root         388  0.0  0.1 1228848 5736 ?        Sl   10:17   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
