top - 10:28:51 up 12 min,  0 users,  load average: 0.10, 0.21, 0.18
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 20.7 us, 31.0 sy,  0.0 ni, 48.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1007.1 free,    910.8 used,   1918.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2757.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1538100 283808  77760 S   0.0   7.2   0:20.53 cilium-+
    388 root      20   0 1228848   5736   2868 S   0.0   0.1   0:00.25 cilium-+
    623 root      20   0 1240432  16576  11548 S   0.0   0.4   0:00.02 cilium-+
    661 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    662 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    663 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
    696 root      20   0 1228744   3712   3040 S   0.0   0.1   0:00.00 gops
    701 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
