key: 1b 00 00 00  value: ed 01 00 00
key: 42 05 00 00  value: 4c 02 00 00
key: 87 07 00 00  value: e0 01 00 00
key: 9d 0e 00 00  value: fb 01 00 00
Found 4 elements
