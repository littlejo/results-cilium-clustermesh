REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     10312     807458      677    bpf_overlay.c
Interface                 INGRESS     226031    101287849   1132   bpf_host.c
Success                   EGRESS      10555     824166      53     encap.h
Success                   EGRESS      5268      405462      1694   bpf_host.c
Success                   EGRESS      96424     12614475    1308   bpf_lxc.c
Success                   INGRESS     106873    13196224    86     l3.h
Success                   INGRESS     112566    13642126    235    trace.h
Unsupported L3 protocol   EGRESS      35        2602        1492   bpf_lxc.c
