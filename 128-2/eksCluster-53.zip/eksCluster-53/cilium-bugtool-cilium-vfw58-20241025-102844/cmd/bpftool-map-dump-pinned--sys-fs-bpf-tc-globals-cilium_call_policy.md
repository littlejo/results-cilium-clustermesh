key: f0 01 00 00  value: 16 02 00 00
key: d2 03 00 00  value: 02 02 00 00
key: 35 04 00 00  value: 64 02 00 00
key: d0 05 00 00  value: 29 02 00 00
Found 4 elements
