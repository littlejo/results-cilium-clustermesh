USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         599  0.0  0.4 1240432 16768 ?       Ssl  10:28   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         638  0.0  0.0   6408  1644 ?        R    10:28   0:00  \_ ps auxfw
root         639  0.0  0.0    352     4 ?        R    10:28   0:00  \_ hostname
root           1  2.1  6.9 1472496 272924 ?      Ssl  10:14   0:19 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.0  0.1 1228848 5760 ?        Sl   10:14   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
