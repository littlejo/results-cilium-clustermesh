REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     186951    96517314   1132   bpf_host.c
Interface                 INGRESS     8111      633728     677    bpf_overlay.c
Success                   EGRESS      2414      381979     86     l3.h
Success                   EGRESS      3801      288758     1694   bpf_host.c
Success                   EGRESS      7780      609994     53     encap.h
Success                   EGRESS      80414     10553997   1308   bpf_lxc.c
Success                   INGRESS     88833     10706200   86     l3.h
Success                   INGRESS     96206     11477055   235    trace.h
Unsupported L3 protocol   EGRESS      36        2672       1492   bpf_lxc.c
